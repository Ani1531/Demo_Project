import get from 'lodash/get';
import * as ActionIdentifiers from '../configs/ActionIdentifiers';

const INITIAL_STATE = {
    cellDraggedToX: undefined,
    cellDraggedToY: undefined,
};

const tileDragReducer = (state = INITIAL_STATE, action) => {
    let type = get(action, 'type');
    switch (type) {
        case ActionIdentifiers.UPDATE_TILES_AND_SET_CELL:
        case ActionIdentifiers.GAME_REDUCER_UPDATE_TILES:
        case ActionIdentifiers.REDUCER_UPDATE_MOUSE_MOVE_TILE:
        case ActionIdentifiers.TILE_REDUCER_SET_HOVERING_CELL: {
            let tempState = {};
            let payload = get(action, 'payload');
            let cell = get(payload, 'cell');
            let caller = get(payload, 'caller');
            tempState.cellDraggedToX =
                caller === 'TileOnTileRelease' ? undefined : get(cell, 'tileX');
            tempState.cellDraggedToY =
                caller === 'TileOnTileRelease' ? undefined : get(cell, 'tileY');
            return tempState;
        }
    }
    return state;
};

export default tileDragReducer;
