//
//  RCTRJSKeyChain.m
//  Lexulous
//
//  Created by Balaram Singh on 31/12/21.
//

#import "RCTRJSKeyChain.h"
#import <Security/Security.h>
#import <React/RCTConvert.h>
#import <React/RCTBridge.h>
#import <React/RCTUtils.h>

@implementation RCTRJSKeyChain

@synthesize bridge = _bridge;

RCT_EXPORT_MODULE(RJSKeyChain);

static RCTRJSKeyChain *__sharedInstance=nil;//SHARED INSTANCE
static dispatch_once_t __once;

+ (BOOL)requiresMainQueueSetup {
  return NO;
}

+ (RCTRJSKeyChain*)getSharedInstanceWithService:(NSString *) service withGroup:(nullable NSString*)group{
    dispatch_once(&__once, ^{
        if(!__sharedInstance){
            __sharedInstance = [[self alloc] init];
        }
        __sharedInstance.service = service;
        __sharedInstance.group = group;
    });
    return __sharedInstance;
}

+ (RCTRJSKeyChain*)getSharedInstance{
    return [RCTRJSKeyChain getSharedInstanceWithService:SERVICE_NAME withGroup:nil];
}

- (id)init{
    if (__sharedInstance == nil) {
        if ((self = [super init])) {
            __sharedInstance = self;
        }
    }
    return __sharedInstance;
}

+ (id)allocWithZone:(NSZone *)zone{
    @synchronized(self) {
        if (__sharedInstance == nil) {
            __sharedInstance = [super allocWithZone:zone];
            return __sharedInstance;
        }
    }
    return nil;
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}
///////////////////////////////////////////////////////////////////////

-(NSMutableDictionary*) prepareDict:(NSString *) key{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];
    
    NSData *encodedKey = [key dataUsingEncoding:NSUTF8StringEncoding];
    [dict setObject:encodedKey forKey:(__bridge id)kSecAttrGeneric];
    [dict setObject:encodedKey forKey:(__bridge id)kSecAttrAccount];
    [dict setObject:[RCTRJSKeyChain getSharedInstance].service forKey:(__bridge id)kSecAttrService];
    [dict setObject:(__bridge id)kSecAttrAccessibleAlwaysThisDeviceOnly forKey:(__bridge id)kSecAttrAccessible];
    
    //This is for sharing data across apps
    if(_group != nil)
        [dict setObject:[RCTRJSKeyChain getSharedInstance].group forKey:(__bridge id)kSecAttrAccessGroup];

    return  dict;

}

RCT_EXPORT_METHOD( initChain:(RCTPromiseResolveBlock)resolve
                  reject:(__unused RCTPromiseRejectBlock)reject){
    [RCTRJSKeyChain getSharedInstance];
    resolve([NSNull null]);
}

RCT_EXPORT_METHOD( insert:(NSString *)key data:(NSData *)data  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(__unused RCTPromiseRejectBlock)reject){
    NSMutableDictionary * dict =[[RCTRJSKeyChain getSharedInstance] prepareDict:key];
    [dict setObject:data forKey:(__bridge id)kSecValueData];
    
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)dict, NULL);
    if(errSecSuccess != status) {
        //CLS_LOG(@"Unable add item with key =%@ error:%d",key,(int)status);
    }
    resolve(@(status == errSecSuccess));
}

RCT_EXPORT_METHOD( find:(NSString*)key esolve:(RCTPromiseResolveBlock)resolve
                  reject:(__unused RCTPromiseRejectBlock)reject){
    NSMutableDictionary *dict = [[RCTRJSKeyChain getSharedInstance] prepareDict:key];
    [dict setObject:(__bridge id)kSecMatchLimitOne forKey:(__bridge id)kSecMatchLimit];
    [dict setObject:(id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)dict,(CFTypeRef*)&result);
    
    if( status != errSecSuccess) {
        //CLS_LOG(@"Unable to fetch item for key %@ with error:%d",key,(int)status);
        resolve([NSNull null]);
    } else {
        NSData* dd = (__bridge NSData *)result;
        NSString* tt = [[NSString alloc] initWithData:dd encoding:NSUTF8StringEncoding];
        resolve(tt);
    }
}

RCT_EXPORT_METHOD( update:(NSString*)key data:(NSData*) data resolve:(RCTPromiseResolveBlock)resolve
                  reject:(__unused RCTPromiseRejectBlock)reject){
    NSMutableDictionary * dictKey =[[RCTRJSKeyChain getSharedInstance] prepareDict:key];

    NSMutableDictionary * dictUpdate =[[NSMutableDictionary alloc] init];
    [dictUpdate setObject:data forKey:(__bridge id)kSecValueData];

    
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)dictKey, (__bridge CFDictionaryRef)dictUpdate);
    if(errSecSuccess != status) {
        //CLS_LOG(@"Unable add update with key =%@ error:%d",key,(int)status);
    }
    resolve(@(status == errSecSuccess));
}

RCT_EXPORT_METHOD(remove: (NSString*)key resolve:(RCTPromiseResolveBlock)resolve
                  reject:(__unused RCTPromiseRejectBlock)reject){
    NSMutableDictionary *dict = [[RCTRJSKeyChain getSharedInstance] prepareDict:key];
    OSStatus status = SecItemDelete((__bridge CFDictionaryRef)dict);
    if( status != errSecSuccess) {
        //CLS_LOG(@"Unable to remove item for key %@ with error:%d",key,(int)status);
    }
    resolve(@(status == errSecSuccess));
}


@end
