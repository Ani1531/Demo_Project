import React from 'react';
import { StyleSheet, TouchableOpacity, View, FlatList, ScrollView } from 'react-native';
import {
    acceptRejectGamePlayRequest,
    deleteHostedGame,
    sendJoinGameRequest,
    sendLeaveGameRequest,
    acceptRejectJoinHostRequest,
    cancelGamePlayRequest,
    buddyRequestAction,
} from '../service/GamePlayService';
import get from 'lodash/get';
import Config from '../configs/Config';
import { formatName } from '../utils/StringUtils';
import ColorConfig from '../configs/ColorConfig';
import DimensionUtils from '../utils/DimensionUtils';
import LayoutUtils from '../utils/LayoutUtils';
import { formatToTwoDigits, getMinutesFromSeconds } from '../utils/Utils';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import Timer from 'react-compound-timer';
import { to } from 'await-to-js';
import { createDialogInstance, createGeneralRequestFailureDialog } from '../utils/MessageUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faUsers, faSpellCheck, faThumbsDown, faTrophy, faHandsHelping, faGamepad } from '@fortawesome/free-solid-svg-icons';
import {
    faGameBoardAlt,
    faGift,
    faUserFriends,
    faUsersSlash,
    faBan,
    faThumbsUp,
    faComment,
    faChessClock,
} from '@fortawesome/pro-duotone-svg-icons';
import { faTimes, faHandshake } from '@fortawesome/pro-light-svg-icons';
import AvatarImage from '../component/AvatarImage';
import {
    GAME_LIVE_GAME_CLEAR_INVITATION,
    ADD_PVT_MESSAGE_KEY,
    GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
    GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
    GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT,
    GAME_LIVE_DELETE_HOSTED_GAME,
} from '../configs/ActionIdentifiers';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import { connect } from 'react-redux';
import GameBoardUtils, { getDictionaryDetails } from '../utils/GameBoardUtils';
import { openUserGiftsPage, openUserStatsPage } from '../utils/UrlUtils';
import LayoutWrapper from '../../src/utils/LayoutWrapper';
import TooltipWrapper from '../component/TooltipWrapper';
import GameHistory from '../component/GameHistory';
import PText from '../component/PText';
import S14Text from '../component/S14Text';
import S10Text from '../component/S10Text';
import S8Text from '../component/S8Text';
import debounce from 'lodash/debounce';
import loadable from '@loadable/component';
import FontAwesomeSpin from '../component/FontAwesomeSpin';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import SparkWrapper from '../component/SparkWrapper';

const LazyProgressCircle = loadable(() => import('../component/LazyProgressCircle'));

require('format-unicorn');
const eventBus = require('js-event-bus')();

function handleStartPrivateChat() {
    this.bindFunction(this.params);
}

class ViewStatsModal extends React.PureComponent {
    state = {
        isOpen: false,
        obj: {},
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        //showOverlay: true,
        failureDetail: null,
        matchChecking: false,
        stats: true,
        showTooltip: false,
        setLoader: false,
    };

    isInvitation = (hostedGame = get(this.props, 'gamelist.hostedGame')) => get(hostedGame, 'isInvitation');

    componentDidMount = () => {
        eventBus.on(Config.CANCEL_GAME_INVITATION_EVENT, this.onMatchRequestRejected);
        eventBus.on(Config.JOIN_HOSTED_GAME_REQUEST_FAILED, this.onRequestFail);
        eventBus.on(Config.ACCEPT_GAME_REQUEST_FAILED, this.onRequestFail);
        eventBus.on(Config.DELETE_HOSTED_GAME_ACTION, this.onGameDeleted);
        eventBus.on(Config.ON_SHOW_VIEW_STATS_MODAL_FOR_SELF_HOST, this.show);
    };

    componentDidUpdate = () => {
        TooltipActionWrapper.rebuild();
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.CANCEL_GAME_INVITATION_EVENT, this.onMatchRequestRejected);
        eventBus.detach(Config.JOIN_HOSTED_GAME_REQUEST_FAILED, this.onRequestFail);
        eventBus.detach(Config.ACCEPT_GAME_REQUEST_FAILED, this.onRequestFail);
        eventBus.detach(Config.DELETE_HOSTED_GAME_ACTION, this.onGameDeleted);
        eventBus.detach(Config.ON_SHOW_VIEW_STATS_MODAL_FOR_SELF_HOST, this.show);
    };

    onGameDeleted = (res) => {
        if (this.props.gamelist.hostedGame && !!res.gameid && res.gameid === this.props.gamelist.hostedGame.gamereqid) {
            let obj = {
                message: 'This game has been deleted',
                btnText: 'OK',
            };
            this.setState({
                showOverlay: true,
                failureDetail: obj,
            });
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT);
        }
    };

    onMatchRequestRejected = (data) => {
        if (get(data, 'action') === Config.REQ_JOIN_HOSTED_GAME_REPSPONSE_ACTION) {
            let obj = {
                message: 'Player has rejected game request',
                btnText: 'OK',
            };
            this.setState({
                showOverlay: true,
                failureDetail: obj,
            });
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT, null, {
                secret: get(this.props, 'gamelist.hostedGameArr.0.secret'),
            });
        } else {
            if (LiveGamePlayUtils.isMultiplayerAcceptDialog()) {
                eventBus.emit(GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE, null, {
                    ...data,
                    reqJoinHostGame: true,
                });
            } else {
                if (this.props.gamelist.hostedGameArr.length === 1) {
                    this.onClose();
                }
                eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT, null, {
                    secret: get(data, 'secret'),
                });
            }
        }
    };

    isOpen = () => this.state.isOpen;

    show = async (hostedGame) => {
        this.setState({
            isOpen: true,
            showOverlay: false,
            failureDetail: null,
            matchChecking: hostedGame.matchCheckingTab,
            stats: hostedGame.statsTab,
            setLoader: false,
        });
    };

    selfHasJoinedMultiplayerGame = () => {
        let jndplys = (this.props.gamelist.hostedGame && this.props.gamelist.hostedGame.jndplys) || [];
        return jndplys.find((player) => player.guid === this.props.game.guid);
    };

    onRequestFail = (data) => {
        if (LiveGamePlayUtils.isHostGameRandom() && data.extcode === '1031') {
            eventBus.emit(GAME_LIVE_DELETE_HOSTED_GAME, null, {
                data: { gameid: data.gameid },
            });
        }
        createGeneralRequestFailureDialog({
            body:
                data.extcode === '1210'
                    ? 'Sorry, the request is not available.'
                    : data.extcode === '1031'
                    ? 'Sorry, someone joined this game before you. Please try another one.'
                    : data.msg,
        });
        this.hide();
    };

    onCancel = async () => {
        if (this.isInvitation()) {
            await to(acceptRejectGamePlayRequest(this.props.gamelist.hostedGame, false));
            if (this.props.gamelist.hostedGameArr.length === 1) {
                this.onClose();
            }
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT);
        } else if (get(this.props, 'gamelist.hostedGame.reqJoinHostGame') && get(this.props, 'gamelist.hostedGame.sender')) {
            this.joinHostGameReqReject(this.props.gamelist.hostedGame);
            if (this.props.gamelist.hostedGameArr.length === 1) {
                this.onClose();
            }
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT);
        } else if (get(this.props, 'gamelist.hostedGame.reqJoinHostGame')) {
            this.setState({ showOverlay: true });
            cancelGamePlayRequest(this.props.gamelist.hostedGame);
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT);
            this.onClose();
        } else {
            this.onClose();
        }
    };

    joinHostGameReqReject = (data) => {
        acceptRejectJoinHostRequest(data, false);
        if (get(data, 'secret')) {
            eventBus.emit(GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE, null, {
                ...data,
                reqJoinHostGame: true,
            });
        }
    };

    onJoinHostReqAccept = async (item = undefined) => {
        if (LiveGamePlayUtils.isMultiplayerAcceptDialog()) {
            acceptRejectJoinHostRequest(item, true);
        } else {
            if (get(this.props, 'gamelist.hostedGame.sender')) {
                acceptRejectJoinHostRequest(this.props.gamelist.hostedGame, true);
            }
        }
    };

    onLeave = async () => {
        this.setState({ showOverlay: true });
        if (this.props.emailHostGameJoin) {
            this.props.emailHostGameJoin('multileave', {
                data: {
                    reqgameid: this.props.gamelist.reqgameid,
                    guid: this.props.game.guid,
                },
            });
            this.onClose();
        } else {
            let res = await to(sendLeaveGameRequest(this.props.gamelist.hostedGame));
            if (!res[0] && res[1].extcode === '1') {
                this.onClose();
            }
        }
    };

    onClose = async () => {
        let wasOpen = this.state.isOpen;
        this.setState({
            isOpen: false,
            hostedGame: undefined,
            showOverlay: false,
            failureDetail: null,
        });
        eventBus.emit(GAME_LIVE_GAME_CLEAR_INVITATION);
        return wasOpen;
    };

    onRequestClose = () => this.onCancel();

    render = () => (this.state.isOpen ? <View style={this.getModalContentStyle()}>{this.renderBody()}</View> : null);

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height:
            DimensionUtils.isMobile() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
                ? '100%'
                : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: DimensionUtils.isMobile() ? '97%' : '70%',
        //maxHeight: '95%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    getsparkViewStyle = () => ({
        backgroundColor: ColorConfig.TRANSPARENT,
        position: 'absolute',
        top: -10,
        left: '50%',
        transform: LayoutWrapper.getSparkTransformValue(),
    });

    showed = () => {
        this.setState({ isOpen: true });
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onRequestClose();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getCloseButtonStyle = () => ({
        color: ColorConfig.BUTTON_CONTAINER_BORDER_COLOR,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    getBodyWidth = () => ({
        width: get(this.props, 'layout.layoutDialogModalMainContainerWidth'),
    });

    getOpponentObject = () => {
        let win = get(this.props, 'gamelist.hostedGame.won') || '0';
        let loss = get(this.props, 'gamelist.hostedGame.lost') || '0';
        let draw = get(this.props, 'gamelist.hostedGame.drawn') || '0';
        let playedNum = Number(win) + Number(loss) + Number(draw);
        let played = String(playedNum);
        let avtar = get(this.props, 'gamelist.hostedGame.uid.avtar');
        let bingos = get(this.props, 'gamelist.hostedGame.bingo_count') || '0';
        let gcr =
            playedNum > 0
                ? String(
                      (((playedNum - Number(get(this.props, 'gamelist.hostedGame.deleted') || '0')) / playedNum) * 100).toFixed(
                          2
                      )
                  ) + '%'
                : 'NA';
        let res = {
            name: get(this.props, 'gamelist.hostedGame.uid.name'),
            rating: get(this.props, 'gamelist.hostedGame.rating') || '0',
            jndplys: get(this.props, 'gamelist.hostedGame.jndplys') || [],
            win,
            loss,
            draw,
            bingos,
            played,
            avtar,
            gcr,
        };
        return res;
    };

    isFourPlayerAcceptDialog = (hostedGame = this.props.gamelist.hostedGame) =>
        hostedGame && !hostedGame.isInvitation && hostedGame.numplys && Number(hostedGame.numplys) === 4;

    getFlex = (value) => ({ flex: value });

    getFlexBasis = () => ({ flexBasis: '0%' });

    getAcceptRejectButtonBgColor = () =>
        !this.props.gamelist.hostedGame.selfHost &&
        !(get(this.props, 'gamelist.hostedGame.watchGame') || get(this.props, 'gamelist.hostedGame.isPlaying')) &&
        !get(this.props, 'gamelist.hostedGame.playerModal') &&
        !LiveGamePlayUtils.isHostGameRandom() &&
        !this.props.emailHostGameJoin
            ? styles.btnBgGreen
            : null;

    renderMultiPlayerGameView = (joinedPlayers, isFourPlayerAcceptDialog) => {
        let hostObject = !this.getGameSettings().isHostedByMe ? this.getOpponentObject() : this.getSelfObject();
        joinedPlayers = this.props.gamelist.hostedGame.jndplys || [];
        let players = [
            {
                avtar: hostObject.avtar,
                name: !this.props.gamelist.hostedGame ? '' : (formatName(hostObject.name) || '').trim(),
                rating: hostObject.rating,
                played: hostObject.played,
                bingos: hostObject.bingos,
                win: hostObject.win,
                loss: hostObject.loss,
                draw: hostObject.draw,
                flexWon:
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(hostObject.win) / Number(hostObject.played)).toFixed(2))
                        : 0,
                flexLost:
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(hostObject.loss) / Number(hostObject.played)).toFixed(2))
                        : 0,
                flexDraw:
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(hostObject.draw) / Number(hostObject.played)).toFixed(2))
                        : 0,
            },
        ];
        joinedPlayers.length !== 0 &&
            joinedPlayers.map((element) => {
                element.flexWon =
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(element.win) / Number(element.played)).toFixed(2))
                        : 0;
                element.flexLost =
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(element.loss) / Number(element.played)).toFixed(2))
                        : 0;
                element.flexDraw =
                    Number(hostObject.played) !== 0
                        ? Number(Number(Number(element.draw) / Number(element.played)).toFixed(2))
                        : 0;
                players.push(element);
            });
        players.forEach((element) => {
            if (element.flexWon == 0 && element.flexLost == 0 && element.flexDraw == 0) {
                element.flexWon = 0.33;
                element.flexLost = 0.33;
                element.flexDraw = 0.33;
            }
        });
        return (
            <>
                <FlatList
                    keyExtractor={(item, index) => index.toString()}
                    data={players}
                    renderItem={({ item, index }) => (
                        <View style={[styles.playerNameRowStyle, index !== 0 && styles.paddingTopZero]} key={index}>
                            <View style={[styles.playerEachNameRowStyle, this.getFlex(0.8), this.getFlexBasis()]}>
                                {item.avtar ? this.renderAvatar(item) : null}
                                <View style={[styles.leftPlayerNameView, styles.borderRadiusFive]}>
                                    <S14Text style={styles.colorWhite}>{item.name + ' (' + item.rating + ')'}</S14Text>
                                </View>
                            </View>
                            <View style={[this.getFlex(0.2), this.getFlexBasis()]} />
                            {get(item, 'secret') ? (
                                <View
                                    style={[
                                        this.getFlex(0.8),
                                        this.getFlexBasis(),
                                        styles.flexDirectionRow,
                                        styles.justifyContentCenter,
                                        styles.alignItemsCenter,
                                    ]}
                                >
                                    <TouchableOpacity
                                        style={styles.acceptDeleteJoinTouchableStyle}
                                        onPress={() => this.joinHostGameReqReject(item)}
                                    >
                                        <PText style={styles.touchableTextStyle}>Reject</PText>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        activeOpacity={1}
                                        style={[styles.acceptDeleteJoinTouchableStyle, styles.btnBgGreen]}
                                        onPress={() => this.onJoinHostReqAccept(item)}
                                    >
                                        <PText style={styles.touchableTextStyle}>
                                            {this.renderJoinHostGameTimerBtn(true, get(item, 'wait'), () =>
                                                eventBus.emit(GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE, null, {
                                                    ...item,
                                                    reqJoinHostGame: true,
                                                })
                                            )}
                                        </PText>
                                    </TouchableOpacity>
                                </View>
                            ) : (
                                <View style={[this.getFlex(0.8), this.getFlexBasis()]}>
                                    <View style={styles.gamesPlayedEachRowView}>
                                        {this.renderProgressBar({
                                            winFlex: item.flexWon,
                                            drawFlex: item.flexDraw,
                                            lossFlex: item.flexLost,
                                            winText: item.win,
                                            lossText: item.loss,
                                            drawText: item.draw,
                                            isSelfObject: true,
                                        })}
                                    </View>
                                    <View style={[styles.gamesPlayedRowView, styles.marginHorizontalZero]}>
                                        <View style={[styles.gamesBingosRowView]}>
                                            <S10Text
                                                style={[styles.gamesText, styles.bingosText, styles.bingosTextForPlayerModal]}
                                            >
                                                {'Bingos: ' + item.bingos}
                                            </S10Text>
                                            <S10Text style={[styles.gamesText, styles.paddingHorizontal0]}>
                                                {'Games: ' + item.played}
                                            </S10Text>
                                        </View>
                                    </View>
                                </View>
                            )}
                        </View>
                    )}
                />
                {joinedPlayers.length === 0 && (
                    <View style={[styles.waitingView, styles.marginBottom10]}>
                        <S14Text>Waiting For Player 2</S14Text>
                    </View>
                )}
                {joinedPlayers.length <= 1 && (
                    <View style={[styles.waitingView, styles.marginBottom10]}>
                        <S14Text>Wating For Player 3</S14Text>
                    </View>
                )}
                {joinedPlayers.length <= 2 && isFourPlayerAcceptDialog && (
                    <View style={styles.waitingView}>
                        <S14Text>Wating For Player 4</S14Text>
                    </View>
                )}
                <View style={[this.getsparkViewStyle(), this.getLeft('48%')]}>
                    <View style={this.getTop(45)}>
                        <SparkWrapper style={this.getMultiPlayerSparkStyleIconObj()} />
                    </View>
                    <View style={this.getTop(58)}>
                        <SparkWrapper style={this.getMultiPlayerSparkStyleIconObj()} />
                    </View>
                    {isFourPlayerAcceptDialog && (
                        <View style={this.getTop(71)}>
                            <SparkWrapper style={this.getMultiPlayerSparkStyleIconObj()} />
                        </View>
                    )}
                </View>
            </>
        );
    };

    getTop = (top) => ({ top });
    getLeft = (left) => ({ left });

    renderAvatar = (playerObject) => (
        <AvatarImage
            id={'avatar_' + playerObject ? playerObject.guid : '0'}
            key={'avatar_' + playerObject ? playerObject.guid : '0'}
            resizeMode={'contain'}
            style={styles.avtarImageStyle}
            show={playerObject ? playerObject.avtar : '0'}
            uri={ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('avatar_url_format').formatUnicorn({
                id: playerObject ? playerObject.avtar : '0',
            })}
        />
    );

    renderProgressBar = ({ winFlex, lossFlex, drawFlex, winText, lossText, drawText, isHeadToHead, isSelfObject }) => (
        <>
            <TooltipWrapper
                style={[
                    styles.yellowView,
                    this.getFlex(winFlex || 0),
                    isSelfObject && styles.borderTopBottomLeftRadiusTwo,
                    !isSelfObject && styles.borderTopBottomRightRadiusTwo,
                    lossFlex === 0 && styles.borderTopBottomRightRadiusTwo,
                ]}
                tooltip={
                    isHeadToHead
                        ? 'Win (' + Math.round(winFlex * 100) + '%)'
                        : 'Win ' + Math.round(winFlex * 100) + '%' + (' (' + winText + ')')
                }
            />
            <TooltipWrapper
                style={[styles.blueView, this.getFlex(drawFlex || 0)]}
                tooltip={
                    isHeadToHead
                        ? 'Draw (' + Math.round(drawFlex * 100) + '%)'
                        : 'Draw ' + Math.round(drawFlex * 100) + '%' + (' (' + drawText + ')')
                }
            />
            <TooltipWrapper
                style={[
                    styles.greyView,
                    this.getFlex(lossFlex || 0),
                    isSelfObject && styles.borderTopBottomRightRadiusTwo,
                    !isSelfObject && styles.borderTopBottomLeftRadiusTwo,
                    winFlex === 0 && styles.borderTopBottomLeftRadiusTwo,
                    winFlex === 0 && lossFlex === 0 && this.getFlex(1),
                ]}
                tooltip={
                    isHeadToHead
                        ? winFlex === 0 && lossFlex === 0
                            ? 'No match has been played till now'
                            : 'Loss (' + Math.round(lossFlex * 100) + '%)'
                        : 'Loss ' + Math.round(lossFlex * 100) + '%' + (' (' + lossText + ')')
                }
            />
        </>
    );

    renderTwoPlayerGameView = (hostedGame) => {
        let opponentObject = this.getOpponentObject();
        let selfObject = this.getSelfObject();
        let opponentName = !this.props.gamelist.hostedGame
            ? ''
            : hostedGame.stats
            ? (formatName(get(hostedGame, 'playerItem.name')) || '').trim()
            : (formatName(opponentObject.name) || '').trim();
        let opponentRating = !this.props.gamelist.hostedGame
            ? ''
            : hostedGame.stats
            ? get(this.props, 'gamelist.hostedGame.stats.data.0.rating_stats.rating') || '0'
            : opponentObject.rating;
        let selfName = !this.props.gamelist.hostedGame ? '' : (formatName(selfObject.name) || '').trim();
        let flexSelfWon =
            !this.props.gamelist.hostedGame || Number(selfObject.played) === 0
                ? 0
                : Number(Number(Number(selfObject.win) / Number(selfObject.played)).toFixed(2));
        let flexSelfLost =
            !this.props.gamelist.hostedGame || Number(selfObject.played) === 0
                ? 0
                : Number(Number(Number(selfObject.loss) / Number(selfObject.played)).toFixed(2));
        let flexSelfDraw =
            !this.props.gamelist.hostedGame || Number(selfObject.played) === 0
                ? 0
                : Number(Number(Number(selfObject.draw) / Number(selfObject.played)).toFixed(2));
        let flexOpponentWon =
            hostedGame && hostedGame.stats
                ? get(hostedGame, 'stats.data.0.game_stats') &&
                  get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0 &&
                  Number(get(hostedGame, 'stats.data.0.game_stats.played')) !== 0
                    ? Number(
                          Number(
                              Number(get(hostedGame, 'stats.data.0.game_stats.won')) /
                                  Number(get(hostedGame, 'stats.data.0.game_stats.played'))
                          ).toFixed(2)
                      )
                    : 0
                : !this.props.gamelist.hostedGame || Number(opponentObject.played) === 0
                ? 0
                : Number(Number(Number(opponentObject.win) / Number(opponentObject.played)).toFixed(2));
        let flexOpponentLost =
            hostedGame && hostedGame.stats
                ? get(hostedGame, 'stats.data.0.game_stats') &&
                  get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0 &&
                  Number(get(hostedGame, 'stats.data.0.game_stats.played')) !== 0
                    ? Number(
                          Number(
                              Number(get(hostedGame, 'stats.data.0.game_stats.lost')) /
                                  Number(get(hostedGame, 'stats.data.0.game_stats.played'))
                          ).toFixed(2)
                      )
                    : 0
                : !this.props.gamelist.hostedGame || Number(opponentObject.played) === 0
                ? 0
                : Number(Number(Number(opponentObject.loss) / Number(opponentObject.played)).toFixed(2));
        let flexOpponentDraw =
            hostedGame && hostedGame.stats
                ? get(hostedGame, 'stats.data.0.game_stats') &&
                  get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0 &&
                  Number(get(hostedGame, 'stats.data.0.game_stats.played')) !== 0
                    ? Number(
                          Number(
                              Number(get(hostedGame, 'stats.data.0.game_stats.drawn')) /
                                  Number(get(hostedGame, 'stats.data.0.game_stats.played'))
                          ).toFixed(2)
                      )
                    : 0
                : !this.props.gamelist.hostedGame || Number(opponentObject.played) === 0
                ? 0
                : Number(Number(Number(opponentObject.draw) / Number(opponentObject.played)).toFixed(2));

        if (flexSelfWon == 0 && flexSelfLost == 0 && flexSelfDraw === 0) {
            flexSelfWon = 0.33;
            flexSelfLost = 0.33;
            flexSelfDraw = 0.33;
        }
        if (flexOpponentWon === 0 && flexOpponentLost === 0 && flexOpponentDraw === 0) {
            flexOpponentWon = 0.33;
            flexOpponentLost = 0.33;
            flexOpponentDraw = 0.33;
        }
        return (
            <>
                <View style={styles.playerNameRowStyle}>
                    <View style={styles.playerEachNameRowStyle}>
                        {selfObject.avtar ? this.renderAvatar(selfObject) : null}
                        <View style={styles.leftPlayerNameView}>
                            <S14Text
                                numberOfLines={2}
                                ellipsizeMode={'tail'}
                                style={[
                                    styles.colorWhite,
                                    DimensionUtils.isMobile()
                                        ? {
                                              fontSize: DimensionUtils.getWindowDimensions().width * 0.03,
                                          }
                                        : {},
                                ]}
                            >
                                {DimensionUtils.isMobile()
                                    ? selfName + '\n(' + selfObject.rating + ')'
                                    : selfName + ' (' + selfObject.rating + ')'}
                            </S14Text>
                        </View>
                    </View>
                    <View style={styles.playerEachNameRowStyle}>
                        <View style={styles.rightPlayerNameView}>
                            <S14Text
                                numberOfLines={2}
                                ellipsizeMode={'tail'}
                                style={[
                                    styles.colorWhiteAlignRight,
                                    DimensionUtils.isMobile()
                                        ? {
                                              fontSize: DimensionUtils.getWindowDimensions().width * 0.03,
                                          }
                                        : {},
                                ]}
                            >
                                {DimensionUtils.isMobile()
                                    ? opponentName + '\n(' + opponentRating + ')'
                                    : '(' + opponentRating + ') ' + opponentName}
                            </S14Text>
                        </View>
                        {opponentObject.avtar
                            ? this.renderAvatar(opponentObject)
                            : hostedGame && hostedGame.playerItem
                            ? this.renderAvatar(hostedGame.playerItem)
                            : null}
                    </View>
                    <View style={this.getsparkViewStyle()}>
                        <SparkWrapper style={this.getSparkStyleIconObj()} />
                    </View>
                </View>
                <View style={styles.gamesPlayedRowView}>
                    <View style={styles.gamesPlayedEachRowView}>
                        {this.renderProgressBar({
                            winFlex: flexSelfWon,
                            drawFlex: flexSelfDraw,
                            lossFlex: flexSelfLost,
                            winText: selfObject.win,
                            lossText: selfObject.loss,
                            drawText: selfObject.draw,
                            isSelfObject: true,
                        })}
                    </View>
                    <View style={this.getWidth(16)} />
                    <View style={[styles.gamesPlayedEachRowView, styles.flexDirectionRowReverse]}>
                        {this.renderProgressBar({
                            winFlex: flexOpponentWon,
                            drawFlex: flexOpponentDraw,
                            lossFlex: flexOpponentLost,
                            winText:
                                hostedGame && hostedGame.stats
                                    ? get(hostedGame, 'stats.data.0.game_stats') &&
                                      get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0
                                        ? get(hostedGame, 'stats.data.0.game_stats.won') || '0'
                                        : '0'
                                    : !this.props.gamelist.hostedGame
                                    ? '0'
                                    : opponentObject.win,
                            lossText:
                                hostedGame && hostedGame.stats
                                    ? get(hostedGame, 'stats.data.0.game_stats') &&
                                      get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0
                                        ? get(hostedGame, 'stats.data.0.game_stats.lost') || '0'
                                        : '0'
                                    : !this.props.gamelist.hostedGame
                                    ? '0'
                                    : opponentObject.loss,
                            drawText:
                                hostedGame && hostedGame.stats
                                    ? get(hostedGame, 'stats.data.0.game_stats') &&
                                      get(hostedGame, 'stats.data.0.game_stats.active_game_count') !== 0
                                        ? get(hostedGame, 'stats.data.0.game_stats.drawn') || '0'
                                        : '0'
                                    : !this.props.gamelist.hostedGame
                                    ? '0'
                                    : opponentObject.draw,
                        })}
                    </View>
                </View>
                <View style={[styles.gamesPlayedRowView]}>
                    <View style={[styles.gamesBingosRowView]}>
                        <S10Text style={[styles.gamesText, styles.bingosText, styles.bingosTextForPlayerModal]}>
                            {'Bingos: ' + selfObject.bingos}
                        </S10Text>
                        <S10Text style={[styles.gamesText, styles.paddingHorizontal0, { textAlign: 'right' }]}>
                            {'Games: ' + selfObject.played}
                        </S10Text>
                    </View>
                    <View style={this.getWidth(16)} />
                    <View style={[styles.gamesBingosRowReverseView]}>
                        <S10Text
                            style={[
                                styles.gamesText,
                                styles.bingosText,
                                styles.bingosTextForPlayerModal,
                                { textAlign: 'right' },
                            ]}
                        >
                            {`Bingos: ${
                                hostedGame && hostedGame.stats
                                    ? get(hostedGame, 'stats.data.0.game_stats.bingo_count') || '0'
                                    : opponentObject.bingos
                            }`}
                        </S10Text>
                        <S10Text style={[styles.gamesText, styles.paddingHorizontal0]}>
                            {`Games: ${
                                hostedGame && hostedGame.stats
                                    ? get(hostedGame, 'stats.data.0.game_stats.played') || '0'
                                    : opponentObject.played
                            }`}
                        </S10Text>
                    </View>
                </View>
            </>
        );
    };

    getSparkStyleIconObj = () => ({
        height: 80,
        width: 45,
    });

    getMultiPlayerSparkStyleIconObj = () => ({
        height: 25,
        width: 15,
    });

    getGameSettings = () => {
        let numberOfPlayers = get(this.props, 'gamelist.hostedGame.numplys') || '2';
        let dictionary = get(this.props, 'gamelist.hostedGame.dic') || 'sow';

        return {
            numberOfPlayers,
            dictionary: getDictionaryDetails(dictionary).explanation,
            playerNotes: get(this.props, 'gamelist.hostedGame.brag') || '',
            isHostedByMe: get(this.props, 'gamelist.hostedGame.selfHost'),
            boardType: get(this.props, 'gamelist.hostedGame.boardtype') || 'N',
            isChallengeGame: GameBoardUtils.isChallengeModeStr(get(this.props, 'gamelist.hostedGame.gametype')),
            duration: get(this.props, 'gamelist.hostedGame.live.duration') || '0',
            increament: get(this.props, 'gamelist.hostedGame.live.increament') || '0',
        };
    };

    getGameSettingsIconStyleObj = () => ({
        color: 'rgb(52, 132, 240)',
        fontSize: 15,
    });

    getWidth = (value) => ({ width: value });

    renderGameSettings = () => {
        let gameSettings = this.getGameSettings();
        let boardType =
            gameSettings.boardType.toUpperCase() === 'N'
                ? 'Lexulous'
                : gameSettings.boardType.toUpperCase() === 'S'
                ? 'Super Lexulous'
                : '';

        let gameSettingsChildren = [
            <View style={[styles.eachGameSettingStyleView, DimensionUtils.isMobile() ? { marginHorizontal: 2 } : null]}>
                <FontAwesomeIcon icon={faUsers} size={15} style={this.getGameSettingsIconStyleObj()} />
                <PText style={[styles.gameSettingsTextStyle]}>{this.getGameSettings().numberOfPlayers + ' players'}</PText>
            </View>,
            boardType !== 'Lexulous' && (
                <View style={styles.eachGameSettingStyleView}>
                    <FontAwesomeIcon icon={faGameBoardAlt} size={15} style={this.getGameSettingsIconStyleObj()} />
                    <PText style={[styles.gameSettingsTextStyle]}>{boardType}</PText>
                </View>
            ),
            <View style={[styles.eachGameSettingStyleView, DimensionUtils.isMobile() ? { marginHorizontal: 2 } : null]}>
                <FontAwesomeIcon icon={faSpellCheck} size={15} style={this.getGameSettingsIconStyleObj()} />
                <PText style={[styles.gameSettingsTextStyle]}>{this.getGameSettings().dictionary}</PText>
            </View>,
            <View style={[styles.eachGameSettingStyleView, DimensionUtils.isMobile() ? { marginHorizontal: 2 } : null]}>
                <FontAwesomeIcon
                    icon={faChessClock}
                    size={18}
                    style={{
                        color: 'rgb(52, 132, 240)',
                    }}
                />
                <PText style={[styles.gameSettingsTextStyle]}>
                    {this.props.emailHostGameJoin
                        ? get(this.props.gamelist.hostedGame, 'fftdays') + ' days'
                        : Number(gameSettings.duration) / 60 + ' min ' + gameSettings.increament + ' inc'}
                </PText>
            </View>,
            get(gameSettings, 'isChallengeGame') ? (
                <View style={styles.eachGameSettingStyleView}>
                    <FontAwesomeIcon
                        icon={faGamepad}
                        size={18}
                        style={{
                            color: 'rgb(52, 132, 240)',
                        }}
                    />
                    <PText style={[styles.gameSettingsTextStyle]}>{'Challenge'}</PText>
                </View>
            ) : null,
        ];
        return (
            <View style={[styles.gameSettingsView, styles.flex1, styles.spaceBetweenRowStyle]}>
                <View
                    style={[
                        styles.gameSettingsStartingView,
                        DimensionUtils.isMobile() ? { paddingLeft: 8, paddingRight: 5 } : null,
                    ]}
                >
                    <S14Text style={[styles.gameSettingsHeadingTextStyle]}>Game Settings</S14Text>
                </View>

                {DimensionUtils.isMobile() ? (
                    <ScrollView horizontal={true} contentContainerStyle={[styles.gameSettingsView]}>
                        {gameSettingsChildren}
                    </ScrollView>
                ) : (
                    <View
                        style={[
                            styles.gameSettingsView,
                            {
                                justifyContent: 'flex-end',
                                alignItems: 'center',
                            },
                        ]}
                    >
                        {' '}
                        {gameSettingsChildren}
                    </View>
                )}
            </View>
        );
    };

    getColor = (color) => ({ color });

    renderHeadToHeadAndRatingChange = () => {
        let h2hLost = get(this.props, 'gamelist.hostedGame.headToHeadData.lost');
        let flexLost =
            !this.props.gamelist.hostedGame || !h2hLost
                ? 0
                : Number((Number(h2hLost.split('( ')[1].split('% )')[0]) / 100).toFixed(2));
        let h2hWon = get(this.props, 'gamelist.hostedGame.headToHeadData.won');
        let flexWon =
            !this.props.gamelist.hostedGame || !h2hWon
                ? 0
                : Number((Number(h2hWon.split('( ')[1].split('% )')[0]) / 100).toFixed(2));
        let h2hDraw = get(this.props, 'gamelist.hostedGame.headToHeadData.draw');
        let flexDraw =
            !this.props.gamelist.hostedGame || !h2hDraw
                ? 0
                : Number((Number(h2hDraw.split('( ')[1].split('% )')[0]) / 100).toFixed(2));

        let wonChange =
            parseInt(get(this.props, 'gamelist.hostedGame.ratingChange.0') || '0') > 0
                ? '+' + get(this.props, 'gamelist.hostedGame.ratingChange.0') || '0'
                : get(this.props, 'gamelist.hostedGame.ratingChange.0') || '0';
        let disLikeChange =
            parseInt(get(this.props, 'gamelist.hostedGame.ratingChange.1') || '0') > 0
                ? '+' + get(this.props, 'gamelist.hostedGame.ratingChange.1') || '0'
                : get(this.props, 'gamelist.hostedGame.ratingChange.1') || '0';
        let shareChange =
            parseInt(get(this.props, 'gamelist.hostedGame.ratingChange.2') || '0') > 0
                ? '+' + get(this.props, 'gamelist.hostedGame.ratingChange.2') || '0'
                : get(this.props, 'gamelist.hostedGame.ratingChange.2') || '0';
        return (
            <View style={[styles.gameSettingsView, styles.justifyContentSpaceBetween, { height: '40%' }]}>
                <View style={[styles.eachHeadToHeadAndRatingChangeViewStyle]}>
                    <S14Text
                        style={[
                            styles.gameSettingsHeadingTextStyle,
                            styles.headToHeadRatingChangeHeadingTextExtraStyle,
                            DimensionUtils.isMobile() ? { fontSize: 12 } : null,
                        ]}
                    >
                        Head To Head
                    </S14Text>
                    <View style={[styles.gamesPlayedEachRowView, styles.additionalStyleForHeadToHeadProgressBar]}>
                        {this.renderProgressBar({
                            winFlex: flexWon,
                            lossFlex: flexLost,
                            drawFlex: flexDraw,
                            isHeadToHead: true,
                            isSelfObject: true,
                        })}
                    </View>
                    <View style={[styles.gameSettingsView, styles.justifyContentSpaceBetween]}>
                        <PText style={[styles.gamesText, styles.winLossTextWrapperStyle]}>
                            {'Win (' + String(Math.round(flexWon * 100)) + '%)'}
                        </PText>
                        <PText style={[styles.gamesText, styles.winLossTextWrapperStyle, styles.textAlignRight]}>
                            {'Lost (' + String(Math.round(flexLost * 100)) + '%)'}
                        </PText>
                    </View>
                </View>
                <View style={[{ width: 5 }]} />
                <View style={[styles.eachHeadToHeadAndRatingChangeViewStyle]}>
                    <S14Text
                        style={[
                            styles.gameSettingsHeadingTextStyle,
                            styles.headToHeadRatingChangeHeadingTextExtraStyle,
                            DimensionUtils.isMobile() ? { fontSize: 12 } : null,
                        ]}
                    >
                        Rating Change
                    </S14Text>
                    <View style={[styles.gameSettingsView, styles.ratingChangeIconsOuterView]}>
                        <View style={styles.ratingChangeEachItemContainerStyle}>
                            <FontAwesomeIcon
                                icon={faTrophy}
                                size={15}
                                style={{
                                    color: '#ffbf37',
                                }}
                            />
                            <PText style={[styles.gameSettingsTextStyle, this.getColor('#ffbf37')]}>{wonChange}</PText>
                        </View>
                        <View style={styles.ratingChangeEachItemContainerStyle}>
                            <FontAwesomeIcon
                                icon={faThumbsDown}
                                size={15}
                                style={{
                                    color: '#ff0000',
                                }}
                            />
                            <PText style={[styles.gameSettingsTextStyle, this.getColor('#ff0000')]}>{disLikeChange}</PText>
                        </View>
                        <View style={styles.ratingChangeEachItemContainerStyle}>
                            <FontAwesomeIcon
                                icon={faHandsHelping}
                                size={15}
                                style={{
                                    color: '#666',
                                }}
                            />
                            <PText style={[styles.gameSettingsTextStyle, this.getColor('#666')]}>{shareChange}</PText>
                        </View>
                    </View>
                </View>
            </View>
        );
    };

    getAlignItems = (alignItems) => ({ alignItems });

    renderLast15GamesHistory = () => {
        return LiveGamePlayUtils.isGameHistoryAvailable() ? (
            <View style={[styles.styleEachStatBox, styles.gameSettingsExtraStyle]}>
                <S14Text style={[styles.gameSettingsHeadingTextStyle, styles.headToHeadRatingChangeHeadingTextExtraStyle]}>
                    Last 15 Games
                </S14Text>
                <GameHistory
                    statModal={true}
                    myName={(formatName(this.getSelfObject().name) || '').trim()}
                    opponentName={formatName(
                        get(this.props, 'gamelist.hostedGame.playerItem.name') ||
                            get(this.props, 'gamelist.hostedGame.uid.name')
                    ).trim()}
                />
            </View>
        ) : null;
    };

    renderPlayersNotes = () => (
        <View style={styles.gameSettingsView}>
            <View style={styles.playerNotesView}>
                <S14Text style={[styles.gameSettingsHeadingTextStyle, styles.playerNotesAdditionalStyle]}>
                    Player's Note
                </S14Text>
            </View>
            <View style={this.getFlex(0.8)}>
                <S10Text style={styles.playerNotesDescTextStyle}>
                    {get(this.getGameSettings(), 'playerNotes') ? atob(this.getGameSettings().playerNotes) : ''}
                </S10Text>
            </View>
        </View>
    );

    getAcceptJoinDeleteButtonStyle = () => ({
        backgroundColor: 'rgb(177, 46, 56)',
        padding: 8,
        borderRadius: 3,
        color: '#fff',
        marginRight: 10,
    });

    getAdditionalStyleForCancelButton = () => ({
        marginRight: 0,
        color: '#777',
    });

    getCloseButtonAdditionalStyle = () => ({
        backgroundColor: this.state.closeBGColor,
    });

    renderStats = (stats) => (
        <View style={[styles.gameSettingsView, styles.playerModalStatsAdditionalView]}>
            <View style={[styles.eachGameSettingStyleView]}>
                <FontAwesomeIcon
                    icon={faGamepad}
                    size={22}
                    style={{
                        color: '#3484f0',
                    }}
                />
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleStatGames]}>
                    {get(stats, 'data.0.game_stats') ? get(stats, 'data.0.game_stats.played') || '0' : '0'}
                </S8Text>
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleGameWinLossDrawText]}>Games</S8Text>
            </View>
            <View style={[styles.eachGameSettingStyleView, styles.paddingTop1]}>
                <FontAwesomeIcon
                    icon={faTrophy}
                    size={22}
                    style={{
                        color: '#ffbf37',
                    }}
                />
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleStatWins]}>
                    {get(stats, 'data.0.game_stats') ? get(stats, 'data.0.game_stats.won') || '0' : '0'}
                </S8Text>
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleGameWinLossDrawText]}>Wins</S8Text>
            </View>
            <View style={[styles.eachGameSettingStyleView, styles.paddingTop1]}>
                <FontAwesomeIcon
                    icon={faThumbsDown}
                    size={22}
                    style={{
                        color: '#ff0000',
                    }}
                />
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleStatLoss]}>
                    {get(stats, 'data.0.game_stats') ? get(stats, 'data.0.game_stats.lost') || '0' : '0'}
                </S8Text>
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleGameWinLossDrawText]}>Losses</S8Text>
            </View>
            <View style={[styles.eachGameSettingStyleView]}>
                <FontAwesomeIcon
                    icon={faHandshake}
                    size={22}
                    style={{
                        color: '#7f7f7f',
                    }}
                />
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleStatDraw]}>
                    {get(stats, 'data.0.game_stats') ? get(stats, 'data.0.game_stats.drawn') || '0' : '0'}
                </S8Text>
                <S8Text style={[styles.gameSettingsTextStyle, styles.styleGameWinLossDrawText]}>Draws</S8Text>
            </View>
        </View>
    );

    renderScores = (stats) => {
        let avgBingoCount =
            get(stats, 'data.0.game_stats') && parseInt(get(stats, 'data.0.game_stats.played') || '0') !== 0
                ? Number(
                      parseInt(get(stats, 'data.0.game_stats.bingo_count') || '0') /
                          parseInt(get(stats, 'data.0.game_stats.played'))
                  ).toFixed(2)
                : '--';
        let leftStatArray = [
            {
                title: 'Highest score',
                details: get(stats, 'data.0.hgms_stats') ? get(stats, 'data.0.hgms_stats.score') || '0' : '--',
            },
            {
                title: 'Total bingos',
                details: get(stats, 'data.0.game_stats') ? get(stats, 'data.0.game_stats.bingo_count') || '0' : '--',
            },
            { title: 'Avg bingos per game', details: avgBingoCount },
            {
                title: 'Avg game score',
                details: get(stats, 'data.0.game_stats')
                    ? get(stats, 'data.0.game_stats.avg_game_score')
                        ? Number(get(stats, 'data.0.game_stats.avg_game_score')).toFixed(2)
                        : '0.00'
                    : '--',
            },
            {
                title: 'Avg score per move',
                details: get(stats, 'data.0.move_stats')
                    ? get(stats, 'data.0.move_stats.avg_move_score')
                        ? Number(get(stats, 'data.0.move_stats.avg_move_score')).toFixed(2)
                        : '0.00'
                    : '--',
            },
            {
                title: 'Most bingos in a game',
                details: get(stats, 'data.0.stats_ext1') ? get(stats, 'data.0.stats_ext1.mostbingosinagame.cnt') || '0' : '--',
            },
        ];
        let rightStatArray = [
            {
                title: '30+ Point Move',
                details: get(stats, 'data.0.stats_ext1') ? get(stats, 'data.0.stats_ext1.mvs30p') || '0' : '--',
            },
            {
                title: '50+ Point Move',
                details: get(stats, 'data.0.stats_ext1') ? get(stats, 'data.0.stats_ext1.mvs50p') || '0' : '--',
            },
            {
                title: '100+ Point Move',
                details: get(stats, 'data.0.stats_ext1') ? get(stats, 'data.0.stats_ext1.mvs100p') || '0' : '--',
            },
            {
                title: 'Avg Time Per Move',
                details: get(stats, 'data.0.move_stats')
                    ? get(stats, 'data.0.move_stats.avg_move_time_spend')
                        ? Number(get(stats, 'data.0.move_stats.avg_move_time_spend')).toFixed(2) + 'h'
                        : '0.00h'
                    : '--',
            },
            {
                title: 'Best Win ever',
                details: get(stats, 'data.0.stats_ext1')
                    ? get(stats, 'data.0.stats_ext1.bestwinever.score')
                        ? Number(get(stats, 'data.0.stats_ext1.bestwinever.score'))
                        : '0'
                    : '--',
            },
            {
                title: 'Best Bingo Score Ever',
                details: get(stats, 'data.0.stats_ext1')
                    ? get(stats, 'data.0.stats_ext1.bestbingoever.score')
                        ? Number(get(stats, 'data.0.stats_ext1.bestbingoever.score'))
                        : '0'
                    : '--',
            },
        ];
        return (
            <View style={[styles.gameSettingsView, styles.justifyContentSpaceBetween]}>
                <View style={styles.eachColumnView}>
                    {leftStatArray.map((element, key) => (
                        <View style={[styles.eachColumnRowView]} key={key}>
                            <View
                                style={[
                                    styles.eachColumnRowLeftView,
                                    key === 0 && styles.borderTopLeftRadiusPaddingTop,
                                    key === leftStatArray.length - 1 && styles.borderBottomLeftRadiusPaddingBottom,
                                    this.getFlexBasis(),
                                ]}
                            >
                                <S10Text style={[styles.styleScoreHeadingStyle, styles.headingTitleTextAdditionalStyle]}>
                                    {element.title}
                                </S10Text>
                            </View>
                            <View
                                style={[
                                    styles.eachColumnRowRightView,
                                    key === 0 && styles.paddingTop16,
                                    key === leftStatArray.length - 1 && styles.paddingBottom14,
                                    ,
                                    this.getFlexBasis(),
                                ]}
                            >
                                <S10Text style={[styles.styleScoresTextStyle]}>{element.details}</S10Text>
                            </View>
                        </View>
                    ))}
                </View>
                <View style={styles.eachColumnView}>
                    {rightStatArray.map((element, key) => (
                        <View style={[styles.eachColumnRowView]} key={key}>
                            <View
                                style={[
                                    styles.eachColumnRowLeftView,
                                    key === 0 && styles.paddingTop15,
                                    key === rightStatArray.length - 1 && styles.paddingBottom15,
                                    ,
                                    this.getFlexBasis(),
                                ]}
                            >
                                <S10Text style={[styles.styleScoreHeadingStyle, styles.headingTitleTextAdditionalStyle]}>
                                    {element.title}
                                </S10Text>
                            </View>
                            <View
                                style={[
                                    styles.eachColumnRowRightView,
                                    key === 0 && styles.borderTopRightRadiusPaddingTop,
                                    key === rightStatArray.length - 1 && styles.borderBottomRightRadiusPaddingBottom,
                                    ,
                                    this.getFlexBasis(),
                                ]}
                            >
                                <S10Text style={[styles.styleScoresTextStyle]}>{element.details}</S10Text>
                            </View>
                        </View>
                    ))}
                </View>
            </View>
        );
    };

    renderBingoScoreView = (stats) => {
        let bestBingoScore = [];
        for (let i = 0; i < get(stats, 'data.0.stats_ext1.bestbingoever.word').length; i++) {
            bestBingoScore.push(get(stats, 'data.0.stats_ext1.bestbingoever.word')[i].toUpperCase());
        }
        bestBingoScore.push(get(stats, 'data.0.stats_ext1.bestbingoever.score') || '0');
        return (
            <>
                <S10Text style={[styles.styleScoreHeadingStyle, styles.bestBingoScoreTextStyle]}>Best Bingo Score : </S10Text>
                <View style={styles.bestBingoScoreView}>
                    <FlatList
                        keyExtractor={(item, index) => index.toString()}
                        data={bestBingoScore}
                        horizontal
                        ItemSeparatorComponent={() => <View style={this.getWidth(2)} />}
                        renderItem={({ item, index }) => (
                            <View
                                style={[
                                    styles.bestBingoScoreEachLetterView,
                                    index === bestBingoScore.length - 1 && styles.additionalBingoScoreViewForBingoScoreText,
                                ]}
                                key={index}
                            >
                                <S14Text
                                    style={[
                                        styles.bestBingoScoreEachLetterTextStyle,
                                        index === bestBingoScore.length - 1 &&
                                            styles.additionalStyleForBestBingoScoreEachLetterText,
                                    ]}
                                >
                                    {item}
                                </S14Text>
                            </View>
                        )}
                    />
                </View>
            </>
        );
    };

    renderProgressCircle = (progressAmount) => (
        <LazyProgressCircle
            style={styles.progressCircleStyle}
            progress={progressAmount / 100}
            strokeWidth={4}
            progressColor={'#ff0000'}
            backgroundColor={'rgba(192, 192, 192, 0.7)'}
            fallback={this.getLoadingText()}
        />
    );

    getLoadingText = () => (
        <View style={styles.loadingTextContainer}>
            <S14Text style={styles.loadingText}>Loading...</S14Text>
        </View>
    );

    renderPiGraphs = (stats) => {
        let twoLwPercentage =
            get(stats, 'data.0.move_stats') && Number(get(stats, 'data.0.move_stats.total_moves') || '0') !== 0
                ? Number(
                      (Number(get(stats, 'data.0.stats_ext1.wds2Lpld') || '0') /
                          Number(get(stats, 'data.0.move_stats.total_moves'))) *
                          100
                  ).toFixed(2)
                : 0;
        let threeLwPercentage =
            get(stats, 'data.0.move_stats') && Number(get(stats, 'data.0.move_stats.total_moves') || '0') !== 0
                ? Number(
                      (Number(get(stats, 'data.0.stats_ext1.wds3Lpld') || '0') /
                          Number(get(stats, 'data.0.move_stats.total_moves'))) *
                          100
                  ).toFixed(2)
                : 0;
        let jqxzPercentage =
            get(stats, 'data.0.move_stats') && Number(get(stats, 'data.0.move_stats.total_moves') || '0') !== 0
                ? Number(
                      (Number(get(stats, 'data.0.stats_ext1.jqxz') || '0') /
                          Number(get(stats, 'data.0.move_stats.total_moves'))) *
                          100
                  ).toFixed(2)
                : 0;
        let uniqueWordPercentage =
            get(stats, 'data.0.move_stats') && Number(get(stats, 'data.0.move_stats.total_moves') || '0') !== 0
                ? Number(
                      (Number(get(this.props, 'gamelist.hostedGame.uniqueWordCount.cnt') || '0') /
                          Number(get(stats, 'data.0.move_stats.total_moves'))) *
                          100
                  ).toFixed(2)
                : 0;
        return (
            <View style={[styles.gameSettingsView, styles.piGraphsViewAdditionalStyle]}>
                <View style={[styles.eachGameSettingStyleView, this.getWidth('24%'), styles.marginHorizontalZero]}>
                    {this.renderProgressCircle(twoLwPercentage)}
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphAmountTextStyle]}>
                        {String(twoLwPercentage) + '%'}
                    </S8Text>
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphBottomTextStyle]}>2LW Played</S8Text>
                </View>
                <View style={[styles.eachGameSettingStyleView, this.getWidth('24%'), styles.marginHorizontalZero]}>
                    {this.renderProgressCircle(threeLwPercentage)}
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphAmountTextStyle]}>
                        {String(threeLwPercentage) + '%'}
                    </S8Text>
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphBottomTextStyle]}>3LW Played</S8Text>
                </View>
                <View style={[styles.eachGameSettingStyleView, this.getWidth('24%'), styles.marginHorizontalZero]}>
                    {this.renderProgressCircle(uniqueWordPercentage)}
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphAmountTextStyle]}>
                        {String(uniqueWordPercentage) + '%'}
                    </S8Text>
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphBottomTextStyle]}>Unique Words</S8Text>
                </View>
                <View style={[styles.eachGameSettingStyleView, this.getWidth('24%'), styles.marginHorizontalZero]}>
                    {this.renderProgressCircle(jqxzPercentage)}
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphAmountTextStyle]}>
                        {String(jqxzPercentage) + '%'}
                    </S8Text>
                    <S8Text style={[styles.gameSettingsTextStyle, styles.piGraphBottomTextStyle]}>JQXZ Words</S8Text>
                </View>
            </View>
        );
    };

    getLexId = (guid, startIndex) => {
        let smallLex = '';
        for (let i = startIndex; i < startIndex + 4; i++) {
            smallLex += guid.charAt(i);
        }
        return smallLex;
    };

    onValueSelected = (type) => {
        let hostedGame = this.props.gamelist.hostedGame;
        switch (type) {
            case 'togglecensor':
                this.toggleBlockConfirmation(hostedGame);
                break;
            case 'togglefriend':
                this.toggleFriendshipConfirmation(hostedGame);
                break;
            case 'sendgift':
                openUserGiftsPage(hostedGame.playerItem);
                break;
            default:
                throw new Error('Invalid option');
        }
    };

    toggleBlockConfirmation = (hostedGame) => {
        createDialogInstance({
            title: hostedGame.playerItem && this.isBlockedByMe(hostedGame.playerItem) ? 'Uncensor Player' : 'Censor Player',
            actionButtonText: 'Yes',
            onAction: () => this.toggleBlock(hostedGame.playerItem),
            body:
                'Are you sure you wish to ' +
                (hostedGame.playerItem && this.isBlockedByMe(hostedGame.playerItem) ? 'uncensor' : 'censor') +
                ' ' +
                get(hostedGame, 'playerItem.name') +
                '?',
            cancelButtonText: 'No',
        });
    };

    toggleFriendshipConfirmation = (hostedGame) => {
        createDialogInstance({
            title: hostedGame.playerItem && this.isMyFriend(get(hostedGame, 'playerItem')) ? 'Remove Friend' : 'Add Friend',
            actionButtonText: 'Yes',
            onAction: () => this.toggleFriendship(hostedGame.playerItem),
            body:
                'Are you sure you wish to ' +
                (hostedGame.playerItem && this.isMyFriend(get(hostedGame, 'playerItem')) ? 'remove' : 'add') +
                ' ' +
                get(hostedGame, 'playerItem.name') +
                ' as friend?',
            cancelButtonText: 'No',
        });
    };

    toggleBlock = async (item = this.props.item) => {
        await LiveGamePlayUtils.toggleBlock(item);
        this.setState({ lastRendered: Date.now() });
    };

    toggleFriendship = async (item = this.props.item) => {
        await LiveGamePlayUtils.toggleFriendship(item);
        this.setState({ lastRendered: Date.now() });
    };

    addOrRemoveFriend = () => {
        TooltipActionWrapper.hide();
        this.onValueSelected('togglefriend');
    };

    censorFriend = () => {
        TooltipActionWrapper.hide();
        this.onValueSelected('togglecensor');
    };

    sendGift = () => {
        this.hide();
        TooltipActionWrapper.hide();
        this.onValueSelected('sendgift');
    };

    startPrivateChat = (params) => {
        this.hide();
        TooltipActionWrapper.hide();

        let obj = {
            guid: params.guid,
            username: params.username,
        };
        eventBus.emit(ADD_PVT_MESSAGE_KEY, null, obj);
    };

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    renderBuddyRequestView = (hostedGame) => (
        <View style={styles.itemCenter}>
            <PText>This user has sent you friend request.</PText>
            <View style={[styles.flexDirectionRow, styles.justifyContentCenter, styles.alignItemsCenter, { marginTop: 2 }]}>
                <TouchableOpacity
                    activeOpacity={1}
                    style={[styles.acceptDeleteJoinTouchableStyle, { paddingHorizontal: 6, paddingVertical: 3 }]}
                    onPress={() => buddyRequestAction(false, get(hostedGame, 'playerItem'))}
                >
                    <PText style={styles.touchableTextStyle}>Reject</PText>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={1}
                    style={[
                        styles.acceptDeleteJoinTouchableStyle,
                        { paddingHorizontal: 6, paddingVertical: 3 },
                        styles.btnBgGreen,
                    ]}
                    onPress={() => buddyRequestAction(true, get(hostedGame, 'playerItem'))}
                >
                    <PText style={styles.touchableTextStyle}>Accept</PText>
                </TouchableOpacity>
            </View>
        </View>
    );

    hasBuddyRequest = (player) => (get(this.props, 'user.buddyRequestList') || []).find((buddy) => buddy.guid === player.guid);

    isMyFriend = (player) => {
        let buddyList = get(this.props, 'user.buddyList') || {};
        return !!(
            (buddyList.buddies || []).find((buddy) => buddy.guid === player.guid) ||
            (buddyList.reqsent || []).find((request) => request.guid === player.guid) ||
            (buddyList.online || []).find((onlinePlayer) => onlinePlayer.guid === player.guid)
        );
    };

    isBlockedByMe = (player) => {
        let sensorList = get(this.props, 'user.sensorList') || [];
        return sensorList.some((sensored) => sensored.guid === (get(player, 'guid') || get(player, 'uid')));
    };

    renderTopRowOfPlayerModal = (hostedGame) => {
        let lexId =
            this.getLexId(get(hostedGame, 'playerItem.guid'), 0) +
            '-' +
            this.getLexId(get(hostedGame, 'playerItem.guid'), 4) +
            '-' +
            this.getLexId(get(hostedGame, 'playerItem.guid'), 8);
        return (
            <View style={[styles.flex1, styles.flexDirectionRow]}>
                <View style={styles.stylePlayerModalTopRowView}>
                    <S14Text style={styles.styleModalPlayerName}>
                        {(formatName(get(hostedGame, 'playerItem.name')) || '').trim()}
                    </S14Text>
                    <PText style={styles.styleModalPlayerLexId}>{'Lex ID ' + lexId}</PText>
                </View>
                <View style={styles.stylePlayerModalTopIconsOuterView}>
                    {get(hostedGame, 'playerItem.guid') !== this.props.game.guid ? (
                        this.hasBuddyRequest(get(hostedGame, 'playerItem')) ? (
                            this.renderBuddyRequestView(hostedGame)
                        ) : (
                            <View style={styles.playerModalTopIconsRowView}>
                                {[Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(
                                    get(this.props, 'game.game_type')
                                ) ? (
                                    <TooltipWrapper
                                        activeOpacity={0.7}
                                        onPress={handleStartPrivateChat.bind({
                                            params: {
                                                guid: get(hostedGame, 'playerItem.guid'),
                                                username: (formatName(get(hostedGame, 'playerItem.name')) || '').trim(),
                                            },
                                            bindFunction: this.startPrivateChat,
                                        })}
                                        style={[styles.statsTopIconContainer, styles.mr10]}
                                        tooltip={'Start Chat'}
                                        onMouseEnter={this.showTooltip}
                                        onMouseOut={this.hideTooltip}
                                    >
                                        <FontAwesomeIcon
                                            icon={faComment}
                                            size={20}
                                            style={{
                                                color: '#3484f0',
                                            }}
                                        />
                                    </TooltipWrapper>
                                ) : null}

                                {!this.isBlockedByMe(hostedGame.playerItem) ? (
                                    <TooltipWrapper
                                        tooltip={
                                            this.isMyFriend(get(hostedGame, 'playerItem')) ? 'Remove Friend' : 'Add Friend'
                                        }
                                        activeOpacity={0.7}
                                        style={[styles.statsTopIconContainer, styles.mr10]}
                                        onPress={this.addOrRemoveFriend}
                                        onMouseEnter={this.showTooltip}
                                        onMouseOut={this.hideTooltip}
                                    >
                                        <FontAwesomeIcon
                                            icon={this.isMyFriend(get(hostedGame, 'playerItem')) ? faUsersSlash : faUserFriends}
                                            size={18}
                                            style={{
                                                color: '#3484f0',
                                            }}
                                        />
                                    </TooltipWrapper>
                                ) : null}
                                <TooltipWrapper
                                    tooltip={
                                        this.isBlockedByMe(get(hostedGame, 'playerItem')) ? 'Uncensor Player' : 'Censor Player'
                                    }
                                    activeOpacity={0.7}
                                    style={[styles.statsTopIconContainer, styles.mr10]}
                                    onPress={this.censorFriend}
                                    onMouseEnter={this.showTooltip}
                                    onMouseOut={this.hideTooltip}
                                >
                                    <FontAwesomeIcon
                                        icon={this.isBlockedByMe(get(hostedGame, 'playerItem')) ? faThumbsUp : faBan}
                                        size={18}
                                        style={{
                                            color: '#3484f0',
                                        }}
                                    />
                                </TooltipWrapper>
                                <TooltipWrapper
                                    tooltip={'Send Gift'}
                                    activeOpacity={0.7}
                                    style={[styles.statsTopIconContainer]}
                                    onMouseEnter={this.showTooltip}
                                    onMouseOut={this.hideTooltip}
                                    onPress={this.sendGift}
                                >
                                    <FontAwesomeIcon
                                        icon={faGift}
                                        size={20}
                                        style={{
                                            color: '#3484f0',
                                        }}
                                    />
                                </TooltipWrapper>
                            </View>
                        )
                    ) : null}
                </View>
            </View>
        );
    };

    renderJoinGameModal = (joinedPlayers) => {
        return (
            <>
                {this.props.gamelist.hostedGame && this.getGameSettings().playerNotes !== '' && (
                    <View style={[styles.styleEachStatBox, styles.padding0]}>{this.renderPlayersNotes()}</View>
                )}

                {this.renderLast15GamesHistory()}

                {joinedPlayers &&
                    joinedPlayers.length == 0 &&
                    ((LiveGamePlayUtils.isRated() &&
                        (!get(this.props, 'gamelist.hostedGame.playerModal') ||
                            (get(this.props, 'gamelist.hostedGame.reqJoinHostGame') &&
                                !LiveGamePlayUtils.isMultiplayerAcceptDialog()))) ||
                        get(this.props, 'gamelist.hostedGame.playerModal')) && (
                        <View style={[styles.styleEachStatBox, styles.headToHeadExtraStyle]}>
                            {this.renderHeadToHeadAndRatingChange()}
                        </View>
                    )}
                {!get(this.props, 'gamelist.hostedGame.playerModal') && (
                    <View style={[styles.styleEachStatBox, styles.gameSettingsExtraStyle]}>{this.renderGameSettings()}</View>
                )}
                <View
                    style={[
                        styles.styleEachStatBox,
                        styles.marginBottom0,
                        get(this.props, 'gamelist.hostedGame.playerModal') && styles.marginTop0,
                    ]}
                >
                    {LiveGamePlayUtils.isMultiplayerAcceptDialog()
                        ? this.renderMultiPlayerGameView(joinedPlayers, this.isFourPlayerAcceptDialog())
                        : this.renderTwoPlayerGameView(get(this.props, 'gamelist.hostedGame'))}
                </View>
            </>
        );
    };

    renderPlayerModal = () => {
        return (
            <>
                {this.state.stats &&
                    get(this.props, 'gamelist.hostedGame.stats') &&
                    get(this.props, 'gamelist.hostedGame.stats.data.0.stats_ext1') &&
                    get(this.props, 'gamelist.hostedGame.stats.data.0.stats_ext1.bestbingoever') && (
                        <View style={[styles.styleEachStatBox, styles.bingoScoresViewExtraStyle]}>
                            {this.renderBingoScoreView(get(this.props, 'gamelist.hostedGame.stats'))}
                        </View>
                    )}
                {this.state.stats && get(this.props, 'gamelist.hostedGame.stats') && (
                    <View
                        style={[
                            styles.styleEachStatBox,
                            get(this.props, 'gamelist.hostedGame.stats.data.0.stats_ext1.bestbingoever') &&
                                styles.piGraphsViewExtraStyle,
                        ]}
                    >
                        {this.renderPiGraphs(get(this.props, 'gamelist.hostedGame.stats'))}
                    </View>
                )}
                {this.state.stats && get(this.props, 'gamelist.hostedGame.stats') && (
                    <View style={[styles.styleEachStatBox, styles.scoresViewExtraStyle]}>
                        {this.renderScores(get(this.props, 'gamelist.hostedGame.stats'))}
                    </View>
                )}
                {this.state.stats && get(this.props, 'gamelist.hostedGame.stats') && (
                    <View
                        style={[
                            styles.styleEachStatBox,
                            get(this.props, 'gamelist.hostedGame.playerModal') && styles.statsViewExtraStyle,
                        ]}
                    >
                        {this.renderStats(get(this.props, 'gamelist.hostedGame.stats'))}
                    </View>
                )}
                <View style={styles.headerButtonRowView}>
                    {get(this.props, 'gamelist.hostedGame.playerItem.guid') !== this.props.game.guid &&
                        !get(this.props, 'gamelist.hostedGame.noMatchChecking') && (
                            <TouchableOpacity
                                activeOpacity={0.7}
                                onPress={() =>
                                    get(this.props, 'gamelist.hostedGame.isPlaying')
                                        ? this.watchGame()
                                        : this.setState({
                                              matchChecking: true,
                                              stats: false,
                                          })
                                }
                                style={[styles.playerModalTouchableStyle, !this.state.matchChecking && styles.whiteBackground]}
                            >
                                <PText style={[!this.state.matchChecking && this.getColor(ColorConfig.LIGHT_BLACK_TEXT)]}>
                                    {(get(this.props, 'gamelist.hostedGame.watchGame') ||
                                    get(this.props, 'gamelist.hostedGame.isPlaying')
                                        ? 'Watch '
                                        : 'Match ') +
                                        (formatName(get(this.props, 'gamelist.hostedGame.playerItem.name')) || '').trim()}
                                </PText>
                            </TouchableOpacity>
                        )}
                    <TouchableOpacity
                        activeOpacity={0.7}
                        onPress={() =>
                            this.setState({
                                stats: true,
                                matchChecking: false,
                            })
                        }
                        style={[styles.playerModalTouchableStyle, !this.state.stats && styles.whiteBackground]}
                    >
                        <PText style={[!this.state.stats && this.getColor(ColorConfig.LIGHT_BLACK_TEXT)]}>Stats</PText>
                    </TouchableOpacity>
                    <TouchableOpacity
                        activeOpacity={0.7}
                        onPress={this.openStatsPage}
                        style={[styles.playerModalTouchableStyle, styles.whiteBackground]}
                    >
                        <PText style={[!this.state.stats && this.getColor(ColorConfig.LIGHT_BLACK_TEXT)]}>Games</PText>
                    </TouchableOpacity>
                </View>
            </>
        );
    };

    openStatsPage = () => openUserStatsPage(get(this.props, 'gamelist.hostedGame.playerItem'));

    watchGame = () =>
        this.setState({ isOpen: false }, () =>
            !get(this.props, 'gamelist.hostedGame.observe')
                ? this.observeGameFromLobby(get(this.props, 'gamelist.hostedGame.playerItem'))
                : this.props.gamelist.hostedGame.onObserveGame()
        );

    observeGameFromLobby = async (player) => {
        let game = {};
        if (this.props.gamelist.observableGamesList && this.props.gamelist.observableGamesList.length > 0) {
            this.props.gamelist.observableGamesList.some((element) => {
                element.players.some((item) => {
                    if (item.uid == player.guid) {
                        game = { gid: element.gid, dic: element.dic };
                    }
                });
            });
        }
        Object.keys(game).length > 0 && this.props.gamelist.hostedGame.onObserveGame(game);
    };

    renderConfirmOrLoader = () => {
        if (this.state.setLoader) {
            return (
                <View style={styles.btnLoaderPadding}>
                    <FontAwesomeSpin size={15} color={ColorConfig.WHITE} />
                </View>
            );
        } else {
            return 'Confirm';
        }
    };

    renderBody = () => {
        let joinedPlayers = this.getOpponentObject().jndplys;
        return (
            <View
                style={[
                    LayoutUtils.getDialogMainContainerStyle(),
                    this.state.isOpen ? this.getModalContainerDimension() : this.getBodyWidth(),
                ]}
            >
                <View style={[styles.flexDirectionRow]}>
                    {this.renderInvitationHeader()}
                    <View style={styles.closeButtonContainer}>
                        <TouchableOpacity
                            activeOpacity={0.7}
                            style={[styles.closeButtonBG, this.getCloseButtonAdditionalStyle()]}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <FontAwesomeIcon
                                icon={faTimes}
                                size={DimensionUtils.isMobile() ? 20 : 24}
                                style={this.getCloseButtonStyle()}
                            />
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.directionColumnReverse}>
                    {(!get(this.props, 'gamelist.hostedGame.playerModal') ||
                        (!this.state.stats && get(this.props, 'gamelist.hostedGame.playerModal'))) &&
                        this.renderJoinGameModal(joinedPlayers)}
                    {get(this.props, 'gamelist.hostedGame.playerModal') && this.renderPlayerModal()}
                </View>

                {this.state.stats && get(this.props, 'gamelist.hostedGame.playerModal') ? (
                    <View style={styles.height25} />
                ) : (
                    <View style={[LayoutUtils.getDialogBodyBtnContainerStyle()]}>
                        {this.selfHasJoinedMultiplayerGame() ? (
                            <View key={this.state.buttonsKey} style={[styles.bodyBtnContainer]}>
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    style={[styles.acceptDeleteJoinTouchableStyle, styles.marginRight0]}
                                    onPress={this.onLeave}
                                >
                                    <PText style={styles.touchableTextStyle}>{'Leave'}</PText>
                                </TouchableOpacity>
                            </View>
                        ) : (
                            <View key={this.state.buttonsKey} style={[styles.bodyBtnContainer]}>
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    style={[
                                        styles.acceptDeleteJoinTouchableStyle,
                                        this.getGameSettings().isHostedByMe && styles.marginRight0,
                                        this.getAcceptRejectButtonBgColor(),
                                    ]}
                                    onPress={
                                        get(this.props, 'gamelist.hostedGame.reqJoinHostGame')
                                            ? this.onJoinHostReqAccept
                                            : get(this.props, 'gamelist.hostedGame.watchGame') ||
                                              get(this.props, 'gamelist.hostedGame.isPlaying')
                                            ? this.watchGame
                                            : this.props.emailHostGameJoin
                                            ? this.emailHostGameJoin
                                            : this.debounceOnRequestToJoin
                                    }
                                >
                                    <PText style={styles.touchableTextStyle}>
                                        {this.props.gamelist.hostedGame &&
                                        this.props.gamelist.hostedGame.numplys &&
                                        Number(this.props.gamelist.hostedGame.numplys) > 2
                                            ? this.props.gamelist.hostedGame.selfHost
                                                ? 'Delete'
                                                : get(this.props, 'gamelist.hostedGame.watchGame') ||
                                                  get(this.props, 'gamelist.hostedGame.isPlaying')
                                                ? 'Watch'
                                                : get(this.props, 'gamelist.hostedGame.reqJoinHostGame')
                                                ? this.renderJoinHostGameTimerBtn()
                                                : LiveGamePlayUtils.isHostGameRandom() || this.props.emailHostGameJoin
                                                ? 'Confirm'
                                                : 'Request To Join'
                                            : get(this.props, 'gamelist.hostedGame.watchGame') ||
                                              get(this.props, 'gamelist.hostedGame.isPlaying')
                                            ? 'Watch'
                                            : get(this.props, 'gamelist.hostedGame.playerModal')
                                            ? 'Next'
                                            : this.isInvitation() || get(this.props, 'gamelist.hostedGame.reqJoinHostGame')
                                            ? this.renderJoinHostGameTimerBtn()
                                            : LiveGamePlayUtils.isHostGameRandom() || this.props.emailHostGameJoin
                                            ? this.renderConfirmOrLoader()
                                            : 'Request To Join'}
                                    </PText>
                                </TouchableOpacity>
                                {this.props.gamelist.hostedGame && this.props.gamelist.hostedGame.selfHost ? null : (
                                    <TouchableOpacity
                                        activeOpacity={0.7}
                                        style={[
                                            styles.acceptDeleteJoinTouchableStyle,
                                            styles.additionalStyleForCancelTouchable,
                                        ]}
                                        onPress={this.onCancel}
                                    >
                                        <PText>{get(this.props, 'gamelist.hostedGame.sender') ? 'Decline' : 'Cancel'}</PText>
                                    </TouchableOpacity>
                                )}
                            </View>
                        )}
                    </View>
                )}

                {this.state.showOverlay ? (
                    <View style={[StyleSheet.absoluteFill, styles.overlayContainer]}>
                        {this.state.failureDetail !== null ? (
                            [
                                <View style={styles.failureDetailLayout}>
                                    <S14Text style={LayoutUtils.getCursorDefaultStyle()}>
                                        {this.state.failureDetail.message}
                                    </S14Text>
                                </View>,
                                this.state.failureDetail.btnText ? (
                                    <View style={[styles.flexDirectionRow, styles.btnContainer]}>
                                        <TouchableOpacity
                                            activeOpacity={1}
                                            style={styles.btn}
                                            onPress={this.onFailureDetailClose}
                                        >
                                            <S14Text style={[styles.touchableTextStyle]}>
                                                {this.state.failureDetail.btnText}
                                            </S14Text>
                                        </TouchableOpacity>
                                    </View>
                                ) : null,
                            ]
                        ) : (
                            <FontAwesomeSpin />
                        )}
                    </View>
                ) : null}
            </View>
        );
    };

    emailHostGameJoin = () => {
        let isMultigame = Number(this.props.gamelist.hostedGame.numplys) > 2;
        this.props.emailHostGameJoin(isMultigame ? 'multijoin' : 'hostjoin', {
            jndply: this.getSelfObject(),
        });
        this.onClose();
    };

    onFailureDetailClose = () => {
        this.props.gamelist.hostedGameArr.length > 0
            ? this.setState({
                  showOverlay: false,
                  failureDetail: null,
              })
            : this.onClose();
    };

    renderJoinHostGameTimerBtn = (
        accept = get(this.props, 'gamelist.hostedGame.sender'),
        timerValue = get(this.props, 'gamelist.hostedGame.wait'),
        onTimerFinish = this.onClose
    ) => {
        let startTime = get(this.props, 'gamelist.hostedGame.startTime');
        if (startTime && !LiveGamePlayUtils.isMultiplayerAcceptDialog()) {
            let timerDiff = (Date.now() - startTime) / 1000;
            timerValue = timerValue - timerDiff;
            if (timerValue <= 0) {
                eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT, null, {
                    timerFinish: true,
                });
                onTimerFinish();
            } else if (this['btnTimer']) {
                this['btnTimer'].setTime(timerValue * 1000);
            }
        }
        return (
            <View style={styles.flexDirectionRow}>
                <PText style={styles.touchableTextStyle}>{accept ? 'Accept ' : 'Waiting '}</PText>
                <PText style={styles.touchableTextStyle}>{'('}</PText>
                <Timer
                    initialTime={timerValue * 1000}
                    startImmediately={true}
                    direction={'backward'}
                    checkpoints={[
                        {
                            time: 0,
                            callback: () => {
                                if (startTime && !LiveGamePlayUtils.isMultiplayerAcceptDialog()) {
                                    eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT, null, { timerFinish: true });
                                }
                                onTimerFinish();
                            },
                        },
                    ]}
                >
                    {({ setTime }) => {
                        this['btnTimer'] = { setTime };
                        return (
                            <View style={[styles.flexDirectionRow, styles.touchableTextStyle, { alignItems: 'center' }]}>
                                <PText style={styles.touchableTextStyle}>
                                    <Timer.Minutes formatValue={formatToTwoDigits} />
                                    <PText style={styles.touchableTextStyle}>{':'}</PText>
                                    <Timer.Seconds formatValue={formatToTwoDigits} />
                                </PText>
                            </View>
                        );
                    }}
                </Timer>
                <PText style={styles.touchableTextStyle}>{')'}</PText>
            </View>
        );
    };

    renderInvitationHeader = () =>
        get(this.props, 'gamelist.hostedGame.playerModal') ? (
            this.renderTopRowOfPlayerModal(get(this.props, 'gamelist.hostedGame'))
        ) : get(this.props, 'gamelist.hostedGame.sender') ? (
            <View style={[styles.invitationHeaderViewStyle, styles.borderRadiusFive]}>
                {this.isInvitation() ||
                (get(this.props, 'gamelist.hostedGame.reqJoinHostGame') &&
                    get(this.props, 'gamelist.hostedGame.sender') &&
                    !LiveGamePlayUtils.isMultiplayerAcceptDialog()) ? (
                    <S14Text style={styles.invitationTextStyle}>{'Incoming Request'}</S14Text>
                ) : null}
            </View>
        ) : (
            <View style={styles.flex1} />
        );

    getInitialTime = () => {
        return Number(get(this.props, 'gamelist.hostedGame.wait')) * 1000;
    };

    acceptTimeUp = () => {
        this.onClose();
    };

    hide = () => {
        let wasOpen = this.state.isOpen;
        this.setState({ isOpen: false });
        return wasOpen;
    };

    getSelfObject = () => {
        let isNativeOrRnWeb =
            DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb');
        let gameStats = isNativeOrRnWeb ? get(this.props.myStats, 'game_stats') : get(this.props.user.user_stats, 'game_stats');
        let played = get(gameStats, 'played') || '0';
        let gcr =
            played > 0 ? String((((played - Number(get(gameStats, 'deleted') || '0')) / played) * 100).toFixed(2)) + '%' : 'NA';
        let res = {
            name: isNativeOrRnWeb ? this.props.myName : get(this.props.user.user_info, 'name'),
            guid: this.props.game.guid,
            rating:
                (isNativeOrRnWeb
                    ? get(this.props.myStats, 'rating_stats.rating')
                    : get(this.props.user.user_stats, 'rating_stats.rating')) || '0',
            played,
            win: get(gameStats, 'won') || '0',
            loss: get(gameStats, 'lost') || '0',
            draw: get(gameStats, 'drawn') || '0',
            bingos: get(gameStats, 'bingo_count') || '0',
            avtar: isNativeOrRnWeb ? this.props.myAvtar : get(this.props.user.user_info, 'avtar'),
            gcr,
        };

        return res;
    };

    getWinRatingChange = () => this.formatRatingChange(get(this.state, 'drParts.0'));

    getLossRatingChange = () => this.formatRatingChange(get(this.state, 'drParts.1'));

    getDrawRatingChange = () => this.formatRatingChange(get(this.state, 'drParts.2'));

    formatRatingChange = (value) => (value && value.startsWith && !value.startsWith('-') ? '+' + value : value);

    debounceOnRequestToJoin = debounce(() => {
        this.setState({ setLoader: true });
        this.onRequestToJoin();
    }, 500);
    onRequestToJoin = async () => {
        if (get(this.props, 'gamelist.hostedGame.stats')) {
            this.setState({ isOpen: false }, () =>
                eventBus.emit(Config.SHOW_HOST_INVITE_DIALOG, null, {
                    guid: this.props.gamelist.hostedGame.playerItem.guid,
                    isUnrated: true,
                })
            );
        } else {
            if (LiveGamePlayUtils.isInviting()) {
                let guid_text = get(this.props, 'gamelist.hostedGame.uid.guid');
                let opts = { isForHosting: false, guid_text };
                eventBus.emit(Config.SHOW_HOST_INVITE_DIALOG, null, opts);
                this.onClose();
            } else {
                if (this.isInvitation()) {
                    this.setState({ showOverlay: true });
                    await acceptRejectGamePlayRequest(this.props.gamelist.hostedGame, true);
                    this.onClose();
                } else if (this.props.gamelist.hostedGame.selfHost) {
                    this.setState({ showOverlay: true });
                    await deleteHostedGame();
                    this.setState({ showOverlay: false });
                    this.onClose();
                } else {
                    let res = await to(sendJoinGameRequest(this.props.gamelist.hostedGame));
                    if (
                        get(res, '1.extcode') === '1164' &&
                        Number(this.props.gamelist.hostedGame.numplys) >
                            (this.props.gamelist.hostedGame.jndplys || []).length + 2
                    ) {
                        eventBus.emit(GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME, null, {
                            jndply: this.getSelfObject(),
                        });
                        this.setState({
                            showOverlay: false,
                            buttonsKey: Date.now(),
                        });
                    }

                    this.setState({
                        showOverlay: false,
                        buttonsKey: Date.now(),
                    });
                }
            }
        }
    };
}

const styles = StyleSheet.create({
    itemCenter: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    userStatsContainer: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
    },
    playedGamesStatsContainer: {
        flex: 2,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
    },
    spaceBetweenRowStyle: { justifyContent: 'space-between' },
    drawContainer: {
        flex: 1,
        flexDirection: 'column-reverse',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    drawContainerData: {
        justifyContent: 'center',
    },
    userNameContainer: {
        flex: 1,
        flexDirection: 'column-reverse',
        position: 'absolute',
    },

    headToHeadTitle: {
        flex: 2,
    },
    titleText: {
        fontWeight: 'bold',
    },
    timerControlTitle: {
        marginBottom: 4,
        height: 15,
        flex: 1,
        textAlign: 'left',
    },
    timerControlData: {
        marginBottom: 0,
        flex: 2,
        height: 15,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
    },

    bodyBtnContainer: {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
    },

    dividerViewHorizontal: {
        width: Config.DIALOG_GENERAL_MARGIN,
        height: 0,
        backgroundColor: ColorConfig.TRANSPARENT,
    },

    dividerViewVertical: {
        width: 0,
        height: Config.DIALOG_GENERAL_MARGIN,
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    mainContainer: {
        backgroundColor: ColorConfig.MAIN_CONTAINER_BACKGROUND_COLOR,
    },
    rowContainer: {
        width: '100%',
        margin: 5,
        height: 50,
    },
    timeControlRowContainer: {
        width: '100%',
        flex: 1,
    },
    imageUserNameContainer: {
        position: 'absolute',
        backgroundColor: 'rgba(0,0,0,0.60)',
        alignItems: 'center',
        width: '100%',
    },
    userName: {
        color: '#FFF',
    },
    imageContainer: {
        flex: 1,
        overflow: 'hidden',
        flexDirection: 'column-reverse',
        marginRight: 15,
    },
    flex1: {
        flex: 1,
    },
    timerText: {
        color: '#dc3545',
        textAlign: 'center',
        flex: 2,
    },
    timer: {
        flexDirection: 'row',
        margin: 5,
    },
    timerContainter: {
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    textCenter: {
        textAlign: 'center',
    },
    invitationHeaderViewStyle: {
        marginTop: 8,
        marginLeft: 8,
        backgroundColor: 'rgb(177, 46, 56)',
        paddingLeft: 8,
        paddingVertical: 4,
        justifyContent: 'center',
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flex: 9,
    },
    closeButtonBG: {
        borderRadius: 45,
        alignItems: 'center',
        justifyContent: 'center',
        width: 30,
        height: 30,
        marginTop: 16,
        marginRight: 16,
    },
    closeButtonContainer: {
        alignItems: 'flex-end',
    },
    statsTopIconContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    mr10: {
        marginRight: 32,
    },
    directionColumnReverse: {
        flexDirection: 'column-reverse',
    },
    otherPlayersRow: {
        textAlign: 'center',
        flex: 1,
        width: '100%',
        paddingVertical: 13,
        margin: 5,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        zIndex: 0,
    },
    invitationTextStyle: {
        color: '#fff',
    },
    marginTopMinus2: { marginTop: -2 },
    overlayContainer: {
        height: '100%',
        width: '100%',
        borderRadius: 4,
        backgroundColor: '#FFF',
        justifyContent: 'center',
        alignItems: 'center',
    },
    failureDetailLayout: {
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        position: 'absolute',
    },
    btnContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 32,
        paddingBottom: 32,
    },
    btn: {
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 3,
        backgroundColor: 'rgb(177, 46, 56)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    styleEachStatBox: {
        padding: 10,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRadius: 5,
        marginHorizontal: 10,
        marginVertical: 5,
    },
    playerNameRowStyle: {
        flex: 1,
        flexDirection: 'row',
        paddingVertical: 7,
    },
    playerEachNameRowStyle: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        width: '50%',
    },
    leftPlayerNameView: {
        backgroundColor: 'rgb(52, 132, 240)',
        paddingHorizontal: 10,
        paddingVertical: 3,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: 'rgb(52, 132, 240)',
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
        flex: 1,
        marginLeft: 5,
        overflow: 'hidden',
    },
    rightPlayerNameView: {
        backgroundColor: 'rgb(0, 128, 0)',
        paddingHorizontal: 10,
        paddingVertical: 3,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: 'rgb(0, 128, 0)',
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5,
        flex: 1,
        marginRight: 5,
        overflow: 'hidden',
    },
    gamesPlayedRowView: {
        flex: 1,
        marginHorizontal: 30,
        marginVertical: 2,
        flexDirection: 'row',
    },
    gamesPlayedEachRowView: {
        flex: 1,
        flexDirection: 'row',
        height: 10,
    },
    yellowView: {
        flex: 3,
        backgroundColor: '#ffba1c',
        borderColor: '#ffba1c',
        height: 8,
    },
    blueView: {
        flex: 1,
        backgroundColor: '#005e9a',
        height: 8,
    },
    greyView: {
        flex: 4,
        backgroundColor: '#d0d8dc',
        borderColor: '#d0d8dc',
        justifyContent: 'center',
        height: 8,
    },
    selfGameCountLocation: {
        position: 'absolute',
        right: 2,
        top: 1,
    },
    opponentGameCountLocation: {
        position: 'absolute',
        left: 2,
        top: 1,
    },
    multiPlayerGameCountLoc: { position: 'absolute', right: 8, top: 1 },
    gamesText: { paddingHorizontal: 2 },
    paddingHorizontal0: { paddingHorizontal: 0 },
    bingosText: { color: '#808080', paddingHorizontal: 0 },
    gameSettingsView: {
        flexDirection: 'row',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    gameSettingsStartingView: {
        height: '100%',
        backgroundColor: '#fafafa',
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
        paddingVertical: 15,
        paddingLeft: 12,
        paddingRight: 15,
    },
    eachGameSettingStyleView: {
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 12,
    },
    gameSettingsHeadingTextStyle: {
        color: '#666',
    },
    gameSettingsTextStyle: {
        fontWeight: '600',
        paddingTop: 2,
        color: '#1b1b1b',
        textAlign: 'center',
    },
    playerNotesAdditionalStyle: { color: '#fff', textAlign: 'center' },
    eachHeadToHeadAndRatingChangeViewStyle: {
        flex: 0.99,
        //height: '40%',
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: '#d2d2d2',
        borderRadius: 5,
    },
    headToHeadRatingChangeHeadingTextExtraStyle: {
        padding: 10,
        backgroundColor: '#fafafa',
        textAlign: 'center',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    winLossTextWrapperStyle: {
        marginHorizontal: 10,
        marginTop: 2,
        marginBottom: 8,
    },
    ratingChangeEachItemContainerStyle: {
        flex: 0.33,
        paddingVertical: 5.5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    playerNotesView: {
        flex: 0.2,
        backgroundColor: '#b3b3b3',
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
    },
    playerNotesDescTextStyle: {
        color: '#7c7c7c',
        textAlign: 'center',
        paddingTop: 0,
    },

    acceptDeleteJoinTouchableStyle: {
        backgroundColor: 'rgb(177, 46, 56)',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderWidth: 1,
        borderColor: ColorConfig.TRANSPARENT,
        borderRadius: 3,
        marginRight: 16,
    },
    touchableTextStyle: { color: '#fff' },
    additionalStyleForCancelTouchable: {
        backgroundColor: '#c0c0c0',
        marginRight: 0,
    },
    waitingView: {
        width: '39%',
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRadius: 5,
        paddingHorizontal: 10,
        paddingVertical: 3,
        marginLeft: 28,
    },
    headerButtonRowView: { flexDirection: 'row', paddingHorizontal: 15 },
    playerModalTouchableStyle: {
        marginLeft: 5,
        paddingHorizontal: 10,
        paddingVertical: 5,
        backgroundColor: '#fafafa',
        borderTopWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: '#d2d2d2',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    eachColumnView: { flex: 0.5 },
    eachColumnRowView: { flex: 1, flexDirection: 'row' },
    eachColumnRowLeftView: {
        flex: 0.6,
        backgroundColor: '#fafafa',
        paddingHorizontal: 20,
        paddingVertical: 3,
    },
    eachColumnRowRightView: {
        flex: 0.4,
        backgroundColor: '#fff',
        paddingVertical: 3,
    },
    styleScoresTextStyle: {
        fontWeight: LayoutWrapper.isSafari() ? '900' : '800',
        textAlign: 'right',
        paddingRight: 23,
    },
    styleScoreHeadingStyle: {
        color: '#808080',
        textAlign: 'left',
    },
    headingTitleTextAdditionalStyle: {
        fontWeight: LayoutWrapper.isSafari() ? '900' : '700',
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    bestBingoScoreTextStyle: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    bestBingoScoreView: { paddingTop: 5 },
    bestBingoScoreEachLetterView: {
        height: 24,
        width: 25,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#f7ac28',
        borderRadius: 4,
        backgroundColor: '#f7ac28',
    },
    additionalBingoScoreViewForBingoScoreText: {
        backgroundColor: '#fff',
        borderColor: '#fff',
        marginLeft: 5,
    },
    bestBingoScoreEachLetterTextStyle: { textAlign: 'center' },
    additionalStyleForBestBingoScoreEachLetterText: {
        fontSize: 18,
        color: '#757575',
        textAlign: 'left',
    },
    redOuterCircleView: {
        height: 32,
        width: 32,
        borderRadius: 32 / 2,
        padding: 5,
        borderColor: '#ff0000',
        borderWidth: 1,
        color: ColorConfig.LIGHT_BLACK_TEXT,
        overflow: 'hidden',
        alignItems: 'center',
        justifyContent: 'center',
    },
    blueInnerCircleView: {
        borderColor: '#0000ff',
        backgroundColor: '#fff',
        borderWidth: 1,
        height: 23,
        width: 23,
        borderRadius: 23 / 2,
    },
    styleModalPlayerName: {
        color: '#000',
        paddingBottom: 1,
        fontWeight: '600',
    },
    styleModalPlayerLexId: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    stylePlayerModalTopIconsOuterView: {
        flex: 1,
        paddingTop: 3,
        justifyContent: 'center',
    },
    playerModalTopIconsRowView: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    stylePlayerModalTopRowView: {
        paddingLeft: 16,
        paddingVertical: 16,
    },
    styleStatGames: { color: '#3484f0', paddingTop: 7 },
    styleGameWinLossDrawText: {
        paddingVertical: 1,
        fontWeight: '600',
    },
    styleStatWins: { color: '#ffbf37', paddingTop: 7 },
    styleStatLoss: { color: '#ff0000', paddingTop: 7 },
    styleStatDraw: { color: '#7f7f7f', paddingTop: 7 },
    gamesBingosRowView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    gamesBingosRowReverseView: {
        flex: 1,
        flexDirection: 'row-reverse',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    paddingTopZero: { paddingTop: 0 },
    borderRadiusFive: { borderRadius: 5 },
    colorWhite: { color: '#fff' },
    borderTopBottomLeftRadiusTwo: {
        borderTopLeftRadius: 2,
        borderBottomLeftRadius: 2,
    },
    borderTopBottomRightRadiusTwo: {
        borderTopRightRadius: 2,
        borderBottomRightRadius: 2,
    },
    marginHorizontalZero: { marginHorizontal: 0 },
    marginBottom10: { marginBottom: 10 },
    avtarImageStyle: {
        height: 25,
        width: 25,
    },
    colorWhiteAlignRight: { color: '#fff', textAlign: 'right' },
    flexDirectionRowReverse: { flexDirection: 'row-reverse' },
    paddingBottom3: { paddingBottom: 3 },
    silverBackground: { backgroundColor: '#c0c0c0' },
    justifyContentSpaceBetween: { justifyContent: 'space-between' },
    textAlignRight: { textAlign: 'right' },
    ratingChangeIconsOuterView: {
        justifyContent: 'space-between',
        paddingVertical: 2,
    },
    playerModalStatsAdditionalView: {
        justifyContent: 'space-between',
        paddingHorizontal: 59,
        paddingTop: 2,
    },
    paddingTop16: { paddingTop: 16 },
    paddingBottom14: { paddingBottom: 14 },
    borderTopLeftRadiusPaddingTop: { borderTopLeftRadius: 5, paddingTop: 15 },
    borderBottomLeftRadiusPaddingBottom: {
        paddingBottom: 15,
        borderBottomLeftRadius: 5,
    },
    paddingTop15: { paddingTop: 15 },
    paddingBottom15: { paddingBottom: 15 },
    borderTopRightRadiusPaddingTop: { borderTopRightRadius: 5, paddingTop: 16 },
    borderBottomRightRadiusPaddingBottom: {
        paddingBottom: 14,
        borderBottomRightRadius: 5,
    },
    progressCircleStyle: {
        height: 25,
        width: 25,
    },
    piGraphsViewAdditionalStyle: {
        justifyContent: 'space-between',
        paddingHorizontal: '4%',
        paddingTop: 2,
    },
    piGraphAmountTextStyle: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
        paddingTop: 7,
        fontWeight: '600',
    },
    piGraphBottomTextStyle: {
        fontWeight: '600',
        paddingVertical: 1,
    },
    flexBackground: { flex: 0.12, backgroundColor: ColorConfig.TRANSPARENT },
    padding0: { padding: 0 },
    headToHeadExtraStyle: { marginBottom: 0, padding: 0, borderWidth: 0 },
    gameSettingsExtraStyle: { marginBottom: 0, padding: 0 },
    marginBottom0: { marginBottom: 0 },
    marginTop0: { marginTop: 0 },
    bingoScoresViewExtraStyle: {
        padding: 0,
        borderWidth: 0,
        marginTop: 18,
        marginBottom: 3,
    },
    piGraphsViewExtraStyle: { marginBottom: 0, borderColor: '#d2d2d2' },
    scoresViewExtraStyle: {
        padding: 0,
        marginBottom: 0,
        marginTop: 0,
        borderColor: '#d2d2d2',
    },
    statsViewExtraStyle: { marginTop: 0, borderColor: '#d2d2d2' },
    whiteBackground: { backgroundColor: '#fff' },
    height25: { height: 25 },
    marginRight0: { marginRight: 0 },
    friendIconEmptyViewForCensoredPlayer: {
        flex: 0.12,
        marginHorizontal: 10,
    },
    bingosTextForPlayerModal: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    paddingVertical0: { paddingVertical: 0 },
    historyBorderView: {
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        paddingRight: 3,
    },
    borderBottomWidthOnce: {
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    paddingVertical: { paddingVertical: 4 },
    paddingLeft: { paddingLeft: 10 },
    additionalStyleForEachWinLossResult: {
        paddingHorizontal: 2,
        paddingVertical: 4,
    },
    paddingRight6: { paddingRight: 6 },
    additionalStyleForHeadToHeadProgressBar: {
        paddingHorizontal: 10,
        marginVertical: 6,
    },
    flexDirectionRow: { flexDirection: 'row' },
    paddingTop1: { paddingTop: 1 },
    alignItemsCenter: { alignItems: 'center' },
    justifyContentCenter: { justifyContent: 'center' },
    btnBgGreen: { backgroundColor: 'rgb(0, 130, 34)' },

    loadingTextContainer: {
        height: 25,
        width: 60,
        alignItems: 'center',
        justifyContent: 'center',
    },
    loadingText: {
        opacity: 0.7,
        fontSize: 12,
    },
    btnLoaderPadding: {
        paddingHorizontal: 16,
        paddingVertical: 0,
        display: 'flex',
    },
});

const mapStateToProps = (state) => ({
    config: state.config,
    game: state.game,
    user: state.user,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
    gamelist: state.gamelist,
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(ViewStatsModal);
