import { Dimensions } from 'react-native';

export default class DocumentWrapper {
    /* static setDocumentTitle = getNull;

    static getContainer = getNull;

    static getScreenWidth = getNull;

    static getScreenHeight = getNull;

    static getBodyWidth = getNull;

    static hasContainerElement = getNull;

    static getContainerOffsetWidth = getNull;

    static getContainerWidth = getNull;

    static getContainerHeight = getNull;

    static isPageVisible = getNull;

    static setContainerHeight = getNull; */

    static setDocumentTitle = (title) => null;

    static getContainer = () => null;

    static getContainerWidth = () => Dimensions.get('window').width;

    static getContainerHeight = () => Dimensions.get('window').height;

    static setContainerHeight = (height) => null;

    static getScreenWidth = () => Dimensions.get('window').width;

    static getScreenHeight = () => Dimensions.get('window').height;

    static getBodyWidth = () => Dimensions.get('window').width;

    static hasContainerElement = () => null;

    static getContainerOffsetWidth = () => Dimensions.get('window').width;

    static isPageVisible = () => true;
}
