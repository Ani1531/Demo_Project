import React from 'react';
import DimensionUtils from '../utils/DimensionUtils';
import {
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    Pressable,
    View,
} from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import LayoutUtils from '../utils/LayoutUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { connect } from 'react-redux';
import get from 'lodash/get';
import S22Text from '../component/S22Text';
import S14Text from '../component/S14Text';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

class ScoringDetailsModal extends React.Component {
    state = {
        isOpen: false,
        width: Math.min(
            DimensionUtils.getWindowDimensions().width *
                (DimensionUtils.isMobile ? 0.7 : 1),
            700
        ),
        height: Math.min(
            DimensionUtils.getWindowDimensions().height *
                (DimensionUtils.isMobile ? 0.8 : 0.9),
            450
        ),
        scoringData: undefined,
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
    };

    componentDidMount = () => {
        eventBus.on(Config.SHOW_SCORING_DETAILS_MODAL, this.show);
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.SHOW_SCORING_DETAILS_MODAL, this.show);
    };

    show = (scoringData) => {
        this.setState({ isOpen: true, scoringData });
    };

    onClose = () => this.setState({ isOpen: false, scoringData: undefined });

    getContainerDimension = () => ({
        width: this.state.width,
        height: this.state.height,
    });

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onClose();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: '70%',
        //maxHeight: '90%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    render = () =>
        this.state.isOpen ? (
            <View style={this.getModalContentStyle()}>
                <View
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                    ]}
                >
                    <View style={LayoutUtils.getDialogTitleContainerStyle()}>
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                            {'Score Calculation'}
                        </S22Text>

                        <TouchableOpacity
                            style={[styles.closeButtonContainer]}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <View
                                style={[
                                    {
                                        backgroundColor:
                                            this.state.closeBGColor,
                                    },
                                    LayoutUtils.getDialogCloseButtonBGStyle(),
                                ]}
                            >
                                <FontAwesomeIcon
                                    icon={faTimes}
                                    size={DimensionUtils.isMobile() ? 20 : 24}
                                    style={this.getCloseButtonStyle()}
                                />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={LayoutUtils.getDialogBodyContainerStyle()}>
                        <ScrollView style={styles.listsContainer}>
                            {this.renderPlayerWiseScoreInfo()}
                        </ScrollView>
                    </View>

                    <View style={LayoutUtils.getDialogBodyBtnContainerStyle()}>
                        <Pressable
                            style={[
                                LayoutUtils.getDialogActionButtonStyle(),
                                LayoutUtils.getBottonStyle(),
                            ]}
                            onPress={this.onClose}
                        >
                            <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                {'OK'}
                            </S14Text>
                        </Pressable>
                    </View>
                </View>
            </View>
        ) : null;

    getListDivider = () => ({ width: 0, height: 10 });

    renderPlayerWiseScoreInfo = () =>
        this.state.scoringData.map((player, index) => {
            return (
                <View>
                    {index !== 0 ? (
                        <View style={[this.getListDivider()]} />
                    ) : null}
                    {this.renderInfo(player)}
                </View>
            );
        });

    getOpponentTileValue = (selfPlayer) => {
        let opponentTileValue = 0;
        this.state.scoringData.forEach((player) => {
            if (selfPlayer.pid !== player.pid) {
                opponentTileValue =
                    Number(opponentTileValue) + Number(player.playerTileValue);
            }
        });
        return opponentTileValue;
    };

    renderInfo = (player) => (
        <View style={[styles.columnDirection, styles.widthNinty]}>
            <View style={[styles.rowDirection, styles.widthHundred]}>
                <S14Text
                    style={[
                        styles.boldFont,
                        styles.flexSix,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {player.pid === this.props.game.pid
                        ? 'Your Move Score'
                        : player.playerName + ' Move Score'}
                </S14Text>
                <S14Text
                    style={[
                        styles.boldFont,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {Number(player.playerGrossScore) +
                        Number(player.playerTileValue) -
                        Number(this.getOpponentTileValue(player))}
                </S14Text>
            </View>
            <View style={[styles.rowDirection, styles.widthHundred]}>
                <S14Text
                    style={[
                        styles.fontItalic,
                        styles.flexSix,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {'Less: Tile Value In Hand (' +
                        (player.playerRack || '').split('').join('-') +
                        ')'}
                </S14Text>
                <S14Text
                    style={[
                        styles.fontItalic,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {'-' + player.playerTileValue}
                </S14Text>
            </View>

            {this.renderOpponentTileValueInHand(player)}

            <View style={[styles.rowDirection, styles.widthHundred]}>
                <View style={[styles.flexSix]} />
                <View
                    style={[
                        styles.widthHundred,
                        styles.blackBackround,
                        styles.flexThree,
                        styles.hairlineHeight,
                    ]}
                />
            </View>
            <View style={[styles.rowDirection, styles.widthHundred]}>
                <S14Text
                    style={[
                        styles.boldFont,
                        styles.flexSix,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {'Final Score'}
                </S14Text>
                <S14Text
                    style={[
                        styles.boldFont,
                        LayoutUtils.getDialogBodyTextStyle(),
                    ]}
                >
                    {player.playerGrossScore}
                </S14Text>
            </View>
        </View>
    );

    renderOpponentTileValueInHand = (selfPlayer) =>
        this.state.scoringData.map((player) => {
            if (selfPlayer.pid !== player.pid) {
                return (
                    <View style={[styles.rowDirection, styles.widthHundred]}>
                        <S14Text
                            style={[
                                styles.fontItalic,
                                styles.flexSix,
                                LayoutUtils.getDialogBodyTextStyle(),
                            ]}
                        >
                            {'Add: Opp Tile Value In Hand (' +
                                (player.playerRack || '').split('').join('-') +
                                ')'}
                        </S14Text>
                        <S14Text
                            style={[
                                styles.fontItalic,
                                LayoutUtils.getDialogBodyTextStyle(),
                            ]}
                        >
                            {player.playerTileValue}
                        </S14Text>
                    </View>
                );
            }
            return null;
        });
}
const styles = StyleSheet.create({
    listsContainer: {
        flex: 1,
        flexDirection: 'column',
    },
    alignItemCenter: {
        alignItems: 'center',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    columnDirection: {
        flexDirection: 'column',
    },
    rowDirection: {
        flexDirection: 'row',
    },
    widthNinty: {
        width: '98%',
    },
    widthHundred: {
        width: '100%',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    flexSix: {
        flex: 6,
    },
    fontItalic: {
        fontStyle: 'italic',
    },
    blackBackround: {
        backgroundColor: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },
    flexThree: {
        flex: 3,
    },
    hairlineHeight: {
        height: StyleSheet.hairlineWidth,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    ScoringDetailsModal
);
