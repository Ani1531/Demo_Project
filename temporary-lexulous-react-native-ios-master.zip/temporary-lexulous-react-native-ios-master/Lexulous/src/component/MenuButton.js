import React from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faBars } from '@fortawesome/free-solid-svg-icons';
import ColorConfig from '../configs/ColorConfig';
import DimensionUtils from '../utils/DimensionUtils';
import Config from '../configs/Config';
import rjAnalytics from '../RJAnalytics';

class MenuButton extends React.Component {
    render = () =>
        DimensionUtils.isNative() ? (
            <TouchableOpacity
                key={'menuContainer'}
                onPress={() => {
                    this.props.openMenuHandler();
                    rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_MENU_BUTTON, 'BOARD');
                }}
                style={[
                    styles.commonButtonMobile,
                    {
                        width: '20%',
                        backgroundColor: 'transparent',
                        paddingRight: 8,
                    },
                ]}
            >
                <FontAwesomeIcon
                    id={'menubuttonicon'}
                    key={'menubuttonicon'}
                    icon={faBars}
                    size={this.props.getCellDimenSizeIconStyleObj().fontSize}
                    style={{
                        ...this.props.getCellDimenSizeIconStyleObj(),
                        color: ColorConfig.BUTTON_TEXT_COLOR,
                    }}
                />
            </TouchableOpacity>
        ) : null;
}
const styles = StyleSheet.create({
    commonButtonMobile: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

export default MenuButton;
