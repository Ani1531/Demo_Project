import React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { getChatAttachmentUrl } from '../utils/UrlUtils';
import ColorConfig from '../configs/ColorConfig';

//const eventBus = require('js-event-bus')();

export default class RemoteImage extends React.Component {
    state = {
        width: this.props.maxWidth,
        link: getChatAttachmentUrl(this.props.imageId),
    };

    componentDidMount = () => {
        Image.getSize(this.state.link, this.setWidth);
    };

    setWidth = (width, height) =>
        this.setState({
            width: Math.min(50 * (width / height), this.props.maxWidth),
        });

    getImageDimensions = () => ({ height: 50, width: this.state.width });

    render = () => (
        <View style={styles.container}>
            <Image
                source={{ uri: this.state.link }}
                style={this.getImageDimensions()}
                resizeMode={'contain'}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.CHAT_BOX_TEXT_INPUT_BORDER_COLOR,
        padding: 5,
        backgroundColor: ColorConfig.CHAT_BOX_BACKGROUND_COLOR,
    },
});
