import * as ActionIdentifiers from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import debounce from 'lodash/debounce';
import cloneDeep from 'lodash/cloneDeep';
import Config from '../configs/Config';
import { CELL_REDUCER_CLEAR_DIRECTION } from '../configs/ActionIdentifiers';
import { batch } from 'react-redux';

const eventBus = require('js-event-bus')();

export const celReducerPlaceTile = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.CELL_REDUCER_SET_TILE,
        payload: res,
        globalState: getState(),
    });
    clearDirectionDelay();
};

export const celReducerUpdateCell = (res) => {
    return {
        type: ActionIdentifiers.CELL_REDUCER_UPDATE_CELL,
        payload: res,
    };
};

export const clearDirectionDelay = debounce(() => eventBus.emit(CELL_REDUCER_CLEAR_DIRECTION), 10000);

export const cellReducerSetHasDirection = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.CELL_REDUCER_SET_DIRECTION,
        payload: res,
        globalState: getState(),
    });
    clearDirectionDelay();
};

export const cellReducerResetBoardStructure = (res) => ({
    type: ActionIdentifiers.CELL_REDUCER_UPDATE_BOARD_STRUCTURE,
    payload: res,
});

export const cellReducerHideTile = (res) => ({
    type: ActionIdentifiers.CELL_REDUCER_HIDE_TILE,
    payload: res,
});

export const cellReducerClearDirection = () => ({
    type: ActionIdentifiers.CELL_REDUCER_CLEAR_DIRECTION,
});

export const cellReducerEmptyGameboard = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.CELL_REDUCER_EMPTY_GAMEBOARD,
        payload: res,
        globalState: getState(),
    });

export const cellReducerOnTileClicked = (res) => (dispatch, getState) => {
    let globalState = getState();

    dispatch({
        type: ActionIdentifiers.CELL_REDUCER_ON_TILE_CLICKED,
        payload: res,
        globalState,
    });

    globalState = getState();
    let tile = cloneDeep(get(res, 'tileType'));
    let cells = get(globalState, 'cells.cells').flat(8);

    let cell = cloneDeep(cells.find((cell) => get(cell, 'currentTile.id') === get(tile, 'id')));

    if (tile && cell && tile.isBlankTile && !tile.currentLetter)
        setTimeout(() => eventBus.emit(Config.DISPLAY_LETTER_PICKER, null, { tile, cell }));

    clearDirectionDelay();
};

export const reducerUpdateBlankTileLetter = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.REDUCER_UPDATE_BLANK_TILE_LETTER,
        payload: res,
        globalState: getState(),
    });

export const reducerUpdateMouseMovetile = (res) => ({
    type: ActionIdentifiers.REDUCER_UPDATE_MOUSE_MOVE_TILE,
    payload: res,
});

export const cellReducerReinitCell = (res) => ({
    type: ActionIdentifiers.RE_INIT_CELL,
    payload: res,
});
