import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import {
    deleteHostedGame,
    sendLeaveGameRequest,
} from '../service/GamePlayService';
import ColorConfig from '../configs/ColorConfig';
import get from 'lodash/get';
import Config from '../configs/Config';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import PlayerAvatarNameRating from './PlayerAvatarNameRating';
import StandardButton from './StandardButton';
import { Motion, spring } from 'react-motion';
import Indicator from './Indicator';
import isEqual from 'lodash/isEqual';
import GameBoardUtils from '../utils/GameBoardUtils';
import Timer from 'react-compound-timer/build';
import { formatToTwoDigits } from '../utils/Utils';
import S14Text from './S14Text';
import S12Text from './PText';

export default class AcceptHostedGameRequestListItem extends React.Component {
    state = {
        backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
    };

    shouldComponentUpdate = (nextProps) =>
        !isEqual(get(this.props, 'item'), get(nextProps, 'item')) ||
        !isEqual(get(this.props, 'rowColor'), get(nextProps, 'rowColor'));

    render = () =>
        !this.props.isMyself || LiveGamePlayUtils.isBlitzGame() ? (
            this.renderBasic()
        ) : (
            <Motion defaultStyle={{ y: 100 }} style={{ y: spring(0) }}>
                {({ y }) => (
                    <View style={{ paddingTop: y, opacity: (100 - y) / 100 }}>
                        {this.renderBasic()}
                    </View>
                )}
            </Motion>
        );

    onPress = () => {
        if (!this.props.isBlitzInp) this.props.onJoinGameWith(this.props.item);
    };

    onLeaveOrDelete = () => {
        if (Number(get(this.props.item, 'numplys')) > 2) {
            this.onPress();
        } else if (LiveGamePlayUtils.isBlitzGame()) {
            sendLeaveGameRequest(this.props.item);
        } else {
            deleteHostedGame();
        }
    };

    onHostedGameDeleteButtonHoverIn = () => {
        this.setState({
            prevBG: this.state.backgroundColor,
            backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_HOVER_COLOR,
        });
    };

    onHostedGameDeleteButtonHoverOut = () => {
        this.setState({ backgroundColor: this.state.prevBG });
    };

    onHostedGamePlayButtonHoverIn = () => {
        this.setState({
            prevBG: this.state.backgroundColor,
            backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_HOVER_COLOR,
        });
    };

    onHostedGamePlayButtonHoverOut = () => {
        this.setState({ backgroundColor: this.state.prevBG });
    };

    getDeleteButtonStyle = () => [
        {
            paddingVertical: 4,
            paddingHorizontal: 3,
            borderRadius: 3,
            backgroundColor: LiveGamePlayUtils.isBlitzGame()
                ? ColorConfig.NEW_GAME_BUTTON_COLOR
                : this.state.backgroundColor,
            alignItems: 'center',
            // width: Config.HOST_ACCEPT_OBSERVE_BUTTON_WIDTH
        },
    ];

    getPlayButtonStyle = () => [
        {
            paddingVertical: 4,
            paddingHorizontal: 9,
            borderRadius: 3,
            backgroundColor: this.state.backgroundColor,
            // width: Config.HOST_ACCEPT_OBSERVE_BUTTON_WIDTH,
            alignItems: 'center',
        },
    ];

    getColorStyle = () => ({ backgroundColor: this.props.rowColor });

    renderBlitzGameView = () => (
        <View style={[styles.flexDirectionRow, styles.blitzRowItemContainer]}>
            <S14Text>
                {this.props.isBlitzInp
                    ? 'Game will end in '
                    : 'Next Blitz game starts in '}
            </S14Text>
            <Timer
                initialTime={
                    (this.props.isBlitzInp
                        ? get(this.props.item, 'endtime')
                        : get(this.props.item, 'starttime')) *
                        1000 -
                    Date.now()
                }
                startImmediately={true}
                direction={'backward'}
            >
                <View style={[styles.flexDirectionRow]}>
                    <S14Text>
                        <Timer.Minutes formatValue={formatToTwoDigits} />
                    </S14Text>
                    <S14Text>{':'}</S14Text>
                    <S14Text>
                        <Timer.Seconds formatValue={formatToTwoDigits} />
                    </S14Text>
                </View>
            </Timer>
        </View>
    );

    renderBasic = () => (
        <TouchableOpacity
            key={'basic_' + this.props.key}
            activeOpacity={1}
            onPress={this.onPress}
            disabled={this.props.isMyself}
            style={
                this.props.isNormalUser || this.props.showRobots
                    ? [
                          styles.playerListItem,
                          this.getColorStyle(),
                          LiveGamePlayUtils.isBlitzGame() && {
                              paddingVertical: 4,
                          },
                      ]
                    : {
                          height: 0,
                          overflow: 'hidden',
                      }
            }
        >
            <View style={[styles.playerListAvatar]}>
                {LiveGamePlayUtils.isBlitzGame() ? (
                    this.renderBlitzGameView()
                ) : (
                    <PlayerAvatarNameRating
                        player={this.props.player}
                        getRatingForPlayer={
                            LiveGamePlayUtils.getRatingForPlayer
                        }
                        toggleFriendship={LiveGamePlayUtils.toggleFriendship}
                        toggleBlock={LiveGamePlayUtils.toggleBlock}
                        flexDirection={'row'}
                        joinGameModalOpen={true}
                        onJoinGame={this.onPress}
                        //avatarClick={(event) => event.stopPropagation()}
                        tooltipID={'appTooltip'}
                    />
                )}
            </View>
            <View style={[styles.playerListActionContainer]}>
                {this.props.isBlitzInp ? null : this.props.isMyself ? (
                    <StandardButton
                        style={this.getDeleteButtonStyle()}
                        onPress={this.onLeaveOrDelete}
                        onMouseOver={this.onHostedGameDeleteButtonHoverIn}
                        onMouseOut={this.onHostedGameDeleteButtonHoverOut}
                        text={
                            LiveGamePlayUtils.isBlitzGame() ? 'Leave' : 'Delete'
                        }
                        textStyle={[styles.deleteButtonTextStyle]}
                    />
                ) : (
                    <StandardButton
                        style={this.getPlayButtonStyle()}
                        onPress={this.onPress}
                        onMouseOver={this.onHostedGamePlayButtonHoverIn}
                        onMouseOut={this.onHostedGamePlayButtonHoverOut}
                        text={LiveGamePlayUtils.isBlitzGame() ? 'Join' : 'Play'}
                        textStyle={[styles.playButtonTextStyle]}
                    />
                )}
                {!LiveGamePlayUtils.isBlitzGame() && (
                    <Indicator
                        numberOfPlayers={get(this.props.item, 'numplys')}
                        isRated={get(this.props.item, 'live.rated') === 'y'}
                        dictionary={get(this.props.item, 'dic')}
                        time={get(this.props.item, 'live')}
                        tooltipID={'appTooltip'}
                        isChallengeGame={GameBoardUtils.isChallengeModeStr(
                            get(this.props.item, 'gametype')
                        )}
                    />
                )}
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    playerListItem: {
        backgroundColor: ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.PLAYER_LIST_ITEM_BORDER_COLOR,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 1,
        paddingHorizontal: Config.RIGHT_LEFT_MARGIN,
    },
    textColor: {
        color: 'red',
    },
    generalMarginLeft: {
        marginLeft: 5,
    },
    playerListAvatar: {
        flex: 2,
    },
    playerListActionContainer: {
        flex: 1,
        paddingRight: 10,
        flexDirection: 'row-reverse',
        alignItems: 'center',
    },
    deleteButtonTextStyle: {
        color: '#FFF',
        fontSize: 12,
    },
    playButtonTextStyle: {
        color: '#FFF',
        fontSize: 12,
    },
    flexDirectionRow: { flexDirection: 'row' },
    blitzRowItemContainer: { alignItems: 'center' },
});
