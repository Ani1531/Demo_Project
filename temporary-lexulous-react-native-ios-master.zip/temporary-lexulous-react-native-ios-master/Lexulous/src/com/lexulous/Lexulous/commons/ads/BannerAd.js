// @flow

import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class BannerAd {
    reInit = false;
    onBannerReceive = null;
    onBannerFail = null;
    adAvailable = false;
    adHeight = 50;
    yOffset: number = 0;
    constructor() {}
    onAppInit = (): void => {};

    onAppReInit = (): void => {
        this.reInit = false;
        this.onBannerReceive = null;
        this.onBannerFail = null;
        this.adAvailable = false;
        this.yOffset = 0;
        this.onAppInit();
    };

    onBannerAdReceived = (adInfo: any): void => {
        if (this.adAvailable == false) {
        }
        this.adAvailable = true;
        if (this.onBannerReceive != null) {
            this.onBannerReceive();
        }
    };

    onBannerAdFailed = (errorInfo: any): void => {
        if (this.adAvailable == true) {
        }
        this.adAvailable = false;
        if (this.onBannerFail != null) {
            this.onBannerFail();
        }
    };

    showBannerAd = (yoffset: number, onBannerReceive: () => void, onBannerFail: () => void): void => {
        if (this.reInit) {
            this.onAppReInit();
        }
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            if (onBannerFail != null) {
                onBannerFail();
            }
            return;
        }
        this.onBannerReceive = onBannerReceive;
        this.onBannerFail = onBannerFail;
        this.yOffset = yoffset;
        if (this.adAvailable) {
            if (this.onBannerReceive != null) {
                this.onBannerReceive();
            }
        } else {
            if (this.onBannerFail != null) {
                this.onBannerFail();
            }
        }
    };

    hideBannerAd = (): void => {
        this.onBannerReceive = null;
        this.onBannerFail = null;
    };

    invalidateBanner = (): void => {
        this.reInit = true;
        this.hideBannerAd();
    };

    onUserSettingsUpdate = (): boolean => {
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            if (this.onBannerFail != null) {
                this.onBannerFail();
                this.hideBannerAd();
                return true;
            }
        }
        return false;
    };
}

const bannerAd: BannerAd = new BannerAd();

export default bannerAd;
