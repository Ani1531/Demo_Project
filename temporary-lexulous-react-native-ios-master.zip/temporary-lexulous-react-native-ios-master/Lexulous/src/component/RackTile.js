import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import get from 'lodash/get';
import GameBoardUtils from '../utils/GameBoardUtils';
import ColorConfig from '../configs/ColorConfig';
import SoundUtils from '../utils/SoundUtils';
import { connect } from 'react-redux';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';

class RackTile extends React.Component {
    onRackTilePress = () => {
        if (this.props.clickSound) {
            SoundUtils.playClickTileSound();
        }
        this.props.onPress();
    };

    getTileBasicScoreLetterViewStyles = () =>
        this.props.tile.isBlankTile
            ? styles.tileBasicScoreLetterViewStyleForFlex1
            : GameBoardUtils.getTileBasicScore(this.props.tile) > 9
            ? styles.tileBasicScoreLetterViewStyleForFlex2
            : GameBoardUtils.getTileBasicScore(this.props.tile) > 1
            ? styles.tileBasicScoreLetterViewStyleForFlex4
            : styles.tileBasicScoreLetterViewStyleForFlex6;

    render = () => (
        <TouchableOpacity
            onPress={this.onRackTilePress}
            style={[
                {
                    height: Math.min(
                        this.props.layout.layoutCellDimen,
                        this.props.containerHeight * 0.45
                    ),
                    width: Math.min(
                        this.props.layout.layoutCellDimen,
                        this.props.containerHeight * 0.45
                    ),
                    borderRadius:
                        Math.min(
                            this.props.layout.layoutCellDimen,
                            this.props.containerHeight * 0.45
                        ) / 8,
                },
                styles.placed_cell,
                this.getMarginRightObj(),
                styles.rowDirection,
            ]}
            activeOpacity={1}
        >
            <View style={this.getTileBasicScoreLetterViewStyles()}>
                <S14Text
                    class="smooth_font"
                    style={[
                        this.props.tile.isBlankTile
                            ? styles.blank_tile_text
                            : styles.text,
                        this.getLetterStyles(),
                    ]}
                >
                    {get(this.props.tile, 'letter')}
                </S14Text>
            </View>

            {this.props.tile.isBlankTile || !this.props.showTileScore ? null : (
                <View style={styles.tilesBasicScoreViewStyle}>
                    <S14Text style={[styles.text, this.getScoreStyles()]}>
                        {GameBoardUtils.getTileBasicScore(this.props.tile)}
                    </S14Text>
                </View>
            )}
        </TouchableOpacity>
    );
    getScoreStyles = () => ({
        bottom: this.props.layout.layoutCellDimen / 12,
        right: this.props.layout.layoutCellDimen / 12,
        fontSize: this.props.layout.layoutCellDimen * 0.2833,
    });
    getLetterStyles = () => ({
        fontSize: Math.min(
            this.props.containerHeight * 0.3,
            (this.props.layout.layoutCellDimen * 2) / 3
        ),
    });
    getMarginRightObj = () => ({
        marginRight: Math.min(
            this.props.containerHeight * 0.05,
            this.props.layout.layoutTileRackMargin
        ),
    });

    getFontSizeStyle = () => ({
        fontSize: this.props.layout.layoutButtonStylesrRoundingEdge.fontSize,
    });

    getTileScoreStyles = () => ({
        bottom:
            this.props.layout.layoutCellDimen /
            (DimensionUtils.isMobile() ? 10 : 12),
        right:
            this.props.layout.layoutCellDimen /
            (DimensionUtils.isMobile() ? 10 : 12),
        fontSize: this.props.layout.layoutCellDimen * 0.2833,
    });
}

const styles = StyleSheet.create({
    tileBasicScoreLetterViewStyleForFlex1: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    tileBasicScoreLetterViewStyleForFlex2: {
        flex: 2,
        justifyContent: 'center',
        alignItems: 'center',
    },
    tileBasicScoreLetterViewStyleForFlex4: {
        flex: 4,
        justifyContent: 'center',
        alignItems: 'center',
    },
    tileBasicScoreLetterViewStyleForFlex6: {
        flex: 6,
        justifyContent: 'center',
        alignItems: 'center',
    },
    tilesBasicScoreViewStyle: {
        flex: 1,
        height: '100%',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    positionAbsolute: {
        position: 'absolute',
    },
    rowDirection: {
        flexDirection: 'row',
    },
    margin: {
        margin: 5,
    },
    alignContentCenterJustified: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    placed_cell: {
        backgroundColor: ColorConfig.RACK_TILE_BACKGROUND_COLOR,
        borderColor: ColorConfig.RACK_TILE_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
    },
    locked_text: {
        color: ColorConfig.LOCKED_TEXT_COLOR,
    },
    text: {
        color: ColorConfig.TILE_TEXT_COLOR,
    },
    blank_tile_text: {
        color: '#2e68cb',
        fontWeight: 'bold',
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    config: state.config,
});

export default connect(mapStateToProps)(RackTile);
