import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import { getLastGamesStatusAndRanking } from '../service/GamePlayService';
import Config from '../configs/Config';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import { replaceLocation } from '../utils/UrlUtils';
import StandardButton from './StandardButton';
import { connect } from 'react-redux';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';

require('format-unicorn');
function handleItemOnPress() {
    this.itemOnPress(this.data);
}

class PlayerLastGamesStatusBar extends React.Component {
    constructor(props) {
        super(props);
        this.scoreDifferentialsScrollViewRef = React.createRef();
    }

    onBoardDimensionsSet = (dimensions) => {
        this.setState(dimensions);
    };

    componentDidMount = () => {
        getLastGamesStatusAndRanking();
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(nextProps, this.props) || !isEqual(nextState, this.state);

    getPlayerLastGamesStatusBarHeight = () => {
        return this.props.panelDimension.height;
    };

    getPlayerLastGamesStatusBarWidth = () => {
        return this.props.panelDimension.width;
    };

    getPanelHeadStyles = () => ({
        padding: this.props.layout.layoutSidePanelTitleBarPadding,
    });

    getPanelFontSize = () => ({
        fontSize: this.props.layout.layoutSidePanelFontSize,
    });

    getNoDataBodyStyles = () => ({
        padding: this.props.layout.layoutSidePanelBodyPadding,
        fontSize: this.props.layout.layoutSidePanelFontSize,
    });

    render = () => (
        <View style={[styles.padding, styles.fullWidth]}>
            <View style={styles.container}>
                <S14Text
                    style={[
                        styles.heading,
                        this.getPanelFontSize(),
                        this.getPanelHeadStyles(),
                        styles.fullWidth,
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    Your Recent Results
                </S14Text>
                {this.props.game.differentialsList &&
                this.props.game.differentialsList.length === 0 ? (
                    <S14Text
                        style={[
                            styles.noData,
                            this.getPanelFontSize(),
                            styles.center,
                            this.getNoDataBodyStyles(),
                            LayoutUtils.getCursorDefaultStyle(),
                        ]}
                    >
                        No History
                    </S14Text>
                ) : (
                    this.renderLastGamesStatus()
                )}
            </View>
            <View style={styles.seperationLineStyle} />
        </View>
    );

    scrollToScrollViewEnd = () => {
        this.scoreDifferentialsScrollViewRef.current.scrollToEnd({
            animated: true,
        });
    };

    renderLastGamesStatus = () => (
        <ScrollView
            horizontal={true}
            showsHorizontalScrollIndicator={true}
            ref={this.scoreDifferentialsScrollViewRef}
            onContentSizeChange={this.scrollToScrollViewEnd}
            className="customScrollView"
        >
            <View style={[styles.lastScoresContainer, this.getPanelFontSize()]}>
                {this.props.game.differentialsList &&
                    this.props.game.differentialsList.map((data, index) => (
                        <StandardButton
                            style={[
                                styles.scoreDataContainer,
                                this.getItemLeftBorderStyles(index),
                                this.getItemContainerStyles(),
                            ]}
                            onPress={handleItemOnPress.bind({
                                data: data,
                                itemOnPress: this.itemOnPress,
                            })}
                            text={Math.abs(data.scoreDifferential)}
                            textStyle={[
                                styles.score,
                                this.getPanelFontSize(),
                                this.getItemFontColor(data),
                            ]}
                        />
                    ))}
            </View>
        </ScrollView>
    );

    itemOnPress = (data) => {
        let puzzle_id = get(data, 'puzzleid');
        let formatStr = String(this.props.config.archive_puzzle_location);
        replaceLocation(formatStr.formatUnicorn({ puzzle_id }));
    };

    getItemContainerStyles = () => ({
        width: this.getPlayerLastGamesStatusBarHeight() / 2,
        padding: this.props.layout.layoutSidePanelBodyPadding,
    });

    getItemLeftBorderStyles = (index) => ({
        borderLeftWidth:
            Number(index) === this.props.game.differentialsList.length - 1
                ? 0
                : 1,
    });

    getItemFontColor = (data) => ({
        color: data.scoreDifferential > 0 ? '#5eb42c' : '#c23742',
    });

    componentWillUnmount = () => {};
}

const styles = StyleSheet.create({
    score: {
        fontWeight: 'bold',
    },
    scoreDataContainer: {
        alignItems: 'center',
        borderWidth: 0,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    lastScoresContainer: {
        flexDirection: 'row-reverse',
        fontWeight: 'bold',
    },
    noData: {
        color: ColorConfig.SIDE_PANEL_SECONDARY_TEXT_COLOR,
    },
    center: {
        textAlign: 'center',
    },
    heading: {
        color: ColorConfig.SIDE_PANEL_HEADING_TEXT_COLOR,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    fullWidth: { width: '100%' },
    container: {
        width: '100%',
        backgroundColor: '#f4f3ef',
        flexDirection: 'column',
        overflow: 'hidden',
        flex: 1,
    },
    padding: {
        paddingBottom: Config.SIDE_PANEL_WRAPPER_PADDING,
    },
    seperationLineStyle: {
        borderTopWidth: 1,
        borderTopColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    game: state.game,
    config: state.config,
});

export default connect(mapStateToProps)(PlayerLastGamesStatusBar);
