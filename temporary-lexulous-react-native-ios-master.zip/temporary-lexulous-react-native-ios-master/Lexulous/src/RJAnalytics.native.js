// @flow

import analytics from '@react-native-firebase/analytics';

class RJAnalytics {
    constructor() {}

    sendAnalyticsEvent = async (event: string, category: string) => {
        let params = {
            value: category,
        };
        await analytics().logEvent(event, params);
    };
}

const rjAnalytics: RJAnalytics = new RJAnalytics();

export default rjAnalytics;
