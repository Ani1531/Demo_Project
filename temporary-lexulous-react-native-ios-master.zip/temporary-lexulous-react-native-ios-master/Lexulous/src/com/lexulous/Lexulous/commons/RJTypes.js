// @flow

import * as React from 'react';
import { AccessToken } from 'react-native-fbsdk-next';
// import type { User } from '@react-native-google-signin/google-signin';  //  Comment for react native web
import type { NavigationProp, RouteProp } from '@react-navigation/native';
import type { authRespData } from '../legacy/LegacyCoordinator';
import { SET_BUSY, SET_FREE } from '../commons/Constants';

export type LXWebCfg = {
    channel?: string,
    guid?: string,
    uuid?: string,
};

export type WkStnCfg = {};

export type FBInstantCfg = {
    picurl?: string,
    channel?: string,
    guid?: string,
    uuid?: string,
    plugins?: {
        share?: string,
        invite?: string,
        purchase?: string,
        friends?: string,
        quit?: string,
        pinapp?: string,
        blindGame?: string,
        onBlindGameMove?: string,
        updateContextStore?: string,
        notifyContextStore?: string,
    },
    products?: {
        protill?: string,
        analizetill?: string,
    },
    gameinvitation?: {
        gid: string,
        pid: string,
        dic: string,
        boarddes: string,
        already_attempted: boolean,
        game_type: string,
        board_type: string,
        request_url_type: string,
        board_size: number,
    },
};

export type AppCfg = {
    source?: SourceType,
    fb_instant?: FBInstantCfg,
    lex_web?: LXWebCfg,
    desktop?: WkStnCfg,
};

export type SourceType = 'desktop' | 'fb_instant' | 'lex_web';

export type AppState = {
    profile: ProfileInfo,
    profileVw: ProfileAssociations,
    gamesList: GamesListProps,
    archiveGamesList: AGLContainerPropsType,
    friends: Friends,
    lnrVw: LNRVwProps,
    minStats: { [string]: UserStats },
};
//===============================================

export const actionSetBusy = (): ActionBusy => {
    return {
        type: SET_BUSY,
    };
};

export const actionSetIdle = (): ActionFree => {
    return {
        type: SET_FREE,
    };
};

export type busyIndicator = {
    busyIndicator: Busy,
};

export type Busy = {
    busy: boolean,
};

export type ActionBusy = ActionGeneric;
export type ActionFree = ActionGeneric;

export type BusyAction = ActionBusy | ActionFree;
//===============================================

export type AppUtilsTypes = {
    colorScheme: string,
};

export type ActionAppUtils = ActionUpdateUtils;

export const actionUpdateAppUtils = (type: string, utildata: AppUtilsTypes): ActionUpdateUtils => {
    return {
        type: type,
        payload: utildata,
    };
};

export type ActionUpdateUtils = {
    type: string,
    payload: AppUtilsTypes,
};

//===============================================
export type PsistData = {
    guid?: string,
    uuid?: string,
};

//=====================================================================

export type GenGlobalIDRequest = {|
    channel: string,
    uuid: string,
|};

export type GenGlobalIDResponseData = {
    first_name: string,
    guid: string,
    uuid: string,
    last_name: string,
    message: string,
    pic_id: string,
};

export type RegisterAppleUserRequest = {
    user: string,
    authcode: string,
    token?: string,
    refresh_token?: string,
    email?: string,
    familyName?: string,
    givenName?: string,
    nickname?: string,
    pkg?: string,
};

export type RegisterAppleUserResponse = RegisterAppleUserSuccessResponse | RegisterAppleUserErrorResponse;

export type RegisterAppleUserSuccessResponse = {
    check: 'Success',
    authuser: string,
    authsecret: string,
    uid: string,
    refresh_token: string,
    email: string,
    avtar: string,
    prouser: string,
    sitecode: 'LEXEMAIL',
};

export type RegisterAppleUserErrorResponse = {
    check: 'Failure',
    errorcode: string,
    message: string,
    sitecode: 'LEXEMAIL',
};

export type RegisterGoogleUserResponse = RegisterGoogleUserSuccessResponse | RegisterGoogleUserErrorResponse;

export type RegisterGoogleUserSuccessResponse = {
    check: 'Success',
    authuser: string,
    authsecret: string,
    uid: string,
    email: string,
    avtar: string,
    prouser: string,
    sitecode: 'LEXEMAIL',
};

export type RegisterGoogleUserErrorResponse = {
    check: 'Failure',
    errorcode: string,
    message: string,
    sitecode: 'LEXEMAIL',
};

export type ProfileInfo = {|
    name?: string,
    avtar?: string,
    picurl?: string,
    guid?: string,
    usrtype?: string,
    lexcom?: string,
    uuid?: string,
|};

export type ProfileResponseData = {
    string: ProfileInfo,
};

export type LegacyAuthData = {|
    lexcom?: {
        authuser: string,
        authsecret: string,
    },
    fb?: {
        fb_sig_user: string,
        fb_sig_session_key: string,
    },
    gglid?: {
        google_sig_user: string,
        google_sig_session_key: string,
    },
    piggyback?: string,
|};

export type LegacyAuthResponse = {
    lexcom?: {
        [emuid: string]: authRespData,
    },
    fb?: {
        [fbuid: string]: authRespData,
    },
    gglid?: {
        [ggluid: string]: authRespData,
    },
    piggyback?: string,
};

export type LgnMedium = 'lexcom' | 'fb' | 'gglid';

export type SuccessResponse = {
    data?:
        | GenGlobalIDResponseData
        | ProfileResponseData
        | AssociationResponse
        | GamesListResponse
        | GLBLFriendsAndFoes
        | UserStats
        | UserSettingsResponse
        | LegacyAuthResponse
        | HostedGameResponse,
    extcode: string,
    action: string,
    tstmp: string,
    piggyback?: string,
    check: 'success',
};

export type ErrorResponse = {
    uri: string,
    msg: string,
    extcode: string,
    action: string,
    tstmp: string,
    check: 'failure',
};

export type LexComAuthData = {|
    lexcom?: LexComAuth,
|};

export type LexComAuth = {
    authuser: string,
    authsecret: string,
};

export type FBAuthData = {|
    fb?: FBAuth,
|};

export type FBAuth = {
    fb_sig_user: string,
    fb_sig_session_key: string,
};

export type DoMerge = {
    domerge: string,
};

export type AssociationRequestData = {| ...LexComAuthData, ...RequestData, ...DoMerge |};

export type ServerResponse = SuccessResponse | ErrorResponse;

export type onGenGlobalCompletion = (request: GenGlobalIDRequest, response: ServerResponse) => void;

export type RequestData = {|
    channel: string,
    guid: string,
    uuid: string,
|};

export type AssociationResponseCodes = '10' | '11' | '16' | '17';

export type AssociationResponse = AssociationResponseInfo | AssociationResponseData;

export type AssociationResponseInfo = {
    status: 'failure',
    messageCode: AssociationResponseCodes,
    message: string,
    title?: string,
    continue?: string,
};

export type AssociationResponseData = {
    guid: string,
    uuid: string,
    first_name: string,
    last_name: string,
    pic_id: string,
    message?: string,
};
//======================================================================

export type UserStats = {
    guid: string,
    channel: string,
    game_stats?: UserGameStats,
    move_stats?: UserMoveStats,
    rating_stats?: UserRatingStats,
    misc_stats?: UserMiscStats,
    hgms_stats?: UserHighestGameScoreStats,
    stats_ext1?: UserExtraStats,
};

export type UserGameStats = {
    won?: string,
    lost?: string,
    drawn?: string,
    deleted?: string,
    played?: string,
    aborted?: string,
    avg_game_score?: string,
    current_streak?: string,
    best_streak?: string,
    bingo_count?: string,
};

export type UserMoveStats = {
    avg_move_score?: string,
    total_moves?: string,
    avg_move_time_spend?: string,
    avg_bonustiles_used_percentage?: string,
};

export type UserRatingStats = {
    rating?: string,
    deviation?: string,
    volatility?: string,
    ratinglastupdate?: string,
    bestrating?: string,
    bestrating_date?: string,
};

export type UserMiscStats = {
    joining_time?: string,
    lastupdate?: string,
};

export type UserHighestGameScoreStats = {
    gid?: string,
    pid?: string,
    score?: string,
};

export type UserExtraStats = {
    mvs30p?: string,
    mvs50p?: string,
    mvs100p?: string,
    wds2Lpld?: string,
    wds3Lpld?: string,
    jqxz?: string,
    mostbingosinagame?: UserMostBingosInAGameStats,
    bestwinever?: UserBestWinEverStats,
    bestbingoever?: UserBestBingoEverStats,
    longestwordplayed?: UserLongestWordPlayedStats,
};

export type UserMostBingosInAGameStats = {
    gid?: string,
    cnt?: string,
};

export type UserBestWinEverStats = {
    gid?: string,
    score?: string,
};

export type UserBestBingoEverStats = {
    gid?: string,
    word?: string,
    score?: string,
};

export type UserLongestWordPlayedStats = {
    gid?: string,
    word?: string,
    len?: string,
    score?: string,
};

//======================================================================

export type AppleLoginInfo = {
    appluserid?: string,
    applauthcode?: string,
    applidttytkn?: string,
    applemail?: string,
    fmlyname?: string,
    gvnname?: string,
    nickname?: string,
};

export type GGLLoginInfo = {
    userInfo: any, //?User,  // Change for react native web
    error: ?string,
};

export type LXLSLoginInfo = {
    authuser: ?string,
    authsecret: ?string,
    uid: ?string,
    email: ?string,
};

export type FBLoginInfo = {
    fbAccessToken: ?AccessToken,
    username: ?string,
};

//=================================STATS==================================
export type ActionUpdateMinStats = {
    type: string,
    payload: { [string]: UserStats },
};
export type ActionClearMinStats = ActionGeneric;
export type MinStatsAction = ActionUpdateMinStats | ActionClearMinStats;
//===============================END STATS================================

//=================================SPLASH TYPES==================================
export type SplashViewProps = {
    popups: PopupData,
    navigation: NavigationProp,
    utils: AppUtilsTypes,
    updatePopupVisibility: (PopupData) => void,
    clearPopups: () => void,
    showAlert: (AlertBoxType) => void,
    clearAlert: () => ActionClearPopups,
};

//===============================END SPLASH TYPES================================

//=================================HOMESCREEN TYPES==================================
export type HomeViewProps = {
    popups: PopupData,
    utils: AppUtilsTypes,
    navigation: NavigationProp,
    updatePopupVisibility: (data: PopupData) => ActionPopupVisibility,
    clearPopups: () => ActionClearPopups,
};

//===============================END HOMESCREEN TYPES================================

//=================================PROFILEVW TYPES==================================

export type ProfileViewProps = {
    profile: ProfileInfo,
    profileVw: ProfileAssociations,
    profileSettings: userSettings,
    friends: Array<FndSectionData>,
    lastupdated: number,
    minStats: { [string]: UserStats },
    popups: PopupData,
    navigation: NavigationProp,
    utils: AppUtilsTypes,
    actionSetProfile: (ProfileInfo) => ActionSetProfile,
    actionUpdateProfile: (ProfileInfo) => ActionUpdateProfile,
    actionUpdateAppleLgnInfo: (?AppleLoginInfo) => ActionUpdateAppleLgnInfo,
    updatePopupVisibility: (data: PopupData) => ActionPopupVisibility,
    clearPopups: () => ActionClearPopups,
    showAlert: (data: AlertBoxType) => void,
    clearAlert: () => ActionClearPopups,
};

export type ProfileAssociations = {
    appleLoginInfo: ?AppleLoginInfo,
    fbLoginInfo: ?FBLoginInfo,
    gglLoginInfo: ?GGLLoginInfo,
    lxlsLoginInfo: ?LXLSLoginInfo,
};

export type ProfileVwAction = ActionSetProfile | ActionUpdateProfile | ActionUpdateAppleLgnInfo;
//===============================END PROFILEVW TYPES================================

//===============================PROFILE TYPES================================
export type ProfileState = {|
    profile: ProfileInfo,
|};

export type ActionSetProfile = {
    type: string,
    payload: ProfileInfo,
};

export type ActionUpdateProfile = {
    type: string,
    payload: ProfileInfo,
};

export type ActionUpdateAppleLgnInfo = {
    type: string,
    payload: ?AppleLoginInfo,
};

export type ActionUpdateFBLgnInfo = {
    type: string,
    payload: ?FBLoginInfo,
};

export type ActionUpdateGGLLgnInfo = {
    type: string,
    payload: ?GGLLoginInfo,
};

export type ActionUpdateLXLSLgnInfo = {
    type: string,
    payload: ?LXLSLoginInfo,
};
export type ActionClearProfile = ActionGeneric;

export type ActionProfileSettings = {
    type: string,
    payload: userSettings,
};
//===============================END PROFILE TYPES================================

//===============================LNRAPI TYPES================================
export type LNRVwState = {
    lrnVwInpData: ?string,
    lrnVwErrCode: ?string,
    lrnVwErrMsg: ?string,
    isFocused: boolean,
};

export type LNRVwData = {
    lrnVwCode: string,
};

export type LNRVwProps = {
    lrnVwLgnInfo: LXLSLoginInfo,
};

export type ActionLRNGeneric = {
    type: string,
    payload: string | LXLSLoginInfo,
};

export type ActionLrnUpdateName = ActionLRNGeneric;
export type ActionLrnUpdateEmail = ActionLRNGeneric;
export type ActionLrnUpdatePwd = ActionLRNGeneric;
export type ActionLrnClearData = ActionGeneric;

export type LNRVwAction = ActionLrnUpdateName | ActionLrnUpdateEmail | ActionLrnUpdatePwd;

export type LNRResponse =
    | LXLSSimpleAuthSuccessResponse
    | LNRErrorResponse
    | LXLSLoginSuccessResponse
    | LXLSRegisterSuccessResponse;

export type LXLSSimpleAuthSuccessResponse = {
    check: 'Success',
    username: string,
    sitecode: 'LEXEMAIL',
};

export type LXLSForgotPasswordResponse = {
    check?: string,
    message?: string,
};

export type LXLSRegisterSuccessResponse = {
    check: 'Success',
    avtar: string,
    sitecode: 'LEXEMAIL',
};

export type LNRErrorResponse = {
    check: 'Failure',
    message: string,
    sitecode: 'LEXEMAIL',
};

export type LXLSLoginSuccessResponse = {
    check: 'Success',
    email: string,
    uid: string,
    avtar: string,
    prouser: string,
    sitecode: 'LEXEMAIL',
};

export type LXLSUserNameAvailabilityErrorRespose = {
    false_chk: 'false',
    username_suggestion1: string,
    username_suggestion2: string,
};
//=============================END LNRAPI TYPES==============================

//=============================GL TYPES==============================
export type GamesListProps = {
    isrefreshing: boolean,
    showreview: boolean,
    showshare: boolean,
    profile: ProfileInfo,
    playersinfo: {
        [string]: ProfileInfo,
    },
    games: Array<GamesListSectionData>,
};

export type GamesListState = {
    isFocused: boolean,
    bannerHt: number,
    newsFeed: Array<NewsFeedType>,
};

export type NewsFeedType = {
    title: string,
    msg: string,
    url?: string,
};

export type NewsFeedResponse = {
    check: string,
    data?: Array<NewsFeedType>,
};

export type ArchiveGamesListRequestData = {
    channel: string,
    guid: string,
    uuid: string,
    epoch: string,
    currenttime: string,
    skip: string,
    limit: string,
};

export type ReviewShareData = {
    reviewsharestate: number,
};

export type GamesListResponse = {
    uid: ProfileInfo,
    playersinfo: {
        [string]: ProfileInfo,
    },
    games: Array<GamesListGameData>,
};

export type GamesListGameData = {
    gid: string,
    startedon: string,
    lastupdate: string,
    turnpid: string,
    dic: string,
    lts?: boolean,
    gametype: string,
    boardtype: string,
    lastmove: string,
    mid: string,
    unreadmsg?: string,
    tilesinbag: string,
    fftdays?: string,
    gameover_reason?: string,
    winner?: Array<string>,
    players: Array<GamesListPlyElement>,
};

export type GamesListPlyElement = {
    uid: string,
    pid: string,
    score: string,
};

export type GamesListSectionData = {
    title: string,
    type: 'myturn' | 'theirturn' | 'archivedgames' | 'extension',
    data: Array<GamesListItemData>,
};

export type GamesListItemData = {
    type: 'game' | 'extension' | 'review' | 'share',
    key: string,
    data: GamesListRowData,
};

export type GamesListRowData = GamesListGameData | GamesListExtensionData | ReviewShareData;

export type GamesListExtensionData = {
    val?: string,
};

export type ExtractedGames = {
    myturngames: Array<GamesListGameData>,
    theirturngames: Array<GamesListGameData>,
    miniarchivedgames: Array<GamesListGameData>,
};

export type GamesListElementViewData = {
    game: GamesListItemData,
    imageTapHandler?: (string) => void,
    gameTapHandler?: (GamesListItemData, () => void | null) => void,
};

export type AvatarWithNameData = {
    imgicon?: number,
    imgtxt?: string,
};

export type GamesListSectionElementData = {
    title: string,
    data: string,
};

//export type GLAction = ActionRefreshGames;
export type GLAction = ActionRefreshGames | ActionGLRefreshStarted | ActionReviewShareUpdateData;

export type ActionRefreshGames = {
    type: string,
    payload: GamesListResponse,
    profile: ProfileInfo,
};

export type ActionGeneric = {
    type: string,
};

export type ActionGLRefreshStarted = ActionGeneric;
export type ActionGLRefreshFinished = ActionGeneric;
export type ActionGLClearData = ActionGeneric;
export type ActionGLClearRvwShrData = ActionGeneric;

export type ActionGLAdEvent = {
    type: string,
    payload: boolean,
};

export type gidType = { gid: string };

export type ActionGLReadChatEvent = {
    type: string,
    payload: Array<gidType>,
};

export type ActionGLReviewShareUpdate = {
    type: string,
    payload: ReviewShareData,
};

export type ActionReviewShareUpdateData = {
    type: string,
    payload: ReviewShareUpdateData,
};

export type ActionGLUpdtViaBoardInfo = {
    type: string,
    payload: GlUpdtViaBoardInfoData,
};

export type ReviewShareUpdateData = {
    type: 'review' | 'share',
    show: boolean,
    reviewsharestate: number,
};

export type ReviewShareExistingIdx = {
    secindex: number,
    idx: number,
    data?: ReviewShareData,
};
//=============================END GL TYPES==============================

//=============================BEGIN POPUP TYPES==============================
export type PopupData = {
    pendingAlerts?: Array<AlertBoxType>,
    showUserNamePopup?: boolean,
    showDictionaryPopup?: boolean,
    showLoginPopup?: boolean,
    showSharePopup?: boolean,
    showHelpPopup?: boolean,
    showDetailsPopup?: boolean,
    showTutorialPopup?: boolean,
    showMatchFriendPopup?: boolean,
    showHostGamePopup?: boolean,
};

export type PopupAction = ActionPopupVisibility | ActionClearPopups;

export type ActionPopupVisibility = {
    type: string,
    payload: PopupData,
};

export type ActionAddAlert = {
    type: string,
    payload: AlertBoxType,
};

export type ActionClearPopups = ActionGeneric;

//=============================END POPUP TYPES==============================

//=============================STATSPROFILE TYPES==============================
export type StatsProfileProp = {
    navigation: NavigationProp,
    route: RouteProp,
    profile: ProfileInfo,
    friends: Friends,
    popups: PopupData,
    utils: AppUtilsTypes,
    actionGLBLMkFriendEvent: (ProfileInfo) => ActionMkFriend,
    actionGLBLRmFriendReqEvent: (ProfileInfo) => ActionMkFriend,
    actionGLBLCancelSentFriendRequest: (ProfileInfo) => ActionCancelSentFndReq,
    actionGLBLCensorEvent: (ProfileInfo) => ActionCensorReq,
    actionGLBLRmAddedFriendReqEvent: (ProfileInfo) => ActionRmAddedFriendReq,
    actionGLBLUncensorEvent: (ProfileInfo) => ActionUncensorReq,
    updatePopupVisibility: (PopupData) => void,
    clearPopups: () => void,
    showAlert: (AlertBoxType) => void,
    clearAlert: () => ActionClearPopups,
};
//===========================END STATSPROFILE TYPES============================

//=============================FNDAPI TYPES==============================

export type GLBLFriendsAndFoes = {
    buddies: Array<ProfileInfo>,
    reqsent: Array<ProfileInfo>,
    pending: Array<ProfileInfo>,
    censored: Array<ProfileInfo>,
};

export type Friends = {
    friends: Array<FndSectionData>,
    isrefreshing: boolean,
    lastupdated: number,
};

export type FriendsVwState = {
    fndAddFriendInpData: ?string,
    isFocused: boolean,
    txtInpRef: { current: null | React.ElementRef<'input'> },
    friendsStats: ?matchFriendData,
    AccountSelection: boolean,
    matchFriendDictionary: string,
    prefferedFndSearchMode: number,
    bannerHt: number,
};

export type ActionAddGLBLFriendsAndFoes = {
    type: string,
    payload: GLBLFriendsAndFoes,
};

export type ActionMkFriend = {
    type: string,
    payload: ProfileInfo,
};

export type ActionRmFriendReq = ActionMkFriend;
export type ActionRmAddedFriendReq = ActionMkFriend;
export type ActionInsertSentFndReq = ActionMkFriend;
export type ActionCancelSentFndReq = ActionMkFriend;
export type ActionCensorReq = ActionMkFriend;
export type ActionUncensorReq = ActionMkFriend;

export type ActionGLBLFndRefreshStarted = ActionGeneric;
export type ActionGLBLFndRefreshFinished = ActionGeneric;
export type ActionGLBLFndClearData = ActionGeneric;

export type ActionGLBLFndAdEvent = {
    type: string,
    payload: boolean,
};

export type FndAction =
    | ActionAddGLBLFriendsAndFoes
    | ActionGLBLFndRefreshStarted
    | ActionGLBLFndRefreshFinished
    | ActionGLBLFndClearData
    | ActionGLBLFndAdEvent
    | ActionMkFriend
    | ActionRmFriendReq;

export type FndSectionData = {
    title: string,
    type: 'fnd' | 'reqsent' | 'pending' | 'censored',
    data: Array<FndItemData>,
};

export type FndItemData = {
    type?: 'fnd' | 'reqsent' | 'pending' | 'censored',
    key?: string,
    data: FndRowData,
};

export type FndRowData = ProfileInfo;
//=============================FNDAPI TYPES==============================

//=============================ProfileBarContainer TYPES==============================

export type ProfileBarContainerProps = {
    profile: ProfileInfo,
    canShare: boolean,
    disableActionBtn: boolean,
    rating: string,
    dictionary: string,
    otherUsrProfile: ProfileInfo,
    popups: PopupData,
    utils: AppUtilsTypes,
    openPopupHandler: () => void,
    userAvatarDidFinishedEditing: () => void,
    updatePopupVisibility: (PopupData) => void,
    showAlert: (AlertBoxType) => void,
    clearAlert: () => void,
};
//=============================ProfileBarContainer TYPES==============================

//=========================================================================
export type us_dictionary = 'twl' | 'sow' | 'it' | 'fr';
export type us_preference = 'Y' | 'y' | 'N' | 'n';

export type UserSettingsResponse = { string: userSettings };

export type userSettings = {
    us_email?: userSettingsEmail,
    us_pushntf?: userSettingsPushNotification,
    us_gameplay?: userSettingsGamePlay,
    us_privacy?: userSettingsPrivacy,
    us_gamestart?: userSettingsGameStart,
    us_prouser?: userSettingsProUser,
    us_purchases?: userPuchases,
};
export type userSettingsEmail = {
    em_gamestarted?: us_preference,
    em_myturn?: us_preference,
    em_chat?: us_preference,
    em_gamecompleted?: us_preference,
    em_dailydigest?: us_preference,
    em_recnudgerequest?: us_preference,
    em_enableautologinlinks?: us_preference,
};
export type userSettingsPushNotification = {
    ntf_gamestarted?: us_preference,
    ntf_myturn?: us_preference,
    ntf_chat?: us_preference,
    ntf_gamecompleted?: us_preference,
    ntf_dailydigest?: us_preference,
    ntf_recnudgerequest?: us_preference,
    ntf_enableautologinlinks?: us_preference,
};
export type userSettingsGamePlay = {
    gp_magictiles?: us_preference,
    gp_moveconfirmation?: us_preference,
    gp_numbrdboard?: us_preference,
    gp_gamesounds?: us_preference,
    gp_premovevalidation?: us_preference,
    gp_autozoomboard?: us_preference,
    gp_gametheme?: string,
    gp_homepage?: string,
    gp_homecountry?: string,
    gp_darktheme?: us_preference,
    gp_scoregraph?: us_preference,
    gp_showtooltip?: us_preference,
    gp_chtfntsze?: string,
    gp_showforum?: us_preference,
};
export type userSettingsPrivacy = {
    pvc_showonlinestatus?: us_preference,
    pvc_showprostatus?: us_preference,
    pvc_disablechat?: us_preference,
    pvc_sgstplys?: us_preference,
    pvc_showlbycht?: us_preference, //default 'y'(on clientside); and 'n' will hide all lobby chat including game updates bingo admin msgs etc.
    pvc_showlbygmupdt?: us_preference, //default 'y'(on clientside); and 'n' will hide a subset like game updates.
};

export type userSettingsGameStart = {
    gs_showinit?: us_preference,
    gs_prefdic?: us_dictionary,
    gs_ratingrange?: string,
    gs_boardtype?: string,
    gs_gametype?: string,
    gs_speed?: string,
    gs_maxreq?: string,
    gs_numplayers?: string,
    gs_rated?: string,
    gs_lvduration?: string,
    gs_lvincrmnt?: string,
};
export type userSettingsProUser = {
    pro_analizegamesleft?: string,
    pro_till?: string,
    anlz_till?: string,
};
export type userPuchases = {
    pro?: string,
    anlz?: string,
};
//========================================================================================
//=============================GameFactoryContainer TYPES==============================
export type GameFactoryContainerProps = {
    popups: PopupData,
    utils: AppUtilsTypes,
    friends: Friends,
    updatePopupVisibility: (PopupData) => void,
    clearPopups: () => void,
    navigation: NavigationProp,
};
//=============================GameFactoryContainer TYPES==============================
//=====================================================================================
export type SliderContainerProps = {
    min: number,
    max: number,
    style: any,
    tag: string,
    onValueSelect: (number, number, string) => void,
};
export type BooleanToggleContainerProps = {
    true_col: string,
    false_col: string,
    value: boolean,
    tag: string,
    onValueSelect: (string, string) => void,
};
export type SelectContainerProps = {
    drillDown_pickerStyle: Array<{ [key: string]: string | number }>,
    defaultButtonText: string,
    selectItem: Array<string>,
    tag: string,
    renderType: string,
    onValueSelect: (string, string) => void,
};
//==============================Other User Stat types============================================

export type StatsSection = {
    title: string,
    data: Array<StatsElementDataType>,
};

export type StatsElementDataType = {
    lbl: string,
    key?: string,
    data: string | LWPdataType,
};

export type LWPdataType = {
    word: string,
    score: string,
};

export type statFndItemData = {
    type?: 'fnd' | 'reqsent' | 'pending' | 'censored',
    key?: string,
    data?: FndRowData,
};
export type StatsDataMap = {
    game_stats?: string,
    aborted?: string,
    active_game_count?: string,
    avg_game_score?: string,
    best_streak?: string,
    bingo_count?: string,
    current_streak?: string,
    deleted?: string,
    drawn?: string,
    lost?: string,
    played?: string,
    won?: string,
    hgms_stats?: string,
    gid?: string,
    pid?: string,
    score?: string,
    misc_stats?: string,
    joining_time?: string,
    lastupdate?: string,
    move_stats?: string,
    avg_bonustiles_used_percentage?: string,
    avg_move_score?: string,
    avg_move_time_spend?: string,
    total_moves?: string,
    rating_stats?: string,
    bestrating?: string,
    bestrating_date?: string,
    deviation?: string,
    rating?: string,
    ratinglastupdate?: string,
    volatility?: string,
    stats_ext1?: string,
};
export type FriendStatus = {
    isFriend: boolean,
    hasCensored: boolean,
    reqPending: boolean,
    reqSent: boolean,
};
export type TutorialPopupProps = {
    closePopupHandler: () => void,
    showTutorialHandler: () => void,
};

export type WinLossStatsBarType = {
    won: number,
    games: number,
    lost: number,
    drawn: number,
    bingos: number,
};
export type MatchFriendPopupProps = {
    cancelMatch: () => void,
    profile: ProfileInfo,
    userStats: matchFriendData,
    navigation: NavigationProp,
    profileSettings: userSettings,
    opponentDict: string,
};
export type matchFriendData = {
    barstats: WinLossStatsBarType,
    rating: string,
    guid: string,
    profile: ProfileInfo,
};

export type StartNewGamePlayers = { [string]: string };

export type StartNewGameSetting = {|
    dic: string,
    gametype: string,
    boardtype: string,
|};
//===================================================================================================

export type DimensionsType = { width: number, height: number };

export type sectionType = {
    key: string,
    title: string,
    content: Array<SectionElementContent>,
};

export type SectionElementContent = {
    key: string,
    lbl: string,
    type: string,
    editable?: string,
    def_value: string,
};
//========================================= AGL type==========================================================
export type AGLContainerPropsType = {
    navigation: NavigationProp,
    archivegames: Array<{
        title: string,
        data: Array<GamesListItemData>,
    }>,
    playersinfo: { [string]: ProfileInfo },
};

export type ActionGLUpdate = {
    type: string,
    payload: GameListUpdateData,
};

export type GameListUpdateData = SvcActionData | SvcActionDataGid;

type SvcActionData = {
    data: SvcActionMoveData,
};

type SvcActionDataGid = {
    gid: string,
    data: SvcActionMoveData,
};

type SvcActionMoveData = {
    lastupdate: string,
    tilesinbag: string,
    current_turn: string,
    game_status: string,
    lastmoveid: string,
    players: Array<SvcPlayerData>,
    boarddata: SvcBoardData,
};

type SvcPlayerData = SvcPlayerData1 | SvcPlayerData2;

type SvcPlayerData1 = {
    pid: string,
    current_score: string,
    currentrack: string,
    racklen: string,
    scores: Array<number>,
};

type SvcPlayerData2 = {
    name: string,
    avtar: string,
    guid: string,
    pid: string,
    usrtype: string,
    lexcom: string,
    racklen: string,
    resigned: string,
    current_score: string,
    onlinestatus: string,
};

type SvcBoardData = {
    brdtype: string,
    wordsplayed: Array<Array<string>>,
    movetiles: Array<Array<string>>,
};

//==========================================================

export type NtfAndroidData = {
    title: string,
    data: string,
    json: string,
    type?: string,
};

export type NtfIOSData = {
    pldata: string,
};

export type NtfIOSGameData = {
    type: string,
    useruid?: string,
    games?: NtfGameData,
};

export type NtfGameData = {
    gameid: string,
    dic: string, //twl,sow etc
    gametype: string, //R for regular
    turnuid: string, //guid
    players: { [string]: string }, //{"1":"642226581473,Diane J,fdzc","2":"113022974700,Ellen A,fdzc"}
};

export type StartNewGameplayers = {
    name: string,
    avtar: string,
    guid: string,
    currentrack: string,
    pid: string,
    rating: string,
    usrtype: string,
    lexcom?: string,
    racklen: string,
    resigned: string,
    current_score: string,
    onlinestatus: string,
};

export type GlUpdtViaBoardInfoData = {
    gameFdGlData: GamesListGameData,
    gameFdPlayerInfo: Array<StartNewGameplayers>,
};

export type AlertBoxType = {
    title?: string,
    title_icon?: number,
    message?: string,
    message_icon?: number,
    actions: Array<{
        text: string,
        action?: () => void,
        color: {
            bgColor: string,
            textColor: string,
        },
        type: string,
    }>,
};

export type HostedGameHostInfo = {
    adult: string,
    ver: string,
    device: string,
};

export type HostedAGameConfig = {
    numplys: string,
    maxrequest: string,
    brag: string,
    dic: string,
    speed: string,
    gametype: string,
    boardtype: string,
    fromrating: string,
    torating: string,
    fftdays: string,
};

export type HostedGameInfo = {
    uid: ProfileInfo,
    gamereqid: string,
    rating: string,
    won: string,
    lost: string,
    drawn: string,
    hstgmtype: string,
    played?: string,
    bingo_count?: string,
    jndplys?: Array<ProfileInfo>,
};

export type ActionHostedGameType = {
    type: string,
    payload: Array<HostedGameElement>,
    guid: string,
};

export type HostedGames = {
    hostedGames: Array<{
        title: 'hosted_game',
        data: Array<HostedGameElement>,
    }>,
};

export type HostedGameActions = ActionHostedGameType | ActionGeneric;
export type HostGameRequestConfig = HostedAGameConfig & HostedGameHostInfo;
export type HostedGameElement = HostedGameInfo & HostedAGameConfig;

export type HostedGameActionType = 'joinhostedgame' | 'leavehostedgame';

export type HostedGameResponse = {
    lxls: {
        channel: string,
        gid: string,
        dic: string,
        gametype: string,
        boardtype: string,
        starttime: string,
        lastupdate: string,
        tilesinbag: string,
        current_turn: string,
        game_status: string,
        chatstatus: string,
        source: string,
        players: Array<StartNewGameplayers>,
        boarddata: SvcBoardData & {
            updatetstmp: Array<Array<string>>,
            rackinfo: Array<Array<string>>,
        },
        chat: Array<Array<string>>,
    },
};
