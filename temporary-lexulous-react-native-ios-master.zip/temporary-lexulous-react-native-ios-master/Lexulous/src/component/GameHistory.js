import React, { Component } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import get from 'lodash/get';
import { connect } from 'react-redux';
import { getNull } from '../utils/Utils';
import PText from './PText';
import S10Text from './S10Text';
import FontAwesomeSpin from './FontAwesomeSpin';
import LayoutWrapper from '../utils/LayoutWrapper';
import GameBoardUtils from '../utils/GameBoardUtils';

class GameHistory extends Component {
    constructor(props) {
        super(props);
        this.gameHistoryScrollRef = React.createRef();
    }

    getColor = (color) => ({ color });

    isWinMore = () =>
        Number(get(this.props, 'game.headToHead.won').split(' (')[0]) >
        Number(get(this.props, 'game.headToHead.lost').split(' (')[0]);

    getFlex = (flex) => ({ flex });

    getBackground = () => ({
        backgroundColor: this.props.statModal
            ? ColorConfig.WHITE
            : ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        minWidth: '100%',
    });

    scrollToEndHistoryEachRow = () => {
        this.gameHistoryScrollRef.current.scrollToEnd({
            animated: true,
        });
    };

    renderEachHistoryCell = ({ element, isTop, isName, color, index }) => (
        <View
            key={'gamehistory_cell_' + index}
            style={[
                styles.historyTextView,
                LayoutWrapper.getHistoryCellPadding(),
                isTop ? styles.seperationStyle : null,
                isName && styles.additionalStyleForPlayerName,
                color && styles.alignItemsFlexEnd,
            ]}
        >
            {isName ? (
                <PText
                    style={[
                        styles.nameTextStyle,
                        color
                            ? [this.getColor(color), styles.fontWeightBold]
                            : null,
                    ]}
                    numberOfLines={1}
                    ellipsizeMode={'tail'}
                >
                    {element}
                </PText>
            ) : (
                <S10Text
                    style={[
                        styles.gameHistoryTextStyle,
                        color
                            ? [this.getColor(color), styles.fontWeightBold]
                            : null,
                    ]}
                >
                    {element}
                </S10Text>
            )}
        </View>
    );

    renderHistoryCellElement = (item, index) => [
        this.renderEachHistoryCell({
            element:
                item.result === 'W'
                    ? this.isPlayerOrderSame()
                        ? '1'
                        : '0'
                    : item.result === 'L'
                    ? this.isPlayerOrderSame()
                        ? '0'
                        : '1'
                    : '-',
            isTop: true,
            index,
        }),
        this.renderEachHistoryCell({
            element:
                item.result === 'W'
                    ? this.isPlayerOrderSame()
                        ? '0'
                        : '1'
                    : item.result === 'L'
                    ? this.isPlayerOrderSame()
                        ? '1'
                        : '0'
                    : '-',
            isTop: false,
            index: index + '_inv',
        }),
    ];

    renderEachPlayerWinAmount = () => [
        this.renderEachHistoryCell({
            element:
                get(
                    this.props,
                    `game.headToHead.h2hstats.${
                        this.isPlayerOrderSame() ? 'won' : 'lost'
                    }`
                ) || '0',
            isTop: true,
            isName: false,
            color: GameBoardUtils.getPlayerWiseStrokeColor('1'),
            /*color: (
                this.isPlayerOrderSame() ? this.isWinMore() : !this.isWinMore()
            )
                ? '#2762e3'
                : '#f0932b',*/
            index: 'h2hstatswon',
        }),
        this.renderEachHistoryCell({
            element:
                get(
                    this.props,
                    `game.headToHead.h2hstats.${
                        this.isPlayerOrderSame() ? 'lost' : 'won'
                    }`
                ) || '0',
            isTop: false,
            isName: false,
            color: GameBoardUtils.getPlayerWiseStrokeColor('2'),
            /*color: (
                this.isPlayerOrderSame() ? !this.isWinMore() : this.isWinMore()
            )
                ? '#2762e3'
                : '#f0932b',*/
            index: 'h2hstatslost',
        }),
    ];

    isPlayerOrderSame = () =>
        get(this.props, 'statModal')
            ? get(this.props, 'game.headToHead.guidArr.0') ===
              get(this.props, 'game.guid')
            : get(this.props, 'game.headToHead.guidArr.0') ===
              get(this.props, 'game.players.0.guid');

    render = () =>
        get(this.props, 'game.headToHead') &&
        Object.keys(get(this.props, 'game.headToHead')).length > 0 ? (
            <ScrollView
                key={'gamehistory_scrollview'}
                contentContainerStyle={this.getBackground()}
                style={{ width: '100%' }}
                horizontal={!get(this.props, 'statModal')}
                ref={this.gameHistoryScrollRef}
                onContentSizeChange={
                    !get(this.props, 'statModal')
                        ? this.scrollToEndHistoryEachRow
                        : getNull
                }
            >
                <View
                    key={'gamehistory_view1'}
                    style={[
                        styles.gameHistoryRowStyle,
                        get(this.props, 'statModal')
                            ? styles.borderBottomWidth0
                            : null,
                    ]}
                >
                    <View
                        key={'gamehistory_view2'}
                        style={styles.gameHistoriesRowStyle}
                    >
                        {get(this.props, 'game.headToHead.gameHistories').map(
                            (element, index) => (
                                <View
                                    key={'gamehistory_view2_' + index}
                                    style={styles.gameHistoryInnerView}
                                >
                                    {this.renderHistoryCellElement(
                                        element,
                                        index
                                    )}
                                </View>
                            )
                        )}
                    </View>
                    <View key={'gamehistory_view3'} style={this.getFlex(0.3)}>
                        {[
                            this.renderEachHistoryCell({
                                element: get(this.props, 'statModal')
                                    ? this.props.myName
                                    : get(this.props, 'game.players.0.name'),
                                isTop: true,
                                isName: true,
                                index: 'myName',
                            }),
                            this.renderEachHistoryCell({
                                element: get(this.props, 'statModal')
                                    ? this.props.opponentName
                                    : get(this.props, 'game.players.1.name'),
                                isTop: false,
                                isName: true,
                                index: 'opponentName',
                            }),
                        ]}
                    </View>
                    <View key={'gamehistory_view4'} style={this.getFlex(0.1)}>
                        {this.renderEachPlayerWinAmount()}
                    </View>
                </View>
            </ScrollView>
        ) : !get(this.props, 'statModal') ? (
            <View
                key={'gamehistory_view5'}
                style={[
                    this.getBackground(),
                    styles.justifyContentCenter,
                    get(this.props, 'height')
                        ? get(this.props, 'height')
                        : null,
                ]}
            >
                <FontAwesomeSpin />
            </View>
        ) : null;
}

const styles = StyleSheet.create({
    justifyContentCenter: { justifyContent: 'center' },
    gameHistoryRowStyle: {
        flexDirection: 'row',
        minWidth: '100%',
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    gameHistoriesRowStyle: {
        flex: 0.6,
        flexDirection: 'row',
    },
    gameHistoryInnerView: {
        flex: 1,
        flexBasis: '0%',
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    gameHistoryTextStyle: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    historyTextView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    nameTextStyle: {
        color: ColorConfig.BLACK,
    },
    borderBottomWidth0: { borderBottomWidth: 0 },
    seperationStyle: {
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    additionalStyleForPlayerName: {
        alignItems: 'flex-start',
        paddingLeft: 12,
    },
    alignItemsFlexEnd: { alignItems: 'flex-end' },
    fontWeightBold: { fontWeight: 'bold' },
});

const mapStateToProps = (state) => ({ game: state.game });

export default connect(mapStateToProps)(GameHistory);
