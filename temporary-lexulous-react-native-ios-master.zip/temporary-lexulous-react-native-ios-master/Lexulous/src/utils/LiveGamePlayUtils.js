import get from 'lodash/get';
import {
    censorPlayer,
    getLiveGameStats,
    uncensorPlayer,
    isLiveGame,
    isEmailGame,
    getHostGamesHeadToHeadStats,
    getUniqueWordsPlayedCount,
} from '../service/GamePlayService';
import GameBoardUtils from './GameBoardUtils';
import { to } from 'await-to-js';
import { addToBuddyList, checkRatingChange, removeFromBuddyList } from '../service/LiveGamePlayService';
import store from '../store';
import Config from '../configs/Config';
import cloneDeep from 'lodash/cloneDeep';
import { findAndRemove } from './Utils';
import { addHostGameHeadToHeadStat, hostJoinDialog, hostJoinedPlayerStats, joinHostedGame } from '../actions/GameActions';
import {
    GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS,
    GAME_LIVE_HOST_JOINED_PLAYER_STATS,
    GAME_LIVE_HOST_JOIN_DIALOG,
    GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
} from '../configs/ActionIdentifiers';
import ConfigurationWrapper from './ConfigurationWrapper';
import ServiceUtils from './ServiceUtils';
import DimensionUtils from './DimensionUtils';

const eventBus = require('js-event-bus')();

export default class LiveGamePlayUtils {
    static getOpponentGuid = (data) =>
        get(data, 'uid.guid') ||
        get(data, 'p1uid') ||
        get(data, 'playerItem.guid') ||
        (get(data, 'reqJoinHostGame') && get(data, 'sender.guid'));

    static getHeadToHeadPercentage = (headToHeadData) => {
        if (Number(headToHeadData.extcode) === 1) {
            let won = parseInt(headToHeadData.data.h2hstats.won || 0);
            let lost = parseInt(headToHeadData.data.h2hstats.lost || 0);
            let draw = parseInt(headToHeadData.data.h2hstats.draw || 0);

            let wonPercentage = ((won / (won + lost + draw)) * 100).toFixed(0);
            let lostPercentage = ((lost / (won + lost + draw)) * 100).toFixed(0);
            let drawPercentage = ((draw / (won + lost + draw)) * 100).toFixed(0);
            let guidRelation = headToHeadData.data.guids;
            let guidArr = guidRelation.split('-');
            let firstElement = guidArr[0];

            //if first element is user's guid
            return {
                h2hstats: headToHeadData.data.h2hstats,
                won:
                    won +
                    ' ( ' +
                    (firstElement === get(store.getState(), 'game.guid') ? wonPercentage : lostPercentage) +
                    '% ) ',
                lost:
                    lost +
                    ' ( ' +
                    (firstElement === get(store.getState(), 'game.guid') ? lostPercentage : wonPercentage) +
                    '% )',
                draw: draw + ' ( ' + drawPercentage + '% )',
                history: headToHeadData.check !== 'failure' ? headToHeadData.data.history : [],
                check: headToHeadData.check,
                guidArr: headToHeadData.check !== 'failure' ? headToHeadData.data.guids.split('-') : [],
            };
        }
    };

    static isHostGameRandom = (hostedGame = get(store.getState(), 'gamelist.hostedGame')) =>
        get(hostedGame, 'hstgmtype') === Config.HOSTED_GAME_TYPES.rnd;

    static isMultiplayerAcceptDialog = (hostedGame = store.getState().gamelist.hostedGame) =>
        hostedGame &&
        //!hostedGame.isInvitation &&
        hostedGame.numplys &&
        Number(hostedGame.numplys) > 2;

    static isRated = (hostedGame = get(store.getState(), 'gamelist.hostedGame')) => {
        let isRated = undefined;
        let isNativeOrRnWeb =
            DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb');
        if (isNativeOrRnWeb) {
            isRated = !LiveGamePlayUtils.isMultiplayerAcceptDialog(hostedGame);
        } else {
            let rated = get(hostedGame, 'livegame') ? get(hostedGame, 'livegame.rated') : get(hostedGame, 'live.rated');
            isRated = rated === 'y';
        }
        return isRated;
    };

    static isInviting = (hostedGame = get(store.getState(), 'gamelist.hostedGame')) => get(hostedGame, 'isInviting');

    static getStatusTextFromCode = (code) => {
        switch (code) {
            case 'ply':
                return 'Playing';
            case 'avl':
                return 'Available';
            case 'jnd':
                return 'Joined';
            default:
                throw new Error('Invalid Status Code');
        }
    };

    static isPlayerPlaying = (code) => code === 'ply';

    static getTimeControlData = ({ time, increment, separator = ' , ' } = {}) => {
        time = time + (Number(time) === 1 ? ' min' : ' mins');
        increment = increment + (Number(increment) === 1 ? ' second' : ' seconds');
        return time + separator + increment;
    };

    static isPlaying = () =>
        get(store.getState(), 'game.gid') &&
        get(store.getState(), 'game.pid') &&
        !Array.isArray(get(store.getState(), 'game.winner'));

    static isObserving = (globalState = store.getState()) => !get(globalState, 'game.pid');

    static clearGame = () => null;

    static isMyTurn = (pid = get(store.getState(), 'game.pid'), currentTurn = get(store.getState(), 'game.currentTurn')) =>
        LiveGamePlayUtils.isPlaying() && pid === currentTurn;

    static hasGameEnded = () => !get(store.getState(), 'game.gameHasEnded');

    static stopPollOperation = () => {};

    static getAllPlayerDatasAndSet = async (jndply) => {
        let opponentStats = (await to(getLiveGameStats([jndply.guid])))[1];
        let game_stats = get(opponentStats, 'data.0.game_stats');
        Object.assign(jndply, game_stats);
        jndply.rating = get(opponentStats, 'data.0.rating_stats.rating');
        jndply.win = get(jndply, 'won') || '0';
        jndply.loss = get(jndply, 'lost') || '0';
        jndply.draw = get(jndply, 'drawn') || '0';
        jndply.playedNum = Number(jndply.win) + Number(jndply.loss) + Number(jndply.draw);
        jndply.played = String(jndply.playedNum);
        jndply.bingos = get(jndply, 'bingo_count') || '0';
        jndply.gcr =
            jndply.playedNum > 0
                ? String((((jndply.playedNum - Number(get(jndply, 'deleted') || '0')) / jndply.playedNum) * 100).toFixed(1)) +
                  '%'
                : 'NA';
        return jndply;
    };

    static getGamesCountWithWinPercentage = (played, win) => {
        let winPercentage =
            !isNaN(Number(played)) &&
            !isNaN(Number(win)) &&
            played != null &&
            win != null &&
            Number(played) > 0 &&
            Number(win) > 0
                ? ((win / played) * 100).toFixed(0)
                : 0;
        return (!isNaN(Number(played)) && played != null ? Number(played) : 0) + '\n(' + winPercentage + '% wins)';
    };

    static getDotColorAndTextForRating = (rating) => {
        rating = Number(rating);
        let resObj = {};
        if (rating < 1200) {
            resObj.rating_color = '#99ff00';
            resObj.rating_level = 'Level 1 of 8';
        } else if (1200 <= rating && rating < 1400) {
            resObj.rating_color = '#00cc33';
            resObj.rating_level = 'Level 2 of 8';
        } else if (1400 <= rating && rating < 1600) {
            resObj.rating_color = '#FFCF00';
            resObj.rating_level = 'Level 3 of 8';
        } else if (1600 <= rating && rating < 1800) {
            resObj.rating_color = '#6699ff';
            resObj.rating_level = 'Level 4 of 8';
        } else if (1800 <= rating && rating < 2000) {
            resObj.rating_color = '#cc6699';
            resObj.rating_level = 'Level 5 of 8';
        } else if (2000 <= rating && rating < 2200) {
            resObj.rating_color = '#993399';
            resObj.rating_level = 'Level 6 of 8';
        } else if (2200 <= rating && rating < 2400) {
            resObj.rating_color = '#ff6633';
            resObj.rating_level = 'Level 7 of 8';
        } else if (rating >= 2400) {
            resObj.rating_color = '#ff0000';
            resObj.rating_level = 'Level 8 of 8';
        }

        return resObj;
    };

    static pendingRequestActionUpdate = (accept, playerItem) => {
        if (accept) {
            let buddyList = cloneDeep(store.getState().user.buddyList) || {};
            (get(buddyList, 'buddies') || []).push(playerItem);
            ServiceUtils.buddyListUpdate(buddyList);
        }
        let buddyReqList = (cloneDeep(store.getState().user.buddyRequestList) || []).filter(
            (buddy) => buddy.guid !== playerItem.guid
        );
        ServiceUtils.pendingRequestListUpdate(buddyReqList);
    };

    static toggleFriendship = async (player) => {
        if (GameBoardUtils.isMyFriend(player)) {
            return await to(removeFromBuddyList(player));
        } else {
            return await to(addToBuddyList(player));
        }
    };

    static addRemoveBuddyUpdate = async (addBuddy, player) => {
        let buddyList = cloneDeep(store.getState().user.buddyList) || {};
        if (addBuddy) {
            (get(buddyList, 'reqsent') || []).push(player);
            ServiceUtils.buddyListUpdate(buddyList);
        } else {
            findAndRemove(get(buddyList, 'buddies') || [], (playerInArr) => playerInArr.guid === player.guid);
            findAndRemove(get(buddyList, 'reqsent') || [], (playerInArr) => playerInArr.guid === player.guid);
            findAndRemove(get(buddyList, 'online') || [], (playerInArr) => playerInArr.guid === player.guid);
            ServiceUtils.buddyListUpdate(buddyList);
        }
    };

    static toggleBlock = async (player) => {
        if (GameBoardUtils.isBlockedByMe(player)) {
            await to(uncensorPlayer(player));
        } else {
            await to(censorPlayer(player));
        }
    };

    static censorUncensorPlayerUpdate = async (isCensor, player) => {
        let blockList = cloneDeep(store.getState().user.sensorList) || [];
        if (isCensor) {
            blockList.push(player);
            ServiceUtils.censorListUpdate(blockList);

            let buddyList = cloneDeep(store.getState().user.buddyList) || {};
            (get(buddyList, 'reqsent') || []).some((player) => player.guid || player.uid) &&
                findAndRemove(get(buddyList, 'reqsent') || [], (item) => player.guid === item.guid);
            (get(buddyList, 'buddies') || []).some((player) => player.guid || player.uid) &&
                findAndRemove(get(buddyList, 'buddies') || [], (item) => player.guid === item.guid);
            (get(buddyList, 'online') || []).some((player) => player.guid || player.uid) &&
                findAndRemove(get(buddyList, 'online') || [], (item) => player.guid === item.guid);

            ServiceUtils.buddyListUpdate(buddyList);
        } else {
            findAndRemove(blockList, (sensored) => sensored.guid === player.guid);
            ServiceUtils.censorListUpdate(blockList);
        }
    };

    static getRatingForPlayer = (guid) => {
        let playerDataInList =
            (get(store.getState(), 'user.onlinePlayerBuddies') || []).find((player) => guid === get(player, 'guid')) ||
            (get(store.getState(), 'user.onlinePlayerOthers') || []).find((player) => guid === get(player, 'guid'));
        return get(playerDataInList, 'rating', '1200');
    };

    static getRatingForPlayerFromLiveGameListData = (guid) => {
        let playerDataInList =
            (get(store.getState(), 'user.onlinePlayerBuddies') || []).find((player) => guid === get(player, 'guid')) ||
            (get(store.getState(), 'user.onlinePlayerOthers') || []).find((player) => guid === get(player, 'guid'));
        return get(playerDataInList, 'rating', '1200');
    };

    static isGameHistoryAvailable = () =>
        (isLiveGame() || isEmailGame()) &&
        !LiveGamePlayUtils.isBlitzGame() &&
        !(get(store.getState(), 'game.gid') && !get(store.getState(), 'game.pid')) &&
        !LiveGamePlayUtils.isMultiplayerAcceptDialog() &&
        !(get(store.getState(), 'game.players') && get(store.getState(), 'game.players').length > 2) &&
        !get(store.getState(), 'game.showingAnalyseMove') &&
        get(store.getState(), 'game.headToHead') &&
        (get(store.getState(), 'game.headToHead.gameHistories') || []).length > 0;

    static isBlitzGame = () => get(store.getState(), 'game.game_type') === Config.GAME_TYPE_BLITZ;

    static getBestMoves = () => {
        let myBestMoves = 0,
            oppBestMoves = 0;
        (get(store.getState(), 'game.moveListCompleteData') || []).forEach((v, i) => {
            Object.entries(v).forEach(([key, obj]) => {
                if (obj.bestScore > 0 && obj.score >= obj.bestScore) {
                    if (key === get(store.getState(), 'game.pid')) {
                        myBestMoves = myBestMoves + 1;
                    } else {
                        oppBestMoves = oppBestMoves + 1;
                    }
                }
            });
        });
        return { myBestMoves, oppBestMoves };
    };

    static onShowViewStatsModal = async (hostedGame) => {
        let opponentGuid = LiveGamePlayUtils.getOpponentGuid(hostedGame) || store.getState().game.guid;
        if (store.getState().game.guid !== opponentGuid) {
            store.dispatch(addHostGameHeadToHeadStat());
        }
        store.dispatch(hostJoinDialog(hostedGame));

        let statsData = await getLiveGameStats([opponentGuid]);
        store.dispatch(hostJoinedPlayerStats(statsData));

        if (hostedGame.playerModal) {
            getUniqueWordsPlayedCount(hostedGame.playerItem.guid);
        }

        if (store.getState().game.guid !== opponentGuid) {
            getHostGamesHeadToHeadStats(hostedGame).then((res) =>
                store.dispatch(
                    addHostGameHeadToHeadStat(
                        res
                            ? {
                                  ...res,
                                  secret: get(hostedGame, 'secret'),
                              }
                            : res
                    )
                )
            );
        }

        if (LiveGamePlayUtils.isMultiplayerAcceptDialog(hostedGame)) {
            if (hostedGame.jndplys) {
                for (let i = 0; i < hostedGame.jndplys.length; i++) {
                    let jndply = await LiveGamePlayUtils.getAllPlayerDatasAndSet(hostedGame.jndplys[i]);
                    store.dispatch(joinHostedGame({ jndply }));
                }
            }
        } else if (
            !LiveGamePlayUtils.isMultiplayerAcceptDialog(hostedGame) ||
            LiveGamePlayUtils.isRated(hostedGame) ||
            LiveGamePlayUtils.isInviting(hostedGame)
        ) {
            let other = opponentGuid || get(hostedGame, 'sender.guid');
            if (other !== store.getState().game.guid) {
                checkRatingChange(other);
            }
        }
    };
}
