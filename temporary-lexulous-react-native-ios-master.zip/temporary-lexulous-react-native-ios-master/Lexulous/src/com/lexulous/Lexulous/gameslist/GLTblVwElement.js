// @flow

import React from 'react';
import { StyleSheet, Text, View, Image, Pressable, Share, ActivityIndicator, Platform } from 'react-native';
import type {
    GamesListElementViewData,
    GamesListGameData,
    GamesListItemData,
    ReviewShareData,
    ReviewShareUpdateData,
    ProfileInfo,
    AvatarWithNameData,
    AlertBoxType,
} from '../commons/RJTypes';

import { glUpdateReviewShareData, glClearReviewShareData } from '../gameslist/GLAction';
import * as CONSTANTS from '../commons/Constants';
import * as GL_CONSTANTS from './GLConstants';
import dataServer from '../store/Store';
import * as GamesListSelector from '../gameslist/GLSelector';
import AvatarWithName from '../components/AvatarWithName';
import userDefault from '../commons/UserDefault';
import { translate } from '../commons/translations/LangTransator';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronRight, faTrophyAlt, faComment } from '@fortawesome/pro-regular-svg-icons';
import { faStripeS } from '@fortawesome/free-brands-svg-icons';
import * as PFLSelector from '../userprofile/PFLSelector';
import soundManager from '../commons/SoundManager';
import interstitialAd from '../commons/ads/InterstitialAd';
import { handleException } from '../commons/RJUtils';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import appConfiguration from '../commons/AppConfiguration';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type GamesListElementStateType = {
    showActivityIndicator: boolean,
};

class GamesListElement extends React.Component<GamesListElementViewData, GamesListElementStateType> {
    constructor(props: GamesListElementViewData) {
        super(props);
        this.state = {
            showActivityIndicator: false,
        };
    }

    onShare = async (): Promise<void> => {
        let inviteFriend = Platform.select({
            native: async () => {
                let guid: ?string = PFLSelector.getGUID(dataServer.getStore().getState());
                if (guid !== null && guid !== undefined) {
                    let msg = CONSTANTS.statShareLink + guid;

                    try {
                        const result: { action: string } = await Share.share(
                            {
                                message: msg,
                            },
                            { title: translate('share_frnds_msg') }
                        );
                        if (result.action === Share.sharedAction) {
                            // shared with activity type of result.activityType
                        }
                    } catch (error) {
                        let alertBoxInfo: AlertBoxType = {
                            message: error.message,
                            actions: [
                                {
                                    text: translate('ok'),
                                    action: () => {
                                        dataServer.getStore().dispatch(clearAlert());
                                    },
                                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                                },
                            ],
                        };
                        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
                        handleException(error);
                    }
                }
            },
            default: () => {
                let invite: string | null = appConfiguration.getInvitePlugin();
                if (invite != null) {
                    let onCompletion = (error: Error | null, value: string | null): void => {
                        if (error != null) {
                            console.log('invite error :: ' + JSON.stringify(error));
                        } else if (value != null) {
                            console.log('invite success :: ' + value);
                        }
                    };
                    console.log('will call invite');
                    window[invite](onCompletion);
                } else {
                    console.log('invite is null');
                }
            },
        });
        inviteFriend();
    };

    lastPlayedTime = (tstmp: string): string => {
        let currdate = new Date();
        let lstplyddate = new Date(parseInt(tstmp) * 1000);
        let datediff = Math.abs(currdate - lstplyddate);
        let diffseconds = Math.ceil(datediff / 1000);
        let diffdays = Math.floor(diffseconds / (60 * 60 * 24));
        let lastplayedtime = '';
        if (diffdays > 0) {
            lastplayedtime = diffdays + translate('d_ago');
        } else {
            let hours = Math.floor(diffseconds / (60 * 60));
            if (hours > 0) {
                lastplayedtime = hours + translate('h_ago');
            } else {
                let minutes = Math.floor(diffseconds / 60);
                if (minutes > 0) {
                    lastplayedtime = minutes + translate('m_ago');
                } else {
                    lastplayedtime = diffseconds + translate('s_ago');
                }
            }
        }
        return lastplayedtime;
    };

    forfeitRemainingTime = (tstmplstplayed: string, fftdays?: string): string => {
        let currtstmp = Date.now() / 1000;
        let fftinsec = parseInt(fftdays !== null && fftdays !== undefined ? fftdays : '1') * 24 * 60 * 60;
        let gameexpirytime = parseInt(tstmplstplayed) + fftinsec;
        let remainingtime = '';
        if (gameexpirytime - currtstmp < 0) {
            remainingtime = '0' + translate('s_to_go');
        } else {
            let diffseconds = Math.abs(gameexpirytime - currtstmp);
            let diffdays = Math.round(diffseconds / (60 * 60 * 24));
            if (diffdays > 0) {
                remainingtime = diffdays + translate('d_to_go');
            } else {
                let hours = Math.round(diffseconds / (60 * 60));
                if (hours > 0) {
                    remainingtime = hours + translate('h_to_go');
                } else {
                    let minutes = Math.round(diffseconds / 60);
                    if (minutes > 0) {
                        remainingtime = minutes + translate('m_to_go');
                    } else {
                        remainingtime = diffseconds + translate('s_to_go');
                    }
                }
            }
        }
        return remainingtime;
    };

    getGameScoresDescription = (data: GamesListGameData, mypid: string): string => {
        let mdfmypid = parseInt(mypid) - 1;
        let scores = data.players.map((item) => item.score);
        let dd = scores.splice(mdfmypid, 1);
        scores.unshift(dd[0]);
        return scores.join('/');
    };

    renderIcons = (data: GamesListGameData, showOppName: boolean, color: string) => {
        let hasUnseenMsg = () => {
            let unseenMsg = data.unreadmsg;
            if (unseenMsg !== undefined && unseenMsg !== null && Number(unseenMsg) > 0) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faComment} size={18} color={'#1d9df1'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displayTrophy = () => {
            if (showOppName) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faTrophyAlt} size={18} color={'#E8BE76'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displaySuperIcon = () => {
            let isSuperLxlsGame: boolean = data.boardtype === 'S';
            if (isSuperLxlsGame) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faStripeS} size={18} color={'#E8BE76'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displayArrowOrIndicator = () => {
            if (this.state.showActivityIndicator) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 4,
                        }}
                    >
                        <ActivityIndicator size="small" color={color} />
                    </View>
                );
            } else {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronRight} size={22} color={color} />
                    </View>
                );
            }
        };

        return (
            <View style={[styles.iconContainer, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {displaySuperIcon()}
                {hasUnseenMsg()}
                {displayTrophy()}
                {displayArrowOrIndicator()}
            </View>
        );
    };

    renderArchivedGame(data: GamesListGameData, mypid: string, myguid: string, opppid: string, oppguid: string) {
        let imgicon = 1;
        let winnerpid = 1;
        let isdraw = false;
        if (data.winner !== null && data.winner != undefined) {
            winnerpid = data.winner[0];
            isdraw = data.winner.length > 1;
        }
        let mewinner = winnerpid === mypid;
        let showOppName = true;
        let winnerinfo = translate('you'); //used
        let playersinfo: { [string]: ProfileInfo } | null = GamesListSelector.getGLPlayersInfo(
            dataServer.getStore().getState(),
            data
        );
        let oppprofile = null;
        let oppname = '';
        if (playersinfo !== null) {
            oppprofile = playersinfo[oppguid];
            oppname = oppprofile.name;
        }
        //let oppprofile: ProfileInfo = this.props.playersinfo.oppguid;
        if (!mewinner) {
            if (oppprofile !== null && oppprofile.name !== undefined && oppprofile.name !== null) {
                winnerinfo = oppprofile.name;
                showOppName = false;
            }
        }

        let lostcolorcode = themeConfigutation.getColor('rgba(0, 0, 0, 0.54)');
        let woncolorcode = themeConfigutation.getColor('#28B463');
        let wonnamecolorcode = themeConfigutation.getColor('#000');

        let appliedwoncolorcode = woncolorcode;
        let appliedwonnamecolorcode = wonnamecolorcode;
        if (!mewinner) {
            appliedwoncolorcode = lostcolorcode;
            appliedwonnamecolorcode = lostcolorcode;
        }

        let won = '';
        if (isdraw) {
            winnerinfo = translate('won_tie');
        } else {
            won = translate('won');
            if (mewinner) {
                won = won + '!';
            }
        }

        let oppavtar = '1';
        if (oppprofile !== null && oppprofile.avtar !== null && oppprofile.avtar !== undefined) {
            oppavtar = oppprofile.avtar;
        }
        imgicon = CONSTANTS.avtarIcons[oppavtar]; //used
        let lastplayedtime = this.lastPlayedTime(data.lastupdate); //used
        let gamescore = this.getGameScoresDescription(data, mypid); //used

        let avtdata: AvatarWithNameData = {
            imgicon: imgicon,
            imgtxt: oppname,
        };

        return (
            <View style={[styles.sectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {/* <Image
                    source={imgicon}
                    style={{
                        width: 50,
                        height: 50,
                        backgroundColor: '#f4f3ef',
                        alignSelf: 'center',
                        marginRight: 8,
                    }}
                /> */}
                <Pressable
                    onPress={() => {
                        if (this.props.imageTapHandler !== null && this.props.imageTapHandler !== undefined) {
                            let handler = this.props.imageTapHandler;
                            soundManager.playSound(soundManager.RJSound.RJSoundClick);
                            interstitialAd.showInterstitialAd(true, () => {
                                handler(oppguid);
                            });
                        }
                    }}
                    style={[styles.imageBtnStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <AvatarWithName showOppName={showOppName} data={avtdata} />
                </Pressable>
                <Pressable
                    onPress={() => {
                        this.setState({ showActivityIndicator: true });
                        soundManager.playSound(soundManager.RJSound.RJSoundClick);
                        setTimeout(() => {
                            if (this.props.gameTapHandler !== null && this.props.gameTapHandler !== undefined) {
                                let handler = this.props.gameTapHandler;
                                interstitialAd.showInterstitialAd(true, () => {
                                    handler(this.props.game, this.hideActivityIndicator);
                                });
                            }
                        }, 0);
                    }}
                    style={[styles.contentStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <View>
                        <Text
                            numberOfLines={0}
                            style={{
                                fontSize: 18,
                                color: appliedwonnamecolorcode,
                            }}
                        >
                            {winnerinfo}
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: appliedwoncolorcode,
                                    fontSize: 16,
                                }}
                            >
                                {won}
                            </Text>
                        </Text>
                        <Text
                            numberOfLines={1}
                            style={{
                                color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                                fontSize: 14,
                            }}
                        >
                            {lastplayedtime + ', ' + gamescore}
                        </Text>
                    </View>
                    {this.renderIcons(data, showOppName, 'grey')}
                </Pressable>
            </View>
        );
    }

    hideActivityIndicator = (): void => {
        this.setState({ showActivityIndicator: false });
    };

    renderMyTurnGame(data: GamesListGameData, mypid: string, myguid: string, opppid: string, oppguid: string) {
        let imgicon = 1;
        let playersinfo: { [string]: ProfileInfo } | null = GamesListSelector.getGLPlayersInfo(
            dataServer.getStore().getState(),
            data
        );
        let oppprofile = null;
        if (playersinfo !== null) {
            oppprofile = playersinfo[oppguid];
        }
        let oppname = ''; //used
        if (oppprofile !== null && oppprofile.name !== undefined && oppprofile.name !== null) {
            oppname = oppprofile.name;
        }
        let oppavtar = '1';
        if (oppprofile !== null && oppprofile.avtar !== null && oppprofile.avtar !== undefined) {
            oppavtar = oppprofile.avtar;
        }
        imgicon = CONSTANTS.avtarIcons[oppavtar]; //used
        let lastplayedtime = this.forfeitRemainingTime(data.lastupdate, data.fftdays); //used
        let gamescore = this.getGameScoresDescription(data, mypid); //used
        let tilesleft = data.tilesinbag + ' tiles'; //used

        let lastmove = data.lastmove;
        let lastmoveopp = oppname; //used
        let lastmovewordscore = '';
        if (lastmove !== '') {
            lastmoveopp = lastmoveopp;
            let qq = lastmove.split(',');
            let word = qq[1];
            let score = qq[2];
            let mvtype = qq[3];
            if (mvtype === 'r') {
                lastmovewordscore = word + ' (' + score + ')';
            } else if (mvtype === 'p') {
                lastmovewordscore = translate('passed_turn') + ' (0)';
            } else if (mvtype === 's') {
                lastmovewordscore = translate('swappd_tiles') + ' (0)';
            } else if (mvtype === 'c') {
                lastmovewordscore = word + ' (' + score + ')';
            }
        }
        let avtdata: AvatarWithNameData = {
            imgicon: imgicon,
            imgtxt: oppname,
        };
        let dash = '';
        if (lastmovewordscore !== '') {
            dash = ' - ';
        }
        let isRecentlyUpdated = data.lts ?? false;
        return (
            <View style={[styles.sectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {/* <Image
                    source={imgicon}
                    style={{
                        width: 50,
                        height: 50,
                        backgroundColor: '#f4f3ef',
                        alignSelf: 'center',
                        marginRight: 8,
                    }}
                /> */}
                <Pressable
                    onPress={() => {
                        if (this.props.imageTapHandler !== null && this.props.imageTapHandler !== undefined) {
                            let handler = this.props.imageTapHandler;
                            soundManager.playSound(soundManager.RJSound.RJSoundClick);
                            interstitialAd.showInterstitialAd(true, () => {
                                handler(oppguid);
                            });
                        }
                    }}
                    style={[styles.imageBtnStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <AvatarWithName showOppName={false} data={avtdata} />
                </Pressable>

                <Pressable
                    onPress={() => {
                        this.setState({ showActivityIndicator: true });
                        soundManager.playSound(soundManager.RJSound.RJSoundClick);
                        setTimeout(() => {
                            if (this.props.gameTapHandler !== null && this.props.gameTapHandler !== undefined) {
                                let handler = this.props.gameTapHandler;
                                interstitialAd.showInterstitialAd(true, () => {
                                    handler(this.props.game, this.hideActivityIndicator);
                                });
                            }
                        }, 0);
                    }}
                    style={[styles.contentStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <View>
                        <Text
                            numberOfLines={0}
                            style={{
                                fontSize: 18,
                                color: isRecentlyUpdated ? 'red' : themeConfigutation.getColor('#000'),
                            }}
                        >
                            {lastmoveopp}
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: themeConfigutation.getColor('#000'),
                                    fontSize: 18,
                                }}
                            >
                                {dash}
                            </Text>
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: themeConfigutation.getColor('#28B463'),
                                    fontSize: 16,
                                }}
                            >
                                {lastmovewordscore}
                            </Text>
                        </Text>
                        <Text
                            numberOfLines={1}
                            style={{
                                color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                                fontSize: 14,
                            }}
                        >
                            {lastplayedtime + ',  ' + tilesleft + ',  ' + gamescore}
                        </Text>
                    </View>
                    {this.renderIcons(data, false, '#1d9df1')}
                </Pressable>
            </View>
        );
    }

    renderTheirTurnGame(data: GamesListGameData, mypid: string, myguid: string, opppid: string, oppguid: string) {
        let imgicon = 1;
        let playersinfo: { [string]: ProfileInfo } | null = GamesListSelector.getGLPlayersInfo(
            dataServer.getStore().getState(),
            data
        );
        let oppprofile = null;
        if (playersinfo !== null) {
            oppprofile = playersinfo[oppguid];
        }
        let oppname = ''; //used
        if (oppprofile !== null && oppprofile.name !== undefined && oppprofile.name !== null) {
            oppname = oppprofile.name;
        }

        let oppavtar = '1';
        if (oppprofile !== null && oppprofile.avtar !== null && oppprofile.avtar !== undefined) {
            oppavtar = oppprofile.avtar;
        }
        imgicon = CONSTANTS.avtarIcons[oppavtar]; //used
        let lastplayedtime = this.forfeitRemainingTime(data.lastupdate, data.fftdays); //used
        let gamescore = this.getGameScoresDescription(data, mypid); //used
        let tilesleft = data.tilesinbag + ' tiles'; //used

        let lastmove = data.lastmove;
        let lastmoveopp = oppname; //used
        let lastmovewordscore = '';
        if (mypid == opppid) {
            lastmoveopp = translate('you');
        }

        if (lastmove !== '') {
            lastmoveopp = lastmoveopp;
            let qq = lastmove.split(',');
            let word = qq[1];
            let score = qq[2];
            let mvtype = qq[3];
            if (mvtype === 'r') {
                lastmovewordscore = word + ' (' + score + ')';
            } else if (mvtype === 'p') {
                lastmovewordscore = translate('passed_turn') + ' (0)';
            } else if (mvtype === 's') {
                lastmovewordscore = translate('swappd_tiles') + ' (0)';
            } else if (mvtype === 'c') {
                lastmovewordscore = word + ' (' + score + ')';
            }
        }
        let avtdata: AvatarWithNameData = {
            imgicon: imgicon,
            imgtxt: oppname,
        };

        let dash = '';
        if (lastmovewordscore !== '') {
            dash = ' - ';
        }
        return (
            <View style={[styles.sectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {/* <Image
                    source={imgicon}
                    style={{
                        width: 50,
                        height: 50,
                        backgroundColor: '#f4f3ef',
                        alignSelf: 'center',
                        marginRight: 8,
                    }}
                /> */}
                <Pressable
                    onPress={() => {
                        if (this.props.imageTapHandler !== null && this.props.imageTapHandler !== undefined) {
                            let handler = this.props.imageTapHandler;
                            soundManager.playSound(soundManager.RJSound.RJSoundClick);
                            interstitialAd.showInterstitialAd(true, () => {
                                handler(oppguid);
                            });
                        }
                    }}
                    style={[styles.imageBtnStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <AvatarWithName showOppName={false} data={avtdata} />
                </Pressable>
                <Pressable
                    onPress={() => {
                        this.setState({ showActivityIndicator: true });
                        soundManager.playSound(soundManager.RJSound.RJSoundClick);
                        setTimeout(() => {
                            if (this.props.gameTapHandler !== null && this.props.gameTapHandler !== undefined) {
                                let handler = this.props.gameTapHandler;
                                interstitialAd.showInterstitialAd(true, () => {
                                    handler(this.props.game, this.hideActivityIndicator);
                                });
                            }
                        }, 0);
                    }}
                    style={[styles.contentStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <View>
                        <Text
                            numberOfLines={0}
                            style={{
                                fontSize: 18,
                                color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                            }}
                        >
                            {lastmoveopp}
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: themeConfigutation.getColor('#000'),
                                    fontSize: 18,
                                }}
                            >
                                {dash}
                            </Text>
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: themeConfigutation.getColor('#000'),
                                    fontSize: 16,
                                }}
                            >
                                {lastmovewordscore}
                            </Text>
                        </Text>
                        <Text
                            numberOfLines={1}
                            style={{
                                color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                                fontSize: 14,
                            }}
                        >
                            {lastplayedtime + ', ' + tilesleft + ', ' + gamescore}
                        </Text>
                    </View>
                    {this.renderIcons(data, false, 'grey')}
                </Pressable>
            </View>
        );
    }

    renderExtensionData(data: GamesListItemData) {
        let imgicon = '';
        let txtln1 = '';
        let txtln2 = '';
        if (data.key === 'playlive') {
            imgicon = require('../assets/icons/play_live.png');
            txtln1 = translate('play_live');
            txtln2 = translate('play_liveMsg');
        } else if (data.key === 'playoffline') {
            imgicon = require('../assets/icons/quickplay_home_icon.png');
            txtln1 = translate('play_offln');
            txtln2 = translate('play_offlnMsg');
        } else if (data.key === 'other_lex_player') {
            imgicon = require('../assets/icons/email_home_icon.png');
            txtln1 = translate('other_lex_player');
            txtln2 = translate('other_lex_playerMsg');
        } else if (data.key === 'analizegames') {
            imgicon = require('../assets/icons/gamelist_archives.png');
            txtln1 = translate('analz_game');
            txtln2 = translate('analz_gameMsg');
        } else if (data.key == 'blindGame') {
            imgicon = require('../assets/icons/plus_icon.png');
            txtln1 = 'Start a new game';
            txtln2 = 'Random game or play with anyone';
        } else {
            imgicon = require('../assets/icons/play_live.png');
        }

        return (
            <View style={[styles.extContainerStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                <Image
                    source={imgicon}
                    style={[styles.imgStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                />
                <View style={[styles.extSectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Text
                        numberOfLines={0}
                        style={{
                            fontSize: 16,
                            color: themeConfigutation.getColor('#000'),
                        }}
                    >
                        {txtln1}
                    </Text>
                    <Text
                        numberOfLines={1}
                        style={{
                            color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                            fontSize: 14,
                        }}
                    >
                        {txtln2}
                    </Text>
                </View>
            </View>
        );
    }

    renderGameData(data: GamesListGameData) {
        let isarchivedgame = false;
        if (data.gameover_reason !== null && data.gameover_reason !== undefined) {
            isarchivedgame = data.gameover_reason;
        }
        let guid: string = CONSTANTS.Default_guid;
        let oppguid: string = CONSTANTS.Default_guid;
        let profile: ProfileInfo = GamesListSelector.getMyProfile(dataServer.getStore().getState());
        if (profile.guid !== undefined && profile.guid !== null) {
            guid = profile.guid;
        }
        let me = data.players.find((element) => element.uid === guid);
        let ismyturn = false;
        let mypid = '1';
        if (me !== undefined && me !== null) {
            mypid = me.pid;
            ismyturn = mypid === data.turnpid;
        }

        let totalplayer = data.players.length;
        let lastmove = data.lastmove;
        let oppidx = 0; //index 0 based
        let myidx = parseInt(mypid) - 1;
        if (isarchivedgame) {
            oppidx = myidx - 1;
        } else if (lastmove !== '') {
            let qq = lastmove.split(',');
            oppidx = parseInt(qq[0]) - 1;
            if (myidx === oppidx) {
                oppidx = myidx - 1;
            }
        } else {
            oppidx = myidx - 1;
        }

        if (oppidx < 0) {
            oppidx = totalplayer - 1;
        }
        oppguid = data.players[oppidx].uid;
        let opppid = (oppidx + 1).toString();
        if (isarchivedgame) {
            return this.renderArchivedGame(data, mypid, guid, opppid, oppguid);
        } else if (ismyturn) {
            return this.renderMyTurnGame(data, mypid, guid, opppid, oppguid);
        } else {
            return this.renderTheirTurnGame(data, mypid, guid, opppid, oppguid);
        }
    }

    // renderGameData(data: GamesListGameData) {
    //     return (
    //         <View
    //             style={{
    //                 flex: 1,
    //                 paddingHorizontal: 8,
    //                 paddingVertical: 8,
    //                 backgroundColor: '#f4f3ef',
    //                 flexDirection: 'row',
    //             }}
    //         >
    //             <Text
    //                 numberOfLines={0}
    //                 style={{
    //                     marginBottom: 1,
    //                     fontSize: 16,
    //                     color: 'black',
    //                 }}
    //             >
    //                 {data.gid}
    //             </Text>
    //         </View>
    //     );
    // }

    renderReviewShareData(data: ReviewShareData) {
        let hdrtxt = '';
        let btnnegtxt = '';
        let btnpositivetext = '';

        switch (data.reviewsharestate) {
            case GL_CONSTANTS.reviewShareStateType.ReviewViewStateInited: {
                hdrtxt = translate('enj_lxls');
                btnnegtxt = translate('not_rly');
                btnpositivetext = translate('yes');
                break;
            }
            case GL_CONSTANTS.reviewShareStateType.ReviewViewStateFeedback: {
                hdrtxt = translate('fdbck_ques');
                btnnegtxt = translate('no_thnx');
                btnpositivetext = translate('ok_sure');
                break;
            }
            case GL_CONSTANTS.reviewShareStateType.ReviewViewStateAppstoreReview: {
                hdrtxt = translate('rating_ques');
                btnnegtxt = translate('no_thnx');
                btnpositivetext = translate('ok_sure');
                break;
            }
            case GL_CONSTANTS.reviewShareStateType.ShareViewStateInited: {
                hdrtxt = translate('compete_ques');
                btnnegtxt = translate('not_rly');
                btnpositivetext = translate('yes');
                break;
            }
            case GL_CONSTANTS.reviewShareStateType.ShareViewStateInvite: {
                hdrtxt = translate('inviting_ques');
                btnnegtxt = translate('no_thnx');
                btnpositivetext = translate('ok_sure');
                break;
            }
        }

        return (
            <View style={[styles.rvwShareContainer, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                <View style={[styles.rvwSharetxt, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Text style={{ color: themeConfigutation.getColor('#000') }}>{hdrtxt}</Text>
                </View>

                <View style={[styles.rvwShrSection, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Pressable
                        style={styles.negativebtn}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('review_share_negative_btn_press', 'gltbl_vw_element');
                            this.negativeBtnTapped(data.reviewsharestate);
                        }}
                    >
                        <Text style={styles.negativebtntext}>{btnnegtxt}</Text>
                    </Pressable>
                    <Pressable
                        style={styles.positivebtn}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('review_share_positive_btn_press', 'gltbl_vw_element');
                            this.positiveBtnTapped(data.reviewsharestate);
                        }}
                    >
                        <Text style={styles.positivebtntext}>{btnpositivetext}</Text>
                    </Pressable>
                </View>
            </View>
        );
    }

    negativeBtnTapped(data: number) {
        let temp = GL_CONSTANTS.reviewShareStateType.ReviewShareStateUnknown;
        let type = 'review';
        if (
            data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInited ||
            data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInvite
        ) {
            type = 'share';
        }

        if (data == GL_CONSTANTS.reviewShareStateType.ReviewViewStateInited) {
            temp = GL_CONSTANTS.reviewShareStateType.ReviewViewStateFeedback;
        }

        if (temp == GL_CONSTANTS.reviewShareStateType.ReviewViewStateFeedback) {
            let uu: ReviewShareUpdateData = {
                type: 'review',
                show: true,
                reviewsharestate: temp,
            };
            dataServer.getStore().dispatch(glUpdateReviewShareData(uu));
        } else {
            if (type == 'review') {
                userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(Number.MAX_SAFE_INTEGER));
            } else if (type == 'share') {
                userDefault.set(CONSTANTS.kPsistShrTrgCnt, JSON.stringify(1));
                userDefault.set(CONSTANTS.kPsistShrAtCnt, JSON.stringify(CONSTANTS.kExtendedShareTrgCnt));
            }
            dataServer.getStore().dispatch(glClearReviewShareData());
        }
    }

    positiveBtnTapped(data: number) {
        let temp = GL_CONSTANTS.reviewShareStateType.ReviewShareStateUnknown;
        let type = 'review';
        if (
            data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInited ||
            data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInvite
        ) {
            type = 'share';
        }
        if (data == GL_CONSTANTS.reviewShareStateType.ReviewViewStateInited) {
            temp = GL_CONSTANTS.reviewShareStateType.ReviewViewStateAppstoreReview;
        } else if (data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInited) {
            temp = GL_CONSTANTS.reviewShareStateType.ShareViewStateInvite;
        }
        if (temp !== GL_CONSTANTS.reviewShareStateType.ReviewShareStateUnknown) {
            let uu: ReviewShareUpdateData = {
                type: type,
                show: true,
                reviewsharestate: temp,
            };
            dataServer.getStore().dispatch(glUpdateReviewShareData(uu));
        } else {
            if (data == GL_CONSTANTS.reviewShareStateType.ReviewViewStateAppstoreReview) {
                //show appstore review here
                userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(Number.MAX_SAFE_INTEGER));
            } else if (data == GL_CONSTANTS.reviewShareStateType.ShareViewStateInvite) {
                //show friend invite here
                this.onShare();
                userDefault.set(CONSTANTS.kPsistShrTrgCnt, JSON.stringify(1));
                userDefault.set(CONSTANTS.kPsistShrAtCnt, JSON.stringify(CONSTANTS.kExtendedShareTrgCnt));
            }
            dataServer.getStore().dispatch(glClearReviewShareData());
        }
    }

    render() {
        let type = this.props.game.type;
        if (type === 'game') {
            let data: GamesListGameData = ((this.props.game.data: any): GamesListGameData);
            return this.renderGameData(data);
        } else if (type === 'extension') {
            let data: GamesListItemData = this.props.game;
            return this.renderExtensionData(data);
        } else if (type === 'review' || type === 'share') {
            let data: ReviewShareData = ((this.props.game.data: any): ReviewShareData);
            return this.renderReviewShareData(data);
        } else {
            return null;
        }
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    negativebtn: {
        backgroundColor: '#808e9b',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#fff',
    },
    negativebtntext: {
        color: '#FFFFFF',
        textAlign: 'center',
        paddingHorizontal: 16,
        paddingVertical: 10,
        textDecorationLine: 'underline',
    },
    positivebtn: {
        backgroundColor: '#1d9df1',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#fff',
    },
    positivebtntext: {
        color: '#FFFFFF',
        textAlign: 'center',
        paddingHorizontal: 16,
        paddingVertical: 10,
        textDecorationLine: 'underline',
    },
    sectionStyle: {
        flex: 1,
        paddingLeft: 10,
        paddingRight: 10,
        paddingVertical: 4,
        flexDirection: 'row',
    },
    iconContainer: {
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    imageBtnStyle: {
        width: 28,
        height: 28,
        alignSelf: 'center',
        marginRight: 8,
    },
    contentStyle: {
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    extContainerStyle: {
        flex: 1,
        paddingHorizontal: 10,
        paddingVertical: 4,
        flexDirection: 'row',
    },
    imgStyle: {
        width: 30,
        height: 30,
        alignSelf: 'center',
        marginRight: 8,
    },
    extSectionStyle: {
        flexGrow: 1,
        justifyContent: 'center',
    },
    rvwShareContainer: {
        flex: 1,
        flexDirection: 'column',
        paddingVertical: 12,
    },
    rvwSharetxt: {
        justifyContent: 'center',
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 8,
    },
    rvwShrSection: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        paddingVertical: 8,
    },
});

export default GamesListElement;
