// @flow

import { createStore, combineReducers } from 'redux';
import type { ActionBusy, ActionFree } from '../commons/RJTypes';
import PFLReducer from '../userprofile/PFLReducer';
import PFLSettingsReducer from '../userprofile/PFLSettingsReducer';
import PFLVwReducer from '../profileview/PFLVwReducer';
import GLReducer from '../gameslist/GLReducer';
import FndReducer from '../friends/FndReducer';
import LNRReducer from '../loginNregister/LNRReducer';
import MinStatsReducer from '../stats/minimalstats/MinStatsReducer';
import BusyReducer from '../commons/BusyReducer';
import UtilsReducer from '../commons/UtilsReducer';
import PopupReducer from '../reducers/popupreducer/PopupReducer';
import debounce from 'lodash/debounce';
import { Platform } from 'react-native';

import type {
    ProfileInfo,
    FBLoginInfo,
    GGLLoginInfo,
    LXLSLoginInfo,
    AppleLoginInfo,
    GamesListSectionData,
} from '../commons/RJTypes';
import store from '../../../../store';

const rootReducer = combineReducers({
    profile: PFLReducer,
    profileVw: PFLVwReducer,
    gamesList: GLReducer,
    friends: FndReducer,
    lnrVw: LNRReducer,
    minStats: MinStatsReducer,
    busyIndicator: BusyReducer,
    profileSettings: PFLSettingsReducer,
    utils: UtilsReducer,
    popups: PopupReducer,
});

class DataServer {
    _store: any = null;

    constructor() {
        this._store = store; // configureStore();
    }

    getStore = () => {
        return this._store;
    };

    getGUID = (): string | null => {
        return this._store.getState().profile?.guid ?? null;
    };

    getUUID = (): string | null => {
        return this._store.getState().profile?.uuid ?? null;
    };

    getProfile = (): ProfileInfo => this._store.getState().profile;

    getFbLoginInfo = (): FBLoginInfo | null => {
        return this._store.getState().profileVw?.fbLoginInfo ?? null;
    };

    getLxlsLoginInfo = (): LXLSLoginInfo | null => {
        return this._store.getState().profileVw?.lxlsLoginInfo ?? null;
    };

    getAppleLoginInfo = (): AppleLoginInfo | null => {
        return this._store.getState().profileVw?.appleLoginInfo ?? null;
    };

    getGGLLoginInfo = (): GGLLoginInfo | null => {
        return this._store.getState().profileVw?.gglLoginInfo ?? null;
    };

    hasActiveGames = (): boolean => {
        let games: Array<GamesListSectionData> = this._store.getState().gamesList.games;
        return games.length > 0;
    };

    getSoundSettings = (): boolean => {
        let sound_enabled = this._store.getState()?.profileSettings.us_gameplay.gp_gamesounds ?? null;
        return sound_enabled === 'y';
    };

    isProUser = (): boolean => {
        let protill = this._store.getState()?.profileSettings.us_prouser.pro_till ?? null;
        if (protill == null) {
            return false;
        } else {
            let currenttstmp = new Date().getTime() / 1000;
            protill = parseInt(protill);
            return protill > currenttstmp;
        }
    };

    setBusy = (action: ActionBusy | ActionFree) => {
        dataServer.getStore().dispatch(action);
    };

    debouncediOSDispatch = debounce((action) => this.setBusy(action), 500);

    debouncedDispatch = (action: ActionBusy | ActionFree) => {
        if (Platform.OS == 'ios') {
            this.debouncediOSDispatch(action);
        } else {
            this.setBusy(action);
        }
    };
}

const configureStore = () => {
    return createStore(rootReducer);
};

const dataServer = new DataServer();

export default dataServer;
