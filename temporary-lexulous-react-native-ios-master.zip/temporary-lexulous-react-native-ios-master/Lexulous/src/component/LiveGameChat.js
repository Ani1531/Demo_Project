import React from 'react';
import { FlatList, StyleSheet, View, TouchableOpacity, TextInput } from 'react-native';
import Config from '../configs/Config';
import { sendMessage } from '../service/GamePlayService';
import get from 'lodash/get';
import ColorConfig from '../configs/ColorConfig';
import SoundUtils from '../utils/SoundUtils';
import { getEventKeyCode } from '../utils/Utils';
import ChatListItem from './ChatListItem';
import { connect } from 'react-redux';
import { lobbyChatSendMessage } from '../service/LiveGamePlayService';
import {
    CELL_REDUCER_CLEAR_DIRECTION,
    CHAT_APPEND_LIST_ITEM,
    CONFIG_SET_SETTING,
    LOBBY_CHAT_MESSAGE,
} from '../configs/ActionIdentifiers';
import isEqual from 'lodash/isEqual';
import S10Text from './S10Text';
import S14Text from './S14Text';
import SettingsUtil from '../utils/SettingsUtil';
import { faTextSize, faCopy } from '@fortawesome/pro-regular-svg-icons';
import TooltipWrapper from './TooltipWrapper';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import Clipboard from '@react-native-clipboard/clipboard';
import cloneDeep from 'lodash/cloneDeep';
import { createDialogInstance } from '../utils/MessageUtils';
import ServiceWrapper from '../utils/ServiceWrapper';
import EventWrapper from '../utils/EventWrapper';
import { faPaperPlane } from '@fortawesome/free-solid-svg-icons';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';

require('format-unicorn');
const eventBus = require('js-event-bus')();

function bindFunction() {
    this.bindRequest(this.params);
}

class LiveGameChat extends React.Component {
    state = {
        sendMessageByEnter: false,
        totalMessageHeight: 0,
        allowFileUpload: true,
        isAnimated: false,
        showOverlay: false,
        chatTextInputHeight: 20,
        doNotShowScamAlert: ServiceWrapper.getLocalStorage(Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_ALERT),
        doNotShowScamLobbyAlert: ServiceWrapper.getLocalStorage(Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_LOBBY_ALERT),
        fontToolTip: false,
    };

    constructor(props) {
        super(props);
        this.textInputRef = React.createRef();
        this.flatListRef = React.createRef();
        if (!!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isDesktopApp')) {
            ServiceWrapper.getDeskChatScamAlertStatus(this.props.isLobbyChat, (data) => {
                if (data) {
                    let obj = this.props.isLobbyChat
                        ? { doNotShowScamLobbyAlert: data.lobbyChatScamAlert }
                        : { doNotShowScamAlert: data.chatScamAlert };
                    this.setState(obj);
                }
            });
        }
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return (
            (this.props.isLobbyChat &&
                (this.props.pvtMessageKey
                    ? !isEqual(
                          get(this.props, 'lobbyChat.pvtMessages.' + this.props.pvtMessageKey + '.messages'),
                          get(nextProps, 'lobbyChat.pvtMessages.' + this.props.pvtMessageKey + '.messages')
                      )
                    : !isEqual(get(this.props, 'lobbyChat.messages'), get(nextProps, 'lobbyChat.messages')))) ||
            (!this.props.isLobbyChat && !isEqual(get(this.props, 'chat.messages'), get(nextProps, 'chat.messages'))) ||
            !isEqual(get(this.props, 'height'), get(nextProps, 'height')) ||
            !isEqual(get(nextState, 'typing'), get(this.state, 'typing')) ||
            !isEqual(get(this.props, 'pvtMessageKey'), get(nextProps, 'pvtMessageKey')) ||
            !isEqual(get(this.props, 'width'), get(nextProps, 'width')) ||
            !isEqual(
                get(nextState, Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_ALERT),
                get(this.state, Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_ALERT)
            ) ||
            !isEqual(
                get(nextState, Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_LOBBY_ALERT),
                get(this.state, Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_LOBBY_ALERT)
            ) ||
            !isEqual(get(this.props, 'config.gp_chtfntsze'), get(nextProps, 'config.gp_chtfntsze')) ||
            !isEqual(get(this.state, 'fontToolTip'), get(nextState, 'fontToolTip'))
        );
    };

    componentDidMount = () => {
        this._scrollNode = this.flatListRef.current.getScrollableNode();
        EventWrapper.addScrollInvertListener(this._scrollNode);

        if (
            get(this.props, 'game.tabWasSetByClicking') &&
            get(this.props, 'game.gameBoardSideLayoutActiveTab') === 0 &&
            !this.props.isLobbyChat
        ) {
            this.textInputRef.current.focus();
        }
    };

    findOpponentName = (guid) => {
        let opponents = (this.props.game.players || []).filter((player) => player.guid !== this.props.game.guid) || [];
        let opponent = opponents.find((opponent) => opponent.guid === guid);
        return get(opponent, 'name');
    };

    onKeyDown = (event) => {
        event.stopPropagation();
        let code = getEventKeyCode(event);
        if (code && code.includes('Enter')) {
            event.preventDefault();
            this.setState({ sendMessageByEnter: true });
            this.sendMessage();
        }
    };

    componentWillUnmount = () => {
        EventWrapper.removeScrollInvertListener();
    };

    onMessageSent = (message) => {
        SoundUtils.messageSound();
        this.setState({
            typing: '',
            showOverlay: false,
            chatTextInputHeight: 20,
        });
        eventBus.emit(this.props.isLobbyChat ? LOBBY_CHAT_MESSAGE : CHAT_APPEND_LIST_ITEM, null, message);
        if (!this.props.isLobbyChat) {
            let data = {
                gid: this.props.game.gid,
                action: 'chat',
            };
            ServiceWrapper.notifyContextStore(data);
        }
    };

    getChatPanelDimen = () => ({
        flex: 1,
    });

    getChatPanelRealDimen = () => ({
        width: this.props.width,
    });

    getSendButtonDimensionStyles = () => ({
        height: this.props.layout.layoutButtonStyles.height,
        width: this.props.layout.layoutButtonStyles.width,
    });

    getSendButtonFontSizeStyles = () => ({
        fontSize: this.props.layout.layoutButtonStyles.fontSize,
    });

    getUploadButtonDimensionStyles = () => ({
        height: this.props.layout.layoutButtonStyles.height,
        width: this.props.layout.layoutButtonStyles.height,
    });

    getIconStyleObj = () => ({
        fontSize: get(this.props, 'layout.layoutFontAwesomeIconSize'),
        color: ColorConfig.CHAT_BOX_SEND_BUTTON_TEXT_COLOR,
    });

    getChatIconStyleObj = () => ({
        height: 16,
        width: 16,
        marginRight: 8,
    });

    focusTextField = () => this.textInputRef.current && this.textInputRef.current.focus();

    getLobbyMessages = () =>
        this.props.pvtMessageKey
            ? this.props.lobbyChat.pvtMessages[this.props.pvtMessageKey].messages
            : this.props.lobbyChat.messages;

    onFocus = () => eventBus.emit(CELL_REDUCER_CLEAR_DIRECTION);

    sendSortMessage = (message) => this.setState({ typing: message }, this.sendMessage);

    renderSortMessageView = () =>
        !this.props.isLobbyChat && this.state.doNotShowScamAlert ? (
            <View style={{ flexDirection: 'row' }}>
                {Config.CHAT_SHORT_MESSAGES.map((message) => (
                    <TouchableOpacity
                        activeOpacity={0.7}
                        onPress={bindFunction.bind({
                            params: message,
                            bindRequest: this.sendSortMessage,
                        })}
                        style={styles.sortMessageContainer}
                    >
                        <S10Text style={styles.sortMessageText}>{message}</S10Text>
                    </TouchableOpacity>
                ))}
            </View>
        ) : null;

    renderScamAlertView = () =>
        (this.props.isLobbyChat && !this.state.doNotShowScamLobbyAlert) ||
        (!this.props.isLobbyChat && !this.state.doNotShowScamAlert) ? (
            <TouchableOpacity activeOpacity={1} style={styles.scamMessageContainer} onPress={this.onDoNotShowScamAlert}>
                {this.props.isLobbyChat ? (
                    <S14Text style={styles.scamMessageTextColor}>
                        {'Avoid sharing personal information with strangers. Click here to hide this message.'}
                    </S14Text>
                ) : (
                    <S10Text style={styles.scamMessageTextColor}>
                        {'Avoid sharing personal information with strangers. Click here to hide this message.'}
                    </S10Text>
                )}
            </TouchableOpacity>
        ) : null;

    onDoNotShowScamAlert = () => {
        if (!!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isDesktopApp')) {
            ServiceWrapper.setDeskChatScamAlertStatus(this.props.isLobbyChat);
        } else {
            ServiceWrapper.setLocalStorage(
                this.props.isLobbyChat
                    ? Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_LOBBY_ALERT
                    : Config.LOCAL_STORAGE_DO_NOT_SHOW_SCAM_ALERT,
                true
            );
        }
        this.setState(this.props.isLobbyChat ? { doNotShowScamLobbyAlert: true } : { doNotShowScamAlert: true });
    };

    componentDidUpdate() {
        TooltipActionWrapper.rebuild();
    }

    render = () => {
        return (
            <View
                style={[
                    styles.mainView,
                    this.getChatPanelDimen(),
                    this.getFlatListStyles(),
                    {
                        flexDirection: 'column-reverse',
                    },
                ]}
            >
                <View>
                    {this.renderScamAlertView()}
                    {this.renderSortMessageView()}
                    <View style={[styles.chatBox]}>
                        <TouchableOpacity onPress={this.state.chatIconEnable ? this.stayFocusSendMessage : null}>
                            <FontAwesomeIcon
                                icon={faPaperPlane}
                                size={16}
                                color={
                                    this.state.chatIconEnable ? '#3484F0' : ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR_DISABLED
                                }
                                style={this.getChatIconStyleObj()}
                            />
                        </TouchableOpacity>

                        <TextInput
                            multiline={true}
                            value={this.state.typing}
                            onChangeText={this.onChangeTextInput}
                            ref={this.textInputRef}
                            textAlignVertical="center"
                            onContentSizeChange={(event) =>
                                this.setState({
                                    chatTextInputHeight: event.nativeEvent.contentSize.height,
                                })
                            }
                            onFocus={this.onFocus}
                            maxLines={250}
                            maxLength={Config.LIVE_GAME_CHAT_CHARACTER_LIMIT}
                            style={[styles.textInputAndPlaceholderContainer, this.getChatInputTextHeight()]}
                            onKeyPress={this.onKeyDown}
                            autoComplete={'off'}
                            autoCompleteType={'off'}
                        />
                        {!this.props.isLobbyChat && this.state.showOverlay ? (
                            <View style={[StyleSheet.absoluteFill, styles.overlayContainer]} />
                        ) : null}
                    </View>
                </View>
                <FlatList
                    ref={this.flatListRef}
                    data={this.props.isLobbyChat ? this.getLobbyMessages() : this.props.chat.messages}
                    renderItem={this.renderItem}
                    keyExtractor={(item) => String(get(item, 'id'))}
                    className={'appFlatList'}
                    inverted
                    initialNumToRender={
                        (
                            (this.props.isLobbyChat
                                ? this.props.pvtMessageKey
                                    ? this.props.lobbyChat.pvtMessages[this.props.pvtMessageKey]
                                    : this.props.lobbyChat.messages
                                : this.props.chat.messages) || []
                        ).length
                    }
                    showsVerticalScrollIndicator={true}
                    style={{
                        flex: 1,
                    }}
                />
                {!this.props.isLobbyChat && (
                    <View style={styles.chatFontSizeChangeButton}>
                        <TooltipWrapper
                            tooltip={'Copy Conversation'}
                            onPress={this.copyMessages}
                            onMouseOver={this.onFontButtonHoverIn}
                            onMouseOut={this.onFontButtonHoverOut}
                        >
                            <FontAwesomeIcon key={'copy-conversion'} icon={faCopy} size={18} />
                        </TooltipWrapper>
                        <TooltipWrapper
                            style={{ marginLeft: 8 }}
                            tooltip={'Change Font Size'}
                            onPress={this.fontSizeUpdateSetting}
                            onMouseOver={this.onFontButtonHoverIn}
                            onMouseOut={this.onFontButtonHoverOut}
                        >
                            <FontAwesomeIcon key={'font-size-update'} icon={faTextSize} size={18} />
                        </TooltipWrapper>
                    </View>
                )}
            </View>
        );
    };

    onFontButtonHoverIn = () => this.setState({ fontToolTip: true });
    onFontButtonHoverOut = () => this.setState({ fontToolTip: false });

    copyMessages = () => {
        let chatMessages = '';
        let messages = cloneDeep(this.props.isLobbyChat ? this.getLobbyMessages() : this.props.chat.messages);
        (messages || []).reverse().forEach((element) => {
            let messageUserName = this.getUserName(element);
            let message = element.message.msg;
            let time = element.message.copyFormattedTime;
            chatMessages = chatMessages.concat(time + ' UTC / ' + messageUserName + ' / ' + message + '\n');
            Clipboard.setString(chatMessages);
            createDialogInstance({
                title: 'Conversation Copied',
                actionButtonText: 'OK',
                onAction: () => null,
                body: 'This coversation is copied to your device clipboard, you may paste it as required.',
            });
        });
    };

    fontSizeUpdateSetting = () => {
        let fontSize = Number(this.props.config.gp_chtfntsze);
        let obj = {
            gp_chtfntsze: fontSize >= 18 ? 10 : fontSize + 2,
        };
        eventBus.emit(CONFIG_SET_SETTING, null, obj);
        SettingsUtil.sendSetting(obj);
    };

    onChangeTextInput = (typing) => {
        let chatIconEnable = false;
        if (typing.length > 0) {
            chatIconEnable = true;
        } else {
            this.setState({ chatTextInputHeight: 20 });
        }
        this.setState({ typing, chatIconEnable });
    };

    getChatInputTextHeight = () => ({
        height: this.state.chatTextInputHeight,
    });

    getFlatListStyles = () => ({
        backgroundColor: '#f4f3ef',
    });

    stayFocusSendMessage = () => {
        this.focusTextField();
        this.sendMessage();
    };

    isBlockedMsg = (msgText) => {
        let mgsArray = msgText.split(Config.URL_REGEX);
        const regex = new RegExp(Config.URL_REGEX);
        let hasBlockedMsg = false;
        mgsArray.map((element) => {
            if (regex.test(element) && element.includes('scrabble')) {
                hasBlockedMsg = true;
            }
        });
        return hasBlockedMsg;
    };

    sendMessage = async () => {
        let messageText = this.state.typing;
        if (!messageText) return;
        if (this.isBlockedMsg(messageText)) {
            this.setState({
                typing: '',
                showOverlay: false,
                chatTextInputHeight: 20,
            });
            return;
        }
        this.setState({
            chatIconEnable: false,
            showOverlay: true,
        });
        let messageInfo = null;
        if (this.props.isLobbyChat) {
            let receiver = this.props.pvtMessageKey ? [this.props.pvtMessageKey] : undefined;
            lobbyChatSendMessage(messageText, receiver);
            messageInfo = {
                data: {
                    sender: this.props.game.guid,
                    message: messageText,
                    type: this.props.pvtMessageKey
                        ? Config.LOBBY_CHAT_MESSAGE_TYPE_PRIVATE
                        : Config.LOBBY_CHAT_MESSAGE_TYPE_NORMAL,
                    pvtMessageKey: this.props.pvtMessageKey,
                },
            };
        } else {
            messageInfo = {
                message: {
                    sender: this.props.game.pid,
                    msg: messageText,
                    time: Math.round(Date.now() / 1000),
                },
                direction: 'outgoing',
                id: Date.now(),
            };
            sendMessage(messageText);
        }
        this.onMessageSent(messageInfo);
    };

    getImageChatItemMaxWidth = () => ({
        width: this.getChatPanelRealDimen().width * 0.8,
    });

    getChatItemMaxWidth = () => ({
        maxWidth: this.getChatPanelRealDimen().width * 0.8,
    });

    getUserName = (item) => {
        if (this.props.isLobbyChat) {
            return get(item, 'username');
        } else {
            return get(
                (this.props.game.players || []).find((p) => get(p, 'pid') === get(item, 'message.sender')),
                'name'
            );
        }
    };

    getChatFontSizeStyle = () => ({
        fontSize: Number(this.props.config.gp_chtfntsze),
    });

    renderGeneralAnnounce = (general_announce) => (
        <View style={styles.generalAnnounceStyle}>
            <S10Text style={[styles.generalAnnounceTextStyle, this.getChatFontSizeStyle()]}>{general_announce}</S10Text>
        </View>
    );

    renderItem = ({ item, index }) =>
        get(item, 'general_announce') ? (
            this.renderGeneralAnnounce(get(item, 'general_announce'))
        ) : (
            <ChatListItem
                isLobbyChat={this.props.isLobbyChat}
                isMultiplayerGame={this.props.game.players && this.props.game.players.length > 2}
                avatarUrl={this.props.config['avatar_url_format'].formatUnicorn({ id: get(item, 'avtar') })}
                messageUserName={this.getUserName(item)}
                getImageChatItemMaxWidth={this.getImageChatItemMaxWidth}
                index={index}
                isImage={
                    !!get(item, 'message.msg') &&
                    get(item, 'message.msg').startsWith('**') &&
                    get(item, 'message.msg').endsWith('**')
                }
                item={item}
                isMyself={get(item, 'message.sender') === get(this.props, 'game.guid')}
                //"TypeError: Cannot read property 'formatUnicorn' of undefined" error found
                //at "https://staging.rjs.in/abhijit/lexulouscom/php/live/beta"
                imageBucketUrl={
                    this.props.config.image_bucket_url
                        ? this.props.config.image_bucket_url.formatUnicorn(
                              {
                                  filename: get(item, 'message.msg').slice(2, -2),
                              },
                              true
                          )
                        : undefined
                }
                getChatItemMaxWidth={this.getChatItemMaxWidth}
                chatFontSize={Number(this.props.config.gp_chtfntsze)}
                width={this.props.width}
            />
        );
}

const styles = StyleSheet.create({
    mainView: {
        flexDirection: 'column',
        borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderLeftColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderRightColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderBottomColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        backgroundColor: ColorConfig.TRANSPARENT,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    },
    chatBox: {
        flexDirection: 'row-reverse',
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: ColorConfig.CHAT_BOX_BACKGROUND_COLOR,
        overflow: 'hidden',
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        width: '100%',
    },

    message: {
        backgroundColor: '#FFF',
        padding: 5,
        borderWidth: 1,
        borderColor: '#ccc',
    },
    sendButtonText: {
        color: ColorConfig.CHAT_BOX_SEND_BUTTON_TEXT_COLOR,
        fontWeight: 'bold',
    },
    flatList: {
        flex: 4,
    },
    textInputAndPlaceholderContainer: {
        flex: 1,
        color: '#000',
        margin: 6,
        borderColor: ColorConfig.CHAT_BOX_TEXT_INPUT_BORDER_COLOR,
    },
    generalAnnounceStyle: {
        alignSelf: 'center',
        margin: 5,
    },
    generalAnnounceTextStyle: {
        color: ColorConfig.BUTTON_TEXT_COLOR,
    },
    transparentColor: {
        backgroundColor: 'transparent',
    },
    overlayContainer: {
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        overflow: 'hidden',
    },
    sortMessageContainer: {
        marginLeft: 8,
        paddingHorizontal: 8,
        paddingVertical: 4,
        backgroundColor: '#fafafa',
        borderTopWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: '#d2d2d2',
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    sortMessageText: {
        color: ColorConfig.LIGHT_BLACK_TEXT,
    },
    scamMessageContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 8,
        backgroundColor: ColorConfig.NEW_GAME_BUTTON_COLOR,
    },
    scamMessageTextColor: {
        color: ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR,
    },
    chatFontSizeChangeButton: {
        position: 'absolute',
        right: 8,
        top: 8,
        flexDirection: 'row',
    },
});

const mapStateToProps = (state) => ({
    chat: state.chat,
    lobbyChat: state.lobbyChat,
    layout: state.layout,
    game: state.game,
    config: state.config,
});

export default connect(mapStateToProps, null, null, { forwardRef: true })(LiveGameChat);
