import React from 'react';

export default class ReactCustomTooltip extends React.PureComponent {
    render = () => null;
}
