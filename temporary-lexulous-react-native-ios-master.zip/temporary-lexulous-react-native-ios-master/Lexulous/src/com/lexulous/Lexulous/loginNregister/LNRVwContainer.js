// @flow

import * as React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { TextInput, View, StyleSheet, Text, Pressable, Image } from 'react-native';
import type { NavigationProp, RouteProp } from '@react-navigation/native';
import type {
    LNRVwProps,
    LNRVwState,
    LNRResponse,
    LXLSSimpleAuthSuccessResponse,
    LNRErrorResponse,
    LXLSLoginSuccessResponse,
    LXLSUserNameAvailabilityErrorRespose,
    LXLSRegisterSuccessResponse,
    LXLSForgotPasswordResponse,
    AlertBoxType,
    PopupData,
    ActionClearPopups,
    AppUtilsTypes,
} from '../commons/RJTypes';
import lnrApi from './LNRApi';
import * as CONSTANTS from '../commons/Constants';
import dataServer from '../store/Store';
import { actionLNRUpdateUserName, actionLNRUpdateLgnInfo, actionLNRUpdateUserEmail } from './LNRAction';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import netManager from '../commons/RJNetInfo';
import { translate } from '../commons/translations/LangTransator';
import i18n from 'i18n-js';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { updatePopupVisibility, clearPopups, showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import loginCoordinator from '../commons/LoginCoordinator';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import { handleException, showMessage } from '../commons/RJUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronLeft, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import appConfiguration from '../commons/AppConfiguration';
import { SafeAreaView } from 'react-native-safe-area-context';

export type LNRVwContainerProps = {
    lnrVw: LNRVwProps,
    navigation: NavigationProp,
    route: RouteProp,
    popups: PopupData,
    utils: AppUtilsTypes,
    updatePopupVisibility: (PopupData) => void,
    clearPopups: () => void,
    showAlert: (AlertBoxType) => void,
    clearAlert: () => ActionClearPopups,
};
type LNRVwContainerState = {
    ...LNRVwState,
    txtInpRef: { current: null | React.ElementRef<'input'> },
};
class LNRVwContainer extends React.Component<LNRVwContainerProps, LNRVwContainerState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    isDeskApp: boolean = false;

    constructor(props: LNRVwContainerProps) {
        super(props);
        this.state = {
            lrnVwInpData: '',
            lrnVwErrCode: null,
            lrnVwErrMsg: null,
            isFocused: false,
            txtInpRef: React.createRef(),
        };
    }

    componentDidMount() {
        this.props.navigation.setOptions({
            headerLeft: () => {
                return (
                    <Pressable
                        style={styles.backButton}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('lnr_vw_container_back_press_closed', 'lnr_vw_container');
                            this.props.navigation.goBack();
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
                    </Pressable>
                );
            },
        });

        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                this.setState({ isFocused: false });
            }
        });
        setTimeout(() => {
            this.state.txtInpRef.current?.focus();
        }, 0);
        let source: string | null = appConfiguration.getApplicationSource();
        if (source != null && source == CONSTANTS.kDeskTopApp) {
            this.isDeskApp = true;
        }
    }

    componentWillUnmount() {
        this.state.txtInpRef.current?.blur();
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    doRegisterUser = () => {
        let authsecret = this.state.lrnVwInpData;
        let email = this.props.lnrVw.lrnVwLgnInfo.email;
        let authuser = this.props.lnrVw.lrnVwLgnInfo.authuser;
        if (authsecret === null || authsecret === undefined || authsecret.length === 0) {
            //SHOW ERR MSG
            showMessage(translate('password_require_mgs'), 'lnr_vw_container');
        } else {
            if (email !== undefined && email !== null && authuser !== undefined && authuser !== null) {
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let rsp: AxiosPromise<LNRResponse> = lnrApi.doRegisterUser(email, authuser, authsecret);
                    rsp.then((response: AxiosResponse<LNRResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((qq: LNRResponse) => {
                            if ((qq?.check ?? CONSTANTS.kFailure).toUpperCase() === CONSTANTS.kSuccess.toUpperCase()) {
                                let tmpsrvresp: LXLSRegisterSuccessResponse = ((qq: any): LXLSRegisterSuccessResponse);
                                //TAKE TO USERNAME SCREEN TO DO
                                let lgndata = {
                                    authuser: authuser,
                                    authsecret: authsecret,
                                    uid: null,
                                    email: email,
                                };
                                loginCoordinator.lgnMgr = lxlsLgnMgr;
                                dataServer.getStore().dispatch(actionLNRUpdateLgnInfo(lgndata));
                                rjAnalytics.sendAnalyticsEvent('password_input_closed', 'lnr_vw_container');
                                rjAnalytics.sendAnalyticsEvent('lnr_vw_container_closed', 'lnr_vw_container');
                                //POP THIS SET
                                this.props.navigation.pop(3);
                            } else {
                                let tmpsrvresp = ((qq: any): LNRErrorResponse);
                                showMessage(tmpsrvresp.message, 'lnr_vw_container');
                            }
                        })
                        .catch((error) => {
                            handleException(error);
                        })
                        .finally(() => {
                            dataServer.getStore().dispatch(actionSetIdle());
                        });
                }
            }
        }
    };

    doCheckNameAvailability = () => {
        this.setState({ lrnVwErrMsg: null });
        let username = this.state.lrnVwInpData;
        if (username === null || username === undefined || username.length === 0) {
            //SHOW ERR MSG
            showMessage(translate('no_user_errMsg'), 'lnr_vw_container');
        } else {
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let rsp: AxiosPromise<string> = lnrApi.doCheckNameAvailability(username);
                rsp.then((response: AxiosResponse<string, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((result: string) => {
                        if (result == 'true') {
                            //TAKE TO REG PWD SCREEN TO DO
                            dataServer.getStore().dispatch(actionLNRUpdateUserName(username));
                            rjAnalytics.sendAnalyticsEvent('new_user_name_input_closed', 'lnr_vw_container');
                            rjAnalytics.sendAnalyticsEvent('new_user_password_input_opened', 'lnr_vw_container');
                            this.props.navigation.navigate('RegPwd', {
                                lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeRegPwd,
                            });
                        } else {
                            let qq: LXLSUserNameAvailabilityErrorRespose = JSON.parse(result);
                            //SHOW ERROR MESSAGE
                            let msg: string = i18n.t('lnrv_Msg4', {
                                username_suggestion1: qq.username_suggestion1,
                                username_suggestion2: qq.username_suggestion2,
                            });
                            this.setState({ lrnVwErrMsg: msg });
                        }
                    })
                    .catch((error) => {
                        handleException(error);
                    })
                    .finally(() => {
                        dataServer.getStore().dispatch(actionSetIdle());
                    });
            }
        }
    };

    doSimpleAuthEmailOrName = () => {
        let emailorname = this.state.lrnVwInpData;
        if (emailorname === null || emailorname === undefined || emailorname.length === 0) {
            //SHOW ERR MSG
            showMessage(translate('no_email_errMsg'), 'lnr_vw_container');
        } else {
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let rsp: AxiosPromise<LNRResponse> = lnrApi.doSimpleAuthEmailOrName(emailorname);
                rsp.then((response: AxiosResponse<LNRResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((qq: LNRResponse) => {
                        if ((qq?.check ?? CONSTANTS.kFailure).toUpperCase() === CONSTANTS.kSuccess.toUpperCase()) {
                            let tmpsrvresp: LXLSSimpleAuthSuccessResponse = ((qq: any): LXLSSimpleAuthSuccessResponse);
                            rjAnalytics.sendAnalyticsEvent('email_input_closed', 'lnr_vw_container');
                            rjAnalytics.sendAnalyticsEvent('password_input_opened', 'lnr_vw_container');
                            //TAKE TO USERNAME SCREEN TO DO
                            dataServer.getStore().dispatch(actionLNRUpdateUserName(tmpsrvresp.username));
                            this.props.navigation.navigate('ExstPwd', {
                                lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeExstPwd,
                            });
                        } else {
                            if (this.validateEmail(emailorname)) {
                                rjAnalytics.sendAnalyticsEvent('email_input_closed', 'lnr_vw_container');
                                rjAnalytics.sendAnalyticsEvent('new_user_name_input_opened', 'lnr_vw_container');
                                dataServer.getStore().dispatch(actionLNRUpdateUserEmail(emailorname));
                                this.props.navigation.navigate('RegUserName', {
                                    lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeRegUserName,
                                });
                            } else {
                                //SHOW ERROR MESSAGE
                                showMessage(translate('not_reg_errMsg'), 'lnr_vw_container');
                            }
                        }
                    })
                    .catch((error) => {
                        handleException(error);
                    })
                    .finally(() => {
                        dataServer.getStore().dispatch(actionSetIdle());
                    });
            }
        }
    };

    doExistingPwdLgn = () => {
        let pwd = this.state.lrnVwInpData;
        if (pwd === null || pwd === undefined || pwd.length === 0) {
            //SHOW ERR MSG
            showMessage(translate('password_require_mgs'), 'lnr_vw_container');
        } else {
            let authuser = this.props.lnrVw.lrnVwLgnInfo.authuser;
            if (authuser !== undefined && authuser !== null) {
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let rsp: AxiosPromise<LNRResponse> = lnrApi.doLogin(authuser, pwd);
                    rsp.then((response: AxiosResponse<LNRResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((qq: LNRResponse) => {
                            //LXLSLoginSuccessResponse
                            if ((qq?.check ?? CONSTANTS.kFailure).toUpperCase() === CONSTANTS.kSuccess.toUpperCase()) {
                                let tmpsrvresp: LXLSLoginSuccessResponse = ((qq: any): LXLSLoginSuccessResponse);
                                let lgndata = {
                                    authuser: this.props.lnrVw.lrnVwLgnInfo.authuser,
                                    authsecret: pwd,
                                    uid: tmpsrvresp.uid,
                                    email: tmpsrvresp.email,
                                };
                                loginCoordinator.lgnMgr = lxlsLgnMgr;
                                dataServer.getStore().dispatch(actionLNRUpdateLgnInfo(lgndata));
                                rjAnalytics.sendAnalyticsEvent('password_input_closed', 'lnr_vw_container');
                                rjAnalytics.sendAnalyticsEvent('lnr_vw_container_closed', 'lnr_vw_container');
                                this.props.navigation.pop(2);
                            } else {
                                let tmpsrvresp = ((qq: any): LNRErrorResponse);
                                showMessage(tmpsrvresp.message, 'lnr_vw_container');
                            }
                        })
                        .catch((error) => {
                            handleException(error);
                        })
                        .finally(() => {
                            dataServer.getStore().dispatch(actionSetIdle());
                        });
                }
            }
        }
    };

    validateEmail = (email: string) => {
        let reg =
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return reg.test(email);
    };

    setLrnVwInpData = (data) => {
        this.setState({ lrnVwInpData: data });
    };

    onPsswrdClick = () => {
        let isregpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegPwd;
        let isexistinguserpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeExstPwd;
        if (isexistinguserpwd) {
            this.doExistingPwdLgn();
        } else if (isregpwd) {
            let validlen = true;
            let value = '';
            if (this.state.lrnVwInpData !== null && this.state.lrnVwInpData !== undefined) {
                value = this.state.lrnVwInpData;
            }
            if (value.length < CONSTANTS.kMinPwdLenght) {
                validlen = false;
            }
            if (validlen == false) {
                showMessage(
                    i18n.t('min_passwrd_msg', {
                        kMinPwdLenght: CONSTANTS.kMinPwdLenght,
                    }),
                    'lnr_vw_container'
                );
            } else {
                this.doRegisterUser();
            }
        }
    };

    onUsernameClick = () => {
        let isregusername = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegUserName;
        if (isregusername) {
            let validlen = true;
            let value = '';
            if (this.state.lrnVwInpData !== null && this.state.lrnVwInpData !== undefined) {
                value = this.state.lrnVwInpData;
            }
            if (value.length < CONSTANTS.kMinPwdLenght) {
                validlen = false;
            }
            if (validlen == false) {
                showMessage(
                    i18n.t('minNmax_usrname_msg', {
                        kMinUserNameLength: CONSTANTS.kMinUserNameLength,
                        kMaxUserNameLength: CONSTANTS.kMaxUserNameLength,
                    }),
                    'lnr_vw_container'
                );
            } else {
                this.doCheckNameAvailability();
            }
        }
    };

    renderArrowForDesktop = () => {
        let isemailusernamescreen = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail;
        let isregpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegPwd;
        let isexistinguserpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeExstPwd;
        if (this.isDeskApp) {
            return (
                <Pressable
                    style={styles.arrowBtn}
                    onPress={() => {
                        if (isemailusernamescreen) {
                            this.doSimpleAuthEmailOrName();
                        } else if (isregpwd || isexistinguserpwd) {
                            this.onPsswrdClick();
                        } else {
                            this.onUsernameClick();
                        }
                    }}
                >
                    <FontAwesomeIcon icon={faArrowRight} size={30} color={themeConfigutation.getColor('#5f6368')} />
                </Pressable>
            );
        } else {
            return null;
        }
    };

    renderEmaiInput = () => {
        let isemailusernamescreen = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail;
        return (
            <TextInput
                ref={this.state.txtInpRef}
                placeholder={translate('yr_email_plchldr')}
                autoCompleteType={'off'}
                autoCapitalize={'none'}
                autoCorrect={false}
                autoFocus={true}
                returnKeyType={'done'}
                placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                style={[styles.textinputstyle, { color: themeConfigutation.getColor('#5f6368') }]}
                keyboardType="email-address"
                onChangeText={(value) => {
                    this.setLrnVwInpData(value);
                }}
                onSubmitEditing={(event) => {
                    if (isemailusernamescreen) {
                        this.doSimpleAuthEmailOrName();
                    }
                }}
                value={this.state.lrnVwInpData}
            />
        );
    };

    renderPwdInput = () => {
        let isregpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegPwd;
        let isexistinguserpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeExstPwd;
        return (
            <TextInput
                ref={this.state.txtInpRef}
                placeholder={translate('lxls_pswrd_plchldr')}
                secureTextEntry={true}
                autoCapitalize={'none'}
                autoCorrect={false}
                autoFocus={true}
                returnKeyType={'done'}
                autoCompleteType={'off'}
                placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                style={[styles.textinputstyle, { color: themeConfigutation.getColor('#5f6368') }]}
                onChangeText={(value) => {
                    if (isregpwd) {
                        let validlen = true;
                        if (value.length > CONSTANTS.kMaxPwdLength) {
                            validlen = false;
                        }
                        if (validlen == false) {
                            showMessage(
                                i18n.t('max_passwrd_msg', {
                                    kMaxPwdLength: CONSTANTS.kMaxPwdLength,
                                }),
                                'lnr_vw_container'
                            );
                        } else {
                            this.setLrnVwInpData(value);
                        }
                    } else {
                        this.setLrnVwInpData(value);
                    }
                }}
                onSubmitEditing={(event) => {
                    this.onPsswrdClick();
                }}
                value={this.state.lrnVwInpData}
            />
        );
    };

    renderUserNameInput = () => {
        let isregusername = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegUserName;
        return (
            <TextInput
                ref={this.state.txtInpRef}
                placeholder={translate('yr_usrname_plchldr')}
                autoCompleteType={'off'}
                autoCapitalize={'none'}
                autoCorrect={false}
                autoFocus={true}
                returnKeyType={'done'}
                placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                style={[styles.textinputstyle, { color: themeConfigutation.getColor('#5f6368') }]}
                onChangeText={(value) => {
                    let validlen = true;
                    let validchars = true;
                    if (value.length > CONSTANTS.kMaxUserNameLength) {
                        validlen = false;
                    }
                    let regex = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
                    validchars = regex.test(value);
                    if (validlen == false) {
                        showMessage(
                            i18n.t('minNmax_usrname_msg', {
                                kMinUserNameLength: CONSTANTS.kMinUserNameLength,
                                kMaxUserNameLength: CONSTANTS.kMaxUserNameLength,
                            }),
                            'lnr_vw_container'
                        );
                    } else if (validchars == true) {
                        translate('spChar_notAllw_msg');
                    } else {
                        this.setLrnVwInpData(value);
                    }
                }}
                onSubmitEditing={(event) => {
                    this.onUsernameClick();
                }}
                value={this.state.lrnVwInpData}
            />
        );
    };

    renderUserNameEmailInput = () => {
        return this.renderEmaiInput();
    };

    renderImageIcon = () => {
        let isemailusernamescreen: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail;
        let isregpwd: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegPwd;
        let isexistinguserpwd: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeExstPwd;
        return (
            <Image
                style={styles.imageStyle}
                source={
                    isemailusernamescreen == true
                        ? require('../assets/icons/email_home_icon.png')
                        : isregpwd == true || isexistinguserpwd == true
                        ? require('../assets/icons/password_icon.png')
                        : require('../assets/icons/username_icon.png')
                }
            />
        );
    };

    renderInfoTxt = (txt: string) => {
        return (
            <Text style={[styles.textStyle, { textAlign: 'justify', color: themeConfigutation.getColor('#5f6368') }]}>
                {txt}
            </Text>
        );
    };

    renderErrorInfo = () => {
        if (this.state.lrnVwErrMsg !== null) {
            return (
                <View style={styles.err_viewstyle}>
                    <Text selectable={false} style={styles.err_textstyle}>
                        {this.state.lrnVwErrMsg}
                    </Text>
                </View>
            );
        }
    };

    doForgotPassword() {
        let authuser: ?string = this.props.lnrVw.lrnVwLgnInfo.authuser;
        if (authuser) {
            let rsp: AxiosResponse<LXLSForgotPasswordResponse> = lnrApi.doForgotPassword(authuser);
            rsp.then((response: AxiosResponse<LXLSForgotPasswordResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((response: LXLSForgotPasswordResponse) => {
                    if (response.check && response.check.toLowerCase() == CONSTANTS.kSuccess) {
                        showMessage(translate('pass_emailed'), 'lnr_vw_container');
                    } else {
                        if (response?.message) {
                            showMessage(response.message, 'lnr_vw_container');
                        }
                    }
                })
                .catch((error) => handleException(error));
        }
    }

    renderResults = () => {
        let isemailusernamescreen: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail;
        let isregusername: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegUserName;
        let isregpwd: boolean = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeRegPwd;
        let isexistinguserpwd = this.props.route.params.lrnVwCode == CONSTANTS.LNRVwCode.LNRVwCodeExstPwd;

        return (
            <View style={styles.inputContainer}>
                <View
                    style={[
                        styles.inputView,
                        {
                            backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    {this.renderImageIcon()}
                    {isemailusernamescreen && this.renderUserNameEmailInput()}
                    {isregusername && this.renderUserNameInput()}
                    {(isregpwd || isexistinguserpwd) && this.renderPwdInput()}
                    {this.renderArrowForDesktop()}
                </View>
                <View style={[styles.textContainer]}>
                    {isemailusernamescreen && this.renderInfoTxt(translate('lnrv_Msg1'))}
                    {isregusername && this.renderInfoTxt(translate('lnrv_Msg2'))}
                    {isregpwd && this.renderInfoTxt(translate('lnrv_Msg3'))}
                    {isexistinguserpwd &&
                        this.renderInfoTxt(
                            i18n.t('lnrv_Msg5', {
                                authuser: this.props.lnrVw.lrnVwLgnInfo.authuser,
                            })
                        )}
                </View>
                {isregusername && this.renderErrorInfo()}
                {isexistinguserpwd ? (
                    <View style={[styles.forgetView]}>
                        <Pressable
                            onPress={() => {
                                rjAnalytics.sendAnalyticsEvent('forgot_pass_btn_pressed', 'lnr_vw_container');
                                this.doForgotPassword();
                            }}
                        >
                            <Text selectable={false} style={[styles.forgetText]}>
                                {translate('frgt_Psswrd')}
                            </Text>
                        </Pressable>
                    </View>
                ) : null}
            </View>
        );
    };

    render = () => {
        return this.state.isFocused ? (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <View style={[styles.mainContainer, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    {this.renderResults()}
                </View>
            </SafeAreaView>
        ) : null;
    };
}
const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        overflow: 'hidden',
        height: '100%',
        width: '100%',
    },
    headerContent: {
        backgroundColor: '#009feb',
        height: 70,
    },
    headerText: {
        color: 'white',
        fontSize: 35,
        fontWeight: 'bold',
        textAlign: 'center',
        margin: '1%',
    },
    inputContainer: {
        height: '80%',
    },
    inputView: {
        height: 70,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        shadowOffset: { width: -2, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
        marginTop: 8,
        paddingBottom: 8,
    },
    imageStyle: {
        width: 40,
        height: 40,
        borderRadius: 3,
        alignSelf: 'center',
        marginRight: 8,
        marginLeft: 14,
    },
    arrowBtn: {
        paddingLeft: 8,
        alignSelf: 'center',
        paddingRight: 8,
    },
    textinputstyle: {
        flex: 1,
        height: '100%',
        width: '85%',
        fontSize: 20,
        paddingLeft: 8,
    },
    forgetView: {
        height: '20%',
        width: '100%',
        marginLeft: 14,
    },
    forgetText: {
        color: '#74c2f3',
        textAlign: 'left',
        fontSize: 15,
        fontWeight: 'bold',
        textDecorationLine: 'underline',
    },
    textContainer: {
        alignSelf: 'flex-start',
        width: '98%',
        height: 60,
        paddingRight: 18,
        marginTop: 20,
        marginBottom: 30,
        marginLeft: 14,
    },
    textStyle: {
        fontSize: 15,
        letterSpacing: 1,
    },
    err_viewstyle: {
        width: '98%',
        paddingRight: 18,
        marginLeft: 14,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginBottom: 10,
    },
    err_textstyle: {
        color: '#c71924',
        fontSize: 15,
    },
    backButton: {
        padding: 10,
    },
});

function mapStateToProps(state) {
    const { lnrVw, popups, utils } = state;
    return { lnrVw, popups, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators({ updatePopupVisibility, clearPopups, showAlert, clearAlert }, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(LNRVwContainer);
