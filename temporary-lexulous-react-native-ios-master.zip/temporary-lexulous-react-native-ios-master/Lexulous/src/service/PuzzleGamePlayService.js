import { createDialogInstance, getCustomMessage } from '../utils/MessageUtils';
import GameBoardUtils, { getRackData } from '../utils/GameBoardUtils';
import { getCallType, getPuzzleRanking, pingPolling } from './GamePlayService';
import Config from '../configs/Config';
import to from 'await-to-js';
import { replaceLocation } from '../utils/UrlUtils';
import { GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY } from '../configs/ActionIdentifiers';
import store from '../store';

const eventBus = require('js-event-bus')();

export default class PuzzleGamePlayService {
    static getRackForPuzzle = (result) => {
        const state = store.getState();
        let data = result.data[state.game.channel].boarddata.rackinfo;
        return getRackData(data);
    };

    static onSendPuzzleMoveFail = (result) => {
        createDialogInstance(
            {
                code: 'sendPuzzleMoveFail', //for content search in json file this key is sent
                body: getCustomMessage(result),
                isConfirmableByKey: true,
            },
            null
        );

        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'PuzzleGamePlayService.onSendPuzzleMoveFail',
            visible: false,
        });
    };

    static onSendPuzzleMoveSuccess = () => {
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'PuzzleGamePlayService.onSendPuzzleMoveSuccess',
            visible: false,
        });
    };

    static onRequestNextPuzzle = () => {
        const state = store.getState();
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'PuzzleGamePlayService.onRequestNextPuzzle',
            boardSpinner: Config.BOARD_SPINNER,
            visible: true,
        });

        if (state.config.isProUser) {
            //eventBus.emit(Config.RESTART_APP);
            eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW);
        } else {
            //php redirection to get puzzle id by guid,uuid for next puzzle
            let phpIndexUrl = state.game.php_index_url;
            replaceLocation(phpIndexUrl);
        }
    };

    static getNotSuccessExitCodeInstance = (data) => ({
        extcode: data[0] ? 0 : data[1].extcode,
        msg: data[0] ? data[0].message : data[1].msg,
    });

    static handleSocialLoginFailure = (err) => {
        createDialogInstance({
            title: 'Message',
            body: 'Sign In Failed',
            cancelButtonText: 'OK',
            notDismissable: true,
            isConfirmableByKey: true,
        });
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'PuzzleGamePlayService.handleSocialLoginFailure',
            visible: false,
        });
    };

    static getUserProfile = (data) =>
        data.data[store.getState().game.guid].name;
}

export const puzzlePingPolling = async () => {
    pingPolling();
};

export const sendPuzzleMove = async (moveArr) => {
    const state = store.getState();
    let requestMethod = getCallType('sendPuzzleMoveData');

    let params = {
        channel: state.game.channel,
        action: Config.SEND_PLAY_MOVE_DATA_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        puzzleid: state.game.puzzle_id,
        move: moveArr,
        dic: state.game.dic,
    };

    let res = requestMethod
        ? await to(requestMethod(params))
        : [Error('Invalid Request Type')];

    getPuzzleRanking();

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.SEND_PUZZLE_MOVE_FAIL, null, extObj);
        eventBus.emit(Config.HIDE_PUZZLE_BOARD_HEADER, null, true);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY, null, res[1]);
        eventBus.emit(Config.SEND_PUZZLE_MOVE_SUCCESS, null, res[1]);
        eventBus.emit(Config.HIDE_PUZZLE_BOARD_HEADER, null, false);
    }
};
