// @flow

import React from 'react';
import dataServer from '../store/Store';
import { connect } from 'react-redux';
import {
    StyleSheet,
    ScrollView,
    Text,
    View,
    Pressable,
    TextInput,
    Keyboard,
    Platform,
    Linking,
    Dimensions,
} from 'react-native';
import type { NavigationProp } from '@react-navigation/native';
import * as CONSTANTS from '../commons/Constants';
import userDefault from '../commons/UserDefault';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faExclamationCircle, faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import type { ServerResponse, ProfileInfo, AppUtilsTypes } from '../commons/RJTypes';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import base64 from 'react-native-base64';
import requestManager from '../commons/RequestManager';
import netManager from '../commons/RJNetInfo';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosResponse } from 'axios';
import { handleException } from '../commons/RJUtils';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import { SafeAreaView } from 'react-native-safe-area-context';

type CustomerSupportScreenContainerState = {
    senderEmail: string,
    supportRequest: string,
    emailIDInputFocused: boolean,
    requestInputFocused: boolean,
    invalidEmailID: boolean,
    invalidComment: boolean,
    requestSent: boolean,
    isFocused: boolean,
};

class CustomerSupportScreenContainer extends React.Component<
    { profile: ProfileInfo, utils: AppUtilsTypes, navigation: NavigationProp },
    CustomerSupportScreenContainerState
> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;

    constructor(props: { profile: ProfileInfo, utils: AppUtilsTypes, navigation: NavigationProp }) {
        super(props);
        this.state = {
            senderEmail: '',
            supportRequest: '',
            emailIDInputFocused: false,
            requestInputFocused: false,
            invalidEmailID: false,
            invalidComment: false,
            requestSent: false,
            isFocused: false,
        };
    }

    componentDidMount = () => {
        userDefault.get(CONSTANTS.supportRequestEmailID).then((value) => {
            this.setState({ senderEmail: value });
        });
        this.props.navigation.setOptions({
            headerLeft: () => this.getHelpIcon(),
        });
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                this.setState({ isFocused: false });
            }
        });
    };

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    getHelpIcon = () => {
        return (
            <Pressable
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('customer_support_closed', 'customer_support_screen_container');
                    this.props.navigation.goBack();
                }}
                style={{ paddingHorizontal: 12 }}
            >
                <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
            </Pressable>
        );
    };

    goToForum = () => {
        Linking.openURL(CONSTANTS.forumLink);
    };

    getEmail = (data: string) => {
        if (!data.trim()) {
            this.setState({ senderEmail: data.trim() });
        } else {
            this.setState({ senderEmail: data, invalidEmailID: false });
        }
    };

    getComments = (data: string) => {
        if (!data.trim()) {
            this.setState({ supportRequest: data.trim() });
        } else {
            this.setState({ supportRequest: data, invalidComment: false });
        }
    };

    OnSubmit = () => {
        if (this.state.senderEmail !== '' && this.validateEmail(this.state.senderEmail)) {
            if (this.state.supportRequest !== '') {
                let msg = `<html><p>${this.state.supportRequest}</p> <br/><br/>GUID: ${
                    this.props.profile.guid ?? CONSTANTS.Default_guid
                }<br/>APP_TYPE: ${CONSTANTS.appType}<br/>APP_VER: ${
                    CONSTANTS.appVersion
                }<br/>DEVICE_MODEL: ${this.getDeviceModel()}<br/>SYSTEM_VERSION: ${
                    Platform.Version
                }<br/>SYSTEM_NAME: ${this.getSystemName()}<br/>DEVICE_RESOLUTION: ${JSON.stringify(
                    Dimensions.get('window')
                )}</html>`;
                console.log('msg ::::::', JSON.stringify(msg));
                userDefault.set(CONSTANTS.supportRequestEmailID, this.state.senderEmail);
                if (netManager.isConnected()) {
                    let useremail = this.state.senderEmail;
                    let subject = `Lexulous ${Platform.OS} Support Request`;
                    let encodedmsg = base64.encode(msg);
                    dataServer.getStore().dispatch(actionSetBusy());
                    requestManager
                        .sendSupporttRequest(useremail, subject, encodedmsg)
                        .then((response: AxiosResponse<ServerResponse, any>) => {
                            if (response.status == CONSTANTS.HTTPSuccessStatus) {
                                return response.data;
                            } else {
                                throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                            }
                        })
                        .then((result: ServerResponse) => {
                            if (result.check === CONSTANTS.kSuccess) {
                                this.setState({ requestSent: true });
                            }
                        })
                        .catch((error) => {
                            handleException(error);
                        })
                        .finally(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                        });
                }
            } else {
                this.setState({ invalidComment: true });
            }
        } else {
            this.setState({ invalidEmailID: true });
        }
        if (this.state.supportRequest === '') {
            this.setState({ invalidComment: true });
        }
        Keyboard.dismiss();
    };

    getSystemName = () => {
        return Platform.select({
            native: `${Platform.OS}`,
            default: `${navigator.userAgent}`,
        });
    };

    getDeviceModel = () => {
        if (Platform.OS === 'ios') {
            return `${Platform.isPad ? 'iPad' : 'iPhone'}`;
        } else if (Platform.OS === 'android') {
            return `${Platform.constants.Model}`;
        } else {
            return 'undefined';
        }
    };

    validateEmail = (email: string) => {
        let reg =
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return reg.test(email);
    };

    setEmailIDInputFocused = () => {
        this.setState({ emailIDInputFocused: !this.state.emailIDInputFocused });
    };

    setRequestInputFocused = () => {
        this.setState({ requestInputFocused: !this.state.requestInputFocused });
    };

    render() {
        return this.state.isFocused ? (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <ScrollView
                    keyboardShouldPersistTaps="always"
                    style={{ backgroundColor: themeConfigutation.getColor('#f4f3ef') }}
                >
                    <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#fffff') }]}>
                        {this.renderNeedHelp()}
                        {this.renderVisitForumEntry()}
                        {this.renderContactViaEmail()}
                        {this.renderEmailInputView()}
                        {this.renderCommentInputView()}
                        {this.showSendBtnOrCnfrmMsg()}
                    </View>
                </ScrollView>
            </SafeAreaView>
        ) : null;
    }

    renderNeedHelp = () => {
        return (
            <View>
                <View style={{ paddingBottom: 8 }}>
                    <Text style={[styles.boldTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('need_hlp')}
                    </Text>
                </View>
                <View>
                    <Text selectable={false} style={[styles.normalTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('need_hlp_Msg1')}
                    </Text>
                    <Text selectable={false} style={[styles.normalTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('need_hlp_Msg2')}
                    </Text>
                </View>
            </View>
        );
    };

    renderVisitForumEntry = () => {
        return (
            <Pressable
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('forum_link_btn_pressed', 'customer_support_screen_container');
                    this.goToForum();
                }}
                style={styles.btnStyle}
            >
                <Text selectable={false} style={styles.btnTextStyle}>
                    {translate('vst_frm')}
                </Text>
            </Pressable>
        );
    };

    renderContactViaEmail = () => {
        return (
            <View>
                <View style={{ paddingBottom: 8 }}>
                    <Text selectable={false} style={[styles.boldTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('cntct_Via_Emaill')}
                    </Text>
                </View>
                <View>
                    <Text selectable={false} style={[styles.normalTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('cntct_Via_Emaill_Msg')}
                    </Text>
                </View>
            </View>
        );
    };

    renderEmailInputView = () => {
        return (
            <View style={[styles.emailContainerStyle]}>
                <Text selectable={false} style={[styles.normalTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                    {translate('yr_Emailid')}
                </Text>
                <View style={[styles.inputContainerStyle, this.applyEmailBorderStyle()]}>
                    <View style={styles.emailInputViewStyle}>
                        <TextInput
                            onFocus={() => this.setEmailIDInputFocused()}
                            onBlur={() => this.setEmailIDInputFocused()}
                            onChangeText={(text) => this.getEmail(text)}
                            value={this.state.senderEmail}
                            style={[styles.textInputStyle, { color: themeConfigutation.getColor('#000') }]}
                        />
                    </View>
                    {this.state.invalidEmailID ? this.showWarningMark() : null}
                </View>
                {this.showEmailWarningMsg()}
            </View>
        );
    };

    renderCommentInputView = () => {
        return (
            <View style={styles.emailContainerStyle}>
                <Text selectable={false} style={[styles.normalTextStyle, { color: themeConfigutation.getColor('#000') }]}>
                    {translate('comments')}
                </Text>
                <View style={[styles.inputContainerStyle, this.applyCommentBorderStyle()]}>
                    <View style={styles.commentInputViewStyle}>
                        <TextInput
                            onFocus={() => this.setRequestInputFocused()}
                            onBlur={() => this.setRequestInputFocused()}
                            onChangeText={(text) => this.getComments(text)}
                            value={this.state.supportRequest}
                            multiline={true}
                            numberOfLines={4}
                            style={[styles.textInputStyle, { color: themeConfigutation.getColor('#000') }]}
                        />
                    </View>
                    {this.state.invalidComment ? this.showWarningMark() : null}
                </View>
                {this.showCmmtWarningMsg()}
            </View>
        );
    };

    applyEmailBorderStyle = () => {
        if (this.state.invalidEmailID) {
            return { borderBottomColor: 'tomato', borderBottomWidth: 1 };
        }
        if (this.state.emailIDInputFocused) {
            return { borderBottomColor: '#4DB6AC', borderBottomWidth: 2 };
        } else {
            return { borderBottomColor: themeConfigutation.getColor('#000'), borderBottomWidth: 1 };
        }
    };

    applyCommentBorderStyle = () => {
        if (this.state.invalidComment) {
            return { borderBottomColor: 'tomato', borderBottomWidth: 1 };
        }
        if (this.state.requestInputFocused) {
            return { borderBottomColor: '#4DB6AC', borderBottomWidth: 2 };
        } else {
            return { borderBottomColor: themeConfigutation.getColor('#000'), borderBottomWidth: 1 };
        }
    };

    showWarningMark = () => {
        return (
            <View style={styles.warningContainerStyle}>
                <FontAwesomeIcon icon={faExclamationCircle} size={20} color={'tomato'} />
            </View>
        );
    };

    showEmailWarningMsg = () => {
        if (this.state.invalidEmailID) {
            return (
                <View style={{ alignItems: 'flex-end' }}>
                    <Text selectable={false} style={styles.redTextStyle}>
                        {translate('yr_Emailid_ErrMsg')}
                    </Text>
                </View>
            );
        } else {
            return null;
        }
    };

    showCmmtWarningMsg = () => {
        if (this.state.invalidComment) {
            return (
                <View style={{ alignItems: 'flex-end' }}>
                    <Text selectable={false} style={styles.redTextStyle}>
                        {translate('comments_ErrMsg')}
                    </Text>
                </View>
            );
        } else {
            return null;
        }
    };

    showSendBtnOrCnfrmMsg = () => {
        if (this.state.requestSent) {
            return (
                <View>
                    <Text selectable={false} style={[styles.redTextStyle, { color: themeConfigutation.getColor('#28B463') }]}>
                        {translate('sent_Msg')}
                    </Text>
                </View>
            );
        } else {
            return (
                <Pressable
                    onPress={() => {
                        this.OnSubmit();
                        rjAnalytics.sendAnalyticsEvent('customer_msg_send_btn_pressed', 'customer_support_screen_container');
                    }}
                    style={styles.sendBtnStyle}
                >
                    <Text selectable={false} style={styles.btnTextStyle}>
                        {translate('send')}
                    </Text>
                </Pressable>
            );
        }
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 12,
    },
    boldTextStyle: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    normalTextStyle: { fontSize: 18 },
    btnStyle: {
        backgroundColor: '#1d9df1',
        width: 150,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 12,
        borderRadius: 4,
    },
    btnTextStyle: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    emailContainerStyle: { marginVertical: 8 },
    inputContainerStyle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    emailInputViewStyle: {
        height: 40,
        width: '100%',
    },
    commentInputViewStyle: {
        height: 100,
        width: '100%',
    },
    textInputStyle: {
        textAlignVertical: 'top',
        fontSize: 16,
        height: '100%',
        ...Platform.select({
            native: {},
            default: {
                outlineStyle: 'none',
            },
        }),
    },
    sendBtnStyle: {
        backgroundColor: '#1d9df1',
        width: 80,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 4,
    },
    warningContainerStyle: {
        position: 'absolute',
        height: 40,
        width: '100%',
        alignItems: 'flex-end',
        justifyContent: 'center',
        zIndex: -1,
    },
    redTextStyle: {
        fontSize: 16,
        color: 'tomato',
    },
});

function mapStateToProps(state) {
    const { profile, utils } = state;
    return { profile, utils };
}

export default connect(mapStateToProps, null)(CustomerSupportScreenContainer);
