import Sound from 'react-native-sound';

class SoundManager {
    _soundFiles = [
        'bingo.mp3',
        'clicktile.mp3',
        'droptilesound.mp3',
        'error.mp3',
        'gamestartendsound.mp3',
        'invalid_word.mp3',
        'message.mp3',
        'opp_submits.mp3',
        'recall.mp3',
        'shuffle.mp3',
        'user_submits.mp3',
        'user_wins_game.mp3',
    ];
    _playableSound = [];

    constructor() {
        this.onAppInit();
    }

    onAppInit = () => {
        //preload sounds
        this._playableSound.forEach((element) => {
            element.release();
        });
        this._playableSound.length = 0;
        this._soundFiles.forEach((element) => {
            let snd = new Sound(element, Sound.MAIN_BUNDLE);
            this._playableSound.push(snd);
        });
    };

    onDestroy = () => {
        //cleanup
        this._playableSound.forEach((element) => {
            element.release();
        });
        this._playableSound.length = 0;
    };

    isPlaying = () => {
        return false;
    };

    playSound = (soundname) => {
        if (this._playableSound.length == 0) {
            this.onAppInit();
        }
        let soundIndex = this._soundFiles.findIndex(
            (item) => item === soundname + '.mp3'
        );
        this._playableSound[soundIndex].play();
    };
}

const HowlObject = new SoundManager();
export default HowlObject;
