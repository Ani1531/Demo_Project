import React from 'react';
import { View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import FontAwesomeSpin from './FontAwesomeSpin';

export default class SimpleTouchableOpacity extends React.PureComponent {
    state = {
        hidden: this.props.hidden,
        loaderVisible: false,
    };

    render = () =>
        this.state.hidden ? null : (
            <View {...this.props}>
                {this.state.loaderVisible ? (
                    <FontAwesomeSpin />
                ) : (
                    this.props.children
                )}
            </View>
        );

    setVisibility = (visible) => this.setState({ hidden: !visible });

    isVisible = () => !this.state.hidden;

    setLoaderVisibility = (visible) =>
        this.setState({ loaderVisible: visible });
}
