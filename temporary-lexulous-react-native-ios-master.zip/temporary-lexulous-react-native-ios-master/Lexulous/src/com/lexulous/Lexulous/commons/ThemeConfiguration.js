//@flow

import { Appearance } from 'react-native';
import dataServer from '../store/Store';
import type { AppearancePreferences, ColorSchemeName } from 'react-native/Libraries/Utilities/NativeAppearance';
import { actionUpdateAppUtils } from '../commons/RJTypes';
import { UPDATE_COLOR_SCHEME } from '../commons/Constants';
import { Platform } from 'react-native';

class ThemeConfiguration {
    _overridenByApp = false;
    _callback: (() => void) | null = null;
    _current_theme: { [string]: string } | null = null;
    _dark_theme: { [string]: string } = {
        '#fff': '#000',
        '#000': '#fff',
        '#212121': '#dedede',
        '#5f6368': '#c8c8c8',
        '#f1f2f6': '#0e0d09',
        '#f4f3ef': '#0a0a0a',
        'rgba(0, 0, 0, 0.54)': '#adadad',
        '#e5e7e9': '#525252',
        '#28B463': '#66ff00',
        '#ffffff': '#0a0a0a', // for homeTabs
        '#d6d6d7': '#656567',
        '#444': '#fff',
        '#3b5494': '#5cb0ff',
        '#0d0d0d': '#525252',
        '#014577': '#1d9df1',
        '#fafafa': '#525252',
        '#0000ff': '#99ff33',
    };
    _unsubscribeListener = null;

    constructor() {
        //this.onAppInit();
    }

    set overridenByApp(value: boolean) {
        this._overridenByApp = value;
        let pref: ?ColorSchemeName = 'light';
        if (this._overridenByApp) {
            pref = 'dark';
        } else {
            pref = Appearance.getColorScheme();
        }
        this.onThemeChange(pref);
    }

    set callback(value: (() => void) | null) {
        this._callback = value;
    }

    onAppInit() {
        this.onDestroy();

        if (this._overridenByApp) {
            this.onThemeChange('dark');
        } else {
            let tpref: ?ColorSchemeName = Appearance.getColorScheme();
            this.onThemeChange(tpref);
        }

        this._unsubscribeListener = Appearance.addChangeListener((preference: AppearancePreferences) => {
            if (!this._overridenByApp) {
                let pref: ColorSchemeName = ((preference.colorScheme: any): ColorSchemeName);
                this.onThemeChange(pref);
            }
        });
    }

    onThemeChange = (colorScheme: ?ColorSchemeName) => {
        if (colorScheme == null || colorScheme == undefined) {
            colorScheme = 'light';
        }

        if (colorScheme === 'dark') {
            this.updateThemeConfig('dark');
        } else {
            this.updateThemeConfig('light');
        }
        dataServer.getStore().dispatch(actionUpdateAppUtils(UPDATE_COLOR_SCHEME, { colorScheme }));
        if (this._callback != null) {
            this._callback();
        }
        let themeUpdateforWeb = Platform.select({
            native: () => {},
            default: () => {
                if (colorScheme === 'dark') {
                    document.body?.classList.add('dark-mode');
                } else {
                    document.body?.classList.remove('dark-mode');
                }
            },
        });
        themeUpdateforWeb();
    };

    onDestroy() {
        if (this._unsubscribeListener) {
            this._unsubscribeListener.remove();
            this._unsubscribeListener = null;
        }
    }

    updateThemeConfig(mode: 'dark' | 'light') {
        switch (mode) {
            case 'dark':
                this._current_theme = this._dark_theme;
                break;

            case 'light':
                this._current_theme = null;
                break;

            default:
                this._current_theme = null;
        }
    }

    getColor(color: string): string {
        if (this._current_theme == null) {
            return color;
        } else {
            let tcolor = this._current_theme[color];

            if (tcolor != null && tcolor !== undefined) {
                return tcolor;
            } else {
                return color;
            }
        }
    }
}
const themeConfigutation = new ThemeConfiguration();

export default themeConfigutation;
