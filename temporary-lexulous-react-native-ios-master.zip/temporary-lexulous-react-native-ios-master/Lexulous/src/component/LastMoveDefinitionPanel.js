import React, { Fragment } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import { connect } from 'react-redux';
import S14Text from './S14Text';
import FontAwesomeSpin from './FontAwesomeSpin';

class LastMoveDefinitionPanel extends React.PureComponent {
    state = {
        lastMoveWords: [],
    };

    getTextfitStyle = () => {
        let totalPassageLength = 0;
        (this.props.game.lastMoveWords || []).forEach((word) => {
            if (word) {
                totalPassageLength += word.wordPlayed.length;
                totalPassageLength += word.showDefinition
                    ? (word.definition || 'Definition not available.').length
                    : 0;
                totalPassageLength += 15;
            }
        });
        return totalPassageLength <= 250
            ? styles.shortPassageSize
            : totalPassageLength <= 375
            ? styles.mediumPassageSize
            : totalPassageLength <= 500
            ? styles.longPassagSize
            : styles.veryLongPassageSize;
    };

    render = () => (
        <View key={'last-move-panel-container'} style={[styles.w100]}>
            <S14Text style={this.getTextfitStyle()}>
                {this.props.game.lastMoveWords &&
                    this.props.game.lastMoveWords.map((word, index) => (
                        <Fragment key={'last-move-word-' + index}>
                            <S14Text
                                style={[
                                    styles.fontBold,
                                    this.getTextfitStyle(),
                                ]}
                            >
                                {word.wordPlayed}
                                {': '}
                            </S14Text>
                            {word.showDefinition
                                ? word.definition || 'Definition not available.'
                                : null}
                            {'\n\n'}
                        </Fragment>
                    ))}
            </S14Text>

            {this.props.game.gameMoveFurtherDataShowLoader ? (
                <View style={[StyleSheet.absoluteFill, styles.loaderContainer]}>
                    <FontAwesomeSpin />
                </View>
            ) : null}
        </View>
    );
}

const styles = StyleSheet.create({
    w100: {
        width: '100%',
        height: '100%',
        overflow: 'hidden',
    },
    shortPassageSize: { fontSize: 14 },
    mediumPassageSize: { fontSize: 12 },
    longPassagSize: { fontSize: 10 },
    veryLongPassageSize: { fontSize: 8 },
    fontBold: { fontWeight: 'bold' },
    loaderContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        overflow: 'hidden',
    },
});
const mapStateToProps = (state) => ({ game: state.game });
export default connect(mapStateToProps)(LastMoveDefinitionPanel);
