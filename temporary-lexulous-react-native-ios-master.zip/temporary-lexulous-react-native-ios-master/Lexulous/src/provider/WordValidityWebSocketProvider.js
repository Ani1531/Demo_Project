import WebSocketAsPromised from 'websocket-as-promised';
import Config from '../configs/Config';
import { to } from 'await-to-js';
import { checkNativeGamelistUpdate, isOnline, queueWithPromisifiedPush, StatusCheckableTimeout } from '../utils/Utils';
import { isEmailGame } from '../service/GamePlayService';
import get from 'lodash/get';
import cloneDeep from 'lodash/cloneDeep';
import WebSocketProvider from './WebSocketProvider';
import {
    CONNECTIVITY_REDUCER_CONNECTION_LOST,
    CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
    CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
    GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
} from '../configs/ActionIdentifiers';
import store from '../store';
import NetInfo from '@react-native-community/netinfo';
import DimensionUtils from '../utils/DimensionUtils';
import ServiceWrapper from '../utils/ServiceWrapper';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';

const wordValidity_request_queue = queueWithPromisifiedPush();
const eventBus = require('js-event-bus')();

let reconnectCount = 0;
let word_validity_websocket_was_disconected = false;
let word_validity_duplicateConnection = false;
let wordValidityWebsocketConnection, wordValidity_reconnectTimeout;

let unsubscribe;

export default class WordValidityWebSocketProvider {
    static disconnect = () => {
        if (WordValidityWebSocketProvider.isConnected()) {
            wordValidityWebsocketConnection.removeAllListeners();
            unsubscribe();
            wordValidityWebsocketConnection.close();
        }
    };

    static getWebSocketConnection = async () => {
        const state = store.getState();
        if (WordValidityWebSocketProvider.isConnected()) return wordValidityWebsocketConnection;

        if (
            !isOnline() ||
            (!WordValidityWebSocketProvider.isConnected() &&
                wordValidity_reconnectTimeout &&
                !wordValidity_reconnectTimeout.getCleared())
        ) {
            return;
        }

        let loginParams = {
            action: 'login',
            guid:
                DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
                    ? ServiceWrapper.getNativeGUID()
                    : state.game.guid,
            uuid:
                DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
                    ? ServiceWrapper.getNativeUUID()
                    : state.game.uuid,
            channel: state.game.channel,
            ver: '3',
            device: 'WB',
            altntf: 'y',
        };

        let wsUrl = encodeURI(state.game.word_validity_websocket_host + '?params=' + JSON.stringify(loginParams));
        wordValidityWebsocketConnection = new WebSocketAsPromised(wsUrl, {
            packMessage: (data) => JSON.stringify(data),
            unpackMessage: (data) => JSON.parse(data),
            attachRequestId: (data, requestId) => Object.assign({ piggyback: JSON.stringify({ msgId: requestId }) }, data), // attach requestId to message as `id` field
            extractRequestId: (data) => data && data.piggyback && JSON.parse(data.piggyback).msgId, // read requestId from message `id` field
            timeout: Config.LIVE_GAME_REQUEST_TIMEOUT_TIME,
        });

        wordValidityWebsocketConnection.onMessage.addListener(WordValidityWebSocketProvider.handleIncomingMessage);
        wordValidityWebsocketConnection.onClose.addListener(WordValidityWebSocketProvider.checkAndReconnect);

        if (!unsubscribe) unsubscribe = NetInfo.addEventListener(WordValidityWebSocketProvider.checkAndReconnect);

        eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED);

        // On first request
        if (!wordValidity_reconnectTimeout) {
            wordValidity_reconnectTimeout = new StatusCheckableTimeout(
                WordValidityWebSocketProvider.checkAndReconnect,
                Config.LIVE_GAME_REQUEST_TIMEOUT_TIME
            );
        }

        await wordValidityWebsocketConnection.open();

        return wordValidityWebsocketConnection;
    };

    static checkAndReconnect = () => {
        if (!WordValidityWebSocketProvider.isConnected() && isOnline()) {
            word_validity_websocket_was_disconected = true;
            if (word_validity_websocket_was_disconected) {
                eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_LOST);
                WordValidityWebSocketProvider.keepReconnecting();
            }
        } else {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED);
            if (word_validity_websocket_was_disconected) {
                word_validity_websocket_was_disconected = false;
                word_validity_duplicateConnection = false;
            }
        }
    };

    static isConnected = () =>
        isOnline() &&
        wordValidityWebsocketConnection &&
        wordValidityWebsocketConnection.ws &&
        [1, 0].includes(wordValidityWebsocketConnection.ws.readyState);

    static keepReconnecting = async () => {
        if (
            (wordValidity_reconnectTimeout && !wordValidity_reconnectTimeout.getCleared()) ||
            reconnectCount >= Config.MAX_RECONNECT_TRIES ||
            WordValidityWebSocketProvider.isConnected()
        ) {
            return;
        }

        ++reconnectCount;

        wordValidity_reconnectTimeout && wordValidity_reconnectTimeout.clear();

        wordValidityWebsocketConnection &&
            wordValidityWebsocketConnection.removeAllListeners() &&
            (await to(wordValidityWebsocketConnection.close()));

        eventBus.emit(CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING);
        await to(WordValidityWebSocketProvider.getWebSocketConnection());

        if (!WordValidityWebSocketProvider.isConnected()) {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED);
            if (reconnectCount < Config.MAX_RECONNECT_TRIES) {
                wordValidity_reconnectTimeout = new StatusCheckableTimeout(
                    WordValidityWebSocketProvider.checkAndReconnect,
                    Config.LIVE_GAME_REQUEST_TIMEOUT_TIME
                );
            }
        } else {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_LOST);
            reconnectCount = 0;
        }
    };

    static isConnecting = () =>
        isOnline() &&
        wordValidityWebsocketConnection &&
        wordValidityWebsocketConnection.ws &&
        [0].includes(wordValidityWebsocketConnection.ws.readyState);

    static getWordValidity = async (params) => await WordValidityWebSocketProvider.send(params);

    static ping = async (params) => await WordValidityWebSocketProvider.send(params);

    static send = async (params) =>
        await wordValidity_request_queue.promisifiedPush(() => WordValidityWebSocketProvider.sendWithoutQueue(params));

    static sendWithoutQueue = async (params) => {
        let connectionReq = await to(WordValidityWebSocketProvider.getWebSocketConnection());
        let sendReq = connectionReq[1] ? await to(connectionReq[1].sendRequest(params)) : [Error('Connection Unavailable')];
        if (sendReq[0]) {
            throw sendReq[0];
        } else return sendReq[1];
    };

    static handleIncomingMessage = (message) => {
        const state = store.getState();
        let messageObj = JSON.parse(message);
        if (isEmailGame()) {
            let gid = get(messageObj, 'data.gid');
            if (gid && state.game.gid && gid === state.game.gid) {
                messageObj.action = get(messageObj, 'type') || get(messageObj, 'action');
                messageObj.extcode = '1';
                messageObj.data.msg = get(messageObj, 'data.chat.0.msg');
                messageObj.data[state.game.channel] = cloneDeep(messageObj.data);
                switch (messageObj.action) {
                    case 'chal':
                        messageObj.action = 'challenge';
                        break;
                    case 'chat':
                        messageObj.action = 'gamechat';
                        break;
                    case 'newgame':
                    case 'gameover':
                        messageObj.action = 'move';
                        break;
                    case 'delgame':
                        messageObj.action = 'deletegame';
                        break;
                    default:
                        break;
                }
                WebSocketProvider.handleIncomingMessage(messageObj);
            }
        }
        checkNativeGamelistUpdate(messageObj);
    };
}
