import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as GameActions from './actions/GameActions';
import * as GameOverActions from './actions/GameOverActions';
import * as ChatActions from './actions/ChatActions';
import * as LayoutActions from './actions/LayoutActions';
import * as ActionIdentifiers from './configs/ActionIdentifiers';
import * as SoloActions from './actions/SoloActions';
import * as ConfigActions from './actions/ConfigActions';
import * as ConnectivityActions from './actions/ConnectivityActions';
import * as CellActions from './actions/CellActions';
import * as LobbyChatActions from './actions/LobbyChatActions';
import * as DimensionActions from './actions/DimensionActions';

const eventBus = require('js-event-bus')();

class TemporaryEventReceiver extends React.Component {
    render = () => null;

    componentDidMount = () => {
        eventBus.on(
            ActionIdentifiers.CHAT_APPEND_LIST_ITEM,
            this.props.appendToMessageList
        );
        eventBus.on(
            ActionIdentifiers.CHAT_APPEND_LIST_ITEM_MORE_TIME,
            this.props.appendToMessageListMoreTime
        );
        eventBus.on(
            ActionIdentifiers.LOBBY_CHAT_MESSAGE,
            this.props.lobbyChatMessage
        );
        eventBus.on(ActionIdentifiers.GAME_HAS_ENDED, this.props.gameOver);
        eventBus.on(ActionIdentifiers.GAME_STARTED, this.props.gameStarted);
        eventBus.on(ActionIdentifiers.GAME_MOVE, this.props.gameMove);
        eventBus.on(
            ActionIdentifiers.GAME_MOVE_COUNT_SET,
            this.props.gameMoveCountSet
        );
        eventBus.on(
            ActionIdentifiers.GAME_MOVE_FURTHER_DATA_SHOW_LOADER,
            this.props.gameMoveFurtherDataShowLoader
        );
        eventBus.on(
            ActionIdentifiers.GAME_MOVE_FURTHER_DATA_HIDE_LOADER,
            this.props.gameMoveFurtherDataHideLoader
        );
        eventBus.on(
            ActionIdentifiers.GAME_WORD_DEFINITIONS,
            this.props.gameWordDefinitions
        );
        eventBus.on(
            ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED,
            this.props.gamePuzzleLastGameStatusesRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED,
            this.props.gamePuzzlePuzzleRankingsRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY,
            this.props.gamePuzzleMoveSentSuccessfully
        );
        eventBus.on(
            ActionIdentifiers.GAME_PUZZLE_PASS_SENT_SUCCESSFULLY,
            this.props.gamePuzzlePassSentSuccessfully
        );
        eventBus.on(
            ActionIdentifiers.GAME_PLAY_BUTTON_WORD_VALIDITY,
            this.props.setPlayButtonWordValidity
        );
        eventBus.on(
            ActionIdentifiers.GAME_RESOURCE_PANEL_WORD_VALIDITY,
            this.props.setResourcePanelWordValidity
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_ROOM_ADD_OBSERVER,
            this.props.gameAddObserver
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_ROOM_REMOVE_OBSERVER,
            this.props.gameRemoveObserver
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_ROOM_LOGIN,
            this.props.gameLiveGameLogin
        );
        eventBus.on(
            ActionIdentifiers.GAME_HAS_ACTIVE_GAME_EVENT,
            this.props.gameHasLiveGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED,
            this.props.gameLiveGameInvitationReceived
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
            this.props.gameLiveMultiplayerHostGameLeave
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_ADD_HOSTED_GAME,
            this.props.gameLiveAddHostedGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_DELETE_HOSTED_GAME,
            this.props.gameLiveDeleteHostedGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_GAME_ACTION,
            this.props.gameLiveGameHost
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE,
            this.props.connectivityReducerGameDuplicateConnectionOccurrence
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_RESTART_SERVER,
            this.props.connectivityReducerRestartServer
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_CLEAR_INVITATION,
            this.props.gameLiveGameClearInvitation
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_GET_ONLINE_STATUS,
            this.props.gameLiveGameGetOnlineStatus
        );
        eventBus.on(
            ActionIdentifiers.GAME_SET_PLAYER_COUNT,
            this.props.gameSetPlayerCount
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED,
            this.props.gameLiveGameHostedGamesListRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_GAME_LOGIN,
            this.props.gameSoloGameLogin
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_NEW_GAME,
            this.props.gameSoloNewGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SAVED_RULES,
            this.props.gameSoloSavedRules
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_GET_RANDOM_BOARD,
            this.props.gameSoloGetRandomBoard
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_RESET_CREATE_BOARD,
            this.props.gameSoloResetBoard
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SET_BOARD_DISABLE,
            this.props.gameSoloSetBoardDisable
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_RESET_RESUME_GAME,
            this.props.gameSoloResetResumeGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_RESET_SLOT_DATA,
            this.props.gameSoloResetSlotData
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_CREATE_GAME_DATA,
            this.props.gameSoloCreateGameData
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_MENU_SHOW_HIDE,
            this.props.gameSoloMenuShowHide
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SET_CURRENT_MENU_OPT,
            this.props.gameSoloSetCurrentMenuOpt
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SET_FORM_TYPE,
            this.props.gameSoloSetFormType
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SET_FORM_DATA,
            this.props.gameSoloSetFormData
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_SET_NO_LOGIN_DATA,
            this.props.gameSoloSetNoLoginData
        );
        eventBus.on(
            ActionIdentifiers.SET_SERVER_TIME_DIFFERENCE,
            this.props.setServerTimeDifference
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE,
            this.props.gameLiveGameOnlinePlayerListAvailable
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED,
            this.props.gameLiveGameObservableGamesListRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_OBSERVABLE_GAME_REMOVE,
            this.props.gameLiveObservableGameRemove
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_PAGE_VISIBILITY_CHANGE,
            this.props.gameLivePageVisibilityChange
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_LANGUAGE_CHANGE,
            this.props.gameLiveLanguageChange
        );
        eventBus.on(
            ActionIdentifiers.GAME_EMAIL_GET_GAME_NOTES,
            this.props.gameEmailGameGetNotes
        );
        eventBus.on(
            ActionIdentifiers.GAME_EMAIL_SET_GAME_NOTES,
            this.props.gameEmailGameSetNotes
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_DELETE_HOSTED_GAME,
            this.props.gameLiveGameDeleteHostedGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_GAME_SEND_GAME_START_DATA,
            this.props.gameSoloGameSendStartData
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED,
            this.props.gameLiveGameOnlinePlayerListSortCriteriaChanged
        );
        eventBus.on(
            ActionIdentifiers.GAME_SOLO_GAME_CURRENT_HINT_DATA,
            this.props.gameSoloGameCurrentHintData
        );
        eventBus.on(
            ActionIdentifiers.GAME_ANALYSE_CURRENT_POSITION_CHANGED,
            this.props.gameAnalyseCurrentPositionChanged
        );
        eventBus.on(
            ActionIdentifiers.GAME_HINT_WORD_LIST_READY,
            this.props.gameHintWordListReady
        );
        eventBus.on(
            ActionIdentifiers.GAME_SET_NOTES_FAILED,
            this.props.gameEmailGameSetNotesFailed
        );
        eventBus.on(
            ActionIdentifiers.GAME_SET_NOTES_STARTED,
            this.props.gameEmailGameSetNotesStarted
        );
        eventBus.on(
            ActionIdentifiers.GAME_ANALYSE_DATA_READY,
            this.props.gameAnalyseDataReady
        );
        eventBus.on(
            ActionIdentifiers.CONFIG_SETTINGS_RETRIEVED,
            this.props.configSettingsRetrieved
        );
        eventBus.on(
            ActionIdentifiers.CONFIG_SET_MENU_VISIBILITY,
            this.props.configMenuVisibiltyChanged
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_USER_STATS_FETCHED,
            this.props.gameLiveGameUserStatsFetched
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_HOST_PARAMS_SET,
            this.props.gameLiveGameHostParamsSet
        );
        eventBus.on(
            ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
            this.props.gameSideLayoutActiveTabSet
        );
        eventBus.on(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_GAME_RESTART_DATA_SET,
            this.props.gameNormalGamePlayOptionsShowRobotsSet
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_LOST,
            this.props.connectivityChanged
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
            this.props.connectivityReducerConnectionReestablished
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
            this.props.connectivityReducerConnectionReconnecting
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_SENSOR_LIST_RETRIEVED,
            this.props.gameLiveGameSSensorListRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_BUDDY_REQ_LIST_RETRIEVED,
            this.props.gameLiveBuddyReqListRetrieved
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_BUDDY_LIST,
            this.props.gameLiveGameBuddyList
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_SET_TILE,
            this.props.celReducerPlaceTile
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_UPDATE_BOARD_STRUCTURE,
            this.props.cellReducerResetBoardStructure
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_HIDE_TILE,
            this.props.cellReducerHideTile
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_SET_DIRECTION,
            this.props.cellReducerSetHasDirection
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_CLEAR_DIRECTION,
            this.props.cellReducerClearDirection
        );
        eventBus.on(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET,
            this.props.gameNormalGamePlayOptionsShowRobotsSet
        );
        eventBus.on(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_GAME_LIST,
            this.props.gameNormalGamePlayOptionsShowSetGameList
        );
        eventBus.on(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST,
            this.props.gameNormalGamePlayOptionsShowSetMobileGameList
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL,
            this.props.gameLiveGameMoreTimeRequestSuccessful
        );
        eventBus.on(
            ActionIdentifiers.CONFIG_SET_SETTING,
            this.props.configReduceerSetSetting
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_EMPTY_GAMEBOARD,
            this.props.cellReducerEmptyGameboard
        );
        eventBus.on(
            ActionIdentifiers.CONFIG_SETTINGS_CHANGED,
            this.props.configReducerSettingsChanged
        );
        eventBus.on(
            ActionIdentifiers.GAME_PAGE_VISIBILITY_CHANGED,
            this.props.gamePageVisibilityChanged
        );
        eventBus.on(
            ActionIdentifiers.GAME_SET_PLAYER_SELF_CURRENT_SCORE,
            this.props.gameSetPlayerSelfCurrentScore
        );
        eventBus.on(
            ActionIdentifiers.GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
            this.props.gameChallengeGameSetPreviousTurn
        );
        eventBus.on(ActionIdentifiers.RELOAD_APP, this.props.reloadApp);
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_UPDATE_CELL,
            this.props.celReducerUpdateCell
        );
        eventBus.on(
            ActionIdentifiers.GAME_REDUCER_UPDATE_TILES,
            this.props.gameReducerUpdateTiles
        );
        eventBus.on(
            ActionIdentifiers.GAME_SHOW_PLAY_BUTTON_LOADER,
            this.props.gamePlayButtonShowLoader
        );
        eventBus.on(
            ActionIdentifiers.GAME_PLAY_BUTTON_SCORE_TEXT,
            this.props.gamePlayButtonSetScoreText
        );
        eventBus.on(
            ActionIdentifiers.GAME_TILE_BEING_DRAGGED,
            this.props.gameTileBeingDragged
        );
        eventBus.on(
            ActionIdentifiers.GAME_BOARD_PUZZLE_RECEIVED,
            this.props.gameBoardPuzzleReceived
        );
        eventBus.on(
            ActionIdentifiers.GAME_INITIALISE_TILES_FOR_CREATE_BOARD,
            this.props.gameInitialiseTilesForCreateBoard
        );
        eventBus.on(
            ActionIdentifiers.UPDATE_TILES_AND_SET_CELL,
            this.props.updateTilesAndCells
        );
        eventBus.on(
            ActionIdentifiers.CELL_REDUCER_ON_TILE_CLICKED,
            this.props.cellReducerOnTileClicked
        );
        eventBus.on(
            ActionIdentifiers.REDUCER_ON_TILE_REMOVED,
            this.props.reducerOnTileRemoved
        );
        eventBus.on(
            ActionIdentifiers.REDUCER_UPDATE_BLANK_TILE_LETTER,
            this.props.reducerUpdateBlankTileLetter
        );
        eventBus.on(
            ActionIdentifiers.REDUCER_UPDATE_MOUSE_MOVE_TILE,
            this.props.reducerUpdateMouseMovetile
        );
        eventBus.on(
            ActionIdentifiers.CHAT_CLEAR_LIST,
            this.props.clearMessageList
        );
        eventBus.on(
            ActionIdentifiers.SET_ACTIVE_PVT_MESSAGE_KEY,
            this.props.setActivePvtMessageKey
        );
        eventBus.on(
            ActionIdentifiers.ADD_PVT_MESSAGE_KEY,
            this.props.addPvtMessageKey
        );
        eventBus.on(
            ActionIdentifiers.REMOVE_PVT_MESSAGE_KEY,
            this.props.removePvtMessageKey
        );
        eventBus.on(
            ActionIdentifiers.LAYOUT_REDUCER_SET_FIELD,
            this.props.layoutReducerSetField
        );
        eventBus.on(
            ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE,
            this.props.gameReducerUpdateGametype
        );
        eventBus.on(
            ActionIdentifiers.GAME_REDUCER_UNSET_GAME_RESTART_DATA,
            this.props.gameReducerUnserGameRestartData
        );
        eventBus.on(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
            this.props.connectivityReducerCheckAndSetConnectivity
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
            this.props.joinHostedGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_JOINED_PLAYER_STATS,
            this.props.hostJoinedPlayerStats
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_JOIN_DIALOG,
            this.props.hostJoinDialog
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS,
            this.props.addHostGameHeadToHeadStat
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT,
            this.props.addHostGameUniqueWordCount
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_RATING_CHANGE,
            this.props.addHostGameRatingChange
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME,
            this.props.reqJoinHostGame
        );
        eventBus.on(
            ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT,
            this.props.reqJoinHostGameReject
        );
        eventBus.on(
            ActionIdentifiers.TILE_REDUCER_SET_HOVERING_CELL,
            this.props.tileReducerSetHoveringTile
        );
        eventBus.on(
            ActionIdentifiers.GAME_REDUCER_SET_MOVE_STRENGTH,
            this.props.gameReducerSetMoveStrength
        );
        eventBus.on(
            ActionIdentifiers.DIMENSION_SCREEN_RESIZE,
            this.props.screenResized
        );
        eventBus.on(
            ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET,
            this.props.gameSideLayoutActiveTabReset
        );
        eventBus.on(
            ActionIdentifiers.GAME_BLITZ_JNDPLYS_UPDATE,
            this.props.gameBlitzJndPlysUpdate
        );
        eventBus.on(
            ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE,
            this.props.gameBlitzJndPlyRemove
        );
        eventBus.on(
            ActionIdentifiers.GAME_BLITZ_INP_GAMEOVER,
            this.props.gameBlitzInpGameOver
        );
        eventBus.on(
            ActionIdentifiers.GAME_HAS_ENDED_ON_GAMEOVER,
            this.props.gameHasEnded
        );
    };

    componentWillUnmount = () => {
        eventBus.detach(
            ActionIdentifiers.CHAT_APPEND_LIST_ITEM,
            this.props.appendToMessageList
        );
        eventBus.detach(
            ActionIdentifiers.CHAT_APPEND_LIST_ITEM_MORE_TIME,
            this.props.appendToMessageListMoreTime
        );
        eventBus.detach(
            ActionIdentifiers.LOBBY_CHAT_MESSAGE,
            this.props.lobbyChatMessage
        );
        eventBus.detach(ActionIdentifiers.GAME_HAS_ENDED, this.props.gameOver);
        eventBus.detach(ActionIdentifiers.GAME_STARTED, this.props.gameStarted);
        eventBus.detach(ActionIdentifiers.GAME_MOVE, this.props.gameMove);
        eventBus.detach(
            ActionIdentifiers.GAME_MOVE_COUNT_SET,
            this.props.gameMoveCountSet
        );
        eventBus.detach(
            ActionIdentifiers.GAME_MOVE_FURTHER_DATA_SHOW_LOADER,
            this.props.gameMoveFurtherDataShowLoader
        );
        eventBus.detach(
            ActionIdentifiers.GAME_MOVE_FURTHER_DATA_HIDE_LOADER,
            this.props.gameMoveFurtherDataHideLoader
        );
        eventBus.detach(
            ActionIdentifiers.GAME_WORD_DEFINITIONS,
            this.props.gameWordDefinitions
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED,
            this.props.gamePuzzleLastGameStatusesRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED,
            this.props.gamePuzzlePuzzleRankingsRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY,
            this.props.gamePuzzleMoveSentSuccessfully
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PUZZLE_PASS_SENT_SUCCESSFULLY,
            this.props.gamePuzzlePassSentSuccessfully
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PLAY_BUTTON_WORD_VALIDITY,
            this.props.setPlayButtonWordValidity
        );
        eventBus.detach(
            ActionIdentifiers.GAME_RESOURCE_PANEL_WORD_VALIDITY,
            this.props.setResourcePanelWordValidity
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_ROOM_ADD_OBSERVER,
            this.props.gameAddObserver
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_ROOM_REMOVE_OBSERVER,
            this.props.gameRemoveObserver
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_ROOM_LOGIN,
            this.props.gameLiveGameLogin
        );
        eventBus.detach(
            ActionIdentifiers.GAME_HAS_ACTIVE_GAME_EVENT,
            this.props.gameHasLiveGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED,
            this.props.gameLiveGameInvitationReceived
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
            this.props.gameLiveMultiplayerHostGameLeave
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_ADD_HOSTED_GAME,
            this.props.gameLiveAddHostedGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_DELETE_HOSTED_GAME,
            this.props.gameLiveDeleteHostedGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_GAME_ACTION,
            this.props.gameLiveGameHost
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE,
            this.props.connectivityReducerGameDuplicateConnectionOccurrence
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_RESTART_SERVER,
            this.props.connectivityReducerRestartServer
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_CLEAR_INVITATION,
            this.props.gameLiveGameClearInvitation
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_GET_ONLINE_STATUS,
            this.props.gameLiveGameGetOnlineStatus
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SET_PLAYER_COUNT,
            this.props.gameSetPlayerCount
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED,
            this.props.gameLiveGameHostedGamesListRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_GAME_LOGIN,
            this.props.gameSoloGameLogin
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_NEW_GAME,
            this.props.gameSoloNewGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SAVED_RULES,
            this.props.gameSoloSavedRules
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_GET_RANDOM_BOARD,
            this.props.gameSoloGetRandomBoard
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_RESET_CREATE_BOARD,
            this.props.gameSoloResetBoard
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SET_BOARD_DISABLE,
            this.props.gameSoloSetBoardDisable
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_RESET_RESUME_GAME,
            this.props.gameSoloResetResumeGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_RESET_SLOT_DATA,
            this.props.gameSoloResetSlotData
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_CREATE_GAME_DATA,
            this.props.gameSoloCreateGameData
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_MENU_SHOW_HIDE,
            this.props.gameSoloMenuShowHide
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SET_CURRENT_MENU_OPT,
            this.props.gameSoloSetCurrentMenuOpt
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SET_FORM_TYPE,
            this.props.gameSoloSetFormType
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SET_FORM_DATA,
            this.props.gameSoloSetFormData
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_SET_NO_LOGIN_DATA,
            this.props.gameSoloSetNoLoginData
        );
        eventBus.detach(
            ActionIdentifiers.SET_SERVER_TIME_DIFFERENCE,
            this.props.setServerTimeDifference
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE,
            this.props.gameLiveGameOnlinePlayerListAvailable
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED,
            this.props.gameLiveGameObservableGamesListRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_OBSERVABLE_GAME_REMOVE,
            this.props.gameLiveObservableGameRemove
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_PAGE_VISIBILITY_CHANGE,
            this.props.gameLivePageVisibilityChange
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_LANGUAGE_CHANGE,
            this.props.gameLiveLanguageChange
        );
        eventBus.detach(
            ActionIdentifiers.GAME_EMAIL_GET_GAME_NOTES,
            this.props.gameEmailGameGetNotes
        );
        eventBus.detach(
            ActionIdentifiers.GAME_EMAIL_SET_GAME_NOTES,
            this.props.gameEmailGameSetNotes
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_DELETE_HOSTED_GAME,
            this.props.gameLiveGameDeleteHostedGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_GAME_SEND_GAME_START_DATA,
            this.props.gameSoloGameSendStartData
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED,
            this.props.gameLiveGameOnlinePlayerListSortCriteriaChanged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SOLO_GAME_CURRENT_HINT_DATA,
            this.props.gameSoloGameCurrentHintData
        );
        eventBus.detach(
            ActionIdentifiers.GAME_ANALYSE_CURRENT_POSITION_CHANGED,
            this.props.gameAnalyseCurrentPositionChanged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_HINT_WORD_LIST_READY,
            this.props.gameHintWordListReady
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SET_NOTES_FAILED,
            this.props.gameEmailGameSetNotesFailed
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SET_NOTES_STARTED,
            this.props.gameEmailGameSetNotesStarted
        );
        eventBus.detach(
            ActionIdentifiers.GAME_ANALYSE_DATA_READY,
            this.props.gameAnalyseDataReady
        );
        eventBus.detach(
            ActionIdentifiers.CONFIG_SETTINGS_RETRIEVED,
            this.props.configSettingsRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.CONFIG_SET_MENU_VISIBILITY,
            this.props.configMenuVisibiltyChanged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_USER_STATS_FETCHED,
            this.props.gameLiveGameUserStatsFetched
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_HOST_PARAMS_SET,
            this.props.gameLiveGameHostParamsSet
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
            this.props.gameSideLayoutActiveTabSet
        );
        eventBus.detach(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_GAME_RESTART_DATA_SET,
            this.props.gameNormalGamePlayOptionsShowRobotsSet
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_LOST,
            this.props.connectivityChanged
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
            this.props.connectivityReducerConnectionReestablished
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
            this.props.connectivityReducerConnectionReconnecting
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_SENSOR_LIST_RETRIEVED,
            this.props.gameLiveGameSSensorListRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_BUDDY_REQ_LIST_RETRIEVED,
            this.props.gameLiveBuddyReqListRetrieved
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_BUDDY_LIST,
            this.props.gameLiveGameBuddyList
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_SET_TILE,
            this.props.celReducerPlaceTile
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_UPDATE_BOARD_STRUCTURE,
            this.props.cellReducerResetBoardStructure
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_HIDE_TILE,
            this.props.cellReducerHideTile
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_SET_DIRECTION,
            this.props.cellReducerSetHasDirection
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_CLEAR_DIRECTION,
            this.props.cellReducerClearDirection
        );
        eventBus.detach(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET,
            this.props.gameNormalGamePlayOptionsShowRobotsSet
        );
        eventBus.detach(
            ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST,
            this.props.gameNormalGamePlayOptionsShowSetMobileGameList
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL,
            this.props.gameLiveGameMoreTimeRequestSuccessful
        );
        eventBus.detach(
            ActionIdentifiers.CONFIG_SET_SETTING,
            this.props.configReduceerSetSetting
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_EMPTY_GAMEBOARD,
            this.props.cellReducerEmptyGameboard
        );
        eventBus.detach(
            ActionIdentifiers.CONFIG_SETTINGS_CHANGED,
            this.props.configReducerSettingsChanged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PAGE_VISIBILITY_CHANGED,
            this.props.gamePageVisibilityChanged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SET_PLAYER_SELF_CURRENT_SCORE,
            this.props.gameSetPlayerSelfCurrentScore
        );
        eventBus.detach(
            ActionIdentifiers.GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
            this.props.gameChallengeGameSetPreviousTurn
        );
        eventBus.detach(ActionIdentifiers.RELOAD_APP, this.props.reloadApp);
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_UPDATE_CELL,
            this.props.celReducerUpdateCell
        );
        eventBus.detach(
            ActionIdentifiers.GAME_REDUCER_UPDATE_TILES,
            this.props.gameReducerUpdateTiles
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SHOW_PLAY_BUTTON_LOADER,
            this.props.gamePlayButtonShowLoader
        );
        eventBus.detach(
            ActionIdentifiers.GAME_PLAY_BUTTON_SCORE_TEXT,
            this.props.gamePlayButtonSetScoreText
        );
        eventBus.detach(
            ActionIdentifiers.GAME_TILE_BEING_DRAGGED,
            this.props.gameTileBeingDragged
        );
        eventBus.detach(
            ActionIdentifiers.GAME_BOARD_PUZZLE_RECEIVED,
            this.props.gameBoardPuzzleReceived
        );
        eventBus.detach(
            ActionIdentifiers.GAME_INITIALISE_TILES_FOR_CREATE_BOARD,
            this.props.gameInitialiseTilesForCreateBoard
        );
        eventBus.detach(
            ActionIdentifiers.UPDATE_TILES_AND_SET_CELL,
            this.props.updateTilesAndCells
        );
        eventBus.detach(
            ActionIdentifiers.CELL_REDUCER_ON_TILE_CLICKED,
            this.props.cellReducerOnTileClicked
        );
        eventBus.detach(
            ActionIdentifiers.REDUCER_ON_TILE_REMOVED,
            this.props.reducerOnTileRemoved
        );
        eventBus.detach(
            ActionIdentifiers.REDUCER_UPDATE_BLANK_TILE_LETTER,
            this.props.reducerUpdateBlankTileLetter
        );
        eventBus.detach(
            ActionIdentifiers.REDUCER_UPDATE_MOUSE_MOVE_TILE,
            this.props.reducerUpdateMouseMovetile
        );
        eventBus.detach(
            ActionIdentifiers.CHAT_CLEAR_LIST,
            this.props.clearMessageList
        );
        eventBus.detach(
            ActionIdentifiers.SET_ACTIVE_PVT_MESSAGE_KEY,
            this.props.setActivePvtMessageKey
        );
        eventBus.detach(
            ActionIdentifiers.ADD_PVT_MESSAGE_KEY,
            this.props.addPvtMessageKey
        );
        eventBus.detach(
            ActionIdentifiers.REMOVE_PVT_MESSAGE_KEY,
            this.props.removePvtMessageKey
        );
        eventBus.detach(
            ActionIdentifiers.LAYOUT_REDUCER_SET_FIELD,
            this.props.layoutReducerSetField
        );
        eventBus.detach(
            ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE,
            this.props.gameReducerUpdateGametype
        );
        eventBus.detach(
            ActionIdentifiers.GAME_REDUCER_UNSET_GAME_RESTART_DATA,
            this.props.gameReducerUnserGameRestartData
        );
        eventBus.detach(
            ActionIdentifiers.CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
            this.props.connectivityReducerCheckAndSetConnectivity
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
            this.props.joinHostedGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_JOINED_PLAYER_STATS,
            this.props.hostJoinedPlayerStats
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_JOIN_DIALOG,
            this.props.hostJoinDialog
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS,
            this.props.addHostGameHeadToHeadStat
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT,
            this.props.addHostGameUniqueWordCount
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_HOST_ADD_RATING_CHANGE,
            this.props.addHostGameRatingChange
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME,
            this.props.reqJoinHostGame
        );
        eventBus.detach(
            ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT,
            this.props.reqJoinHostGameReject
        );
        eventBus.detach(
            ActionIdentifiers.TILE_REDUCER_SET_HOVERING_CELL,
            this.props.tileReducerSetHoveringTile
        );
        eventBus.detach(
            ActionIdentifiers.GAME_REDUCER_SET_MOVE_STRENGTH,
            this.props.gameReducerSetMoveStrength
        );
        eventBus.detach(
            ActionIdentifiers.DIMENSION_SCREEN_RESIZE,
            this.props.screenResized
        );
        eventBus.detach(
            ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET,
            this.props.gameSideLayoutActiveTabReset
        );
        eventBus.detach(
            ActionIdentifiers.GAME_BLITZ_JNDPLYS_UPDATE,
            this.props.gameBlitzJndPlysUpdate
        );
        eventBus.detach(
            ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE,
            this.props.gameBlitzJndPlyRemove
        );
        eventBus.detach(
            ActionIdentifiers.GAME_BLITZ_INP_GAMEOVER,
            this.props.gameBlitzInpGameOver
        );
        eventBus.detach(
            ActionIdentifiers.GAME_HAS_ENDED_ON_GAMEOVER,
            this.props.gameHasEnded
        );
    };
}

const mapStateToProps = (state) => state;

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            appendToMessageList: ChatActions.appendToMessageList,
            appendToMessageListMoreTime:
                ChatActions.appendToMessageListMoreTime,
            lobbyChatMessage: LobbyChatActions.lobbyChatMessage,
            gameStarted: GameActions.gameStarted,
            gameMove: GameActions.gameMove,
            gameMoveCountSet: GameActions.gameMoveCountSet,
            gameOver: GameOverActions.gameOver,
            gameMoveFurtherDataShowLoader:
                GameActions.gameMoveFurtherDataShowLoader,
            gameMoveFurtherDataHideLoader:
                GameActions.gameMoveFurtherDataHideLoader,
            gameWordDefinitions: GameActions.gameWordDefinitions,
            gamePuzzleLastGameStatusesRetrieved:
                GameActions.gamePuzzleLastGameStatusesRetrieved,
            gamePuzzlePuzzleRankingsRetrieved:
                GameActions.gamePuzzlePuzzleRankingsRetrieved,
            gamePuzzleMoveSentSuccessfully:
                GameActions.gamePuzzleMoveSentSuccessfully,
            gamePuzzlePassSentSuccessfully:
                GameActions.gamePuzzlePassSentSuccessfully,
            setResourcePanelWordValidity:
                GameActions.setResourcePanelWordValidity,
            setPlayButtonWordValidity: GameActions.setPlayButtonWordValidity,
            gameAddObserver: GameActions.gameAddObserver,
            gameRemoveObserver: GameActions.gameRemoveObserver,
            gameLiveGameLogin: GameActions.gameLiveGameLogin,
            gameHasLiveGame: GameActions.gameHasLiveGame,
            gameLiveGameInvitationReceived:
                GameActions.gameLiveGameInvitationReceived,
            gameLiveMultiplayerHostGameLeave:
                GameActions.gameLiveMultiplayerHostGameLeave,
            gameLiveAddHostedGame: GameActions.gameLiveAddHostedGame,
            gameLiveDeleteHostedGame: GameActions.gameLiveDeleteHostedGame,
            gameLiveGameHost: GameActions.gameLiveGameHost,
            gameLiveGameCancelInvitation:
                GameActions.gameLiveGameCancelInvitation,
            gameLiveGameMoreTimeRequestSuccessful:
                GameActions.gameLiveGameMoreTimeRequestSuccessful,
            gameLiveGameClearInvitation:
                GameActions.gameLiveGameClearInvitation,
            gameLiveGameGetOnlineStatus:
                GameActions.gameLiveGameGetOnlineStatus,
            gameSetPlayerCount: GameActions.gameSetPlayerCount,
            gameLiveGameHostedGamesListRetrieved:
                GameActions.gameLiveGameHostedGamesListRetrieved,
            gameSoloSetNoLoginData: GameActions.gameSoloSetNoLoginData,
            gameSoloGameLogin: SoloActions.gameSoloGameLogin,
            gameSoloNewGame: SoloActions.gameSoloNewGame,
            gameSoloSavedRules: SoloActions.gameSoloSavedRules,
            gameSoloGetRandomBoard: SoloActions.gameSoloGetRandomBoard,
            gameSoloResetBoard: SoloActions.gameSoloResetBoard,
            gameSoloSetBoardDisable: SoloActions.gameSoloSetBoardDisable,
            gameSoloResetResumeGame: SoloActions.gameSoloResetResumeGame,
            gameSoloResetSlotData: SoloActions.gameSoloResetSlotData,
            gameSoloCreateGameData: SoloActions.gameSoloCreateGameData,
            gameSoloMenuShowHide: SoloActions.gameSoloMenuShowHide,
            gameSoloSetCurrentMenuOpt: SoloActions.gameSoloSetCurrentMenuOpt,
            gameSoloSetFormType: SoloActions.gameSoloSetFormType,
            gameSoloSetFormData: SoloActions.gameSoloSetFormData,
            setServerTimeDifference: ConfigActions.setServerTimeDifference,
            gameLiveGameOnlinePlayerListAvailable:
                GameActions.gameLiveGameOnlinePlayerListAvailable,
            gameLiveGameObservableGamesListRetrieved:
                GameActions.gameLiveGameObservableGamesListRetrieved,
            gameLiveObservableGameRemove:
                GameActions.gameLiveObservableGameRemove,
            gameLivePageVisibilityChange:
                GameActions.gameLivePageVisibilityChange,
            gameLiveLanguageChange: GameActions.gameLiveLanguageChange,
            gameEmailGameGetNotes: GameActions.gameEmailGameGetNotes,
            gameEmailGameSetNotes: GameActions.gameEmailGameSetNotes,
            gameLiveGameDeleteHostedGame:
                GameActions.gameLiveGameDeleteHostedGame,
            gameSoloGameSendStartData: GameActions.gameSoloGameSendStartData,
            gameLiveGameOnlinePlayerListSortCriteriaChanged:
                GameActions.gameLiveGameOnlinePlayerListSortCriteriaChanged,
            gameSoloGameCurrentHintData:
                GameActions.gameSoloGameCurrentHintData,
            gameAnalyseDataReady: GameActions.gameAnalyseDataReady,
            gameAnalyseCurrentPositionChanged:
                GameActions.gameAnalyseCurrentPositionChanged,
            gameHintWordListReady: GameActions.gameHintWordListReady,
            gameEmailGameSetNotesFailed:
                GameActions.gameEmailGameSetNotesFailed,
            gameEmailGameSetNotesStarted:
                GameActions.gameEmailGameSetNotesStarted,
            configSettingsRetrieved: ConfigActions.configSettingsRetrieved,
            configMenuVisibiltyChanged:
                ConfigActions.configMenuVisibiltyChanged,
            gameLiveGameUserStatsFetched:
                GameActions.gameLiveGameUserStatsFetched,
            gameLiveGameHostParamsSet: GameActions.gameLiveGameHostParamsSet,
            gameSideLayoutActiveTabSet: GameActions.gameSideLayoutActiveTabSet,
            gameNormalGamePlayOptionsShowRobotsSet:
                GameActions.gameNormalGamePlayOptionsShowRobotsSet,
            gameNormalGamePlayOptionsShowSetGameList:
                GameActions.gameNormalGamePlayOptionsShowSetGameList,
            gameNormalGamePlayOptionsShowSetMobileGameList:
                GameActions.gameNormalGamePlayOptionsShowSetMobileGameList,
            gameLiveGameRestartDataSet: GameActions.gameLiveGameRestartDataSet,
            connectivityChanged: ConnectivityActions.connectivityChanged,
            connectivityReducerGameDuplicateConnectionOccurrence:
                ConnectivityActions.connectivityReducerGameDuplicateConnectionOccurrence,
            connectivityReducerConnectionReestablished:
                ConnectivityActions.connectivityReducerConnectionReestablished,
            connectivityReducerConnectionReconnecting:
                ConnectivityActions.connectivityReducerConnectionReconnecting,
            connectivityReducerRestartServer:
                ConnectivityActions.connectivityReducerRestartServer,
            gameLiveGameSSensorListRetrieved:
                GameActions.gameLiveGameSSensorListRetrieved,
            gameLiveBuddyReqListRetrieved:
                GameActions.gameLiveBuddyReqListRetrieved,
            gameLiveGameBuddyList: GameActions.gameLiveGameBuddyList,
            celReducerPlaceTile: CellActions.celReducerPlaceTile,
            cellReducerResetBoardStructure:
                CellActions.cellReducerResetBoardStructure,
            cellReducerHideTile: CellActions.cellReducerHideTile,
            cellReducerSetHasDirection: CellActions.cellReducerSetHasDirection,
            cellReducerClearDirection: CellActions.cellReducerClearDirection,
            configReduceerSetSetting: ConfigActions.configReduceerSetSetting,
            cellReducerEmptyGameboard: CellActions.cellReducerEmptyGameboard,
            configReducerSettingsChanged:
                ConfigActions.configReducerSettingsChanged,
            gamePageVisibilityChanged: GameActions.gamePageVisibilityChanged,
            gameSetPlayerSelfCurrentScore:
                GameActions.gameSetPlayerSelfCurrentScore,
            gameChallengeGameSetPreviousTurn:
                GameActions.gameChallengeGameSetPreviousTurn,
            reloadApp: GameActions.reloadApp,
            celReducerUpdateCell: CellActions.celReducerUpdateCell,
            gameReducerUpdateTiles: GameActions.gameReducerUpdateTiles,
            gamePlayButtonShowLoader: GameActions.gamePlayButtonShowLoader,
            gamePlayButtonSetScoreText: GameActions.gamePlayButtonSetScoreText,
            gameTileBeingDragged: GameActions.gameTileBeingDragged,
            gameBoardPuzzleReceived: GameActions.gameBoardPuzzleReceived,
            gameInitialiseTilesForCreateBoard:
                GameActions.gameInitialiseTilesForCreateBoard,
            updateTilesAndCells: GameActions.updateTilesAndCells,
            cellReducerOnTileClicked: CellActions.cellReducerOnTileClicked,
            reducerOnTileRemoved: GameActions.reducerOnTileRemoved,
            reducerUpdateBlankTileLetter:
                CellActions.reducerUpdateBlankTileLetter,
            reducerUpdateMouseMovetile: CellActions.reducerUpdateMouseMovetile,
            clearMessageList: ChatActions.clearMessageList,
            setActivePvtMessageKey: LobbyChatActions.setActivePvtMessageKey,
            addPvtMessageKey: LobbyChatActions.addPvtMessageKey,
            removePvtMessageKey: LobbyChatActions.removePvtMessageKey,
            layoutReducerSetField: LayoutActions.layoutReducerSetField,
            gameReducerUpdateGametype: GameActions.gameReducerUpdateGametype,
            gameReducerUnserGameRestartData:
                GameActions.gameReducerUnserGameRestartData,
            connectivityReducerCheckAndSetConnectivity:
                ConfigActions.connectivityReducerCheckAndSetConnectivity,
            joinHostedGame: GameActions.joinHostedGame,
            hostJoinedPlayerStats: GameActions.hostJoinedPlayerStats,
            hostJoinDialog: GameActions.hostJoinDialog,
            addHostGameHeadToHeadStat: GameActions.addHostGameHeadToHeadStat,
            addHostGameUniqueWordCount: GameActions.addHostGameUniqueWordCount,
            addHostGameRatingChange: GameActions.addHostGameRatingChange,
            reqJoinHostGame: GameActions.reqJoinHostGame,
            reqJoinHostGameReject: GameActions.reqJoinHostGameReject,
            tileReducerSetHoveringTile: GameActions.tileReducerSetHoveringTile,
            gameReducerSetMoveStrength: GameActions.gameReducerSetMoveStrength,
            screenResized: DimensionActions.screenResized,
            gameSideLayoutActiveTabReset:
                GameActions.gameSideLayoutActiveTabReset,
            gameBlitzJndPlysUpdate: GameActions.gameBlitzJndPlysUpdate,
            gameBlitzJndPlyRemove: GameActions.gameBlitzJndPlyRemove,
            gameBlitzInpGameOver: GameActions.gameBlitzInpGameOver,
            gameHasEnded: GameActions.gameHasEnded,
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TemporaryEventReceiver);
