// @flow

export const UPDATE_MINSTATS: string = 'UPDATE_MINSTATS';
export const CLR_MINSTATS: string = 'CLR_MINSTATS';
