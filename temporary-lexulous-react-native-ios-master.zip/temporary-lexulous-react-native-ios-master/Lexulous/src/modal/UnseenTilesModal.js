import React from 'react';
import Config from '../configs/Config';
import { StyleSheet, TouchableOpacity, Pressable, View } from 'react-native';
import GameBoardUtils, { getDictionaryDetails } from '../utils/GameBoardUtils';
import ColorConfig from '../configs/ColorConfig';
import Grid from '../component/Grid';
import LayoutUtils from '../utils/LayoutUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import toInteger from 'lodash/toInteger';
import DimensionUtils from '../utils/DimensionUtils';
import { connect } from 'react-redux';
import get from 'lodash/get';
import PText from '../component/PText';
import S22Text from '../component/S22Text';
import S14Text from '../component/S14Text';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

class UnseenTilesModal extends React.Component {
    state = {
        isOpen: false,
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
    };
    componentDidMount = () => {
        eventBus.on(Config.SHOW_UNSEEN_TILES_DIALOG, this.onShow);
    };
    componentWillUnmount = () => {
        eventBus.detach(Config.SHOW_UNSEEN_TILES_DIALOG, this.onShow);
    };
    onShow = () => {
        this.setState({
            isOpen: true,
        });
    };

    getTilesInBagNumber = () => this.props.game.unseenTileCount;

    getVowelCount = () =>
        !isNaN(this.props.game.unseenVowelCount)
            ? this.props.game.unseenVowelCount || 0
            : 0;

    getVowelPercentage = () =>
        Math.round(
            (this.getVowelCount() * 100) / (this.getTilesInBagNumber() || 1)
        );

    getTilesInBag = () =>
        this.getTilesInBagNumber() +
        ' unseen ' +
        (Number(this.getTilesInBagNumber()) !== 1 ? 'tiles' : 'tile') +
        ', ' +
        this.getVowelPercentage() +
        '% Vowels';

    onClose = () => {
        let wasOpen = this.state.isOpen;
        this.setState({ isOpen: false });
        return wasOpen;
    };
    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onClose();
    };
    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };
    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: DimensionUtils.isMobile() ? '90%' : '60%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    render = () =>
        this.state.isOpen ? (
            <View
                key={'unseen_tiles_container'}
                style={this.getModalContentStyle()}
            >
                <View
                    key={'unseen_tiles_view_1'}
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                    ]}
                >
                    <View
                        key={'unseen_tiles_view_2'}
                        style={LayoutUtils.getDialogTitleContainerStyle()}
                    >
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                            {this.getTilesInBag()}
                        </S22Text>

                        <TouchableOpacity
                            style={styles.closeButtonContainer}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <View
                                key={'unseen_tiles_view_3'}
                                style={[
                                    {
                                        backgroundColor:
                                            this.state.closeBGColor,
                                    },
                                    LayoutUtils.getDialogCloseButtonBGStyle(),
                                ]}
                            >
                                <FontAwesomeIcon
                                    icon={faTimes}
                                    size={DimensionUtils.isMobile() ? 20 : 24}
                                    style={this.getCloseButtonStyle()}
                                />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View
                        key={'unseen_tiles_view_4'}
                        style={LayoutUtils.getDialogBodyContainerStyle()}
                    >
                        {this.renderRemainingTilesDistributionStyle()}
                        <S22Text
                            style={[
                                LayoutUtils.getDialogTitleStyle(),
                                styles.letterPointMargin,
                            ]}
                        >
                            {'Letter points'}
                        </S22Text>
                        {this.renderLetterPointView()}
                    </View>

                    <View
                        key={'unseen_tiles_view_5'}
                        style={LayoutUtils.getDialogBodyBtnContainerStyle()}
                    >
                        <Pressable
                            style={[
                                LayoutUtils.getDialogActionButtonStyle(),
                                LayoutUtils.getBottonStyle(),
                            ]}
                            onPress={this.onClose}
                        >
                            <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                {'OK'}
                            </S14Text>
                        </Pressable>
                    </View>
                </View>
            </View>
        ) : null;

    getLetterPoints = () => {
        switch (getDictionaryDetails(this.props.game.dic).lang) {
            case 'us_en':
            case 'uk_en':
                return (
                    this.props.game.letterScoreInfo ||
                    GameBoardUtils.ENGLISH_LETTER_SCORES
                );
            case 'fr':
                return (
                    this.props.game.letterScoreInfo ||
                    GameBoardUtils.FRENCH_LETTER_SCORES
                );
            case 'it':
                return (
                    this.props.game.letterScoreInfo ||
                    GameBoardUtils.ITALIAN_LETTER_SCORES
                );
        }
    };

    renderLetterPointView = () => {
        let dataArr = this.getLetterPoints().split('|');
        return (
            <Grid
                keyExtractor={(item, index) => index.toString()}
                renderItem={this.renderLetterPointStyleItem}
                renderPlaceholder={this._renderPlaceholder}
                data={dataArr.slice(0, 26) || []}
                numColumns={Config.UNSEEN_TILES_MODAL_COLUMN_COUNT}
                style={{
                    ...this.getGridDimension(),
                    ...styles.letterPointMargin,
                }}
            />
        );
    };

    getGridDimension = () => ({
        overflow: 'hidden',
        width: '100%',
        height: 'auto',
    });

    renderRemainingTilesDistributionStyle = () => (
        <Grid
            keyExtractor={(item, index) => index.toString()}
            renderItem={this.renderDistributionStyleItem}
            renderPlaceholder={this._renderPlaceholder}
            data={this.props.game.letterDistribution || []}
            numColumns={Config.UNSEEN_TILES_MODAL_COLUMN_COUNT}
            style={this.getGridDimension()}
        />
    );

    getDistributionItemStyles = (item) => ({
        backgroundColor: item.placed
            ? ColorConfig.UNSEEN_TILES_PLACED_TILES_BACKGROUND_COLOR
            : '#FFF',
        borderRightWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
    });
    setLeftBorderStyle = (key) =>
        toInteger(key) % Config.UNSEEN_TILES_MODAL_COLUMN_COUNT === 0
            ? { borderLeftWidth: StyleSheet.hairlineWidth }
            : null;
    setTopBorderStyle = (key) =>
        toInteger(key) < Config.UNSEEN_TILES_MODAL_COLUMN_COUNT
            ? { borderTopWidth: StyleSheet.hairlineWidth }
            : null;

    renderDistributionStyleItem = (item, key) => {
        return (
            <View
                key={key}
                style={[
                    styles.itemCenter,
                    styles.borderColor,
                    styles.cellWidth,
                    styles.cellPadding,
                    this.getDistributionItemStyles(item),
                    this.setLeftBorderStyle(key),
                    this.setTopBorderStyle(key),
                ]}
            >
                <PText>{String(item.letter)}</PText>
            </View>
        );
    };

    getTopBorderStyle = () => ({ borderTopWidth: StyleSheet.hairlineWidth });

    getBottomBorderStyle = () => ({
        borderBottomWidth: StyleSheet.hairlineWidth,
    });

    getRightBorderStyle = () => ({
        borderRightWidth: StyleSheet.hairlineWidth,
    });

    renderLetterPointStyleItem = (item, key) => {
        return (
            <View
                key={'unseen_tiles_letter_container_' + key}
                style={[
                    styles.cellWidth,
                    this.getRightBorderStyle(),
                    this.getBottomBorderStyle(),
                    this.setLeftBorderStyle(key),
                ]}
            >
                <View
                    key={'unseen_tiles_letter_' + key}
                    style={[
                        styles.itemCenter,
                        styles.borderColor,
                        styles.cellPadding,
                        styles.darkBG,
                        this.setTopBorderStyle(key),
                    ]}
                >
                    <PText>{String(item.split(',')[0])}</PText>
                </View>
                <View
                    key={'unseen_tiles_letter_value_' + key}
                    style={[
                        styles.itemCenter,
                        styles.cellPadding,
                        this.getTopBorderStyle(),
                    ]}
                >
                    <PText>{String(item.split(',')[1])}</PText>
                </View>
            </View>
        );
    };
}
const styles = StyleSheet.create({
    //Main Renders Styles
    modalContent: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
    },
    itemCenter: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    borderColor: {
        borderColor: '#000',
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
    letterPointMargin: {
        marginTop: 8,
    },
    cellWidth: {
        width: '7%',
        /* width:
            'calc(' +
            (100 / Number(Config.UNSEEN_TILES_MODAL_COLUMN_COUNT)).toFixed(1) +
            '% - 1px)', */
    },
    cellPadding: {
        padding: 3,
    },
    darkBG: {
        backgroundColor: ColorConfig.UNSEEN_TILES_PLACED_TILES_BACKGROUND_COLOR,
    },
});
const mapStateToProps = (state) => ({
    game: state.game,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    UnseenTilesModal
);
