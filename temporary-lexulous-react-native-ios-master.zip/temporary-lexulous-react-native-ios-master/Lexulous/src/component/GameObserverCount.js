import { faEye } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import { connect } from 'react-redux';
import get from 'lodash/get';
import TooltipWrapper from './TooltipWrapper';
import S14Text from './S14Text';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

class GameObserverCount extends React.Component {
    getObserversData = () => {
        const { observers } = this.props.game;
        const { onlinePlayerBuddies, onlinePlayerOthers } = this.props.user;

        let guids = typeof observers === 'undefined' ? [] : observers;
        let players = [];

        guids.forEach((v, i) => {
            let obj =
                onlinePlayerBuddies.find((value) => value.guid === v) ||
                onlinePlayerOthers.find((value) => value.guid === v);
            if (obj) {
                players.push(obj);
            }
        });

        this.reBuildTooltip();
        return players;
    };

    reBuildTooltip = () => {
        setTimeout(() => {
            TooltipActionWrapper.rebuild();
        }, 100);
    };

    render = () => {
        let observers = !!get(this.props, 'game.pid')
            ? this.getObserversData()
            : [];
        return observers.length > 0 ? (
            <View style={styles.observerCountViewStyle}>
                <S14Text style={styles.observerCountTextStyle}>
                    {(observers.length > 0 ? ', ' : '') + observers.length}
                </S14Text>
                <TooltipWrapper
                    tooltip={(observers || [])
                        .map((player) => player.name)
                        .join('<br>')}
                    multiline={true}
                    expTooltip={true}
                >
                    <FontAwesomeIcon
                        id={'observeicon'}
                        key={'observeicon'}
                        size={14}
                        style={styles.styleWatchIcon}
                        icon={faEye}
                    />
                </TooltipWrapper>
            </View>
        ) : null;
    };
}

const styles = StyleSheet.create({
    observerCountTextStyle: {
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        marginRight: 2,
        fontWeight: 'bold',
    },
    styleWatchIcon: {
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        paddingLeft: 2,
    },
    observerCountViewStyle: {
        flexDirection: 'row',
        alignItems: 'center',
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    user: state.user,
});

export default connect(mapStateToProps)(GameObserverCount);
