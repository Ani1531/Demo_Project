import chatReducer from '../reducers/ChatReducer';
import gameReducer from '../reducers/GameReducer';
import layoutReducer from '../reducers/LayoutReducer';
import soloReducer from '../reducers/SoloReducer';
import configReducer from '../reducers/ConfigReducer';
import cellReducer from '../reducers/CellReducer';
import lobbyChatReducer from '../reducers/LobbyChatReducer';
import tileReducer from '../reducers/TileReducer';
import userReducer from '../reducers/UserReducer';
import gamelistReducer from '../reducers/GameListReducer';
import tileDragReducer from '../reducers/TileDragReducer';
import store from '../store';
import { gameLiveBuddyReqListRetrieved, gameLiveGameBuddyList, gameLiveGameSSensorListRetrieved } from '../actions/GameActions';

export default class ServiceUtils {
    static getCommonReducers = () => ({
        chat: chatReducer,
        game: gameReducer,
        layout: layoutReducer,
        config: configReducer,
        solitaire: soloReducer,
        cells: cellReducer,
        lobbyChat: lobbyChatReducer,
        tiles: tileReducer,
        user: userReducer,
        gamelist: gamelistReducer,
        tileDrag: tileDragReducer,
    });

    static buddyListUpdate = (data) => {
        store.dispatch(gameLiveGameBuddyList(data));
    };

    static pendingRequestListUpdate = (data) => {
        store.dispatch(gameLiveBuddyReqListRetrieved(data));
    };

    static censorListUpdate = (data) => {
        store.dispatch(gameLiveGameSSensorListRetrieved(data));
    };
}
