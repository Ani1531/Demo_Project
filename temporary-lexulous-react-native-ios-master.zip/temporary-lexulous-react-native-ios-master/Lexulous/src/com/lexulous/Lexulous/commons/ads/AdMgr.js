// @flow

class AdMgr {
    adSdkInited: boolean = false;
    constructor() {}
    onAppInit = (): void => {};
}

const adMgr: AdMgr = new AdMgr();

export default adMgr;
