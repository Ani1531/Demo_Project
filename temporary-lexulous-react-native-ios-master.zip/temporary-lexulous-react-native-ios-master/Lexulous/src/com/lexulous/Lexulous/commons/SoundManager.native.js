// @flow

import Sound from 'react-native-sound';
import dataServer from '../store/Store';

class SoundManager {
    _soundFiles: Array<string> = [
        'bingo.mp3',
        'click.wav',
        'drop_tile.wav',
        'error.mp3',
        'game_start.mp3',
        'new_message.mp3',
        'notification.wav',
        'pick_tile.wav',
        'recall.mp3',
        'shuffle.mp3',
        'word_formed.wav',
    ];
    _RJSound = {
        RJSoundBingo: 0,
        RJSoundClick: 1,
        RJSoundDropTile: 2,
        RJSoundError: 3,
        RJSoundGameStart: 3,
        RJSoundNewMsg: 4,
        RJSoundNtf: 5,
        RJSoundPickTile: 6,
        RJSoundRecall: 7,
        RJSoundShuffle: 8,
        RJSoundWordFormed: 9,
    };
    _playableSound: Array<Sound> = [];

    constructor() {
        this.onAppInit();
    }

    get RJSound() {
        return this._RJSound;
    }

    onAppInit = (): void => {
        this.onDestroy();
        //preload sounds
        this._soundFiles.forEach((element) => {
            let snd = new Sound(element, Sound.MAIN_BUNDLE);
            this._playableSound.push(snd);
        });
    };

    onDestroy = (): void => {
        //cleanup
        this._playableSound.forEach((element) => {
            element.release();
        });
        this._playableSound.length = 0;
    };

    playSound = (soundname: number): void => {
        //play the preloaded sound
        //configure any play flags here from redux store here
        let isSoundEnabled: boolean = dataServer.getSoundSettings();

        if (isSoundEnabled) {
            if (this._playableSound.length == 0) {
                this.onAppInit(); //for hot reload
            }
            this._playableSound[soundname].play();
        }
    };
}

const soundManager: SoundManager = new SoundManager();

export default soundManager;
