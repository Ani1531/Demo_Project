//@flow
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import RangeSlider from 'rn-range-slider';
import type { SliderContainerProps } from '../commons/RJTypes';

const THUMB_RADIUS = 13;

type SliderContainerState = {
    low: number,
    high: number,
};
export default class SliderContainer extends React.Component<SliderContainerProps, SliderContainerState> {
    constructor(props: SliderContainerProps) {
        super(props);
        this.state = {
            low: this.props.min,
            high: this.props.max,
        };
    }

    renderLabel = (value: any) => (
        <View style={styles.root}>
            <Text style={styles.text}>{value}</Text>
        </View>
    );
    renderNotch = () => <View style={styles.notch_root} />;
    renderRail = () => <View style={styles.rail_root} />;
    renderRailSelected = () => <View style={styles.rail_selectedroot} />;
    renderThumb = () => <View style={styles.thumb_root} />;

    onSliderValueChange = (low: number, high: number) => {
        if (low !== this.props.min || high !== this.props.max) {
            this.setState({
                low: low,
                high: high,
            });
            this.props.onValueSelect(low, high, this.props.tag);
        }
    };

    render() {
        return (
            <RangeSlider
                style={this.props.style}
                gravity={'center'}
                min={600}
                max={4200}
                low={this.state.low}
                high={this.state.high}
                step={50}
                selectionColor="#3df"
                blankColor="#f618"
                floatingLabel
                renderThumb={this.renderThumb}
                renderRail={this.renderRail}
                renderRailSelected={this.renderRailSelected}
                renderLabel={this.renderLabel}
                renderNotch={this.renderNotch}
                onTouchEnd={(low: number, high: number) => {
                    this.onSliderValueChange(low, high);
                }}
            />
        );
    }
}
const styles = StyleSheet.create({
    root: {
        alignItems: 'center',
        padding: 8,
        backgroundColor: '#4499ff',
        borderRadius: 4,
    },
    text: {
        fontSize: 16,
        color: '#fff',
    },

    notch_root: {
        width: 8,
        height: 8,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderTopColor: '#4499ff',
        borderLeftWidth: 4,
        borderRightWidth: 4,
        borderTopWidth: 8,
    },
    rail_root: {
        flex: 1,
        height: 5,
        borderRadius: 2,
        backgroundColor: '#E4E4E4',
    },
    rail_selectedroot: {
        height: 5,
        backgroundColor: '#1d9df1',
        borderRadius: 2,
    },
    thumb_root: {
        width: THUMB_RADIUS * 2,
        height: THUMB_RADIUS * 2,
        borderRadius: THUMB_RADIUS,
        borderWidth: 1,
        borderColor: '#ffffff',
        // backgroundColor: '#FE6600',
        backgroundColor: '#1d9df1',
        shadowColor: '#000000',
        shadowOffset: { width: 0, height: -1 },
        shadowOpacity: 0.16,
        shadowRadius: 6,
    },
});
