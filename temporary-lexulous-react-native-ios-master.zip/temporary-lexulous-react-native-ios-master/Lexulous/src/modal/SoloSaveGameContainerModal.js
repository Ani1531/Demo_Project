import React from 'react';
import { View } from 'react-native';
import DimensionUtils from '../utils/DimensionUtils';
import LayoutUtils from '../utils/LayoutUtils';
import ColorConfig from '../configs/ColorConfig';
import SoloGameStartForm from '../component/SoloGameStartForm';
import { connect } from 'react-redux';
import Config from '../configs/Config';
import {
    sendSoloGameStartData,
    saveCreateGameData,
} from '../service/LiveGamePlayService';
import {
    GAME_SOLO_RESET_SLOT_DATA,
    GAME_SOLO_MENU_SHOW_HIDE,
    GAME_SOLO_SET_CURRENT_MENU_OPT,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

class SoloSaveGameContainerModal extends React.Component {
    isOpen = () =>
        this.props.slotData &&
        this.props.slotData.type === Config.SOLO_SLOT_SAVE;

    onClose = () => eventBus.emit(GAME_SOLO_RESET_SLOT_DATA);

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: '46%',
        height: '60%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    render = () =>
        this.isOpen() ? (
            <View style={this.getModalContentStyle()}>
                <View
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                    ]}
                >
                    <SoloGameStartForm
                        savedRules={true}
                        onActionButton={this.onAction}
                        onCancel={this.onClose}
                    />
                </View>
            </View>
        ) : null;

    onAction = (slotData) => {
        let params = {
            boarddes: this.props.createBoardDes,
            bdsqval: this.props.bdsqvalSlot,
            tilevalues: this.props.createBoardTilevalues,
            tile_count: this.props.createBoardTileCount,
            slotid: slotData.slotId + '',
            slotname: slotData.slotName,
        };
        saveCreateGameData(params);
        this.sendGameRequest();
        this.onClose();
        eventBus.emit(GAME_SOLO_MENU_SHOW_HIDE, null, { menuOpt: false });
        eventBus.emit(GAME_SOLO_SET_CURRENT_MENU_OPT);
    };

    sendGameRequest = () => {
        let params = {
            action: Config.START_NEW_GAME_ACTION,
            boardtype: 'N',
            gametype: this.props.isRobot ? 'robot' : 'solitaire',
            robotlevel: this.props.level,
            dic: this.props.dictionary,
            timertype: this.props.time > 0 ? '1' : '0',
            timerlength: this.props.time,
            boarddetails: Config.SOLO_BOARD_TYPE_MANUAL,
            boarddes: this.props.createBoardDes,
            bdsqval: this.props.bdsqvalSlot,
            tilevalues: this.props.createBoardTilevalues,
            tile_count: this.props.createBoardTileCount,
        };
        sendSoloGameStartData(params);
    };
}

const mapStateToProps = (state) => ({
    isRobot: state.solitaire.isRobot,
    dictionary: state.solitaire.dictionary,
    level: state.solitaire.level,
    time: state.solitaire.time,
    slotData: state.solitaire.slotData,
    bdsqvalSlot: state.solitaire.bdsqvalSlot,
    createBoardDes: state.solitaire.createBoardDes,
    createBoardTilevalues: state.solitaire.createBoardTilevalues,
    createBoardTileCount: state.solitaire.createBoardTileCount,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    SoloSaveGameContainerModal
);
