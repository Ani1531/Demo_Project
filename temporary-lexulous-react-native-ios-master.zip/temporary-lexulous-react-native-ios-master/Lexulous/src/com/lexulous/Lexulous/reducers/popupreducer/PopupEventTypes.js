// @flow

export const UPDT_POPUP_VISIBILITY: string = 'UPDT_POPUP_VISIBILITY';
export const HIDE_ALL_POPUPS: string = 'HIDE_ALL_POPUPS';
export const SHOW_ALERT: string = 'SHOW_ALERT';
export const CLEAR_ALERT: string = 'CLEAR_ALERT';
export const CLEAR_ALL_ALERTS: string = 'CLEAR_ALL_ALERTS';
