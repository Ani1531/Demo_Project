const { ipcRenderer } = require('electron');
window.ipcRenderer = ipcRenderer;
