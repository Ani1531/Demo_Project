import React from 'react';
import {
    FlatList,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
} from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import { getHints } from '../service/LiveGamePlayService';
import StandardButton from './StandardButton';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
    faAngleDoubleLeft,
    faChevronLeft,
    faChevronRight,
} from '@fortawesome/free-solid-svg-icons';
import { faAngleDoubleRight } from '@fortawesome/pro-duotone-svg-icons';
import get from 'lodash/get';
import { GAME_ANALYSE_CURRENT_POSITION_CHANGED } from '../configs/ActionIdentifiers';
import log from 'loglevel';
import isEqual from 'lodash/isEqual';
import PText from './PText';
import S14Text from './S14Text';

const eventBus = require('js-event-bus')();

class HintSection extends React.Component {
    componentDidMount = () => {};

    componentWillUnmount = () => {};

    getCurrentMoveList = () => {
        let movesObjs = this.props.game.movesObjs;
        let currentPosition = this.props.game.currPosition;
        let moveObj = (movesObjs || [])[currentPosition];
        return moveObj.possibleMoves;
    };

    onAnalyseDisplayMoveRack = () =>
        this.setState({ lastRendered: Date.now() });

    onHintsClick = () => {
        getHints();
    };

    onStatsClick = () => {
        eventBus.emit(Config.SHOW_SOLO_STATS_DIALOG);
    };

    getCellDimension = () => ({
        height: this.props.layout.layoutCellDimension,
    });

    shouldComponentUpdate(nextProps, nextState, nextContext) {
        return (
            !isEqual(nextState, this.state) ||
            !isEqual(
                get(this.props, 'game.currentPosition'),
                get(nextProps, 'game.currentPosition')
            ) ||
            !isEqual(
                get(this.props, 'game.moveListCompleteData'),
                get(nextProps, 'game.moveListCompleteData')
            ) ||
            !isEqual(
                get(this.props, 'game.showingAnalyseMove'),
                get(nextProps, 'game.showingAnalyseMove')
            ) ||
            !isEqual(
                get(this.props, 'game.movesObjs'),
                get(nextProps, 'game.movesObjs')
            ) ||
            !isEqual(
                get(this.props, 'game.game_type'),
                get(nextProps, 'game.game_type')
            ) ||
            !isEqual(
                get(this.props, 'game.hintWordList'),
                get(nextProps, 'game.hintWordList')
            ) ||
            !isEqual(
                get(this.props, 'forSoloGameHintSection'),
                get(nextProps, 'forSoloGameHintSection')
            )
        );
    }

    render = () => {
        let moveList = [];
        log.info(
            'in HintSection, in render, this.props.game.moveListCompleteData is:\n' +
                JSON.stringify(this.props.game.moveListCompleteData, null, 2)
        );
        this.props.game.moveListCompleteData.forEach((element) => {
            Object.values(element).map((item) => {
                moveList = [...moveList, item];
            });
        });
        log.info(
            'in HintSection, in render, moveList is:\n' +
                JSON.stringify(moveList, null, 2)
        );
        let movePlayedBy = get(
            moveList[Number(this.props.game.currPosition)],
            'player.name'
        );
        let selectedMoveWord = get(
            moveList[Number(this.props.game.currPosition)],
            'words'
        );
        let selectedMoveScore = get(
            moveList[Number(this.props.game.currPosition)],
            'score'
        );
        return (
            <View
                style={[
                    styles.container,
                    this.props.game.showingAnalyseMove
                        ? styles.additionalContainerStylesForAnalyseSection
                        : null,
                    this.props.game.game_type === 'solo'
                        ? styles.additionalContainerStylesForSoloMode
                        : null,
                ]}
            >
                {this.props.forSoloGameHintSection ? (
                    <View
                        style={[
                            styles.touchableContainerStyle,
                            this.getCellDimension(),
                            styles.additionalBottomBorderInSoloMode,
                        ]}
                    >
                        <StandardButton
                            style={styles.touchableStyle}
                            onPress={this.onHintsClick}
                            text={'Hints'}
                        />
                        <StandardButton
                            style={styles.touchableStyle}
                            onPress={this.onStatsClick}
                            text={'Stats'}
                        />
                    </View>
                ) : (
                    <View style={styles.analyseMainView}>
                        <View style={styles.analyseModeLeftViewOuterStyle}>
                            <View
                                style={[
                                    styles.analyseModeLeftViewInnerStyle,
                                    { marginBottom: 2 },
                                ]}
                            >
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    onPress={this.goToPreviousMove}
                                    style={[
                                        styles.iconTouchableStyle,
                                        {
                                            paddingHorizontal: 4,
                                        },
                                    ]}
                                >
                                    <FontAwesomeIcon
                                        icon={faChevronLeft}
                                        size={10}
                                        style={{
                                            color: '#fff',
                                        }}
                                    />
                                </TouchableOpacity>
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    onPress={this.goToNextMove}
                                    style={[
                                        styles.iconTouchableStyle,
                                        {
                                            marginRight: 0,
                                            paddingHorizontal: 4,
                                        },
                                    ]}
                                >
                                    <FontAwesomeIcon
                                        icon={faChevronRight}
                                        size={10}
                                        style={{
                                            color: '#fff',
                                        }}
                                    />
                                </TouchableOpacity>
                            </View>
                            <View style={styles.analyseModeLeftViewInnerStyle}>
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    onPress={this.goToFirstMove}
                                    style={styles.iconTouchableStyle}
                                >
                                    <FontAwesomeIcon
                                        icon={faAngleDoubleLeft}
                                        size={10}
                                        style={{
                                            color: '#fff',
                                        }}
                                    />
                                </TouchableOpacity>
                                <TouchableOpacity
                                    activeOpacity={0.7}
                                    onPress={this.goToLastMove}
                                    style={[
                                        styles.iconTouchableStyle,
                                        { marginRight: 0 },
                                    ]}
                                >
                                    <FontAwesomeIcon
                                        icon={faAngleDoubleRight}
                                        size={10}
                                        style={{
                                            color: '#fff',
                                        }}
                                    />
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View style={styles.analysisModeRightViewOuterStyle}>
                            <PText
                                style={[
                                    styles.moveTextStyle,
                                    { textAlign: 'right' },
                                ]}
                            >
                                <Text>Move </Text>
                                <Text style={{ color: '#338AFF' }}>
                                    {Number(this.props.game.currPosition) + 1}{' '}
                                </Text>
                                <Text>of </Text>
                                <Text style={{ color: '#338AFF' }}>
                                    {this.props.game.movesObjs.length}
                                </Text>
                            </PText>
                            {this.props.game.showingAnalyseMove ? (
                                <View
                                    style={[
                                        styles.touchableContainerStyle,
                                        this.getCellDimension(),
                                    ]}
                                >
                                    <StandardButton
                                        style={[
                                            styles.touchableStyle,
                                            { alignItems: 'flex-end' },
                                        ]}
                                        onPress={this.resetToOrginalMove}
                                        text={
                                            movePlayedBy +
                                            ': ' +
                                            selectedMoveWord.toString() +
                                            ' (' +
                                            selectedMoveScore.toString() +
                                            ')'
                                        }
                                        textStyle={{ fontSize: 13 }}
                                    />
                                </View>
                            ) : null}
                        </View>
                    </View>
                )}
                <FlatList
                    data={
                        this.props.game.showingAnalyseMove
                            ? this.getCurrentMoveList()
                            : this.props.game.hintWordList
                    }
                    style={styles.hintListStyle}
                    renderItem={this.renderItem}
                />
            </View>
        );
    };

    resetToOrginalMove = () => eventBus.emit(Config.RESET_ANALYSE_HINT);

    onHintItemPress = (item) => {
        eventBus.emit(Config.HINT_WORD_SELECTED, null, item);
    };

    renderHints = (item) => (
        <TouchableOpacity
            style={styles.flexDirectionRow}
            onPress={onHintClick.bind({
                onHintItemPress: this.onHintItemPress,
                item,
            })}
        >
            <S14Text>
                {(item.wordsFormed || []).join(', ') + ' (' + item.score + ')'}
            </S14Text>
        </TouchableOpacity>
    );

    renderItem = ({ item, index }) => (
        <View
            style={[
                styles.eachListItemView,
                this.props.game.game_type === 'solo'
                    ? styles.additionalHintListStylesForSoloGame
                    : null,
                this.props.game.showingAnalyseMove &&
                    index == 0 && {
                        borderTopWidth: Config.SIDE_PANEL_BORDER_WIDTH + 1,
                    },
                this.props.game.showingAnalyseMove &&
                    index === this.getCurrentMoveList().length - 1 && {
                        borderBottomWidth: 0,
                    },
            ]}
        >
            <S14Text>
                {item.wordsFormed && item.wordsFormed.length > 0
                    ? this.renderHints(item)
                    : null}
            </S14Text>
        </View>
    );

    goToPosition = (position) => {
        let currPosition = get(this.props, 'game.currPosition');
        if (
            (position === 0 && currPosition === 0) ||
            (position === this.props.game.movesObjs.length - 1 &&
                currPosition === this.props.game.movesObjs.length - 1)
        )
            return;

        eventBus.emit(GAME_ANALYSE_CURRENT_POSITION_CHANGED, null, {
            currPosition: position,
        });
        eventBus.emit(Config.ANALYSE_DISPLAY_MOVE_RACK, null, {
            movesObjs: this.props.game.movesObjs,
            players: this.props.game.players,
            position,
        });
    };

    goToFirstMove = () => {
        this.goToPosition(0);
    };

    goToPreviousMove = () => {
        let position = Math.max(0, this.props.game.currPosition - 1);
        this.goToPosition(position);
    };

    goToNextMove = () => {
        let position = Math.min(
            Math.max(0, this.props.game.movesObjs.length - 1),
            this.props.game.currPosition + 1
        );
        this.goToPosition(position);
    };

    goToLastMove = () => {
        this.goToPosition(this.props.game.movesObjs.length - 1);
    };
}

function onHintClick() {
    this.onHintItemPress(this.item);
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        overflow: 'hidden',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    },
    touchableStyle: {
        flex: 1,
        paddingVertical: 5,
        alignItems: 'center',
        justifyContent: 'center',
    },
    touchableContainerStyle: {
        width: '100%',
        flexDirection: 'row',
    },
    hintListStyle: {
        flex: 1,
        overflow: 'hidden',
        backgroundColor: ColorConfig.DEFAULT_CELL_BACKGROUND_COLOR,
    },
    flexDirectionRow: { flexDirection: 'row' },
    moveText: {
        flex: 3,
        marginVertical: 5,
        paddingVertical: 0,
        textAlign: 'center',
    },
    additionalHintListStylesForSoloGame: {
        borderBottomWidth: 0,
        borderRightWidth: 0,
    },
    additionalContainerStylesForAnalyseSection: {
        borderLeftWidth: 0,
        borderTopWidth: 0,
        borderRightWidth: 0,
    },
    additionalContainerStylesForSoloMode: { borderWidth: 0 },
    additionalBottomBorderInSoloMode: {
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    analyseModeLeftViewOuterStyle: {
        justifyContent: 'center',
    },
    analyseModeLeftViewInnerStyle: {
        flexDirection: 'row',
        marginTop: 2,
        justifyContent: 'space-around',
    },
    analysisModeRightViewOuterStyle: { alignItems: 'flex-end' },
    analyseMainView: {
        flexDirection: 'row',
        paddingHorizontal: 10,
        paddingBottom: 2,
        backgroundColor: '#DFE0E2',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    iconTouchableStyle: {
        backgroundColor: '#338AFF',
        padding: 3,
        marginRight: 5,
        borderRadius: 3,
    },
    moveTextStyle: {
        alignItems: 'center',
        marginTop: 6,
    },
    eachListItemView: {
        flex: 1,
        paddingVertical: 2,
        paddingHorizontal: 10,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    game: state.game,
});

export default connect(mapStateToProps)(HintSection);
