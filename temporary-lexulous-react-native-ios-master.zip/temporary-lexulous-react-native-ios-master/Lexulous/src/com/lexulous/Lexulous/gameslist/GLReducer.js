// @flow

import {
    ADD_GAMES,
    GL_REFRESH_STARTED,
    GL_REFRESH_FINISHED,
    CLR_GAMES,
    UPDT_RVW_SHR,
    CLR_RVW_SHR,
    GL_AD_EVT,
    GL_READ_CHAT,
    GL_SVCCON_ADD_GAME,
    GL_UPDT_VIA_BOARD_INFO,
} from './GLEventTypes';

import type {
    GLAction,
    ExtractedGames,
    GamesListGameData,
    GamesListSectionData,
    GamesListProps,
    GamesListItemData,
    ReviewShareExistingIdx,
    ReviewShareData,
    GamesListResponse,
    ActionRefreshGames,
    ActionGLRefreshStarted,
    ActionReviewShareUpdateData,
    ReviewShareUpdateData,
    ActionGLRefreshFinished,
    ActionGLClearData,
    ActionGLAdEvent,
    ActionGLReadChatEvent,
    ProfileInfo,
    ActionGLUpdate,
    ActionGLUpdtViaBoardInfo,
    GlUpdtViaBoardInfoData,
} from '../commons/RJTypes';
import i18n from 'i18n-js';
import get from 'lodash/get';

const glinistate = {
    isrefreshing: false,
    showreview: false,
    showshare: false,
    profile: {},
    playersinfo: {},
    games: [],
};

// Use the initialState as a default value
export default function GLReducer(state: GamesListProps = glinistate, taction: GLAction) {
    switch (taction.type) {
        case ADD_GAMES: {
            let action = ((taction: any): ActionRefreshGames);
            let profile: ProfileInfo = action.profile ?? state.profile;
            let extractedGames: ExtractedGames = segregateGames(action.payload);

            let myturngames: Array<GamesListGameData> = getGames(state.games, 'myturn');
            let theirturngames: Array<GamesListGameData> = getGames(state.games, 'theirturn');
            let miniarchivedgames: Array<GamesListGameData> = getGames(state.games, 'archivedgames');

            myturngames = [...myturngames, ...extractedGames.myturngames];
            theirturngames = [...theirturngames, ...extractedGames.theirturngames];
            miniarchivedgames = [...miniarchivedgames, ...extractedGames.miniarchivedgames];

            if (profile.guid !== undefined && profile.guid !== null) {
                let guid = profile.guid;
                myturngames = sortGamesList(myturngames, guid);
                theirturngames = sortGamesList(theirturngames, guid);
                miniarchivedgames = sortGamesList(miniarchivedgames, guid);
            }

            let games: Array<GamesListSectionData> = [];

            if (myturngames.length > 0) {
                let ttlstr = i18n.t('my_turn', {
                    number: myturngames.length,
                });
                let secdata: Array<GamesListItemData> = myturngames.map((val: GamesListGameData) => {
                    return {
                        type: 'game',
                        key: val.gid,
                        data: val,
                    };
                });
                games.push({
                    title: ttlstr,
                    type: 'myturn',
                    data: secdata,
                });
            }

            if (theirturngames.length > 0) {
                let ttlstr = i18n.t('their_turn', {
                    number: theirturngames.length,
                });
                let secdata: Array<GamesListItemData> = theirturngames.map((val: GamesListGameData) => {
                    return {
                        type: 'game',
                        key: val.gid,
                        data: val,
                    };
                });
                games.push({
                    title: ttlstr,
                    type: 'theirturn',
                    data: secdata,
                });
            }

            if (miniarchivedgames.length > 0) {
                let ttlstr = i18n.t('recent_games', {
                    number: miniarchivedgames.length,
                });
                let secdata: Array<GamesListItemData> = miniarchivedgames.map((val: GamesListGameData) => {
                    return {
                        type: 'game',
                        key: val.gid,
                        data: val,
                    };
                });
                games.push({
                    title: ttlstr,
                    type: 'archivedgames',
                    data: secdata,
                });
            }

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: state.isrefreshing,
                showreview: state.showreview,
                showshare: state.showshare,
                profile: profile,
                playersinfo: { ...state.playersinfo, ...action.payload.playersinfo },
                games: games,
            };
            return newstate;
        }
        case GL_REFRESH_STARTED: {
            let action = ((taction: any): ActionGLRefreshStarted);
            let games: Array<GamesListSectionData> = [];

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: true,
                showreview: state.showreview,
                showshare: state.showshare,
                profile: state.profile,
                playersinfo: {},
                games: games,
            };
            return newstate;
        }
        case CLR_GAMES: {
            let action = ((taction: any): ActionGLClearData);
            let games: Array<GamesListSectionData> = [];

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo | {},
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: state.isrefreshing,
                showreview: state.showreview,
                showshare: state.showshare,
                profile: {},
                playersinfo: {},
                games: games,
            };
            return newstate;
        }
        case GL_REFRESH_FINISHED: {
            let action = ((taction: any): ActionGLRefreshFinished);
            let games: Array<GamesListSectionData> = [];

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: false,
                showreview: state.showreview,
                showshare: state.showshare,
                profile: state.profile,
                playersinfo: {},
                games: games,
            };
            return newstate;
        }
        case GL_AD_EVT: {
            let action = ((taction: any): ActionGLAdEvent);
            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: state.isrefreshing,
                showreview: state.showreview,
                showshare: state.showshare,
                profile: state.profile,
                playersinfo: state.playersinfo,
                games: state.games,
            };
            return newstate;
        }
        case UPDT_RVW_SHR: {
            let action = ((taction: any): ActionReviewShareUpdateData);
            let shrvdata: ReviewShareUpdateData = action.payload;
            let showreview: boolean = false;
            let showshare: boolean = false;
            if (shrvdata.type === 'review') {
                showreview = shrvdata.show;
            } else if (shrvdata.type === 'share') {
                showshare = shrvdata.show;
            }

            let games: Array<GamesListSectionData> = state.games;
            let eidx: ReviewShareExistingIdx = findExistingReviewShareIndex(games);
            if (eidx.secindex == -1) {
                //NOT FOUND INSERT
                insertReviewShareData(games, shrvdata);
            } else {
                //FOUND MODIFY EXISTING
                if (eidx.data !== null && eidx.data !== undefined) {
                    eidx.data.reviewsharestate = shrvdata.reviewsharestate;
                }
            }

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: state.isrefreshing,
                showreview: showreview,
                showshare: showshare,
                profile: state.profile,
                playersinfo: state.playersinfo,
                games: JSON.parse(JSON.stringify(games)),
            };
            return newstate;
        }
        case CLR_RVW_SHR: {
            let showreview: boolean = false;
            let showshare: boolean = false;

            let games: Array<GamesListSectionData> = state.games;
            let eidx: ReviewShareExistingIdx = findExistingReviewShareIndex(games);
            if (eidx.secindex !== -1) {
                //FOUND MODIFY EXISTING
                games[eidx.secindex].data.splice(eidx.idx, 1);
            }

            let newstate: {
                isrefreshing: boolean,
                showreview: boolean,
                showshare: boolean,
                profile: ProfileInfo,
                playersinfo: { [string]: ProfileInfo },
                games: Array<GamesListSectionData>,
            } = {
                isrefreshing: state.isrefreshing,
                showreview: showreview,
                showshare: showshare,
                profile: state.profile,
                playersinfo: state.playersinfo,
                games: JSON.parse(JSON.stringify(games)),
            };
            return newstate;
        }
        case GL_READ_CHAT: {
            let action = ((taction: any): ActionGLReadChatEvent);
            let games: Array<GamesListSectionData> = state.games.map((item, index) => {
                item.data.map((item2, index2) => {
                    if (item2.type == 'game') {
                        let gmdata: GamesListGameData = ((item2.data: any): GamesListGameData);
                        if (action.payload.includes(gmdata.gid)) {
                            if (gmdata.unreadmsg !== undefined && gmdata.unreadmsg !== null) {
                                delete gmdata.unreadmsg;
                            }
                        }
                    }
                    return item2;
                });
                return item;
            });

            return { ...state, games };
        }

        case GL_SVCCON_ADD_GAME: {
            let action = ((taction: any): ActionGLUpdate);
            let isOwnMove = !!get(action.payload, 'gid');
            let gid = get(action.payload, 'data.gid') || get(action.payload, 'gid');

            let games = [...state.games];

            let gameList =
                games.filter(
                    (item) =>
                        item.type ===
                        games.find((item1) => {
                            return item1.data.find((ele) => ele.key === gid);
                        })?.type
                )[0]?.data ?? [];

            let gameIndex = gameList.findIndex((item) => item.key === gid);
            let gameData = gameList.find((item) => item.key === gid);

            let isChatData: boolean = get(action.payload, 'data').hasOwnProperty('chat');
            let isGameOver: boolean = get(action.payload, 'data').hasOwnProperty('gameover_reason');
            let hasWinner: boolean = get(action.payload, 'data').hasOwnProperty('winner');
            let isDeletedGame = isGameOver && !hasWinner;

            let removeEmptySections = () => {
                let idx = games.reduce(function (accumulator, element, index) {
                    if (element.data == null || element.data == undefined || element.data.length == 0) {
                        accumulator.push(index);
                    }
                    return accumulator;
                }, []);
                idx = idx.sort();
                for (var i = idx.length - 1; i >= 0; i--) {
                    games.splice(idx[i], 1);
                }
            };

            if (isDeletedGame) {
                if (gameIndex !== -1) {
                    gameList.splice(gameIndex, 1);
                    removeEmptySections();
                    return { ...state, games };
                }
                return state;
            } else {
                let playersinfo = state.playersinfo;
                let playersData = get(action.payload, 'data.players');

                let newUserinfo: Array<{ [string]: ProfileInfo }> = playersData
                    .map((item) => {
                        let plInfoFound: boolean = Object.keys(playersinfo).includes(item.guid);
                        if (!plInfoFound) {
                            let data: { [string]: ProfileInfo } = {
                                [item.guid]: {
                                    name: item.name,
                                    avtar: item.avtar,
                                    guid: item.guid,
                                    usrtype: item.usrtype,
                                    lexcom: item.lexcom,
                                },
                            };
                            return data;
                        }
                    })
                    .filter((m) => m !== undefined && m !== null);

                if (newUserinfo.length > 0) {
                    let playerArrayToDic = Object.assign({}, ...newUserinfo);
                    playersinfo = { ...playersinfo, ...playerArrayToDic };
                }

                if (gameIndex === -1) {
                    gameData = {
                        type: 'game',
                        key: gid,
                        data: get(action.payload, 'data'),
                    };
                }

                if (gameData !== undefined && gameData !== null) {
                    let gData = ((gameData.data: any): GamesListGameData);

                    if (!isGameOver) {
                        if (isChatData) {
                            let msgCount = Number(gData.unreadmsg ?? 0);
                            msgCount++;
                            gData.unreadmsg = msgCount.toString();
                        } else {
                            gData.lts = true;
                            gData.lastmove = get(action.payload, 'data.boarddata.wordsplayed.0.0');
                        }
                    } else {
                        gData.gameover_reason = get(action.payload, 'data.gameover_reason');
                        gData.winner = get(action.payload, 'data.winner');
                    }

                    gData.turnpid = get(action.payload, 'data.current_turn');
                    gData.tilesinbag = get(action.payload, 'data.tilesinbag');

                    (gData.players || []).map((player) => {
                        let sPlayer = get(action.payload, 'data.players').find((p) => p.pid === player.pid);
                        if (!!sPlayer) {
                            player.score = get(sPlayer, 'current_score');
                            if (gameIndex === -1) {
                                player.uid = get(sPlayer, 'guid');
                            }
                        }
                    });

                    let gameType = !hasWinner ? (isOwnMove ? 'theirturn' : 'myturn') : 'archivedgames';

                    if (!isChatData) {
                        gameList.splice(gameIndex, 1);
                        let filteredgames = games.filter((item) => item.type === gameType);
                        if (filteredgames.length > 0) {
                            let updateGameList = filteredgames[0]?.data;
                            updateGameList.unshift(gameData);
                        } else {
                            let ttlstr = null;
                            switch (gameType) {
                                case 'myturn':
                                    ttlstr = i18n.t('my_turn', {
                                        number: 1,
                                    });
                                    break;
                                case 'theirturn':
                                    ttlstr = i18n.t('their_turn', {
                                        number: 1,
                                    });
                                    break;
                                case 'archivedgames':
                                    ttlstr = i18n.t('recent_games', {
                                        number: 1,
                                    });
                                    break;
                                default:
                                    break;
                            }

                            let secdata: Array<GamesListItemData> = Array(gameData);
                            games.push({
                                title: ttlstr,
                                type: gameType,
                                data: secdata,
                            });
                        }
                    }
                }
                removeEmptySections();
                return { ...state, games, playersinfo };
            }
        }
        case GL_UPDT_VIA_BOARD_INFO: {
            let action = ((taction: any): ActionGLUpdtViaBoardInfo);
            let data: GlUpdtViaBoardInfoData = action.payload;
            let gameFdGlData = data.gameFdGlData;
            let gameFdPlayerInfo = data.gameFdPlayerInfo;

            let games: Array<GamesListSectionData> = [...state.games];
            let playersinfo: { [string]: ProfileInfo } = state.playersinfo;

            let gid = gameFdGlData.gid;

            let gameList =
                games.filter(
                    (item) =>
                        item.type ===
                        games.find((item) => {
                            return item.data.find((ele) => ele.key === gid);
                        })?.type
                )[0]?.data ?? [];

            let gameIndex = gameList.findIndex((item) => item.key === gid);
            let gameData = gameList.find((item) => item.key === gid);

            if (gameIndex === -1) {
                gameData = {
                    type: 'game',
                    key: gid,
                    data: gameFdGlData,
                };
            }

            let gameTurnType = getGameTurnTypeFrmBoardInfo(data, state.profile.guid ?? '000000000000');

            if (gameData !== undefined && gameData !== null) {
                let gData = ((gameData.data: any): GamesListGameData);
                if (
                    gameData.data.lastupdate != gameFdGlData.lastupdate ||
                    gameTurnType == 'archivedgames' ||
                    gameIndex === -1
                ) {
                    gameData.data = gameFdGlData;

                    let newUserinfo: Array<{ [string]: ProfileInfo } | void> = gameFdPlayerInfo
                        .map((item) => {
                            let isNewPlayer: boolean = !Object.keys(playersinfo).includes(item.guid);
                            if (isNewPlayer) {
                                let info_data: { [string]: ProfileInfo } = {
                                    [item.guid]: {
                                        name: item.name,
                                        avtar: item.avtar,
                                        guid: item.guid,
                                        usrtype: item.usrtype,
                                        lexcom: item.lexcom,
                                    },
                                };
                                return info_data;
                            }
                        })
                        .filter((m) => m !== undefined && m !== null);

                    if (newUserinfo.length > 0) {
                        let playerArrayToDic = Object.assign({}, ...newUserinfo);
                        playersinfo = { ...playersinfo, ...playerArrayToDic };
                    }

                    gameList.splice(gameIndex, 1);
                    let filteredgames = games.filter((item) => item.type === gameTurnType);
                    if (filteredgames.length > 0) {
                        let updateGameList = filteredgames[0]?.data;
                        updateGameList.unshift(gameData);
                    } else {
                        let ttlstr = null;
                        switch (gameTurnType) {
                            case 'myturn':
                                ttlstr = i18n.t('my_turn', {
                                    number: 1,
                                });
                                break;
                            case 'theirturn':
                                ttlstr = i18n.t('their_turn', {
                                    number: 1,
                                });
                                break;
                            case 'archivedgames':
                                ttlstr = i18n.t('recent_games', {
                                    number: 1,
                                });
                                break;
                            default:
                                break;
                        }

                        let secdata: Array<GamesListItemData> = Array(gameData);
                        if (ttlstr != null && gameTurnType != undefined) {
                            games.push({
                                title: ttlstr,
                                type: gameTurnType,
                                data: secdata,
                            });
                        }
                    }
                }
                delete gData.lts;
            }

            return { ...state, games, playersinfo };
        }

        default:
            return state;
    }
}

let sortGamesList = (games: Array<GamesListGameData>, guid: string): Array<GamesListGameData> => {
    let mdfgames = games.sort((a: GamesListGameData, b: GamesListGameData) => {
        let isaarchivedgame = false;
        let isbarchivedgame = false;
        if (a.hasOwnProperty('gameover_reason')) {
            isaarchivedgame = true;
        }
        if (b.hasOwnProperty('gameover_reason')) {
            isbarchivedgame = true;
        }

        if (isaarchivedgame && isbarchivedgame) {
            return parseInt(b.lastupdate) - parseInt(a.lastupdate);
        } else if (isaarchivedgame && !isbarchivedgame) {
            return 1;
        } else if (!isaarchivedgame && isbarchivedgame) {
            return -1;
        }

        let ahasmyturn = a.players[parseInt(a.turnpid) - 1].uid === guid;
        let bhasmyturn = b.players[parseInt(b.turnpid) - 1].uid === guid;
        if (ahasmyturn && bhasmyturn) {
            return parseInt(b.lastupdate) - parseInt(a.lastupdate);
        } else if (ahasmyturn && !bhasmyturn) {
            return -1;
        } else if (!ahasmyturn && bhasmyturn) {
            return 1;
        } else if (!ahasmyturn && !bhasmyturn) {
            return parseInt(b.lastupdate) - parseInt(a.lastupdate);
        } else {
            //to satisfy flow
            return 1;
        }
    });
    return mdfgames;
};

let segregateGames = (response: GamesListResponse): ExtractedGames => {
    let myturngames: Array<GamesListGameData> = [];
    let theirturngames: Array<GamesListGameData> = [];
    let miniarchivedgames: Array<GamesListGameData> = [];

    let games = response.games;
    let uid: Array<string> = Object.keys(response.uid);
    games.forEach((game: GamesListGameData) => {
        if (game.gameover_reason !== null && game.gameover_reason !== undefined) {
            miniarchivedgames.push(game);
        } else {
            let guid: string = '000000000000';
            if (uid != null && uid != undefined && uid.length > 0) {
                guid = uid[0];
            }
            let me = game.players.find((element) => element.uid === guid);
            let ismyturn = false;
            let mypid = '1';
            if (me !== undefined && me !== null) {
                mypid = me.pid;
                ismyturn = mypid === game.turnpid;
                if (ismyturn) {
                    myturngames.push(game);
                } else {
                    theirturngames.push(game);
                }
            }
        }
    });
    return { myturngames, theirturngames, miniarchivedgames };
};

let getGames = (
    games: Array<GamesListSectionData>,
    gametype: 'myturn' | 'theirturn' | 'archivedgames'
): Array<GamesListGameData> => {
    let qq = games
        .map((ff) => {
            if (ff.type == gametype) {
                let mm = ff.data.map((uu) => {
                    return ((uu.data: any): GamesListGameData);
                });
                return mm;
            }
        })
        .flat()
        .filter((zz) => zz != null);
    return ((qq: any): Array<GamesListGameData>);
};

let findExistingReviewShareIndex = (games: Array<GamesListSectionData>): ReviewShareExistingIdx => {
    let eidx: ReviewShareExistingIdx = {
        secindex: -1,
        idx: -1,
    };
    games.forEach((data, idx) => {
        if (data.type === 'myturn' || data.type === 'theirturn' || data.type === 'archivedgames') {
            data.data.forEach((tdata, tidx) => {
                if (tdata.type === 'review' || tdata.type === 'share') {
                    eidx.data = ((tdata.data: any): ReviewShareData);
                    eidx.secindex = idx;
                    eidx.idx = tidx;
                }
            });
        }
    });
    return eidx;
};

let insertReviewShareData = (games: Array<GamesListSectionData>, shrvdata: ReviewShareUpdateData) => {
    let eidx = findReviewShareInsertIdx(games);
    if (eidx.secindex !== -1) {
        let reviewsharestate = shrvdata.reviewsharestate;
        let mm: GamesListItemData = {
            type: shrvdata.type,
            key: '-1',
            data: { reviewsharestate },
        };
        games[eidx.secindex].data.splice(eidx.idx, 0, mm);
    }
};

let findReviewShareInsertIdx = (games: Array<GamesListSectionData>): ReviewShareExistingIdx => {
    let eidx: ReviewShareExistingIdx = {
        secindex: -1,
        idx: -1,
    };
    games.every((data, idx) => {
        if (data.type === 'myturn' || data.type === 'theirturn' || data.type === 'archivedgames') {
            if (data.data.length > 0) {
                if (data.data.length >= 4) {
                    eidx.secindex = idx;
                    eidx.idx = 3;
                } else {
                    eidx.secindex = idx;
                    eidx.idx = data.data.length;
                }
                return false;
            }
        }
        return true;
    });
    return eidx;
};

let getGameTurnTypeFrmBoardInfo = (data: GlUpdtViaBoardInfoData, myGuid: string) => {
    let gameFdGlData = data.gameFdGlData;

    if (gameFdGlData.gameover_reason !== null && gameFdGlData.gameover_reason !== undefined) {
        return 'archivedgames';
    } else {
        let guid: string = myGuid;
        let me = gameFdGlData.players.find((element) => element.uid === guid);
        let ismyturn = false;
        let mypid = '1';
        if (me !== undefined && me !== null) {
            mypid = me.pid;
            ismyturn = mypid === gameFdGlData.turnpid;
            if (ismyturn) {
                return 'myturn';
            } else {
                return 'theirturn';
            }
        }
    }
};
