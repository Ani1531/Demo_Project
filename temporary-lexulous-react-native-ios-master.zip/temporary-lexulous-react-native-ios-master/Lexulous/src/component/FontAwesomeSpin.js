import React, { Component } from 'react';
import { Animated, Easing } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons';

class FontAwesomeSpin extends Component {
    spinValue = new Animated.Value(0);

    componentDidMount() {
        this.spin();
    }

    spin = () => {
        this.spinValue.setValue(0);

        Animated.timing(this.spinValue, {
            toValue: 1,
            duration: 2000,
            easing: Easing.linear,
            useNativeDriver: true,
        }).start(() => this.spin());
    };

    render() {
        const rotate = this.spinValue.interpolate({
            inputRange: [0, 1],
            outputRange: ['0deg', '360deg'],
        });
        let size = this.props.size ?? 20;
        return (
            <Animated.View style={{ transform: [{ rotate }] }}>
                <FontAwesomeIcon
                    icon={faCircleNotch}
                    size={size}
                    style={{ color: this.props.color }}
                />
            </Animated.View>
        );
    }
}

export default FontAwesomeSpin;
