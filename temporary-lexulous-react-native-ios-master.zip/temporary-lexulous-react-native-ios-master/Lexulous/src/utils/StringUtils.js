// import { toArray } from 'react-emoji-render';

export default class StringUtils {
    static isString = (aRef) =>
        (typeof aRef).toLowerCase() === 'string' || aRef instanceof String;

    static isUpperCase(aChar) {
        return String(aChar).toUpperCase() === String(aChar);
    }
}

export const generateUUID = () => {
    const uuidv1 = require('uuid/v1');
    return uuidv1();
};

export const formatName = (nameStr) => {
    let nameStrArr = (nameStr || '').split(' ');
    if (nameStrArr.length > 1) {
        nameStr =
            nameStrArr[0] +
            ' ' +
            nameStrArr[nameStrArr.length - 1].charAt(0) +
            '.';
    }
    return nameStr;
};

// export const parseEmojis = (value) => {
//     let emojisArray = toArray(value);
//     let newValue = emojisArray.reduce((previous, current) => {
//         if (typeof current === 'string') {
//             return previous + current;
//         }
//         return previous + current.props.children;
//     }, '');
//     return newValue;
// };
