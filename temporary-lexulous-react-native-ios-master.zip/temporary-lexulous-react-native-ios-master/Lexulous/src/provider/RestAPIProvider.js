import axios from 'axios';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import qs from 'qs';
let instance;

//const mime = require('mime');

const getInstance = () => {
    if (!instance)
        instance = axios.create({
            baseURL: ConfigurationWrapper.getSpecificLexulousGameConfiguration('base_url'),
            timeout: 10000,
        });
    return instance;
};

export default class RestAPIProvider {
    static getPuzzleData = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));
        let a = await instance.post('/archivegame', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static sendPuzzleMoveData = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));
        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getLastGamesStatus = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/archivegameslist', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getUserProfile = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));
        let a = await instance.post('/user', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getDictionaryData = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('json', JSON.stringify(params));
        let a = await instance.post(ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('dictionary_url'), urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendPuzzlePass = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getArchivedPuzzle = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/archivegame', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getPuzzleRanking = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/stats', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });

        return a.data;
    };

    static getWordValidity = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getGameFeed = async (params, useArchiveGame) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post(useArchiveGame ? '/archivegame' : '/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendEmailMove = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendEmailPass = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendEmailSwap = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendEmailResign = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static deleteEmailGame = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static resignEmailGame = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getEmailGameStats = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/stats', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static nextGameUrl = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/gameslist', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendEmailRematch = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/archivegame', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };
    static getSettings = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/user', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static setSettings = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/user', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendMessage = async (params) => {
        let instance = getInstance();
        let urlParams = qs.stringify({
            params: JSON.stringify(params),
        });

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static setGameNotes = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getGameNotes = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static batch = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/batch', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static sendImage = async (params, file) => {
        /*
        let instance = getInstance();
        let formData = new FormData();
        let extension = mime.getExtension(file.type);
        formData.append('userfile', file, generateUUID() + "." + extension);
        let
            a = await instance(
                {
                    url: '/uploadchatimage',
                    method: "post",
                    headers: {
                        'content-type': 'multipart/form-data'
                    },
                    params: {
                        params: JSON.stringify(params)
                    },
                    data: formData
                }
            );
        return a.data;
        */
    };

    static sendChallengeMove = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static readAllChatMessages = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/game', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getUniqueWordsPlayedCount = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/stats', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getHeadToHeadStats = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/stats', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static friendApi = async (params) => {
        let instance = getInstance();
        let urlParams = new URLSearchParams();
        urlParams.append('params', JSON.stringify(params));

        let a = await instance.post('/friend', urlParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        return a.data;
    };

    static getDefinationByApi = async (word) => {
        let url = 'https://www.lexulous.com/v2/ajax/callUrlAjax.php';
        let data = {
            action: 'get_word_meaning',
            mobile: 'y',
            meaning: 'y',
            dic: 'twl',
            word: word,
        };
        let params = {
            method: 'POST',
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
            },
            data: qs.stringify(data),
            url,
        };
        let wordArray = await axios(params)
            .then((response) => response.data)
            .catch((error) => {
                console.log('error', error);
            });
        return wordArray;
    };
}
