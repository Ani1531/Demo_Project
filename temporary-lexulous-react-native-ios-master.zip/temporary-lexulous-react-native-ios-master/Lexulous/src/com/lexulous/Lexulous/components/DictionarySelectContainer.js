// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCircle as fasCircle } from '@fortawesome/free-solid-svg-icons';
import { faCircle as falCircle, faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { library } from '@fortawesome/fontawesome-svg-core';
library.add(falCircle, fasCircle);
import { translate } from '../commons/translations/LangTransator';
import themeConfigutation from '../commons/ThemeConfiguration';

type DictionarySelectContainerProps = {
    btnTxt: string,
    editingFinishedHandler: (string) => void,
    editingCancledHandler: () => void,
};

type DictionarySelectContainerState = {
    selectedDictionary: string,
    validDictionaries: Array<{ dictionary: string, selected: boolean }>,
};

class DictionarySelectContainer extends React.Component<DictionarySelectContainerProps, DictionarySelectContainerState> {
    state = {
        selectedDictionary: translate('dict_us'),
        validDictionaries: [
            { dictionary: translate('dict_us'), selected: true },
            { dictionary: translate('dict_uk'), selected: false },
            { dictionary: translate('dict_it'), selected: false },
            { dictionary: translate('dict_fr'), selected: false },
        ],
    };

    updateSelectedDictionary = (data: string, index: number) => {
        let validDictionaries = [...this.state.validDictionaries];
        let srch_data = validDictionaries[index];

        srch_data.selected = true;
        validDictionaries.forEach((it) => {
            if (it.dictionary !== data) {
                it.selected = false;
            }
        });

        this.setState({ validDictionaries });

        this.setState({ selectedDictionary: data });
    };

    playGame = () => {
        if (this.state.selectedDictionary !== '') {
            this.props.editingFinishedHandler(this.state.selectedDictionary);
        }
    };

    renderValidDictionaries = () => {
        return (
            <View>
                {this.state.validDictionaries.map((element, index) => {
                    return (
                        <Pressable
                            onPress={() => this.updateSelectedDictionary(element.dictionary, index)}
                            style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                padding: 6,
                                marginHorizontal: 20,
                            }}
                            key={index}
                        >
                            <Text style={{ paddingRight: 30, color: themeConfigutation.getColor('#000') }}>
                                {element.dictionary}
                            </Text>
                            <View
                                style={{
                                    height: 20,
                                    width: 20,
                                    borderRadius: 30,
                                    borderColor: '#1d9df1',
                                    borderWidth: 2,
                                    justifyContent: 'center',
                                    alignContent: 'center',
                                }}
                            >
                                {element.selected === true ? (
                                    <FontAwesomeIcon
                                        icon={fasCircle}
                                        size={12}
                                        color={'#1d9df1'}
                                        style={{ alignSelf: 'center' }}
                                    />
                                ) : null}
                            </View>
                        </Pressable>
                    );
                })}
            </View>
        );
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View style={[styles.popupContainer, { backgroundColor: themeConfigutation.getColor('#fafafa') }]}>
                    <Pressable onPress={() => this.props.editingCancledHandler()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Text style={[styles.PopupHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('lang_Pref')}
                    </Text>
                    {this.renderValidDictionaries()}
                    <Pressable
                        style={[styles.buttonStyle, { shadowColor: themeConfigutation.getColor('#000') }]}
                        onPress={this.playGame}
                    >
                        <Text style={styles.savebBtnText}>{this.props.btnTxt}</Text>
                    </Pressable>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    popupContainer: {
        flexDirection: 'column',
        maxWidth: 320,
        maxHeight: 350,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    savebBtnText: {
        color: '#ffffff',
        textAlign: 'center',
        paddingHorizontal: 16,
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    PopupHeaderStyle: {
        color: '#ffffff',
        textAlign: 'center',
        paddingHorizontal: 16,
        marginBottom: 8,
        fontWeight: 'bold',
    },
    buttonStyle: {
        marginVertical: 16,
        padding: 8,
        borderRadius: 5,
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        backgroundColor: '#1d9df1',
    },
});

export default DictionarySelectContainer;
