import ConfigurationWrapper from './ConfigurationWrapper';

require('format-unicorn');

export const getAvatarUrl = (avatar_id) =>
    ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('avatar_url') +
    avatar_id +
    '.png';
export const openUserStatsPage = (user) => {
    let url = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
        'site_domain_user_stats_page'
    ).formatUnicorn(user);
    spawnWindow(url);
};

export const openUserGiftsPage = (user) => {
    let url = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
        'site_domain_user_gifts_page'
    ).formatUnicorn(user);
    spawnWindow(url);
};

export const openPurchaseProPage = (withGift = true) => {
    let user = {
        guid: ConfigurationWrapper.getSpecificLexulousGameConfiguration('guid'),
    };
    if (withGift) {
        replaceLocation(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'purchase_pro_page'
            ).formatUnicorn(user)
        );
    } else {
        let purchaseUrl =
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'purchase_page'
            );
        if (typeof purchaseUrl === 'undefined') {
            replaceLocation(
                ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                    'purchase_pro_page'
                ).formatUnicorn(user)
            );
        } else {
            replaceLocation(purchaseUrl);
        }
    }
};

export const replaceLocation = (url) => {
    if (
        !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'replace_location'
        )
    ) {
        let method =
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'replace_location'
            );
        method(url);
    } else {
        window.top.location = url;
    }
};

export const spawnWindow = (url) => {
    if (
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'spawn_window'
        )
    ) {
        let method =
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'spawn_window'
            );
        method(url);
    } else {
        window.top.open(url);
    }
};

export const getChatAttachmentUrl = (filename) =>
    ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
        'image_bucket_url'
    ).formatUnicorn({ filename });

export const proChangeUrl = (gid) => {
    let urlArr = window.location.href
        .replace('https://', '')
        .replace('http://', '')
        .split('/');
    let url = urlArr.slice(1, urlArr.length - 1).join('/') + '/' + gid;
    window.history.replaceState('', '', '/' + url);
};
