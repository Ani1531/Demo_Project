import { svcconGameListUpdate, glViaBoardInfoUpdate, actionReadChat } from '../com/lexulous/Lexulous/gameslist/GLAction';
import dataServer from '../com/lexulous/Lexulous/store/Store';
import { gameBoardDataExchanger } from './GameBoardDataExchange';
import { actionUpdateUserSettings } from '../com/lexulous/Lexulous/userprofile/PFLAction';
import bannerAd from '../com/lexulous/Lexulous/commons/ads/BannerAd';
import interstitialAd from '../com/lexulous/Lexulous/commons/ads/InterstitialAd';
import { handleException } from '../com/lexulous/Lexulous/commons/RJUtils';
import {
    actionGLBLCancelSentFriendRequest,
    actionGLBLCensorEvent,
    actionGLBLInsertSentFriendRequest,
    actionGLBLMkFriendEvent,
    actionGLBLRmAddedFriendReqEvent,
    actionGLBLRmFriendReqEvent,
    actionGLBLUncensorEvent,
} from '../com/lexulous/Lexulous/friends/FndAction';

export default class ServiceWrapper {
    static getLocalStorage = (key) => null;

    static setLocalStorage = (key, value) => null;

    static openSupport = (onSupportFunc) => onSupportFunc && onSupportFunc();

    static nativeGameListUpdate = (data) => dataServer.getStore().dispatch(svcconGameListUpdate(data));

    static getNativeGUID = () => dataServer.getGUID();

    static getNativeUUID = () => dataServer.getUUID();

    static nativeUpdateUserSettings = (settings) => {
        dataServer.getStore().dispatch(actionUpdateUserSettings(settings));
    };

    static nativeGameListUpdateViaBoardInfo = (data) => dataServer.getStore().dispatch(glViaBoardInfoUpdate(data));

    static nativeGameListReadChat = (data) => dataServer.getStore().dispatch(actionReadChat(data));

    static nativeGetBannerAdsHeight = () => bannerAd.adHeight;

    static nativeShowBannerAds = (yoffset, onBannerReceive, onBannerFail) =>
        bannerAd.showBannerAd(yoffset, onBannerReceive, onBannerFail);

    static nativeHideBannerAds = () => bannerAd.hideBannerAd();

    static nativeShowInterstitialAd = (nextFunc) => {
        interstitialAd.showInterstitialAd(true, () => {
            nextFunc;
        });
    };

    static getDataFromCache = async (cacheName, cacheKey) => {};

    static setDataIntoCache = (cacheName, cacheKey, response) => null;

    static handleCrashReport = (error) => {
        handleException(error);
    };

    static onBlindGameMove = () => null;
    static notifyContextStore = (data) => null;
    static updateContextStore = (data) => null;

    static showDesktopNotification = (notificationInfo) => null;

    static sendFriendRequest = (data) => {
        dataServer.getStore().dispatch(actionGLBLInsertSentFriendRequest(data));
    };

    static cancelFriendRequest = (data) => {
        dataServer.getStore().dispatch(actionGLBLCancelSentFriendRequest(data));
    };

    static rejectFriendRequest = (data) => {
        dataServer.getStore().dispatch(actionGLBLRmFriendReqEvent(data));
    };

    static acceptFriendRequest = (data) => {
        dataServer.getStore().dispatch(actionGLBLMkFriendEvent(data));
    };

    static removeFriend = (data) => {
        dataServer.getStore().dispatch(actionGLBLRmAddedFriendReqEvent(data));
    };

    static censorPlayer = (data) => {
        dataServer.getStore().dispatch(actionGLBLCensorEvent(data));
    };

    static uncensorPlayer = (data) => {
        dataServer.getStore().dispatch(actionGLBLUncensorEvent(data));
    };

    static getDeskChatScamAlertStatus = (isLobbyChat, func) => null;

    static setDeskChatScamAlertStatus = (isLobbyChat) => null;
}
