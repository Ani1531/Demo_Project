// @flow
import type { Busy, BusyAction } from '../commons/RJTypes';
import { SET_BUSY, SET_FREE } from '../commons/Constants';

const BusyInitState: Busy = {
    busy: false,
};

export default function BusyReducer(state: Busy = BusyInitState, action: BusyAction) {
    switch (action.type) {
        case SET_BUSY: {
            if (state.busy != true) {
                return { ...state, ...{ busy: true } };
            }
            return state;
        }
        case SET_FREE: {
            if (state.busy != false) {
                return { ...state, ...{ busy: false } };
            }
            return state;
        }
        default:
            return state;
    }
}
