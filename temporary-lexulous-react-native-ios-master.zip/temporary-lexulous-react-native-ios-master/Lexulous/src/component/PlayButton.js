import React, { useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import TileTouchableOpacity from '../component/TileTouchableOpacity';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import { connect } from 'react-redux';
import get from 'lodash/get';
import MoveStrengthView from './MoveStrengthView';
import useInterval from '../provider/UseInterval';
import { isLiveGame } from '../service/GamePlayService';
import TooltipWrapper from './TooltipWrapper';
import DimensionUtils from '../utils/DimensionUtils';
import { isNumber } from '../utils/Utils';
import S14Text from './S14Text';
import FontAwesomeSpin from './FontAwesomeSpin';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

const eventBus = require('js-event-bus')();

function RenderMoveStrength(props) {
    const [percentage, setPercentage] = useState(0);
    // useInterval to apply move strength percentage animation when props "enable" is true
    useInterval(
        () =>
            !props.moveStrengthPercentage
                ? setPercentage(percentage < 100 ? percentage + 1 : 0)
                : {},
        10
    );
    return props.enable ? (
        <TooltipWrapper
            style={[styles.linearGradient, { height: props.height }]}
            tooltip={
                'Move strength: ' +
                Math.round(props.moveStrengthPercentage) +
                '%'
            }
            expTooltip={true}
        >
            <MoveStrengthView
                colors={[
                    ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
                    ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
                ]}
                percentage={props.moveStrengthPercentage || percentage}
            />
        </TooltipWrapper>
    ) : null;
}

class PlayButton extends React.PureComponent {
    state = {
        disabled: false,
        hidden: this.props.hidden,
        backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
        onPlayPress: this.props.onPlayPress,
        outputs: this.props.outputs,
        playButtonText: this.props.playButtonText,
        currentScore: '',
        loaderVisible: false,
        loaderColor: ColorConfig.LOADER_COLOR,
    };

    constructor(props) {
        super(props);
        this.playButtonTextContainerRef = React.createRef();
    }

    componentDidUpdate = () => {
        TooltipActionWrapper.rebuild();
    };
    getPlayButtonStyles = () => ({
        // width: this.props.layout.layoutButtonStyles ? this.props.layout.layoutButtonStyles.width * 1.4 : Config.PLAY_BUTTON_FIXED_WIDTH,
        height: '100%',
        width: '100%',
        margin: DimensionUtils.isMobile() ? 5 : undefined,
        overflow: 'hidden',
    });

    getButtonFontSizeObj = () => {
        let fontSize = this.props.layout.fontSize
            ? this.props.layout.fontSize
            : Config.PLAY_BUTTON_FIXED_FONT_SIZE;

        fontSize += DimensionUtils.isMobile() ? 1 : 0;

        return {
            fontSize,
        };
    };

    getCurrentScoreStyles = () => ({
        fontSize: this.props.layout.layoutCellDimen / 2.3,
        marginLeft: 3,
    });

    shouldShowPlayButton = () => {
        let tiles = this.props.getTiles() || [];
        let placedTiles = (tiles || []).filter((tile) => tile.position);
        let placedTilesCount = (placedTiles || []).length;
        if (
            get(this.props, 'game.guid') &&
            !get(this.props, 'game.archiveGameView')
        ) {
            if (get(this.props, 'game.showingAnalyseMove')) return true;
            else if (get(this.props, 'game.gameHasEnded')) {
                return true;
            } else if (
                ![Config.GAME_TYPE_PUZZLE].includes(
                    get(this.props, 'game.game_type')
                ) &&
                ((!get(this.props, 'game.pid') &&
                    !!get(this.props, 'game.gid')) ||
                    (!!get(this.props, 'game.pid') &&
                        get(this.props, 'game.pid') !==
                            get(this.props, 'game.currentTurn')))
            ) {
                return true;
            } else if (
                placedTilesCount > 0 &&
                ([Config.GAME_TYPE_PUZZLE].includes(
                    get(this.props, 'game.game_type')
                ) ||
                    !get(this.props, 'game.pid') ||
                    (!!get(this.props, 'game.pid') &&
                        get(this.props, 'game.pid') ===
                            get(this.props, 'game.currentTurn')))
            ) {
                return true;
            } else if (
                ![Config.GAME_TYPE_PUZZLE].includes(
                    get(this.props, 'game.game_type')
                ) &&
                get(this.props, 'game.pid') !==
                    get(this.props, 'game.currentTurn')
            ) {
                if (
                    get(this.props, 'game.game_type') ===
                        Config.GAME_TYPE_EMAIL ||
                    (get(this.props, 'game.gid') &&
                        !get(this.props, 'game.pid'))
                ) {
                    return true;
                }
            }
        }
        return false;
    };

    isVisible = () => !this.state.hidden;

    getButtonText = () => {
        if (
            get(this.props, 'game.gameHasEnded') ||
            get(this.props, 'game.showingAnalyseMove')
        ) {
            return get(this.props, 'game.game_type') === Config.GAME_TYPE_EMAIL
                ? 'Next'
                : 'Close';
        } else if (
            ![Config.GAME_TYPE_PUZZLE].includes(
                get(this.props, 'game.game_type')
            ) &&
            !get(this.props, 'game.pid') &&
            get(this.props, 'game.gid')
        ) {
            return 'Exit';
        } else if (
            get(this.props, 'game.game_type') === Config.GAME_TYPE_EMAIL &&
            get(this.props, 'game.currentTurn') !== get(this.props, 'game.pid')
        ) {
            return 'Next';
        } else return 'Play';
    };

    shouldShowLoader = () =>
        !!get(this.props, 'game.showPlayButtonSpinnerData.visible');

    getBackgroundColor = () => {
        if (get(this.props, 'game.gameHasEnded'))
            return get(this.state, 'backgroundColor') ===
                ColorConfig.PLAY_BUTTON_BACKGROUND_HOVER_COLOR
                ? this.state.backgroundColor
                : ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR;

        if (
            get(this.props, 'game.game_type') === Config.GAME_TYPE_EMAIL &&
            (get(this.props, 'game.gameHasEnded') ||
                get(this.props, 'game.pid') !==
                    get(this.props, 'game.currentTurn'))
        ) {
            return get(this.state, 'backgroundColor') ===
                ColorConfig.STANDARD_BUTTON_HOVER_BACKGROUND_COLOR
                ? this.state.backgroundColor
                : DimensionUtils.isNative()
                ? ColorConfig.NATIVE_BUTTON_BACKGROUND_BLUE_COLOR
                : ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR;
        }

        if (get(this.props, 'game.showPlayButtonSpinnerData.backgroundColor')) {
            return get(
                this.props,
                'game.showPlayButtonSpinnerData.backgroundColor'
            );
        }

        if (get(this.state, 'backgroundColor')) {
            return this.state.backgroundColor;
        }

        if (get(this.props, 'game.playButtonWordValid')) {
            return ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR;
        }

        return ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR;
    };

    onPlayButtonHoverIn = () => {
        if (
            this.getBackgroundColor() ===
            ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR
        ) {
            this.setState({
                backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_HOVER_COLOR,
            });
        } else if (
            this.getBackgroundColor() ===
            ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR
        ) {
            this.setState({
                backgroundColor:
                    ColorConfig.STANDARD_BUTTON_HOVER_BACKGROUND_COLOR,
            });
        }
    };

    onPlayButtonHoverOut = () => this.setState({ backgroundColor: undefined });

    onPlayButtonTextChanged = (text) =>
        this.playButtonTextContainerRef &&
        this.playButtonTextContainerRef.current &&
        this.playButtonTextContainerRef.current.setJustifyContent('center');

    onPlayButtonPress = () => {
        if (this.shouldShowLoader() && isLiveGame()) return;
        this.props.onPlayPress && this.props.onPlayPress();
    };

    isMyTurn = () =>
        String(this.props.game.currentTurn) === String(this.props.game.pid) ||
        this.props.game.game_type === Config.GAME_TYPE_PUZZLE;

    getPlayButtonBackgroundColor = () => ({
        backgroundColor: this.shouldShowLoader()
            ? (get(this.props, 'game.players') || []).some(
                  (player) => player.guid === get(this.props, 'game.guid')
              ) && get(this.props, 'game.playButtonWordValid')
                ? ColorConfig.DICTIONARY_VALID_TEXT_COLOR
                : this.getBackgroundColor()
            : this.isMyTurn() && !!this.props.game.playButtonWordValid
            ? ColorConfig.DICTIONARY_VALID_TEXT_COLOR
            : this.getBackgroundColor(),
    });

    getPlayButtonPadding = () => {
        let text = this.getButtonText();
        return {
            marginLeft:
                text === 'Play'
                    ? !!get(this.props, 'game.playButtonScoreText')
                        ? Config.SIDE_PANEL_WRAPPER_PADDING / 2
                        : Config.SIDE_PANEL_WRAPPER_PADDING
                    : Config.SIDE_PANEL_WRAPPER_PADDING,
            marginRight:
                (text === 'Play'
                    ? !!get(this.props, 'game.playButtonScoreText')
                        ? Config.SIDE_PANEL_WRAPPER_PADDING / 2
                        : Config.SIDE_PANEL_WRAPPER_PADDING
                    : Config.SIDE_PANEL_WRAPPER_PADDING) +
                (!!get(this.props, 'game.playButtonScoreText') &&
                isNumber(this.props.game.moveStrengthPercentage)
                    ? 3
                    : 0),
        };
    };

    render = () =>
        this.shouldShowPlayButton() ? (
            <TouchableOpacity
                onPress={this.onPlayButtonPress}
                style={[
                    styles.playButton,
                    this.getPlayButtonStyles(),
                    this.getPlayButtonBackgroundColor(),
                ]}
                onMouseOver={this.onPlayButtonHoverIn}
                onMouseOut={this.onPlayButtonHoverOut}
                activeOpacity={1}
            >
                <TileTouchableOpacity
                    ref={this.playButtonTextContainerRef}
                    style={[styles.directionRow, styles.widthHundred]}
                >
                    <View
                        style={[
                            styles.playButtonTextContainer,
                            this.getPlayButtonPadding(),
                        ]}
                    >
                        {this.shouldShowLoader() ? null : (
                            <S14Text
                                style={[
                                    styles.playButtonText,
                                    this.getButtonFontSizeObj(),
                                    this.shouldShowLoader() && !isLiveGame()
                                        ? styles.opacity0
                                        : null,
                                ]}
                            >
                                {this.getButtonText()}
                            </S14Text>
                        )}
                        {!!get(this.props, 'game.playButtonScoreText') &&
                        !this.shouldShowLoader() ? (
                            <S14Text
                                style={[
                                    styles.scoreText,
                                    this.getCurrentScoreStyles(),
                                    this.getButtonFontSizeObj(),
                                    this.shouldShowLoader() && !isLiveGame()
                                        ? styles.opacity0
                                        : null,
                                ]}
                            >
                                {get(this.props, 'game.playButtonScoreText')}
                            </S14Text>
                        ) : null}
                    </View>

                    {!!get(this.props, 'game.playButtonScoreText') &&
                    !this.shouldShowLoader() ? (
                        <View
                            style={{
                                position: 'absolute',
                                right: 0,
                                top: 0,
                                bottom: 0,
                                backgroundColor: 'yellow',
                            }}
                        >
                            <RenderMoveStrength
                                height={
                                    DimensionUtils.isMobile()
                                        ? '100%'
                                        : this.props.layout.layoutButtonStyles
                                        ? this.props.layout.layoutButtonStyles
                                              .height
                                        : Config.PLAY_BUTTON_FIXED_HEIGHT
                                }
                                enable={
                                    !!get(
                                        this.props,
                                        'game.playButtonScoreText'
                                    ) &&
                                    isNumber(
                                        this.props.game.moveStrengthPercentage
                                    )
                                }
                                moveStrengthPercentage={
                                    this.props.game.moveStrengthPercentage
                                }
                            />
                        </View>
                    ) : null}
                </TileTouchableOpacity>
                {this.shouldShowLoader() ? (
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            styles.loaderContainer,
                        ]}
                    >
                        <FontAwesomeSpin />
                    </View>
                ) : null}
            </TouchableOpacity>
        ) : null;

    getText = () => this.state.outputs || this.props.outputs;
}

const styles = StyleSheet.create({
    playButton: {
        backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 5,
        overflow: 'hidden',
        minWidth: 60,
    },
    playButtonTextContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    playButtonText: {
        color: ColorConfig.PLAY_BUTTON_TEXT_COLOR,
    },
    commonButton: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        margin: 3,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        flexDirection: 'row',
    },

    scoreText: {
        color: ColorConfig.PLAY_BUTTON_TEXT_COLOR,
    },

    directionRow: {
        flexDirection: 'row',
    },
    widthHundred: {
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    spaceBetweenRowStyle: { justifyContent: 'space-between' },
    loaderContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        borderRadius: 4,
        overflow: 'hidden',
    },
    linearGradient: {
        alignSelf: 'flex-end',
        justifyContent: 'flex-end',
        backgroundColor: '#cccccc',
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5,
        width: 5,
    },
    opacity0: {
        opacity: 0,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    tiles: state.tiles,
    layout: state.layout,
});

export default connect(mapStateToProps)(PlayButton);
