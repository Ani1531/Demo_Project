import React from 'react';
import { StyleSheet, View } from 'react-native';
import Slider, { SliderTooltip } from 'rc-slider';
import 'rc-slider/assets/index.css';

const { createSliderWithTooltip } = Slider;
const Range = createSliderWithTooltip(Slider.Range);

export default class MultiSlider extends React.Component {
    getPointer = () => ({
        cursor: 'pointer',
        backgroundColor: this.props.nativeSlider ? '#1d9df1' : '#3484f0',
    });
    getTrackStyle = () => ({
        backgroundColor: this.props.nativeSlider ? '#1d9df1' : '#3484f0',
    });
    getLowValue = () => {
        return this.props.nativeSlider ? 600 : 0;
    };
    getHighValue = () => {
        return this.props.nativeSlider ? 4200 : 5000;
    };
    getStepValue = () => {
        return this.props.nativeSlider ? 50 : 100;
    };
    render = () => (
        <View>
            <View style={styles.sliderContainer}>
                <Range
                    min={this.getLowValue()}
                    max={this.getHighValue()}
                    step={this.getStepValue()}
                    trackStyle={[this.getTrackStyle()]}
                    handleStyle={this.getPointer()}
                    defaultValue={[this.props.minValue, this.props.maxValue]}
                    tipFormatter={(value) => `${value}`}
                    onChange={(event) => this.props.onChangeValue(event[0], event[1])}
                />
            </View>
        </View>
    );
}
const styles = StyleSheet.create({
    sliderContainer: {
        width: '100%',
    },
});
