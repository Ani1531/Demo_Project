import React from 'react';
import { ReactComponent as Spark } from '../assets/icon/bolt.svg';
import ColorConfig from '../configs/ColorConfig';

export default class SparkWrapper extends React.PureComponent {
    render = () => (
        <Spark fill={ColorConfig.TRANSPARENT} style={this.props.style} />
    );
}
