import ReactTooltip from 'react-tooltip';

export default class TooltipActionWrapper {
    static rebuild = () => ReactTooltip.rebuild();
    static hide = () => ReactTooltip.hide();
}