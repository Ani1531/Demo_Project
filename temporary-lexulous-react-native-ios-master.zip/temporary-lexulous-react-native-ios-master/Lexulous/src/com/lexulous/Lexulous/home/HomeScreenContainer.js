// @flow
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { View, Pressable, Linking, StatusBar } from 'react-native';
import * as CONSTANTS from '../commons/Constants';
import type { HomeViewProps } from '../commons/RJTypes';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import LoadingContainer from '../components/LoadingIndicator';
import { faHome, faUserFriends, faPlus, faCog, faQuestionCircle } from '@fortawesome/pro-light-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import GLContainer from '../gameslist/GLContainer';
import FriendsContainer from '../friends/FriendsContainer';
import PFLVwContainer from '../profileview/PFLVwContainer';
import GameFactoryContainer from '../gamesfactory/GameFactoryContainer';
import soundManager from '../commons/SoundManager';
import GetHelpContainer from '../components/GetHelpContainer';
import { updatePopupVisibility, clearPopups } from '../reducers/popupreducer/PopupAction';
import AlertBox from '../components/AlertBox';
import { translate } from '../commons/translations/LangTransator';
import adMgr from '../commons/ads/AdMgr';
import interstitialAd from '../commons/ads/InterstitialAd';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import HostAGameContainer from '../components/HostAGameContainer';
import { SafeAreaView } from 'react-native-safe-area-context';

const Tab = createBottomTabNavigator();

class HomeScreenContainer extends React.Component<HomeViewProps> {
    componentDidMount() {
        adMgr.onAppInit();
        this.props.navigation.setOptions({
            headerRight: () => this.getHelpIcon(),
        });
    }

    render() {
        return this.HomeTabs();
    }

    getHelpIcon = () => {
        return (
            <Pressable
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('help_container_opened', 'home_screen_container');
                    this.openHelpContainer();
                }}
                style={{ padding: 16 }}
            >
                <FontAwesomeIcon icon={faQuestionCircle} size={22} color={'white'} />
            </Pressable>
        );
    };

    HomeTabs() {
        return (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <View style={{ flex: 1 }}>
                    <StatusBar hidden={false} barStyle={'light-content'} animated={true} />
                    {this.renderGetHelpContainer()}
                    {this.renderHostGameContainer()}
                    <LoadingContainer />
                    <AlertBox />
                    <Tab.Navigator
                        screenOptions={({ route }) => ({
                            tabBarIcon: ({ focused, color, size }) => {
                                let iconName;
                                if (route.name === 'Home') {
                                    iconName = focused ? faHome : faHome;
                                } else if (route.name === 'Friends') {
                                    iconName = focused ? faUserFriends : faUserFriends;
                                } else if (route.name === 'New Game') {
                                    iconName = focused ? faPlus : faPlus;
                                } else if (route.name === 'Settings') {
                                    iconName = focused ? faCog : faCog;
                                } else {
                                    iconName = focused ? faHome : faHome;
                                }
                                return <FontAwesomeIcon icon={iconName} size={size} color={color} />;
                            },
                        })}
                        tabBarOptions={{
                            activeTintColor: 'tomato',
                            inactiveTintColor: 'gray',
                            style: {
                                justifyContent: 'center',
                                backgroundColor: themeConfigutation.getColor('#ffffff'),
                            },
                            safeAreaInsets: {
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0,
                            },
                            keyboardHidesTabBar: true, // check it for ios devices
                        }}
                        backBehavior={() => {}}
                    >
                        <Tab.Screen
                            name={translate('home')}
                            component={GLContainer}
                            listeners={{
                                tabPress: (e) => {
                                    soundManager.playSound(soundManager.RJSound.RJSoundClick);
                                    interstitialAd.showInterstitialAd(true, () => {
                                        this.closeAllPopup();
                                    });
                                    rjAnalytics.sendAnalyticsEvent('home_tab_pressed', 'home_screen_container');
                                },
                            }}
                        />
                        <Tab.Screen
                            name={translate('friend_tab')}
                            component={FriendsContainer}
                            listeners={{
                                tabPress: (e) => {
                                    soundManager.playSound(soundManager.RJSound.RJSoundClick);
                                    interstitialAd.showInterstitialAd(true, () => {
                                        this.closeAllPopup();
                                    });
                                    rjAnalytics.sendAnalyticsEvent('friend_tab_pressed', 'home_screen_container');
                                },
                            }}
                        />
                        <Tab.Screen
                            name={translate('new_Game')}
                            component={GameFactoryContainer}
                            listeners={{
                                tabPress: (e) => {
                                    soundManager.playSound(soundManager.RJSound.RJSoundClick);
                                    interstitialAd.showInterstitialAd(true, () => {
                                        this.closeAllPopup();
                                    });
                                    rjAnalytics.sendAnalyticsEvent('new_game_tab_pressed', 'home_screen_container');
                                },
                            }}
                        />
                        <Tab.Screen
                            name={translate('settings')}
                            component={PFLVwContainer}
                            listeners={{
                                tabPress: (e) => {
                                    soundManager.playSound(soundManager.RJSound.RJSoundClick);
                                    interstitialAd.showInterstitialAd(true, () => {
                                        this.closeAllPopup();
                                    });
                                    rjAnalytics.sendAnalyticsEvent('settings_tab_pressed', 'home_screen_container');
                                },
                            }}
                        />
                    </Tab.Navigator>
                </View>
            </SafeAreaView>
        );
    }

    openHelpContainer = () => {
        this.props.clearPopups();
        this.props.updatePopupVisibility({ showHelpPopup: true });
    };

    closeHelpContainer = () => {
        this.props.clearPopups();
    };

    closeAllPopup = this.closeHelpContainer;

    getTutorial = () => {
        rjAnalytics.sendAnalyticsEvent('tutorial_opened', 'home_screen_container');
        this.props.navigation.navigate('Tutorial');
    };

    getUserForum = () => {
        rjAnalytics.sendAnalyticsEvent('forumLink_opened', 'home_screen_container');
        Linking.openURL(CONSTANTS.forumLink);
    };

    getCstmSupport = () => {
        rjAnalytics.sendAnalyticsEvent('customer_support_opened', 'home_screen_container');
        this.props.navigation.navigate('CustomerSupportScreen');
        this.closeHelpContainer();
    };

    getTermsPrivacy = () => {
        rjAnalytics.sendAnalyticsEvent('terms_privacyLink_opened', 'home_screen_container');
        Linking.openURL(CONSTANTS.kPrivacyPolicyUrl);
    };

    renderGetHelpContainer = () => {
        if (this.props.popups.showHelpPopup) {
            return (
                <GetHelpContainer
                    tutorialHandler={this.getTutorial}
                    userForumHandler={this.getUserForum}
                    cstmSupportHandler={this.getCstmSupport}
                    userPrivacyHandler={this.getTermsPrivacy}
                    closePopupHandler={() => {
                        rjAnalytics.sendAnalyticsEvent('help_container_closed', 'home_screen_container');
                        this.closeHelpContainer();
                    }}
                />
            );
        } else {
            return null;
        }
    };

    renderHostGameContainer = () => {
        if (this.props.popups.showHostGamePopup) {
            return <HostAGameContainer closePopupHandler={this.props.clearPopups} />;
        } else return null;
    };
}

function mapStateToProps(state) {
    const { popups, utils } = state;
    return { popups, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            updatePopupVisibility,
            clearPopups,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreenContainer);
