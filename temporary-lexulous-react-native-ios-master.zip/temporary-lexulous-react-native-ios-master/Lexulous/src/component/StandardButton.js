import React from 'react';
import { Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import TooltipWrapper from './TooltipWrapper';
import S14Text from './S14Text';
import FontAwesomeSpin from './FontAwesomeSpin';

export default class StandardButton extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            backgroundColor: undefined,
        };
    }

    isLoaderVisible = () =>
        typeof this.props.loaderVisible !== 'undefined'
            ? this.props.loaderVisible
            : false;

    onMouseOver = () => {
        if (this.props.mouseHoverEffect) {
            this.setState({
                backgroundColor:
                    this.props.mouseHoverEffect.hoverBackgroundColor,
            });
        }

        if (this.props.onMouseOver) {
            this.props.onMouseOver();
        }
    };

    onMouseOut = () => {
        if (this.props.mouseHoverEffect) {
            this.setState({
                backgroundColor: undefined,
            });
        }

        if (this.props.onMouseOut) {
            this.props.onMouseOut();
        }
    };

    render = () => (
        <TooltipWrapper
            {...this.props}
            activeOpacity={1}
            onPress={this.props.onPress}
            onMouseOver={this.onMouseOver}
            onMouseOut={this.onMouseOut}
            style={[
                this.props.style,
                !!this.state.backgroundColor
                    ? { backgroundColor: this.state.backgroundColor }
                    : null,
            ]}
            tooltip={this.props.tooltip}
        >
            {this.props.children ? (
                this.props.children
            ) : (
                <S14Text
                    style={[
                        this.props.textStyle,
                        this.isLoaderVisible() ? styles.opacity0 : null,
                    ]}
                >
                    {this.props.text}
                </S14Text>
            )}

            {this.isLoaderVisible() ? (
                <View style={[StyleSheet.absoluteFill, styles.loaderContainer]}>
                    <FontAwesomeSpin
                        color={ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR}
                    />
                </View>
            ) : null}
        </TooltipWrapper>
    );
}

const styles = StyleSheet.create({
    opacity0: {
        opacity: 0,
    },
    loaderContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        borderRadius: 4,
        overflow: 'hidden',
    },
});
