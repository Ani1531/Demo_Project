import React from 'react';
import { Image } from 'react-native';

export default class AvatarImage extends React.Component {
    render = () => (
        <Image style={this.props.style} source={{ uri: this.props.uri }} />
    );
}
