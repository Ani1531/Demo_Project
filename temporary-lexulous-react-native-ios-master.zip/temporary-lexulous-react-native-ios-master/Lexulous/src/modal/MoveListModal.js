import React from 'react';
import DimensionUtils from '../utils/DimensionUtils';
import {
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import LayoutUtils from '../utils/LayoutUtils';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
//import DefinitionPanel from "../component/DefinitionPanel";
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { connect } from 'react-redux';
import get from 'lodash/get';
import TooltipWrapper from '../component/TooltipWrapper';
import MoveStrengthView from '../component/MoveStrengthView';
import { isSoloGame } from '../service/GamePlayService';
import PText from '../component/PText';
import S14Text from '../component/S14Text';
import S22Text from '../component/S22Text';

function handleToGettWordDefintion() {
    this.getWordDefintion(this.col2);
}

class MoveListModal extends React.Component {
    state = {
        isOpen: false,
        width: Math.min(
            DimensionUtils.getWindowDimensions().width *
                (DimensionUtils.isMobile ? 0.7 : 1),
            700
        ),
        height: Math.min(
            DimensionUtils.getWindowDimensions().height *
                (DimensionUtils.isMobile ? 0.8 : 0.95),
            500
        ),
        wordsPlayed: [],
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
    };

    constructor(props) {
        super(props);
        this.definitionPanelRef = React.createRef();
    }

    show = () => {
        this.setState(
            { isOpen: true, moveDataToDefine: false },
            this.movelistScrollToEnd
        );
    };

    onClose = () => this.setState({ isOpen: false });

    isOpen = () => this.state.isOpen;

    componentDidMount = () => {};

    componentWillUnmount = () => {};

    isCompleteInfo = (players) =>
        players.length > 0 &&
        players.every((player) => !!player && !!player.name);

    movelistScrollToEnd = () => {
        this.movelistScrollRef && this.movelistScrollRef.scrollToEnd();
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onClose();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    renderSerialColumn = () => {
        return (
            <View key={'movelist-view-serial-column'} style={styles.slColumn}>
                <View
                    key={'movelist-view-serial-column-#'}
                    style={[styles.slTableCell, styles.cellPadding]}
                >
                    <PText style={styles.slText}>#</PText>
                </View>
                {this.props.game.moveListCompleteData.map((v, i) => {
                    let sl = i + 1;
                    let cellStyle = [styles.slTableCell, styles.cellPadding];
                    if (
                        sl ===
                        Number(this.props.game.moveListCompleteData.length)
                    ) {
                        cellStyle = [
                            styles.slTableCell,
                            styles.cellPadding,
                            styles.borderBottomNone,
                        ];
                    }

                    return (
                        <View
                            key={'movelist-view-serial-column-#-' + i}
                            style={cellStyle}
                        >
                            <PText style={styles.slText}>{sl}</PText>
                        </View>
                    );
                })}
            </View>
        );
    };

    getPlayerSectionWidth = () => {
        const { players } = this.props.game;
        let length = (players || []).length;
        return { width: 96 / length + '%' };
    };

    renderPlayerMoves = (pid, index) => {
        let playerName = 'Player ' + pid;
        let playerMoves = [];
        this.props.game.moveListCompleteData.forEach((v, i) => {
            Object.entries(v).forEach(([key, obj]) => {
                if (parseInt(key) === pid) {
                    playerName = obj.player.name;
                    let moveStrength =
                        obj.bestScore > 0
                            ? (obj.score / obj.bestScore) * 100
                            : 0;
                    if (moveStrength > 100) moveStrength = 100;
                    playerMoves.push({
                        word: obj.words.toUpperCase(),
                        score: obj.score,
                        moveStrength,
                        totalScore: obj.totalScore,
                    });
                }
            });
        });

        let noOfPlayers = (this.props.game.players || []).length;
        let lastColumn = noOfPlayers - 1 === index;

        let headingStyleKey = 'player' + pid + 'Heading';
        let scoreColumnStyleKey = 'player' + pid + 'ScoreColumn';

        let playerSectionStyle = [
            styles.playerSection,
            this.getPlayerSectionWidth(),
            lastColumn ? styles.borderRightRadius : null,
        ];

        let scoreColumnStyles = [
            styles[scoreColumnStyleKey],
            lastColumn ? styles.borderRightBottomRadius : null,
        ];

        return (
            <View
                key={'movelist-view-playermove-' + index}
                style={playerSectionStyle}
            >
                {playerMoves.length > 0 ? (
                    <View
                        key={'movelist-view-move-name-score-' + index}
                        style={[
                            styles[headingStyleKey],
                            styles.rowDirection,
                            lastColumn ? styles.borderRightTopRadius : null,
                        ]}
                    >
                        <View
                            key={'movelist-view-move-name-' + index}
                            style={[
                                styles.playerNameContainer,
                                styles.cellPadding,
                            ]}
                        >
                            {Number(pid) === 1 || Number(pid) === 3 ? (
                                <PText
                                    numberOfLines={1}
                                    ellipsizeMode={'tail'}
                                    style={[styles.wordText, styles.whiteText]}
                                >
                                    {playerName}
                                </PText>
                            ) : (
                                <PText
                                    numberOfLines={1}
                                    ellipsizeMode={'tail'}
                                    style={styles.wordText}
                                >
                                    {playerName}
                                </PText>
                            )}
                        </View>
                        <View
                            key={'movelist-view-move-score-' + index}
                            style={[
                                styles.playerScoreHeading,
                                styles.cellPadding,
                            ]}
                        >
                            {Number(pid) === 1 || Number(pid) === 3 ? (
                                <PText
                                    numberOfLines={1}
                                    ellipsizeMode={'tail'}
                                    style={[styles.whiteText]}
                                >
                                    Score
                                </PText>
                            ) : (
                                <PText
                                    numberOfLines={1}
                                    ellipsizeMode={'tail'}
                                    style={styles.scoreText}
                                >
                                    Score
                                </PText>
                            )}
                        </View>
                    </View>
                ) : (
                    <View
                        key={'movelist-view-move-name-score-' + index}
                        style={[styles[headingStyleKey], styles.cellPadding]}
                    >
                        {Number(pid) === 1 || Number(pid) === 3 ? (
                            <S14Text style={[styles.whiteText]}>
                                {playerName}
                            </S14Text>
                        ) : (
                            <S14Text style={styles.wordText}>
                                {playerName}
                            </S14Text>
                        )}
                    </View>
                )}

                {playerMoves.length > 0 ? (
                    <View
                        key={'movelist-view-move-word-row-' + index}
                        style={styles.rowDirection}
                    >
                        <View
                            key={'movelist-view-move-word-column-' + index}
                            style={styles.wordColumn}
                        >
                            {playerMoves.map((v, i) => {
                                let cellStyle = [
                                    styles.tableCell,
                                    styles.cellPadding,
                                ];
                                if (
                                    i ===
                                    Number(
                                        this.props.game.moveListCompleteData
                                            .length
                                    ) -
                                        1
                                ) {
                                    cellStyle = [
                                        styles.tableCell,
                                        styles.cellPadding,
                                        styles.borderBottomNone,
                                    ];
                                }

                                return (
                                    <View
                                        key={
                                            'movelist-view-move-word-score-' + i
                                        }
                                        style={cellStyle}
                                    >
                                        <TooltipWrapper
                                            style={[
                                                styles.rowDirection,
                                                styles.cellAlignCenter,
                                            ]}
                                            tooltip={v.word}
                                            expTooltip={true}
                                        >
                                            {!isSoloGame() && (
                                                <TooltipWrapper
                                                    style={styles.bestScore}
                                                    tooltip={
                                                        'Move strength: ' +
                                                        Math.round(
                                                            v.moveStrength
                                                        ) +
                                                        '%'
                                                    }
                                                    expTooltip={true}
                                                >
                                                    <MoveStrengthView
                                                        colors={[
                                                            ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
                                                            ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
                                                        ]}
                                                        percentage={
                                                            v.moveStrength
                                                        }
                                                    />
                                                </TooltipWrapper>
                                            )}
                                            <PText
                                                numberOfLines={1}
                                                ellipsizeMode={'tail'}
                                            >
                                                {v.word}
                                            </PText>
                                            <View
                                                key={
                                                    'movelist-view-move-score-' +
                                                    i
                                                }
                                            >
                                                <PText>
                                                    {' (' + v.score + ')'}
                                                </PText>
                                            </View>
                                        </TooltipWrapper>
                                    </View>
                                );
                            })}
                        </View>
                        <View
                            key={
                                'movelist-view-move-total-score-column-' + index
                            }
                            style={scoreColumnStyles}
                        >
                            {playerMoves.map((v, i) => {
                                let cellStyle = [
                                    styles.tableCell,
                                    styles.cellPadding,
                                ];
                                if (
                                    i ===
                                    Number(
                                        this.props.game.moveListCompleteData
                                            .length
                                    ) -
                                        1
                                ) {
                                    cellStyle = [
                                        styles.tableCell,
                                        styles.cellPadding,
                                        styles.borderBottomNone,
                                    ];
                                }

                                return (
                                    <View
                                        key={
                                            'movelist-view-move-totalscore-' + i
                                        }
                                        style={cellStyle}
                                    >
                                        <PText
                                            style={[
                                                styles.scoreText,
                                                styles.fontBold,
                                            ]}
                                        >
                                            {v.totalScore}
                                        </PText>
                                    </View>
                                );
                            })}
                        </View>
                    </View>
                ) : (
                    <View style={styles.notPLayingContainer}>
                        <PText style={styles.notPlayingText}>
                            {'(not playing)'}
                        </PText>
                    </View>
                )}
            </View>
        );
    };

    getScrollContainerStyle = () => ({
        paddingLeft: 10,
        paddingRight: 10,
        maxHeight: Math.round(
            (get(this.props, 'layout.layoutGamePlayAreaHeight') * 72) / 100
        ),
    });

    render = () => {
        return this.state.isOpen ? (
            <View
                key={'movelist-view-modalcontent'}
                style={this.getModalContentStyle()}
            >
                <View
                    key={'movelist-view-container'}
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getContainerDimension(),
                    ]}
                >
                    <View
                        key={'movelist-view-header'}
                        style={styles.dialogTitleContainerStyle}
                    >
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                            {'Moves List'}
                        </S22Text>

                        <TouchableOpacity
                            style={[styles.closeButtonContainer]}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <View
                                key={'movelist-view-close'}
                                style={[
                                    {
                                        backgroundColor:
                                            this.state.closeBGColor,
                                    },
                                    LayoutUtils.getDialogCloseButtonBGStyle(),
                                ]}
                            >
                                <FontAwesomeIcon
                                    icon={faTimes}
                                    size={DimensionUtils.isMobile() ? 20 : 24}
                                    style={this.getCloseButtonStyle()}
                                />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View
                        key={'movelist-view-word'}
                        style={this.getScrollContainerStyle()}
                    >
                        <ScrollView className={'appFlatList'}>
                            <View
                                key={'movelist-view-scroll'}
                                style={styles.rowDirection}
                            >
                                {/* Serial No. */}
                                {this.renderSerialColumn()}

                                {(this.props.game.players || []).map(
                                    (player, index) => {
                                        return this.renderPlayerMoves(
                                            parseInt(player.pid),
                                            index
                                        );
                                    }
                                )}
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </View>
        ) : null;
    };

    getContainerDimension = () => ({
        width: '90%',
        //maxHeight: '90%',
        paddingBottom: 24,
    });

    getSumUpto = (index, moveList = []) => {
        let subarray = moveList.slice(0, index + 1) || [];
        let sum = 0;
        let flatSubArray = subarray.flat();

        flatSubArray.map((word) => {
            let wordStr = JSON.stringify(word);
            let wordParts = wordStr.split(',');
            sum = Number(sum) + Number(wordParts[2]);
            return null;
        });

        return sum;
    };

    renderMoves = (elem, index) => (
        <View
            style={{
                flexDirection: 'column',
                borderColor: 'black',
                borderTopWidth: StyleSheet.hairlineWidth,
            }}
        >
            {this.renderPlayerWiseMove(elem, index)}
        </View>
    );

    renderPlayerWiseMove = (elem, index) =>
        elem.map((data, i) => {
            return this.renderRow(
                index + 1,
                Number(data.pid) === Number(this.props.game.pid) ||
                    (LiveGamePlayUtils.isObserving() && i === 0)
                    ? 'Move ' + (index + 1)
                    : '',
                data.word,
                data.score,
                data.totalScore,
                true
            );
        });

    onListLayout = (event) => {
        let { width, height } = event.nativeEvent.layout;
        this.setState({ listWidth: width, listHeight: height });
    };

    getTextColor = (columnNumber, rowNumber, col1, col2, col3, col4) => {
        if (rowNumber === 0 && [0, 1].includes(columnNumber))
            return ColorConfig.THREE_L_CELL_BACKGROUND_COLOR;
        if (rowNumber === 0)
            return ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR_DISABLED;
        if (
            columnNumber === 1 &&
            ['PASS', 'SWAP', 'CHALLENGE'].includes(col2) &&
            String(col3) === '0'
        )
            return ColorConfig.THREE_L_CELL_BACKGROUND_COLOR;
        return ColorConfig.DIALOG_MODAL_HEADING_TEXT_COLOR;
    };

    getRowContainerStyles = () => ({
        minWidth: this.props.layout.layoutCellDimen * 6,
    });

    getRowTextColor = (val, index, col1, col2, col3, col4) => ({
        color: this.getTextColor(val, index, col1, col2, col3, col4),
    });

    getDefinitionPanelLayout = (event) => {
        let { width, height } = event.nativeEvent.layout;
        this.setState({
            definitionPanelWidth: width,
            definitionPanelHeight: height,
        });
    };

    getLastMoveDefinitionPanelDimen = () => ({
        height: 50, //this.state.definitionPanelHeight,
        width:
            this.state.definitionPanelWidth - Config.SIDE_PANEL_WRAPPER_PADDING,
    });

    getWordDefintion = async (moveWord) => {
        this.setState({ moveDataToDefine: true });
        this.definitionPanelRef.current.updateMoveDefinition({ moveWord });
    };

    renderRow = (index, col1, col2, col3, col4, clickable) => {
        return (
            <View
                style={[
                    styles.columnDirection,
                    this.getRowContainerStyles(),
                    {
                        borderLeftWidth:
                            index === 0 ? StyleSheet.hairlineWidth : 0,
                    },
                ]}
            >
                <View
                    style={[
                        styles.border,
                        styles.widthHundred,
                        {
                            borderTopWidth:
                                col1 === ' ' ? StyleSheet.hairlineWidth : 0,
                        },
                    ]}
                >
                    <S14Text
                        style={[
                            styles.rowText,
                            this.getRowTextColor(
                                0,
                                index,
                                col1,
                                col2,
                                col3,
                                col4
                            ),
                        ]}
                    >
                        {col1}
                    </S14Text>
                </View>

                <TouchableOpacity
                    style={[styles.border, styles.widthHundred]}
                    onPress={
                        clickable && col2 !== ' '
                            ? handleToGettWordDefintion.bind({
                                  col2: col2,
                                  getWordDefintion: this.getWordDefintion,
                              })
                            : undefined
                    }
                >
                    <S14Text
                        style={[
                            styles.rowText,
                            styles.fontWeightMax,
                            this.getRowTextColor(
                                1,
                                index,
                                col1,
                                col2,
                                col3,
                                col4
                            ),
                        ]}
                    >
                        {col2}
                    </S14Text>
                </TouchableOpacity>
                <View style={[styles.border, styles.widthHundred]}>
                    <S14Text
                        style={[
                            {
                                alignSelf: Number.isInteger(col3)
                                    ? 'flex-end'
                                    : undefined,
                            },
                            styles.rowText,
                            this.getRowTextColor(
                                2,
                                index,
                                col1,
                                col2,
                                col3,
                                col4
                            ),
                        ]}
                    >
                        {col3}
                    </S14Text>
                </View>
                <View style={[styles.border, styles.widthHundred]}>
                    <S14Text
                        style={[
                            {
                                alignSelf: Number.isInteger(col4)
                                    ? 'flex-end'
                                    : undefined,
                            },
                            styles.rowText,
                            this.getRowTextColor(
                                3,
                                index,
                                col1,
                                col2,
                                col3,
                                col4
                            ),
                        ]}
                    >
                        {col4}
                    </S14Text>
                </View>
            </View>
        );
    };
}

const styles = StyleSheet.create({
    listsContainer: {
        flex: 1,
        flexDirection: 'column',
    },
    alignItemsCenter: {
        alignContent: 'center',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    widthFifty: {
        width: '50%',
    },
    widthHundred: {
        width: '100%',
    },
    columnDirection: {
        flexDirection: 'column',
    },
    rowDirection: {
        flexDirection: 'row',
    },
    rowText: {
        marginHorizontal: 2,
        fontWeight: 'bold',
    },
    flexOne: {
        flex: 1,
    },
    flexThree: {
        flex: 3,
    },
    flexFour: {
        flex: 4,
    },
    flexSix: {
        flex: 6,
    },
    fontWeightMax: {
        fontWeight: '900',
    },
    border: {
        borderColor: 'black',
        borderWidth: StyleSheet.hairlineWidth,
        borderTopWidth: 0,
        borderLeftWidth: 0,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
    dialogTitleContainerStyle: {
        paddingLeft: 10,
        paddingTop: 18,
        paddingRight: 17,
        paddingBottom: 16,
        flexDirection: 'row',
    },
    playerSection: {
        flexDirection: 'column',
        backgroundColor: 'rgb(244,243,239)',
        borderRightWidth: 1,
        borderBottomWidth: 1,
        borderRightColor: 'rgb(209,209,209)',
        borderBottomColor: 'rgb(209,209,209)',
    },
    borderRightRadius: {
        borderTopRightRadius: 7,
        borderBottomRightRadius: 7,
    },
    borderRightTopRadius: {
        borderTopRightRadius: 7,
    },
    borderRightBottomRadius: {
        borderBottomRightRadius: 7,
    },
    whiteText: {
        color: '#ffffff',
    },
    player1Heading: {
        justifyContent: 'center',
        backgroundColor: 'rgb(208,0,0)',
    },
    player1ScoreColumn: {
        flexDirection: 'column',
        width: '30%',
        backgroundColor: 'rgb(235,177,175)',
    },
    player2Heading: {
        justifyContent: 'center',
        backgroundColor: 'rgb(179,210,255)',
    },
    player2ScoreColumn: {
        flexDirection: 'column',
        width: '30%',
        backgroundColor: 'rgb(225,233,244)',
    },
    player3Heading: {
        justifyContent: 'center',
        backgroundColor: 'rgb(35,177,41)',
    },
    player3ScoreColumn: {
        flexDirection: 'column',
        width: '30%',
        backgroundColor: 'rgb(203,230,199)',
    },
    player4Heading: {
        justifyContent: 'center',
        backgroundColor: 'rgb(254,224,94)',
        borderTopRightRadius: 7,
    },
    player4ScoreColumn: {
        flexDirection: 'column',
        width: '30%',
        backgroundColor: 'rgb(255, 234, 140)',
        borderBottomRightRadius: 7,
    },
    playerNameContainer: {
        width: '70%',
        justifyContent: 'center',
        borderRightWidth: 1,
        borderRightColor: 'rgb(209,209,209)',
    },
    playerScoreHeading: {
        width: '30%',
        justifyContent: 'center',
    },
    slColumn: {
        width: '4%',
        flexDirection: 'column',
        backgroundColor: 'rgb(141,139,140)',
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
    },
    wordColumn: {
        flexDirection: 'column',
        width: '70%',
        borderRightWidth: 1,
        borderRightColor: 'rgb(209,209,209)',
    },
    slTableCell: {
        justifyContent: 'center',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: 'rgb(209,209,209)',
    },
    tableCell: {
        justifyContent: 'center',
        borderBottomWidth: 1,
        borderBottomColor: 'rgb(209,209,209)',
    },
    cellPadding: {
        padding: 5,
        height: 28,
    },
    cellAlignCenter: { alignItems: 'center' },
    slText: {
        color: '#ffffff',
    },
    scoreText: {
        textAlign: 'right',
    },
    fontBold: {
        fontWeight: 'bold',
    },
    borderBottomNone: {
        borderBottomWidth: 0,
    },
    notPLayingContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    notPlayingText: {
        color: 'rgb(200,200,200)',
        fontWeight: 'bold',
    },
    bestScore: {
        width: 5,
        //height: '100%',
        height: 16,
        marginRight: 5,
        backgroundColor: '#cccccc',
        justifyContent: 'flex-end',
    },
});

const mapStateToProps = (state) => ({ layout: state.layout, game: state.game });
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    MoveListModal
);
