import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import ResourcesPanel from './ResourcesPanel';
import LiveGameChat from './LiveGameChat';
import get from 'lodash/get';
import RestAPIProvider from '../provider/RestAPIProvider';
import S14Text from './S14Text';
import GameBoardUtils from '../utils/GameBoardUtils';
import { readAllChatMessages } from '../service/EmailGamePlayService';
import ServiceWrapper from '../utils/ServiceWrapper';
import store from '../store';

class NativeChatDictionary extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showDefinedWords: false,
        };
    }

    closeMenu = () => {
        if (this.props.type === 'chat') {
            readAllChatMessages();
            let gidArray = [store.getState().game.gid];
            ServiceWrapper.nativeGameListReadChat(gidArray);
        }
        this.props.closeMenuHandler();
        ServiceWrapper.nativeHideBannerAds();
    };

    getCrossCloseBtn = () => {
        return (
            <TouchableOpacity
                style={[styles.btnStyle, styles.padRightFour]}
                onPress={() => ServiceWrapper.nativeShowInterstitialAd(this.closeMenu())}
            >
                <FontAwesomeIcon icon={faTimes} size={20} colo={ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR} />
            </TouchableOpacity>
        );
    };

    getDialogHeader = (title) => {
        return (
            <View style={[styles.dialogheaderStyle, { marginTop: 8 }]}>
                <Text style={styles.headerText}>{title}</Text>
                {this.getCrossCloseBtn()}
            </View>
        );
    };

    getDefinedWordsView = () => {
        if (this.state.showDefinedWords) {
            let [word] = Object.keys(this.state.searchWordDefinition);
            let des = this.state.searchWordDefinition[word];
            return this.state.showDefinedWords ? (
                <View style={[styles.w100, styles.paddingEight]}>
                    <S14Text>
                        <S14Text style={[styles.fontBold]}>Definition{'\n\n'}</S14Text>
                        <S14Text style={[styles.fontBold]}>
                            {word}
                            {': '}
                        </S14Text>
                        {des.length > 0 ? des[0].description : 'Definition not available.'}
                        {'\n'}
                    </S14Text>
                </View>
            ) : null;
        }
    };

    getWordDefination = async (word) => {
        let definition = await RestAPIProvider.getDefinationByApi([word]);
        this.setState({
            showDefinedWords: true,
            searchWordDefinition: definition,
        });
    };

    renderAllPlayedWordDefination = () => {
        let AllWords = get(this.props, 'game.allRegularPlayedWords');
        return (
            <View style={styles.paddingEight}>
                <S14Text style={[styles.fontBold]}>Words played in this game{'\n'}</S14Text>
                <ScrollView vertical={true}>
                    {Object.keys(AllWords)
                        .reverse()
                        .map((word, index) =>
                            word.length > 0 ? (
                                <View style={[styles.w100]} key={index}>
                                    <S14Text>
                                        <S14Text style={[styles.fontBold]}>
                                            {word}
                                            {': '}
                                        </S14Text>
                                        {AllWords[word].length > 0
                                            ? AllWords[word][0].description
                                            : 'Definition not available.'}
                                        {'\n'}
                                    </S14Text>
                                </View>
                            ) : null
                        )}
                </ScrollView>
            </View>
        );
    };

    renderDictionaryView = () => (
        <View style={{ flex: 1 }}>
            <View style={styles.fullView}>
                {this.getDialogHeader('Dictionary')}
                <View style={[styles.dialogBodyStyle]}>
                    <ResourcesPanel getWordDefination={this.getWordDefination} />
                    {this.getDefinedWordsView()}
                    <View style={{ flex: 1 }}>{this.renderAllPlayedWordDefination()}</View>
                </View>
            </View>
        </View>
    );

    renderChatView = () => (
        <View style={{ flex: 1 }}>
            {this.getDialogHeader('Chat')}
            <View style={[styles.dialogBodyStyle]}>
                <LiveGameChat
                    width={
                        GameBoardUtils.isMenuAtTheBottom()
                            ? get(this.props, 'layout.boardDimen')
                            : get(this.props, 'layout.layoutSidePanelWidth')
                    }
                />
            </View>
        </View>
    );

    render = () => (this.props.type === 'chat' ? this.renderChatView() : this.renderDictionaryView());
}

const styles = StyleSheet.create({
    fullView: { width: '100%', height: '100%', padding: 8 },
    dialogheaderStyle: {
        height: 30,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 8,
    },
    dialogBodyStyle: {
        height: '80%',
        // flex: 1,
        paddingTop: 8,
        paddingHorizontal: 8,
    },
    headerText: {
        color: ColorConfig.DIALOG_MODAL_HEADING_TEXT_COLOR,
        fontSize: 18,
    },
    gameidText: {
        marginLeft: 8,
        fontWeight: 'bold',
    },
    btnStyle: {
        marginVertical: 4,
    },
    padRightFour: { paddingRight: 4 },
    paddingEight: { padding: 8 },
    w100: {
        width: '100%',
    },
    fontBold: { fontWeight: 'bold' },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: state.layout,
});

export default connect(mapStateToProps)(NativeChatDictionary);
