import Config from '../configs/Config';
import ConfigurationWrapper from './ConfigurationWrapper';
import DocumentWrapper from './DocumentWrapper';

export default class DimensionUtils {
    static getInitValues = () => {
        let isMobile = DimensionUtils.isMobile();
        let elem = DocumentWrapper.getContainer();
        let width = isMobile ? DocumentWrapper.getScreenWidth() : elem.offsetWidth;
        let boardWidthDimen = isMobile
            ? DocumentWrapper.getBodyWidth()
            : width * ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('boardWidthToContainerWidthRatio');
        return {
            boardWidthDimen,
            layoutBoardDimenWidth: boardWidthDimen,
            isMobile,
        };
    };

    static getWindowDimensions = ({ divDimensOnly = false } = {}) => {
        let isMobile = DimensionUtils.isMobile();
        let elem = DocumentWrapper.getContainer();
        let width = isMobile && !divDimensOnly ? DocumentWrapper.getScreenWidth() : elem.offsetWidth;
        let height = isMobile && !divDimensOnly ? DocumentWrapper.getScreenHeight() : elem.offsetHeight;
        return { width, height };
    };

    static getParentContainer = () => DocumentWrapper.getContainer();

    static getContainerPosition = () => {
        let elem = DocumentWrapper.getContainer();
        let rect = elem && elem.getBoundingClientRect();
        let scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        return rect
            ? { top: rect.top + scrollTop, left: rect.left + scrollLeft }
            : {
                  top: 0,
                  left: 0,
              };
    };

    static isMobile = (
        divWidth = (DocumentWrapper.hasContainerElement() && DocumentWrapper.getContainerOffsetWidth()) ||
            DocumentWrapper.getScreenWidth()
    ) =>
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isMobile') ||
        divWidth < Config.MIN_DESKTOP_CONSIDERABLE_WIDTH ||
        DocumentWrapper.getScreenWidth() < Config.MIN_DESKTOP_CONSIDERABLE_WIDTH;

    static isNative = () => false;
}
