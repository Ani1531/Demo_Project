import React from 'react';
import { StyleSheet } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import { getDictionaryDetails } from '../utils/GameBoardUtils';
import { connect } from 'react-redux';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import S14Text from './S14Text';
import S16Text from './S16Text';
import LayoutUtils from '../utils/LayoutUtils';

class TwoLetterWordsPassages extends React.Component {
    shouldComponentUpdate = (nextProps, nextState) => {
        return !isEqual(
            get(this.props, 'game.dic'),
            get(nextProps, 'game.dic')
        );
    };

    getPassage = () => {
        let dic = this.props.game.dic;
        let dictionary = getDictionaryDetails(dic);
        switch (dictionary.lang) {
            case 'uk_en':
                return this.getUkEnTwoLetterWordsPassage();
            case 'fr':
                return this.getFrenchTwoLetterWordsPassage();
            case 'it':
                return this.getItalianTwoLetterWordsPassage();
            default:
                return this.getUsEnTwoLetterWordsPassage();
        }
    };

    render = () => {
        return this.getPassage();
    };

    getUsEnTwoLetterWordsPassage = () => (
        <S14Text
            style={[
                styles.margin,
                styles.fill,
                styles.dictionaryPassageNormal,
                styles.containerBackgroundColor,
                LayoutUtils.getCursorDefaultStyle(),
            ]}
        >
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                A
            </S16Text>
            A AB AD AE AG AH AI AL AM AN AR AS AT AW AX AY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                B
            </S16Text>
            A BE BI BO BY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                D
            </S16Text>
            A DE DO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                E
            </S16Text>
            D EF EH EL EM EN ER ES ET EW EX{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                F
            </S16Text>
            A FE{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                G
            </S16Text>
            I GO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                H
            </S16Text>
            A HE HI HM HO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                I
            </S16Text>
            D IF IN IS IT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                J
            </S16Text>
            O{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                K
            </S16Text>
            A KI{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                L
            </S16Text>
            A LI LO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                M
            </S16Text>
            A ME MI MM MO MU MY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                N
            </S16Text>
            A NE NO NU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                O
            </S16Text>
            D OE OF OH OI OK OM ON OP OR OS OW OX OY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                P
            </S16Text>
            A PE PI PO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Q
            </S16Text>
            I{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                R
            </S16Text>
            E{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                S
            </S16Text>
            H SI SO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                T
            </S16Text>
            A TE TI TO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                U
            </S16Text>
            H UM UN UP US UT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                W
            </S16Text>
            E WO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                X
            </S16Text>
            I XU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Y
            </S16Text>
            A YE YO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Z
            </S16Text>
            A{' '}
        </S14Text>
    );

    getUkEnTwoLetterWordsPassage = () => (
        <S14Text
            style={[
                styles.margin,
                styles.fill,
                styles.dictionaryPassageNormal,
                styles.containerBackgroundColor,
                LayoutUtils.getCursorDefaultStyle(),
            ]}
        >
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                A
            </S16Text>
            A AB AD AE AG AH AI AL AM AN AR AS AT AW AX AY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                B
            </S16Text>
            A BE BI BO BY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                C
            </S16Text>
            H{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                D
            </S16Text>
            A DE DI DO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                E
            </S16Text>
            A ED EE EF EH EL EM EN ER ES ET EW EX{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                F
            </S16Text>
            A FE FY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                G
            </S16Text>
            I GO GU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                H
            </S16Text>
            A HE HI HM HO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                I
            </S16Text>
            D IF IN IO IS IT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                J
            </S16Text>
            A JO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                K
            </S16Text>
            A KI KO KY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                L
            </S16Text>
            A LI LO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                M
            </S16Text>
            A ME MI MM MO MU MY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                N
            </S16Text>
            A NE NO NU NY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                O
            </S16Text>
            B OD OE OF OH OI OK OM ON OO OP OR OS OU OW OX OY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                P
            </S16Text>
            A PE PI PO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Q
            </S16Text>
            I{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                R
            </S16Text>
            E{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                S
            </S16Text>
            H SI SO ST{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                T
            </S16Text>
            A TE TI TO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                U
            </S16Text>
            G UH UM UN UP UR US UT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                W
            </S16Text>
            E WO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                X
            </S16Text>
            I XU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Y
            </S16Text>
            A YE YO YU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Z
            </S16Text>
            A ZE ZO{' '}
        </S14Text>
    );

    getFrenchTwoLetterWordsPassage = () => (
        <S14Text
            style={[
                styles.margin,
                styles.fill,
                styles.dictionaryPassageNormal,
                styles.containerBackgroundColor,
                LayoutUtils.getCursorDefaultStyle(),
            ]}
        >
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                A
            </S16Text>
            A AH AI AN AS AU AY{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                B
            </S16Text>
            A BE BI BU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                C
            </S16Text>
            A CE CI{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                D
            </S16Text>
            A DE DO DU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                E
            </S16Text>
            H EN ES ET EU EX{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                F
            </S16Text>
            A FI{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                G
            </S16Text>
            O{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                H
            </S16Text>
            A HE HI HO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                I
            </S16Text>
            F IL IN{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                J
            </S16Text>
            E{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                K
            </S16Text>
            A{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                L
            </S16Text>
            A LE LI LU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                M
            </S16Text>
            A ME MI MU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                N
            </S16Text>
            A NE NI NO NU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                O
            </S16Text>
            C OH ON OR OS OU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                P
            </S16Text>
            I PU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                R
            </S16Text>
            A RE RI RU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                S
            </S16Text>
            A SE SI SU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                T
            </S16Text>
            A TE TU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                U
            </S16Text>
            N US UT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                V
            </S16Text>
            A VE VS VU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                W
            </S16Text>
            U{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                X
            </S16Text>
            I{' '}
        </S14Text>
    );

    getItalianTwoLetterWordsPassage = () => (
        <S14Text
            style={[
                styles.margin,
                styles.fill,
                styles.dictionaryPassageNormal,
                styles.containerBackgroundColor,
                LayoutUtils.getCursorDefaultStyle(),
            ]}
        >
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                A
            </S16Text>
            D AH AI AL AM AT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                A
            </S16Text>
            A BE BI BO BU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                C
            </S16Text>
            A CD CE CI CO CU CX{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                D
            </S16Text>
            A DE DI DO DU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                E
            </S16Text>
            A ED EE EH EI EL EN EO ES ET EX{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                F
            </S16Text>
            A FE FI FM FO FU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                G
            </S16Text>
            E GI GO <S16Text style={styles.dictionaryPassageFirst}>H</S16Text>A
            HE HI HM HO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                I
            </S16Text>
            D IH IL IN IO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                K
            </S16Text>
            O{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                L
            </S16Text>
            A LE LI LO LP{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                M
            </S16Text>
            A ME MI MM MO MU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                N
            </S16Text>
            E NI NO NU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                O
            </S16Text>
            C OD OE OH OI OK ON OR{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                P
            </S16Text>
            A PC PE PH PI PO PS PU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Q
            </S16Text>
            U{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                R
            </S16Text>
            E RH RO{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                S
            </S16Text>
            A SE SI SO SS ST SU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                T
            </S16Text>
            A TE TI TO TU TV{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                U
            </S16Text>
            A UE UF UH UN UP UT{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                V
            </S16Text>
            A VE VI VO VU{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                W
            </S16Text>
            C{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                X
            </S16Text>
            I{' '}
            <S16Text
                style={[
                    styles.dictionaryPassageFirst,
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                Z
            </S16Text>
            A ZI{' '}
        </S14Text>
    );
}

const styles = StyleSheet.create({
    margin: { margin: 8 },
    fill: { flex: 1, backgroundColor: 'red' },
    containerBackgroundColor: {
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    dictionaryPassageNormal: {
        color: '#000000',
        fontWeight: 'bold',
    },

    dictionaryPassageFirst: {
        color: '#c23742',
        fontWeight: 'bold',
    },

    twoLetterWordsPassageHeader: {
        alignSelf: 'center',
        fontWeight: 'bold',
        color: ColorConfig.SIDE_PANEL_HEADING_TEXT_COLOR,
    },
});

const mapStateToProps = (state) => ({ game: state.game });

export default connect(mapStateToProps)(TwoLetterWordsPassages);
