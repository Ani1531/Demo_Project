import React from 'react';
import { StyleSheet, TouchableOpacity, View, Pressable } from 'react-native';
import Config from '../configs/Config';
import RackTile from '../component/RackTile';
import ColorConfig from '../configs/ColorConfig';
import DimensionUtils from '../utils/DimensionUtils';
import LayoutUtils from '../utils/LayoutUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { connect } from 'react-redux';
import get from 'lodash/get';
import S14Text from '../component/S14Text';
import LayoutWrapper from '../utils/LayoutWrapper';
function onRackTilePress() {
    this.onLetterSelected(this.alphabet);
}

class LetterSelectorModal extends React.Component {
    state = {
        isOpen: false,
        onDialogDismissed: undefined,
        onLetterSelected: undefined,
        alphabets: Config.ALPHABET_PICKER_ARRANGEMENT,
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
    };

    show = (onDialogDismissed, onLetterSelected) => {
        this.setState({ isOpen: true, onDialogDismissed, onLetterSelected });
    };

    isVisible = () => this.state.isOpen;

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onClose();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: DimensionUtils.isMobile() ? '50%' : '29%',
        //maxHeight: '90%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    getCloseButtonSTyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    render = () =>
        this.state.isOpen ? (
            <View style={this.getModalContentStyle()}>
                <View
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                    ]}
                >
                    <TouchableOpacity
                        style={[
                            DimensionUtils.isMobile()
                                ? styles.closeButtonContainerMobile
                                : styles.closeButtonContainer,
                        ]}
                        onPress={this.onCloseButtonClick}
                        onMouseEnter={this.onCloseButtonMouseEnter}
                        onMouseLeave={this.onCloseButtonMouseLeave}
                    >
                        <View
                            style={[
                                { backgroundColor: this.state.closeBGColor },
                                LayoutUtils.getDialogCloseButtonBGStyle(),
                            ]}
                        >
                            <FontAwesomeIcon
                                icon={faTimes}
                                size={DimensionUtils.isMobile() ? 20 : 24}
                                style={this.getCloseButtonSTyle()}
                            />
                        </View>
                    </TouchableOpacity>

                    <View style={LayoutUtils.getDialogBodyContainerStyle()}>
                        {this.state.alphabets.map((row, index) => (
                            <View
                                key={'row_' + index}
                                style={[
                                    styles.rowArrangementAlphabet,
                                    this.getTileRackMargin(),
                                ]}
                            >
                                {row.map((alphabet) => {
                                    let tile = { letter: alphabet };
                                    return (
                                        <RackTile
                                            key={alphabet}
                                            tile={tile}
                                            showTileScore={false}
                                            clickSound={true}
                                            onPress={onRackTilePress.bind({
                                                alphabet,
                                                onLetterSelected:
                                                    this.onLetterSelected,
                                            })}
                                            containerHeight={get(
                                                this.props,
                                                'layout.layoutGamePlayAreaHeight'
                                            )}
                                        />
                                    );
                                })}
                            </View>
                        ))}
                    </View>

                    <View
                        style={[
                            LayoutUtils.getDialogBodyBtnContainerStyle(),
                            DimensionUtils.isMobile()
                                ? styles.buttonContainerMobileOverride
                                : undefined,
                        ]}
                    >
                        <Pressable
                            style={[
                                LayoutUtils.getDialogActionButtonStyle(),
                                LayoutUtils.getBottonStyle(),
                            ]}
                            onPress={this.onClose}
                        >
                            <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                {'CANCEL'}
                            </S14Text>
                        </Pressable>
                    </View>
                </View>
            </View>
        ) : null;

    getTileRackMargin = () => ({
        marginBottom: this.props.layout.layoutTileRackMargin,
    });
    onLetterSelected = (alphabet) => {
        this.state.onLetterSelected(alphabet);
        this.setState({
            isOpen: false,
            onDialogDimissed: undefined,
            onLetterSelected: undefined,
        });
    };

    onClose = () => {
        if (this.state.onDialogDismissed) this.state.onDialogDismissed();
        this.setState({
            isOpen: false,
            onDialogDismissed: undefined,
            onLetterSelected: undefined,
        });
    };
}

const styles = StyleSheet.create({
    letter: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },

    rowArrangementAlphabet: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },

    columnArrangementAlphabet: {
        flexDirection: 'column',
    },

    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
        paddingHorizontal: 32,
        paddingTop: 32,
        paddingBottom: 16,
    },
    closeButtonContainerMobile: {
        flex: 1,
        alignItems: 'flex-end',
        paddingHorizontal: 16,
        paddingTop: 16,
        paddingBottom: 8,
    },
});
const mapStateToProps = (state) => ({
    layout: state.layout,
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    LetterSelectorModal
);
