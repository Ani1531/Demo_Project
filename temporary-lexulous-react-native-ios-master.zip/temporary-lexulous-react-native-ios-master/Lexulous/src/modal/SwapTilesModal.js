import React from 'react';
import { StyleSheet, TouchableOpacity, View, Pressable } from 'react-native';
import { sendSwapTilesRequest } from '../service/GamePlayService';
import { to } from 'await-to-js';
import LayoutUtils from '../utils/LayoutUtils';
import DimensionUtils from '../utils/DimensionUtils';
import ColorConfig from '../configs/ColorConfig';
import RackTile from '../component/RackTile';
import Config from '../configs/Config';
import SoundUtils from '../utils/SoundUtils';
import { createDialogInstance, getCustomMessage } from '../utils/MessageUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { connect } from 'react-redux';
import get from 'lodash/get';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import S22Text from '../component/S22Text';
import S14Text from '../component/S14Text';
import FontAwesomeSpin from '../component/FontAwesomeSpin';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

function onTilePressed() {
    this.selected
        ? this.onSelectedTilePressed(this.tile)
        : this.onUnselectedTilePressed(this.tile);
}

class SwapTilesModal extends React.Component {
    state = {
        isOpen: false,
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        showLoader: false,
    };

    componentDidMount = () => {
        eventBus.on(Config.SWAP_TILES_REQUEST_FAILED, this.onSwapFail);
        eventBus.on(
            Config.SWAP_TILES_EMAIL_GAME_REQUEST_FAILED,
            this.onSwapFail
        );
        eventBus.on(Config.GAME_HAS_ENDED, this.hide);
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.SWAP_TILES_REQUEST_FAILED, this.onSwapFail);
        eventBus.detach(
            Config.SWAP_TILES_EMAIL_GAME_REQUEST_FAILED,
            this.onSwapFail
        );
        eventBus.detach(Config.GAME_HAS_ENDED, this.hide);
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.hide();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: DimensionUtils.isMobile ? '90%' : '44%',
        //maxHeight: '90%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    getSwapRackDimension = () => ({
        height: this.props.layout.layoutCellDimen,
        width: '100%',
        /* (this.props.layout.layoutCellDimen +
                this.props.layout.layoutCellDimen / 10) *
            ConfigurationWrapper.getSpecificLexulousGameConfiguration(
                'rack_size'
            ) */
    });

    render = () =>
        this.state.isOpen ? (
            <View style={this.getModalContentStyle()}>
                <View
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                    ]}
                >
                    <View style={LayoutUtils.getDialogTitleContainerStyle()}>
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                            {'Exchange Tiles'}
                        </S22Text>
                        <TouchableOpacity
                            style={styles.closeButtonContainer}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <View
                                style={[
                                    {
                                        backgroundColor:
                                            this.state.closeBGColor,
                                    },
                                    LayoutUtils.getDialogCloseButtonBGStyle(),
                                ]}
                            >
                                <FontAwesomeIcon
                                    icon={faTimes}
                                    size={DimensionUtils.isMobile() ? 20 : 24}
                                    style={this.getCloseButtonStyle()}
                                />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={LayoutUtils.getDialogBodyContainerStyle()}>
                        {this.renderUnselectedTiles()}
                        {this.renderSelectedTiles()}
                    </View>

                    <View
                        style={[
                            LayoutUtils.getDialogBodyBtnContainerStyle(),
                            DimensionUtils.isMobile()
                                ? [
                                      styles.buttonContainerMobileOverride,
                                      { paddingTop: 0 },
                                  ]
                                : undefined,
                        ]}
                    >
                        <Pressable
                            style={[
                                LayoutUtils.getDialogSecondActionButtonStyle(),
                                LayoutUtils.getBottonStyle(),
                            ]}
                            onPress={this.onSelectAll}
                        >
                            <S14Text
                                style={LayoutUtils.getBottonTextBlueStyle()}
                            >
                                {'EXCHANGE ALL'}
                            </S14Text>
                        </Pressable>
                        <Pressable
                            style={[
                                LayoutUtils.getDialogActionButtonStyle(),
                                LayoutUtils.getBottonStyle(),
                            ]}
                            onPress={this.onSendLetters}
                        >
                            <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                {'OK'}
                            </S14Text>
                        </Pressable>
                    </View>
                    {this.state.showLoader ? (
                        <View
                            style={[
                                StyleSheet.absoluteFill,
                                styles.loaderContainer,
                            ]}
                        >
                            <FontAwesomeSpin />
                        </View>
                    ) : null}
                </View>
            </View>
        ) : null;

    setOnSwapSuccess = (onSwapSuccess) => {
        this.setState({ onSwapSuccess });
    };

    onSendLetters = async () => {
        //If Tiles Selected
        if (this.state.selectedTiles && this.state.selectedTiles.length > 0) {
            this.setState({ showLoader: true });
            let res = await to(sendSwapTilesRequest(this.state.selectedTiles));
            if (res[1]) {
                this.state.selectedTiles.forEach(
                    (tile) => (tile.forRevealSolution = false)
                );
                if (this.state.onSwapSuccess) this.state.onSwapSuccess(res[1]);
                SoundUtils.userSubmits();
            }
            this.hide();
        }
        //If No Tiles Selected
        else {
            this.onNoTilesSelected();
        }
    };

    onSwapFail = (data) => {
        createDialogInstance({
            title: Config.DIALOG_HEADER_TEXT,
            body: getCustomMessage(data),
            cancelButtonText: 'OK',
        });
    };

    onNoTilesSelected = () => {
        createDialogInstance({
            title: 'Swap Tiles',
            body: 'Please select the tiles you wish to swap.',
            cancelButtonText: 'OK',
        });
    };

    hide = () => this.setState({ isOpen: false });

    onClose = () => {
        this.setState({ isOpen: false });
    };

    show = (tiles) => {
        this.setState({ showLoader: false });
        let unselectedTiles = [];
        let selectedTiles = [];
        (tiles || []).forEach((tile) => {
            if (tile.position) selectedTiles.push(tile);
            else unselectedTiles.push(tile);
        });
        this.setState({ isOpen: true, unselectedTiles, selectedTiles });
    };

    renderUnselectedTiles = () => (
        <View style={[styles.margin]}>
            <S14Text
                style={[
                    styles.marginBottom,
                    LayoutUtils.getDialogBodyTextStyle(),
                ]}
            >
                {'Select tiles to be exchanged:'}
            </S14Text>
            {this.renderTiles({
                tiles: this.state.unselectedTiles,
                selected: false,
            })}
        </View>
    );

    renderSelectedTiles = () => (
        <View style={[styles.margin]}>
            <S14Text
                style={[
                    styles.marginBottom,
                    LayoutUtils.getDialogBodyTextStyle(),
                ]}
            >
                {'The following tiles will be exchanged:'}
            </S14Text>
            {this.renderTiles({
                tiles: this.state.selectedTiles,
                selected: true,
            })}
        </View>
    );

    renderTiles = ({ tiles = [], selected } = {}) => (
        <View style={[styles.rowDirection, this.getSwapRackDimension()]}>
            {tiles.map((tile) => (
                <RackTile
                    tile={tile}
                    showTileScore={true}
                    clickSound={true}
                    onPress={onTilePressed.bind({
                        selected: selected,
                        tile: tile,
                        onSelectedTilePressed: this.onSelectedTilePressed,
                        onUnselectedTilePressed: this.onUnselectedTilePressed,
                    })}
                    containerHeight={get(
                        this.props,
                        'layout.layoutGamePlayAreaHeight'
                    )}
                />
            ))}
        </View>
    );

    onSelectedTilePressed = (tile) => {
        let { selectedTiles = [], unselectedTiles = [] } = this.state || {};
        selectedTiles = selectedTiles.filter(
            (tileInArr) => !(get(tileInArr, 'id') === get(tile, 'id'))
        );
        unselectedTiles.push(tile);
        this.setState({ selectedTiles, unselectedTiles });
    };

    onUnselectedTilePressed = (tile) => {
        let { selectedTiles = [], unselectedTiles = [] } = this.state || {};
        unselectedTiles = unselectedTiles.filter(
            (tileInArr) => !(get(tileInArr, 'id') === get(tile, 'id'))
        );
        selectedTiles.push(tile);
        this.setState({ selectedTiles, unselectedTiles });
    };

    onSelectAll = () => {
        let { selectedTiles = [], unselectedTiles = [] } = this.state || {};
        unselectedTiles.forEach((tileInArr) => {
            selectedTiles.push(tileInArr);
        });
        unselectedTiles = [];
        this.setState({ selectedTiles, unselectedTiles });
    };
}

const styles = StyleSheet.create({
    rowDirection: {
        flexDirection: 'row',
    },
    margin: {
        margin: 5,
    },
    marginBottom: {
        marginBottom: 5,
    },
    alignContentCenterJustified: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    placed_cell: {
        backgroundColor: ColorConfig.RACK_TILE_BACKGROUND_COLOR,
        borderColor: ColorConfig.RACK_TILE_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        alignItems: 'center',
        justifyContent: 'center',
    },
    locked_text: {
        color: ColorConfig.LOCKED_TEXT_COLOR,
    },
    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    alignSelfStart: {
        alignSelf: 'flex-start',
    },
    flexOne: {
        flex: 1,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
    loaderContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        width: '100%',
        borderRadius: 4,
        backgroundColor: ColorConfig.MAIN_CONTAINER_BACKGROUND_COLOR,
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    SwapTilesModal
);
