// @flow

import * as React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { StyleSheet, Text, View, Pressable, ScrollView, Image, Platform, Linking, AppState } from 'react-native';
import * as CONSTANTS from '../commons/Constants';
import type {
    ProfileViewProps,
    ProfileInfo,
    ProfileAssociations,
    userSettings,
    ServerResponse,
    sectionType,
    SectionElementContent,
    AlertBoxType,
} from '../commons/RJTypes';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';

import {
    actionSetProfile,
    actionUpdateProfile,
    actionUpdateAppleLgnInfo,
    actionUpdateLXLSLgnInfo,
    actionUpdateUserSettings,
} from '../userprofile/PFLAction';
import requestManager from '../commons/RequestManager';
import dataServer from '../store/Store';
import fbLgnMgr from '../commons/FBLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import applLgnMgr from '../commons/ApplLgnMgr';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import FndElementView from '../friends/FndElementView';

import loginCoordinator from '../commons/LoginCoordinator';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faPlus, faMinus, faSignOutAlt, faGameBoard } from '@fortawesome/pro-light-svg-icons';
import { faFacebookSquare, faGoogle, faApple } from '@fortawesome/free-brands-svg-icons';
import UserNameContainer from '../components/UserNameContainer';
import netManager from '../commons/RJNetInfo';
import LoadingIndicator from '../components/LoadingIndicator';
import Accordion from 'react-native-collapsible/Accordion';
import fndApi from '../friends/FndApi';
import BooleanToggleContainer from './BooleanToggleContainer';
import SelectContainer from './SelectContainer';
import SliderContainer from './SliderContainer';
import { updatePopupVisibility, clearPopups, showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import ProfileBarContainer from '../components/ProfileBarContainer';
import ButtonContainer from './ButtonContainer';
import inAppPurchases from '../commons/iap/InAppPurchases';
import { translate } from '../commons/translations/LangTransator';
import userDefault from '../commons/UserDefault';
import DetailsContainer from '../components/DetailsContainer';
import type { AxiosPromise, AxiosResponse } from 'axios';
import pushNtfMgr from '../commons/PushNtfMgr';
import trslateConstants from '../commons/translations/TrslateConstants';
import soundManager from '../commons/SoundManager';
import bannerAd from '../commons/ads/BannerAd';
import { handleException } from '../commons/RJUtils';
import appConfiguration from '../commons/AppConfiguration';
import rjAnalytics from '../../../../RJAnalytics';
import WordValidityWebSocketProvider from '../../../../provider/WordValidityWebSocketProvider';
import SlidingWindowContainer from './SlidingWindowContainer';
import themeConfigutation from '../commons/ThemeConfiguration';

type PFLVwContainerState = {
    userName: string,
    avatarNo: string,
    detailTypeKey: string,
    activeSections: Array<any>,
    isFocused: boolean,
    testNotificationTapped: boolean,
    hasPushNtfPermission: boolean,
    currentAdsFreeSubscriptions: Array<string>,
    bannerHt: number,
};

class PFLVwContainer extends React.Component<ProfileViewProps, PFLVwContainerState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    appSource: string = '';

    constructor(props: ProfileViewProps) {
        super(props);
        this.state = {
            userName: this.props.profile.name ?? CONSTANTS.Default_name,
            avatarNo: this.props.profile.avtar ?? CONSTANTS.Default_Avtar,
            activeSections: [],
            detailTypeKey: '',
            isFocused: false,
            testNotificationTapped: false,
            hasPushNtfPermission: false,
            currentAdsFreeSubscriptions: [],
            bannerHt: 0,
        };
        this.setIsFbInstant();
    }

    setIsFbInstant = () => {
        let source: string | null = appConfiguration.getApplicationSource();
        if (source != null) {
            this.appSource = source;
        }
    };

    componentDidMount() {
        this.doUpdatePushNotificationPermission();
        AppState.addEventListener('change', this.handleAppStateChange);
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (loginCoordinator.lgnMgr) {
                let performchecks = loginCoordinator.lgnMgr === lxlsLgnMgr;
                if (performchecks) {
                    loginCoordinator.onLXLSDotComLogin(null);
                }
            }
            if (
                this.props.lastupdated == null ||
                this.props.lastupdated == undefined ||
                this.props.lastupdated + CONSTANTS.kFriendCacheDurationSeconds < Math.floor(Date.now() / 1000)
            ) {
                if (netManager.isConnected()) {
                    fndApi.getFriendListCumulative(false);
                }
            }
            if (this.state.isFocused == false) {
                bannerAd.showBannerAd(CONSTANTS.kTabBarHeight, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });
            }
            this.setState({ testNotificationTapped: false });
            this.updateSubscriptionStatus();
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ activeSections: [] }); //for closing opened section
                this.setState({ isFocused: false });
            }
        });
    }

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        AppState.removeEventListener('change', this.handleAppStateChange);
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    handleAppStateChange = (nextAppState): void => {
        if (nextAppState === 'active') {
            this.doUpdatePushNotificationPermission();
        }
    };

    doUpdatePushNotificationPermission = (): void => {
        pushNtfMgr.notificationChecking().then((haspermission: boolean) => {
            if (this.state.hasPushNtfPermission != haspermission) {
                if (haspermission == true) {
                    pushNtfMgr.mountPushNotification((registered) => {
                        this.setState({ hasPushNtfPermission: haspermission });
                        this.setState({ testNotificationTapped: !registered });
                        pushNtfMgr.doUpdateDevicePin(false);
                    });
                } else {
                    this.setState({ hasPushNtfPermission: haspermission });
                    this.setState({ testNotificationTapped: false });
                }
            }
        });
    };

    doFbLogin = (onCompletionCallback: ?() => void) => {
        let callback = () => {
            loginCoordinator.onFBLogin(onCompletionCallback);
        };
        fbLgnMgr.doFbLogin(callback);
    };

    doLXLSDotComLogin = () => {
        rjAnalytics.sendAnalyticsEvent('email_input_opened', 'pfl_vw_container');
        this.props.navigation.navigate('UserNameOREmail', {
            lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail,
        });
    };

    doGoogleLogin = () => {
        let callback = () => {
            loginCoordinator.onGoogleLogin(null);
        };
        gglLgnMgr.doGoogleLogin(callback);
    };

    doAppleLogin = async () => {
        if (CONSTANTS.isAppleLoginSupported()) {
            applLgnMgr.signInWithApple(loginCoordinator.onAppleLogin, null);
        }
    };

    doSetProfile = () => {
        let avt = { [CONSTANTS.kAvtar]: '25' };
        this.props.actionSetProfile(avt);
    };

    userNameBeginEditing = () => {
        this.props.updatePopupVisibility({ showUserNamePopup: true });
    };

    userNameDidCancledEditing = () => {
        this.props.clearPopups();
    };

    userNameDidFinishedEditing = (name: string) => {
        this.props.clearPopups();
        this.setState({ userName: name });
        if (this.props.profile.name !== undefined && this.props.profile.name !== null && this.props.profile.name !== name) {
            this.updateUserinfo(name, null);
        }
    };

    userAvatarDidFinishedEditing = (recentSelectedAvtar: string) => {
        this.setState({ avatarNo: recentSelectedAvtar });
        if (
            this.props.profile.avtar !== undefined &&
            this.props.profile.avtar !== null &&
            this.props.profile.avtar !== recentSelectedAvtar
        ) {
            this.updateUserinfo(null, recentSelectedAvtar);
        }
    };

    getAccountVisibilityStatus = (): { [string]: string } => {
        let loggedinanyone: boolean =
            this.props.profileVw.gglLoginInfo != null ||
            this.props.profileVw.lxlsLoginInfo != null ||
            this.props.profileVw.appleLoginInfo != null ||
            this.props.profileVw.fbLoginInfo != null;
        let lxlsvisible = this.props.profileVw.gglLoginInfo == null && this.props.profileVw.appleLoginInfo == null;
        let visibleflgs = null;
        if (loggedinanyone) {
            visibleflgs = {
                ac_facebook: this.props.profileVw.fbLoginInfo ? 'y' : 'n',
                ac_google: this.props.profileVw.gglLoginInfo ? 'y' : 'n',
                ac_lexulous: lxlsvisible && this.props.profileVw.lxlsLoginInfo ? 'y' : 'n',
                ac_apple: CONSTANTS.isAppleLoginSupported() && this.props.profileVw.appleLoginInfo ? 'y' : 'n',
                ac_logout: 'y',
            };
        } else {
            visibleflgs = {
                ac_facebook: 'y',
                ac_google: 'y',
                ac_lexulous: 'y',
                ac_apple: CONSTANTS.isAppleLoginSupported() ? 'y' : 'n',
                ac_logout: 'n',
            };
        }
        return visibleflgs;
    };

    getAccountVisibilityStatusText = (): { [string]: string } => {
        let loggedinanyone: boolean =
            this.props.profileVw.gglLoginInfo != null ||
            this.props.profileVw.lxlsLoginInfo != null ||
            this.props.profileVw.appleLoginInfo != null ||
            this.props.profileVw.fbLoginInfo != null;
        let lxlsvisible = this.props.profileVw.gglLoginInfo == null && this.props.profileVw.appleLoginInfo == null;
        let visibletxtvals = null;
        let txtlink = translate('link');
        let txtdetails = translate('details');
        if (loggedinanyone) {
            visibletxtvals = {
                ac_facebook: this.props.profileVw.fbLoginInfo ? txtdetails : '',
                ac_google: this.props.profileVw.gglLoginInfo ? txtdetails : '',
                ac_lexulous: lxlsvisible && this.props.profileVw.lxlsLoginInfo ? txtdetails : '',
                ac_apple: CONSTANTS.isAppleLoginSupported() && this.props.profileVw.appleLoginInfo ? txtdetails : '',
                ac_logout: translate('signout'),
            };
        } else {
            visibletxtvals = {
                ac_facebook: txtlink,
                ac_google: txtlink,
                ac_lexulous: txtlink,
                ac_apple: CONSTANTS.isAppleLoginSupported() ? txtlink : '',
                ac_logout: '',
            };
        }
        return visibletxtvals;
    };

    updateUserinfo = (name: ?string, avtid: ?string) => {
        let uName = name ?? this.props.profile.name;
        let uAvtar = avtid ?? this.props.profile.avtar;
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateProfile(uName, uAvtar);
            rsp.then((response) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    let usrpfl: ProfileInfo = { name: uName, avtar: uAvtar };
                    dataServer.getStore().dispatch(actionUpdateProfile(usrpfl));
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    receiveTestPushNtf = async () => {
        if (this.state.hasPushNtfPermission) {
            let pinValue = await userDefault.get(CONSTANTS.kPsistDevicePin);
            let currentDevicePin = pinValue ?? '';

            if (currentDevicePin) {
                let rq: AxiosPromise<ServerResponse> = requestManager.updateDevicePin(currentDevicePin, 'y');
                rq.then((response: AxiosResponse<ServerResponse, any>) => {
                    this.setState({ testNotificationTapped: true });
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then(async (srvresp: ServerResponse) => {
                        if (srvresp.check === CONSTANTS.kSuccess) {
                            console.log('receiveTestPushNtf srvresp', JSON.stringify(srvresp));
                        } else {
                            console.log('updateDevicePin error', srvresp);
                        }
                    })
                    .catch((error) => {
                        handleException(error);
                    })
                    .finally(() => {});
            }
        } else {
            Linking.openSettings();
        }
    };

    renderUserNameContainer = () => {
        if (this.props.popups.showUserNamePopup) {
            return (
                <UserNameContainer
                    editingCancledHandler={() => {
                        this.userNameDidCancledEditing();
                        rjAnalytics.sendAnalyticsEvent('username_editing_closed', 'pfl_vw_container');
                    }}
                    editingFinishedHandler={(name: string) => {
                        this.userNameDidFinishedEditing(name);
                        rjAnalytics.sendAnalyticsEvent('username_editing_save_closed', 'pfl_vw_container');
                    }}
                    btnTxt={translate('save')}
                    btnAutoEnable={false}
                    avoidKeyboard={false}
                    userName={this.state.userName}
                />
            );
        } else {
            return null;
        }
    };

    separator = () => {
        return <View style={styles.seperatorStyle} />;
    };

    filterSections = (sectionKey) => {
        let hideSectionForWeb = () => {
            if (this.appSource == CONSTANTS.kFBInstantApp) {
                return sectionKey != 'us_pushntf' && sectionKey != 'us_email';
            }
            return sectionKey != 'us_pushntf';
        };
        return Platform.select({
            native: sectionKey != null && sectionKey != undefined,
            web: hideSectionForWeb(),
        });
    };

    getApplicableSetting = () => {
        let applicablesettings = null;
        let appliedfilters = () => {
            if (applicablesettings != null) {
                return applicablesettings;
            } else {
                applicablesettings = CONSTANTS.settingsDescriptor.filter((section) => this.filterSections(section.key));
                return applicablesettings;
            }
        };
        return appliedfilters;
    };

    settingDescription = this.getApplicableSetting();

    renderSettingslist = () => {
        let accountVisibilityflgs = this.getAccountVisibilityStatus();
        let sections = this.settingDescription().map((section) => {
            section.content.map((section_element) => {
                if (section_element.key === 'gp_boardtheme' || section_element.key === 'gp_tiletheme') {
                    if (this.props.profileSettings[section.key]['gp_gametheme']) {
                        let theme_val = this.props.profileSettings[section.key]['gp_gametheme'].split('-');
                        if (section_element.def_value && section_element.key === 'gp_boardtheme') {
                            section_element.def_value = theme_val[0];
                        }
                        if (section_element.def_value && section_element.key === 'gp_tiletheme') {
                            section_element.def_value = theme_val[1];
                        }
                    }
                } else if (section.key == 'us_account') {
                    section_element.def_value = accountVisibilityflgs[section_element.key];
                    section_element.editable = section_element.def_value == 'y' ? 'true' : 'false';
                } else if (section.key == 'us_prouser' && section_element.key == 'ad_free') {
                    if (this.appSource == CONSTANTS.kFBInstantApp || this.appSource == CONSTANTS.kDeskTopApp) {
                        section_element.editable = 'false';
                    }
                } else {
                    if (this.props.profileSettings[section.key][section_element.key]) {
                        if (section_element.def_value) {
                            section_element.def_value = this.props.profileSettings[section.key][section_element.key];
                        }
                    }
                }
            });

            this.checkAnalyzActiveUntiill(section);
            return section;
        });

        return (
            <Accordion
                sections={sections}
                activeSections={this.state.activeSections}
                renderHeader={this.renderHeader}
                renderContent={this.renderContent}
                onChange={this.updateSections}
                containerStyle={styles.drillDown_container}
                renderChildrenCollapsed={false}
                duration={200}
            />
        );
    };

    renderHeader = (section: { title: string }, index: number, isActive: boolean) => {
        let setting_len = this.settingDescription().length;
        return (
            <View>
                {index === 0 ? this.separator() : null}
                <View style={[styles.drillDown_header, { backgroundColor: themeConfigutation.getColor('#e5e7e9') }]}>
                    <Text style={[styles.drillDown_headerText, { color: themeConfigutation.getColor('#000') }]}>
                        {translate(section.title)}
                    </Text>
                    {isActive ? (
                        <FontAwesomeIcon
                            icon={faMinus}
                            size={22}
                            style={{ padding: 8, color: themeConfigutation.getColor('#000') }}
                        />
                    ) : (
                        <FontAwesomeIcon
                            icon={faPlus}
                            size={22}
                            style={{ padding: 8, color: themeConfigutation.getColor('#000') }}
                        />
                    )}
                </View>
                {setting_len !== index ? this.separator() : null}
            </View>
        );
    };

    checkAnalyzActiveUntiill = (section) => {
        section.content.map((item) => {
            if (item.key === 'anlz_till') {
                let valDate = Number(item.def_value) * 1000;
                let recentDate = Date.now();
                if (valDate >= recentDate) {
                    section.content.map((item2) => {
                        if (item2.key === 'pro_analizegamesleft') {
                            item2.editable = 'false';
                        }
                    });
                }
            }
        });
    };

    renderContent = (section: sectionType, index: number) => {
        return <View style={styles.drillDown_content}>{this.renderCesorOrOtherList(section)}</View>;
    };

    renderCesorOrOtherList = (section) => {
        if (section.key === 'us_censor') {
            return this.getCensorList();
        } else if (section.key === 'us_account') {
            return this.renderMyAccoutElement(section);
        } else if (section.key === 'us_pushntf') {
            return this.renderTestNtfView(section);
        } else {
            return section.content.map((element) => {
                return (
                    <View style={styles.fullWidth} key={element.key}>
                        {this.renderSectionElements(element)}
                    </View>
                );
            });
        }
    };

    renderTestNtfView = (section) => {
        let lstEnabled = section.content
            .map((item) => {
                if (item.editable === 'true') {
                    if (item.key !== 'get_test_ntf') {
                        return item.def_value;
                    }
                }
            })
            .filter((i) => i != null && i != undefined);

        let showTestNotification = lstEnabled.includes('y');

        return section.content.map((element) => {
            if (element.key === 'get_test_ntf') {
                if (showTestNotification) {
                    return (
                        <View style={styles.fullWidth} key={element.key}>
                            {this.renderSectionElements(element)}
                        </View>
                    );
                }
            } else {
                return (
                    <View style={styles.fullWidth} key={element.key}>
                        {this.renderSectionElements(element)}
                    </View>
                );
            }
        });
    };

    renderSectionElements = (item) => {
        return item.editable === 'true' ? (
            <View style={styles.fullWidth}>
                <View style={[styles.drillDown_contentRowstyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Text style={[styles.contentheaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate(item.lbl)}
                    </Text>
                    {this.renderSettingsType(item)}
                </View>
                {this.separator()}
            </View>
        ) : null;
    };

    renderAccountElementContent = (element: SectionElementContent) => {
        let renderself = (element: SectionElementContent) => {
            return (
                <View style={styles.fullWidth} key={element.key}>
                    <View style={styles.fullWidth}>
                        <View
                            style={[
                                styles.drillDown_contentRowstyle,
                                { justifyContent: 'flex-start', backgroundColor: themeConfigutation.getColor('#f4f3ef') },
                            ]}
                        >
                            <View style={{ flexShrink: 1 }}>{this.renderIcons(element.key)}</View>
                            <View style={{ width: '45%', justifyContent: 'flex-start', flexDirection: 'row' }}>
                                <Text style={[styles.contentheaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                                    {element.lbl}
                                </Text>
                            </View>
                            <View style={{ flexGrow: 1, justifyContent: 'flex-end', flexDirection: 'row' }}>
                                {this.renderSettingsType(element)}
                            </View>
                        </View>
                        {this.separator()}
                    </View>
                </View>
            );
        };
        if (element.key === 'ac_google') {
            if (gglLgnMgr.hasPlayServices()) {
                return renderself(element);
            } else {
                return null;
            }
        } else {
            return renderself(element);
        }
    };

    renderMyAccoutElement = (item) => {
        return item.content.map((element) => {
            if (element.editable === 'true') {
                if (this.appSource == CONSTANTS.kFBInstantApp && (element.key == 'ac_facebook' || element.key == 'ac_logout')) {
                    return this.renderAccountElementContent(element);
                }
                if (this.appSource == CONSTANTS.kDeskTopApp && (element.key == 'ac_lexulous' || element.key == 'ac_logout')) {
                    return this.renderAccountElementContent(element);
                }
                if (this.appSource != CONSTANTS.kFBInstantApp && this.appSource != CONSTANTS.kDeskTopApp) {
                    return this.renderAccountElementContent(element);
                }
            } else {
                return null;
            }
        });
    };

    renderIcons = (data) => {
        switch (data) {
            case 'ac_facebook':
                return (
                    <FontAwesomeIcon
                        icon={faFacebookSquare}
                        size={25}
                        color={themeConfigutation.getColor('#3b5494')}
                        style={{ padding: 8 }}
                    />
                );

            case 'ac_google':
                return <FontAwesomeIcon icon={faGoogle} size={25} color={'#E13834'} style={{ padding: 8 }} />;

            case 'ac_apple':
                return (
                    <FontAwesomeIcon
                        icon={faApple}
                        size={25}
                        style={{ padding: 8, color: themeConfigutation.getColor('#000') }}
                    />
                );

            case 'ac_lexulous':
                return <FontAwesomeIcon icon={faGameBoard} size={25} color={'#00a6f0'} style={{ padding: 8 }} />;

            case 'ac_logout':
                return (
                    <FontAwesomeIcon
                        icon={faSignOutAlt}
                        size={25}
                        style={{ padding: 8, color: themeConfigutation.getColor('#000') }}
                    />
                );

            default:
                return null;
        }
    };
    updateSections = (activeSections: Array<any>) => {
        soundManager.playSound(soundManager.RJSound.RJSoundClick);
        this.setState({ activeSections });
    };
    getBooleanContainer = (data) => {
        return (
            <BooleanToggleContainer
                value={data.def_value == 'y' ? true : false}
                false_col={'#767577'}
                tag={data.key}
                true_col={'#1d9df1'}
                onValueSelect={this.onSwitchValueChange}
            />
        );
    };
    getSelectContainer = (data) => {
        let dropDownStyle =
            data.key === 'gp_boardtheme' || data.key === 'gp_tiletheme'
                ? [styles.pickerStyle]
                : [styles.drillDown_pickerStyle, { backgroundColor: themeConfigutation.getColor('#e5e7e9') }];
        return (
            <SelectContainer
                drillDown_pickerStyle={dropDownStyle}
                selectItem={this.getDisplaySelectorvalues(data.key)}
                defaultButtonText={this.getDefaultnSelecteddata(data)}
                onValueSelect={this.onDropdownValueSelect}
                tag={data.key}
                renderType={'text'}
            />
        );
    };
    getSlidingWindowContainer = (data) => {
        return (
            <SlidingWindowContainer
                frameItems={this.getDisplaySelectorvalues(data.key)}
                onValueSelect={this.onSlidingValueSelect}
                defaultFrame={data}
                renderType={data.key == 'gp_brdcntrimg' ? 'icon' : 'text'}
            />
        );
    };
    getDisplaySelectorvalues = (data) => {
        switch (data) {
            case 'gs_prefdic':
                return trslateConstants.DictionaryNames();
            case 'gs_boardtype':
                return trslateConstants.BoardTypes();
            case 'gs_gametype':
                return trslateConstants.GameTypes();
            case 'gp_brdcntrimg':
                return trslateConstants.BoardCenterImgTypes();
            case 'gp_chtfntsze':
                return trslateConstants.FontSizeTypes();
            default:
                return ['1', '2', '3', '4'];
        }
    };
    getDefaultnSelecteddata = (data) => {
        switch (data.key) {
            case 'gs_prefdic':
                return trslateConstants.DictionaryValues()[data.def_value];
            case 'gs_boardtype':
                return trslateConstants.BoardTypeValues()[data.def_value];
            case 'gs_gametype':
                return trslateConstants.GameTypeValues()[data.def_value];
            default:
                return data.def_value;
        }
    };

    getDictionaryValue = (defaultVal: string) => {
        return trslateConstants.DictionaryValues()[defaultVal];
    };
    getSliderContainer = (data) => {
        let range_value = data.def_value.split('-');
        let min_range = Number(range_value[0]);
        let max_range = Number(range_value[1]);
        if (min_range < CONSTANTS.SliderLowerRange) {
            min_range = CONSTANTS.SliderLowerRange;
        }
        if (max_range > CONSTANTS.SliderUpperRange) {
            max_range = CONSTANTS.SliderUpperRange;
        }
        return (
            <View style={{ width: '51%', justifyContent: 'flex-end', flexDirection: 'row' }}>
                <SliderContainer
                    min={min_range}
                    max={max_range}
                    style={styles.slider_container}
                    onValueSelect={this.onRangeValueSelect}
                    tag={data.key}
                />
            </View>
        );
    };

    purchaseDidCompleted = (data: ServerResponse | null, sku: string): void => {
        console.info('pflview purchaseDidCompleted :: ' + sku);
        console.info('pflview purchaseDidCompleted 003 :: ' + CONSTANTS.kLexProOneMonthSubsPrdctId);
        switch (sku) {
            case CONSTANTS.kLexAnalizerPrdctId:
                requestManager.fetchUserSettings();
                break;
            case CONSTANTS.kLexProOneMonthSubsPrdctId:
                this.updateSubscriptionStatus();
                break;
            case CONSTANTS.kLexProOneYearSubsPrdctId:
                this.updateSubscriptionStatus();
                break;
        }
    };

    didTappedPurchaseAnalizerConsumable = () => {
        Platform.OS === 'android' || Platform.OS === 'ios'
            ? inAppPurchases.requestPurchase(CONSTANTS.kLexAnalizerPrdctId, this.purchaseDidCompleted)
            : null;
    };

    getPrchsBtnClickedFunc = (data) => {
        if (data.key === 'pro_till') {
            this.getActivated_ProActiveUntill();
        }
        if (data.key === 'anlz_till') {
            this.getActivated_AnalizeActiveUntill();
        }
    };

    didTappedSubscription = (data: SectionElementContent) => {
        let sku = [CONSTANTS.kLexProOneMonthSubsPrdctId, CONSTANTS.kLexProOneYearSubsPrdctId];
        if (data.key === 'ad_free') {
            let isempty = this.state.currentAdsFreeSubscriptions && this.state.currentAdsFreeSubscriptions.length === 0;
            if (isempty) {
                this.showSubscriptionAlert(sku);
            } else {
                this.showCancelSubscriptionAlert();
            }
        }
    };

    showSubscriptionAlert = async (sku: Array<string>) => {
        let ProductDetails: { [string]: { [string]: string } } = await inAppPurchases.getProductsDisplayDetails(sku);
        let AlertBtnDetails = sku.map((productId) => {
            return {
                text: `${
                    ProductDetails[productId].subscriptionPeriodAndroid === 'P1Y'
                        ? '1 ' + translate('year')
                        : '1 ' + translate('month')
                }              ${ProductDetails[productId].localizedPrice}/${
                    ProductDetails[productId].subscriptionPeriodAndroid === 'P1Y' ? translate('year') : translate('month')
                }`,
                action: () => {
                    this.doSubscriptionAdFree(productId);
                    this.props.clearAlert();
                },
                color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
            };
        });
        let cancelBtnDetails = {
            text: translate('cancel'),
            action: () => {
                this.props.clearAlert();
            },
            color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
            type: CONSTANTS.AlertBoxButtonType.SHOWCANCELONLY,
        };
        AlertBtnDetails.push(cancelBtnDetails);

        let alertBoxInfo: AlertBoxType = {
            title: translate('active_pro'),
            message: translate('activate_des'),
            actions: AlertBtnDetails,
        };
        this.props.showAlert(alertBoxInfo);
    };

    showCancelSubscriptionAlert = async () => {
        let ProductDetails: { [string]: { [string]: string } } = await inAppPurchases.getProductsDisplayDetails(
            this.state.currentAdsFreeSubscriptions
        );
        let Subscdetails = ProductDetails[this.state.currentAdsFreeSubscriptions[0]];

        let alertBoxInfo: AlertBoxType = {
            title: translate('active_pro'),
            message: `${translate('activate_des')} \n\n ${Subscdetails.title}\n${Subscdetails.localizedPrice}/${
                Subscdetails.subscriptionPeriodAndroid === 'P1Y' ? translate('year') : translate('month')
            }`,
            actions: [
                {
                    text: translate('cancel_subsciption'),
                    action: () => {
                        this.doSubscriptionAdFree(this.state.currentAdsFreeSubscriptions[0]);
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
                {
                    text: translate('cancel'),
                    action: () => {
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWCANCELONLY,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    };

    getActivated_ProActiveUntill = () => {
        console.log('PRO active until Purchase Btn clicked');
        let purchaseBtnClicked = Platform.select({
            native: () => {
                console.log('PRO active until implementation pending');
            },
            default: () => {
                let purchase: string | null = appConfiguration.getPurchasePlugin();
                if (purchase != null) {
                    let productId: string | null = appConfiguration.getProductProtill();
                    if (productId != null) {
                        let onCompletion = (error: Error | null, value: string | null): void => {
                            if (error != null) {
                                console.log('PRO active until purchase error :: ' + JSON.stringify(error));
                            } else if (value != null) {
                                console.log('PRO active until purchase success :: ' + value);
                                requestManager.fetchUserSettings();
                            }
                        };
                        console.log('will call PRO active until purchase');
                        window[purchase](productId, onCompletion);
                    }
                } else {
                    console.log('PRO active until purchase is null');
                }
            },
        });
        purchaseBtnClicked();
    };

    getActivated_AnalizeActiveUntill = () => {
        console.log('Analyze active until Purchase Btn clicked');
        let purchaseBtnClicked = Platform.select({
            native: () => {
                console.log('Analyze active until implementation pending');
            },
            default: () => {
                let purchase: string | null = appConfiguration.getPurchasePlugin();
                if (purchase != null) {
                    let productId: string | null = appConfiguration.getProductAnalysetill();
                    if (productId != null) {
                        let onCompletion = (error: Error | null, value: string | null): void => {
                            if (error != null) {
                                console.log('Analyze active until purchase error :: ' + JSON.stringify(error));
                            } else if (value != null) {
                                console.log('Analyze active until purchase success :: ' + value);
                                requestManager.fetchUserSettings();
                            }
                        };
                        console.log('will call Analyze active until purchase');
                        window[purchase](productId, onCompletion);
                    }
                } else {
                    console.log('Analyze active until purchase is null');
                }
            },
        });
        purchaseBtnClicked();
    };

    updateSubscriptionStatus = () => {
        console.info('will update subscription status');
        let reqdata = [CONSTANTS.kLexProOneMonthSubsPrdctId, CONSTANTS.kLexProOneYearSubsPrdctId];
        userDefault.getMultiple(reqdata).then((result) => {
            let data: Array<string> = [];
            if (result != null) {
                console.log('updateSubscriptionStatus value :: ' + JSON.stringify(result));
                result.forEach((value, index) => {
                    if (value !== null && value !== undefined) {
                        console.log('updateSubscriptionStatus value :: ' + value);
                        switch (reqdata[index]) {
                            case CONSTANTS.kLexProOneMonthSubsPrdctId:
                                data.push(CONSTANTS.kLexProOneMonthSubsPrdctId);
                                break;
                            case CONSTANTS.kLexProOneYearSubsPrdctId:
                                data.push(CONSTANTS.kLexProOneYearSubsPrdctId);
                                break;
                        }
                    }
                });
            }
            console.info('subscription status updated currentSubscriptions :: ' + JSON.stringify(data));
            this.setState({ currentAdsFreeSubscriptions: data });
            setTimeout(() => {
                bannerAd.onUserSettingsUpdate();
            }, 0);
        });
    };

    doSubscriptionAdFree = (sku: string) => {
        let isempty = this.state.currentAdsFreeSubscriptions && this.state.currentAdsFreeSubscriptions.length === 0;
        if (!isempty) {
            if (this.state.currentAdsFreeSubscriptions.includes(sku)) {
                if (Platform.OS === 'ios') {
                    Linking.openURL('https://apps.apple.com/account/subscriptions');
                } else if (Platform.OS === 'android') {
                    let url =
                        'https://play.google.com/store/account/subscriptions?package=' +
                        CONSTANTS.packageName +
                        '&sku=' +
                        this.state.currentAdsFreeSubscriptions[0];
                    console.log('is not empty will open cancel subscription :: ' + url);
                    Linking.openURL(url);
                }
            }
        } else {
            if (!this.state.currentAdsFreeSubscriptions.includes(sku)) {
                console.log('is empty will initiate purchase');
                Platform.OS === 'android' || Platform.OS === 'ios'
                    ? inAppPurchases.requestSubscription(sku, this.purchaseDidCompleted)
                    : null;
            }
        }
    };

    getPurchaseBtn = (data) => {
        let val = data.def_value;
        let btnStyle = {};
        let btnDisable = false;
        let TextColor = 'white';

        if (Number(val) > 0) {
            val = data.def_value;
            btnStyle = { backgroundColor: themeConfigutation.getColor('#f4f3ef') };
            TextColor = themeConfigutation.getColor('#000');
            btnDisable = true;
        } else {
            val = 'Purchase';
            if (this.appSource == CONSTANTS.kDeskTopApp || this.appSource == CONSTANTS.kFBInstantApp) {
                val = 'Inactive';
                btnDisable = true;
                btnStyle = { backgroundColor: 'transparent' };
                TextColor = themeConfigutation.getColor('#000');
            }
        }

        return (
            <Pressable
                disabled={btnDisable}
                style={[styles.prchsBtnStyle, btnStyle]}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('pro_featu_analyzer_credit_btn_press', 'pfl_vw_container');
                    this.didTappedPurchaseAnalizerConsumable();
                }}
            >
                <Text style={[{ color: TextColor, fontSize: 14 }]}> {val} </Text>
            </Pressable>
        );
    };

    getDateFormat = (data) => {
        let timestamp = new Date(data).getTime();
        let todate = new Date(timestamp).getDate();
        let tomonth = new Date(timestamp).getMonth() + 1;
        let toyear = new Date(timestamp).getFullYear();
        return todate + '/' + tomonth + '/' + toyear;
    };

    getPurchaseBtnOrValidDate = (data) => {
        let valDate = Number(data.def_value) * 1000;
        let recentDate = Date.now();
        let btnStyle = {};
        let btnDisable = false;
        let TextColor = 'white';

        if (valDate >= recentDate) {
            valDate = this.getDateFormat(valDate);
            btnStyle = { backgroundColor: themeConfigutation.getColor('#f4f3ef') };
            TextColor = themeConfigutation.getColor('#000');
            btnDisable = true;
        } else {
            valDate = 'Purchase';
            if (this.appSource == CONSTANTS.kDeskTopApp) {
                btnDisable = true;
                valDate = 'Inactive';
                btnStyle = { backgroundColor: 'transparent' };
                TextColor = themeConfigutation.getColor('#000');
            }
        }

        return (
            <Pressable
                disabled={btnDisable}
                style={[styles.prchsBtnStyle, btnStyle]}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('pro_featur__' + data.key + '_btn_press', 'pfl_vw_container');
                    this.getPrchsBtnClickedFunc(data);
                }}
            >
                <Text style={[{ color: TextColor, fontSize: 14 }]}> {valDate} </Text>
            </Pressable>
        );
    };

    getSubscriptionBtn = (data) => {
        let isempty = this.state.currentAdsFreeSubscriptions && this.state.currentAdsFreeSubscriptions.length === 0;
        let valAction = 'Inactive';
        let btnDisable = false;
        let TextColor = 'white';
        console.log('getSubscriptionBtn :: ' + JSON.stringify(this.state.currentAdsFreeSubscriptions));
        if (!isempty) {
            valAction = 'Active';
        }

        return (
            <Pressable
                disabled={btnDisable}
                style={[styles.prchsBtnStyle]}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('pro_featur__' + data.key + '_btn_press', 'pfl_vw_container');
                    this.didTappedSubscription(data);
                }}
            >
                <Text style={[{ color: TextColor, fontSize: 14 }]}> {valAction} </Text>
            </Pressable>
        );
    };

    renderSettingsType(data) {
        switch (data.type) {
            case 'kBool':
                return this.getBooleanContainer(data);

            case 'kSel':
                return this.getSelectContainer(data);

            case 'kWindow':
                return this.getSlidingWindowContainer(data);

            case 'kSlider':
                return this.getSliderContainer(data);

            case 'kSwipe':
                return this.renderThemeImage(data);

            case 'kPchse':
                return this.getPurchaseBtn(data);

            case 'kDate':
                return this.getPurchaseBtnOrValidDate(data);

            case 'kSubs':
                return this.getSubscriptionBtn(data);

            case 'kLgn':
                return this.getLoginOrLogoutButton(data);

            case 'kLgnout':
                return this.getLoginOrLogoutButton(data);

            case 'kBtnNtf':
                return this.getTestNotificationUI(data);

            case 'kBtnDelUser':
                return this.getDelUserUI(data);

            default:
                return null;
        }
    }

    getDelUserUI = (data) => {
        return (
            <ButtonContainer
                tag={data.key}
                buttonText={translate('del_acc')}
                onbuttonPressed={(key: string) => {
                    rjAnalytics.sendAnalyticsEvent('privacy_sett_del_acc_btn_press', 'pfl_vw_container');
                    this.doDeleteAccount(key);
                }}
            />
        );
    };

    getTestNotificationUI = (data) => {
        let btnStyle = [styles.prchsBtnStyle, { width: 60, height: 30 }];
        let btnTextColour = [{ color: 'white', fontSize: 14 }];
        if (!this.state.hasPushNtfPermission) {
            btnStyle.push({ backgroundColor: '#FF6347' });
        }
        if (this.state.testNotificationTapped) {
            btnTextColour.push({ color: '#000000' });
            btnStyle.push({ backgroundColor: '#808080' });
        }
        return (
            <Pressable
                disabled={this.state.testNotificationTapped}
                style={btnStyle}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('notification_test_nft_btn_pressed', 'pfl_vw_container');
                    this.receiveTestPushNtf();
                }}
            >
                <Text style={btnTextColour}> {translate('send')} </Text>
            </Pressable>
        );
    };

    getLoginOrLogoutButton = (data) => {
        let txtvals = this.getAccountVisibilityStatusText();
        return <ButtonContainer tag={data.key} buttonText={txtvals[data.key]} onbuttonPressed={this.loginOrloghoutHandler} />;
    };

    doDeleteAccount = (key: string) => {
        rjAnalytics.sendAnalyticsEvent('del_acc_cfm_alert_opened', 'pfl_vw_container');
        let alertBoxInfo: AlertBoxType = {
            message: translate('del_acc_cfm'),
            actions: [
                {
                    text: translate('alert_no_button'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('del_acc_cfm_alert_no_btn_press_closed', 'pfl_vw_container');
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
                {
                    text: translate('alert_yes_button'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('del_acc_cfm_alert_yes_btn_press_closed', 'pfl_vw_container');
                        this.props.clearAlert();
                        this.accDeleteHandler();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    };

    accDeleteHandler = () => {
        let rq: AxiosPromise<ServerResponse> = requestManager.deleteUserAccount();
        rq.then((response: AxiosResponse<ServerResponse, any>) => {
            if (response.status == CONSTANTS.HTTPSuccessStatus) {
                return response.data;
            } else {
                throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
            }
        })
            .then(async (srvresp: ServerResponse) => {
                if (srvresp.check === CONSTANTS.kSuccess) {
                    this.logOutHandler();
                } else {
                    console.log('accDeleteHandler error', srvresp);
                }
            })
            .catch((error) => {
                handleException(error);
            })
            .finally(() => {});
    };

    loginOrloghoutHandler = (key: string) => {
        this.setState({ detailTypeKey: key });
        switch (key) {
            case 'ac_facebook': {
                if (this.props.profileVw.fbLoginInfo == null) {
                    this.doFbLogin(null);
                } else {
                    this.openDetailsPopup();
                }
                break;
            }
            case 'ac_google': {
                if (this.props.profileVw.gglLoginInfo == null) {
                    this.doGoogleLogin();
                } else {
                    this.openDetailsPopup();
                }
                break;
            }
            case 'ac_lexulous': {
                if (this.props.profileVw.lxlsLoginInfo == null) {
                    this.doLXLSDotComLogin();
                } else {
                    this.openDetailsPopup();
                }
                break;
            }
            case 'ac_apple': {
                if (this.props.profileVw.appleLoginInfo == null) {
                    this.doAppleLogin();
                } else {
                    this.openDetailsPopup();
                }
                break;
            }
            case 'del_user':
                {
                    rjAnalytics.sendAnalyticsEvent('sign_out_cfm_alert_opened', 'pfl_vw_container');
                    let alertBoxInfo: AlertBoxType = {
                        message: translate('sign_out_cfm'),
                        actions: [
                            {
                                text: translate('alert_no_button'),
                                action: () => {
                                    rjAnalytics.sendAnalyticsEvent(
                                        'sign_out_cfm_alert_no_btn_press_closed',
                                        'pfl_vw_container'
                                    );
                                    this.props.clearAlert();
                                },
                                color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                                type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                            },
                            {
                                text: translate('alert_yes_button'),
                                action: () => {
                                    rjAnalytics.sendAnalyticsEvent(
                                        'sign_out_cfm_alert_yes_btn_press_closed',
                                        'pfl_vw_container'
                                    );
                                    this.props.clearAlert();
                                    this.logOutHandler();
                                },
                                color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                                type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                            },
                        ],
                    };
                    this.props.showAlert(alertBoxInfo);
                }
                break;
            case 'ac_logout':
                rjAnalytics.sendAnalyticsEvent('sign_out_cfm_alert_opened', 'pfl_vw_container');
                let alertBoxInfo: AlertBoxType = {
                    message: translate('sign_out_cfm'),
                    actions: [
                        {
                            text: translate('alert_no_button'),
                            action: () => {
                                rjAnalytics.sendAnalyticsEvent('sign_out_cfm_alert_no_press_closed', 'pfl_vw_container');
                                this.props.clearAlert();
                            },
                            color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                            type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                        },
                        {
                            text: translate('alert_yes_button'),
                            action: () => {
                                rjAnalytics.sendAnalyticsEvent('sign_out_cfm_alert_yes_press_closed', 'pfl_vw_container');
                                this.props.clearAlert();
                                this.logOutHandler();
                            },
                            color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                            type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                        },
                    ],
                };
                this.props.showAlert(alertBoxInfo);
                break;
        }
    };

    openDetailsPopup = () => {
        rjAnalytics.sendAnalyticsEvent('my_account_login_details_opened', 'pfl_vw_container');
        this.props.updatePopupVisibility({ showDetailsPopup: true });
    };

    closeDetailPopuop = () => {
        this.props.clearPopups();
        this.setState({ detailTypeKey: '' });
    };

    renderDetailsContainer = () => {
        if (this.props.popups.showDetailsPopup) {
            let details: { profile: ProfileInfo, ProfileVw: ProfileAssociations } = {
                profile: this.props.profile,
                ProfileVw: this.props.profileVw,
            };
            return (
                <DetailsContainer
                    closePopupHandler={() => {
                        this.closeDetailPopuop();
                        rjAnalytics.sendAnalyticsEvent('my_account_login_details_closed', 'pfl_vw_container');
                    }}
                    details={details}
                    detailTypeKey={this.state.detailTypeKey}
                />
            );
        } else {
            return null;
        }
    };

    logOutHandler = () => {
        gglLgnMgr.doSignOut(null);
        applLgnMgr.doSignOut(null);
        fbLgnMgr.doSignOut(null);
        lxlsLgnMgr.doSignOut(null);
        lxlsLgnMgr.deleteTempLoginData();

        //clear redux data
        pushNtfMgr.deleteDevicePin();
        loginCoordinator.cleanOldOrInvalidData();
        WordValidityWebSocketProvider.disconnect();
        //clear local storage data
        userDefault.clearAll();
        if (Platform.OS === 'android') {
            userDefault.getName().then((name) => {
                userDefault.setName('USER_SETTINGS_FILE_NAME').then(() => {
                    userDefault.clearAll().then(() => {
                        userDefault.setName(name);
                    });
                });
            });
        }
        let logoutFBInstant = Platform.select({
            native: () => {},
            default: () => {
                let quitapp: string | null = appConfiguration.getQuitAppPlugin();
                if (quitapp != null) {
                    console.log('will call quit app');
                    window[quitapp]();
                } else {
                    console.log('Quit app is null');
                }
            },
        });
        logoutFBInstant();
        //begin from start
        themeConfigutation.overridenByApp = false;
        this.props.navigation.reset({
            index: 0,
            routes: [{ name: 'AppSplash' }],
        });
    };

    onImagePress = (guid: string) => {
        rjAnalytics.sendAnalyticsEvent('censored_players_avtar_pressed', 'pfl_vw_container');
        rjAnalytics.sendAnalyticsEvent('profile_stats_container_opened', 'pfl_vw_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + guid } });
    };

    getCensorList = () => {
        let friendsList = this.props.friends;
        let censorList = friendsList.filter((item) => item.type === 'censored');
        let DisplayEmptyListMsg: boolean = censorList.length < 1;
        if (DisplayEmptyListMsg) {
            return (
                <View
                    style={[
                        styles.msgViewStyle,
                        {
                            backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                            borderColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Text style={[styles.contentheaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('empty_cnsr_list_msg')}
                    </Text>
                </View>
            );
        } else {
            return censorList.map((element, index) =>
                element.data.map((element1, index) => (
                    <View
                        key={index}
                        style={{
                            width: '100%',
                            height: 60,
                            justifyContent: 'center',
                            alignItems: 'center',
                            backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                            borderColor: themeConfigutation.getColor('#000'),
                            borderBottomWidth: 1,
                        }}
                    >
                        <FndElementView element={element1} imageHandler={this.onImagePress} />
                    </View>
                ))
            );
        }
    };

    updateUserSetting = (settings: userSettings) => {
        let updateKey: string = Object.keys(settings)[0];
        let updatedSettingVal = { [updateKey]: { ...this.props.profileSettings[updateKey], ...settings[updateKey] } };
        if (netManager.isConnected()) {
            // dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateUserSetting(settings);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    dataServer.getStore().dispatch(actionUpdateUserSettings(updatedSettingVal));

                    // requestManager.fetchUserSettings();
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    // dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    onRangeValueSelect = (min: number, max: number, key: string) => {
        let updated_range = min.toString() + '-' + max.toString();
        let section_tag = this.getSectionTag(key);
        let setting_lbl = {
            [section_tag]: {
                [key]: updated_range,
            },
        };
        console.log('setting_lbl', setting_lbl);
        rjAnalytics.sendAnalyticsEvent(section_tag + '__' + key, 'pfl_vw_container');
        this.updateUserSetting(setting_lbl);
    };

    onSwitchValueChange = (key: string, val: string) => {
        let section_tag = this.getSectionTag(key);
        let setting_lbl = {
            [section_tag]: {
                [key]: val,
            },
        };
        if (key == 'gp_darktheme') {
            themeConfigutation.overridenByApp = val == 'y';
        }
        rjAnalytics.sendAnalyticsEvent(section_tag + '__' + key, 'pfl_vw_container');
        this.updateUserSetting(setting_lbl);
    };
    onDropdownValueSelect = (key: string, val: string) => {
        let section_tag = this.getSectionTag(key);
        let updated_value = this.getChangedselectorValue(key, val);
        let setting_lbl = {
            [section_tag]: {
                [key]: updated_value,
            },
        };
        // console.log('setting_lbl', setting_lbl);
        rjAnalytics.sendAnalyticsEvent(section_tag + '__' + key, 'pfl_vw_container');
        this.updateUserSetting(setting_lbl);
    };
    onSlidingValueSelect = (key: string, val: string) => {
        this.onDropdownValueSelect(key, val);
    };
    getChangedselectorValue = (key: string, val: string) => {
        switch (key) {
            case 'gs_prefdic':
                return trslateConstants.DictionaryServervalues()[val];
            case 'gs_boardtype':
                return trslateConstants.BoardServervalues()[val];
            case 'gs_gametype':
                return trslateConstants.gameServervalues()[val];

            default:
                return val;
        }
    };

    getSectionTag = (key: string) => {
        let section_tag = '';
        let setttingsSection = this.settingDescription();
        for (let i = 0; i < setttingsSection.length && section_tag == ''; i++) {
            let section_data = setttingsSection[i].content;
            for (let j = 0; j < section_data.length; j++) {
                if (section_data[j].key === key) {
                    section_tag = setttingsSection[i].key;
                    break;
                }
            }
        }
        return section_tag;
    };

    renderThemeImage = (data) => {
        return (
            <Pressable
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('rjshrpicker_theme_opened', 'pfl_vw_container');
                    this.props.navigation.navigate('Theme', {
                        header: data.key == 'gp_boardtheme' ? translate('slct_bthm') : translate('slct_tthm'),
                        tag: data.key,
                        currentSelection: data.def_value ?? '0',
                    });
                }}
            >
                <Image
                    resizeMode="contain"
                    source={
                        data.key == 'gp_boardtheme'
                            ? CONSTANTS.boardThemes[data.def_value ?? '0']
                            : CONSTANTS.tileThemes[data.def_value ?? '0']
                    }
                    style={[styles.avatarFieldStyle]}
                />
            </Pressable>
        );
    };

    renderAdViewPlaceHolder = () => {
        return <View style={[styles.adview, { height: this.state.bannerHt }]} />;
    };

    renderLexulousVersion = () => {
        return (
            <Text style={{ alignSelf: 'center', marginBottom: 20, color: themeConfigutation.getColor('#5f6368') }}>
                {`${translate('lexulous_ver')} ${CONSTANTS.appVersion}`}
            </Text>
        );
    };

    render() {
        return this.state.isFocused ? (
            <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                <LoadingIndicator />
                <ProfileBarContainer
                    canShare={false}
                    openPopupHandler={() => {
                        this.userNameBeginEditing();
                        rjAnalytics.sendAnalyticsEvent('username_editing_opened', 'pfl_vw_container');
                    }}
                    userAvatarDidFinishedEditing={(recentSelectedAvtar: string) => {
                        this.userAvatarDidFinishedEditing(recentSelectedAvtar);
                        rjAnalytics.sendAnalyticsEvent('avtar_changed', 'pfl_vw_container');
                    }}
                    disableActionBtn={false}
                />

                <ScrollView showsVerticalScrollIndicator={false}>
                    {this.renderSettingslist()}
                    {this.renderLexulousVersion()}
                </ScrollView>
                {this.renderUserNameContainer()}
                {this.renderDetailsContainer()}
                {this.renderAdViewPlaceHolder()}
            </View>
        ) : null;
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    descriptionText: { textAlign: 'center' },
    drillDown_header: {
        // backgroundColor: 'rgb(226, 225, 221)',
        paddingHorizontal: 10,
        paddingVertical: 4,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    drillDown_container: {
        marginBottom: 20,
    },
    drillDown_headerText: {
        textAlign: 'center',
        fontSize: 16,
        padding: 8,
        fontWeight: 'bold',
    },
    drillDown_content: {
        backgroundColor: '#fff',
        width: '100%',
        alignItems: 'center',
    },
    active: {
        backgroundColor: 'rgb(242, 242, 242)',
    },
    drillDown_contentRowstyle: {
        padding: 8,
        width: '100%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        alignItems: 'center',
        // marginTop: 3,
        // marginBottom: 3,
    },
    drillDown_pickerStyle: {
        margin: 4,
        width: 160,
        height: 40,
        // margin: 12,
        alignSelf: 'center',
        justifyContent: 'center',
        borderWidth: 1,
    },
    slider_container: {
        width: '100%',
        justifyContent: 'center',
    },
    pickerStyle: {
        height: 50,
        width: 75,
        alignSelf: 'flex-start',
        backgroundColor: 'transparent',
    },
    avatarFieldStyle: {
        width: 70,
        height: 50,
        justifyContent: 'center',
    },
    prchsBtnStyle: {
        backgroundColor: '#1d9df1',
        width: 100,
        height: 30,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 5,
        borderRadius: 4,
    },
    contentheaderStyle: {
        fontSize: 14,
        paddingHorizontal: 10,
        paddingVertical: 4,
    },
    msgViewStyle: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 12,
        borderBottomWidth: 1,
    },
    adview: {
        backgroundColor: '#f4f3ef',
    },
    fullWidth: {
        width: '100%',
    },
    seperatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
});

function mapStateToProps(state) {
    const { profile, profileVw, profileSettings, minStats, popups, utils } = state;
    const friends = state.friends.friends ?? [];
    const lastupdated = state.friends.lastupdated ?? 0;
    return { profile, profileVw, profileSettings, friends, lastupdated, minStats, popups, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionSetProfile,
            actionUpdateProfile,
            actionUpdateAppleLgnInfo,
            actionUpdateLXLSLgnInfo,
            actionUpdateUserSettings,
            updatePopupVisibility,
            clearPopups,
            showAlert,
            clearAlert,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(PFLVwContainer);
