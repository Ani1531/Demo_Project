// @flow

import React from 'react';
import { Image, View, StyleSheet, Platform } from 'react-native';

export default class NavLexLogo extends React.Component<{}> {
    render = () => {
        return (
            <View style={styles.logoContainerStyle}>
                <Image source={require('../assets/lexlogo/lex_nav_logo.png')} style={styles.container} resizeMode="contain" />
            </View>
        );
    };
}
const styles = StyleSheet.create({
    logoContainerStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        ...Platform.select({
            web: {
                width: 140,
                height: 29,
            },
        }),
    },
});
