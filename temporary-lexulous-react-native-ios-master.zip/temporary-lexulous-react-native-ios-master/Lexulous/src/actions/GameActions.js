import * as ActionIdentifiers from '../configs/ActionIdentifiers';

import {
    getGameType,
    getHostGamesHeadToHeadStats,
    getLiveGameStats,
    getMoveStrengthData,
    getOnlinePlayerList,
    isEmailGame,
    isLiveGame,
    updateMoveDefinition,
} from '../service/GamePlayService';
import get from 'lodash/get';
import keys from 'lodash/keys';
import isString from 'lodash/isString';
import Config from '../configs/Config';
import log from 'loglevel';
import { clearDirectionDelay } from './CellActions';
import SoundUtils from '../utils/SoundUtils';
import { lobbyChatMessage } from './LobbyChatActions';
import { batch } from 'react-redux';
import to from 'await-to-js';
import { getRobotMove } from '../service/LiveGamePlayService';
import { gameOver } from './GameOverActions';
import EventWrapper from '../utils/EventWrapper';
import { getNextGameUrl } from '../service/EmailGamePlayService';
import RestAPIProvider from '../provider/RestAPIProvider';
import DimensionUtils from '../utils/DimensionUtils';
import { screenResized } from './DimensionActions';

const eventBus = require('js-event-bus')();

const getPlayerOnlineMessageObj = (buddy, isOnline = true) => ({
    data: {
        type: Config.LOBBY_CHAT_MESSAGE_TYPE_PRIVATE,
        pvtMessageKey: buddy.guid,
        sender: buddy.guid,
        message: `${get(buddy, 'name')} is ${isOnline ? 'online' : 'offline'}`,
        name: buddy.name,
    },
    showAsGameUpdate: true,
});

export const gameHasEnded = (messageObj, globalState) => ({
    type: ActionIdentifiers.GAME_HAS_ENDED,
    payload: messageObj,
    globalState,
});

export const gameStarted = (boardData) => (dispatch, getState) => {
    batch(async () => {
        let state = getState();
        dispatch({
            type: ActionIdentifiers.GAME_STARTED,
            payload: boardData,
            globalState: state,
        });
        state = getState();
        getMoveStrengthData(state);
        dispatch(gameMoveFurtherDataShowLoader());
        let res = await updateMoveDefinition({
            moveWord: get(state, 'game.lastMoveWordPlayedData'),
            lastMoveWordsArr: get(state, 'game.lastMoveWordsArr'),
        });
        dispatch(gameMoveFurtherDataHideLoader());
        dispatch(gameWordDefinitions(res));
        dispatch(getOppStatsAndH2hStats());
        dispatch(sendWordsPlayed(boardData));
        dispatch(screenResized());
    });
};

const getOppStatsAndH2hStats = () => async (dispatch, getState) => {
    if (isLiveGame() || isEmailGame()) {
        let player = get(getState(), 'game.players').find((item) => item.guid !== get(getState(), 'game.guid'));
        if (player) {
            let res = await getHostGamesHeadToHeadStats({
                uid: {
                    guid: player.guid,
                },
            });
            dispatch(addHostGameHeadToHeadStat(res));

            if (isEmailGame() && res) {
                let userStats = [];
                (res.guidArr || []).forEach(async (item) => {
                    let statsData = await getLiveGameStats([item]);
                    let userStat = {
                        guid: item,
                        rating: get(statsData, 'data.0.rating_stats.rating'),
                        played: get(statsData, 'data.0.game_stats.played'),
                        won: get(statsData, 'data.0.game_stats.won'),
                        lost: get(statsData, 'data.0.game_stats.lost'),
                        drawn: get(statsData, 'data.0.game_stats.drawn'),
                        bingo_count: get(statsData, 'data.0.game_stats.bingo_count'),
                    };
                    userStats.push(userStat);
                });
                let nextGameUrl = await getNextGameUrl(get(getState(), 'config.isProUser'));
                let eventObj = {
                    userStatsObj: {
                        data: {
                            userstats: userStats,
                            h2hstats: res.h2hstats,
                            nextgamegid: get(nextGameUrl, 'data.gid'),
                        },
                    },
                };
                EventWrapper.dispatchCustomEvent(eventObj);
            }
        }
    }
};

const sendWordsPlayed = (boardData) => async (dispatch, getState) => {
    let wordsPlayed = get(boardData, 'data.' + getState().game.channel + '.boarddata.wordsplayed') || [];
    let wordsPlayedEventObj = wordsPlayed.map((words) =>
        words.map((word) => {
            let wordInfo = word.split(',');
            if (wordInfo.length > 0) {
                return wordInfo[3] === 'r' ? wordInfo[1] : '';
            }
        })
    );

    if (isEmailGame()) {
        let eventObj = {
            wordsPlayedObj: {
                data: wordsPlayedEventObj,
            },
        };
        EventWrapper.dispatchCustomEvent(eventObj);
    }

    if (DimensionUtils.isNative()) {
        let wordDefinationArray = await RestAPIProvider.getDefinationByApi(wordsPlayedEventObj.flat());

        dispatch({
            type: ActionIdentifiers.GET_ALL_PLAYED_WORD_DEFINATIONS,
            payload: wordDefinationArray,
        });
    }
};

export const gameMove = (boardData) => (dispatch, getState) => {
    batch(async () => {
        dispatch({
            type: ActionIdentifiers.GAME_MOVE,
            payload: boardData,
            globalState: getState(),
        });

        let state = getState();

        getMoveStrengthData(state);

        dispatch(gameMoveFurtherDataShowLoader());

        log.info(
            'in GameActions, in gameMove, get(state, "game.lastMoveWordPlayedData") is:\n' +
                JSON.stringify(get(state, 'game.lastMoveWordPlayedData'), null, 2)
        );
        log.info(
            'in GameActions, in gameMove, get(state, "game.lastMoveWordsArr") is:\n' +
                JSON.stringify(get(state, 'game.lastMoveWordsArr'), null, 2)
        );

        let res = await updateMoveDefinition({
            moveWord: get(state, 'game.lastMoveWordPlayedData'),
            lastMoveWordsArr: get(state, 'game.lastMoveWordsArr') || [],
        });
        log.info('in GameActions, in gameMove, res is:\n' + JSON.stringify(res, null, 2));
        dispatch(gameMoveFurtherDataHideLoader());
        dispatch(gameWordDefinitions(res));
        state = getState();
        if (get(state, 'game.game_type') === Config.GAME_TYPE_SOLO) {
            if (state.game.sourceType === Config.SOLO_SOURCE_ROBOT) {
                playRobotMove(state);
            }
        }

        dispatch({
            type: ActionIdentifiers.SET_PLAYER_STATUS_AVL_AFTER_GAME_HAS_ENDED,
            payload: boardData,
            globalState: getState(),
        });

        dispatch({
            type: ActionIdentifiers.REMOVE_OBSERVABLE_GAME_FROM_LIST_AFTER_GAME_HAS_ENDED,
            payload: boardData,
            globalState: getState(),
        });
        dispatch(sendWordsPlayed(boardData));
    });
};

const playRobotMove = (globalState) =>
    setTimeout(async () => {
        let res = await to(getRobotMove());
        if (res[1]) {
            let soundFunc = SoundUtils.oppSubmits;
            let movetiles = get(res[1], 'data.' + get(globalState, 'game.channel') + '.boarddata.movetiles');
            if (movetiles[0] && movetiles[0].length >= Config.BINGO_TILES_COUNT) soundFunc = SoundUtils.bingoSound;
            soundFunc();
        }
    }, 500);

export const setResourcePanelWordValidity = (isValid) => ({
    type: ActionIdentifiers.GAME_RESOURCE_PANEL_WORD_VALIDITY,
    payload: isValid,
});
export const setPlayButtonWordValidity = (isValid) => ({
    type: ActionIdentifiers.GAME_PLAY_BUTTON_WORD_VALIDITY,
    payload: isValid,
});

export const gameWordDefinitions = (data) => ({
    type: ActionIdentifiers.GAME_WORD_DEFINITIONS,
    payload: data,
});

/* TODO: MERGE THESE TWO*/
export const gameMoveFurtherDataShowLoader = () => ({
    type: ActionIdentifiers.GAME_MOVE_FURTHER_DATA_SHOW_LOADER,
});

export const gameMoveFurtherDataHideLoader = () => ({
    type: ActionIdentifiers.GAME_MOVE_FURTHER_DATA_HIDE_LOADER,
});
/* END MERGE THESE TWO*/

export const gamePuzzleLastGameStatusesRetrieved = (res) => ({
    type: ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED,
    payload: res,
});

export const gamePuzzlePuzzleRankingsRetrieved = (res) => ({
    type: ActionIdentifiers.GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED,
    payload: res,
});

export const gamePuzzleMoveSentSuccessfully = (res) => ({
    type: ActionIdentifiers.GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY,
    payload: res,
    forNext: true,
    isArchivedGame: false,
});

export const gamePuzzlePassSentSuccessfully = (res) => ({
    type: ActionIdentifiers.GAME_PUZZLE_PASS_SENT_SUCCESSFULLY,
    payload: res,
    forNext: true,
    isArchivedGame: false,
});

export const gameAddObserver = (res) => async (dispatch, getState) => {
    let guids = get(res, 'data.guids') || [];
    let playerList = [
        ...(get(getState(), 'user.onlinePlayerBuddies') || []),
        ...(get(getState(), 'user.onlinePlayerOthers') || []),
    ];
    let someDataMissing = guids.some((guid) => !(playerList || []).find((player) => player.guid === guid));
    if (someDataMissing) await getOnlinePlayerList();
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_ROOM_ADD_OBSERVER,
        payload: res,
    });
};

export const gameRemoveObserver = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_ROOM_REMOVE_OBSERVER,
    payload: res,
});

export const gameLiveGameLogin = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_ROOM_LOGIN,
    payload: res,
});

export const gameHasLiveGame = (res) => ({
    type: ActionIdentifiers.GAME_HAS_ACTIVE_GAME_EVENT,
    payload: res,
});

export const gameLiveGameInvitationReceived = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED,
        globalState: getState(),
        payload: res,
    });

export const gameLiveMultiplayerHostGameLeave = (res) => (dispatch, getState) => {
    batch(() => {
        dispatch({
            type: ActionIdentifiers.GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
            payload: res,
        });
        dispatch({
            type: ActionIdentifiers.PLAYER_LIST_CHANGE_PLAYER_STATUS_JOINED,
            payload: res,
            globalState: getState(),
        });
    });
};

export const gameLiveAddHostedGame = (res) => async (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_ADD_HOSTED_GAME,
        payload: res,
        globalState: getState(),
    });
};

export const gameLiveDeleteHostedGame = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_DELETE_HOSTED_GAME,
    payload: res,
});

export const gameLiveGameHost = (res) => async (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_HOST_GAME_ACTION,
        payload: res,
        globalState: getState(),
    });
};

export const gameLiveGameCancelInvitation = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_CANCEL_INVITATION,
    payload: res,
});

export const gameLiveGameMoreTimeRequestSuccessful = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL,
    payload: res,
});

export const gameLiveGameClearInvitation = () => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_CLEAR_INVITATION,
});

export const gameLiveGameGetOnlineStatus = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_GET_ONLINE_STATUS,
    payload: res,
});

export const gameSetPlayerCount = (res) => ({
    type: ActionIdentifiers.GAME_SET_PLAYER_COUNT,
    payload: res,
});

export const gameLiveGameHostedGamesListRetrieved = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED,
        payload: res,
        globalState: getState(),
    });

export const gameLiveGameOnlinePlayerListAvailable = (res) => (dispatch, getState) => {
    batch(() => {
        log.info('in GameActions, in gameLiveGameOnlinePlayerListAvailable, res is: ' + JSON.stringify(res, null, 2));
        let type = get(res, 'type');
        if (type === 'addply' || type === 'rmply') {
            let buddyList = get(getState(), 'user.buddyList');
            log.info(
                'in GameActions, in gameLiveGameOnlinePlayerListAvailable, buddyList is: ' + JSON.stringify(buddyList, null, 2)
            );
            let data = get(res, 'data') || get(res, 'res.data');
            log.info('in GameActions, in gameLiveGameOnlinePlayerListAvailable, data is: ' + JSON.stringify(data, null, 2));
            let guids = (isString(data) ? [data] : keys(data)) || [];
            log.info('in GameActions, in gameLiveGameOnlinePlayerListAvailable, guids is: ' + JSON.stringify(guids, null, 2));
            let buddyMatches = (buddyObj, guid) => get(buddyObj, 'guid') === guid;
            let buddy =
                (get(buddyList, 'buddies') || []).find((buddy) => guids.find((guid) => buddyMatches(buddy, guid))) ||
                (get(buddyList, 'reqsent') || []).find((buddy) => guids.find((guid) => buddyMatches(buddy, guid)));
            log.info('in GameActions, in gameLiveGameOnlinePlayerListAvailable, buddy is: ' + JSON.stringify(buddy, null, 2));
            let tabIsAlreadyOpen =
                Object.keys(get(getState(), 'lobbyChat.pvtMessages')).length > 0 &&
                Object.keys(get(getState(), 'lobbyChat.pvtMessages')).includes(get(buddy, 'guid'));
            log.info(
                'in GameActions, in gameLiveGameOnlinePlayerListAvailable, tabIsAlreadyOpen is: ' +
                    JSON.stringify(tabIsAlreadyOpen, null, 2)
            );
            if (!!buddy && (type === 'addply' || (type === 'rmply' && tabIsAlreadyOpen))) {
                if (!tabIsAlreadyOpen) SoundUtils.messageSound();
                dispatch(lobbyChatMessage(getPlayerOnlineMessageObj(buddy, type === 'addply')));
            }
        }

        dispatch({
            type: ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE,
            payload: res,
            globalState: getState(),
        });
    });
};

export const gameLiveGameObservableGamesListRetrieved = (res) => (dispatch, getState) => {
    batch(() => {
        dispatch({
            type: ActionIdentifiers.GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED,
            payload: res,
            globalState: getState(),
        });

        dispatch({
            type: ActionIdentifiers.PLAYER_LIST_SET_PLAYER_STATUS_PLY,
            payload: res,
            globalState: getState(),
        });
    });
};

export const gameLiveObservableGameRemove = (res) => (dispatch, getState) => {
    batch(() => {
        dispatch({
            type: ActionIdentifiers.PLAYER_LIST_SET_PLAYER_STATUS_AVL,
            payload: res,
            globalState: getState(),
        });

        dispatch({
            type: ActionIdentifiers.GAME_LIVE_OBSERVABLE_GAME_REMOVE,
            payload: res,
            globalState: getState(),
        });
    });
};

export const gameEmailGameGetNotes = (res) => ({
    type: ActionIdentifiers.GAME_EMAIL_GET_GAME_NOTES,
    payload: res,
});

export const gameEmailGameSetNotes = (res) => ({
    type: ActionIdentifiers.GAME_EMAIL_SET_GAME_NOTES,
    payload: res,
});

export const gameLiveGameDeleteHostedGame = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_DELETE_HOSTED_GAME,
    payload: res,
});

export const gameSoloGameSendStartData = (res) => async (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_SOLO_GAME_SEND_GAME_START_DATA,
        payload: res,
        globalState: getState(),
    });

    getMoveStrengthData(getState());
};

export const gameLiveGameOnlinePlayerListSortCriteriaChanged = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED,
    payload: res,
});

export const gameSoloGameCurrentHintData = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_GAME_CURRENT_HINT_DATA,
    payload: res,
});

export const gameAnalyseDataReady = (res) => ({
    type: ActionIdentifiers.GAME_ANALYSE_DATA_READY,
    payload: res,
});

export const gameAnalyseCurrentPositionChanged = (res) => ({
    type: ActionIdentifiers.GAME_ANALYSE_CURRENT_POSITION_CHANGED,
    payload: res,
});

export const gameHintWordListReady = (res) => ({
    type: ActionIdentifiers.GAME_HINT_WORD_LIST_READY,
    payload: res,
});

export const gameEmailGameSetNotesStarted = () => ({
    type: ActionIdentifiers.GAME_SET_NOTES_STARTED,
});

export const gameEmailGameSetNotesFailed = (res) => ({
    type: ActionIdentifiers.GAME_SET_NOTES_FAILED,
    payload: res,
});

export const gameLiveGameUserStatsFetched = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_USER_STATS_FETCHED,
    payload: res,
});

export const gameLiveGameHostParamsSet = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_HOST_PARAMS_SET,
    payload: res,
});

export const gameSideLayoutActiveTabSet = (res) => ({
    type: ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
    payload: res,
});

export const gameNormalGamePlayOptionsShowRobotsSet = (res) => ({
    type: ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET,
    payload: res,
});

export const gameNormalGamePlayOptionsShowSetGameList = (res) => ({
    type: ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_GAME_LIST,
    payload: res,
});

export const gameNormalGamePlayOptionsShowSetMobileGameList = (res) => ({
    type: ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST,
    payload: res,
});

export const gameLiveGameRestartDataSet = (res) => ({
    type: ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_GAME_RESTART_DATA_SET,
    payload: res,
});

export const gameLiveGameSSensorListRetrieved = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_GAME_SENSOR_LIST_RETRIEVED,
    payload: res,
});

export const gameLiveBuddyReqListRetrieved = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_BUDDY_REQ_LIST_RETRIEVED,
        payload: res,
        globalState: getState(),
    });
};

export const gameLiveGameBuddyList = (res) => (dispatch, getState) => {
    batch(() => {
        dispatch({
            type: ActionIdentifiers.GAME_LIVE_GAME_BUDDY_LIST,
            payload: res,
            globalState: getState(),
        });
        let online = get(res, 'online') || [];
        (get(res, 'buddies') || []).map((buddy) => {
            if (online.includes(buddy.guid)) {
                dispatch(lobbyChatMessage(getPlayerOnlineMessageObj(buddy)));
            }
        });
    });
};

export const gameSoloSetNoLoginData = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SET_NO_LOGIN_DATA,
    payload: res,
});

export const gamePageVisibilityChanged = (res) => ({
    type: ActionIdentifiers.GAME_PAGE_VISIBILITY_CHANGED,
    payload: res,
});

export const gameSetPlayerSelfCurrentScore = (res) => ({
    type: ActionIdentifiers.GAME_SET_PLAYER_SELF_CURRENT_SCORE,
    payload: res,
});

export const gameChallengeGameSetPreviousTurn = (res) => ({
    type: ActionIdentifiers.GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
    payload: res,
});

export const gameReducerUpdateTiles = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.GAME_REDUCER_UPDATE_TILES,
        payload: res,
        globalState: getState(),
    });

export const reloadApp = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.RELOAD_APP,
        payload: { ...res, globalState: getState() },
    });

export const gamePlayButtonShowLoader = (res) => ({
    type: ActionIdentifiers.GAME_SHOW_PLAY_BUTTON_LOADER,
    payload: res,
});

export const gamePlayButtonSetScoreText = (res) => ({
    type: ActionIdentifiers.GAME_PLAY_BUTTON_SCORE_TEXT,
    payload: res,
});

export const gameTileBeingDragged = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.GAME_TILE_BEING_DRAGGED,
        payload: res,
        globalState: getState(),
    });

export const gameBoardPuzzleReceived = (res) => ({
    type: ActionIdentifiers.GAME_BOARD_PUZZLE_RECEIVED,
    payload: res,
});

export const gameInitialiseTilesForCreateBoard = (res) => ({
    type: ActionIdentifiers.GAME_INITIALISE_TILES_FOR_CREATE_BOARD,
    payload: res,
});

export const gameLivePageVisibilityChange = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_PAGE_VISIBILITY_CHANGE,
    payload: res,
});

export const gameLiveLanguageChange = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_LANGUAGE_CHANGE,
    payload: res,
});

export const gameMoveCountSet = (res) => ({
    type: ActionIdentifiers.GAME_MOVE_COUNT_SET,
    payload: res,
});

export const updateTilesAndCells = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.UPDATE_TILES_AND_SET_CELL,
        payload: res,
        globalState: getState(),
    });
    let tile = get(res, 'tile');
    let cell = get(res, 'cell');
    if (tile && cell && tile.isBlankTile && !tile.currentLetter)
        eventBus.emit(Config.DISPLAY_LETTER_PICKER, null, { tile, cell });
    clearDirectionDelay();
};

export const reducerOnTileRemoved = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.REDUCER_ON_TILE_REMOVED,
        payload: res,
        globalState: getState(),
    });
};

export const gameReducerUpdateGametype = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE,
        payload: res,
        globalState: getState(),
    });
};

export const gameReducerUnserGameRestartData = (res) => ({
    type: ActionIdentifiers.GAME_REDUCER_UNSET_GAME_RESTART_DATA,
    payload: res,
});

export const joinHostedGame = (res) => (dispatch, getState) => {
    batch(() => {
        dispatch({
            type: ActionIdentifiers.GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
            payload: res,
        });
        dispatch({
            type: ActionIdentifiers.PLAYER_LIST_CHANGE_PLAYER_STATUS_JOINED,
            payload: res,
            globalState: getState(),
        });
    });
};

export const hostJoinedPlayerStats = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_HOST_JOINED_PLAYER_STATS,
    payload: res,
});

export const hostJoinDialog = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_HOST_JOIN_DIALOG,
    payload: res,
});

export const addHostGameHeadToHeadStat = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS,
    payload: res,
});

export const addHostGameUniqueWordCount = (res) => ({
    type: ActionIdentifiers.GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT,
    payload: res,
});

export const addHostGameRatingChange = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_HOST_ADD_RATING_CHANGE,
        payload: res,
        globalState: getState(),
    });
};

export const reqJoinHostGame = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME,
        payload: res,
        globalState: getState(),
    });
};

export const reqJoinHostGameReject = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT,
        payload: res,
        globalState: getState(),
    });
};

export const tileReducerSetHoveringTile = (res) => ({
    type: ActionIdentifiers.TILE_REDUCER_SET_HOVERING_CELL,
    payload: res,
});

export const gameReducerSetMoveStrength = (res) => ({
    type: ActionIdentifiers.GAME_REDUCER_SET_MOVE_STRENGTH,
    payload: res,
});

export const gameSideLayoutActiveTabReset = (res) => ({
    type: ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET,
    payload: res,
});

export const gameBlitzJndPlysUpdate = (res) => ({
    type: ActionIdentifiers.GAME_BLITZ_JNDPLYS_UPDATE,
    payload: res,
});

export const gameBlitzJndPlyRemove = (res) => (dispatch, getState) => {
    dispatch({
        type: ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE,
        payload: res,
        globalState: getState(),
    });
};

export const gameBlitzInpGameOver = (res) => (dispatch, getState) => {
    if (get(res, 'data.gid') === get(getState(), 'game.gid')) {
        dispatch(gameOver(res));
    } else {
        batch(() => {
            dispatch({
                type: ActionIdentifiers.GAME_BLITZ_INP_GAMEOVER,
                payload: res,
                globalState: getState(),
            });

            dispatch(gameLiveObservableGameRemove(res));
        });
    }
};

export const setEmailData = (data: boolean): ActionGLAdEvent => {
    return {
        type: ActionIdentifiers.SET_EMAIL_GAME_DATA,
        payload: data,
    };
};
