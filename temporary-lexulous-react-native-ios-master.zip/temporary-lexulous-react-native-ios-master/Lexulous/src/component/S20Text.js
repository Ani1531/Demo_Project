import React from 'react';
import { Text } from 'react-native';
import omit from 'lodash/omit';

export default class S20Text extends React.Component {
    render = () => (
        <Text
            {...omit(this.props, 'style')}
            style={[{ fontSize: 20 }, this.props.style]}
        />
    );
}
