// @flow

import dataServer from '../store/Store';

import { actionUpdateGGLLgnInfo } from '../userprofile/PFLAction';
import LgnMgr from './LgnMgr';
import { handleException } from './RJUtils';

class GGLgnMgr extends LgnMgr {
    _userInfo: any; //?User = null;  // chnage for React native web
    _error: ?string = null;
    _hasPlayServices = false;
    type = 'GGLgnMgr';

    constructor() {
        super();
        this._userInfo = null;
        this._error = null;
    }

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        try {
            this._userInfo = null;
            this._error = null;

            let delpendingassoc = await this.deletePendingAssociation();
            if (onCompletion) {
                onCompletion();
            }
            dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(null));
        } catch (error) {
            console.error(error);
            handleException(error);
        }
    };

    isUserLoggedIn(): boolean {
        let loggedin: boolean = this._userInfo !== null && this._userInfo !== undefined;
        return loggedin;
    }

    hasPlayServices = (): boolean => {
        return this._hasPlayServices;
    };

    doGoogleLogin = async (onCompletion: ?() => void): Promise<void> => {};

    checkLoginSilentMode = async (): Promise<void> => {};
}

const gglLgnMgr: GGLgnMgr = new GGLgnMgr();
export default gglLgnMgr;
