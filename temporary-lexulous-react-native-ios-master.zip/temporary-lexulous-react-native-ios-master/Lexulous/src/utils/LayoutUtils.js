import DimensionUtils from './DimensionUtils';
import ColorConfig from '../configs/ColorConfig';
import ConfigurationWrapper from './ConfigurationWrapper';
import store from '../store';
import get from 'lodash/get';

export default class LayoutUtils {
    static isMobile = () =>
        !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'isMobile'
        );

    static getToolTipContainerStyle = () => ({
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        zIndex: 1000,
        backgroundColor: '#404040ea',
        padding: 8,
        borderRadius: 5,
    });

    /* Alert dialog style start */
    static getDialogActionButtonStyle = (rematchTimer = false) => ({
        backgroundColor: rematchTimer
            ? 'rgb(0, 130, 34)'
            : DimensionUtils.isNative()
            ? ColorConfig.NATIVE_BUTTON_BACKGROUND_BLUE_COLOR
            : ColorConfig.ALERT_BUTTON_BACKGROUND_COLOR,
        color: ColorConfig.ALERT_BUTTON_TEXT_COLOR,
        paddingLeft: 16,
        paddingRight: 16,
        height: 36,
        marginLeft: 16,
        minWidth: 80,
        paddingBottom: 1,
    });
    static getDialogSecondActionButtonStyle = () => ({
        backgroundColor: '#FFF',
        color: ColorConfig.ALERT_OTHER_BUTTON_TEXT_COLOR,
        paddingLeft: 16,
        paddingRight: 16,
        // marginTop: DimensionUtils.isMobile() ? 16 : undefined,
        marginBottom: DimensionUtils.isMobile() ? 16 : undefined,
        height: 36,
        marginLeft: 16,
        minWidth: 80,
        paddingBottom: 1,
    });
    static getDialogThirdActionButtonStyle = () => ({
        backgroundColor: '#FFF',
        color: ColorConfig.ALERT_OTHER_BUTTON_TEXT_COLOR,
        paddingLeft: 16,
        paddingRight: 16,
        marginTop: DimensionUtils.isMobile() ? 16 : undefined,
        marginBottom: DimensionUtils.isMobile() ? 16 : undefined,
        height: 36,
        marginLeft: 16,
        minWidth: 80,
        paddingBottom: 1,
    });
    static getDialogCloseButtonBGStyle = () => ({
        borderRadius: DimensionUtils.isMobile() ? 40 : '50px',
        height: DimensionUtils.isMobile() ? 30 : '40px',
        width: DimensionUtils.isMobile() ? 30 : '40px',
        alignItems: 'center',
        justifyContent: 'center',
        /*position: 'absolute',
        right: 20,
        top: 24,*/
    });

    static getScoreTimerMainContainerDimension = () => ({
        width: get(store.getState(), 'layout.layoutBoardWidth'),
    });

    static getPanelFontSize = () => ({
        fontSize:
            LayoutUtils.getScoreTimerMainContainerDimension().width * 0.035,
    });

    static getPanelStatsSmallerThanToolTipFontSize = () => ({
        fontSize: LayoutUtils.getPanelFontSize().fontSize * 0.8,
    });

    static getDialogMainContainerStyle = () => ({
        flexDirection: 'column',
        width: '100%',
        backgroundColor: ColorConfig.MAIN_CONTAINER_BACKGROUND_COLOR,
        alignSelf: 'center',
        borderRadius: 4,
        borderWidth: 0,
        boxShadow:
            '0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2)',
    });
    static getDialogTitleContainerStyle = () => ({
        paddingLeft: DimensionUtils.isMobile() ? 16 : 32,
        paddingTop: DimensionUtils.isMobile() ? 16 : 32,
        paddingRight: DimensionUtils.isMobile() ? 16 : 32,
        paddingBottom: DimensionUtils.isMobile() ? 8 : 16,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
    });
    static getDialogTitleStyle = () => ({
        ...(DimensionUtils.isMobile() ? { fontSize: 18 } : {}),
        color: ColorConfig.DIALOG_MODAL_HEADING_TEXT_COLOR,
        //cursor: 'default',
    });
    static getDialogBodyContainerStyle = () => ({
        //width: 'calc(100%-64)',
        paddingLeft: DimensionUtils.isMobile() ? 16 : 32,
        paddingRight: DimensionUtils.isMobile() ? 16 : 32,
    });
    static getDialogBodyBtnContainerStyle = () => ({
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingLeft: DimensionUtils.isMobile() ? 16 : 32,
        paddingRight: DimensionUtils.isMobile() ? 16 : 32,
        paddingTop: 16,
        paddingBottom: DimensionUtils.isMobile() ? 16 : 32,
    });

    static getDialogBodyTextStyle = () => ({
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    });
    /* Alert dialog style end*/

    /* Menu style start */
    static getMenuMainContainerStyle = () => ({
        backgroundColor: '#f4f3ef',
        minWidth: '156px',
        paddingTop: 4,
        borderWidth: 0,
    });
    static getMenuItemStyle = () => ({
        minHeight: 30,
        borderBottomWidth: 1,
        paddingLeft: 16,
        paddingRight: 16,
        alignItems: 'flex-start',
        justifyContent: 'center',
    });
    static getMenuTextStyle = () => ({
        cursor: 'pointer',
        fontFamily: 'Product Sans',
    });
    static getCursorPointerStyle = () => ({
        cursor: 'pointer',
    });
    static getBottonStyle = () => ({
        alignItems: 'center',
        justifyContent: 'center',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        borderRadius: 5,
        elevation: 5,
    });
    static getBottonTextStyle = () => ({
        color: ColorConfig.ALERT_BUTTON_TEXT_COLOR,
        fontWeight: '500',
    });
    static getBottonTextBlueStyle = () => ({
        color: DimensionUtils.isNative()
            ? ColorConfig.NATIVE_BUTTON_BACKGROUND_BLUE_COLOR
            : ColorConfig.ALERT_OTHER_BUTTON_TEXT_COLOR,
        fontWeight: '500',
    });
    static getCursorDefaultStyle = () => ({
        //cursor: 'default',
    });

    static getLoaderTextColorStyle = () => ({
        color: get(store.getState(), 'config.isDarkMode')
            ? ColorConfig.WHITE
            : ColorConfig.BLACK,
    });
}
