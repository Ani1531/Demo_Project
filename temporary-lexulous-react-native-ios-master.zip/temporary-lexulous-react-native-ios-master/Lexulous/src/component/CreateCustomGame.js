import { StyleSheet, View, Pressable } from 'react-native';
import React from 'react';
import LayoutUtils from '../utils/LayoutUtils';
import CustomBoard from './CustomBoard';
import get from 'lodash/get';
import store from '../store';
import { connect } from 'react-redux';
import Config from '../configs/Config';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';

const eventBus = require('js-event-bus')();

class CreateCustomGame extends React.Component {
    state = {
        key: Math.random(),
    };

    constructor(props) {
        super(props);
    }

    onTimeSelect = (value) => this.setState({ time: value });
    onRobotLevelSelect = (value) => this.setState({ level: value });
    onDictionarySelect = (value) => this.setState({ dictionary: value });

    onPrevious = () => {
        eventBus.emit(Config.CUSTOM_BOARD_NEXT_OPTION, null, -1);
    };

    onNext = () => {
        eventBus.emit(Config.CUSTOM_BOARD_NEXT_OPTION, null, 1);
    };

    getContainerStyle = () => ({
        flex: 1,
        overflow: 'hidden',
    });

    getSoloCreateCustomGameDialogBodyBtnContainerStyle = () => ({
        ...LayoutUtils.getDialogBodyBtnContainerStyle(),
        paddingRight: Config.RIGHT_LEFT_MARGIN,
        height: this.props.layout.layoutRackContainerHeight,
        width: '100%',
        alignSelf: 'flex-end',
    });

    render = () => (
        <View style={this.getContainerStyle()}>
            <View style={styles.flex}>
                <View>
                    <CustomBoard
                        id={'board'}
                        key={'board'}
                        {...this.getBoardDimension()}
                        previousAction={this.props.onCancel}
                        nextAction={this.props.onActionButton}
                    />
                </View>

                <View
                    style={[
                        this.getSoloCreateCustomGameDialogBodyBtnContainerStyle(),
                    ]}
                >
                    <Pressable
                        style={[
                            LayoutUtils.getDialogSecondActionButtonStyle(),
                            LayoutUtils.getBottonStyle(),
                        ]}
                        onPress={this.onPrevious}
                    >
                        <S14Text style={LayoutUtils.getBottonTextBlueStyle()}>
                            {'Go back'}
                        </S14Text>
                    </Pressable>
                    <Pressable
                        style={[
                            LayoutUtils.getDialogActionButtonStyle(),
                            LayoutUtils.getBottonStyle(),
                        ]}
                        onPress={this.onNext}
                    >
                        <S14Text style={LayoutUtils.getBottonTextStyle()}>
                            {'Next'}
                        </S14Text>
                    </Pressable>
                </View>
            </View>
        </View>
    );

    getBoardDimension = () => {
        let boardDimenWidth = get(store.getState(), 'layout.boardWidthDimen');
        return {
            top: 0,
            left: 0,
            height: boardDimenWidth,
            width: boardDimenWidth,
        };
    };
}

const styles = StyleSheet.create({
    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    flex: { flex: 1 },
    alignItemEnd: { alignItems: 'flex-end' },
    flexDirection: { flexDirection: 'row' },
});

const mapStateToProps = (state) => ({
    layout: {
        layoutRackContainerHeight: state.layout.layoutRackContainerHeight,
    },
});

export default connect(mapStateToProps)(CreateCustomGame);
