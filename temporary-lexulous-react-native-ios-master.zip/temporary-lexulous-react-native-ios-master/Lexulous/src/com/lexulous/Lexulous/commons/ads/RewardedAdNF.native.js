// @flow

import AppLovinMAX from 'react-native-applovin-max';
import { kRewardedNFInterStitialAdUnit } from '../Constants';
import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class RewardedAdNF {
    retryAttempt = 0;
    onCompletion: (boolean) => void = (shown: boolean) => {};
    constructor() {}
    onAppInit = (): void => {
        AppLovinMAX.addEventListener('OnRewardedAdLoadedEvent', () => {
            this.retryAttempt = 0;
        });
        AppLovinMAX.addEventListener('OnRewardedAdLoadFailedEvent', () => {
            this.retryAttempt = this.retryAttempt + 1;
            var retryDelay = Math.pow(2, Math.min(5, this.retryAttempt));
            setTimeout(function () {
                AppLovinMAX.loadRewardedAd(kRewardedNFInterStitialAdUnit);
            }, retryDelay * 1000);
        });
        AppLovinMAX.addEventListener('OnRewardedAdClickedEvent', () => {});
        AppLovinMAX.addEventListener('OnRewardedAdDisplayedEvent', () => {});
        AppLovinMAX.addEventListener('OnRewardedAdFailedToDisplayEvent', () => {
            AppLovinMAX.loadRewardedAd(kRewardedNFInterStitialAdUnit);
            this.onAdCompletion(true);
        });
        AppLovinMAX.addEventListener('OnRewardedAdHiddenEvent', () => {
            AppLovinMAX.loadRewardedAd(kRewardedNFInterStitialAdUnit);
            this.onAdCompletion(true);
        });
        AppLovinMAX.addEventListener('OnRewardedAdReceivedRewardEvent', () => {
            AppLovinMAX.loadRewardedAd(kRewardedNFInterStitialAdUnit);
            this.onAdCompletion(true);
        });
        AppLovinMAX.loadRewardedAd(kRewardedNFInterStitialAdUnit);
    };

    showRewardedNFInterstitialAd = (onCompletion: (boolean) => void): void => {
        this.onCompletion = onCompletion;
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            this.onAdCompletion(false);
            return;
        }
        if (AppLovinMAX.isRewardedAdReady(kRewardedNFInterStitialAdUnit)) {
            AppLovinMAX.showRewardedAd(kRewardedNFInterStitialAdUnit, null, null);
        } else {
            this.onAdCompletion(false);
        }
    };

    canShowRewardedNFInterstitial = (): boolean => {
        return AppLovinMAX.isRewardedAdReady(kRewardedNFInterStitialAdUnit);
    };

    onAdCompletion = (shown: boolean) => {
        let temp = this.onCompletion;
        this.onCompletion = (shown: boolean) => {};
        if (temp) {
            temp(shown);
        }
    };
}

const rewardedAdNF: RewardedAdNF = new RewardedAdNF();

export default rewardedAdNF;
