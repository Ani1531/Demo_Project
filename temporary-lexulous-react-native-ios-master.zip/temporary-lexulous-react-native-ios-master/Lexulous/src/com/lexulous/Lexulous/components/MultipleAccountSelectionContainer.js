// @flow

import React from 'react';
import { StyleSheet, Text, View, Image, Pressable } from 'react-native';
import { avtarIcons } from '../commons/Constants';
import { translate } from '../commons/translations/LangTransator';
import type { authRespData } from '../legacy/LegacyCoordinator';
import i18n from 'i18n-js';
import themeConfigutation from '../commons/ThemeConfiguration';

type MultipleAccountSelectionContainerProps = {
    AccountData: Array<AccountInfo>,
    didSelectedAccount: (authRespData) => void,
};

type AccountInfo = {
    avtar: string,
    username: string,
    accinfo: authRespData,
    activegames: string,
};

class MultipleAccountSelectionContainer extends React.Component<MultipleAccountSelectionContainerProps> {
    renderAccountDetails = (accinfo: AccountInfo, index: number) => (
        <View style={styles.detailsFeildsStyle} key={index}>
            <Image source={avtarIcons[accinfo.avtar]} style={[styles.avatarFieldStyle]} />
            <View style={styles.eachDetailFeild}>
                <View style={styles.eachDetailStyle}>
                    <Text
                        style={[
                            styles.detailsTextstyle,
                            { flex: 1, flexWrap: 'wrap', color: themeConfigutation.getColor('#000') },
                        ]}
                    >
                        {accinfo.username}
                    </Text>
                </View>
                <View style={styles.eachDetailStyle}>
                    <Text
                        style={[
                            styles.detailsTextstyle,
                            { flex: 1, flexWrap: 'wrap', color: themeConfigutation.getColor('#000') },
                        ]}
                    >
                        {i18n.t('actv_games', {
                            cnt: accinfo.activegames,
                        })}
                    </Text>
                </View>
            </View>
            <Pressable onPress={() => this.props.didSelectedAccount(accinfo.accinfo)} style={[styles.seletBtnStyle]}>
                <Text style={{ fontSize: 12, color: 'white' }}>SELECT </Text>
            </Pressable>
        </View>
    );

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.mainContainer,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Text style={[styles.PopupHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('Multiple_accnts_fnd')}
                    </Text>
                    <View style={styles.bodyStyle}>
                        <Text style={[styles.bodyHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                            {translate('Multiple_accnts_fnd_msg')}
                        </Text>
                        {this.props.AccountData.map((element, index) => this.renderAccountDetails(element, index))}
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    mainContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 12,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        width: '95%',
        maxWidth: 320,
    },
    bodyStyle: { marginBottom: 20 },
    detailsFeildsStyle: {
        flexDirection: 'row',
        marginTop: 8,
        paddingBottom: 4,
        alignItems: 'center',
    },
    avatarFieldStyle: {
        width: 50,
        height: 50,
    },
    eachDetailFeild: {
        marginVertical: 4,
        marginHorizontal: 16,
        flexGrow: 1,
    },
    eachDetailStyle: { flexDirection: 'row', marginBottom: 2 },
    detailsTextstyle: { fontSize: 12, color: 'black' },
    PopupHeaderStyle: {
        textAlign: 'center',
        fontSize: 20,
        paddingHorizontal: 16,
        marginBottom: 8,
        marginTop: 18,
    },
    bodyHeaderStyle: {
        textAlign: 'center',
        fontSize: 14,
        paddingHorizontal: 16,
        marginBottom: 8,
    },
    seletBtnStyle: {
        maxWidth: 90,
        minWidth: 25,
        maxHeight: 30,
        minHeight: 25,
        width: 70,
        height: 25,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        backgroundColor: '#00a6f0',
    },
});

export default MultipleAccountSelectionContainer;
