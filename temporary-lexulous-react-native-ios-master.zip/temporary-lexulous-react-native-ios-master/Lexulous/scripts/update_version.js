const SHORTVERSION = 'shortVersion';
const VERSION = 'version';

module.exports = () => {
    //load .env data to array
    const fs = require('fs');
    const env_array = fs.readFileSync('./.env', 'utf-8').split('\n');

    //calculate SHORTVERSION and VERSION
    var short_version = env_array.find((key) => key.includes(SHORTVERSION)).split('=')[1];
    var version = env_array.find((key) => key.includes(VERSION)).split('=')[1];

    //load package.json file in object format
    const package_json = JSON.parse(fs.readFileSync('./package.json', 'utf-8'));

    //package version updated here
    package_json.build.mac.bundleVersion = version;
    package_json.build.mac.bundleShortVersion = short_version;

    //write package.json file
    fs.writeFileSync('package.json', JSON.stringify(package_json, null, 4));
};
