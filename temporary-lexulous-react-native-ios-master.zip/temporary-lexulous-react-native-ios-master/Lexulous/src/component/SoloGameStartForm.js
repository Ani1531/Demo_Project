import { StyleSheet, View, TouchableOpacity, Text, TextInput, ScrollView, Pressable } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import React from 'react';
import DimensionUtils from '../utils/DimensionUtils';
import LayoutUtils from '../utils/LayoutUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { faPlay, faPencilAlt } from '@fortawesome/free-solid-svg-icons';
import Config from '../configs/Config';
import { createDialogInstance } from '../utils/MessageUtils';
import { getNull } from '../utils/Utils';
import { connect } from 'react-redux';
import { GAME_SOLO_SET_FORM_DATA } from '../configs/ActionIdentifiers';
import TooltipWrapper from './TooltipWrapper';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import PText from './PText';
import S14Text from './S14Text';
import S22Text from './S22Text';
import SelectOption from '../component/SelectOption';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

const eventBus = require('js-event-bus')();

function bindFunction() {
    this.bindRequest(this.params);
}

class SoloGameStartForm extends React.Component {
    state = {
        key: Math.random(),
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        showTooltip: false,
        hoverDicEffect: false,
        hoverTimeEffect: !this.props.isRobot ? true : false,
        hoverRobotEffect: false,
    };

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    componentDidUpdate() {
        TooltipActionWrapper.rebuild();
    }

    shouldComponentUpdate = (nextState) => !isEqual(get(this.state, 'showTooltip'), get(nextState, 'showTooltip'));

    onTimeSelect = (value) =>
        eventBus.emit(GAME_SOLO_SET_FORM_DATA, null, {
            time: value,
        });
    onRobotLevelSelect = (value) =>
        eventBus.emit(GAME_SOLO_SET_FORM_DATA, null, {
            level: value,
        });
    onDictionarySelect = (value) =>
        eventBus.emit(GAME_SOLO_SET_FORM_DATA, null, {
            dictionary: value,
        });

    onStartGame = () => {
        this.props.onActionButton && this.props.onActionButton();
    };

    onCancel = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.props.onCancel();
    };

    onHoverDismissButton = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    whenNotHoverDismissButton = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getDialogDismissButtonBackgroundColor = () => ({
        backgroundColor: this.state.closeBGColor,
    });

    onDicHoverInOut = () => {
        this.setState({ hoverDicEffect: !this.state.hoverDicEffect });
    };
    onTimeInOut = () => {
        this.setState({ hoverTimeEffect: !this.state.hoverTimeEffect });
    };
    onRobotInOut = () => {
        this.setState({ hoverRobotEffect: !this.state.hoverRobotEffect });
    };

    getHoverInStyle = () => ({
        border: 0,
        borderBottomStyle: 'solid',
        borderWidth: '2.5px',
        fontSize: '100%',
    });
    getHoverOutStyle = () => ({
        border: 0,
        borderBottomStyle: 'ridge',
        borderWidth: '3px',
        fontSize: '100%',
    });

    render = () => (
        <View style={styles.flex}>
            <View style={LayoutUtils.getDialogTitleContainerStyle()}>
                <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                    {this.props.savedRules
                        ? this.props.slotData && this.props.slotData.type === Config.SOLO_SLOT_SAVE
                            ? 'Select One Slot'
                            : 'Load Saved Rules'
                        : 'Game Options'}
                </S22Text>
                <TouchableOpacity
                    onMouseEnter={this.onHoverDismissButton}
                    onMouseLeave={this.whenNotHoverDismissButton}
                    style={[styles.dismissButtonInnerStyle]}
                    onPress={this.onCancel}
                >
                    <View style={[this.getDialogDismissButtonBackgroundColor(), LayoutUtils.getDialogCloseButtonBGStyle()]}>
                        <FontAwesomeIcon
                            icon={faTimes}
                            size={DimensionUtils.isMobile() ? 20 : 24}
                            style={this.getCloseButtonStyle()}
                        />
                    </View>
                </TouchableOpacity>
            </View>
            {this.props.savedRules ? this.renderBoardSlot() : this.renderGameForm()}
        </View>
    );

    renderGameForm = () => {
        return (
            <View style={styles.flex}>
                <View style={LayoutUtils.getDialogBodyContainerStyle()}>
                    <View style={styles.flexDirectionColumn}>
                        <View style={styles.pickerContainerStyle}>
                            <View onMouseEnter={this.onDicHoverInOut} onMouseLeave={this.onDicHoverInOut}>
                                <PText style={styles.numberStepperLabel}>Dictionary</PText>
                                <SelectOption
                                    style={this.state.hoverDicEffect ? this.getHoverInStyle() : this.getHoverOutStyle()}
                                    type={Config.SELECT_OPTION_TYPES.dictionary}
                                    selectedValue={this.props.dictionary}
                                    onSelectChange={this.onDictionarySelect}
                                />
                            </View>
                        </View>
                        <View style={styles.pickersDividerStyle} />
                        {!this.props.isRobot ? null : (
                            <View style={styles.pickerContainerStyle}>
                                <View onMouseEnter={this.onRobotInOut} onMouseLeave={this.onRobotInOut}>
                                    <TooltipWrapper
                                        tooltip={'Robot Move level'}
                                        onMouseEnter={this.showTooltip}
                                        onMouseOut={this.hideTooltip}
                                    >
                                        <PText style={styles.numberStepperLabel}>Robot Level</PText>
                                    </TooltipWrapper>
                                    <SelectOption
                                        style={this.state.hoverRobotEffect ? this.getHoverInStyle() : this.getHoverOutStyle()}
                                        type={Config.SELECT_OPTION_TYPES.robotLevel}
                                        selectedValue={this.props.level}
                                        onSelectChange={this.onRobotLevelSelect}
                                    />
                                </View>
                            </View>
                        )}
                        <View style={styles.pickersDividerStyle} />

                        <View style={styles.pickerContainerStyle}>
                            <View onMouseEnter={this.onTimeInOut} onMouseLeave={this.onTimeInOut}>
                                <TooltipWrapper
                                    tooltip={'Total time each game'}
                                    onMouseEnter={this.showTooltip}
                                    onMouseOut={this.hideTooltip}
                                >
                                    <PText style={styles.numberStepperLabel}>Time</PText>
                                </TooltipWrapper>
                                <SelectOption
                                    style={this.state.hoverTimeEffect ? this.getHoverInStyle() : this.getHoverOutStyle()}
                                    type={Config.SELECT_OPTION_TYPES.timeRobot}
                                    selectedValue={this.props.time}
                                    onSelectChange={this.onTimeSelect}
                                />
                            </View>
                        </View>
                        <View style={styles.pickersDividerStyle} />
                    </View>
                </View>

                <View
                    style={[
                        LayoutUtils.getDialogBodyBtnContainerStyle(),
                        styles.flex,
                        styles.alignItemEnd,
                        DimensionUtils.isMobile() ? styles.buttonContainerMobileOverride : undefined,
                    ]}
                >
                    <Pressable
                        style={[LayoutUtils.getDialogSecondActionButtonStyle(), LayoutUtils.getBottonStyle()]}
                        onPress={this.onCancel}
                    >
                        <S14Text style={LayoutUtils.getBottonTextBlueStyle()}>{'GO BACK'}</S14Text>
                    </Pressable>

                    <Pressable
                        style={[LayoutUtils.getDialogActionButtonStyle(), LayoutUtils.getBottonStyle()]}
                        onPress={this.onStartGame}
                    >
                        <S14Text style={LayoutUtils.getBottonTextStyle()}>{'NEXT'}</S14Text>
                    </Pressable>
                </View>
            </View>
        );
    };

    slotNameChangeDialog = (obj) => {
        this.setState({ slotName: obj.slotName, slotId: obj.slotIndex });
        createDialogInstance({
            title: obj.slotSaveIndex === obj.slotIndex ? 'Save Board' : obj.slotId ? 'Overwrite Slot' : 'Cannot save slot',
            actionButtonText: 'Ok',
            onAction: obj.slotSaveIndex === obj.slotIndex || obj.slotId ? this.getSlotNameChangeAction : getNull,
            body:
                obj.slotSaveIndex === obj.slotIndex || obj.slotId
                    ? this.getSlotNameChangeDialogBody(obj)
                    : 'Please, try saving board to slot: ' + obj.slotSaveIndex,
        });
    };

    getSlotNameChangeAction = () => {
        if (this.state.slotName && this.state.slotName.length > 0) {
            this.props.onActionButton &&
                this.props.onActionButton({
                    slotId: this.state.slotId,
                    slotName: this.state.slotName,
                });
        }
    };

    getSlotNameChangeDialogBody = (obj) => (
        <View>
            <S14Text>{obj.slotId ? 'Do you want to overwrite slot?' : 'Please, enter slot name'}</S14Text>
            <TextInput
                style={styles.slotNameTextInput}
                defaultValue={obj.slotId ? obj.slotName : ''}
                onChangeText={this.onSlotNameChange}
                autoFocus={true}
                maxLength={10}
                autoComplete={'off'}
                autoCompleteType={'off'}
            />
        </View>
    );

    onSlotNameChange = (text) => {
        this.setState({ slotName: text });
    };

    renderBoardSlot = () => {
        return (
            <View style={[styles.flex, styles.slotContainer]}>
                <ScrollView>
                    {this.props.slotData && this.props.slotData.boardSlot && this.props.slotData.boardSlot.length > 0 ? (
                        this.props.slotData.boardSlot.map((obj, index) => {
                            obj.slotIndex = index + 1;
                            return (
                                <TouchableOpacity
                                    style={styles.slotRow}
                                    activeOpacity={this.props.slotData.type === Config.SOLO_SLOT_SAVE ? 0.5 : 1}
                                    onPress={
                                        this.props.slotData.type === Config.SOLO_SLOT_SAVE
                                            ? bindFunction.bind({
                                                  params: obj,
                                                  bindRequest: this.slotNameChangeDialog,
                                              })
                                            : null
                                    }
                                >
                                    <S14Text style={styles.bodyText}>{index + 1 + '. ' + obj.slotName}</S14Text>
                                    {this.props.slotData.type === Config.SOLO_SLOT_PLAY_EDIT ? (
                                        <View style={styles.slotActionContainer}>
                                            <View style={styles.slotActionButtonContainer}>
                                                <TouchableOpacity
                                                    onPress={bindFunction.bind({
                                                        params: {
                                                            slotId: obj.slotId,
                                                            type: Config.SOLO_SLOT_PLAY_BUTTON,
                                                        },
                                                        bindRequest: this.props.onActionButton,
                                                    })}
                                                >
                                                    <FontAwesomeIcon
                                                        icon={faPlay}
                                                        size={14}
                                                        style={this.getSlotActionPlayStyle()}
                                                    />
                                                </TouchableOpacity>
                                                <TouchableOpacity
                                                    style={styles.slotActionButton}
                                                    onPress={bindFunction.bind({
                                                        params: {
                                                            slotId: obj.slotId,
                                                            type: Config.SOLO_SLOT_EDIT_BUTTON,
                                                        },
                                                        bindRequest: this.props.onActionButton,
                                                    })}
                                                >
                                                    <FontAwesomeIcon
                                                        icon={faPencilAlt}
                                                        size={14}
                                                        style={this.getSlotActionPlayStyle()}
                                                    />
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                    ) : null}
                                </TouchableOpacity>
                            );
                        })
                    ) : (
                        <S14Text style={styles.bodyText}>
                            {this.props.slotData !== undefined ? 'There has no saved rules.' : 'Loading...'}
                        </S14Text>
                    )}
                </ScrollView>
            </View>
        );
    };

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    getSlotActionPlayStyle = () => ({
        fontSize: 12,
    });
}
const mapStateToProps = (state) => ({
    isRobot: state.solitaire.isRobot,
    dictionary: state.solitaire.dictionary,
    level: state.solitaire.level,
    time: state.solitaire.time,
    slotData: state.solitaire.slotData,
});
export default connect(mapStateToProps)(SoloGameStartForm);

const styles = StyleSheet.create({
    rowDirection: {
        flexDirection: 'row',
    },
    pickerContainerStyle: { flex: 1 },
    pickersDividerStyle: { width: 10 },
    widthHundred: {
        width: '100%',
    },
    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    dismissButtonInnerStyle: { flex: 1, alignItems: 'flex-end' },
    flexDirectionColumn: { flexDirection: 'column' },
    flex: { flex: 1 },
    alignItemEnd: { alignItems: 'flex-end' },
    slotContainer: {
        paddingLeft: 32,
        paddingRight: 32,
        paddingBottom: 32,
    },
    slotRow: {
        flexDirection: 'row',
        marginBottom: 4,
    },
    slotActionContainer: {
        flex: 1,
        justifyContent: 'center',
    },
    slotActionButtonContainer: {
        alignSelf: 'flex-end',
        flexDirection: 'row',
    },
    slotActionButton: {
        marginLeft: 8,
    },
    slotNameTextInput: {
        height: 25,
        borderWidth: StyleSheet.hairlineWidth,
        marginTop: 4,
    },
    robotLevelTimeStyle: {
        color: 'rgba(0, 0, 0, 0.54)',
    },
    numberStepperLabel: {
        color: ColorConfig.NEW_HOST_GAMES_RATING_LABEL_COLOR,
        paddingBottom: 10,
    },
});
