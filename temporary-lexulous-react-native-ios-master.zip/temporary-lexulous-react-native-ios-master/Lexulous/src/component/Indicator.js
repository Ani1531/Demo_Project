import get from 'lodash/get';
import React from 'react';
import { Text, StyleSheet, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import { getDictionaryDetails } from '../utils/GameBoardUtils';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import TooltipWrapper from './TooltipWrapper';
import isEqual from 'lodash/isEqual';
import S8Text from './S8Text';
import S10Text from './S10Text';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

export default class Indicator extends React.Component {
    state = {
        showTooltip: false,
    };

    shouldComponentUpdate = (nextState) =>
        !isEqual(get(this.state, 'showTooltip'), get(nextState, 'showTooltip'));

    componentDidMount = () => {
        TooltipActionWrapper.rebuild();
    };

    getDictionaryIndicatorBackground = (dictionaryCode) => {
        switch (getDictionaryDetails(dictionaryCode).indicator) {
            case 'S':
                return { backgroundColor: '#45ad7d' };
            case 'T':
                return { backgroundColor: '#a00be0' };
            case 'F':
                return { backgroundColor: '#f1b06f' };
            case 'I':
                return { backgroundColor: '#f1b06f' };
            default:
                throw new Error('Invalid Dictionary Code');
        }
    };

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    renderDictionaryIndicator = () => (
        <TooltipWrapper
            key={'DictionaryIndicator'}
            tooltip={getDictionaryDetails(this.props.dictionary).explanation}
        >
            <S8Text
                style={[
                    styles.dictionaryIndicatorTextColor,
                    styles.indicatorBoxStyle,
                    this.getDictionaryIndicatorBackground(
                        this.props.dictionary
                    ),
                ]}
            >
                {getDictionaryDetails(this.props.dictionary).indicator}
            </S8Text>
        </TooltipWrapper>
    );

    renderRatedIndicator = () =>
        this.props.isRated ? null : (
            <TooltipWrapper
                key={'RatedIndicator'}
                tooltip={this.props.isRated ? 'Rated' : 'Unrated'}
            >
                <S8Text
                    style={[
                        styles.ratedSmallIndicatorTextColor,
                        styles.indicatorBoxStyle,
                        styles.ratedIndicatorContainer,
                    ]}
                >
                    {this.props.isRated ? 'R' : 'U'}
                </S8Text>
            </TooltipWrapper>
        );

    renderChallengeIndicator = () => (
        <TooltipWrapper
            key={'ChallengeIndicator'}
            tooltip={this.props.isChallengeGame ? 'Challenge' : 'Regular'}
        >
            <S8Text
                style={[
                    styles.ratedSmallIndicatorTextColor,
                    styles.indicatorBoxStyle,
                    styles.challengeIndicatorContainer,
                ]}
            >
                {this.props.isChallengeGame ? 'C' : 'R'}
            </S8Text>
        </TooltipWrapper>
    );

    renderNumberOfPlayersIndicator = () =>
        Number(this.props.numberOfPlayers) >= 3 ? (
            <TooltipWrapper
                key={'NumberOfPlayersIndicator'}
                tooltip={this.props.numberOfPlayers + ' player game'}
            >
                <S8Text
                    style={[
                        styles.ratedSmallIndicatorTextColor,
                        styles.indicatorBoxStyle,
                        styles.numberOfPlayerIndicatorContainer,
                    ]}
                >
                    {this.props.numberOfPlayers}
                </S8Text>
            </TooltipWrapper>
        ) : null;

    renderTimeIndicator = () => (
        <TooltipWrapper
            key={'TimeIndicator'}
            tooltip={LiveGamePlayUtils.getTimeControlData({
                time: Number(get(this.props.time, 'duration') / 60),
                increment: get(this.props.time, 'increament'),
                separator: ',<br/>',
            })}
            multiline={true}
        >
            <S10Text
                style={[
                    styles.timeControlTextColor,
                    styles.timerControlContainer,
                ]}
            >
                {Math.floor(Number(get(this.props.time, 'duration')) / 60) +
                    '/' +
                    get(this.props.time, 'increament')}
            </S10Text>
        </TooltipWrapper>
    );

    render = () => (
        <View
            key={'indicator_container'}
            style={styles.indicatorRowStyle}
            onMouseEnter={this.showTooltip}
            onMouseLeave={this.hideTooltip}
        >
            {this.renderNumberOfPlayersIndicator()}
            <View
                key={'NumberOfPlayersIndicatorDivider'}
                style={styles.inputLabelDivider}
            />
            {this.props.isChallengeGame
                ? [
                      this.renderChallengeIndicator(),
                      <View
                          key={'ChallengeIndicatorDivider'}
                          style={styles.inputLabelDivider}
                      />,
                  ]
                : null}
            {!this.props.observe && [
                this.renderRatedIndicator(),
                <View
                    key={'RatedIndicatorDivider'}
                    style={styles.inputLabelDivider}
                />,
            ]}
            {this.renderDictionaryIndicator()}
            <View
                key={'DictionaryIndicatorDivider'}
                style={styles.inputLabelDivider}
            />
            {this.renderTimeIndicator()}
            <View
                key={'TimeIndicatorDivider'}
                style={styles.inputLabelDivider}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    inputLabelDivider: {
        height: 0,
        width: 5,
    },
    indicatorRowStyle: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 5,
    },
    indicatorBoxStyle: {
        flexDirection: 'column',
        width: 10,
        height: 10,
        textAlign: 'center',
    },

    //rated indicator styles
    ratedSmallIndicatorTextColor: {
        color: ColorConfig.RATED_INDICATOR_TEXT_COLOR,
    },
    ratedIndicatorContainer: {
        backgroundColor:
            ColorConfig.ACCEPT_HOSTED_LIST_ITEM__TIMED_INDICATOR_COLOR,
    },
    //
    challengeIndicatorContainer: {
        backgroundColor:
            ColorConfig.ACCEPT_HOSTED_LIST_ITEM__CHALLENGE_INDICATOR_COLOR,
    },
    //dictionary indicator styles
    dictionaryIndicatorTextColor: {
        color: ColorConfig.DICTIONARY_INDICATOR_TEXT_COLOR,
    },
    //

    //time indicator styles
    timeControlTextColor: {
        color: ColorConfig.TIME_CONTROL_TEXT_COLOR,
    },
    timerControlContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        paddingRight: 4,
        width: 40,
    },
    //

    //number of players indicator styles
    numberOfPlayerIndicatorContainer: {
        backgroundColor: '#008080',
    },
    //
});
