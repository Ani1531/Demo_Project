// @flow

export const LRN_UPDT_UNAME: string = 'LRN_UPDT_UNAME';
export const LRN_UPDT_EMAIL: string = 'LRN_UPDT_EMAIL';
export const LRN_UPDT_LGN_INFO: string = 'LRN_UPDT_LGN_INFO';
export const LRN_CLR_DATA: string = 'LRN_CLR_DATA';
