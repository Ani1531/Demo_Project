// @flow

import React from 'react';
import { StyleSheet, Text, View, Dimensions, Pressable, FlatList, Linking, Platform } from 'react-native';
import type { NewsFeedType } from '../commons/RJTypes';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type NewsFeedProps = {
    newsFeed: Array<NewsFeedType>,
};

type NewsFeedState = {
    dim: any,
};

class NewsFeedView extends React.Component<NewsFeedProps, NewsFeedState> {
    unsubscribeDimensionListener: ?() => void = null;

    constructor(props: NewsFeedProps) {
        super(props);
        this.state = {
            dim: Dimensions.get('window'),
        };
    }

    componentDidMount() {
        this.unsubscribeDimensionListener = Dimensions.addEventListener('change', this.onChange);
    }

    onChange = (evt: any) => {
        this.setState({ dim: evt.window });
    };

    componentWillUnmount() {
        if (this.unsubscribeDimensionListener) {
            this.unsubscribeDimensionListener();
        }
    }

    goToURL = (url: string) => {
        if (url != '') {
            Linking.openURL(url);
        }
    };

    renderNewsFeedItem = ({ item }: { item: NewsFeedType }) => {
        let renderNewsFeedForNative = () => {
            let url = item.url ?? '';
            return (
                <Pressable
                    onPress={() => {
                        rjAnalytics.sendAnalyticsEvent('news_feed_opened', 'gl_container');
                        this.goToURL(url);
                    }}
                    style={[
                        styles.newsFeedItemStyle,
                        { width: this.state.dim.width, backgroundColor: themeConfigutation.getColor('#f4f3ef') },
                    ]}
                >
                    <View style={{ marginVertical: 8 }}>
                        <Text
                            style={{ fontWeight: 'bold', fontSize: 14, color: themeConfigutation.getColor('#000') }}
                            numberOfLines={1}
                        >
                            {item.title}
                        </Text>
                        <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }} numberOfLines={3}>
                            {item.msg}
                        </Text>
                    </View>
                </Pressable>
            );
        };

        let renderNewsFeedForWeb = () => {
            return (
                <View
                    style={[
                        styles.newsFeedItemStyle,
                        {
                            width: this.state.dim.width,
                            marginVertical: 8,
                            backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                        },
                    ]}
                >
                    <div
                        style={{ fontFamily: 'Arial', color: themeConfigutation.getColor('#000') }}
                        dangerouslySetInnerHTML={{ __html: item.msg }}
                    />
                </View>
            );
        };

        return Platform.select({
            native: renderNewsFeedForNative(),
            default: renderNewsFeedForWeb(),
        });
    };

    render() {
        if (this.props.newsFeed.length > 0) {
            return (
                <View style={{ width: this.state.dim.width }}>
                    <FlatList
                        data={this.props.newsFeed}
                        renderItem={this.renderNewsFeedItem}
                        keyExtractor={(item, index) => index.toString()}
                        horizontal
                        pagingEnabled={true}
                        showsHorizontalScrollIndicator={true}
                        persistentScrollbar={true}
                    />
                </View>
            );
        }
        return null;
    }
}

const styles = StyleSheet.create({
    newsFeedItemStyle: {
        paddingHorizontal: 10,
        paddingVertical: 8,
        flexDirection: 'column',
    },
});

export default NewsFeedView;
