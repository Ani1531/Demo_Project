// @flow

import { UPDT_SETTINGS, CLR_PROFILE } from './PFLEventTypes';

import type { ActionProfileSettings, userSettings } from '../commons/RJTypes';

const INITIAL_STATE = {
    us_email: {
        em_gamestarted: 'n',
        em_myturn: 'y',
        em_chat: 'y',
        em_gamecompleted: 'y',
        em_dailydigest: 'y',
        em_recnudgerequest: 'y',
        em_enableautologinlinks: 'y',
    },
    us_pushntf: {
        ntf_gamestarted: 'y',
        ntf_myturn: 'y',
        ntf_chat: 'y',
        ntf_gamecompleted: 'y',
        ntf_dailydigest: 'y',
        ntf_recnudgerequest: 'y',
    },
    us_gameplay: {
        gp_magictiles: 'y',
        gp_moveconfirmation: 'n',
        gp_numbrdboard: 'y',
        gp_gamesounds: 'y',
        gp_autozoomboard: 'y',
        gp_gametheme: '1-0',
        gp_homepage: 'email',
        gp_homecountry: 'KH',
        gp_darktheme: 'n',
        gp_scoregraph: 'y',
        gp_showtooltip: 'y',
        gp_chtfntsze: '16',
        gp_showforum: 'y',
    },
    us_privacy: {
        pvc_showonlinestatus: 'y',
        pvc_showprostatus: 'n',
        pvc_disablechat: 'n',
        pvc_sgstplys: 'y',
        pvc_showlbycht: 'y',
        pvc_showlbygmupdt: 'y',
    },
    us_gamestart: {
        gs_showinit: 'n',
        gs_prefdic: 'sow',
        gs_ratingrange: '600-4200',
        gs_boardtype: 'N',
        gs_gametype: 'ER',
        gs_speed: '5',
        gs_maxreq: '5',
        gs_numplayers: '2',
        gs_rated: 'n',
        gs_lvduration: '420',
        gs_lvincrmnt: '10',
    },
    us_prouser: {
        pro_till: '0',
        anlz_till: '0',
    },
    us_purchases: {},
};

export default function PFLSettingsReducer(state: userSettings = INITIAL_STATE, action: ActionProfileSettings) {
    switch (action.type) {
        case UPDT_SETTINGS: {
            return {
                ...state,
                ...action.payload,
            };
        }
        case CLR_PROFILE: {
            return INITIAL_STATE;
        }
        default:
            return state;
    }
}
