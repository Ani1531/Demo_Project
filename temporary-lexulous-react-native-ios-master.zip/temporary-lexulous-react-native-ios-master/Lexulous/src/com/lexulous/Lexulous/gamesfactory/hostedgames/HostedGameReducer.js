// @flow

import type { HostedGameElement, HostedGameActions, ActionHostedGameType, HostedGames } from '../../commons/RJTypes';
import { RESET_HOSTED_GAMES } from './HostedGameEvents';

const hglinistate = {
    hostedGames: [
        {
            title: 'hosted_game',
            data: [],
        },
    ],
};

export default function HostedGameReducer(state: HostedGames = hglinistate, taction: HostedGameActions) {
    switch (taction.type) {
        case RESET_HOSTED_GAMES: {
            let action = ((taction: any): ActionHostedGameType);
            let myguid = action.guid;

            let hostedGameList = action.payload.filter((item) => item.uid.guid != myguid);
            let myHostedGame = action.payload.filter((item) => item.uid.guid == myguid);
            if (myHostedGame.length > 0) {
                hostedGameList.unshift(myHostedGame[0]);
            }

            let newstate: HostedGames = {
                hostedGames: [
                    {
                        title: 'hosted_game',
                        data: hostedGameList,
                    },
                ],
            };
            return newstate;
        }
        default:
            return state;
    }
}
