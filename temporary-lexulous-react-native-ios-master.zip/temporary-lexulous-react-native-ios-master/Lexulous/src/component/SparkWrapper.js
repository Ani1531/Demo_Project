import React from 'react';

export default class SparkWrapper extends React.PureComponent {
    render = () => null;
}
