// @flow
import type { ActionAppUtils, ActionUpdateUtils, AppUtilsTypes } from '../commons/RJTypes';
import { UPDATE_COLOR_SCHEME } from '../commons/Constants';

const AppUtilsInitState: AppUtilsTypes = {
    colorScheme: 'light',
};

export default function UtilsReducer(state: AppUtilsTypes = AppUtilsInitState, action: ActionAppUtils) {
    switch (action.type) {
        case UPDATE_COLOR_SCHEME: {
            let mdfdaction = ((action: any): ActionUpdateUtils);
            let payload = ((mdfdaction.payload: any): AppUtilsTypes);
            return { ...state, ...payload };
        }
        default: {
            return state;
        }
    }
}
