import get from 'lodash/get';
import invoke from 'lodash/invoke';
import Queue from 'queue';
import { generateUUID } from './StringUtils';
import Timeout from 'smart-timeout';
import ConfigurationWrapper from './ConfigurationWrapper';
import store from '../store';
import arrayMoveLib from 'array-move';
import isNumberLodash from 'lodash/isNumber';
import DimensionUtils from './DimensionUtils';
import ServiceWrapper from './ServiceWrapper';
import { faCat, faDog, faGhost, faPlus, faSmile } from '@fortawesome/free-solid-svg-icons';
import Config from '../configs/Config';
import { gameBoardDataExchanger } from './GameBoardDataExchange';

export class StatusCheckableTimeout {
    constructor(fn, interval) {
        this.id = generateUUID();
        this.fn = fn;
        Timeout.set(this.id, this.done, interval);
    }

    done = () => {
        this.fn && this.fn();
    };

    getCleared = () => {
        let res = !(Timeout.exists(this.id) && Timeout.pending(this.id) && this.getRemaining() > 0);

        return res;
    };

    getRemaining = () => Timeout.remaining(this.id);

    clear = () => Timeout.clear(this.id);
}

export const is2dArray = (array) => array.every((item) => Array.isArray(item));

export const getNull = () => null;

export const invokeGlobalMethod = (methodName, paramsArr) => {
    if (
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(methodName) &&
        get(window, ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(methodName))
    ) {
        invoke(
            window,
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(methodName),
            ...(ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(paramsArr) || [])
        );
        return true;
    }
    return false;
};

export const findAndRemove = (arr, findPredicate) => {
    let index = arr.findIndex(findPredicate);
    index >= 0 && arr.splice(index, 1);
};

export const queueWithPromisifiedPush = (params = { concurrency: 1, autostart: true }) => {
    let queue = new Queue(params);
    queue.promisifiedPush = (job) =>
        new Promise((accept, reject) => {
            let acceptCallback = (result, jobCB) => {
                if (job === jobCB) {
                    accept(result);
                    clearListeners();
                }
            };
            let errorCallback = (err, jobCB) => {
                if (job === jobCB) {
                    reject(err);
                    clearListeners();
                }
            };
            let clearListeners = () => {
                queue.removeListener('success', acceptCallback);
                queue.removeListener('error', errorCallback);
            };
            queue.on('success', acceptCallback);
            queue.on('error', errorCallback);
            queue.push(job);
        });
    return queue;
};

export const getEventKeyCode = (event) => get(event, 'code') || get(event, 'key') || get(event, 'nativeEvent.key') || '';

export const isOnline = () => {
    let globalState = store.getState();
    let isConnected = get(globalState, 'config.isConnected');
    return isConnected;
};

export const formatToTwoDigits = (value) => ('0' + value).slice(-2);

export const getMinutesFromSeconds = (data) => Math.floor(data / 60);

export const arrayMove = (arr, old_index, new_index) => {
    return arrayMoveLib.mutate(arr, old_index, new_index);
};

export const arraySwap = (arr, old_index, new_index) => {
    let temp = arr[old_index];
    arr[old_index] = arr[new_index];
    arr[new_index] = temp;
    return arr;
};

export const isNumber = (aNum) => isNumberLodash(aNum) && aNum !== null;

export const lastArrayElement = (arr) => {
    return arr.slice(-1)[0];
};

export const checkNativeGamelistUpdate = (result) => {
    //Native opponent move response apply
    if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
        let action = get(result, 'type') || get(result, 'action');
        let data = get(result, 'data.' + store.getState().game.channel) || get(result, 'data');
        let gid = get(result, 'gid');
        if (
            action === 'move' ||
            action === 'pass' ||
            action === 'swap' ||
            action === 'newgame' ||
            action === 'chat' ||
            action === 'delgame' ||
            action === 'resign' ||
            action === 'deletegame'
        ) {
            if (action === 'deletegame') {
                data = { ...data, gameover_reason: 'DELETE' };
            }
            if (
                (action === 'move' || action === 'pass' || action === 'swap') &&
                !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
            ) {
                ServiceWrapper.onBlindGameMove();
            }

            let isOwnMove = !!get(result, 'gid');

            if (
                (action === 'move' ||
                    action === 'pass' ||
                    action === 'swap' ||
                    action === 'resign' ||
                    action === 'deletegame') &&
                isOwnMove &&
                !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
            ) {
                let data = {
                    gid: gid,
                    action: action,
                };
                ServiceWrapper.notifyContextStore(data);
            }

            let updategameslist = !(isOwnMove && action === 'chat');

            if (updategameslist) {
                ServiceWrapper.nativeGameListUpdate({ data, gid });
            }
            if (!isOwnMove && !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isDesktopApp')) {
                desktopAppNotification(result);
            }
        }
    }
};

export const checkNativeGamelistUpdateViaBoardInfo = (result) => {
    //Native gameFeed
    const state = store.getState();
    let action = get(result, 'action');
    let data = get(result, 'data.' + state.game.channel);
    if (action === 'gamefeed') {
        let lastMoveData = data.boarddata.wordsplayed;
        let lastMove = lastMoveData.length > 0 ? lastMoveData[lastMoveData.length - 1][0] : '';

        let gameFdGlData = {
            gid: data.gid,
            startedon: data.starttime,
            lastupdate: data.lastupdate,
            turnpid: data.current_turn,
            dic: data.dic,
            mid: data.chat.length.toString(),
            gametype: data.gametype,
            boardtype: data.boardtype,
            lastmove: lastMove,
            tilesinbag: data.tilesinbag,
            players: data.players.map((item) => {
                return {
                    uid: item.guid,
                    pid: item.pid,
                    score: item.current_score,
                };
            }),
        };

        if (data.hasOwnProperty('gameover_reason')) {
            gameFdGlData = { ...gameFdGlData, ...{ gameover_reason: data.gameover_reason, winner: data.winner } };
        }

        let gameFdPlayerInfo = data.players;

        ServiceWrapper.nativeGameListUpdateViaBoardInfo({ gameFdGlData, gameFdPlayerInfo });

        //was a new game started by me or unplayed game started by me
        if (lastMove == '' && !data.hasOwnProperty('gameover_reason')) {
            let guid: string = state.game.guid;
            let me = gameFdGlData.players.find((element) => element.uid === guid);
            let ismyturn = false;
            let mypid = '1';
            if (me !== undefined && me !== null) {
                mypid = me.pid;
                ismyturn = mypid === gameFdGlData.turnpid;
                if (ismyturn) {
                    let plys = data.players
                        .map((p) => {
                            return p.lexcom;
                        })
                        .filter((m) => m !== undefined && m !== null);
                    let gdata = {
                        gid: data.gid,
                        players: plys,
                    };
                    ServiceWrapper.updateContextStore(gdata);
                }
            }
        }
    }
};

export const getBoardCenterIcon = () => {
    let boardCenterIcon = get(store.getState(), 'config.gp_brdcntrimg');
    switch (boardCenterIcon) {
        case Config.BOARD_CENTER_ICONS.ICON_CAT:
            return faCat;
        case Config.BOARD_CENTER_ICONS.ICON_DOG:
            return faDog;
        case Config.BOARD_CENTER_ICONS.ICON_GHOST:
            return faGhost;
        case Config.BOARD_CENTER_ICONS.ICON_PLUS:
            return faPlus;
        case Config.BOARD_CENTER_ICONS.ICON_SMILE:
            return faSmile;
        default:
            return faPlus;
    }
};

const desktopAppNotification = (result) => {
    let myGUID = store.getState().profile.guid;
    let myPID = result.data.players.filter((i) => i.guid == myGUID)[0].pid;
    let action = get(result, 'type') || get(result, 'action');
    let Ntf_Title = null;
    let Ntf_msg = null;

    let oponentName = result.data.players.filter((item) => {
        let lastTurnPid = 1;
        lastTurnPid = Number(result.data.current_turn) - 1;
        if (lastTurnPid == myPID) {
            lastTurnPid = lastTurnPid - 1;
        }
        if (lastTurnPid < 1) {
            lastTurnPid = result.data.players.length;
        }
        return item.pid == lastTurnPid.toString();
    })[0].name;

    if (action === 'move') {
        Ntf_Title = 'MOVE';
        Ntf_msg = `${oponentName} has played a move`;
    } else if (action === 'pass') {
        Ntf_Title = 'PASS';
        Ntf_msg = `${oponentName} has passed their turn`;
    } else if (action === 'swap') {
        Ntf_Title = 'SWAP';
        Ntf_msg = `${oponentName} has swapped tiles`;
    } else if (action === 'newgame') {
        Ntf_Title = 'NEW GAME';
        Ntf_msg = `${oponentName} has started a new game`;
    } else if (action === 'chat') {
        Ntf_Title = 'CHAT';
        Ntf_msg = `${oponentName} has sent you a message`;
    } else if (action === 'delgame') {
        Ntf_Title = 'DELETE GAME';
        Ntf_msg = `${oponentName} has deleted a game`;
    } else if (action === 'resign') {
        Ntf_Title = 'RESIGN GAME';
        Ntf_msg = `${oponentName} has resigned a game`;
    }

    if (Ntf_Title != null && Ntf_msg != null) {
        let notificationInfo = {
            title: Ntf_Title,
            message: Ntf_msg,
        };

        ServiceWrapper.showDesktopNotification(notificationInfo);
    }
};

export const getNativeWebGameType = () => gameBoardDataExchanger.gameBoardData?.game_type;
