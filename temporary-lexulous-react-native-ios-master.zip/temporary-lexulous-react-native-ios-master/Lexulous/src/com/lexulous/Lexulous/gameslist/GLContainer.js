// @flow

import React from 'react';
import { connect, batch } from 'react-redux';
import { bindActionCreators } from 'redux';
import { StyleSheet, Text, View, SectionList, AppState, Platform } from 'react-native';

import type { ServerResponse } from '../commons/RJTypes';

import GamesListElement from './GLTblVwElement';
import userDefault from '../commons/UserDefault';
import * as ProfileSelector from '../userprofile/PFLSelector';
import * as CONSTANTS from '../commons/Constants';
import * as GL_CONSTANTS from './GLConstants';
import { actionAddGames, glRefreshStarted, glRefreshFinished, glUpdateReviewShareData } from '../gameslist/GLAction';
import dataServer from '../store/Store';
import glApi from './GLApi';
import type {
    GamesListProps,
    GamesListState,
    GamesListResponse,
    ReviewShareUpdateData,
    GamesListItemData,
    GamesListGameData,
    ProfileInfo,
    PsistData,
    RequestData,
    NewsFeedResponse,
    AppUtilsTypes,
    SourceType,
    AlertBoxType,
} from '../commons/RJTypes';
import minStatsApi from '../stats/minimalstats/MinStatsApi';
import { actionSetBusy, actionSetIdle } from '../commons/RJTypes';
import type { NavigationProp } from '@react-navigation/native';
import loginCoordinator from '../commons/LoginCoordinator';
import fbLgnMgr from '../commons/FBLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import applLgnMgr from '../commons/ApplLgnMgr';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import netManager from '../commons/RJNetInfo';
import requestManager from '../commons/RequestManager';
import { translate } from '../commons/translations/LangTransator';
import fndApi from '../friends/FndApi';
import type { AxiosPromise, AxiosResponse } from 'axios';
import RNBootSplash from 'react-native-bootsplash';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import { setEmailData } from '../../../../actions/GameActions';
import WordValidityWebSocketProvider from '../../../../provider/WordValidityWebSocketProvider';
import InAppReview from 'react-native-in-app-review';
import pushNtfMgr from '../commons/PushNtfMgr';
import bannerAd from '../commons/ads/BannerAd';
import { handleException } from '../commons/RJUtils';
import inAppPurchases from '../commons/iap/InAppPurchases';
import NewsFeedView from '../components/NewFeedView';
import rjAnalytics from '../../../../RJAnalytics';
import appConfiguration from '../commons/AppConfiguration';
import themeConfigutation from '../commons/ThemeConfiguration';
import ServiceWrapper from '../../../../utils/ServiceWrapper';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import * as PFLSelector from '../userprofile/PFLSelector';

class GLContainer extends React.Component<
    { gamesList: GamesListProps, utils: AppUtilsTypes, navigation: NavigationProp },
    GamesListState
> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    appstate = 'inactive';
    sectionListWindowSize: number = CONSTANTS.SectionListWindowSize.For_Native;
    disableShareNReviewRow: boolean = false;

    constructor(props: { gamesList: GamesListProps, utils: AppUtilsTypes, navigation: NavigationProp }) {
        super(props);
        this.state = {
            isFocused: true,
            bannerHt: 0,
            newsFeed: [],
        };
    }

    componentDidMount() {
        if (Platform.OS === 'android' || Platform.OS === 'ios') {
            RNBootSplash.hide({ fade: true });
        } else {
            let source: string | null = appConfiguration.getApplicationSource();
            if (source != null) {
                if (source == CONSTANTS.kDeskTopApp || source == CONSTANTS.kFBInstantApp) {
                    this.sectionListWindowSize = CONSTANTS.SectionListWindowSize.For_Web;
                }
                if (source == CONSTANTS.kDeskTopApp) {
                    this.disableShareNReviewRow = true;
                }
            }
        }
        AppState.addEventListener('change', this.handleAppStateChange);
        this.handleAppStateChange('active');
        let showReviewShare = Platform.select({
            native: () => {
                setTimeout(() => {
                    this.doShowReviewInterface();
                    this.doShowShareInterface();
                }, 1000);
            },
            default: () => {
                setTimeout(() => {
                    this.doShowReviewInterface();
                    this.doShowShareInterface();
                }, 1000);
            },
        });
        showReviewShare();
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                bannerAd.showBannerAd(CONSTANTS.kTabBarHeight, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });

                userDefault.get(CONSTANTS.kStatsUpdate).then((lastsuccessfulltstmp) => {
                    if (lastsuccessfulltstmp != null && lastsuccessfulltstmp != undefined && lastsuccessfulltstmp != 0) {
                        let currentTimestampInSec = Math.floor(Date.now() / 1000);
                        let hasExpired: boolean =
                            currentTimestampInSec - Number(lastsuccessfulltstmp ?? 0) > CONSTANTS.kStatsUpdateDurationSec;
                        if (hasExpired) {
                            minStatsApi.getLoggedInUserStats();
                        }
                    } else {
                        minStatsApi.getLoggedInUserStats();
                    }
                });

                userDefault.get(CONSTANTS.kUpdateSettings).then((lastsuccessfulltstmp) => {
                    if (lastsuccessfulltstmp != null && lastsuccessfulltstmp != undefined && lastsuccessfulltstmp != 0) {
                        let currentTimestampInSec = Math.floor(Date.now() / 1000);
                        let hasExpired: boolean =
                            currentTimestampInSec - Number(lastsuccessfulltstmp ?? 0) > CONSTANTS.kUpdateSettingDurationSec;
                        if (hasExpired) {
                            requestManager.fetchUserSettings();
                        }
                    } else {
                        requestManager.fetchUserSettings();
                    }
                });
            }
        });

        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ isFocused: false });
            }
        });
        bannerAd.showBannerAd(CONSTANTS.kTabBarHeight, this.onBannerReceive, this.onBannerFail);
        let source: SourceType | null = appConfiguration.getApplicationSource();
        if (source != null && source == CONSTANTS.kDeskTopApp) {
            userDefault.get(CONSTANTS.kPsistNtfPermState).then((value) => {
                if (value == null || value == undefined) {
                    this.doTakeNotificationPermission();
                }
            });
        }
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        if (sguid != null && sguid != undefined && suuid != null && suuid != undefined) {
            const data: gameBoardDataExchng = {
                gid: '',
                pid: '',
                dic: '',
                boarddes: '',
                already_attempted: false,
                game_type: 'email',
                board_type: '',
                request_url_type: '',
                channel: '',
                guid: sguid,
                uuid: suuid,
                board_size: 0,
            };
            gameBoardDataExchanger.gameBoardData = data;
            dataServer.getStore().dispatch(setEmailData(data));
        }
    }

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        bannerAd.invalidateBanner();
        AppState.removeEventListener('change', this.handleAppStateChange);
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    handleAppStateChange = (nextAppState): void => {
        if (this.appstate.match(/inactive|background/) && nextAppState === 'active') {
            //APP SWITCHED TO FOREGROUND
            let showReviewShare = Platform.select({
                native: () => {
                    let alreadyshowing = this.props.gamesList.showshare == true;
                    if (alreadyshowing === false) {
                        this.doShowShareInterface();
                    }
                    this.doShowReviewInterface();
                },
                default: () => {
                    let alreadyshowing = this.props.gamesList.showshare == true;
                    if (alreadyshowing === false) {
                        this.doShowShareInterface();
                    }
                },
            });
            showReviewShare();

            WordValidityWebSocketProvider.getWebSocketConnection();
            pushNtfMgr.pinMayHaveExpired().then((pinhasexpired) => {
                pushNtfMgr.doUpdateDevicePin(pinhasexpired);
            });
            this.getNewsFeed();
        }
        if (/* this.appstate === 'active' && */ nextAppState.match(/inactive|background/)) {
            //APP SWITCHED TO BACKGROUND
            Platform.select({
                native: () => {
                    WordValidityWebSocketProvider.disconnect();
                },
                default: {},
            });
        }
        this.appstate = nextAppState;
    };

    handleTap = (game: GamesListItemData, onCompletion: () => void | null): void => {
        let type = game.type;
        if (type === 'game') {
            let gamedata: GamesListGameData = ((game.data: any): GamesListGameData);
            let boardType: string = gamedata.boardtype;
            let gid: string = gamedata.gid;
            let guid: string = CONSTANTS.Default_guid;
            let uuid: string = '';
            let dict: string = gamedata.dic;
            let profile: ProfileInfo = this.props.gamesList.profile;
            if (profile.guid !== undefined && profile.guid !== null) {
                guid = profile.guid;
            }
            if (profile.uuid !== undefined && profile.uuid !== null) {
                uuid = profile.uuid;
            }
            let me = gamedata.players.find((element) => element.uid === guid);
            let mypid = '1';
            if (me !== undefined && me !== null) {
                mypid = me.pid;
            }
            const gameBoardData: gameBoardDataExchng = {
                gid: gid,
                pid: mypid,
                dic: dict, //sow, fr, it
                boarddes: 'n',
                already_attempted: false,
                game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                board_type: boardType == CONSTANTS.Super ? CONSTANTS.server_S : CONSTANTS.server_N,
                //request_url_type: 'rest_api', //"rest_api",//"web_socket",
                //channel: CONSTANTS.kChannel,
                guid: guid,
                uuid: uuid,
                board_size: boardType == CONSTANTS.Super ? CONSTANTS.Board_sz_s : CONSTANTS.Board_sz_n,
            };
            gameBoardDataExchanger.gameBoardData = gameBoardData;
            dataServer.getStore().dispatch(setEmailData(gameBoardData));
            if (onCompletion != null && onCompletion != undefined) {
                onCompletion();
            }
            rjAnalytics.sendAnalyticsEvent('board_screen_opened', 'gl_container');
            this.props.navigation.navigate('BoardScreen');
        }
    };
    onImagePress = (guid: string) => {
        rjAnalytics.sendAnalyticsEvent('profile_stats_opened', 'gl_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + guid } });
    };
    renderItem = ({ item }) => {
        return <GamesListElement game={item} imageTapHandler={this.onImagePress} gameTapHandler={this.handleTap} />;
    };

    renderHeaderItem = ({ section: { title } }) => (
        <Text
            style={[
                styles.header,
                { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#000') },
            ]}
        >
            {title}
        </Text>
    );

    extractKey = (item) => item.key;

    renderGameList = () => {
        return (
            <SectionList
                sections={(this.props.gamesList.games: any)}
                contentContainerStyle={{ flexGrow: 1 }}
                renderItem={this.renderItem}
                keyExtractor={this.extractKey}
                renderSectionHeader={this.renderHeaderItem}
                ItemSeparatorComponent={separator}
                ListFooterComponent={separator}
                onRefresh={() => this.onRefresh()}
                refreshing={false}
                ListEmptyComponent={this.renderMsg}
                // initialNumToRender={10}
                // maxToRenderPerBatch={10}
                // updateCellsBatchingPeriod={50}
                windowSize={this.sectionListWindowSize}
                stickySectionHeadersEnabled
                style={{
                    flexGrow: 1,
                    backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                }}
            />
        );
    };

    getNewsFeed = () => {
        let news_feed_rsp: AxiosPromise<NewsFeedResponse> = requestManager.getNewsFeed(CONSTANTS.getOSPlatformString());
        news_feed_rsp
            .then((response: AxiosPromise<NewsFeedResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
            .then((response: NewsFeedResponse) => {
                if (response.check && response.check.toLowerCase() == CONSTANTS.kSuccess) {
                    this.setState({ newsFeed: response.data });
                }
            })
            .catch((error) => handleException(error));
    };

    renderNewsFeed = () => {
        if (this.state.newsFeed.length > 0) {
            return <NewsFeedView newsFeed={this.state.newsFeed} />;
        }
        return null;
    };

    renderMsg = () => {
        return (
            <View style={styles.msgStyle}>
                <Text style={{ color: themeConfigutation.getColor('#000') }}>{translate('no_Games_Msg')}</Text>
            </View>
        );
    };

    renderAdViewPlaceHolder = () => {
        return <View style={[{ backgroundColor: themeConfigutation.getColor('#f4f3ef') }, { height: this.state.bannerHt }]} />;
    };

    render() {
        return this.state.isFocused ? (
            <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {this.renderNewsFeed()}
                {this.renderGameList()}
                {this.renderAdViewPlaceHolder()}
            </View>
        ) : null;
    }

    onRefresh = () => {
        let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
        if ((sguid ?? 0) !== 0) {
            this.fetchGamesList();
        } else {
            loginCoordinator
                .fetchInitDataFromUserPrefs()
                .then((result) => {
                    this.fetchProfile(result);
                })
                .catch((err) => handleException(err));
        }
    };

    fetchProfile = (datastoreresponse: PsistData) => {
        let storedguid = datastoreresponse.guid;
        let storeduuid = datastoreresponse.uuid;
        if (storedguid && storeduuid) {
            let data: RequestData = {
                channel: CONSTANTS.kChannel,
                guid: storedguid,
                uuid: storeduuid ?? '',
            };
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let rsp: AxiosPromise<ServerResponse> = requestManager.getProfile(data);
                rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((result: ServerResponse) => {
                        if (storeduuid !== null && storeduuid !== undefined) {
                            requestManager.onProfileResponse(storedguid, storeduuid, result);
                        }
                        let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                        if ((sguid ?? 0) !== 0) {
                            requestManager.fetchUserSettings();
                            minStatsApi.getLoggedInUserStats();
                            fndApi.getFriendListCumulative(false);
                            this.fetchGamesList();
                            inAppPurchases.getPurchaseHistory();
                        }
                    })
                    .catch((error) => {
                        handleException(error);
                    })
                    .finally(() => {
                        dataServer.debouncedDispatch(actionSetIdle());
                    });
            }
            applLgnMgr.checkLoginSilentMode();
            fbLgnMgr.checkLoginSilentMode();
            lxlsLgnMgr.checkLoginSilentMode();
            gglLgnMgr.checkLoginSilentMode();
        }
    };

    fetchGamesList = () => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            dataServer.getStore().dispatch(glRefreshStarted());
            let promises: Array<AxiosPromise<ServerResponse>> = [];
            let p1: AxiosPromise<ServerResponse> = glApi.getActiveGamesList();
            promises.push(p1);
            let p2: AxiosPromise<ServerResponse> = glApi.getArchivedGamesList();
            promises.push(p2);
            Promise.all(promises)
                .then(async ([a, b]) => {
                    let a1: ServerResponse = await a.data;
                    let b1: ServerResponse = await b.data;
                    let activegamecnt: number = 0;
                    let archivegamecnt: number = 0;
                    let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
                    if (a1.check === CONSTANTS.kSuccess && b1.check === CONSTANTS.kSuccess) {
                        let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                        let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                        activegamecnt = a1respdata.games.length;
                        archivegamecnt = b1respdata.games.length;
                        batch(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            dataServer.getStore().dispatch(glRefreshFinished());
                            dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                            dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                        });
                    } else if (a1.check === CONSTANTS.kSuccess) {
                        let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                        activegamecnt = a1respdata.games.length;
                        batch(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            dataServer.getStore().dispatch(glRefreshFinished());
                            dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                        });
                    } else if (b1.check === CONSTANTS.kSuccess) {
                        let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                        archivegamecnt = b1respdata.games.length;
                        batch(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            dataServer.getStore().dispatch(glRefreshFinished());
                            dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                        });
                    } else {
                        batch(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            dataServer.getStore().dispatch(glRefreshFinished());
                        });
                    }
                    let gamecount = activegamecnt + archivegamecnt;
                    if (gamecount == 0) {
                        this.props.navigation.navigate('New Game');
                    }
                })
                .catch((e) => {
                    batch(() => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        dataServer.getStore().dispatch(glRefreshFinished());
                    });
                });
        }
    };

    onActiveGamesListResposeReceive = (response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let respdata: GamesListResponse = ((response.data: any): GamesListResponse);
            let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
            dataServer.getStore().dispatch(actionAddGames(respdata, profile));
        }
    };

    onArchiveGamesListResposeReceive = (response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let respdata: GamesListResponse = ((response.data: any): GamesListResponse);
            let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
            dataServer.getStore().dispatch(actionAddGames(respdata, profile));
        }
    };

    doShowShareInterface = () => {
        let reqdata = [CONSTANTS.kPsistShrTrgCnt, CONSTANTS.kPsistShrAtCnt];
        userDefault
            .getMultiple(reqdata)
            .then((result) => {
                let data = {};
                if (result != null) {
                    result.forEach((value, index) => {
                        if (value !== null && value !== undefined) {
                            data[reqdata[index]] = JSON.parse(JSON.stringify(value));
                        }
                    });
                }
                let appshrtriggercnt = data[CONSTANTS.kPsistShrTrgCnt];
                let appshratcnt = data[CONSTANTS.kPsistShrAtCnt];
                if (
                    appshrtriggercnt !== null &&
                    appshrtriggercnt !== undefined &&
                    appshratcnt !== null &&
                    appshratcnt !== undefined
                ) {
                    let tval = parseInt(appshrtriggercnt);
                    let pval = parseInt(appshratcnt);
                    if (tval == pval && !this.disableShareNReviewRow) {
                        let uu: ReviewShareUpdateData = {
                            type: 'share',
                            show: true,
                            reviewsharestate: GL_CONSTANTS.reviewShareStateType.ShareViewStateInited,
                        };
                        dataServer.getStore().dispatch(glUpdateReviewShareData(uu));
                        let pinApp = Platform.select({
                            native: () => {},
                            default: () => {
                                let pinapp: string | null = appConfiguration.getPinappPlugin();
                                if (pinapp != null) {
                                    console.log('will call Pin app');
                                    window[pinapp]();
                                } else {
                                    console.log('Pin app is null');
                                }
                            },
                        });
                        pinApp();
                    } else if (tval > pval) {
                        tval = 1;
                        userDefault.set(CONSTANTS.kPsistShrTrgCnt, JSON.stringify(tval));
                    } else {
                        tval = tval + 1;
                        userDefault.set(CONSTANTS.kPsistShrTrgCnt, JSON.stringify(tval));
                    }
                } else {
                    userDefault.set(CONSTANTS.kPsistShrTrgCnt, JSON.stringify(1));
                    userDefault.set(CONSTANTS.kPsistShrAtCnt, JSON.stringify(CONSTANTS.kInitialShareTrgCnt));
                }
            })
            .catch((error) => handleException(error));
    };

    doShowReviewInterface = () => {
        let reqdata = [CONSTANTS.kPsistRvwTrgCnt, CONSTANTS.kPsistRvwAtCnt];
        userDefault
            .getMultiple(reqdata)
            .then((result) => {
                let data = {};
                if (result != null) {
                    result.forEach((value, index) => {
                        if (value !== null && value !== undefined) {
                            data[reqdata[index]] = JSON.parse(JSON.stringify(value));
                        }
                    });
                }
                let appreviewtriggercnt = data[CONSTANTS.kPsistRvwTrgCnt];
                let appreviewatcnt = data[CONSTANTS.kPsistRvwAtCnt];
                if (
                    appreviewtriggercnt !== null &&
                    appreviewtriggercnt !== undefined &&
                    appreviewatcnt !== null &&
                    appreviewatcnt !== undefined
                ) {
                    let tval = parseInt(appreviewtriggercnt);
                    let pval = parseInt(appreviewatcnt);
                    if (tval == pval && !this.disableShareNReviewRow) {
                        this.doTriggerInAppReview();
                    } else if (tval > pval) {
                        tval = 1;
                        userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(tval));
                    } else {
                        tval = tval + 1;
                        userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(tval));
                    }
                } else {
                    userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(1));
                    userDefault.set(CONSTANTS.kPsistRvwAtCnt, JSON.stringify(CONSTANTS.kInitialRvwTrgCnt));
                }
            })
            .catch((error) => handleException(error));
    };

    doTriggerInAppReview = () => {
        //android version >= 21 and iOS >= 10.3
        if (InAppReview.isAvailable()) {
            InAppReview.RequestInAppReview()
                .then((hasFlowFinishedSuccessfully) => {
                    if (hasFlowFinishedSuccessfully) {
                        userDefault.set(CONSTANTS.kPsistRvwTrgCnt, JSON.stringify(1));
                        userDefault.set(CONSTANTS.kPsistRvwAtCnt, JSON.stringify(CONSTANTS.kExtendedRvwTrgCnt));
                    }
                })
                .catch((error) => {
                    handleException(error);
                });
        }
    };

    checkPendingAssociation = () => {
        let pendingassoc = userDefault.get(CONSTANTS.kPsistPendingAssociation);
        if (pendingassoc !== null && pendingassoc !== undefined) {
            //TO DO
            //USER INITIATED LOGIN PREFERRED
            userDefault.clear(CONSTANTS.kPsistPendingAssociation);
            switch (pendingassoc) {
                case 'GGLgnMgr': {
                    lxlsLgnMgr.deleteTempLoginData();
                    gglLgnMgr.doSignOut(null);
                    break;
                }
                case 'FBLgnMgr': {
                    fbLgnMgr.doSignOut(null);
                    break;
                }
                case 'ApplLgnMgr': {
                    lxlsLgnMgr.deleteTempLoginData();
                    applLgnMgr.doSignOut(null);
                    break;
                }
                case 'LXLSLgnMgr': {
                    lxlsLgnMgr.deleteTempLoginData();
                    lxlsLgnMgr.doSignOut(null);
                    break;
                }
            }
        }
    };

    doTakeNotificationPermission = () => {
        let alertBoxInfo: AlertBoxType = {
            message_icon: require('../assets/icons/badge.png'),
            message: translate('notif_perm'),
            actions: [
                {
                    text: translate('alert_no_button'),
                    action: () => {
                        userDefault.set(CONSTANTS.kPsistNtfPermState, CONSTANTS.PsistNtfPermState.Denied);
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
                {
                    text: translate('alert_yes_button'),
                    action: () => {
                        userDefault.set(CONSTANTS.kPsistNtfPermState, CONSTANTS.PsistNtfPermState.Shown);
                        ServiceWrapper.showDesktopNotification(null);
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };
}

const separator = () => {
    return <View style={styles.seperatorStyle} />;
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    header: {
        fontSize: 12,
        paddingLeft: 10,
        paddingTop: 4,
        paddingBottom: 4,
    },
    msgStyle: {
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    seperatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
});

function mapStateToProps(state) {
    const { gamesList, utils } = state;
    return { gamesList, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            glUpdateReviewShareData,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(GLContainer);
