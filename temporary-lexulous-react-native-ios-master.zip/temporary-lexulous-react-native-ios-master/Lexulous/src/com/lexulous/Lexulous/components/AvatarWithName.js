// @flow

import React from 'react';
import { StyleSheet, Text, ImageBackground } from 'react-native';
import type { AvatarWithNameData } from '../commons/RJTypes';

type AvatarWithNameProps = {
    data: AvatarWithNameData,
    showOppName: boolean,
};

class AvatarWithName extends React.Component<AvatarWithNameProps> {
    renderOpponentName = () => {
        if (this.props.showOppName) {
            return (
                <Text numberOfLines={1} style={styles.nameStyle}>
                    {this.props.data.imgtxt}
                </Text>
            );
        } else {
            return null;
        }
    };

    render() {
        return (
            <ImageBackground source={this.props.data.imgicon} style={styles.imageStyle}>
                {this.renderOpponentName()}
            </ImageBackground>
        );
    }
}

const styles = StyleSheet.create({
    nameStyle: {
        flex: 1,
        width: 28,
        height: 10,
        textAlign: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.54)',
        color: 'white',
        fontSize: 8,
    },
    imageStyle: {
        flex: 1,
        flexDirection: 'row',
        width: 28,
        height: 28,
        alignItems: 'flex-end',
        marginRight: 8,
    },
});

export default AvatarWithName;
