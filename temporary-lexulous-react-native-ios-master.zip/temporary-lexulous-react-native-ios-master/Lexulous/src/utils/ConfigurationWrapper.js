import { getNull } from './Utils';
import NativeGameConfig from '../configs/NativeGameConfig';

export default class ConfigurationWrapper {
    /* static getLexulousGameConfigTooltipMargin = getNull;

    static getSpecificLexulousGameConfiguration = getNull;

    static getLexulousGameConfiguration = getNull;

    static getLexulousGeneralConfiguration = getNull; */

    static getSpecificLexulousGameConfiguration = (field) =>
        NativeGameConfig.__lexulous_game_configuration__[field];

    static getSpecificLexulousGeneralConfiguration = (field) =>
        NativeGameConfig.__lexulous_general_configuration__[field];

    static getLexulousGameConfiguration = () =>
        NativeGameConfig.__lexulous_game_configuration__;

    static getLexulousGeneralConfiguration = () =>
        NativeGameConfig.__lexulous_general_configuration__;
}
