import React from 'react';
import { TouchableOpacity } from 'react-native';

export default class TooltipWrapper extends React.PureComponent {
    constructor(props) {
        super(props);
        this.tooltipRef = React.createRef();
    }

    componentDidUpdate = () => {
        this.tooltipRef.current.setNativeProps({
            'data-for': this.props.expTooltip ? 'expTooltip' : 'appTooltip',
            'data-tip': this.props.tooltip ? this.props.tooltip : '',
            'data-multiline': this.props.multiline,
        });
    };

    render() {
        return (
            <TouchableOpacity
                activeOpacity={1}
                ref={this.tooltipRef}
                {...this.props}
            >
                {this.props.children}
            </TouchableOpacity>
        );
    }
}
