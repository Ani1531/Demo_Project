#!/bin/node

//usage
//node scripts/set-environment.js ios|android|fbinstant|mac|url dev|prod
const fs = require('fs');
const platform = process.argv[2];
const buildtype = process.argv[3];
let envfile = platform + '_' + buildtype;
let apiendpoints = 'url_' + buildtype;
const envcontent = fs.readFileSync(`./environments/${envfile}.env`, 'utf8');
const apicontent = fs.readFileSync(`./environments/${apiendpoints}.env`, 'utf8');
let envfilecontent = envcontent + '\n' + apicontent;
fs.writeFileSync('.env', envfilecontent);
//=============== start google config =================================
if (platform == 'android' || platform == 'ios') {
    let googleConfigContent = fs.readFileSync(`./environments/google_service_${envfile}.env`, 'utf8');
    if (platform == 'android') {
        fs.writeFileSync('./android/app/google-services.json', googleConfigContent);
    } else if (platform == 'ios') {
        fs.writeFileSync('./ios/GoogleService-Info.plist', googleConfigContent);
    }
    let gameConfigContent = fs.readFileSync(`./environments/NativeGameConfig_${buildtype}.env`, 'utf8');
    fs.writeFileSync('./src/configs/NativeGameConfig.js', gameConfigContent);
}
//=============== end google config =================================
//=============== start Index.html  =================================
if (platform == 'fbinstant') {
    let indexContent = fs.readFileSync(`./environments/index_${envfile}.env`, 'utf8');
    fs.writeFileSync('index.html', indexContent);
} else if (platform == 'mac' || platform == 'win') {
    let indexContent = fs.readFileSync(`./environments/index_${buildtype}.env`, 'utf8');
    fs.writeFileSync('index.html', indexContent);

    //update version in package.json file
    const updateVersion = require('./update_version');
    updateVersion();
}
//=============== end Index.html =================================
