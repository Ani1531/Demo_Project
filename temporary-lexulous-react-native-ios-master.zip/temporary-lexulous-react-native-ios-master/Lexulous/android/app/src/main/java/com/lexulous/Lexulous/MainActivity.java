package com.lexulous.Lexulous;

import com.facebook.react.ReactActivity;
//Begin added for splash screen
import com.zoontek.rnbootsplash.RNBootSplash;
import android.os.Bundle;
//end added for splash screen

public class MainActivity extends ReactActivity {

  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  @Override
  protected String getMainComponentName() {
    return "Lexulous";
  }

  //Begin added for splash screen
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState); // or super.onCreate(null) with react-native-screens
    RNBootSplash.init(R.drawable.splash_screen, MainActivity.this); // display the generated bootsplash.xml drawable over our MainActivity
  }
  //end added for splash screen
}
