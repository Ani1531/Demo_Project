//@flow
export type gameBoardDataExchng = {
    gid: string,
    pid: string,
    dic: string, //sow, fr, it
    boarddes: string,
    already_attempted: boolean,
    game_type: string, //"email",//"live_room","puzzle","solo", "blitz"
    board_type: string,
    //request_url_type: string, //"rest_api",//"web_socket",
    //channel: string,
    guid: string,
    uuid: string,
    board_size: number,
    isBlindGame?: boolean,
    onBlindGameMove?: () => void,
    updateContextStore?: ({ gid: string, players: Array<string> }) => void,
    notifyFBContext?: ({ gid: string, action: string }) => void,
};

class GameBoardDataExchanger {
    _gameBoardData: ?gameBoardDataExchng = null;
    constructor() {
        this._gameBoardData = null;
    }
    get gameBoardData() {
        return this._gameBoardData;
    }
    set gameBoardData(value: gameBoardDataExchng) {
        this._gameBoardData = value;
    }
}

export const gameBoardDataExchanger = new GameBoardDataExchanger();
