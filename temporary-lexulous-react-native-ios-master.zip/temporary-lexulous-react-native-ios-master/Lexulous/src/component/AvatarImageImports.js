import React from 'react';
import { Image } from 'react-native';
import a1 from '../assets/avatars/1.png';
import a2 from '../assets/avatars/2.png';
import a3 from '../assets/avatars/3.png';
import a4 from '../assets/avatars/4.png';
import a5 from '../assets/avatars/5.png';
import a6 from '../assets/avatars/6.png';
import a7 from '../assets/avatars/7.png';
import a8 from '../assets/avatars/8.png';
import a9 from '../assets/avatars/9.png';
import a10 from '../assets/avatars/10.png';
import a11 from '../assets/avatars/11.png';
import a12 from '../assets/avatars/12.png';
import a13 from '../assets/avatars/13.png';
import a14 from '../assets/avatars/14.png';
import a15 from '../assets/avatars/15.png';
import a16 from '../assets/avatars/16.png';
import a17 from '../assets/avatars/17.png';
import a18 from '../assets/avatars/18.png';
import a19 from '../assets/avatars/19.png';
import a20 from '../assets/avatars/20.png';
import a21 from '../assets/avatars/21.png';
import a22 from '../assets/avatars/22.png';
import a23 from '../assets/avatars/23.png';
import a24 from '../assets/avatars/24.png';
import a25 from '../assets/avatars/25.png';
import a26 from '../assets/avatars/26.png';
import a27 from '../assets/avatars/27.png';
import a28 from '../assets/avatars/28.png';
import a29 from '../assets/avatars/29.png';
import a30 from '../assets/avatars/30.png';
import a31 from '../assets/avatars/31.png';
import a32 from '../assets/avatars/32.png';
import a33 from '../assets/avatars/33.png';
import a34 from '../assets/avatars/34.png';
import a35 from '../assets/avatars/35.png';
import a36 from '../assets/avatars/36.png';
import a37 from '../assets/avatars/37.png';
import a38 from '../assets/avatars/38.png';
import a39 from '../assets/avatars/39.png';
import a40 from '../assets/avatars/40.png';
import a41 from '../assets/avatars/41.png';
import a42 from '../assets/avatars/42.png';
import a43 from '../assets/avatars/43.png';
import a44 from '../assets/avatars/44.png';
import a45 from '../assets/avatars/45.png';
import a46 from '../assets/avatars/46.png';
import a47 from '../assets/avatars/47.png';
import a48 from '../assets/avatars/48.png';
import a49 from '../assets/avatars/49.png';
import a50 from '../assets/avatars/50.png';
import a51 from '../assets/avatars/51.png';
import a52 from '../assets/avatars/52.png';
import a53 from '../assets/avatars/53.png';
import a54 from '../assets/avatars/54.png';
import a55 from '../assets/avatars/55.png';
import a56 from '../assets/avatars/56.png';
import a57 from '../assets/avatars/57.png';
import a58 from '../assets/avatars/58.png';
import a59 from '../assets/avatars/59.png';
import a60 from '../assets/avatars/60.png';
import a61 from '../assets/avatars/61.png';
import a62 from '../assets/avatars/62.png';
import a63 from '../assets/avatars/63.png';
import a64 from '../assets/avatars/64.png';
import a65 from '../assets/avatars/65.png';
import a66 from '../assets/avatars/66.png';
import a67 from '../assets/avatars/67.png';
import a68 from '../assets/avatars/68.png';
import a69 from '../assets/avatars/69.png';
import a70 from '../assets/avatars/70.png';
import a71 from '../assets/avatars/71.png';
import a72 from '../assets/avatars/72.png';
import a73 from '../assets/avatars/73.png';
import a74 from '../assets/avatars/74.png';
import a75 from '../assets/avatars/75.png';
import a76 from '../assets/avatars/76.png';
import a77 from '../assets/avatars/77.png';
import a78 from '../assets/avatars/78.png';
import a79 from '../assets/avatars/79.png';
import a80 from '../assets/avatars/80.png';
import a81 from '../assets/avatars/81.png';
import a82 from '../assets/avatars/82.png';
import a83 from '../assets/avatars/83.png';
import a84 from '../assets/avatars/84.png';
import a85 from '../assets/avatars/85.png';
import a86 from '../assets/avatars/86.png';
import a87 from '../assets/avatars/87.png';
import a88 from '../assets/avatars/88.png';
import a89 from '../assets/avatars/89.png';
import a90 from '../assets/avatars/90.png';
import a91 from '../assets/avatars/91.png';
import a92 from '../assets/avatars/92.png';
import a93 from '../assets/avatars/93.png';
import a94 from '../assets/avatars/94.png';
import a95 from '../assets/avatars/95.png';
import a96 from '../assets/avatars/96.png';
import a97 from '../assets/avatars/97.png';
import a98 from '../assets/avatars/98.png';
import a99 from '../assets/avatars/99.png';
import a100 from '../assets/avatars/100.png';
import a101 from '../assets/avatars/101.png';
import a102 from '../assets/avatars/102.png';
import a103 from '../assets/avatars/103.png';
import a104 from '../assets/avatars/104.png';
import a105 from '../assets/avatars/105.png';
import a106 from '../assets/avatars/106.png';
import a107 from '../assets/avatars/107.png';

export default class AvatarImage extends React.Component {
    render = () => (
        <Image
            style={this.props.style}
            source={require('../assets/avatars/' + this.props.show + '.png')}
        />
    );

    getImage = () => {
        switch (this.props.show) {
            case '1':
                return a1;
            case '2':
                return a2;
            case '3':
                return a3;
            case '4':
                return a4;
            case '5':
                return a5;
            case '6':
                return a6;
            case '7':
                return a7;
            case '8':
                return a8;
            case '9':
                return a9;
            case '10':
                return a10;
            case '11':
                return a11;
            case '12':
                return a12;
            case '13':
                return a13;
            case '14':
                return a14;
            case '15':
                return a15;
            case '16':
                return a16;
            case '17':
                return a17;
            case '18':
                return a18;
            case '19':
                return a19;
            case '20':
                return a20;
            case '21':
                return a21;
            case '22':
                return a22;
            case '23':
                return a23;
            case '24':
                return a24;
            case '25':
                return a25;
            case '26':
                return a26;
            case '27':
                return a27;
            case '28':
                return a28;
            case '29':
                return a29;
            case '30':
                return a30;
            case '31':
                return a31;
            case '32':
                return a32;
            case '33':
                return a33;
            case '34':
                return a34;
            case '35':
                return a35;
            case '36':
                return a36;
            case '37':
                return a37;
            case '38':
                return a38;
            case '39':
                return a39;
            case '40':
                return a40;
            case '41':
                return a41;
            case '42':
                return a42;
            case '43':
                return a43;
            case '44':
                return a44;
            case '45':
                return a45;
            case '46':
                return a46;
            case '47':
                return a47;
            case '48':
                return a48;
            case '49':
                return a49;
            case '50':
                return a50;
            case '51':
                return a51;
            case '52':
                return a52;
            case '53':
                return a53;
            case '54':
                return a54;
            case '55':
                return a55;
            case '56':
                return a56;
            case '57':
                return a57;
            case '58':
                return a58;
            case '59':
                return a59;
            case '60':
                return a60;
            case '61':
                return a61;
            case '62':
                return a62;
            case '63':
                return a63;
            case '64':
                return a64;
            case '65':
                return a65;
            case '66':
                return a66;
            case '67':
                return a67;
            case '68':
                return a68;
            case '69':
                return a69;
            case '70':
                return a70;
            case '71':
                return a71;
            case '72':
                return a72;
            case '73':
                return a73;
            case '74':
                return a74;
            case '75':
                return a75;
            case '76':
                return a76;
            case '77':
                return a77;
            case '78':
                return a78;
            case '79':
                return a79;
            case '80':
                return a80;
            case '81':
                return a81;
            case '82':
                return a82;
            case '83':
                return a83;
            case '84':
                return a84;
            case '85':
                return a85;
            case '86':
                return a86;
            case '87':
                return a87;
            case '88':
                return a88;
            case '89':
                return a89;
            case '90':
                return a90;
            case '91':
                return a91;
            case '92':
                return a92;
            case '93':
                return a93;
            case '94':
                return a94;
            case '95':
                return a95;
            case '96':
                return a96;
            case '97':
                return a97;
            case '98':
                return a98;
            case '99':
                return a99;
            case '100':
                return a100;
            case '101':
                return a101;
            case '102':
                return a102;
            case '103':
                return a103;
            case '104':
                return a104;
            case '105':
                return a105;
            case '106':
                return a106;
            case '107':
                return a107;
        }
    };
}
