import get from 'lodash/get';
import {
    GAME_SOLO_GAME_LOGIN,
    GAME_SOLO_NEW_GAME,
    GAME_SOLO_SAVED_RULES,
    GAME_SOLO_GET_RANDOM_BOARD,
    GAME_SOLO_RESET_CREATE_BOARD,
    GAME_SOLO_SET_BOARD_DISABLE,
    GAME_SOLO_RESET_RESUME_GAME,
    GAME_SOLO_RESET_SLOT_DATA,
    GAME_SOLO_CREATE_GAME_DATA,
    GAME_SOLO_MENU_SHOW_HIDE,
    GAME_SOLO_SET_CURRENT_MENU_OPT,
    GAME_SOLO_SET_FORM_TYPE,
    GAME_SOLO_SET_FORM_DATA,
    RELOAD_APP,
} from '../configs/ActionIdentifiers';
import Config from '../configs/Config';
import SettingsUtil from '../utils/SettingsUtil';
import log from 'loglevel';

const INITIAL_STATE = {
    setBoardButton: true,
    bdsqvalSlot: Config.DEFAULT_BDSQVAL,
    tilecountSlot: Config.DEFAULT_TILE_COUNT,
    tilevaluesSlot: Config.DEFAULT_TILE_SCORE,
    menuOpt: true,
    currentOpt: Config.SOLO_DEFAULT_MENU_OPT,
};

const soloReducer = (state = INITIAL_STATE, action) => {
    let messageObj = action.payload;
    let globalState = get(action, 'globalState');
    switch (get(action, 'type')) {
        case GAME_SOLO_GAME_LOGIN: {
            log.info('SoloReducer: ' + action.type);
            state.soloRating =
                get(messageObj, 'rating') || Config.DEFAULT_RATING_VALUE;
            state.pregamedata = get(messageObj, 'pregamedata')
                ? get(messageObj, 'pregamedata').split(',')
                : [];
            state.isOldUser = state.pregamedata.length > 1;
            state.dictionary = state.isOldUser
                ? state.pregamedata[0]
                : SettingsUtil.get(
                      'us_gamestart.gs_prefdic',
                      undefined,
                      globalState
                  );
            state.level = state.isOldUser ? state.pregamedata[1] : '1';
            state.time = state.isOldUser
                ? Number(state.pregamedata[2] / 60) + ''
                : '0';
            state.gid = get(messageObj, 'gid');
            state.hasSavedGame = state.gid && Number(state.gid) > 0;
            state.menuOpt = true;
            state.currentOpt = Config.SOLO_DEFAULT_MENU_OPT;
            break;
        }
        case RELOAD_APP:
        case GAME_SOLO_NEW_GAME: {
            log.info('SoloReducer ' + action.type);

            if (action.type === RELOAD_APP) {
                let globalState = get(messageObj, 'globalState');
                log.info(
                    "SoloReducer get(messageObj, 'soloNewGame') is:" +
                        get(messageObj, 'soloNewGame')
                );
                log.info(
                    "SoloReducer get(globalState, 'game.game_type') " +
                        get(globalState, 'game.game_type')
                );
                if (
                    !(
                        get(globalState, 'game.game_type') ===
                        Config.GAME_TYPE_SOLO
                    )
                ) {
                    log.info('SoldReducer breaking ');
                    break;
                }
            }

            state.soloNewGame = get(messageObj, 'soloNewGame');

            log.info('SoldReducer state.soloNewGame is: ' + state.soloNewGame);

            state.menuOpt = ![
                Config.SOLO_NO_LOGIN_NEW_GAME,
                Config.SOLO_REMATCH,
            ].includes(state.soloNewGame);

            log.info('SoldReducer state.menuOpt is: ' + state.menuOpt);

            state.hasSavedGame = false;

            break;
        }
        case GAME_SOLO_SAVED_RULES: {
            log.info('SoloReducer: ' + action.type);
            let boardSlot = [];
            Object.entries(get(messageObj, 'data.boarddetails')).forEach(
                ([key, item]) => {
                    boardSlot.push({
                        slotId: key,
                        slotName: item,
                    });
                }
            );
            if (messageObj.saveType) {
                let slotSaveIndex = boardSlot.length + 1;
                for (let i = slotSaveIndex; i <= 20; i++) {
                    boardSlot.push({
                        slotSaveIndex: slotSaveIndex,
                        slotName: 'SLOT' + i,
                    });
                }
            }
            state.slotData = {
                type: messageObj.saveType
                    ? Config.SOLO_SLOT_SAVE
                    : Config.SOLO_SLOT_PLAY_EDIT,
                boardSlot: boardSlot,
            };
            break;
        }
        case GAME_SOLO_GET_RANDOM_BOARD: {
            log.info('SoloReducer: ' + action.type);
            state.boarddes = messageObj.boarddes;
            state.bdsqvalSlot = messageObj.bdsqvalSlot || state.bdsqvalSlot;
            state.tilecountSlot =
                messageObj.tilecountSlot || state.tilecountSlot;
            state.tilevaluesSlot =
                messageObj.tilevaluesSlot || state.tilevaluesSlot;
            state.setBoardButton = true;
            break;
        }
        case GAME_SOLO_RESET_CREATE_BOARD: {
            log.info('SoloReducer: ' + action.type);
            state.boarddes = undefined;
            state.setBoardButton = true;
            break;
        }
        case GAME_SOLO_SET_BOARD_DISABLE: {
            log.info('SoloReducer: ' + action.type);
            state.setBoardButton = false;
            break;
        }
        case GAME_SOLO_RESET_RESUME_GAME: {
            log.info('SoloReducer: ' + action.type);
            state.hasSavedGame = false;
            break;
        }
        case GAME_SOLO_RESET_SLOT_DATA: {
            log.info('SoloReducer: ' + action.type);
            state.slotData = undefined;
            break;
        }
        case GAME_SOLO_CREATE_GAME_DATA: {
            log.info('SoloReducer: ' + action.type);
            state.createBoardDes =
                get(messageObj, 'createBoardDes') || state.createBoardDes;
            state.createBoardTilevalues =
                get(messageObj, 'createBoardTilevalues') ||
                state.createBoardTilevalues;
            state.createBoardTileCount =
                get(messageObj, 'createBoardTileCount') ||
                state.createBoardTileCount;
            break;
        }
        case GAME_SOLO_MENU_SHOW_HIDE: {
            log.info('SoloReducer: ' + action.type);
            state.menuOpt = get(messageObj, 'menuOpt');
            break;
        }
        case GAME_SOLO_SET_CURRENT_MENU_OPT: {
            log.info('SoloReducer: ' + action.type);
            state.currentOpt = get(
                messageObj,
                'currentOpt',
                Config.SOLO_DEFAULT_MENU_OPT
            );
            break;
        }
        case GAME_SOLO_SET_FORM_TYPE: {
            log.info('SoloReducer: ' + action.type);
            state.isRobot = get(messageObj, 'isRobot');
            break;
        }
        case GAME_SOLO_SET_FORM_DATA: {
            log.info('SoloReducer: ' + action.type);
            state.isOldUser = true;
            state.dictionary =
                get(messageObj, 'dictionary') || state.dictionary;
            state.level = get(messageObj, 'level') || state.level;
            state.time = get(messageObj, 'time') || state.time;
            break;
        }
    }
    return { ...state };
};

export default soloReducer;
