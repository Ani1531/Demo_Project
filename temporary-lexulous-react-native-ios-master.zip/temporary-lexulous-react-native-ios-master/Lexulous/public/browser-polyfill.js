/* String.prototype.formatUnicorn =
    String.prototype.formatUnicorn ||
    function () {
        'use strict';
        var str = this.toString();
        if (arguments.length) {
            var t = typeof arguments[0];
            var key;
            var args =
                'string' === t || 'number' === t
                    ? Array.prototype.slice.call(arguments)
                    : arguments[0];

            for (key in args) {
                str = str.replace(
                    new RegExp('\\{' + key + '\\}', 'gi'),
                    args[key]
                );
            }
        }
        return str;
    };

if (![].includes) {
    Array.prototype.includes = function (searchElement) {
        'use strict';
        var O = Object(this);
        var len = parseInt(O.length) || 0;
        if (len === 0) {
            return false;
        }
        var n = parseInt(arguments[1]) || 0;
        var k;
        if (n >= 0) {
            k = n;
        } else {
            k = len + n;
            if (k < 0) {
                k = 0;
            }
        }
        var currentElement;
        while (k < len) {
            currentElement = O[k];
            if (
                searchElement === currentElement ||
                (searchElement !== searchElement &&
                    currentElement !== currentElement)
            ) {
                return true;
            }
            k++;
        }
        return false;
    };
}

if (!String.prototype.includes) {
    String.prototype.includes = function (search, start) {
        'use strict';
        if (search instanceof RegExp) {
            throw TypeError('first argument must not be a RegExp');
        }
        if (start === undefined) {
            start = 0;
        }
        return this.indexOf(search, start) !== -1;
    };
} 

Array.prototype.move = function (from, to) {
    this.splice(to, 0, this.splice(from, 1)[0]);
};

Array.prototype.replaceContents = function (array2) {
    //make a clone of the 2nd array to avoid any referential weirdness
    var newContent = array2.slice(0);
    //empty the array
    this.length = 0;
    //push in the 2nd array
    this.push.apply(this, newContent);
};

Array.prototype.last = function () {
    return this[this.length - 1];
};*/
