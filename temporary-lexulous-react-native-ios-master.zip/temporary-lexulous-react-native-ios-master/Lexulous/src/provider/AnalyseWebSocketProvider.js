import WebSocketAsPromised from 'websocket-as-promised';
import Config from '../configs/Config';
import { to } from 'await-to-js';
import { isOnline } from '../utils/Utils';
import store from '../store';
import get from 'lodash/get';

const eventBus = require('js-event-bus')();

let analyseWebsocketConnection;

export default class AnalyseWebSocketProvider {
    static getConnection = async () => {
        const state = store.getState();
        if (
            isOnline() &&
            analyseWebsocketConnection &&
            analyseWebsocketConnection.ws &&
            [1, 0].includes(analyseWebsocketConnection.ws.readyState)
        ) {
            return analyseWebsocketConnection;
        } else {
            let loginParams = {
                action: 'login',
                guid: state.game.guid,
                uuid: state.game.uuid,
                channel: state.game.channel,
                ver: '12',
                device: 'WB',
            };
            let wsUrl = encodeURI(
                state.game.analyse_websocket_host +
                    'analyzer?params=' +
                    JSON.stringify(loginParams)
            );
            analyseWebsocketConnection = new WebSocketAsPromised(wsUrl, {
                packMessage: (data) => JSON.stringify(data),
                unpackMessage: (data) => JSON.parse(data),
                attachRequestId: (data, requestId) =>
                    Object.assign(
                        { piggyback: JSON.stringify({ msgId: requestId }) },
                        data
                    ), // attach requestId to message as `id` field
                extractRequestId: (data) =>
                    data && data.piggyback && JSON.parse(data.piggyback).msgId, // read requestId from message `id` field
                timeout: Config.LIVE_GAME_REQUEST_TIMEOUT_TIME,
            });
            let res = await to(analyseWebsocketConnection.open());
            if (!res[0]) {
                return analyseWebsocketConnection;
            }
        }
    };

    static getPossibleMoves = async (gid) => {
        const state = store.getState();
        let params = {
            action: 'analysegame',
            gid: gid || state.game.gid,
        };
        let connectionResult = await to(
            AnalyseWebSocketProvider.getConnection()
        );
        let requestResult = connectionResult[1]
            ? await to(connectionResult[1].sendRequest(params))
            : [Error('Unable to connect to analyse web socket')];
        if (requestResult[1]) {
            return requestResult[1];
        } else {
            throw requestResult[0];
        }
    };

    static getMoveStrengthData = async (wordsplayed, movetiles, rackinfo) => {
        const state = store.getState();

        let params = {
            action: Config.MOVE_STRENGTH_ACTION,
            game: {
                channel: state.game.channel,
                gid: state.game.gid,
                dic: state.game.dic,
                gametype: 'LR',
                boardtype:
                    get(state, 'game.board_type') === 'super' ? 'S' : 'N',

                boarddata: {
                    wordsplayed: wordsplayed,
                    movetiles: movetiles,
                    rackinfo: rackinfo,
                },
            },
        };
        let connectionResult = await to(
            AnalyseWebSocketProvider.getConnection()
        );
        let requestResult = connectionResult[1]
            ? await to(connectionResult[1].sendRequest(params))
            : [Error('Unable to connect to analyse web socket')];
        if (requestResult[1]) {
            return requestResult[1];
            // eventBus.emit(GAME_MOVE_STRENGTH_DATA, null, requestResult[1]);
        } else {
            throw requestResult[0];
        }
    };
}
