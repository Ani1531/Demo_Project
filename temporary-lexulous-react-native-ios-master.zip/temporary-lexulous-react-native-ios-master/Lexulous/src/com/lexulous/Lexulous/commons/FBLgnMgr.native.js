// @flow

import { Settings, AccessToken, LoginManager, Profile, GameRequestDialog } from 'react-native-fbsdk-next';
import dataServer from '../store/Store';
import { actionUpdateFBLgnInfo } from '../userprofile/PFLAction';
import LgnMgr from './LgnMgr';
import * as CONSTANTS from './Constants';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import { translate } from '../commons/translations/LangTransator';
import { handleException, showMessage } from './RJUtils';

class FBLgnMgr extends LgnMgr {
    _accessToken: ?AccessToken = null;
    _tempOnLoginCallBack: ?() => void = null;
    type = 'FBLgnMgr';

    constructor() {
        super();
        this._accessToken = null;
        this._tempOnLoginCallBack = null;
        Settings.initializeSDK();
        AccessToken.addListener(this.fbTokenChangeListener);
    }

    get accessToken(): ?AccessToken {
        return this._accessToken;
    }

    checkLoginSilentModeAsync = async (): Promise<boolean> => {
        let loggedin: boolean = await this.isUserLoggedIn();
        if (loggedin) {
            let currentProfile = await Profile.getCurrentProfile();
            if (currentProfile) {
                let lgndata = {
                    fbAccessToken: this._accessToken,
                    username: currentProfile.name,
                };
                dataServer.getStore().dispatch(actionUpdateFBLgnInfo(lgndata));
            } else {
                loggedin = false;
            }
        }
        return loggedin;
    };

    checkLoginSilentMode = (onboarduser: ?() => void) => {
        console.log('RJS_TEST checkLoginSilentMode');
        this.isUserLoggedIn().then((loggedin) => {
            if (loggedin) {
                Profile.getCurrentProfile().then((currentProfile) => {
                    if (currentProfile) {
                        let lgndata = {
                            fbAccessToken: this._accessToken,
                            username: currentProfile.name,
                        };
                        dataServer.getStore().dispatch(actionUpdateFBLgnInfo(lgndata));
                        if (onboarduser) {
                            onboarduser();
                        }
                    }
                });
            }
        });
    };

    isUserLoggedIn = async (): Promise<boolean> => {
        let loggedin: boolean = this._accessToken !== null && this._accessToken !== undefined;
        if (!loggedin) {
            let tokenInfo = await AccessToken.getCurrentAccessToken();
            this._accessToken = tokenInfo;
            loggedin = this._accessToken !== null && this._accessToken !== undefined;
        }
        return loggedin;
    };

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     this._tempOnLoginCallBack = null;
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        this.fbDidLoggedOut(onCompletion);
    };

    doFbLogin = (onCompletion: ?() => void) => {
        this._tempOnLoginCallBack = onCompletion;
        AccessToken.getCurrentAccessToken().then((tokenInfo) => {
            this._accessToken = tokenInfo;
            let loggedin = tokenInfo !== null && tokenInfo !== undefined;
            if (loggedin == true) {
                //User is logged in some permission required
                if (
                    !this._accessToken?.permissions.includes('user_friends') ||
                    this._accessToken?.declinedPermissions.includes('user_friends')
                ) {
                    LoginManager.logInWithPermissions(['user_friends']).then(
                        function (result) {
                            //FBLgnMgr.sharedInstance.tempOnLoginCallBack = null;
                        },
                        function (error) {
                            this.fbDidLoggedOut(onCompletion);
                            this.tempOnLoginCallBack = null;
                        }
                    );
                } else {
                    this.fbDidLoggedIn(onCompletion);
                    this._tempOnLoginCallBack = null;
                }
            } else {
                //Access token was not found
                LoginManager.logInWithPermissions(['user_friends']).then(
                    function (result) {
                        //FBLgnMgr.sharedInstance.tempOnLoginCallBack = null;
                    },
                    function (error) {
                        this.fbDidLoggedOut(onCompletion);
                        this._tempOnLoginCallBack = null;
                    }
                );
            }
        });
    };

    fbTokenChangeListener = (accessToken: ?AccessToken) => {
        if (this._accessToken != accessToken) {
            this._accessToken = accessToken;
            if (accessToken !== null) {
                this.fbDidLoggedIn(this._tempOnLoginCallBack);
            } else {
                this.fbDidLoggedOut(this._tempOnLoginCallBack);
            }
            this._tempOnLoginCallBack = null;
        }
    };

    fbDidLoggedOut = async (onCompletion: ?() => void) => {
        LoginManager.logOut();
        this._tempOnLoginCallBack = null;
        this._accessToken = null;
        let delpendingassoc = await this.deletePendingAssociation();
        dataServer.getStore().dispatch(actionUpdateFBLgnInfo(null));
        if (onCompletion) {
            onCompletion();
        }
    };

    getFbUserProfile = async (): Promise<?Profile> => {
        return new Promise((resolve, reject) => {
            Profile.getCurrentProfile().then((currentProfile) => {
                if (currentProfile) {
                    resolve(currentProfile);
                } else {
                    reject(currentProfile);
                }
            });
        });
    };

    retryFn = (maxRetries: number, fn: () => Promise<any>) => {
        return fn().catch((err) => {
            if (maxRetries <= 0) {
                throw err;
            }
            return this.retryFn(maxRetries - 1, fn);
        });
    };

    // fbDidLoggedIn = (onCompletion: ?() => void) => {
    //     AccessToken.getCurrentAccessToken().then((tokenInfo) => {
    //         this._accessToken = tokenInfo;
    //         if (tokenInfo !== null) {
    //             Profile.getCurrentProfile().then((currentProfile) => {
    //                 if (currentProfile) {
    //                     let lgndata = {
    //                         fbAccessToken: this._accessToken,
    //                         username: currentProfile.name,
    //                     };
    //                     dataServer.getStore().dispatch(actionUpdateFBLgnInfo(lgndata));
    //                     if (onCompletion) {
    //                         onCompletion();
    //                     }
    //                 } else {
    //                     if (onCompletion) {
    //                         onCompletion();
    //                     }
    //                 }
    //             });
    //         } else {
    //             if (onCompletion) {
    //                 onCompletion();
    //             }
    //         }
    //     });
    // };

    fbDidLoggedIn = (onCompletion: ?() => void) => {
        dataServer.getStore().dispatch(actionSetBusy());
        AccessToken.getCurrentAccessToken().then((tokenInfo) => {
            this._accessToken = tokenInfo;
            if (tokenInfo !== null) {
                this.retryFn(CONSTANTS.kRetryCount, this.getFbUserProfile)
                    .then((currentProfile) => {
                        let lgndata = {
                            fbAccessToken: this._accessToken,
                            username: currentProfile.name,
                        };
                        dataServer.getStore().dispatch(actionUpdateFBLgnInfo(lgndata));
                        if (onCompletion) {
                            onCompletion();
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                        }
                    })
                    .catch((error) => {
                        if (onCompletion) {
                            onCompletion();
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                        }
                    });
            } else {
                if (onCompletion) {
                    onCompletion();
                } else {
                    dataServer.debouncedDispatch(actionSetIdle());
                }
            }
        });
    };

    doInviteFbFriends = () => {
        const gamerequest = {
            filters: 'app_non_users',
            message: translate('fb_msg'),
            title: 'Lexulous Crossword Game',
        };

        GameRequestDialog.canShow()
            .then((canShow) => {
                if (canShow) {
                    return GameRequestDialog.show(gamerequest);
                }
            })
            .then(
                (result) => {
                    let cnt = result.to.length ?? 0;
                    if (cnt > 0) {
                        showMessage(translate('fnd_invtd'), 'fb_lgn_mgr');
                    }
                },
                (error) => {
                    handleException(error);
                }
            );
    };
}
const fbLgnMgr: FBLgnMgr = new FBLgnMgr();

export default fbLgnMgr;
