// @flow

import { UPDT_POPUP_VISIBILITY, HIDE_ALL_POPUPS, SHOW_ALERT, CLEAR_ALERT, CLEAR_ALL_ALERTS } from './PopupEventTypes';

import type { PopupAction, ActionPopupVisibility, ActionAddAlert, PopupData, AlertBoxType } from '../../commons/RJTypes';
import { AlertBoxButtonType } from '../../commons/Constants';

const INITIAL_STATE = {
    pendingAlerts: [],
    showUserNamePopup: false,
    showDictionaryPopup: false,
    showLoginPopup: false,
    showSharePopup: false,
    showHelpPopup: false,
    showDetailsPopup: false,
    showTutorialPopup: false,
    showMatchFriendPopup: false,
    showHostGamePopup: false,
};

export default function PopupReducer(state: PopupData = INITIAL_STATE, taction: PopupAction) {
    switch (taction.type) {
        case UPDT_POPUP_VISIBILITY: {
            let action = ((taction: any): ActionPopupVisibility);
            if (action.payload) {
                if (Object.keys(action.payload).length === 0) {
                    return state;
                } else {
                    let qq = Object.values(action.payload);
                    const reducer = (previousValue, currentValue) => previousValue && currentValue;
                    let istryingtoshow = qq.reduce(reducer);
                    if (istryingtoshow) {
                        return {
                            ...INITIAL_STATE,
                            pendingAlerts: state.pendingAlerts,
                            ...action.payload,
                        };
                    } else {
                        return {
                            ...state,
                            ...action.payload,
                        };
                    }
                }
            } else {
                return state;
            }
        }
        case HIDE_ALL_POPUPS: {
            return {
                ...INITIAL_STATE,
                pendingAlerts: state.pendingAlerts,
            };
        }
        case SHOW_ALERT: {
            let action = ((taction: any): ActionAddAlert);
            let alertBoxInfo: AlertBoxType = action.payload;
            if (validateAlertInfo(alertBoxInfo)) {
                let statePendingAlert = state.pendingAlerts ?? [];
                let pendingAlerts = [...statePendingAlert, alertBoxInfo];

                return {
                    ...state,
                    pendingAlerts,
                };
            } else {
                return state;
            }
        }
        case CLEAR_ALERT: {
            let pendingAlerts = state.pendingAlerts ?? [];
            if (pendingAlerts.length > 0) {
                pendingAlerts.shift();
            }
            return {
                ...state,
                pendingAlerts,
            };
        }
        case CLEAR_ALL_ALERTS: {
            let pendingAlerts = [];

            return {
                ...state,
                pendingAlerts,
            };
        }
        default:
            return state;
    }
}

let validateAlertInfo = (alertBoxInfo: AlertBoxType) => {
    let validationStatus = true;

    let showCancelOnlyBtn = alertBoxInfo.actions?.filter(({ type }) => type === AlertBoxButtonType.SHOWCANCELONLY);
    let showBothBtn = alertBoxInfo?.actions?.filter(({ type }) => type === AlertBoxButtonType.SHOWBOTH);
    let isInvalid: boolean =
        showBothBtn.length > 1 || showCancelOnlyBtn.length > 1 || (showBothBtn.length >= 1 && showCancelOnlyBtn.length >= 1);

    validationStatus = !isInvalid;

    return validationStatus;
};
