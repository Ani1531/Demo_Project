import React from 'react';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { isProUser, isPuzzleGame, isSoloGame } from '../service/GamePlayService';
import { createDialogInstance } from '../utils/MessageUtils';
import { connect } from 'react-redux';
import { CONFIG_SET_SETTING, CONFIG_SETTINGS_CHANGED, CONFIG_SET_MENU_VISIBILITY } from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faToggleOn, faToggleOff } from '@fortawesome/pro-light-svg-icons';
import { openPurchaseProPage } from '../utils/UrlUtils';
import ProTag from './ProTag';
import S14Text from './S14Text';
import { getBoardCenterIcon } from '../utils/Utils';

const eventBus = require('js-event-bus')();

class GameSettingsMenu extends React.Component {
    state = {
        availableBoardThemes: [
            { theme: 'Lexulous', id: '0', selected: false },
            { theme: 'Classic', id: '1', selected: false },
            { theme: 'Adventure', id: '2', selected: false },
            { theme: 'Essence', id: '3', selected: false },
            { theme: 'Spirit', id: '4', selected: false },
            { theme: 'Dark', id: '5', selected: false },
        ],
        selectedBoardTheme: (get(this.props, 'config.theme') || '').split('-')[0] || '0',
        selectedTileTheme: (get(this.props, 'config.theme') || '').split('-')[1] || '0',
        availableTileThemes: [
            { theme: 'Lexulous', id: '0', selected: false },
            { theme: 'Classic', id: '1', selected: false },
            { theme: 'Adventure', id: '2', selected: false },
            { theme: 'Essence', id: '3', selected: false },
            { theme: 'Dark', id: '4', selected: false },
        ],
    };

    haveInitialMovesCompleted = () => {
        let i,
            isCompleted = 'no';
        if (this.props.game.moveListCompleteData.length !== 0) {
            for (i = 1; i <= this.props.game.players.length; i++) {
                if (typeof this.props.game.moveListCompleteData[0][i] === 'object') {
                    isCompleted = 'yes';
                } else {
                    isCompleted = 'no';
                    return isCompleted;
                }
            }
        }

        return isCompleted;
    };

    selectBoardCenterIcon = () => {
        let availableBoardCenterIcons = Object.values(Config.BOARD_CENTER_ICONS);
        let iconIndex = availableBoardCenterIcons.findIndex((item) => item === this.props.config.gp_brdcntrimg);
        let nextIconIndex = iconIndex + 1;
        if (nextIconIndex >= availableBoardCenterIcons.length) {
            nextIconIndex = 0;
        }
        this.setSetting({
            gp_brdcntrimg: availableBoardCenterIcons[nextIconIndex],
        });
    };

    selectBoardTheme = () => {
        let selectedBoardThemeIndex = this.state.selectedBoardTheme;
        let boardThemes = this.state.availableBoardThemes;
        let nextSelected = Number(selectedBoardThemeIndex) + 1;
        if (nextSelected >= boardThemes.length) nextSelected = 0;
        boardThemes.forEach((element, index) => {
            element.selected = index === nextSelected;
        });
        this.setState(
            {
                availableBoardThemes: boardThemes,
                selectedBoardTheme: nextSelected,
            },
            () => {
                this.setSetting({
                    theme: this.state.selectedBoardTheme + '-' + this.state.selectedTileTheme,
                });
            }
        );
    };

    selectTileTheme = () => {
        let selectedTileThemeIndex = this.state.selectedTileTheme;
        let tileThemes = this.state.availableTileThemes;
        let nextSelected = Number(selectedTileThemeIndex) + 1;
        if (nextSelected >= tileThemes.length) nextSelected = 0;
        tileThemes.forEach((element, index) => {
            element.selected = index === nextSelected;
        });
        this.setState(
            {
                availableTileThemes: tileThemes,
                selectedTileTheme: nextSelected,
            },
            () => {
                this.setSetting({
                    theme: this.state.selectedBoardTheme + '-' + this.state.selectedTileTheme,
                });
            }
        );
    };

    onSoloNewGame = () => {
        createDialogInstance({
            title: 'New Game',
            actionButtonText: 'Yes',
            onAction: () =>
                eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, null, {
                    soloNewGame: this.props.game.soloDemoAcc ? Config.SOLO_NO_LOGIN_NEW_GAME : Config.SOLO_NEW_GAME,
                }),
            body: 'Are you sure you wish to start a new game? This will clear your current game.',
            notDismissable: true,
            isConfirmableByKey: false,
            cancelButtonText: 'No',
            onCancel: () => null,
        });
    };

    onResign = () => {
        eventBus.emit(Config.RESIGN_DELETE_GAME, null, { doResign: true });
        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);
    };

    onDelete = () => {
        eventBus.emit(Config.RESIGN_DELETE_GAME, null, { doResign: false });
        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);
    };

    getBoardThemeId = () => (get(this.props, 'config.theme') || '').split('-')[0] || '0';

    getTileThemeId = () => (get(this.props, 'config.theme') || '').split('-')[1] || '0';

    getBoardTheme = () => this.state.availableBoardThemes[this.getBoardThemeId()];

    getTileTheme = () => this.state.availableTileThemes[this.getTileThemeId()];

    toggleSound = () => {
        this.setSetting({ sounds_enabled: !this.props.config.sounds_enabled });
    };

    toggleNumberedPlane = () => {
        this.setSetting({ numbered_plain: !this.props.config.numbered_plain });
    };

    toggleTapToPlay = () => {
        if (isProUser()) {
            this.setSetting({ tap_to_play: !this.props.config.tap_to_play });
        } else {
            createDialogInstance({
                title: 'PRO Feature: Magic Tiles',
                body: 'This feature is available for PRO users only.',
                actionButtonText: 'Go PRO',
                onAction: () => openPurchaseProPage(false),
            });
        }
    };

    toggleAutoZoom = () => {
        this.setSetting({ autozoom: !this.props.config.autozoom });
    };

    togglePreConfirmation = () => {
        this.setSetting({
            move_confirmation: !this.props.config.move_confirmation,
        });
    };

    toggleTooltip = () => {
        this.setSetting({
            tooltip_enabled: !this.props.config.tooltip_enabled,
        });
    };

    setSetting = async (obj) => {
        eventBus.emit(CONFIG_SETTINGS_CHANGED, null, true);
        eventBus.emit(CONFIG_SET_SETTING, null, obj);
    };

    getMenuItemHeight = () => ({
        height: 40, // Math.round(this.props.layout.layoutCellDimen * 1.4),
    });

    getIconStyle = (key) => ({
        fontSize: 20,
        color: this.props.config[key]
            ? ColorConfig.CONTEXTIFIED_CONTEXT_MENU_TEXT_HOVER_COLOR
            : ColorConfig.CONTEXTIFIED_CONTEXT_MENU_TEXT_COLOR,
    });

    getDiplayBlockStyle = (key) => ({
        display: 'block',
    });

    getBoardCenterIconStyle = () => ({
        color: ColorConfig.CONTEXTIFIED_CONTEXT_MENU_TEXT_COLOR,
    });

    render = () => {
        return (
            <View style={[styles.menuContainer /* this.getDiplayBlockStyle() */]}>
                {LiveGamePlayUtils.isPlaying() && !isPuzzleGame() && !this.props.game.gameHasEnded ? (
                    <TouchableOpacity
                        activeOpacity={1}
                        style={[styles.menuStyle, this.getMenuItemHeight()]}
                        onPress={
                            isSoloGame()
                                ? this.onSoloNewGame
                                : this.haveInitialMovesCompleted() === 'yes'
                                ? this.onResign
                                : this.onDelete
                        }
                    >
                        <View style={styles.menuTextContainer}>
                            <S14Text style={styles.menuTextStyle}>
                                {isSoloGame()
                                    ? 'New Game'
                                    : this.haveInitialMovesCompleted() === 'yes' ||
                                      this.props.game.game_type === Config.GAME_TYPE_BLITZ
                                    ? 'Resign Game'
                                    : 'Delete Game'}
                            </S14Text>
                        </View>
                    </TouchableOpacity>
                ) : null}

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Sounds'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.toggleSound}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.sounds_enabled ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('sounds_enabled')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Numbered Board'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.toggleNumberedPlane}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.numbered_plain ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('numbered_plain')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>
                            {'Magic Tile'}
                            <ProTag />
                        </S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.toggleTapToPlay}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.tap_to_play ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('tap_to_play')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Auto Zoom'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.toggleAutoZoom}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.autozoom ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('autozoom')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Move Confirmation'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.togglePreConfirmation}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.move_confirmation ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('move_confirmation')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Tooltip'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.toggleTooltip}>
                        <FontAwesomeIcon
                            size={20}
                            icon={this.props.config.tooltip_enabled ? faToggleOn : faToggleOff}
                            style={this.getIconStyle('tooltip_enabled')}
                        />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Center Icon'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.selectBoardCenterIcon}>
                        <FontAwesomeIcon size={20} icon={getBoardCenterIcon()} style={this.getBoardCenterIconStyle()} />
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Board Theme'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.selectBoardTheme}>
                        <S14Text style={styles.menuTextStyle}>{this.getBoardTheme().theme}</S14Text>
                    </TouchableOpacity>
                </View>

                <View style={[styles.menuStyle, this.getMenuItemHeight()]}>
                    <View style={styles.menuTextContainer}>
                        <S14Text style={styles.menuTextStyle}>{'Tile Theme'}</S14Text>
                    </View>
                    <TouchableOpacity activeOpacity={1} style={styles.menuIconContainer} onPress={this.selectTileTheme}>
                        <S14Text style={styles.menuTextStyle}>{this.getTileTheme().theme}</S14Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    };
}

const styles = StyleSheet.create({
    menuContainer: {
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderWidth: 0,
    },
    menuStyle: {
        borderBottomWidth: 1,
        borderBottomColor: ColorConfig.CONTEXTIFIED_CONTEXT_MENU_BORDER_COLOR,
        //flex: 1,
        flexDirection: 'row',
    },
    menuTextContainer: {
        flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingLeft: 10,
    },
    menuTextStyle: {
        color: ColorConfig.CONTEXTIFIED_CONTEXT_MENU_TEXT_COLOR,
    },
    menuIconContainer: {
        alignItems: 'flex-end',
        justifyContent: 'center',
        paddingRight: 10,
    },
    pickerContainerStyle: {
        flex: 1,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    config: state.config,
    layout: state.layout,
});
export default connect(mapStateToProps)(GameSettingsMenu);
