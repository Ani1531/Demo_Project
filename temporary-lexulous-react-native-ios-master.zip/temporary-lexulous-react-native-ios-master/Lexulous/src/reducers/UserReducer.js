import get from 'lodash/get';
import * as ActionIdentifiers from '../configs/ActionIdentifiers';
import log from 'loglevel';
import cloneDeep from 'lodash/cloneDeep';
import {
    addToSortedList,
    getPlayerListData,
    sortList,
} from '../service/GamePlayService';
import { findAndRemove } from '../utils/Utils';
import Config from '../configs/Config';
import isArray from 'lodash/isArray';

const INITIAL_STATE = {
    playerListDataOn: 'name',
    playerListDataOrder: 'asc',
};

const sortOnlinePlayerList = (state) => {
    state.onlinePlayerBuddies = sortList(
        state.onlinePlayerBuddies,
        state.playerListDataOn,
        state.playerListDataOrder
    );
    state.onlinePlayerOthers = sortList(
        state.onlinePlayerOthers,
        state.playerListDataOn,
        state.playerListDataOrder
    );
};

const setOnlinePlayerList = (state, globalState, playerListData) => {
    state.onlinePlayerBuddies = [];
    state.onlinePlayerOthers = [];
    (playerListData || []).map((player) => {
        if (player.guid === get(globalState, 'game.guid')) {
            state.myData = [player];
        } else if (isPlayerBuddy(state, globalState, player)) {
            state.onlinePlayerBuddies.push(player);
        } else {
            state.onlinePlayerOthers.push(player);
        }
    });
    sortOnlinePlayerList(state);
};

const setPlayerBuddyOthers = (state, globalState) => {
    let onlinePlayerBuddies = state.onlinePlayerBuddies || [];
    let onlinePlayerOthers = state.onlinePlayerOthers || [];
    for (let i = 0; i < onlinePlayerBuddies.length; i++) {
        let player = onlinePlayerBuddies[i];
        if (!isPlayerBuddy(state, globalState, player)) {
            onlinePlayerOthers = addToSortedList(
                onlinePlayerOthers,
                player,
                state.playerListDataOn,
                state.playerListDataOrder
            );
            onlinePlayerBuddies.splice(i, 1);
            i--;
        }
    }
    for (let i = 0; i < onlinePlayerOthers.length; i++) {
        let player = onlinePlayerOthers[i];
        if (isPlayerBuddy(state, globalState, player)) {
            onlinePlayerBuddies = addToSortedList(
                onlinePlayerBuddies,
                player,
                state.playerListDataOn,
                state.playerListDataOrder
            );
            onlinePlayerOthers.splice(i, 1);
            i--;
        }
    }
};

const isPlayerBuddy = (state, globalState, player) => {
    let status = false;
    if (get(globalState, 'game.game_type') === Config.GAME_TYPE_BLITZ) {
        status = (state.buddyRequestList || []).find(
            (item) => item.guid === player.guid
        );
    } else {
        status =
            (get(state.buddyList, 'buddies') || []).find(
                (item) => item.guid === player.guid
            ) ||
            (get(state.buddyList, 'reqsent') || []).find(
                (item) => item.guid === player.guid
            ) ||
            (state.buddyRequestList || []).find(
                (item) => item.guid === player.guid
            );
    }
    return status;
};

const userReducer = (state = INITIAL_STATE, action) => {
    let globalState = get(action, 'globalState');
    switch (action.type) {
        case ActionIdentifiers.GAME_LIVE_ROOM_LOGIN: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.user_info = action.payload.data;
            state.firstMoveDuration = get(
                action.payload,
                'settings.nofirstmovedeleteduration'
            );
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_USER_STATS_FETCHED: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.user_stats = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_SENSOR_LIST_RETRIEVED: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.sensorList = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_BUDDY_REQ_LIST_RETRIEVED: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.buddyRequestList = action.payload;
            setPlayerBuddyOthers(state, globalState);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_BUDDY_LIST: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.buddyList = action.payload;
            setPlayerBuddyOthers(state, globalState);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            state.playerListDataOn = action.payload.playerListDataOn;
            state.playerListDataOrder = action.payload.playerListDataOrder;
            sortOnlinePlayerList(state);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);
            let playerListDataOn = state.playerListDataOn;
            let playerListDataOrder = state.playerListDataOrder;
            switch (get(action.payload, 'type')) {
                case Config.ADD_ONLINE_PLAYER:
                    let playerData = get(
                        getPlayerListData(get(action.payload, 'res')),
                        '0'
                    );
                    if (
                        !(state.onlinePlayerBuddies || []).find(
                            (player) => player.guid === playerData.guid
                        ) &&
                        !(state.onlinePlayerOthers || []).find(
                            (player) => player.guid === playerData.guid
                        )
                    ) {
                        let buddies = state.onlinePlayerBuddies || [];
                        let others = state.onlinePlayerOthers || [];
                        if (isPlayerBuddy(state, globalState, playerData)) {
                            buddies = addToSortedList(
                                buddies,
                                playerData,
                                playerListDataOn,
                                playerListDataOrder
                            );
                            state.onlinePlayerBuddies = buddies;
                        } else {
                            others = addToSortedList(
                                others,
                                playerData,
                                playerListDataOn,
                                playerListDataOrder
                            );
                            state.onlinePlayerOthers = others;
                        }
                    }
                    break;
                case Config.REMOVE_ONLINE_PLAYER:
                    let guid = get(action.payload, 'res.data');
                    if (isPlayerBuddy(state, globalState, { guid })) {
                        findAndRemove(
                            state.onlinePlayerBuddies || [],
                            (player) => player.guid === guid
                        );
                    } else {
                        findAndRemove(
                            state.onlinePlayerOthers || [],
                            (player) => player.guid === guid
                        );
                    }
                    break;
                default:
                    let playerListData = getPlayerListData(action.payload);
                    let myGUID = get(globalState, 'game.guid');
                    let selfIndex = playerListData.findIndex(
                        (item) =>
                            get(item, 'uid.guid') === myGUID ||
                            get(item, 'guid') === myGUID
                    );
                    /* if (selfIndex > 0) {
                        playerListData.move(selfIndex, 0);
                    } */
                    setOnlinePlayerList(state, globalState, playerListData);
            }
            break;
        }

        case ActionIdentifiers.SET_PLAYER_STATUS_AVL_AFTER_GAME_HAS_ENDED:
        case ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE:
        case ActionIdentifiers.GAME_BLITZ_INP_GAMEOVER: {
            log.info('UserReducer: ' + action.type);
            state = cloneDeep(state);
            let gameHasEnded = get(globalState, 'game.gameHasEnded');
            let gametype = get(globalState, 'game.game_type');
            if (
                (gameHasEnded &&
                    [
                        Config.GAME_TYPE_LIVE_GAME,
                        Config.GAME_TYPE_BLITZ,
                    ].includes(gametype)) ||
                action.type === ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE ||
                action.type === ActionIdentifiers.GAME_BLITZ_INP_GAMEOVER
            ) {
                let players =
                    get(
                        action.payload,
                        'data.' + globalState.game.channel + '.players'
                    ) ||
                    get(action.payload, 'data.jndplys') ||
                    [];
                players.map((gamePlayer) => {
                    let player =
                        (state.onlinePlayerBuddies || []).find(
                            (p) => p.guid === gamePlayer.guid
                        ) ||
                        (state.onlinePlayerOthers || []).find(
                            (p) => p.guid === gamePlayer.guid
                        ) ||
                        (state.myData || []).find(
                            (p) => p.guid === gamePlayer.guid
                        );
                    if (player) {
                        player.status = 'avl';
                        player.rating =
                            gametype === Config.GAME_TYPE_BLITZ
                                ? '0'
                                : gamePlayer.rating;
                        player.sortingRating = Number(player.rating);
                    }
                });
            }
            break;
        }

        case ActionIdentifiers.PLAYER_LIST_SET_PLAYER_STATUS_AVL: {
            log.info('UserReducer: ' + action.type);
            state = cloneDeep(state);
            let gameid =
                get(action.payload, 'data.gameid') ||
                get(action.payload, 'data.gid');
            let gameInfo = (
                get(globalState, 'gamelist.observableGamesList') || []
            ).find((item) => item.gid === gameid);

            (get(gameInfo, 'players') || get(gameInfo, 'jndplys') || []).map(
                (gamePlayer) => {
                    let player =
                        (state.onlinePlayerBuddies || []).find(
                            (p) => p.guid === gamePlayer.guid
                        ) ||
                        (state.onlinePlayerOthers || []).find(
                            (p) => p.guid === gamePlayer.guid
                        );
                    if (player) player.status = 'avl';
                }
            );
            break;
        }

        case ActionIdentifiers.PLAYER_LIST_SET_PLAYER_STATUS_PLY: {
            log.info('UserReducer: ' + action.type);
            state = cloneDeep(state);
            if (get(globalState, 'game.game_type') === Config.GAME_TYPE_BLITZ) {
                (get(action.payload, 'data') || []).map((game) => {
                    let jndplys = get(game, 'jndplys') || [];
                    jndplys.map((ply) => {
                        let player =
                            (state.onlinePlayerBuddies || []).find(
                                (p) => p.guid === ply.guid
                            ) ||
                            (state.onlinePlayerOthers || []).find(
                                (p) => p.guid === ply.guid
                            );
                        if (player) player.status = 'ply';
                    });
                });
            } else {
                let allPlayers = {
                    ...(get(action.payload, 'data.playersinfo') || {}),
                    ...(get(action.payload, 'data.uid') || {}),
                };
                if (Object.keys(get(action.payload, 'data.uid')).length === 0) {
                    let keys = Object.keys(allPlayers || {});
                    keys.map((key) => {
                        let player =
                            (state.onlinePlayerBuddies || []).find(
                                (p) => p.guid === key
                            ) ||
                            (state.onlinePlayerOthers || []).find(
                                (p) => p.guid === key
                            );
                        if (player) player.status = 'ply';
                    });
                }
            }
            break;
        }

        case ActionIdentifiers.PLAYER_LIST_CHANGE_PLAYER_STATUS_JOINED: {
            log.info('UserReducer: ' + action.type);
            state = cloneDeep(state);
            if (get(globalState, 'game.game_type') === Config.GAME_TYPE_BLITZ) {
                let jndGuids =
                    get(action.payload, 'data.guid') ||
                    get(action.payload, 'data.guids') ||
                    get(action.payload, 'jndply.guid');
                if (!isArray(jndGuids)) {
                    jndGuids = [jndGuids];
                }
                (jndGuids || []).map((jndGuid) => {
                    let player =
                        (state.onlinePlayerBuddies || []).find(
                            (p) => p.guid === jndGuid
                        ) ||
                        (state.onlinePlayerOthers || []).find(
                            (p) => p.guid === jndGuid
                        ) ||
                        (state.myData || []).find((p) => p.guid === jndGuid);
                    if (player)
                        player.status = player.status === 'jnd' ? 'avl' : 'jnd';
                });
            }
            break;
        }

        case ActionIdentifiers.GAME_BLITZ_JNDPLYS_UPDATE: {
            state = cloneDeep(state);
            log.info('UserReducer: ' + action.type);

            let jndplysUpdate = get(action.payload, 'data.jndplys') || [];
            jndplysUpdate.map((player) => {
                let playerData =
                    (state.onlinePlayerBuddies || []).find(
                        (p) => p.guid === player.guid
                    ) ||
                    (state.onlinePlayerOthers || []).find(
                        (p) => p.guid === player.guid
                    ) ||
                    (state.myData || []).find((p) => p.guid === player.guid);
                if (playerData) {
                    playerData.rating =
                        player.score || playerData.rating || '0';
                    playerData.sortingRating = Number(playerData.rating);
                }
            });
            break;
        }
    }
    return { ...state };
};

export default userReducer;
