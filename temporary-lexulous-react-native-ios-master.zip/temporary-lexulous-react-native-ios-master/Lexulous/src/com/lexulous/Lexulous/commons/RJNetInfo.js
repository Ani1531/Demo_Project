// @flow

import NetInfo from '@react-native-community/netinfo';
import type { NetInfoState } from '@react-native-community/netinfo';
import dataServer from '../store/Store';
import { type AlertBoxType } from '../commons/RJTypes';
import { translate } from '../commons/translations/LangTransator';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';

class RJNetInfo {
    _unsubscribeHdl = null;
    _connected: boolean = false;
    constructor() {}

    onAppInit = (): void => {
        this.onDestroy();
        this._unsubscribeHdl = NetInfo.addEventListener(this.updateInternetState);
    };

    onDestroy = (): void => {
        //cleanup
        if (this._unsubscribeHdl) {
            this._unsubscribeHdl();
            this._unsubscribeHdl = null;
        }
    };

    isConnected = (): boolean => {
        return this._connected;
    };

    showNetworkErrorMessage = (msg: string) => {
        let alertBoxInfo: AlertBoxType = {
            message: msg,
            actions: [
                {
                    text: translate('ok'),
                    action: () => {
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    updateInternetState = (netstate: NetInfoState): void => {
        this._connected = netstate.isConnected;
        if (!this._connected) {
            this.showNetworkErrorMessage(translate('internet_lostMsg'));
        }
    };

    queryInternetStatus = () => {
        NetInfo.fetch().then((netstate: NetInfoState) => {
            this.updateInternetState(netstate);
        });
    };
}

const netManager: RJNetInfo = new RJNetInfo();

export default netManager;
