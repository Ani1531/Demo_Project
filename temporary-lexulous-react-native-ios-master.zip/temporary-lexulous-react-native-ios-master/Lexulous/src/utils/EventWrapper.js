import Config from '../configs/Config';
import WebSocketProvider from '../provider/WebSocketProvider';
import store from '../store';
import { getNull } from './Utils';

const eventBus = require('js-event-bus')();

export default class EventWrapper {
    //App.js
    static addKeyListener = getNull;
    static removeKeyListener = getNull;
    //

    //Board.js
    static addSdkCompletedEventListener = getNull;
    static removeSdkCompletedEventListener = getNull;
    //

    //LiveGameChat.js
    static addKeyDownListener = getNull;
    static removeKeyDownListener = getNull;
    //
    //Shuffle button right click
    static addRightClickListener = getNull;
    static removeRightClickListener = getNull;
    //
    //Shuffle button right click
    static addBodyScrollListener = getNull;
    static removeBodyScrollListener = getNull;
    //
    // to prevent page scorll on tile touch and move
    static addEventTouchListener = getNull;
    static removeEventTouchListener = getNull;

    //Custom event handle
    static addCustomeEventListener = getNull;
    static removeCustomeEventListener = getNull;

    static dispatchCustomEvent = getNull;

    static addScrollInvertListener = (scrollNode) => getNull;
    static removeScrollInvertListener = () => getNull;

    static prevAppState = undefined;
    static onAppStateChange = (appstate, func) => {
        if (appstate === 'active') {
            if (EventWrapper.prevAppState === 'background') {
                eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, null, {
                    background: true,
                    caller: 'onAppStateChange.background',
                    gid: store?.getState().game.gid,
                    pid: store?.getState().game.pid,
                });
            }
        } else {
            func && func();
            WebSocketProvider.disconnect();
        }
        EventWrapper.prevAppState = appstate;
    };
}
