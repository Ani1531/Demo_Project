// @flow

import userDefault from '../commons/UserDefault';
import React from 'react';
import type { AxiosPromise, AxiosResponse } from 'axios';
import type {
    ServerResponse,
    LegacyAuthResponse,
    ProfileInfo,
    LXLSLoginInfo,
    FBLoginInfo,
    GamesListResponse,
    LegacyAuthData,
} from '../commons/RJTypes';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import * as CONSTANTS from '../commons/Constants';
import { rjLog, handleException, showMessage } from '../commons/RJUtils.js';
import requestManager from '../commons/RequestManager';
import netManager from '../commons/RJNetInfo';
import dataServer from '../store/Store';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import fbLgnMgr from '../commons/FBLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import * as RootNavigation from '../commons/RootNavigation';
import { translate } from '../commons/translations/LangTransator';
import loginCoordinator from '../commons/LoginCoordinator';
import { actionLNRUpdateLgnInfo } from '../loginNregister/LNRAction';
import { actionSetProfile } from '../userprofile/PFLAction';
import MultipleAccountSelectionContainer from '../components/MultipleAccountSelectionContainer';

const qs = require('qs');

export const LegacyOnboardPathCode = {
    Normal: 0,
    Merge: 1,
};
Object.freeze(LegacyOnboardPathCode);

export const LoginPrefCode = {
    LxlsNone: '0',
    LxlsEmail: '1',
    LxlsFB: '2',
};
Object.freeze(LoginPrefCode);

export const kPreInstalledKey = 'LkfpyASB'; //kPsistGUID
export const kLegacyPrimaryPrefferedLogin = 'LEXPRO_EG_USER_PWD';
export const kLegacySecondaryPrefferedLogin = 'LEXPRO_FBGUID';

export const kLegacyLexEmailAuthUser = 'LEXPRO_EG_USER_NAME';
export const kLegacyLexEmailAuthSecret = 'LEXPRO_EG_USER_PWD';
export const kLegacyLexEmail = 'LEXPRO_EG_USER_EMID';
export const kSharedPrefNameSpace = 'com.rjs.lexulous';

export type legacyDataType = {
    guid?: string,
    primaryPrefferedLogin?: string,
    secondaryPrefferedLogin?: string,
};

export type authRespData = {
    guid: string,
    uuid: string,
};

export type MergedStatus = {
    merged: Array<authRespData>,
    unmerged: Array<authRespData>,
};

export type MergedAccountGameStats = {
    activegamecnt: number,
    profile: ?ProfileInfo,
};

class LegacyCoordinator {
    legacyData: ?legacyDataType = null;
    emailLoginInfoData: ?LXLSLoginInfo = null;
    showMultipleAccountSelection: ?() => void;
    uiDelegateMultipleAccountSelection: ?(?() => React$Element<typeof MultipleAccountSelectionContainer>) => Promise<void>;

    constructor() {
        this.onAppInit();
    }

    onAppInit = (): void => {
        userDefault.setName(kSharedPrefNameSpace);
        this.onDestroy();
        this.refreshLegacyData();
        this.showMultipleAccountSelection = null;
        this.uiDelegateMultipleAccountSelection = null;
    };

    onDestroy = (): void => {
        this.legacyData = null;
        this.emailLoginInfoData = null;
    };

    resetUiDelegate = async (): Promise<void> => {
        if (this.uiDelegateMultipleAccountSelection) {
            await this.uiDelegateMultipleAccountSelection(null);
        }
    };

    refreshLegacyData = async () => {
        let ldata: legacyDataType = await this.getStoredValuesForOnboardingProc();
        this.legacyData = ldata;

        let emdata: LXLSLoginInfo = await this.getStoredLexEmailAuthData();
        this.emailLoginInfoData = emdata;

        return true;
    };

    getStoredValuesForOnboardingProc = async (): Promise<legacyDataType> => {
        let pkey = await userDefault.get(kPreInstalledKey);
        let data: legacyDataType = {};
        if (pkey != null && pkey !== undefined) {
            data.guid = JSON.parse(JSON.stringify(pkey));
        }
        ////////////////////////////////////////
        let reqdata = [kLegacyPrimaryPrefferedLogin, kLegacySecondaryPrefferedLogin];
        await userDefault.setName('USER_SETTINGS_FILE_NAME');
        let result = await userDefault.getMultiple(reqdata);
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    switch (reqdata[index]) {
                        case kLegacyPrimaryPrefferedLogin:
                            {
                                let found = JSON.parse(JSON.stringify(value));
                                if (found != null || found != undefined) {
                                    data.primaryPrefferedLogin = '1';
                                } else {
                                    data.primaryPrefferedLogin = '0';
                                }
                            }
                            break;
                        case kLegacySecondaryPrefferedLogin:
                            {
                                let found = JSON.parse(JSON.stringify(value));
                                if (found != null || found != undefined) {
                                    data.secondaryPrefferedLogin = '2';
                                } else {
                                    data.secondaryPrefferedLogin = '0';
                                }
                            }
                            break;
                    }
                }
            });
        }
        await userDefault.setName(kSharedPrefNameSpace);
        return data;
    };

    isMaidenInstall = (): boolean => {
        if (this.legacyData == null || this.legacyData == undefined) {
            return true;
        } else {
            let preinstalled = this.legacyData.guid;
            let legacyeminstall = this.legacyData.primaryPrefferedLogin;
            let legacyfbinstall = this.legacyData.secondaryPrefferedLogin;
            if (
                (preinstalled == null || preinstalled == undefined) &&
                (legacyeminstall == null || legacyeminstall == undefined) &&
                (legacyfbinstall == null || legacyfbinstall == undefined)
            ) {
                return true;
            }
        }
        return false;
    };

    wasPreInstalled = (): boolean => {
        if (this.legacyData == null || this.legacyData == undefined) {
            return false;
        } else {
            let preinstalled = this.legacyData.guid;
            if (preinstalled != null || preinstalled != undefined) {
                return true;
            }
        }
        return false;
    };

    wasInstalledOverLegacy = (): boolean => {
        if (this.legacyData == null || this.legacyData == undefined) {
            return false;
        } else {
            let legacyprimary = this.legacyData.primaryPrefferedLogin;
            let legacysecondary = this.legacyData.secondaryPrefferedLogin;
            if ((legacyprimary != null || legacyprimary != undefined) && legacyprimary != LoginPrefCode.LxlsNone) {
                return true;
            }
            if ((legacysecondary != null || legacysecondary != undefined) && legacysecondary != LoginPrefCode.LxlsNone) {
                return true;
            }
        }
        return false;
    };

    onboardUserPathCode = async (): Promise<number> => {
        await this.refreshLegacyData();
        let maideninstall = this.isMaidenInstall();
        let waspreinstalled = this.wasPreInstalled();
        let wasinstalledoverlegacy = this.wasInstalledOverLegacy();
        let pathcode = LegacyOnboardPathCode.Normal;
        if (maideninstall || waspreinstalled) {
            pathcode = LegacyOnboardPathCode.Normal;
        } else if (wasinstalledoverlegacy) {
            pathcode = LegacyOnboardPathCode.Merge;
        }
        return pathcode;
    };

    getLegacyLoginMediums = (): Array<string> => {
        let lgnmediums: Array<string> = [];
        if (this.legacyData != null && this.legacyData != undefined) {
            let legacyprimary = this.legacyData.primaryPrefferedLogin;
            let legacysecondary = this.legacyData.secondaryPrefferedLogin;
            if ((legacyprimary != null || legacyprimary != undefined) && legacyprimary != LoginPrefCode.LxlsNone) {
                lgnmediums.push(legacyprimary);
            }
            if ((legacysecondary != null || legacysecondary != undefined) && legacysecondary != LoginPrefCode.LxlsNone) {
                lgnmediums.push(legacysecondary);
            }
        }
        return lgnmediums; //'0'|'1'|'2'
    };

    //entry point
    doOnboardUser = () => {
        if (netManager.isConnected()) {
            let lgnmediums: Array<string> = this.getLegacyLoginMediums();
            if (lgnmediums.length > 0) {
                if (lgnmediums.length > 1) {
                    // MERGE CONDITION
                    this.doMergeOrSelectGuid();
                } else {
                    switch (lgnmediums[0]) {
                        case LoginPrefCode.LxlsEmail:
                            this.doOnboardLexEmailUser();
                            break;
                        case LoginPrefCode.LxlsFB:
                            {
                                let callback = () => {
                                    this.doOnboardFBUser();
                                };
                                fbLgnMgr.checkLoginSilentMode(callback);
                            }
                            break;
                    }
                }
            }
        } else {
            showMessage(translate('err_code_008'), 'legacy_coordinator');
        }
    };

    doStoreDataForLoginTransfer = (guid: string, uuid: string, psistdata: ?LXLSLoginInfo) => {
        requestManager.updatePsistDataGuidUuid(guid, uuid);
        if (psistdata != null && psistdata != undefined) {
            lxlsLgnMgr.storeLoginInfo(psistdata);
        }

        this.resetUiDelegate().then(() => {
            this.onAppInit();
            RootNavigation.navigationRef.current?.reset({
                index: 0,
                routes: [{ name: 'AppSplash' }],
            });
        });
    };

    doMergeOrSelectGuid = async () => {
        let emaillgninfo: ?LXLSLoginInfo = this.emailLoginInfoData;
        let promises: Array<AxiosPromise<ServerResponse>> = [];
        if (
            emaillgninfo != null &&
            emaillgninfo != undefined &&
            emaillgninfo.authuser != null &&
            emaillgninfo.authuser != undefined &&
            emaillgninfo.authsecret != null &&
            emaillgninfo.authsecret != undefined
        ) {
            let username: string = emaillgninfo.authuser;
            let pwd: string = emaillgninfo.authsecret;
            let authdata = this.getLexEmailAuthData(username, pwd);
            let p1: AxiosPromise<ServerResponse> = requestManager.getGuidUuid(authdata);
            promises.push(p1);
        }
        //-------------------------------------------------------------------------
        let fbloggedin: boolean = await fbLgnMgr.checkLoginSilentModeAsync();
        let fblogininfo = dataServer.getFbLoginInfo();
        if (
            fblogininfo != null &&
            fblogininfo != undefined &&
            fblogininfo.fbAccessToken !== null &&
            fblogininfo.fbAccessToken !== undefined
        ) {
            let userid: string = fblogininfo.fbAccessToken.userID;
            let accessToken: string = fblogininfo.fbAccessToken.accessToken;
            let authdata = this.getFBAuthData(userid, accessToken);
            let p2: AxiosPromise<ServerResponse> = await requestManager.getGuidUuid(authdata);
            promises.push(p2);
        }
        //-------------------------------------------------------------------------
        let legcyrsp: Array<LegacyAuthResponse> = [];
        let result: AxiosResponse<ServerResponse, any>[] = await Promise.all(promises);
        result.forEach((resp, index) => {
            let p: ServerResponse = resp.data;

            if (p.check === CONSTANTS.kSuccess) {
                let uu: LegacyAuthResponse = ((p.data: any): LegacyAuthResponse);
                uu.piggyback = p.piggyback;
                if (p.piggyback == CONSTANTS.kPlatformLexCom) {
                    if (uu.lexcom != null && uu.lexcom != undefined) {
                        let mediumdata: Array<string> = Object.keys(uu.lexcom);
                        let uid = mediumdata[0];
                        if (emaillgninfo != null && emaillgninfo != undefined) {
                            emaillgninfo.uid = uid;
                        }
                    }
                }
                legcyrsp.push(uu);
            } else {
            }
        });
        let mergedstatus: MergedStatus = this.getGuidsMergedStatus(legcyrsp);
        let anyoneaccismerged = mergedstatus.merged.length == 1;
        let noneismergedaccount = mergedstatus.merged.length == 0;
        if (noneismergedaccount) {
            //THESE ACCOUNT WILL BE MERGED INTO ONE
            //AND BOTH SOCIAL LOGINS WILL BE PRESERVED
            //USER WILL ALAWAYS BE SWITCHED TO LXLS ACCOUNT WITH OTHER ACCOUNT MERGED TO IT
            //USERS OTHER DEVICE WITH THE DELECTED GUID WILL FAIL ONCE

            let primaryacc: ?authRespData = mergedstatus.unmerged.find((auth: authRespData) => {
                if (
                    fblogininfo != null &&
                    fblogininfo != undefined &&
                    fblogininfo.fbAccessToken !== null &&
                    fblogininfo.fbAccessToken !== undefined
                ) {
                    let hasmedium: ?authRespData = this.guidHasLoginMedium(
                        legcyrsp,
                        auth.guid,
                        fblogininfo.fbAccessToken.userID,
                        CONSTANTS.kPlatformFB
                    );
                    if (hasmedium != null) {
                        return true;
                    }
                }
                return false;
            });

            if (primaryacc != null) {
                let selectedacc: authRespData = primaryacc;

                if (
                    emaillgninfo != null &&
                    emaillgninfo != undefined &&
                    emaillgninfo.authuser != null &&
                    emaillgninfo.authuser != undefined &&
                    emaillgninfo.authsecret != null &&
                    emaillgninfo.authsecret != undefined &&
                    emaillgninfo.uid != null &&
                    emaillgninfo.uid != undefined
                ) {
                    requestManager.updatePsistDataGuidUuid(selectedacc.guid, selectedacc.uuid);
                    let usrpfl = {
                        guid: selectedacc.guid,
                        uuid: selectedacc.uuid,
                    };
                    dataServer.getStore().dispatch(actionSetProfile(usrpfl));
                    dataServer.getStore().dispatch(actionLNRUpdateLgnInfo(emaillgninfo));
                    loginCoordinator.lgnMgr = lxlsLgnMgr;
                    let onLoginCompletion = () => {
                        this.resetUiDelegate().then(() => {
                            this.onAppInit();
                            RootNavigation.navigationRef.current?.reset({
                                index: 0,
                                routes: [{ name: 'AppSplash' }],
                            });
                        });
                    };
                    await loginCoordinator.onLXLSDotComLogin(onLoginCompletion);
                } else {
                    showMessage(translate('err_code_002'), 'legacy_coordinator');
                }
            } else {
                showMessage(translate('err_code_001'), 'legacy_coordinator');
            }
        } else if (anyoneaccismerged) {
            //HANDLE ANY ONE ACCOUNT IS MERGED
            let mrgedacc: authRespData = mergedstatus.merged[0];
            let guid = mrgedacc.guid;
            let uuid = mrgedacc.uuid;

            if (
                emaillgninfo != null &&
                emaillgninfo != undefined &&
                emaillgninfo.authuser != null &&
                emaillgninfo.authuser != undefined &&
                emaillgninfo.authsecret != null &&
                emaillgninfo.authsecret != undefined &&
                emaillgninfo.uid != null &&
                emaillgninfo.uid != undefined
            ) {
                let hasmedium = this.guidHasLoginMedium(legcyrsp, guid, emaillgninfo.uid, CONSTANTS.kPlatformLexCom);
                if (hasmedium != null) {
                    lxlsLgnMgr.storeLoginInfo(emaillgninfo);
                } else {
                    // logout apple or google
                    await gglLgnMgr.doSignOut();
                }
            }

            if (
                fblogininfo != null &&
                fblogininfo != undefined &&
                fblogininfo.fbAccessToken !== null &&
                fblogininfo.fbAccessToken !== undefined
            ) {
                let hasmedium = this.guidHasLoginMedium(
                    legcyrsp,
                    guid,
                    fblogininfo.fbAccessToken.userID,
                    CONSTANTS.kPlatformFB
                );
                if (hasmedium == null) {
                    fbLgnMgr.doSignOut(null);
                }
            }

            requestManager.updatePsistDataGuidUuid(guid, uuid);
            this.resetUiDelegate().then(() => {
                this.onAppInit();
                RootNavigation.navigationRef.current?.reset({
                    index: 0,
                    routes: [{ name: 'AppSplash' }],
                });
            });
        } else {
            //BOTH ACCOUNTS ARE MERGED
            //fetch active game count for both accounts
            let mrgedacc1: authRespData = mergedstatus.merged[0];
            let mrgedacc2: authRespData = mergedstatus.merged[1];
            let activecnt1: MergedAccountGameStats = await this.getActiveGameCount(mrgedacc1.guid, mrgedacc1.uuid);
            let activecnt2: MergedAccountGameStats = await this.getActiveGameCount(mrgedacc2.guid, mrgedacc2.uuid);
            let handleGuidSelection = (selectedacc: authRespData) => {
                let guid = selectedacc.guid;
                let uuid = selectedacc.uuid;
                if (this.uiDelegateMultipleAccountSelection) {
                    this.uiDelegateMultipleAccountSelection(null);
                }
                if (
                    emaillgninfo != null &&
                    emaillgninfo != undefined &&
                    emaillgninfo.authuser != null &&
                    emaillgninfo.authuser != undefined &&
                    emaillgninfo.authsecret != null &&
                    emaillgninfo.authsecret != undefined &&
                    emaillgninfo.uid != null &&
                    emaillgninfo.uid != undefined
                ) {
                    let hasmedium = this.guidHasLoginMedium(legcyrsp, guid, emaillgninfo.uid, CONSTANTS.kPlatformLexCom);
                    if (hasmedium != null) {
                        lxlsLgnMgr.storeLoginInfo(emaillgninfo);
                    } else {
                        // logout apple or google
                        gglLgnMgr.doSignOut();
                    }
                }

                if (
                    fblogininfo != null &&
                    fblogininfo != undefined &&
                    fblogininfo.fbAccessToken !== null &&
                    fblogininfo.fbAccessToken !== undefined
                ) {
                    let hasmedium = this.guidHasLoginMedium(
                        legcyrsp,
                        guid,
                        fblogininfo.fbAccessToken.userID,
                        CONSTANTS.kPlatformFB
                    );
                    if (hasmedium == null) {
                        fbLgnMgr.doSignOut(null);
                    }
                }

                requestManager.updatePsistDataGuidUuid(guid, uuid);
                this.resetUiDelegate().then(() => {
                    this.onAppInit();
                    RootNavigation.navigationRef.current?.reset({
                        index: 0,
                        routes: [{ name: 'AppSplash' }],
                    });
                });
            };
            let showSelectOption = (): React$Element<typeof MultipleAccountSelectionContainer> => {
                const accountselectiondata = [
                    {
                        avtar: activecnt1.profile?.avtar ?? CONSTANTS.Default_Avtar,
                        username: activecnt1.profile?.name ?? CONSTANTS.Default_name,
                        accinfo: mrgedacc1,
                        activegames: activecnt1.activegamecnt.toString(),
                    },
                    {
                        avtar: activecnt2.profile?.avtar ?? CONSTANTS.Default_Avtar,
                        username: activecnt2.profile?.name ?? CONSTANTS.Default_name,
                        accinfo: mrgedacc2,
                        activegames: activecnt2.activegamecnt.toString(),
                    },
                ];
                return (
                    <MultipleAccountSelectionContainer
                        didSelectedAccount={handleGuidSelection}
                        AccountData={accountselectiondata}
                    />
                );
            };
            if (mrgedacc1.guid != mrgedacc2.guid) {
                if (this.uiDelegateMultipleAccountSelection) {
                    this.uiDelegateMultipleAccountSelection(showSelectOption);
                }
            } else {
                handleGuidSelection(mrgedacc1);
            }
        }
    };

    getGuidsMergedStatus = (lgninfo: Array<LegacyAuthResponse>): MergedStatus => {
        //[{"lexcom":{"3":{"guid":"638310641730","uuid":"7697a577-f193-46a6-a309-7013d2559b78"}},"fb":{"1337660664":{"guid":"638310641730","uuid":"7697a577-f193-46a6-a309-7013d2559b78"}}},{"lexcom":{"20414317":{"guid":"812350008081","uuid":"8685dca3-1eec-4198-97ae-b4ae392299a6"}},"fb":{"1227949774":{"guid":"812350008081","uuid":"8685dca3-1eec-4198-97ae-b4ae392299a6"}}}]
        let merged: Array<authRespData> = [];
        let unmerged: Array<authRespData> = [];
        lgninfo.forEach((info) => {
            let lgncnt: number = 0;
            let authrsp: ?authRespData = null;
            if (info.lexcom != null && info.lexcom != undefined) {
                authrsp = info.lexcom[Object.keys(info.lexcom)[0]];
                lgncnt++;
            }
            if (info.fb != null && info.fb != undefined) {
                authrsp = info.fb[Object.keys(info.fb)[0]];
                lgncnt++;
            }
            if (info.gglid != null && info.gglid != undefined) {
                authrsp = info.gglid[Object.keys(info.gglid)[0]];
                lgncnt++;
            }
            if (authrsp != null && authrsp != undefined) {
                if (lgncnt > 1) {
                    merged.push(authrsp);
                } else {
                    unmerged.push(authrsp);
                }
            }
        });
        return {
            merged: merged,
            unmerged: unmerged,
        };
    };

    guidHasLoginMedium = (lgninfo: Array<LegacyAuthResponse>, guid: string, uid: string, acctype: string): ?authRespData => {
        let found: ?LegacyAuthResponse = null;

        found = lgninfo.find((info) => {
            try {
                return info[acctype][uid].guid == guid;
            } catch (error) {
                handleException(error);
            }
            return false;
        });

        return found?.[acctype]?.[uid] ?? null;
    };

    //====================================EMAIL USER RELATED==========================================
    getStoredLexEmailAuthData = async (): Promise<LXLSLoginInfo> => {
        let reqdata = [kLegacyLexEmailAuthUser, kLegacyLexEmailAuthSecret, kLegacyLexEmail];
        await userDefault.setName('USER_SETTINGS_FILE_NAME');
        let result = await userDefault.getMultiple(reqdata);
        let data: LXLSLoginInfo = {};
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    switch (reqdata[index]) {
                        case kLegacyLexEmailAuthUser:
                            data.authuser = JSON.parse(JSON.stringify(value));
                            break;
                        case kLegacyLexEmailAuthSecret:
                            data.authsecret = JSON.parse(JSON.stringify(value));
                            break;
                        case kLegacyLexEmail:
                            data.email = JSON.parse(JSON.stringify(value));
                            break;
                    }
                }
            });
        }
        await userDefault.setName(kSharedPrefNameSpace);
        return data;
    };

    getLexEmailAuthData = (username: string, pwd: string): LegacyAuthData => {
        return {
            lexcom: {
                authuser: username,
                authsecret: pwd,
            },
            piggyback: CONSTANTS.kPlatformLexCom,
        };
    };

    doOnboardLexEmailUser = () => {
        let tt: ?LXLSLoginInfo = this.emailLoginInfoData;
        if (
            tt != null &&
            tt != undefined &&
            tt.authuser != null &&
            tt.authuser != undefined &&
            tt.authsecret != null &&
            tt.authsecret != undefined
        ) {
            let username: string = tt.authuser;
            let pwd: string = tt.authsecret;
            let authdata = this.getLexEmailAuthData(username, pwd);
            let p1: AxiosPromise<ServerResponse> = requestManager.getGuidUuid(authdata);

            p1.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((jresp: ServerResponse) => {
                    if (jresp.check === CONSTANTS.kSuccess) {
                        let authresp: LegacyAuthResponse = ((jresp.data: any): LegacyAuthResponse);
                        let isempty = Object.keys(authresp).length === 0 && authresp.constructor === Object;
                        if (!isempty) {
                            if (authresp.lexcom != null && authresp.lexcom != undefined) {
                                let mediumdata: Array<string> = Object.keys(authresp.lexcom);
                                let emuid = mediumdata[0];
                                let guid = authresp.lexcom[emuid].guid;
                                let uuid = authresp.lexcom[emuid].uuid;
                                this.doStoreDataForLoginTransfer(guid, uuid, this.emailLoginInfoData);
                            }
                        }
                    } else {
                        showMessage(translate('err_code_006'), 'legacy_coordinator');
                    }
                })
                .catch((error) => {
                    showMessage(translate('err_code_003'), 'legacy_coordinator');
                });
        }
    };

    //====================================END EMAIL USER RELATED======================================

    //====================================FB USER RELATED==========================================

    getFBAuthData = (userid: string, token: string): LegacyAuthData => {
        return {
            fb: {
                fb_sig_user: userid,
                fb_sig_session_key: token,
            },
            piggyback: CONSTANTS.kPlatformFB,
        };
    };

    doOnboardFBUser = () => {
        let tt: ?FBLoginInfo = dataServer.getFbLoginInfo();
        if (tt != null && tt != undefined && tt.fbAccessToken !== null && tt.fbAccessToken !== undefined) {
            let userid: string = tt.fbAccessToken.userID;
            let accessToken: string = tt.fbAccessToken.accessToken;
            let authdata = this.getFBAuthData(userid, accessToken);
            let p1: AxiosPromise<ServerResponse> = requestManager.getGuidUuid(authdata);

            p1.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((jresp: ServerResponse) => {
                    if (jresp.check === CONSTANTS.kSuccess) {
                        let authresp: LegacyAuthResponse = ((jresp.data: any): LegacyAuthResponse);
                        let isempty = Object.keys(authresp).length === 0 && authresp.constructor === Object;
                        if (!isempty) {
                            if (authresp.fb != null && authresp.fb != undefined) {
                                let mediumdata: Array<string> = Object.keys(authresp.fb);
                                let fbid = mediumdata[0];
                                let guid = authresp.fb[fbid].guid;
                                let uuid = authresp.fb[fbid].uuid;
                                this.doStoreDataForLoginTransfer(guid, uuid, null);
                            }
                        }
                    } else {
                        showMessage(translate('err_code_007'), 'legacy_coordinator');
                    }
                })
                .catch((error) => {
                    showMessage(translate('err_code_004'), 'legacy_coordinator');
                });
        } else {
            showMessage(translate('err_code_005'), 'legacy_coordinator');
        }
    };

    //====================================END FB USER RELATED=========================================

    getActiveGamesList = (guid: string, uuid: string): AxiosPromise<ServerResponse> => {
        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: guid,
            [CONSTANTS.kParamUuid]: uuid,
        };

        let action = { [CONSTANTS.kParamAction]: 'gameslist' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });
        rjLog(params, 'getActiveGamesList');
        return requestManager.axiosinst({
            url: CONSTANTS.kGamesListApiPath,
            data: params,
        });
    };

    getActiveGameCount = async (guid: string, uuid: string): Promise<MergedAccountGameStats> => {
        let activegamecnt: number = 0;
        let profile: ?ProfileInfo = null;
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let response: AxiosResponse<ServerResponse, any> = await this.getActiveGamesList(guid, uuid);
            dataServer.debouncedDispatch(actionSetIdle());
            if (response.status == CONSTANTS.HTTPSuccessStatus) {
                let jresp: ServerResponse = response.data;
                if (jresp.check === CONSTANTS.kSuccess) {
                    let glrespdata: GamesListResponse = ((jresp.data: any): GamesListResponse);
                    activegamecnt = glrespdata.games.length;
                    profile = glrespdata.uid[guid];
                }
            }
        }
        return { activegamecnt, profile };
    };
}

const legacyCoordinator: LegacyCoordinator = new LegacyCoordinator();

export default legacyCoordinator;
