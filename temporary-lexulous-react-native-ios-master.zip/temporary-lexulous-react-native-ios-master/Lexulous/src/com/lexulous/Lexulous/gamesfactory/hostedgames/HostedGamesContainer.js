// @flow

import React from 'react';
import { connect } from 'react-redux';
import { StyleSheet, Text, View, SectionList, Platform, Image, Pressable } from 'react-native';
import * as CONSTANTS from '../../commons/Constants';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import type { HostedGames, WinLossStatsBarType, ServerResponse, HostedGameElement } from '../../commons/RJTypes';
import type { NavigationProp } from '@react-navigation/native';
import appConfiguration from '../../commons/AppConfiguration';
import { translate } from '../../commons/translations/LangTransator';
import WinLossStatsBarContainer from '../../stats/statsprofile/WinLossStatsBarContainer';
import FndElementView from '../../friends/FndElementView';
import interstitialAd from '../../commons/ads/InterstitialAd';
import rjAnalytics from '../../../../../RJAnalytics';
import dataServer from '../../store/Store';
import hostedGamesApi from '../hostedgames/HostedGamesApi';
import netManager from '../../commons/RJNetInfo';
import type { AxiosPromise, AxiosResponse } from 'axios';
import * as PFLSelector from '../../userprofile/PFLSelector';
import { actionSetIdle, actionSetBusy } from '../../commons/RJTypes';
import themeConfigutation from '../../commons/ThemeConfiguration';
import Config from '../../../../../configs/Config';

type HostedGamesContainerType = {
    hostedGames: HostedGames,
    navigation: NavigationProp,
    hostGameAction: (item: HostedGameElement) => void,
};

class HostedGamesContainer extends React.Component<HostedGamesContainerType> {
    sectionListWindowSize: number = CONSTANTS.SectionListWindowSize.For_Native;
    loggedinGuid = PFLSelector.getGUID(dataServer.getStore().getState());
    constructor(props: HostedGamesContainerType) {
        super(props);
    }

    componentDidMount = () => {
        let updateSectionListWndwSize = Platform.select({
            native: () => null,
            default: () => {
                let source: string | null = appConfiguration.getApplicationSource();
                if (source != null) {
                    if (source == CONSTANTS.kDeskTopApp || source == CONSTANTS.kFBInstantApp) {
                        this.sectionListWindowSize = CONSTANTS.SectionListWindowSize.For_Web;
                    }
                }
            },
        });
        updateSectionListWndwSize();
    };

    deleteHostedGame = (item) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = hostedGamesApi.deleteHostedGames(item.gamereqid);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((res: ServerResponse) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    if (res.check === CONSTANTS.kSuccess) {
                        hostedGamesApi.getHostedGamesList();
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    console.log('Error while Deleting hosted games...');
                });
        }
    };

    onImagePress = (guid: string) => {
        rjAnalytics.sendAnalyticsEvent('hosted_game_opened', 'new_game_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + guid } });
    };

    renderIconSection = (item: HostedGameElement) => {
        let renderPlyrNum = () => {
            if (Number(item.numplys) > 2) {
                return (
                    <View style={[styles.iconStyle, { backgroundColor: '#9C00D7' }]}>
                        <Text style={{ color: 'white', fontSize: 8 }}>{item.numplys}</Text>
                    </View>
                );
            } else return <View style={[styles.iconStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}></View>;
        };

        let renderGameType = () => {
            if (item.gametype == 'EC') {
                return (
                    <View style={[styles.iconStyle, { backgroundColor: '#D41414' }]}>
                        <Text style={{ color: 'white', fontSize: 8 }}>C</Text>
                    </View>
                );
            } else return <View style={[styles.iconStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}></View>;
        };

        let renderDaysPerTurn = () => {
            return (
                <View style={styles.iconStyle}>
                    <Text
                        style={{
                            color: themeConfigutation.getColor('#000'),
                            fontSize: 8,
                            textDecorationLine: 'underline',
                            fontWeight: 'bold',
                        }}
                    >
                        {item.fftdays}
                    </Text>
                </View>
            );
        };

        let renderDicType = () => {
            let dicIcon = 'S';
            let IconColor = '#32A373';
            switch (item.dic) {
                case CONSTANTS.US_English:
                    dicIcon = 'T';
                    IconColor = '#9C00D7';
                    break;
                case CONSTANTS.UK_English:
                    dicIcon = 'S';
                    IconColor = '#32A373';
                    break;
                case CONSTANTS.Italian:
                    dicIcon = 'I';
                    IconColor = '#F0A869';
                    break;
                case CONSTANTS.French:
                    dicIcon = 'F';
                    IconColor = '#F0A869';
                    break;
                default:
                    dicIcon = 'S';
                    IconColor = '#32A373';
                    break;
            }
            return (
                <View style={[styles.iconStyle, { backgroundColor: IconColor }]}>
                    <Text style={{ color: 'white', fontSize: 8 }}>{dicIcon}</Text>
                </View>
            );
        };

        return (
            <View style={styles.iconContainer}>
                {renderPlyrNum()}
                {renderGameType()}
                {renderDaysPerTurn()}
                {renderDicType()}
            </View>
        );
    };

    renderPlayAndDeleteBtn = (item: HostedGameElement) => {
        let isMyHostedGame = item.uid.guid == this.loggedinGuid;
        let btnColor = '#1d9df1';
        let btnText = translate('play');
        let action = () => {
            this.props.hostGameAction(item);
        };

        if (isMyHostedGame) {
            btnColor = '#BE333C';
            btnText = translate('del_acc');
            action = () => {
                this.deleteHostedGame(item);
            };
        }
        if (item.jndplys !== null && item.jndplys != undefined && item.jndplys.length > 0) {
            let hasJoinedGame = item.jndplys.filter((i) => this.loggedinGuid == i.guid).length > 0;
            if (hasJoinedGame) {
                btnColor = '#BE333C';
                btnText = translate('leave');
                action = () => {
                    this.props.hostGameAction(item);
                };
            }
        }

        return (
            <Pressable
                style={[
                    styles.buttonStyle,
                    {
                        backgroundColor: btnColor,
                    },
                ]}
                onPress={action}
            >
                <Text style={{ textAlign: 'center', color: 'white' }}>{btnText}</Text>
            </Pressable>
        );
    };

    renderItem = ({ item }) => {
        let statdata: WinLossStatsBarType = {};
        let name = item.uid.name;

        let avtar = item.uid.avtar ?? '1';
        let timg: number | {| uri: string |} = item.uid.picurl ? { uri: item.uid.picurl } : CONSTANTS.avtarIcons[avtar];

        let rating = item.rating ?? '1500';
        let played = item.played ?? '0';
        let won = item.won ?? '0';
        let lost = item.lost ?? '0';
        let drawn = item.drawn ?? '0';
        let bingos = item.bingo_count ?? '0';

        statdata = {
            won: Number(won),
            lost: Number(lost),
            drawn: Number(drawn),
            games: Number(played),
            bingos: Number(bingos),
        };

        let iconNbtnStyle = () => {
            return Platform.select({
                native: {
                    paddingLeft: 12,
                    flexDirection: 'column',
                    justifyContent: 'space-evenly',
                    alignItems: 'flex-end',
                },
                default: { flexDirection: 'row', justifyContent: 'flex-end' },
            });
        };

        return (
            <View style={styles.mainContainer}>
                <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Pressable
                        style={{ alignSelf: 'center' }}
                        onPress={() => {
                            interstitialAd.showInterstitialAd(true, () => {
                                if (item.uid.guid !== null && item.uid.guid !== undefined) {
                                    this.onImagePress(item.uid.guid);
                                }
                            });
                        }}
                    >
                        <Image
                            source={timg}
                            style={[styles.imgStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                        />
                    </Pressable>
                    <View style={[styles.contentStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                        <Text numberOfLines={0} style={[styles.nameStyle, { color: themeConfigutation.getColor('#000') }]}>
                            {name}
                            <Text> </Text>
                            <Text style={{ fontSize: 16 }}>({rating})</Text>
                        </Text>
                        <WinLossStatsBarContainer statdata={statdata} isForHostedGame={true} />
                    </View>
                </View>
                <View style={iconNbtnStyle()}>
                    {this.renderIconSection(item)}
                    {this.renderPlayAndDeleteBtn(item)}
                </View>
            </View>
        );
    };

    renderHeaderItem = ({ section: { title } }) => (
        <Text
            style={[
                styles.header,
                { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#000') },
            ]}
        >
            {translate(title)}
        </Text>
    );

    extractKey = (item, index) => item + index;

    render() {
        let noHostedGames = this.props.hostedGames.hostedGames[0].data.length > 0;
        if (noHostedGames) {
            return (
                <SectionList
                    sections={(this.props.hostedGames.hostedGames: any)}
                    renderItem={this.renderItem}
                    keyExtractor={this.extractKey}
                    renderSectionHeader={this.renderHeaderItem}
                    ItemSeparatorComponent={separator}
                    ListEmptyComponent={this.renderMsg}
                    ItemSeparatorComponent={separator}
                    ListFooterComponent={separator}
                    windowSize={this.sectionListWindowSize}
                    stickySectionHeadersEnabled
                    style={[styles.width100, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                />
            );
        } else return null;
    }

    renderMsg = () => {
        return (
            <View style={styles.msgStyle}>
                <Text style={{ color: themeConfigutation.getColor('#000') }}>{translate('no_Games_Msg')}</Text>
            </View>
        );
    };
}

const separator = () => {
    return <View style={styles.seperatorStyle} />;
};

const styles = StyleSheet.create({
    mainContainer: {
        width: '100%',
        flexDirection: 'row',
        padding: 4,
        paddingRight: 16,
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    container: {
        paddingLeft: 8,
        paddingVertical: 4,
        flexDirection: 'row',
        ...Platform.select({
            native: { flex: 1 },
            default: { flexGrow: 1 },
        }),
    },
    header: {
        fontSize: 12,
        paddingLeft: 10,
        paddingTop: 4,
        paddingBottom: 4,
    },
    msgStyle: {
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    contentStyle: {
        ...Platform.select({
            native: { flex: 4 },
            default: { flexGrow: 1 },
        }),
        justifyContent: 'center',
    },
    imgStyle: {
        width: 30,
        height: 30,
        marginRight: 8,
    },
    nameStyle: {
        marginBottom: 1,
        fontSize: 18,
        paddingLeft: 8,
    },
    width100: { flex: 1, width: '100%' },
    seperatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
    buttonStyle: {
        width: 80,
        justifyContent: 'center',
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderRadius: 2,
    },
    iconContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
        ...Platform.select({
            native: { paddingBottom: 4 },
            default: {
                paddingHorizontal: 8,
            },
        }),
    },
    iconStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 12,
        height: 12,
        marginHorizontal: 2,
    },
});

function mapStateToProps(state) {
    const { hostedGames, utils } = state;
    return { hostedGames, utils };
}

export default connect(mapStateToProps, null)(HostedGamesContainer);
