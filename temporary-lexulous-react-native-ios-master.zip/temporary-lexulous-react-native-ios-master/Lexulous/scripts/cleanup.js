const fs = require('fs');

let isEnvFileExist = fs.existsSync('.env');
let isGoogleJonExist = fs.existsSync('./android/app/google-services.json');
let isGooglePlistExits = fs.existsSync('./ios/GoogleService-Info.plist');
let isIndexHtmlExist = fs.existsSync('index.html');
let isNativeGameConfigExist = fs.existsSync('./src/configs/NativeGameConfig.js');

try {
    if (isEnvFileExist) {
        fs.unlinkSync('.env', (err) => {
            if (err) throw err;
        });
    }

    if (isGoogleJonExist) {
        fs.unlinkSync('./android/app/google-services.json', (err) => {
            if (err) throw err;
        });
    }

    if (isGooglePlistExits) {
        fs.unlinkSync('./ios/GoogleService-Info.plist', (err) => {
            if (err) throw err;
        });
    }

    if (isIndexHtmlExist) {
        fs.unlinkSync('index.html', (err) => {
            if (err) throw err;
        });
    }

    if (isNativeGameConfigExist) {
        fs.unlinkSync('./src/configs/NativeGameConfig.js', (err) => {
            if (err) throw err;
        });
    }

    fs.rmdirSync('dist', { recursive: true }, (err) => {
        if (err) throw err;
    });
    if (!fs.existsSync('dist')) {
        fs.mkdirSync('dist');
    }

    fs.rmdirSync('build', { recursive: true }, (err) => {
        if (err) throw err;
    });
    if (!fs.existsSync('build')) {
        fs.mkdirSync('build');
    }
} catch (err) {
    console.log('clean up error : ' + err);
}
