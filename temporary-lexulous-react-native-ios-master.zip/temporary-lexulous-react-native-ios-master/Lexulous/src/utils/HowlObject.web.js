import { Howl } from 'howler';
import ConfigurationWrapper from './ConfigurationWrapper';

const sound = new Howl({
    src: [
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'sound_sprite_location'
        ),
    ],
    sprite: {
        bingo: [0, 2977.9591836734694],
        clicktile: [3100, 78.36734693877557],
        droptilesound: [4200, 104.48979591836772],
        error: [5300.000000000001, 313.4693877551023],
        gamestartendsound: [6400.000000000001, 626.9387755102036],
        invalid_word: [7500.000000000001, 417.95918367346906],
        message: [8600.000000000002, 261.224489795918],
        opp_submits: [9700.000000000002, 1985.3061224489802],
        recall: [11800.000000000002, 208.97959183673544],
        shuffle: [12900.000000000004, 156.73469387755114],
        user_submits: [14000.000000000004, 1567.3469387755094],
        user_wins_game: [16100.000000000002, 2168.163265306124],
    },
});
class SoundManager {
    isPlaying = () => sound.playing();

    playSound = (soundname) => {
        sound.play(soundname);
    };
}

const HowlObject = new SoundManager();
export default HowlObject;
