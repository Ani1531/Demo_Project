import {
    LOBBY_CHAT_MESSAGE,
    ADD_PVT_MESSAGE_KEY,
    SET_ACTIVE_PVT_MESSAGE_KEY,
    REMOVE_PVT_MESSAGE_KEY,
} from '../configs/ActionIdentifiers';

export const lobbyChatMessage = (res) => async (dispatch, getState) => {
    dispatch({
        type: LOBBY_CHAT_MESSAGE,
        payload: res,
        globalState: getState(),
    });
};

export const setActivePvtMessageKey = (res) => ({
    type: SET_ACTIVE_PVT_MESSAGE_KEY,
    payload: res,
});

export const addPvtMessageKey = (res) => ({
    type: ADD_PVT_MESSAGE_KEY,
    payload: res,
});

export const removePvtMessageKey = (res) => ({
    type: REMOVE_PVT_MESSAGE_KEY,
    payload: res,
});
