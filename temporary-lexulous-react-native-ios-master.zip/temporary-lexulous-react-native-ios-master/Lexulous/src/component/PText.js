import React from 'react';
import { Text } from 'react-native';
import omit from 'lodash/omit';

export default class PText extends React.Component {
    render = () => (
        <Text
            {...omit(this.props, 'style')}
            style={[{ fontSize: 12 }, this.props.style]}
        />
    );
}
