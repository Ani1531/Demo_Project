// @flow

import type {
    GamesListResponse,
    ActionRefreshGames,
    ActionGLRefreshStarted,
    ActionReviewShareUpdateData,
    ReviewShareUpdateData,
    ActionGLRefreshFinished,
    ActionGLClearData,
    ActionGLClearRvwShrData,
    ActionGLAdEvent,
    ActionGLReadChatEvent,
    gidType,
    ProfileInfo,
    GameListUpdateData,
    ActionGLUpdate,
    ActionGLUpdtViaBoardInfo,
    GlUpdtViaBoardInfoData,
} from '../commons/RJTypes';

import {
    ADD_GAMES,
    CLR_GAMES,
    GL_REFRESH_STARTED,
    GL_REFRESH_FINISHED,
    UPDT_RVW_SHR,
    CLR_RVW_SHR,
    GL_AD_EVT,
    GL_READ_CHAT,
    GL_SVCCON_ADD_GAME,
    GL_UPDT_VIA_BOARD_INFO,
} from './GLEventTypes';

export const actionAddGames = (data: GamesListResponse, profile: ProfileInfo): ActionRefreshGames => {
    return {
        type: ADD_GAMES,
        payload: data,
        profile: profile,
    };
};

export const glRefreshStarted = (): ActionGLRefreshStarted => {
    return {
        type: GL_REFRESH_STARTED,
    };
};

export const glRefreshFinished = (): ActionGLRefreshFinished => {
    return {
        type: GL_REFRESH_FINISHED,
    };
};

export const glClearData = (): ActionGLClearData => {
    return {
        type: CLR_GAMES,
    };
};

export const glUpdateReviewShareData = (data: ReviewShareUpdateData): ActionReviewShareUpdateData => {
    return {
        type: UPDT_RVW_SHR,
        payload: data,
    };
};

export const glClearReviewShareData = (): ActionGLClearRvwShrData => {
    return {
        type: CLR_RVW_SHR,
    };
};
export const glAdEvent = (data: boolean): ActionGLAdEvent => {
    return {
        type: GL_AD_EVT,
        payload: data,
    };
};

export const actionReadChat = (data: Array<gidType>): ActionGLReadChatEvent => {
    return {
        type: GL_READ_CHAT,
        payload: data,
    };
};

export const svcconGameListUpdate = (data: GameListUpdateData): ActionGLUpdate => {
    return {
        type: GL_SVCCON_ADD_GAME,
        payload: data,
    };
};

export const glViaBoardInfoUpdate = (data: GlUpdtViaBoardInfoData): ActionGLUpdtViaBoardInfo => {
    return {
        type: GL_UPDT_VIA_BOARD_INFO,
        payload: data,
    };
};
