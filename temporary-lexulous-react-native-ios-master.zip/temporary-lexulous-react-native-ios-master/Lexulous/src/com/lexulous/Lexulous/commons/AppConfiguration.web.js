// @flow

import type { AppCfg, SourceType } from './RJTypes';

class AppConfiguration {
    _source: SourceType | null = null;

    constructor() {
        let cfg: AppCfg = window.__app_configuration__ ?? null;
        this._source = cfg?.source ?? null;
    }

    getAppConfiguration = (param: string | null = null): AppCfg | null => {
        let cfg: AppCfg = window.__app_configuration__ ?? null;
        if (cfg != null) {
            if (param != null && param != undefined) {
                return { [param]: cfg[param] };
            } else {
                return cfg;
            }
        }
        return cfg;
    };

    getSharePlugin = (): string | null => {
        let share: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        share = plf?.plugins?.share ?? null;
        return share;
    };

    getFriendsPlugin = (): string | null => {
        let friends: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        friends = plf?.plugins?.friends ?? null;
        return friends;
    };

    getInvitePlugin = (): string | null => {
        let invite: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        invite = plf?.plugins?.invite ?? null;
        return invite;
    };

    getPinappPlugin = (): string | null => {
        let pinapp: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        pinapp = plf?.plugins?.pinapp ?? null;
        return pinapp;
    };

    getPurchasePlugin = (): string | null => {
        let purchase: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        purchase = plf?.plugins?.purchase ?? null;
        return purchase;
    };

    getQuitAppPlugin = (): string | null => {
        let quit: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        quit = plf?.plugins?.quit ?? null;
        return quit;
    };

    getProductProtill = (): string | null => {
        let productId: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        productId = plf?.products?.protill ?? null;
        return productId;
    };

    getProductAnalysetill = (): string | null => {
        let productId: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);

        productId = plf?.products?.analizetill ?? null;

        return productId;
    };

    getApplicationSource = (): SourceType | null => {
        let appsource: AppCfg | null = this.getAppConfiguration('source');
        return appsource?.source ?? null;
    };

    getBlindGamePlugin = (): string | null => {
        let blindGameData: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        blindGameData = plf?.plugins?.blindGame ?? null;
        return blindGameData;
    };

    getOnBlindGameMovePlugin = (): string | null => {
        let onBlindGameMove: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        onBlindGameMove = plf?.plugins?.onBlindGameMove ?? null;
        return onBlindGameMove;
    };

    getUpdateContextStorePlugin = (): string | null => {
        let updateContextStore: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        updateContextStore = plf?.plugins?.updateContextStore ?? null;
        return updateContextStore;
    };

    getNotifyContextStorePlugin = (): string | null => {
        let notifyContextStore: string | null = null;
        let plf: any = this.getAppConfiguration(this._source);
        notifyContextStore = plf?.plugins?.notifyContextStore ?? null;
        return notifyContextStore;
    };
}
const appConfiguration: AppConfiguration = new AppConfiguration();

export default appConfiguration;
