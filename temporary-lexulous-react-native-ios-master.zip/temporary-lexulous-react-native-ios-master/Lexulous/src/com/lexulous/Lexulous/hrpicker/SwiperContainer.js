// @flow

import React from 'react';
import { View, Text, Animated, Dimensions, ScrollView, Image, Pressable, StyleSheet, Platform } from 'react-native';
import LoadingIndicator from '../components/LoadingIndicator';
import { type ScrollEvent } from 'react-native/Libraries/Types/CoreEventTypes';
import { translate } from '../commons/translations/LangTransator';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronRight, faChevronLeft } from '@fortawesome/pro-regular-svg-icons';
import themeConfigutation from '../commons/ThemeConfiguration';
type SwiperContainerprops = {
    userData: { [string]: string },
    themeArr: Array<string>,
    header: string,
    currentSelection: string,
    didSelectedItem: ({ [string]: string }, string) => void,
    themeSource: Object,
};
type SwiperContainerState = {
    currentPage: string,
    isScrolling: boolean,
    isPrevious: boolean,
    dim: any,
    scrollViewRef: any,
};

export default class SwiperContainer extends React.Component<SwiperContainerprops, SwiperContainerState> {
    scrollX = new Animated.Value(0);
    unsubscribeDimensionListener: ?() => void = null;
    constructor(props: SwiperContainerprops) {
        super(props);
        this.state = {
            currentPage: '0',
            isScrolling: false,
            isPrevious: '0' == this.props.currentSelection,
            dim: Dimensions.get('window'),
            scrollViewRef: React.createRef(),
        };
    }

    componentDidMount() {
        this.unsubscribeDimensionListener = Dimensions.addEventListener('change', this.onChange);
    }

    componentWillUnmount() {
        if (this.unsubscribeDimensionListener) {
            this.unsubscribeDimensionListener();
        }
    }

    onChange = (evt: any) => {
        this.setState({ dim: evt.window });
    };

    onThemeselect = (selectedTheme: string) => {
        this.props.didSelectedItem(this.props.userData, selectedTheme);
    };

    handleScroll = (event: ScrollEvent) => {
        this.setState(
            { currentPage: Math.round(parseFloat(event.nativeEvent.contentOffset.x / this.state.dim.width)).toString() },
            () => {
                this.setState({
                    isPrevious: this.state.currentPage == this.props.currentSelection,
                });
            }
        );
    };

    onScrollstart = () => {
        this.setState({
            isScrolling: true,
        });
    };

    onScrollend = () => {
        this.setState({
            isScrolling: false,
        });
    };

    renderHeader = () => {
        return <Text style={[styles.headerText, { color: themeConfigutation.getColor('#000') }]}>{this.props.header}</Text>;
    };

    renderSelector = () => {
        let imageContainerStyle = [
            styles.imageView,
            {
                width: this.state.dim.width,
                height: '100%',
            },
        ];
        if (this.props.header === translate('slct_tthm')) {
            imageContainerStyle.push({ backgroundColor: themeConfigutation.getColor('#fff') });
        }

        return (
            <ScrollView
                horizontal={true}
                pagingEnabled={true}
                showsHorizontalScrollIndicator={false}
                onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: this.scrollX } } }], {
                    useNativeDriver: false,
                    listener: this.handleScroll,
                })}
                onScrollBeginDrag={() => this.onScrollstart()}
                onScrollEndDrag={() => this.onScrollend()}
                scrollEventThrottle={16}
                ref={this.state.scrollViewRef}
            >
                {this.props.themeArr.map((item, index) => {
                    return (
                        <View key={index} style={imageContainerStyle}>
                            <Image resizeMode="contain" source={this.props.themeSource[item]} style={styles.singleImageView} />
                        </View>
                    );
                })}
            </ScrollView>
        );
    };

    renderScrollLeftArrow() {
        let scroll_left_arrow = null;
        if (Platform.OS === 'web') {
            scroll_left_arrow = (
                <Pressable
                    onPress={() => {
                        this.state.scrollViewRef.current.scrollTo({
                            x: this.state.dim.width * (parseInt(this.state.currentPage) - 1),
                        });
                    }}
                    disabled={parseInt(this.state.currentPage) === 0}
                >
                    <FontAwesomeIcon
                        icon={faChevronLeft}
                        size={30}
                        color={this.state.currentPage === '0' ? '#ABB2B9' : themeConfigutation.getColor('#000')}
                    />
                </Pressable>
            );
        }
        return scroll_left_arrow;
    }

    renderScrollRightArrow = () => {
        let scroll_right_arrow = null;
        if (Platform.OS === 'web') {
            let totalScrollItem = this.props.themeArr.length - 1;
            scroll_right_arrow = (
                <Pressable
                    onPress={() => {
                        this.state.scrollViewRef.current.scrollTo({
                            x: this.state.dim.width * (parseInt(this.state.currentPage) + 1),
                        });
                    }}
                    disabled={parseInt(this.state.currentPage) === totalScrollItem}
                >
                    <FontAwesomeIcon
                        icon={faChevronRight}
                        size={30}
                        color={
                            parseInt(this.state.currentPage) === totalScrollItem
                                ? '#ABB2B9'
                                : themeConfigutation.getColor('#000')
                        }
                    />
                </Pressable>
            );
        }
        return scroll_right_arrow;
    };

    renderCurrentPageIndicator = () => {
        let position = Animated.divide(this.scrollX, this.state.dim.width);
        return (
            <View style={[styles.indicatorview, { width: this.state.dim.width }]}>
                {this.props.themeArr.length > 0 &&
                    this.props.themeArr.map((_, i) => {
                        let optrange: Array<number> = [0.3, 1, 0.3];
                        let opacity = position.interpolate({
                            inputRange: [i - 1, i, i + 1],
                            outputRange: optrange,
                            extrapolate: 'clamp',
                        });
                        return (
                            <Animated.View
                                key={i}
                                style={[
                                    styles.indicatorCircle,
                                    { backgroundColor: themeConfigutation.getColor('#444'), opacity: opacity },
                                ]}
                            />
                        );
                    })}
            </View>
        );
    };

    renderButton = () => {
        return (
            <Pressable
                disabled={this.state.isScrolling || this.state.isPrevious}
                onPress={() => {
                    this.onThemeselect(this.state.currentPage.toString());
                }}
                style={[styles.buttonView, { backgroundColor: this.state.isPrevious ? '#ABB2B9' : '#0B4D97' }]}
            >
                <Text style={styles.buttonText}>{translate('select')}</Text>
            </Pressable>
        );
    };

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: themeConfigutation.getColor('#fff') }}>
                <LoadingIndicator />
                {this.renderHeader()}
                {this.renderSelector()}
                {this.renderCurrentPageIndicator()}
                <View style={styles.footerView}>
                    {this.renderScrollLeftArrow()}
                    {this.renderButton()}
                    {this.renderScrollRightArrow()}
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    imageView: {
        padding: 8,
        justifyContent: 'center',
    },
    singleImageView: {
        height: '100%',
        width: '100%',
    },
    indicatorview: {
        flexDirection: 'row',
        height: 10,
        justifyContent: 'center',
        zIndex: 9,
    },
    indicatorCircle: {
        height: 6,
        width: 6,
        margin: 2,
        borderRadius: 30,
    },
    buttonView: {
        padding: 12,
        borderRadius: 4,
        marginHorizontal: 75,
        zIndex: 1,
    },
    buttonText: {
        color: '#fff',
        fontSize: 13,
    },
    headerText: {
        textAlign: 'center',
        fontSize: 22,
        padding: 5,
    },
    footerView: {
        height: 80,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
