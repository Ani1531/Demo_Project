// @flow

import React, { Component } from 'react';
import { Text, Pressable, StyleSheet } from 'react-native';

type ButtonContainerprops = {
    tag: string,
    buttonText: string,
    onbuttonPressed: (string) => void,
};

export default class ButtonContainer extends Component<ButtonContainerprops> {
    constructor(props: ButtonContainerprops) {
        super(props);
    }

    render() {
        return (
            <Pressable
                style={styles.BtnStyle}
                onPress={() => {
                    this.props.onbuttonPressed(this.props.tag);
                }}
            >
                <Text style={styles.btnTxtStyle}> {this.props.buttonText}</Text>
            </Pressable>
        );
    }
}

const styles = StyleSheet.create({
    BtnStyle: {
        backgroundColor: '#1d9df1',
        width: 85,
        height: 30,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 3,
        borderRadius: 4,
        marginRight: 5,
    },
    btnTxtStyle: {
        color: 'white',
        fontSize: 13,
        fontWeight: '700',
    },
});
