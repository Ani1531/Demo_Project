module.exports = {
    singleQuote: true,
    trailingComma: 'es5',
    semi: true,
    tabWidth: 4,
    printWidth: 128,
};
