import store from '../store';
import get from 'lodash/get';

export default class LayoutWrapper {
    static getScrollX = () => window.scrollX;
    static getScrollY = () => window.scrollY;
    static isSafariMobile = () => window.isSafariMobile;
    static isSafari = () => window.isSafari;
    static getMobileLobbyTabHeight = () => '6.67vw';
    static getDialogTransformValue = () => 'translate(-50.1%, -50.1%)';
    static getDialogTopValue = () => '50%';
    static getDialogLeftValue = () => '50%';
    static getSparkTransformValue = () => 'translate(-48%, 0)';
    static getPuzzleBoardHeaderTransformValue = () => 'translate(0,-50%)';
    static getHistoryCellPadding = () => ({
        padding: 8,
    });
    static getBoardContainerHeight = () => null;
    static getNativeDriverValue = () => true;
    static setBoardHeaderHeight = (height) => null;
    static setSidePanelTabWidthHeight = (width, height) => null;
    static getLoaderContainerHeight = () =>
        get(store.getState(), 'layout.layoutGamePlayAreaHeight');
}
