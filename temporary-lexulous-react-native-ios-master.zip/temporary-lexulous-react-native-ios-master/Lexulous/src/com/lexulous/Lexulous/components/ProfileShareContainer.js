// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable, Share, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { translate } from '../commons/translations/LangTransator';
import * as PFLSelector from '../userprofile/PFLSelector';
import dataServer from '../store/Store';
import * as CONSTANTS from '../commons/Constants';
import { handleException } from '../commons/RJUtils';
import type { AlertBoxType } from '../commons/RJTypes';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import appConfiguration from '../commons/AppConfiguration';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type ProfileShareContainerProps = {
    closePopupHandler: () => void,
};

class ProfileShareContainer extends React.Component<ProfileShareContainerProps> {
    onShare = async (): Promise<void> => {
        this.props.closePopupHandler();
        let share = Platform.select({
            native: () => {
                let nativeshare = async (): Promise<void> => {
                    let guid: ?string = PFLSelector.getGUID(dataServer.getStore().getState());
                    if (guid !== null && guid !== undefined) {
                        let msg = CONSTANTS.statShareLink + guid;

                        try {
                            const result: { action: string } = await Share.share(
                                {
                                    message: msg,
                                },
                                { title: translate('share_frnds_msg') }
                            );
                            if (result.action === Share.sharedAction) {
                                // shared with activity type of result.activityType
                            }
                        } catch (error) {
                            let alertBoxInfo: AlertBoxType = {
                                message: error.message,
                                actions: [
                                    {
                                        text: translate('ok'),
                                        action: () => {
                                            dataServer.getStore().dispatch(clearAlert());
                                        },
                                        color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                                        type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                                    },
                                ],
                            };
                            dataServer.getStore().dispatch(showAlert(alertBoxInfo));
                            handleException(error);
                        }
                    }
                };
                nativeshare();
            },
            default: () => {
                let shareplugin: string | null = appConfiguration.getSharePlugin();
                if (shareplugin != null) {
                    let onCompletion = (error: Error | null, value: string | null): void => {
                        if (error != null) {
                            console.log('share error :: ' + JSON.stringify(error));
                        } else if (value != null) {
                            console.log('share success :: ' + value);
                        }
                    };
                    window[shareplugin](onCompletion);
                }
            },
        });
        share();
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.container,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.props.closePopupHandler()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Text style={[styles.PopupHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('shr_W_Frnd')}
                    </Text>
                    <Text style={[styles.discpTextStyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                        {translate('shr_W_Frnd_Msg')}
                    </Text>
                    <Pressable
                        style={[styles.btnStyle]}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('share_btn_tapped', 'profile_share_container');
                            this.onShare();
                        }}
                    >
                        <Text style={[styles.BtnTextStyle]}>{translate('tap_shr')}</Text>
                    </Pressable>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        maxWidth: 320,
        maxHeight: 350,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    btnStyle: {
        marginVertical: 20,
        padding: 8,
        borderRadius: 5,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        backgroundColor: '#1d9df1',
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    PopupHeaderStyle: {
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
        marginBottom: 8,
    },
    BtnTextStyle: {
        color: '#ffffff',
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
    },
    discpTextStyle: {
        textAlign: 'center',
        fontSize: 12,
        paddingHorizontal: 16,
    },
});

export default ProfileShareContainer;
