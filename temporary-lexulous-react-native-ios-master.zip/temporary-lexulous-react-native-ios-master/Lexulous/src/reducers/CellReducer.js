import GameBoardUtils from '../utils/GameBoardUtils';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import {
    CELL_REDUCER_SET_TILE,
    CELL_REDUCER_SET_DIRECTION,
    CELL_REDUCER_UPDATE_BOARD_STRUCTURE,
    CELL_REDUCER_HIDE_TILE,
    GAME_STARTED,
    CELL_REDUCER_CLEAR_DIRECTION,
    CELL_REDUCER_EMPTY_GAMEBOARD,
    CELL_REDUCER_UPDATE_CELL,
    UPDATE_TILES_AND_SET_CELL,
    GAME_TILE_BEING_DRAGGED,
    CELL_REDUCER_ON_TILE_CLICKED,
    REDUCER_ON_TILE_REMOVED,
    REDUCER_UPDATE_BLANK_TILE_LETTER,
    GAME_REDUCER_UPDATE_TILES,
    REDUCER_UPDATE_MOUSE_MOVE_TILE,
    RE_INIT_CELL,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import cloneDeep from 'lodash/cloneDeep';
import zip from 'lodash/zip';
import isBoolean from 'lodash/isBoolean';
import isObject from 'lodash/isObject';
import isString from 'lodash/isString';
import Config from '../configs/Config';
import isArray from 'lodash/isArray';
import SoundUtils, { isSoundsEnabled } from '../utils/SoundUtils';

const updateMoveScoreValidity = () => {
    setTimeout(
        () =>
            eventBus.emit(Config.UPDATE_MOVE_VALIDITY, null, {
                finalise: false,
                doPlayBtnCheckWordValidityReq: true,
            }),
        200
    );
};

const eventBus = require('js-event-bus')();

export const printBoard = (gameboard) => {
    let boardText = '';
    gameboard.forEach((row) => {
        let rowLetters = row.map((cell) =>
            !cell.currentTile
                ? '...'
                : (cell.currentTile.currentLetter || cell.currentTile.letter) +
                  (cell.currentTile.forRevealSolution ? 'R' : 'N') +
                  (cell.locked ? 'L' : 'O')
        );
        let rowText = rowLetters.join('   ');
        boardText = boardText + '\n' + rowText;
    });
};

const isDroppedTile = (state, tile, { position = false } = {}) => {
    let cell = (get(state, 'cells') || []).flat(8).find((cell) => get(cell, 'currentTile.id') === get(tile, 'id'));
    if (position) {
        let ret = !!cell ? { x: cell.tileX, y: cell.tileY } : undefined;
        return ret;
    }
    return !!cell;
};

const getCellDirection = (state) => get(state, 'direction');

const getCellDirectionTileX = (state) => get(state, 'directionPositionX');

const getCellDirectionTileY = (state) => get(state, 'directionPositionY');

const hasTile = (state, x, y) => !!get(get(state, 'cells.' + x + '.' + y), 'currentTile');

const hasLockedTile = (state, x, y) => !!get(get(state, 'cells.' + x + '.' + y), 'currentTile.locked');

const setMagicTile = (state, globalState, action) => {
    let placedTilesCells = get(state, 'cells')
        .flat(8)
        .filter((cell) => cell.currentTile && !cell.locked);

    let placedTiles = placedTilesCells.map((cell) => ({
        ...cell.currentTile,
        position: { x: cell.tileX, y: cell.tileY },
    }));

    if (placedTiles.length >= 2 && !!get(globalState, 'config.tap_to_play')) {
        let fixedDirection =
            placedTiles[0].position.x === placedTiles[1].position.x
                ? 'x'
                : placedTiles[0].position.y === placedTiles[1].position.y
                ? 'y'
                : undefined;

        let isDiscontinous = !fixedDirection;

        let firstCell, secondCell, secondTile;

        if (!isDiscontinous) {
            placedTilesCells = placedTilesCells.sort(
                (cellA, cellB) => get(cellA, 'tilePlacedTimeStamp', 0) - get(cellB, 'tilePlacedTimeStamp', 0)
            );

            placedTiles = placedTiles.sort(
                (tileA, tileB) =>
                    tileA.position[fixedDirection === 'x' ? 'y' : 'x'] - tileB.position[fixedDirection === 'x' ? 'y' : 'x']
            );
            secondTile = placedTiles[1];

            firstCell = placedTilesCells[placedTilesCells.length - 2];
            secondCell = placedTilesCells[placedTilesCells.length - 1];

            {
                let startVariyingDirectionValue =
                    firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')] >
                    secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')]
                        ? secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')]
                        : firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')];

                let endVaryingDirectionValue =
                    firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')] >
                    secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')]
                        ? firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')]
                        : secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')];

                let fixedDirectionValue =
                    firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')] >
                    secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')]
                        ? secondCell['tile' + (fixedDirection === 'x' ? 'X' : 'Y')]
                        : firstCell['tile' + (fixedDirection === 'x' ? 'X' : 'Y')];

                for (let i = startVariyingDirectionValue + 1; i < endVaryingDirectionValue; i++) {
                    let cell = get(
                        globalState,
                        `cells.cells.${fixedDirection === 'x' ? fixedDirectionValue : i}.${
                            fixedDirection === 'x' ? i : fixedDirectionValue
                        }`
                    );

                    if (!cell.currentTile) {
                        isDiscontinous = true;
                        break;
                    }
                }
            }
        }
        if (isDiscontinous) {
            state.direction = undefined;
            state.directionPositionX = undefined;
            state.directionPositionY = undefined;
            if (state.showArrow == false) {
                state.showArrow = undefined;
            }
        } else {
            let isGoingLeftwardOrTopward =
                firstCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')] >
                secondCell['tile' + (fixedDirection === 'x' ? 'Y' : 'X')];

            let incrementer =
                isGoingLeftwardOrTopward && (!state.showArrow || get(action, 'payload.caller') === 'TileOnTileRelease')
                    ? -1
                    : 1;

            if (fixedDirection) {
                let x = secondTile.position.x;
                let y = secondTile.position.y;
                do {
                    x = x + (fixedDirection === 'x' ? 0 : incrementer);
                    y = y + (fixedDirection === 'y' ? 0 : incrementer);
                } while (
                    (incrementer > 0 &&
                        x < get(globalState, 'game.board_size') &&
                        y < get(globalState, 'game.board_size') &&
                        hasTile(state, x, y)) ||
                    (incrementer < 0 && x >= 0 && y >= 0 && hasTile(state, x, y))
                );

                if (!hasTile(state, x, y)) {
                    state.direction = fixedDirection === 'x' ? 'y' : 'x';
                    state.directionPositionX = x;
                    state.directionPositionY = y;
                    if (get(action, 'payload.caller') === 'TileOnTileRelease') {
                        state.showArrow = false;
                    }
                }
            }
        }
    }
};

const getTiles = ({ includeEmptySpace = false, forRendering = false, globalState } = {}) => {
    let currentRackArr = [];
    if (get(globalState, 'tiles.rackArr')) {
        currentRackArr = cloneDeep(get(globalState, 'tiles.rackArr'));
    } else {
        let players = get(globalState, 'tiles.players');
        let selfPid = get(globalState, 'game.pid');
        let currentTurn = get(globalState, 'game.currentTurn');
        let pidToUse = isString(selfPid) && selfPid.length > 0 ? selfPid : currentTurn;
        let player = (players || []).find((player) => player.pid === pidToUse);
        currentRackArr = cloneDeep(get(player, 'currentRackArr') || []);
    }

    let nonNullTiles = currentRackArr.filter(Boolean);
    if (includeEmptySpace) {
        return nonNullTiles;
    }
    let actualTiles = nonNullTiles.filter((tile) => !tile.isEmptySpace);
    if (forRendering && actualTiles.length > 2) return nonNullTiles;
    return actualTiles;
};

const initGameBoard = (globalState, dimenY, dimenX, setPosType = true, forCreateGame = false) => {
    let gameboard = [];
    for (let i = 0; i < dimenY; i++) {
        let row = [];
        for (let j = 0; j < dimenX; j++) {
            row.push({
                tileX: j,
                tileY: i,
                positionType: forCreateGame ? undefined : setPosType ? getPositionType(globalState, dimenX, dimenY, j, i) : '',
            });
        }
        gameboard.push(row);
    }
    return gameboard;
};

const getPositionType = (globalState, dimenX, dimenY, tileX, tileY) => {
    let boardType = getSpecialPostions(globalState, dimenX, dimenY);
    for (let i = 0; i < boardType.length; i++) {
        let { type, positions } = boardType[i];
        for (let j = 0; j < positions.length; j++) {
            let position = positions[j];
            if (position[0] === tileX && position[1] === tileY) return type;
        }
    }
    return '';
};

const getSpecialPostions = (globalState, dimenX, dimenY) =>
    get(globalState, 'game.customBoardInfo') || getDefaultBoardConfiguartion(dimenX, dimenY);

const getDefaultBoardConfiguartion = (dimenX) => {
    switch (dimenX) {
        case Config.CLASSIC_BOARD_SIZE_FIFTEEN:
            return Config.FITFEEN_BY_FIFTEEN_BOARD;
        case Config.SUPER_BOARD_SIZE_TWENTYONE:
            return Config.TWENTYONE_BY_TWENTYONE_BOARD;
    }
};

const INITIAL_STATE = {
    cells: zip(
        ...initGameBoard(
            null,
            Number(ConfigurationWrapper.getLexulousGameConfiguration().board_size),
            Number(ConfigurationWrapper.getLexulousGameConfiguration().board_size)
        )
    ),
};

export default (state = INITIAL_STATE, action) => {
    let globalState = get(action, 'globalState');
    let payload = get(action, 'payload');
    let position = get(payload, 'position') || get(payload, 'cells.position');
    let tile = get(payload, 'tile') || get(payload, 'cells.tile');
    let forCreateGame = !!get(payload, 'forCreateGame');

    switch (action.type) {
        case GAME_STARTED:
        case CELL_REDUCER_UPDATE_BOARD_STRUCTURE: {
            state = cloneDeep(state);
            let channel = get(globalState, 'game.channel');
            let board_type = forCreateGame
                ? 'normal'
                : get(payload, 'data.' + channel + '.boardtype')
                ? get(payload, 'data.' + channel + '.boardtype') === 'S'
                    ? 'super'
                    : 'normal'
                : get(globalState, 'game.board_type');

            let board_size = undefined;

            switch (board_type) {
                case 'normal': {
                    board_size = 15;
                    break;
                }
                case 'super': {
                    board_size = 21;
                    break;
                }
            }

            state.cells = zip(...initGameBoard(globalState, board_size, board_size, get(payload, 'setPosType'), forCreateGame));

            break;
        }
        case UPDATE_TILES_AND_SET_CELL:
        case CELL_REDUCER_SET_TILE: {
            state = cloneDeep(state);
            let emptyGameBoard = get(payload, 'emptyGameBoard');
            if (emptyGameBoard) {
                let { nonLockedTilesOnly, letRevealSolutionRemain, forAnalyseMove } = emptyGameBoard;
                let gameBoardTiles = state.cells;
                for (let x = 0; x < gameBoardTiles.length; x++) {
                    for (let y = 0; y < gameBoardTiles.length; y++) {
                        let cell = gameBoardTiles[y][x];
                        let tile = cell.currentTile;
                        if (tile) {
                            if (forAnalyseMove && tile.forRevealSolution) {
                                cell.currentTile = null;
                            } else {
                                if (tile && !letRevealSolutionRemain) tile.forRevealSolution = false;
                                cell.currentTile = !nonLockedTilesOnly || (nonLockedTilesOnly && !cell.locked) ? null : tile;
                            }
                            cell.locked = !!cell.currentTile ? cell.locked : false;
                        }
                        cell.hidden = false;
                    }
                }
            }
            let word = get(payload, 'word');
            if (word) {
                (word.set || word.movetiles).forEach((letter) => {
                    let parts = letter.split(',');
                    let tile = GameBoardUtils.tileCreation(parts[2], true);
                    let x = Number(parts[1]);
                    let y = Number(parts[0]);
                    let cell = get(state, `cells.${x}.${y}`);
                    if (cell) {
                        cell.currentTile = tile;
                    }
                });
            } else if (position) {
                let previousCell = get(state, 'cells')
                    .flat(8)
                    .find((cell) => get(cell, 'currentTile.id') === get(tile, 'id'));

                if (previousCell) {
                    previousCell.currentTile = undefined;
                    previousCell.hidden = false;
                }
                let cell = get(state.cells, position.x + '.' + position.y);
                if (cell) {
                    cell.currentTile = tile ? cloneDeep(tile) : undefined;
                    cell.locked = get(payload, 'locked');
                    cell.hidden = false;
                    cell.tilePlacedTimeStamp = tile ? Date.now() : undefined;
                }
                if (!cell.locked) {
                    if (get(action, 'payload.caller') !== 'TileOnTileRelease' || get(globalState, 'config.isProUser')) {
                        setMagicTile(state, globalState, action);
                    } else {
                        state.direction = undefined;
                        state.directionPositionX = undefined;
                        state.directionPositionY = undefined;
                        state.showArrow = undefined;
                    }
                }
            } else {
                let cells = get(payload, 'cells');
                let forHintWordPlacement = get(payload, 'forHintWordPlacement');
                if (cells) {
                    state = cloneDeep(state);
                    if (forHintWordPlacement) {
                        let unlockedPlacedTilesCells = state.cells.flat(8).filter((cell) => !!cell.currentTile && !cell.locked);
                        (unlockedPlacedTilesCells || []).forEach((cell) => {
                            cell.currentTile = undefined;
                            cell.tilePlacedTimeStamp = undefined;
                            cell.hidden = false;
                        });
                    }
                    cells.forEach((cellInArr) => {
                        let cell = get(state.cells, cellInArr.tileX + '.' + cellInArr.tileY);
                        Object.assign(cell, cellInArr);
                    });
                }
            }
            printBoard(zip(...state.cells));
            updateMoveScoreValidity();
            break;
        }

        case REDUCER_UPDATE_BLANK_TILE_LETTER:
        case CELL_REDUCER_UPDATE_CELL: {
            state = cloneDeep(state);
            let cell = get(action, 'payload.cell');
            let tileX = get(cell, 'tileX');
            let tileY = get(cell, 'tileY');
            let oldCell = (state.cells || []).flat(8).find((cell) => cell.tileX === tileX && cell.tileY === tileY);
            Object.assign(oldCell, cell);
            updateMoveScoreValidity();
            break;
        }

        case CELL_REDUCER_SET_DIRECTION: {
            state = cloneDeep(state);
            if (get(payload, 'createBoard')) {
                let selectedTile = get(payload, 'createBoard.selectedTile');
                if (selectedTile) {
                    let cell = get(state.cells, position.x + '.' + position.y);
                    if (cell) {
                        cell.currentTile = GameBoardUtils.tileCreation(selectedTile.letter);
                        cell.locked = false;
                        cell.hidden = false;
                    }
                }
            } else {
                state.direction = get(payload, 'direction');
                state.directionPositionX = get(position, 'x');
                state.directionPositionY = get(position, 'y');
                state.showArrow = get(payload, 'showArrow');
            }
            break;
        }

        case GAME_TILE_BEING_DRAGGED:
        case CELL_REDUCER_HIDE_TILE: {
            tile = get(action, 'payload.tileBeingDragged');
            let droppedInRack = get(action, 'payload.droppedInRack');
            if (droppedInRack) {
                state = cloneDeep(state);
                let currentCell = get(state, 'cells')
                    .flat(8)
                    .find((cell) => get(cell, 'currentTile') && get(cell, 'currentTile.id') === get(tile, 'id'));
                if (currentCell) {
                    currentCell.currentTile = undefined;
                    currentCell.tilePlacedTimeStamp = undefined;
                    currentCell.hidden = false;
                }
            } else {
                position =
                    get(action, 'payload.position') || (tile && isDroppedTile(state, tile, { position: true })) || position;
                if (!isObject(position)) break;
                let unset = !get(payload, 'unset');
                state = cloneDeep(state);
                state.cells[position.x][position.y].hidden = isBoolean(get(payload, 'hidden')) ? get(payload, 'hidden') : unset;
            }
            break;
        }

        case CELL_REDUCER_CLEAR_DIRECTION: {
            state = cloneDeep(state);
            state.direction = undefined;
            state.directionPositionX = undefined;
            state.directionPositionY = undefined;
            state.showArrow = undefined;
            break;
        }
        case CELL_REDUCER_EMPTY_GAMEBOARD: {
            let nonLockedTilesOnly = get(payload, 'nonLockedTilesOnly');
            let letNonLockedTilesRemain = get(payload, 'letNonLockedTilesRemain');
            let letRevealSolutionRemain = get(payload, 'letRevealSolutionRemain');
            let forAnalyseMove = get(payload, 'forAnalyseMove');

            state = cloneDeep(state);
            let gameBoardTiles = state.cells;
            for (let x = 0; x < gameBoardTiles.length; x++) {
                for (let y = 0; y < gameBoardTiles.length; y++) {
                    let cell = gameBoardTiles[y][x];
                    let tile = cell.currentTile;
                    if (tile) {
                        if (forAnalyseMove && tile.forRevealSolution) {
                            cell.currentTile = null;
                            cell.tilePlacedTimeStamp = undefined;
                        } else {
                            if (!letRevealSolutionRemain) tile.forRevealSolution = false;
                            cell.currentTile =
                                !nonLockedTilesOnly || (!letNonLockedTilesRemain && nonLockedTilesOnly && !cell.locked)
                                    ? null
                                    : tile;
                        }
                        cell.locked = !!cell.currentTile ? cell.locked : false;
                    }
                }
            }
            //printBoard(state);
            break;
        }

        case CELL_REDUCER_ON_TILE_CLICKED: {
            state = cloneDeep(state);

            let { tileType, position } = get(action, 'payload');

            if (getCellDirection(state) || position) {
                let x = getCellDirectionTileX(state);
                let y = getCellDirectionTileY(state);
                let cellDirection = getCellDirection(state);
                let varyingCoordinate = cellDirection === 'x' ? x : y;
                let constantCoordinate = cellDirection === 'x' ? y : x;

                let tiles = getTiles({
                    globalState,
                    includeEmptySpace: true,
                });

                let unplacedTiles = tiles.filter(
                    (tile) => !(isDroppedTile(state, tile) || get(tile, 'id') === get(tileType, 'id'))
                );
                let unplacedCount = unplacedTiles.length;

                if (!position) {
                    if (unplacedCount > 0) {
                        let nextCoordinate = varyingCoordinate + 1;

                        let cellDirection = getCellDirection(state);

                        let boardSize = (get(state, 'cells') || []).length;

                        let xCoord = undefined;
                        let yCoord = undefined;

                        while (nextCoordinate <= boardSize - 1) {
                            xCoord = cellDirection === 'x' ? nextCoordinate : constantCoordinate;
                            yCoord = cellDirection === 'y' ? nextCoordinate : constantCoordinate;

                            if (!hasTile(state, xCoord, yCoord)) break;
                            nextCoordinate++;
                        }

                        state.directionPositionX = xCoord;
                        state.directionPositionY = yCoord;
                    }
                }

                SoundUtils.playDropTileSound({
                    playForSure: isSoundsEnabled(globalState),
                });
                let queryString = `cells.${x}.${y}`;
                let cell = get(state, queryString);

                if (cell) {
                    cell.currentTile = tileType;
                    cell.hidden = false;
                    cell.locked = false;
                    cell.tilePlacedTimeStamp = tileType ? Date.now() : undefined;
                }
                if (state.showArrow || get(globalState, 'config.isProUser')) setMagicTile(state, globalState, action);
                else {
                    state.direction = undefined;
                    state.directionPositionX = undefined;
                    state.directionPositionY = undefined;
                    state.showArrow = undefined;
                }
                if (!(tileType.isBlankTile && !tileType.currentLetter)) updateMoveScoreValidity();
            }
            break;
        }
        case REDUCER_ON_TILE_REMOVED: {
            let tileOrTiles = get(action, 'payload.tileOrTiles');
            state = cloneDeep(state);

            if (!isArray(tileOrTiles)) tileOrTiles = [tileOrTiles];

            for (let i = 0; i < tileOrTiles.length; i++) {
                let tileType = tileOrTiles[i];
                let cell =
                    (get(state, 'cells') || [])
                        .flat(8)
                        .find((cellInArr) => get(cellInArr, 'currentTile.id') === get(tileType, 'id')) ||
                    get(state, `cells.${tileType.tileX}.${tileType.tileY}`);
                if (cell) {
                    cell.currentTile = undefined;
                    cell.tilePlacedTimeStamp = undefined;
                    cell.locked = get(payload, 'locked');
                    cell.hidden = false;
                }
            }

            state.direction = get(payload, 'direction') || state.direction;
            state.directionPositionX = get(position, 'x');
            state.directionPositionY = get(position, 'y');
            state.showArrow = get(payload, 'showArrow') || state.showArrow;
            updateMoveScoreValidity();
            break;
        }
        case RE_INIT_CELL: {
            state.cells = zip(
                ...initGameBoard(
                    null,
                    Number(ConfigurationWrapper.getLexulousGameConfiguration().board_size),
                    Number(ConfigurationWrapper.getLexulousGameConfiguration().board_size)
                )
            );
            break;
        }
    }
    return state;
};
