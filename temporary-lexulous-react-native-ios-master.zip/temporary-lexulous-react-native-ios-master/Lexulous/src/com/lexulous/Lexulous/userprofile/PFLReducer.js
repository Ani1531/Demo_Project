// @flow

import { SET_PROFILE, UPDT_PROFILE, CLR_PROFILE } from './PFLEventTypes';

import type { ActionSetProfile, ProfileState } from '../commons/RJTypes';

// Use the initialState as a default value
export default function PFLReducer(state: ProfileState = { profile: {} }, action: ActionSetProfile) {
    switch (action.type) {
        case SET_PROFILE: {
            return {
                ...state.profile,
                ...action.payload,
            };
        }
        case UPDT_PROFILE: {
            return {
                ...state,
                ...{
                    ...state.profile,
                    ...action.payload,
                },
            };
        }
        case CLR_PROFILE: {
            return { profile: {} };
        }
        default:
            return state;
    }
}
