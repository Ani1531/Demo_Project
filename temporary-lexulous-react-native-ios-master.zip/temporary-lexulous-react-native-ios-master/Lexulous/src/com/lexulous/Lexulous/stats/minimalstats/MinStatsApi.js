// @flow
import fndApi from '../../friends/FndApi';
import { actionUpdateMinStats } from './MinStatsAction';
import type { AxiosPromise, AxiosResponse } from 'axios';
import dataServer from '../../store/Store';
import { actionSetProfile, actionUpdateUserSettings } from '../../userprofile/PFLAction';
import userDefault from '../../commons/UserDefault';
import * as CONSTANTS from '../../commons/Constants';
import * as PFLSelector from '../../userprofile/PFLSelector';
import type { ServerResponse } from '../../commons/RJTypes';
import netManager from '../../commons/RJNetInfo';
import { handleException } from '../../commons/RJUtils';

class MinStatsApi {
    getLoggedInUserStats = () => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        if (netManager.isConnected() && sguid != null && sguid != undefined) {
            let rsp: AxiosPromise<ServerResponse> = fndApi.getStats([sguid], []);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    if (result.check === CONSTANTS.kSuccess) {
                        if (result.data != null && result.data[0] != undefined) {
                            let loggedinStats = {
                                [result.data[0].guid]: result.data[0],
                            };
                            dataServer.getStore().dispatch(actionUpdateMinStats(loggedinStats));
                            let statsUpdateTimestampInSec = Math.floor(Date.now() / 1000);
                            userDefault.set(CONSTANTS.kStatsUpdate, statsUpdateTimestampInSec.toString());
                        }
                    }
                })
                .catch((error) => {
                    handleException(error);
                });
        }
    };
}
const minStatsApi = new MinStatsApi();
export default minStatsApi;
