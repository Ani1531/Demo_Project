// @flow

import { UPDT_POPUP_VISIBILITY, HIDE_ALL_POPUPS, SHOW_ALERT, CLEAR_ALERT, CLEAR_ALL_ALERTS } from './PopupEventTypes';
import type { ActionPopupVisibility, ActionClearPopups, ActionAddAlert, PopupData, AlertBoxType } from '../../commons/RJTypes';

export const updatePopupVisibility = (data: PopupData): ActionPopupVisibility => {
    return {
        type: UPDT_POPUP_VISIBILITY,
        payload: data,
    };
};

export const clearPopups = (): ActionClearPopups => {
    return {
        type: HIDE_ALL_POPUPS,
    };
};

export const showAlert = (data: AlertBoxType): ActionAddAlert => {
    return {
        type: SHOW_ALERT,
        payload: data,
    };
};

export const clearAlert = (): ActionClearPopups => {
    return {
        type: CLEAR_ALERT,
    };
};

export const clearAllAlerts = (): ActionClearPopups => {
    return {
        type: CLEAR_ALL_ALERTS,
    };
};
