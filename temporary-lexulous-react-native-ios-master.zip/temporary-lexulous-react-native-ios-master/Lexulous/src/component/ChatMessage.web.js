import React from 'react';
import loadable from '@loadable/component';
const Emoji = loadable(() => import('react-emoji-render'));

export default class ChatMessage extends React.PureComponent {
    render = () => (
        <Emoji text={this.props.message} fallback={this.props.fallback} />
    );
}
