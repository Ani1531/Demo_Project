// @flow

export const SET_PROFILE: string = 'SET_PROFILE';
export const UPDT_PROFILE: string = 'UPDT_PROFILE';
export const CLR_PROFILE: string = 'CLR_PROFILE';
export const UPDT_APPL_LGN_INFO: string = 'UPDT_APPL_LGN_INFO';
export const UPDT_FB_LGN_INFO: string = 'UPDT_FB_LGN_INFO';
export const UPDT_GGL_LGN_INFO: string = 'UPDT_GGL_LGN_INFO';
export const UPDT_LXLS_LGN_INFO: string = 'UPDT_LXLS_LGN_INFO';
export const UPDT_SETTINGS = 'UPDT_SETTINGS';
