// @flow

import dataServer from '../store/Store';
import { Platform } from 'react-native';
import { actionSetProfile, actionUpdateUserSettings } from '../userprofile/PFLAction';
import userDefault from '../commons/UserDefault';
import { v4 as uuidv4 } from 'uuid';
import * as CONSTANTS from '../commons/Constants';
import * as PFLSelector from '../userprofile/PFLSelector';
import { rjLog, isStrEmpty, handleException } from './RJUtils';
import base64 from 'react-native-base64';
import { translate } from '../commons/translations/LangTransator';
import appConfiguration from '../commons/AppConfiguration';
import themeConfigutation from './ThemeConfiguration';
import type {
    GenGlobalIDRequest,
    ServerResponse,
    GenGlobalIDResponseData,
    onGenGlobalCompletion,
    RequestData,
    RegisterAppleUserRequest,
    AssociationRequestData,
    userSettings,
    UserSettingsResponse,
    RegisterGoogleUserResponse,
    RegisterAppleUserResponse,
    AppState,
    StartNewGamePlayers,
    StartNewGameSetting,
    LegacyAuthData,
    AlertBoxType,
    NewsFeedResponse,
    SourceType,
    ProfileInfo,
} from './RJTypes';
// import type { User } from '@react-native-google-signin/google-signin';   //  Comment for react native web
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import netManager from '../commons/RJNetInfo';
import * as ProfileSelector from '../userprofile/PFLSelector';
import axios from 'axios';
import type { AxiosPromise, AxiosInstance } from 'axios';
import { configSettingsRetrieved } from '../../../../actions/ConfigActions';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';
import bannerAd from '../commons/ads/BannerAd';

const qs = require('qs');

class RequestManager {
    axiosinst: AxiosInstance = axios.create({
        method: 'post',
        baseURL: CONSTANTS.kBaseUrl,
        timeout: 2500,
        headers: CONSTANTS.kHeader,
    });
    constructor() {}

    onGenGlobalIDResponse = (request: GenGlobalIDRequest, response: ServerResponse): void => {
        if (response.check === CONSTANTS.kSuccess) {
            let respdata: GenGlobalIDResponseData = ((response.data: any): GenGlobalIDResponseData);
            if (respdata?.guid !== undefined && respdata?.uuid !== undefined) {
                this.updatePsistDataGuidUuid(respdata.guid, respdata.uuid);
            }
        }

        //NO ELSE CHECKING FOR REQUEST FAILURE
    };

    updatePsistDataGuidUuid = (guid: string, uuid: string) => {
        // userDefault.set(CONSTANTS.kPsistGUID, '730005128462'); ////TEST CODE
        // userDefault.set(CONSTANTS.kPsistUUID, '10534322-bf9c-4d45-a35f-f4c9b8e9982b');
        userDefault.set(CONSTANTS.kPsistGUID, guid);
        userDefault.set(CONSTANTS.kPsistUUID, uuid);
    };

    doGenGlobalID = (onCompletion: onGenGlobalCompletion): void => {
        let data = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamUuid]: uuidv4(),
        };
        let generate = () => {
            let rsp: AxiosPromise<ServerResponse> = this.genGlobalID(data);
            rsp.then((response) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw {
                        name: 'RequestFail',
                        status: response.status,
                        message: 'Request Failed',
                    };
                }
            })
                .then((result: ServerResponse) => {
                    onCompletion(data, result);
                })
                .catch((error) => {
                    handleException(error);
                    generateRetryConfirmation(generateFailureHandler);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        };
        let generateFailureHandler = generate;
        let generateRetryConfirmation = (retry: () => void) => {
            let alertBoxInfo: AlertBoxType = {
                message: translate('err_internet'),
                actions: [
                    {
                        text: translate('retry'),
                        action: () => {
                            retry();
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBUTTONONLY,
                    },
                ],
            };
            dataServer.getStore().dispatch(showAlert(alertBoxInfo));
        };
        generate();
    };

    genGlobalID = (data: GenGlobalIDRequest): AxiosPromise<ServerResponse> => {
        let action = {
            [CONSTANTS.kParamAction]: CONSTANTS.kActionRegisterGlobalUser,
        };
        let mdata = { ...action, ...data };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });
        rjLog(params, 'genGlobalID');
        return this.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    updateProfile = (name: ?string, avtid: ?string): AxiosPromise<ServerResponse> => {
        let st: AppState = dataServer.getStore().getState();
        let sguid = PFLSelector.getGUID(st);
        let suuid = PFLSelector.getUUID(st);
        let svdavtar = PFLSelector.getAvtar(st);
        let svdname = PFLSelector.getName(st);
        let encodedname = base64.encode(name ?? svdname);
        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            name: encodedname,
            pic_id: avtid ?? svdavtar,
        };
        let action = { [CONSTANTS.kParamAction]: 'updateprofile' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });

        rjLog(params, 'updateprofile');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    onDoGetProfileResponse = (request: RequestData, response: ServerResponse) => {
        this.onProfileResponse(request.guid, request.uuid, response);
    };

    onProfileResponse = (guid: string, uuid: string, response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let prfl = response?.data?.[guid];
            let picurl: string | null = null;
            if (prfl !== undefined) {
                let fillpic = Platform.select({
                    native: () => {},
                    default: () => {
                        let source: SourceType | null = appConfiguration.getApplicationSource();
                        if (source) {
                            let appCfg: any = appConfiguration.getAppConfiguration(source);
                            picurl = appCfg?.[source]?.picurl ?? null;
                        }
                    },
                });
                fillpic();
                let usrpfl: ProfileInfo = picurl == null ? { ...prfl, ...{ uuid } } : { ...prfl, ...{ uuid }, ...{ picurl } };
                dataServer.getStore().dispatch(actionSetProfile(usrpfl));
            }
        }
        //NO ELSE CHECKING FOR REQUEST FAILURE
    };

    doGetProfile = (data: RequestData, onCompletion: (request: RequestData, response: ServerResponse) => void) => {
        let rsp: AxiosPromise<ServerResponse> = this.getProfile(data);
        rsp.then((response: Response) => {
            if (response.status == CONSTANTS.HTTPSuccessStatus) {
                return response.data;
            } else {
                throw {
                    name: 'RequestFail',
                    status: response.status,
                    message: 'Request Failed',
                };
            }
        })
            .then((result: ServerResponse) => {
                onCompletion(data, result);
            })
            .catch((error) => {
                handleException(error);
            })
            .finally(() => {
                dataServer.debouncedDispatch(actionSetIdle());
            });
    };

    getProfile = (data: RequestData): AxiosPromise<ServerResponse> => {
        let action = { [CONSTANTS.kParamAction]: CONSTANTS.kGetProfile };
        let mdata = { ...action, ...data };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });

        rjLog(params, 'getProfile');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    getProfileOtherUser = (guids: Array<string>): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let data = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamGuids]: guids,
        };

        let action = { [CONSTANTS.kParamAction]: CONSTANTS.kGetProfile };
        let mdata = { ...action, ...data };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });

        rjLog(params, 'getProfile');
        return this.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    doRegisterAppleUser = (data: RegisterAppleUserRequest): AxiosPromise<RegisterAppleUserResponse> => {
        data[CONSTANTS.kParamPkg] = 'com.lexulous.LexulousLite';
        if (isStrEmpty(data[CONSTANTS.kParamRefreshToken])) {
            delete data[CONSTANTS.kParamRefreshToken];
        }
        if (isStrEmpty(data[CONSTANTS.kParamEmail])) {
            delete data[CONSTANTS.kParamEmail];
        }
        if (isStrEmpty(data[CONSTANTS.kParamFamilyName])) {
            delete data[CONSTANTS.kParamFamilyName];
        }
        if (isStrEmpty(data[CONSTANTS.kParamGivenName])) {
            delete data[CONSTANTS.kParamGivenName];
        }
        if (isStrEmpty(data[CONSTANTS.kParamNickName])) {
            delete data[CONSTANTS.kParamNickName];
        }

        let params: string = qs.stringify({
            [CONSTANTS.kJson]: JSON.stringify(data),
        });

        rjLog(params, 'doRegisterAppleUser');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmUrl + CONSTANTS.kUrlMdfrAppleLgn,
            data: params,
        });
    };

    doRegisterGoogleUser = (data: any): AxiosPromise<RegisterGoogleUserResponse> => {
        //  chnage type User to any for react native web
        let reqdata = {
            accesstoken: data.idToken,
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
        };

        let params: string = qs.stringify({
            [CONSTANTS.kJson]: JSON.stringify(reqdata),
        });

        rjLog(params, 'doRegisterGoogleUser');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kEmailBaseUrl + CONSTANTS.kEmailGameApiPath + 'googlelogin?ver=IPH_4_0',
            data: params,
        });
    };

    doAssociation = (data: AssociationRequestData): AxiosPromise<ServerResponse> => {
        let action = { action: 'association' };
        let reqdata = { ...data, ...action };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });

        rjLog(params, 'association');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
            timeout: 25000,
        });
    };

    updateUserSetting = (data: userSettings): AxiosPromise<ServerResponse> => {
        let action = { action: 'setusersettings' };
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            settings: data,
        };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });
        rjLog(params, 'setusersettings');
        //setting apply for board
        dataServer.getStore().dispatch(configSettingsRetrieved(data));
        return this.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    fetchUserSettings = () => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.getUserSetting();
            rsp.then((response) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    if (result.check === CONSTANTS.kSuccess) {
                        let settingsrsp: UserSettingsResponse = ((result.data: any): UserSettingsResponse);
                        let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                        if (sguid != null && sguid != undefined) {
                            let usrset: userSettings = settingsrsp[sguid];
                            // $FlowFixMe
                            delete usrset[CONSTANTS.kParamChannel];
                            // $FlowFixMe
                            delete usrset[CONSTANTS.kParamGuid];
                            let darkmode = (usrset.us_gameplay?.gp_darktheme ?? 'n').toLowerCase();
                            themeConfigutation.overridenByApp = darkmode == 'y';
                            dataServer.getStore().dispatch(actionUpdateUserSettings(usrset));
                            //setting apply for board
                            dataServer.getStore().dispatch(configSettingsRetrieved(usrset));

                            let currentSettingUpdateTimestampInSec = Math.floor(Date.now() / 1000);
                            userDefault.set(CONSTANTS.kUpdateSettings, currentSettingUpdateTimestampInSec.toString());
                            setTimeout(() => {
                                bannerAd.onUserSettingsUpdate();
                            }, 0);
                        }
                    }
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    getUserSetting = (guids?: Array<string>): AxiosPromise<ServerResponse> => {
        let action = { action: 'getusersettings' };
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };
        let reqdata2 = {
            ['uids']: guids,
        };
        let mdata = { ...action, ...reqdata, ...reqdata2 };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });
        rjLog(params, 'getusersettings');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    sendSupporttRequest = (useremail: string, subject: string, msg: string) => {
        let reqdata = {
            [CONSTANTS.kParamAction]: 'userfeedback',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamUserEmail]: useremail,
            [CONSTANTS.kParamSubject]: subject,
            [CONSTANTS.kParamMsg]: msg,
        };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'userfeedback');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kBaseUrl,
            url: CONSTANTS.kFeedBackPath,
            data: params,
            timeout: Platform.select({
                native: 2500,
                default: 5000,
            }),
        });
    };

    verifyAnalizerReceipt = (receiptdata: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'verifyreceipt',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kParamReceiptData]: receiptdata,
            dummy: 'y',
        };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'verifyreceipt');
        return requestManager.axiosinst({
            url: CONSTANTS.kGameApiPath,
            data: params,
        });
    };

    updateDevicePin = (pin: string, ack: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'updatepin',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kPin]: pin,
            [CONSTANTS.kVer]: CONSTANTS.appVersion,
            [CONSTANTS.kAck]: ack,
        };
        if (CONSTANTS.getOSPlatformString() == 'AP') {
            reqdata = { ...reqdata, ...{ priority: 'h' } };
        } else if (CONSTANTS.getOSPlatformString() == 'IP') {
            reqdata = { ...reqdata, ...{ appver: 'lite' } };
        }
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'updatepin');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    deleteDevicePin = (pin: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'deletepin',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kPin]: pin,
        };

        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'deletepin');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    startNewGame = (data: StartNewGamePlayers, setting: StartNewGameSetting): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'startnewgame',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };
        reqdata = { ...data, ...reqdata, ...setting };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'startnewgame');
        return requestManager.axiosinst({
            url: CONSTANTS.kGameApiPath,
            data: params,
        });
    };

    getGuidUuid = (data: LegacyAuthData): AxiosPromise<ServerResponse> => {
        let action = { action: 'getguiduuid' };
        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
        };
        let mdata = { ...action, ...data, ...reqdata };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });
        rjLog(params, 'getguiduuid');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    getDefinationByApi = (word: Array<string>) => {
        let data = {
            action: CONSTANTS.kGetDefinationAction,
            mobile: 'y',
            meaning: 'y',
            dic: 'twl', //this value is not used by server.
            word: word,
        };
        let params: string = qs.stringify(data);
        rjLog(params, CONSTANTS.kGetDefinationAction);
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kWordDefinationUrl,
            data: params,
        });
    };

    deleteUserAccount = (): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'deleteuser',
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });
        rjLog(params, 'deleteuser');
        return requestManager.axiosinst({
            url: CONSTANTS.kUserApiPath,
            data: params,
        });
    };

    getNewsFeed = (device: string): AxiosPromise<NewsFeedResponse> => {
        let reqdata = {
            device: device,
        };
        let params: string = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(reqdata) });

        return requestManager.axiosinst({
            url: CONSTANTS.kLxEmUrl + 'getusernotification',
            data: params,
        });
    };
}
const requestManager = new RequestManager();
export default requestManager;
