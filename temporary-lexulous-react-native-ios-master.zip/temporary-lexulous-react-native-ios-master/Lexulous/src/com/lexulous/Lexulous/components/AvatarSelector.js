// @flow

import React from 'react';
import { connect } from 'react-redux';
import type { ProfileInfo } from '../commons/RJTypes';
import { StyleSheet, Image, Platform } from 'react-native';
import { avtarIcons, Default_Avtar } from '../commons/Constants';
import SelectDropdown from 'react-native-select-dropdown';
import themeConfigutation from '../commons/ThemeConfiguration';

type PFLAvatarEditProps = {
    profile: ProfileInfo,
    editingFinishedHandler: (data: string) => void,
    avtar: ?string,
};

class AvatarSelector extends React.Component<PFLAvatarEditProps> {
    constructor(props: PFLAvatarEditProps) {
        super(props);
    }

    getSelectedValue = (data: string) => {
        this.props.editingFinishedHandler(data);
    };

    render() {
        let renderOtherAvtar: boolean = this.props.avtar !== null && this.props.avtar !== undefined;
        let timg: number | {| uri: string |} = avtarIcons[this.props.profile.avtar ?? Default_Avtar];
        if (renderOtherAvtar) {
            timg = avtarIcons[this.props.avtar ?? Default_Avtar];
        }
        if (renderOtherAvtar == false && this.props.profile.picurl) {
            timg = { uri: this.props.profile.picurl };
        }
        return (
            <SelectDropdown
                buttonStyle={styles.pickerStyle}
                rowStyle={[styles.pickerRowStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                data={Object.keys(avtarIcons)}
                disabled={
                    this.props.editingFinishedHandler == null ||
                    this.props.editingFinishedHandler == undefined ||
                    this.props.profile.picurl != null
                }
                onSelect={(selectedItem: string) => this.getSelectedValue(selectedItem)}
                renderCustomizedButtonChild={() => {
                    return <Image source={timg} style={[styles.avatarFieldStyle]} resizeMode="cover" />;
                }}
                renderCustomizedRowChild={(item: string) => {
                    return <Image source={avtarIcons[item]} style={[styles.avatarFieldStyle]} resizeMode="center" />;
                }}
            />
        );
    }
}

const styles = StyleSheet.create({
    avatarFieldStyle: {
        ...Platform.select({
            native: { height: 30, width: 30 },
            default: { height: 49, width: 49 },
        }),
    },

    pickerStyle: {
        height: '100%',
        ...Platform.select({
            native: { width: 30 },
            default: { width: 60 },
        }),
        backgroundColor: 'transparent',
        alignSelf: 'flex-start',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 0,
    },
    pickerRowStyle: {
        ...Platform.select({
            native: { height: 35, width: 30 },
            default: { height: 49, width: 49 },
        }),
        alignItems: 'center',
        justifyContent: 'center',
    },
});

function mapStateToProps(state) {
    const { profile } = state;
    return { profile };
}

export default connect(mapStateToProps, null)(AvatarSelector);
