// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable, ActivityIndicator } from 'react-native';
import type { GamesListElementViewData, GamesListGameData, ProfileInfo, AvatarWithNameData } from '../commons/RJTypes';

import * as CONSTANTS from '../commons/Constants';
import dataServer from '../store/Store';
import * as AGLSelector from './AGLSelector';
import AvatarWithName from '../components/AvatarWithName';
import { translate } from '../commons/translations/LangTransator';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronRight, faTrophyAlt, faComment } from '@fortawesome/pro-regular-svg-icons';
import { faStripeS } from '@fortawesome/free-brands-svg-icons';
import soundManager from '../commons/SoundManager';
import interstitialAd from '../commons/ads/InterstitialAd';
import themeConfigutation from '../commons/ThemeConfiguration';

type AGLTblVwElementType = {
    showActivityIndicator: boolean,
};

class AGLTblVwElement extends React.Component<{ ...GamesListElementViewData }, AGLTblVwElementType> {
    constructor(props: { ...GamesListElementViewData }) {
        super(props);
        this.state = {
            showActivityIndicator: false,
        };
    }
    lastPlayedTime = (tstmp: string): string => {
        let currdate = new Date();
        let lstplyddate = new Date(parseInt(tstmp) * 1000);
        let datediff = Math.abs(currdate - lstplyddate);
        let diffseconds = Math.ceil(datediff / 1000);
        let diffdays = Math.floor(diffseconds / (60 * 60 * 24));
        let lastplayedtime = '';
        if (diffdays > 0) {
            lastplayedtime = diffdays + translate('d_ago');
        } else {
            let hours = Math.floor(diffseconds / (60 * 60));
            if (hours > 0) {
                lastplayedtime = hours + translate('h_ago');
            } else {
                let minutes = Math.floor(diffseconds / 60);
                if (minutes > 0) {
                    lastplayedtime = minutes + translate('m_ago');
                } else {
                    lastplayedtime = diffseconds + translate('s_ago');
                }
            }
        }
        return lastplayedtime;
    };

    getGameScoresDescription = (data: GamesListGameData, mypid: string): string => {
        let mdfmypid = parseInt(mypid) - 1;
        let scores = data.players.map((item) => item.score);
        let dd = scores.splice(mdfmypid, 1);
        scores.unshift(dd[0]);
        return scores.join('/');
    };

    renderIcons = (data: GamesListGameData, showOppName: boolean, color: string) => {
        let hasUnseenMsg = () => {
            let unseenMsg = data.unreadmsg;
            if (unseenMsg !== undefined && unseenMsg !== null && Number(unseenMsg) > 0) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faComment} size={18} color={'#1d9df1'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displayTrophy = () => {
            if (showOppName) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faTrophyAlt} size={18} color={'#E8BE76'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displaySuperIcon = () => {
            let isSuperLxlsGame: boolean = data.boardtype === 'S';
            if (isSuperLxlsGame) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 12,
                        }}
                    >
                        <FontAwesomeIcon icon={faStripeS} size={18} color={'#E8BE76'} />
                    </View>
                );
            } else {
                return null;
            }
        };

        let displayArrowOrIndicator = () => {
            if (this.state.showActivityIndicator) {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                            paddingRight: 4,
                        }}
                    >
                        <ActivityIndicator size="small" color={color} />
                    </View>
                );
            } else {
                return (
                    <View
                        style={{
                            justifyContent: 'center',
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronRight} size={22} color={color} />
                    </View>
                );
            }
        };

        return (
            <View style={[styles.iconSectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {displaySuperIcon()}
                {hasUnseenMsg()}
                {displayTrophy()}
                {displayArrowOrIndicator()}
            </View>
        );
    };

    hideActivityIndicator = (): void => {
        this.setState({ showActivityIndicator: false });
    };

    renderArchivedGame(data: GamesListGameData, mypid: string, myguid: string, opppid: string, oppguid: string) {
        let imgicon = 1;
        let winnerpid = 1;
        let isdraw = false;
        if (data.winner !== null && data.winner != undefined) {
            winnerpid = data.winner[0];
            isdraw = data.winner.length > 1;
        }
        let mewinner = winnerpid === mypid;
        let showOppName = true;
        let winnerinfo = translate('you'); //used
        let playersinfo: { [string]: ProfileInfo } | null = AGLSelector.getAGLPlayersInfo(
            dataServer.getStore().getState(),
            data
        );
        let oppprofile = null;
        let oppname = '';
        if (playersinfo !== null) {
            oppprofile = playersinfo[oppguid];
            oppname = oppprofile.name;
        }
        //let oppprofile: ProfileInfo = this.props.playersinfo.oppguid;
        if (!mewinner) {
            if (oppprofile !== null && oppprofile.name !== undefined && oppprofile.name !== null) {
                winnerinfo = oppprofile.name;
                showOppName = false;
            }
        }

        let lostcolorcode = themeConfigutation.getColor('rgba(0, 0, 0, 0.54)');
        let woncolorcode = themeConfigutation.getColor('#28B463');
        let wonnamecolorcode = themeConfigutation.getColor('#000');

        let appliedwoncolorcode = woncolorcode;
        let appliedwonnamecolorcode = wonnamecolorcode;
        if (!mewinner) {
            appliedwoncolorcode = lostcolorcode;
            appliedwonnamecolorcode = lostcolorcode;
        }

        let won = '';
        if (isdraw) {
            winnerinfo = translate('won_tie');
        } else {
            won = translate('won');
            if (mewinner) {
                won = won + '!';
            }
        }

        let oppavtar = '1';
        if (oppprofile !== null && oppprofile.avtar !== null && oppprofile.avtar !== undefined) {
            oppavtar = oppprofile.avtar;
        }
        imgicon = CONSTANTS.avtarIcons[oppavtar]; //used
        let lastplayedtime = this.lastPlayedTime(data.lastupdate); //used
        let gamescore = this.getGameScoresDescription(data, mypid); //used

        let avtdata: AvatarWithNameData = {
            imgicon: imgicon,
            imgtxt: oppname,
        };

        return (
            <View style={[styles.sectionListStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {/* <Image
                    source={imgicon}
                    style={{
                        width: 50,
                        height: 50,
                        backgroundColor: '#f4f3ef',
                        alignSelf: 'center',
                        marginRight: 8,
                    }}
                /> */}
                <Pressable
                    onPress={() => {
                        if (this.props.imageTapHandler !== null && this.props.imageTapHandler !== undefined) {
                            let handler = this.props.imageTapHandler;
                            soundManager.playSound(soundManager.RJSound.RJSoundClick);
                            interstitialAd.showInterstitialAd(true, () => {
                                handler(oppguid);
                            });
                        }
                    }}
                    style={[styles.imageBtnStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <AvatarWithName showOppName={showOppName} data={avtdata} />
                </Pressable>
                <Pressable
                    onPress={() => {
                        this.setState({ showActivityIndicator: true });
                        soundManager.playSound(soundManager.RJSound.RJSoundClick);
                        setTimeout(() => {
                            if (this.props.gameTapHandler !== null && this.props.gameTapHandler !== undefined) {
                                let handler = this.props.gameTapHandler;
                                interstitialAd.showInterstitialAd(true, () => {
                                    handler(this.props.game, this.hideActivityIndicator);
                                });
                            }
                        }, 0);
                    }}
                    style={[styles.btnStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                >
                    <View>
                        <Text
                            numberOfLines={0}
                            style={{
                                fontSize: 18,
                                color: appliedwonnamecolorcode,
                            }}
                        >
                            {winnerinfo}
                            <Text
                                numberOfLines={0}
                                style={{
                                    color: appliedwoncolorcode,
                                    fontSize: 16,
                                }}
                            >
                                {won}
                            </Text>
                        </Text>
                        <Text
                            numberOfLines={1}
                            style={{
                                color: themeConfigutation.getColor('rgba(0, 0, 0, 0.54)'),
                                fontSize: 14,
                            }}
                        >
                            {lastplayedtime + ', ' + gamescore}
                        </Text>
                    </View>
                    {this.renderIcons(data, showOppName, 'grey')}
                </Pressable>
            </View>
        );
    }

    renderGameData(data: GamesListGameData) {
        let isarchivedgame = false;
        if (data.gameover_reason !== null && data.gameover_reason !== undefined) {
            isarchivedgame = data.gameover_reason;
        }
        let guid: string = CONSTANTS.Default_guid;
        let oppguid: string = CONSTANTS.Default_guid;
        let profile: ProfileInfo = AGLSelector.getMyProfile(dataServer.getStore().getState());
        if (profile.guid !== undefined && profile.guid !== null) {
            guid = profile.guid;
        }
        let me = data.players.find((element) => element.uid === guid);
        let mypid = '1';
        if (me !== undefined && me !== null) {
            mypid = me.pid;
        }

        let totalplayer = data.players.length;
        let lastmove = data.lastmove;
        let oppidx = 0; //index 0 based
        let myidx = parseInt(mypid) - 1;
        if (isarchivedgame) {
            oppidx = myidx - 1;
        } else if (lastmove !== '') {
            let qq = lastmove.split(',');
            oppidx = parseInt(qq[0]) - 1;
            if (myidx === oppidx) {
                oppidx = myidx - 1;
            }
        } else {
            oppidx = myidx - 1;
        }

        if (oppidx < 0) {
            oppidx = totalplayer - 1;
        }
        oppguid = data.players[oppidx].uid;
        let opppid = (oppidx + 1).toString();
        return this.renderArchivedGame(data, mypid, guid, opppid, oppguid);
    }

    render() {
        let data: GamesListGameData = ((this.props.game.data: any): GamesListGameData);
        return this.renderGameData(data);
    }
}

const styles = StyleSheet.create({
    sectionListStyle: {
        flex: 1,
        paddingLeft: 10,
        paddingRight: 10,
        paddingVertical: 4,
        flexDirection: 'row',
    },
    imageBtnStyle: {
        width: 28,
        height: 28,
        alignSelf: 'center',
        marginRight: 8,
    },
    btnStyle: {
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    iconSectionStyle: {
        flexGrow: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
});

export default AGLTblVwElement;
