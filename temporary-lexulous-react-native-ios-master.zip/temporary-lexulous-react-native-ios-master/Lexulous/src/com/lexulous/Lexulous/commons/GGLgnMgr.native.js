// @flow

import dataServer from '../store/Store';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import type { User } from '@react-native-google-signin/google-signin';
import { actionUpdateGGLLgnInfo } from '../userprofile/PFLAction';
import LgnMgr from './LgnMgr';
import { kGoogleLoginConfig } from './Constants';
import { handleException } from './RJUtils';

class GGLgnMgr extends LgnMgr {
    _userInfo: ?User = null;
    _error: ?string = null;
    _hasPlayServices = false;
    type = 'GGLgnMgr';

    constructor() {
        super();
        this._userInfo = null;
        this._error = null;
        GoogleSignin.configure(kGoogleLoginConfig);
        GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: false })
            .then((hasplayservices) => {
                this._hasPlayServices = hasplayservices;
            })
            .catch((error) => {
                this._hasPlayServices = false;
            });
    }

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        try {
            this._userInfo = null;
            this._error = null;
            await GoogleSignin.signOut();
            let delpendingassoc = await this.deletePendingAssociation();
            if (onCompletion) {
                onCompletion();
            }
            dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(null));
        } catch (error) {
            console.error(error);
            handleException(error);
        }
    };

    isUserLoggedIn(): boolean {
        let loggedin: boolean = this._userInfo !== null && this._userInfo !== undefined;
        return loggedin;
    }

    hasPlayServices = (): boolean => {
        return this._hasPlayServices;
    };

    doGoogleLogin = async (onCompletion: ?() => void): Promise<void> => {
        try {
            let templgninfo = await GoogleSignin.signIn();
            this._userInfo = templgninfo;
            this._error = null;
            let lgninfo = {
                userInfo: this._userInfo,
                error: null,
            };
            dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(lgninfo));
        } catch (error) {
            this._userInfo = null;
            this._error = error.code;
            dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(null));
            handleException(error);
        }
        if (onCompletion) {
            onCompletion();
        }
    };

    checkLoginSilentMode = async (): Promise<void> => {
        try {
            const currentUser: any = await GoogleSignin.getCurrentUser();
            if (currentUser != null && currentUser != undefined) {
                let templgninfo: any = currentUser;
                this._userInfo = templgninfo;
                this._error = null;
                let lgninfo = {
                    userInfo: this._userInfo,
                    error: null,
                };
                dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(lgninfo));
            }
        } catch (error) {
            this._userInfo = null; //TO DO
            this._error = error.code;
            dataServer.getStore().dispatch(actionUpdateGGLLgnInfo(null));
            handleException(error);
        }
    };
}

const gglLgnMgr: GGLgnMgr = new GGLgnMgr();
export default gglLgnMgr;
