import React from 'react';
import { StyleSheet, TouchableOpacity, View, Pressable } from 'react-native';
import DimensionUtils from '../utils/DimensionUtils';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import LayoutUtils from '../utils/LayoutUtils';
import { to } from 'await-to-js';
import {
    acceptRejectGamePlayRequest,
    cancelGamePlayRequest,
    getGameType,
    isSoloGame,
    sendLiveGameRequest,
} from '../service/GamePlayService';
import get from 'lodash/get';
import { getEventKeyCode } from '../utils/Utils';
import { onStartAnalyse, showAnalysePurchaseDialog, getGameRequestText, getDictionaryDetails } from '../utils/GameBoardUtils';
import { replaceLocation } from '../utils/UrlUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import { createDialogInstance } from '../utils/MessageUtils';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import { CHAT_CLEAR_LIST, GAME_SIDE_LAYOUT_ACTIVE_TAB_SET } from '../configs/ActionIdentifiers';
import Timer from 'react-compound-timer';
import { formatToTwoDigits } from '../utils/Utils';
import { connect } from 'react-redux';
import log from 'loglevel';
import S22Text from '../component/S22Text';
import S14Text from '../component/S14Text';
import { sendEmailRematchRequest } from '../service/EmailGamePlayService';
import FontAwesomeSpin from '../component/FontAwesomeSpin';
import LayoutWrapper from '../utils/LayoutWrapper';

require('format-unicorn');
const eventBus = require('js-event-bus')();

const dialogModalContent = {
    sendPuzzleMoveFail_title: 'Message',
    sendPuzzleMoveFail_cancelButtonText: 'OK',
};

class DialogModal extends React.Component {
    state = {
        isOpen: false,
        title: undefined,
        body: undefined,
        actionButtonText: undefined,
        cancelButtonText: 'Cancel',
        onCancel: undefined,
        onAction: undefined,
        width: get(this.props, 'layout.layoutDialogModalMainContainerWidth'),
        hideCancel: false,
        notDismissable: false,
        showSignInOptions: false,
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        showOverlay: false,
        rematchTimer: false,
    };

    onKeyUp = (event) => {
        let code = getEventKeyCode(event);
        if (code.includes('Escape') && this.isCancellable() && this.isOpen()) {
            this.onCancel();
        } else if (code.includes('Enter')) {
            if (this.isOpen() && this.isConfirmableByKey()) {
                this.onAction();
            }
        }
    };

    componentDidMount = () => {
        eventBus.on(Config.MATCH_REMATCH_RESPONSE_EVENT, this.onRematchMatchResponse);
        eventBus.on(Config.CANCEL_GAME_INVITATION_EVENT, this.onCancelMatchResponse);
        eventBus.on(Config.MATCH_REQUEST_REJECTED_EVENT, this.onMatchRequestRejected);
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.MATCH_REMATCH_RESPONSE_EVENT, this.onRematchMatchResponse);
        eventBus.on(Config.CANCEL_GAME_INVITATION_EVENT, this.onCancelMatchResponse);
        eventBus.detach(Config.MATCH_REQUEST_REJECTED_EVENT, this.onMatchRequestRejected);
    };

    isConfirmableByKey = () => this.state.isConfirmableByKey;

    show = ({
        code,
        title = dialogModalContent[code + '_title'],
        body = dialogModalContent[code + 'body'],
        actionButtonText = dialogModalContent[code + '_actionButtonText'],
        onAction,
        cancelButtonText = dialogModalContent[code + '_cancelButtonText'],
        onCancel,
        hideCancel,
        notDismissable,
        showSignInOptions,
        isConfirmableByKey,
        scoringData,
        dialogType,
        notAutoCancellable,
        isResign,
        isMultiPlayer,
        secondButtonText,
        secondActionClick,
        thirdButtonText,
        thirdActionClick,
        gameReqMessage,
    } = {}) =>
        this.setState({
            isOpen: true,
            title,
            body,
            actionButtonText,
            onAction,
            cancelButtonText,
            onCancel,
            hideCancel,
            notDismissable,
            showSignInOptions,
            isConfirmableByKey,
            scoringData,
            dialogType,
            notAutoCancellable,
            isResign,
            secondButtonText,
            secondActionClick,
            thirdButtonText,
            thirdActionClick,
            isMultiPlayer,
            showOverlay: false,
            gameReqMessage,
        });

    hide = () => {
        let wasOpen = this.state.isOpen;
        this.setState({
            isOpen: false,
            showOverlay: false,
            rematchReq: false,
        });
        return wasOpen;
    };

    onAction = () => this.setState(this.getStateForAction(), this.handleAction);

    getStateForAction = () => {
        switch (this.state.dialogType) {
            case Config.DIALOG_TYPE_REMATCH:
                if (this.state.isMultiPlayer) {
                    return {
                        isOpen: false,
                        showOverlay: false,
                    };
                }
                break;
            case Config.DIALOG_TYPE_REMATCH_CONFIG_CONFIRM:
                return { showOverlay: true };
            default:
                return {
                    isOpen: false,
                    showOverlay: false,
                };
        }
    };

    handleAction = () => {
        let func;
        switch (this.state.dialogType) {
            case Config.DIALOG_TYPE_REMATCH:
                if (!this.state.isMultiPlayer) func = this.onRematchClick;
                break;
            default:
                func = this.state.onAction;
                break;
        }
        func && func();
    };

    onRematchClick = () => {
        switch (getGameType()) {
            case Config.GAME_TYPE_EMAIL: {
                this.onEmailGameRematchClick();
                break;
            }
            case Config.GAME_TYPE_LIVE_GAME: {
                this.getOpponent();
                this.setState({ rematchTimer: true });
                break;
            }
            case Config.GAME_TYPE_SOLO: {
                this.rematchSoloGame();
                break;
            }
            default:
                break;
        }
    };

    onEmailGameRematchClick = () => {
        let dic = getDictionaryDetails(this.props.game.dic).abreviations;
        createDialogInstance({
            title: 'Rematch',
            actionButtonText: 'Yes',
            onAction: this.onSendEmailGameRematchRequest,
            secondButtonText: 'No',
            secondActionClick: this.proceedToNewEmailGame,
            body: 'Do you wish to start another game using the ' + dic + ' word list?',
            dialogType: Config.DIALOG_TYPE_REMATCH_CONFIG_CONFIRM,
        });
    };

    proceedToNewEmailGame = () => {
        replaceLocation(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('rematch_link').formatUnicorn({
                gid: this.props.game.gid,
            })
        );
    };

    peekHasOpponents = () => {
        let opponents = get(this.props, 'game.players').filter(
            (player) => get(player, 'guid') !== get(this.props, 'game.guid')
        );
        let hasOpponents = opponents && opponents.length > 0;
        return { opponents, hasOpponents };
    };

    getOpponent = () => {
        let data = this.peekHasOpponents(true);
        data.hasOpponents && this.onSendGameRequest({ guid: data.opponents[0].guid });
        return data.hasOpponents;
    };

    onSendGameRequest = async (opts) => {
        await this.setState({ showOverlay: true });
        let res = await to(sendLiveGameRequest(opts));
        if (res[1]) {
            this.setState({
                showOverlay: false,
                timerValue: parseInt(get(res[1], 'data.wait')) * 1000,
                isReqRecived: false,
                secret: get(res[1], 'data.secret'),
                rematchReq: true,
            });
        }
    };

    onSendEmailGameRematchRequest = async () => {
        await this.setState({ showOverlay: true });
        let res = await to(sendEmailRematchRequest());
        if (res[0]) {
            this.setState({
                showOverlay: false,
                dialogType: undefined,
                title: undefined,
                body: 'Unable to send request',
                gameReqMessage: undefined,
                rematchReq: false,
                actionButtonText: 'OK',
                onAction: this.hide,
            });
        } else {
            let isProUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isProUser');
            if (
                isProUser ||
                !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb') ||
                DimensionUtils.isNative()
            ) {
                let players = get(res[1], 'data.' + this.props.game.channel + '.players');
                let selfPlayer = players.find((player) => player.guid === this.props.game.guid);
                let data = {
                    gid: get(res[1], 'data.' + this.props.game.channel + '.gid'),
                    dic: get(res[1], 'data.' + this.props.game.channel + '.dic'),
                    pid: get(selfPlayer, 'pid'),
                };
                //eventBus.emit(Config.RESTART_APP, null, data);
                eventBus.emit(CHAT_CLEAR_LIST);
                eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, null, data);
            } else {
                replaceLocation(
                    ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('email_game_link_format').formatUnicorn({
                        gid: get(res[1], 'data.' + this.props.game.channel + '.gid'),
                    })
                );
            }
        }
    };

    rematchSoloGame = () => {
        this.setState({ isOpen: false });
        eventBus.emit(Config.HIDE_BOARD_CONTAINER);
        log.info('SoloReducer, emitting Config.RESTART_APP');
        /* eventBus.emit(Config.RESTART_APP, null, {
            soloNewGame: this.props.game.soloDemoAcc
                ? Config.SOLO_NO_LOGIN_NEW_GAME
                : Config.SOLO_REMATCH,
        }); */
        eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, null, {
            soloNewGame: this.props.game.soloDemoAcc ? Config.SOLO_NO_LOGIN_NEW_GAME : Config.SOLO_REMATCH,
        });
        this.setState({ isOpen: false });
    };

    onCancel = () => this.setState(this.getStateForCancel(), this.handleCancel);

    getStateForCancel = () => {
        switch (this.state.dialogType) {
            /* case Config.DIALOG_TYPE_REMATCH:
                return {}; */
            default:
                return { isOpen: false };
        }
    };

    handleCancel = () => {
        let func;
        switch (this.state.dialogType) {
            /* case Config.DIALOG_TYPE_REMATCH:
                func = this.onRematchClick;
                break; */
            default:
                func = this.state.onCancel;
                break;
        }
        func && func();
    };

    isRematchDialog = () => this.state.dialogType === Config.DIALOG_TYPE_REMATCH;

    isOpen = () => this.state.isOpen;

    isCancellable = () => !this.state.notDismissable;

    isAutoCancellable = () =>
        !Config.NOT_AUTO_CANCELLABLE_DIALOG_TYPES.includes(this.state.dialogType) && !this.state.notAutoCancellable;

    getIsConfirmableByKey = () => this.state.isConfirmableByKey;

    checkAndHide = () => {
        if (this.isCancellable()) {
            this.onCancelPress();
            return true;
        }
        return false;
    };

    hasSecondAction = () =>
        (this.isRematchDialog() && !(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('delete')) ||
        !!this.state.secondButtonText;

    getSecondActionText = () => (this.isRematchDialog() ? 'ANALYSE' : this.state.secondButtonText);

    onSecondActionClick = () => {
        if (this.isRematchDialog()) {
            this.onAnalyseClick();
        } else {
            this.state.secondActionClick && this.state.secondActionClick();
            this.setState({ isOpen: false });
        }
    };

    hasThirdAction = () =>
        (this.state.scoringData && !this.state.isResign && !this.state.rematchTimer) || !!this.state.thirdButtonText;
    getThirdActionText = () =>
        this.state.scoringData && !this.state.isResign && !this.state.rematchTimer ? 'SCORING' : this.state.thirdButtonText;
    onThirdActionClick = () => {
        if (this.state.scoringData && !this.state.isResign && !this.state.rematchTimer) {
            this.onShowScoringData();
        } else {
            this.state.thirdActionClick && this.state.thirdActionClick();
            this.setState({ isOpen: false });
        }
    };

    onAnalyseClick = async () => {
        let isProUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isProUser');
        let isAnalyseUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isAnalyseUser');

        if (isProUser || isAnalyseUser) {
            this.setState({ showOverlay: true });
            await onStartAnalyse();
            this.setState({ isOpen: false });
            eventBus.emit(GAME_SIDE_LAYOUT_ACTIVE_TAB_SET, null, 2);
        } else {
            showAnalysePurchaseDialog();
        }
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.onCancelPress();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile() ? '100%' : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    render = () =>
        this.state.isOpen ? (
            <View style={this.getModalContentStyle()}>
                <View style={[LayoutUtils.getDialogMainContainerStyle(), this.getContainerDimension()]}>
                    <View style={LayoutUtils.getDialogTitleContainerStyle()}>
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>{this.state.title}</S22Text>
                        <TouchableOpacity
                            activeOpacity={1}
                            style={[styles.closeButtonContainer]}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <View
                                style={[
                                    {
                                        backgroundColor: this.state.closeBGColor,
                                    },
                                    LayoutUtils.getDialogCloseButtonBGStyle(),
                                ]}
                            >
                                <FontAwesomeIcon
                                    size={DimensionUtils.isMobile() ? 20 : 24}
                                    icon={faTimes}
                                    style={this.getCloseButtonStyle()}
                                />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <S14Text
                        style={[
                            styles.bodyText,
                            LayoutUtils.getDialogBodyContainerStyle(),
                            LayoutUtils.getCursorDefaultStyle(),
                        ]}
                    >
                        {this.state.body}
                    </S14Text>
                    {this.state.gameReqMessage && this.state.gameReqMessage.length > 0 ? (
                        <S14Text
                            style={[
                                styles.bodyText,
                                LayoutUtils.getDialogBodyContainerStyle(),
                                LayoutUtils.getCursorDefaultStyle(),
                                styles.gameReqMessage,
                            ]}
                        >
                            {this.state.gameReqMessage}
                        </S14Text>
                    ) : null}
                    {/* Body Buttons Start */}
                    <View
                        style={[
                            LayoutUtils.getDialogBodyBtnContainerStyle(),
                            DimensionUtils.isMobile() ? styles.buttonContainerMobileOverride : undefined,
                        ]}
                    >
                        {this.hasThirdAction() ? (
                            <Pressable
                                style={[
                                    LayoutUtils.getBottonStyle(),
                                    DimensionUtils.isMobile()
                                        ? LayoutUtils.getDialogThirdActionButtonStyle()
                                        : LayoutUtils.getDialogSecondActionButtonStyle(),
                                ]}
                                onPress={this.onThirdActionClick}
                            >
                                <S14Text style={LayoutUtils.getBottonTextBlueStyle()}>{this.getThirdActionText()}</S14Text>
                            </Pressable>
                        ) : null}
                        {!isSoloGame() && this.hasSecondAction() ? (
                            <Pressable
                                style={[LayoutUtils.getDialogSecondActionButtonStyle(), LayoutUtils.getBottonStyle()]}
                                onPress={this.state.rematchReq ? this.onRematchReject : this.onSecondActionClick}
                            >
                                <S14Text style={LayoutUtils.getBottonTextBlueStyle()}>
                                    {this.state.rematchReq
                                        ? this.state.isReqRecived
                                            ? 'REJECT'
                                            : 'CANCEL'
                                        : this.getSecondActionText()}
                                </S14Text>
                            </Pressable>
                        ) : null}
                        {this.state.onAction ? (
                            <Pressable
                                style={[
                                    LayoutUtils.getDialogActionButtonStyle(this.state.rematchReq),
                                    LayoutUtils.getBottonStyle(),
                                ]}
                                onPress={this.state.rematchReq ? this.onRematchReqAction : this.onActionPress}
                            >
                                <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                    {this.state.rematchReq
                                        ? this.renderButtonTimerView(this.state.isReqRecived ? 'ACCEPT' : 'WAITING FOR OPP')
                                        : this.state.actionButtonText}
                                </S14Text>
                            </Pressable>
                        ) : this.state.hideCancel ? null : (
                            <Pressable
                                style={[LayoutUtils.getDialogActionButtonStyle(), LayoutUtils.getBottonStyle()]}
                                onPress={this.onCancelPress}
                            >
                                <S14Text style={LayoutUtils.getBottonTextStyle()}>
                                    {this.state.cancelButtonText || 'CANCEL'}
                                </S14Text>
                            </Pressable>
                        )}
                    </View>
                    {/* Body Buttons End */}

                    {this.state.showOverlay ? (
                        <View style={[StyleSheet.absoluteFill, styles.overlayContainer]}>
                            <FontAwesomeSpin />
                        </View>
                    ) : null}
                </View>
            </View>
        ) : null;

    renderButtonTimerView = (buttonText) => (
        <View style={styles.rowDirection}>
            <S14Text style={styles.timerText}>{buttonText + ' ('}</S14Text>
            <Timer
                initialTime={this.state.timerValue}
                startImmediately={true}
                direction={'backward'}
                checkpoints={[
                    {
                        time: 0,
                        callback: this.showExpiredMessage,
                    },
                ]}
            >
                <S14Text style={styles.timerText}>
                    <Timer.Minutes formatValue={formatToTwoDigits} />
                    <S14Text style={styles.timerText}>{':'}</S14Text>
                    <Timer.Seconds formatValue={formatToTwoDigits} />
                </S14Text>
            </Timer>
            <S14Text style={styles.timerText}>{')'}</S14Text>
        </View>
    );

    getContainerDimension = () => ({
        width: DimensionUtils.isMobile() ? '90%' : '53%',
        //maxHeight: '90%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    onShowScoringData = () => {
        eventBus.emit(Config.SHOW_SCORING_DETAILS_MODAL, null, this.state.scoringData);
    };

    onActionPress = () => this.onAction('action');

    onCancelPress = () => this.onCancel();

    showExpiredMessage = () => {
        this.setState({
            showOverlay: false,
            title: 'Request Expired',
            dialogType: undefined,
            actionButtonText: 'OK',
            onAction: this.hide,
            body: 'The player did not respond to your rematch request',
            gameReqMessage: undefined,
            rematchReq: false,
            rematchTimer: false,
        });
    };

    onRematchReject = async () => {
        if (this.state.isReqRecived) {
            let req = await to(acceptRejectGamePlayRequest({ secret: this.state.secret }, false));
        } else {
            let req = await to(cancelGamePlayRequest({ secret: this.state.secret }));
            this.setState({
                rematchTimer: false,
            });
        }
        if (this.isOpen()) {
            let data = this.peekHasOpponents();
            this.setState({
                gameReqMessage: getGameRequestText({
                    opponentName: get(this.state.sender, 'name') || (data.hasOpponents && data.opponents[0].name),
                    rematchData: { accept: false },
                }),
                rematchReq: false,
            });
        }
    };

    onRematchReqAction = async () => {
        if (this.state.isReqRecived) {
            acceptRejectGamePlayRequest({ secret: this.state.secret }, true);
        }
    };

    onRematchMatchResponse = (data) => {
        let sender = get(data, 'sender');
        let isReqRecived = get(data, 'p2uid') === get(this.props, 'game.guid');
        if (this.isOpen()) {
            this.setState({
                gameReqMessage: getGameRequestText({
                    opponentName: get(sender, 'name'),
                    rematchData: { accept: true },
                }),
                secret: get(data, 'secret'),
                timerValue: parseInt(get(data, 'wait')) * 1000,
                sender,
                isReqRecived,
                rematchReq: true,
                showOverlay: false,
            });
        }
    };

    onCancelMatchResponse = (data) => {
        if (this.isOpen()) {
            this.setState({
                gameReqMessage: getGameRequestText({
                    opponentName: get(this.state.sender, 'name'),
                    rematchData: { accept: false },
                }),
                rematchReq: false,
            });
        }
    };

    onMatchRequestRejected = () => {
        if (this.isOpen())
            this.setState({
                showOverlay: false,
                dialogType: undefined,
                title: undefined,
                body: 'Player has rejected game request',
                gameReqMessage: undefined,
                rematchReq: false,
                actionButtonText: 'OK',
                onAction: this.hide,
            });
    };
}

const styles = StyleSheet.create({
    //Main Renders Styles
    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },

    bodyText: {
        flex: 1,
        justifyContent: 'center',
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },
    signInButtonsContainer: {
        alignSelf: 'center',
        flexDirection: 'row',
    },
    bodyBtnContainerWithSignInOptions: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-end',
        marginTop: Config.DIALOG_GENERAL_MARGIN,
    },
    transparent: {
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    center: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    scoringInfoMargin: {
        marginTop: 10,
    },
    scoringInfoTextColor: {
        color: ColorConfig.ALERT_OTHER_BUTTON_TEXT_COLOR,
    },
    flexOne: {
        flex: 1,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
    rowDirection: {
        flexDirection: 'row',
    },
    overlayContainer: {
        height: '100%',
        width: '100%',
        borderRadius: 4,
        backgroundColor: ColorConfig.MAIN_CONTAINER_BACKGROUND_COLOR,
        justifyContent: 'center',
        alignItems: 'center',
    },
    btn: {
        marginTop: 5,
        padding: 5,
        borderRadius: 3,
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
    },
    btnTextStyle: {
        color: '#000',
    },
    marginFive: {
        margin: 5,
    },
    timerText: {
        color: ColorConfig.ALERT_BUTTON_TEXT_COLOR,
        alignSelf: 'center',
    },
    gameReqMessage: { fontWeight: 'bold', marginTop: 16 },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(DialogModal);
