// @flow
import type { AppleRequestResponse, AppleCredentialState } from '@invertase/react-native-apple-authentication';
import LgnMgr from './LgnMgr';
import type { AppleLoginInfo, RegisterAppleUserRequest } from './RJTypes';

class ApplLgnMgr extends LgnMgr {
    type = 'ApplLgnMgr';
    constructor() {
        super();
        this.onAppInit();
    }

    onAppInit = (): void => {
        //eventlistener will be called by apple
    };

    //apple login started check if logged in previously
    fetchAndUpdateAppleCredentialState = async (user: string) => {};

    checkLoginSilentMode = async (): Promise<void> => {};

    signInWithApple = async (
        onCompletion: ?(c: ?() => void, a: AppleCredentialState, b: AppleRequestResponse) => Promise<void>,
        onCompletionCallback: ?() => void
    ): Promise<void> => {
        if (onCompletion) {
            onCompletion(onCompletionCallback, null, null);
        }
    };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {};

    deleteAppleLoginInfo = async (): Promise<boolean> => {
        return true;
    };

    getDataFromAppleCredential = (appleAuthRequestResponse: AppleRequestResponse) => {
        let bulkdata = {};
        let rdxdata: AppleLoginInfo = {};
        let regdata: RegisterAppleUserRequest = {};
        return { bulkdata, rdxdata, regdata };
    };
}
const applLgnMgr: ApplLgnMgr = new ApplLgnMgr();

export default applLgnMgr;
