import {
    DIMENSION_SCREEN_RESIZE,
    LAYOUT_REDUCER_SET_FIELD,
    LAYOUT_SET_BOARD_ABOVE_VIEWS_HEIGHT,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import cloneDeep from 'lodash/cloneDeep';
import Config from '../configs/Config';
import DimensionUtils from '../utils/DimensionUtils';
import { StyleSheet } from 'react-native';
import { isLiveGame, isPuzzleGame } from '../service/GamePlayService';
import log from 'loglevel';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';

const INITIAL_STATE = {
    cellDimen: 0,
    boardWidth: 0,
    layoutCellDimen: 0,
    layoutSidePanelTitleBarPadding: 0,
    layoutSidePanelBodyPadding: 0,
    layoutButtonStyles: {
        width: 0,
        height: 0,
        fontSize: 0,
    },
    layoutButtonStylesrRoundingEdge: {
        width: 0,
        height: 0,
        fontSize: 0,
        borderRadius: 0,
    },
    layoutRackStartMargin: 0,
    layoutRackStartMarginOriginal: 0,
    layoutRackContainerHeight: 0,
    layoutTileMarginInRack: 0,
    layoutDialogModalMainContainerWidth: 0,
    layoutSidePanelWidth: 0,
    layoutBoardDimenWidth: 0,
    layoutTileRackMargin: 0,
    layoutFontAwesomeIconSize: 0,
    layoutBoardAboveViewsHeight: 0,
};

const getRackRevealSolutionHeight = (state) =>
    DimensionUtils.isMobile()
        ? 3 * get(state, 'layoutCellDimen')
        : get(state, 'layoutTileBoardRackHeight') -
          get(state, 'boardDimen') -
          (isPuzzleGame() ? 0 : get(state, 'layoutBoardAboveViewsHeight', 0));

const layoutReducer = (state = INITIAL_STATE, action) => {
    let globalState = get(action, 'globalState');
    switch (action.type) {
        case DIMENSION_SCREEN_RESIZE: {
            let layoutBoardAboveViewsHeight = get(state, 'layoutBoardAboveViewsHeight', 0);

            state = cloneDeep(state);
            let fieldsToUpdateInit = DimensionUtils.getInitValues(action.payload);

            Object.assign(state, fieldsToUpdateInit);

            if (!!action.payload) {
                let newDimens = calculateWindowSizesAndGetState({
                    globalState,
                    container: action.payload,
                });

                newDimens.layoutRackStartMarginOriginal =
                    get(newDimens, 'layoutBoardLeft') +
                    get(newDimens, 'layoutBoardWidth') * 0.1 +
                    get(newDimens, 'layoutCellDimen') * 2;
                newDimens.cellDimen = get(newDimens, 'layoutCellDimen');
                newDimens.boardWidth = get(newDimens, 'layoutBoardWidth');
                newDimens.layoutTileMarginInRack = Math.min(3, newDimens.boardWidth * 0.01);
                newDimens.layoutSidePanelTitleBarPadding = get(newDimens, 'fontSize') * 0.3;
                newDimens.layoutSidePanelBodyPadding = get(newDimens, 'fontSize') * 0.9;
                newDimens.layoutButtonStyles = {
                    width: newDimens.cellDimen + 2 * (newDimens.cellDimen / 3.5),
                    height: newDimens.cellDimen,
                    fontSize: newDimens.cellDimen / 2.3,
                };
                newDimens.layoutButtonStylesrRoundingEdge = {
                    width: newDimens.cellDimen,
                    height: newDimens.cellDimen,
                    fontSize: newDimens.cellDimen / 2.3,
                    borderRadius: newDimens.cellDimen / 8,
                };

                newDimens.layoutRackStartMargin =
                    get(action.payload, 'width') + newDimens.boardWidth * 0.1 + newDimens.cellDimen * 2;

                newDimens.layoutDialogModalMainContainerWidth = Math.min(
                    DimensionUtils.isMobile() ? get(action.payload, 'width') * 0.8 : get(action.payload, 'width') * 0.6,
                    400
                );
                newDimens.layoutSidePanelWidth = get(action.payload, 'width') - newDimens.boardWidth - Config.RIGHT_LEFT_MARGIN;
                newDimens.layoutTileRackMargin = newDimens.cellDimen / 10;
                newDimens.layoutFontAwesomeIconSize = newDimens.cellDimen / 2.3;
                newDimens.layoutGamePlayAreaHeight = DimensionUtils.isMobile()
                    ? get(action.payload, 'height') / 2
                    : get(action.payload, 'height') - (isLiveGame() ? Config.LOBBY_CHAT_VIEW_HEIGHT : 0);
                newDimens.screenWidth = get(action.payload, 'width');
                newDimens.screenHeight = get(action.payload, 'height');
                log.info(
                    "layoutRackContainerHeight, in LayoutReducer, 1st case, get(newDimens, 'layoutGamePlayAreaHeight') is:\n " +
                        JSON.stringify(get(newDimens, 'layoutGamePlayAreaHeight'), null, 2)
                );
                log.info(
                    "layoutRackContainerHeight, in LayoutReducer, 1st case, get(state, 'layoutBoardAboveViewsHeight') is:\n " +
                        JSON.stringify(get(state, 'layoutBoardAboveViewsHeight'), null, 2)
                );
                log.info(
                    "layoutRackContainerHeight, in LayoutReducer, 1st case, get(newDimens, 'layoutBoardWidth') is:\n " +
                        JSON.stringify(get(newDimens, 'layoutBoardWidth'), null, 2)
                );
                newDimens.layoutRackContainerHeight =
                    DimensionUtils.isMobile() || get(globalState, 'game.board_type') === 'super'
                        ? Math.max(
                              100,
                              Math.min(
                                  200,
                                  get(newDimens, 'layoutGamePlayAreaHeight') -
                                      (get(state, 'layoutBoardAboveViewsHeight') + get(newDimens, 'layoutBoardWidth'))
                              )
                          )
                        : get(newDimens, 'layoutGamePlayAreaHeight') -
                          (get(state, 'layoutBoardAboveViewsHeight') + get(newDimens, 'layoutBoardWidth'));
                log.info(
                    'layoutRackContainerHeight, in LayoutReducer, 1st case, state.layoutRackContainerHeight is ' +
                        newDimens.layoutRackContainerHeight
                );

                newDimens.layoutTileMarginInRack = Math.min(3, get(newDimens, 'layoutBoardWidth') * 0.01);
                newDimens.layoutTileBoardRackHeight =
                    layoutBoardAboveViewsHeight +
                    get(newDimens, 'layoutBoardWidth') +
                    get(newDimens, 'layoutRackContainerHeight');

                log.info(
                    'in LayoutReducer, in DIMENSION_SCREEN_RESIZE case, state.layoutBoardAboveViewsHeight is ' +
                        state.layoutBoardAboveViewsHeight
                );
                log.info('in LayoutReducer, state is:\n' + JSON.stringify(state, null, 2));

                Object.assign(state, newDimens);

                state.layoutRevealSolutionHeight = getRackRevealSolutionHeight(state);
                log.info(
                    "in LayoutReducer, get(state, 'layoutTileBoardRackHeight') is: " + get(state, 'layoutTileBoardRackHeight')
                );
                log.info("in LayoutReducer, get(state, 'layoutBoardDimenWidth') is: " + get(state, 'layoutBoardDimenWidth'));
                log.info('in LayoutReducer, isPuzzleGame() is: ' + isPuzzleGame());
                log.info(
                    "in LayoutReducer, get(state, 'layoutBoardAboveViewsHeight', 0) is: " +
                        get(state, 'layoutBoardAboveViewsHeight', 0)
                );
                log.info('in LayoutReducer, state.layoutRevealSolutionHeight is: ' + state.layoutRevealSolutionHeight);
            }
            calculateCellDimensionsAndPositions(state, globalState);
            break;
        }
        case LAYOUT_SET_BOARD_ABOVE_VIEWS_HEIGHT: {
            state = cloneDeep(state);
            state.layoutBoardAboveViewsHeight = get(action, 'payload');

            state.layoutRackContainerHeight = DimensionUtils.isMobile()
                ? Math.max(
                      100,
                      Math.min(
                          200,
                          get(state, 'layoutGamePlayAreaHeight') -
                              (get(state, 'layoutBoardAboveViewsHeight') + get(state, 'layoutBoardWidth'))
                      )
                  )
                : get(state, 'layoutGamePlayAreaHeight') -
                  (get(state, 'layoutBoardAboveViewsHeight') + get(state, 'layoutBoardWidth'));

            log.info(
                'layoutRackContainerHeight, in LayoutReducer, 2nd case, state.layoutRackContainerHeight is ' +
                    state.layoutRackContainerHeight
            );

            state.layoutTileBoardRackHeight =
                get(state, 'layoutBoardAboveViewsHeight') +
                get(state, 'layoutBoardWidth') +
                get(state, 'layoutRackContainerHeight');
            state.layoutRevealSolutionHeight = getRackRevealSolutionHeight(state);
            log.info('in LayoutReducer, state.layoutRevealSolutionHeight is: ' + state.layoutRevealSolutionHeight);
            calculateCellDimensionsAndPositions(state, globalState);
            break;
        }
        case LAYOUT_REDUCER_SET_FIELD: {
            state = cloneDeep(state);
            let payload = get(action, 'payload') ?? {};
            Object.assign(state, payload);
            calculateCellDimensionsAndPositions(state, globalState);
            break;
        }
    }

    return state;
};

const calculateCellDimensionsAndPositions = (state, globalState) => {
    state.cellDimensions = [];
    let boardSize = get(globalState, 'game.board_size');
    let containerPosition = DimensionUtils.getContainerPosition();
    let offsetXBy = containerPosition.left;
    let offsetYBy = containerPosition.top + get(state, 'layoutBoardAboveViewsHeight', 0);

    for (let x = 0; x < boardSize; x++) {
        state.cellDimensions[x] = [];
        for (let y = 0; y < boardSize; y++) {
            state.cellDimensions[x][y] = {};
            let cell = state.cellDimensions[x][y];
            cell.tileX = x;
            cell.tileY = y;
            let cellWidth = state.layoutCellDimen;
            let cellHeight = state.layoutCellDimen;

            cell.layout = {
                x: cell.tileX * cellWidth,
                y: 0,
                width: cellWidth,
                height: cellHeight,
            };

            cell.tileStartYUnscaledUnoffset = cell.tileY * cellHeight;
            cell.tileEndYUnscaledUnoffset = cell.tileStartYUnscaledUnoffset + cellHeight;
            cell.tileStartXUnscaledUnoffset = cell.layout.x;
            cell.tileEndXUnscaledUnoffset = cell.tileStartXUnscaledUnoffset + cellWidth;

            cell.tileStartX = offsetXBy + cell.tileStartXUnscaledUnoffset;
            cell.tileEndX = offsetXBy + cell.tileEndXUnscaledUnoffset;
            cell.tileStartY = offsetYBy + cell.tileStartYUnscaledUnoffset;
            cell.tileEndY = offsetYBy + cell.tileEndYUnscaledUnoffset;
        }
    }

    log.info('in LayoutReducer, state.cellDimensions is: ' + JSON.stringify(state.cellDimensions, null, 2));
};

const getGamePlayAreaHeight = ({ globalState } = {}) => {
    let isMobile = DimensionUtils.isMobile();
    let isSuperBoard = get(globalState, 'game.board_type') === 'super';
    let divDimens = DimensionUtils.getWindowDimensions({ divDimensOnly: true });
    let defaultDimens = DimensionUtils.getWindowDimensions();
    let result =
        isMobile || isSuperBoard
            ? divDimens.height / 2
            : defaultDimens.height - (isLiveGame() ? Config.LOBBY_CHAT_VIEW_HEIGHT + Config.RIGHT_LEFT_MARGIN : 0);
    return result;
};

const calculateWindowSizesAndGetState = ({ globalState, container } = {}) => {
    let boardDimen,
        dimen,
        cellDimen,
        tileDimen,
        calculationDifference,
        step = 1;

    let board_size = get(globalState, 'game.board_size');

    boardDimen = container.width - board_size * StyleSheet.hairlineWidth;
    dimen = Math.floor(boardDimen / board_size);
    if (
        get(globalState, 'game.board_type') === 'super' &&
        !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
    ) {
        let heightWidthDiff = container.height - container.width;
        if (heightWidthDiff < 250) {
            dimen = dimen * 0.7;
        } else if (heightWidthDiff < 300) {
            dimen = dimen * 0.75;
        } else if (heightWidthDiff < 350) {
            dimen = dimen * 0.8;
        } else if (heightWidthDiff < 400) {
            dimen = dimen * 0.85;
        } else if (heightWidthDiff < 455) {
            dimen = dimen * 0.9;
        } else if (heightWidthDiff < 500) {
            dimen = dimen * 0.95;
        }
    }
    boardDimen = dimen * board_size + (board_size + 1) * StyleSheet.hairlineWidth;

    let totalHeaderBoardRackHeight = boardDimen + dimen + 70;

    let gamePlayAreaHeight = getGamePlayAreaHeight({ globalState });

    let totalDifference = totalHeaderBoardRackHeight - gamePlayAreaHeight;

    if (!DimensionUtils.isMobile() && !(get(globalState, 'game.board_type') === 'super')) {
        if (totalDifference > 56) {
            let totalReductionRequiredRatio = totalDifference / totalHeaderBoardRackHeight;

            step = step - totalReductionRequiredRatio;

            boardDimen = container.width * step - (board_size + 1) * StyleSheet.hairlineWidth;
            dimen = Math.floor(boardDimen / board_size);
            boardDimen = dimen * board_size /*+
            (Config.CLASSIC_BOARD_SIZE_FIFTEEN + 1) * StyleSheet.hairlineWidth*/;
        }

        totalDifference =
            totalHeaderBoardRackHeight -
            getGamePlayAreaHeight({
                globalState,
            }); /* - Config.RIGHT_LEFT_MARGIN*/
    }

    let dividedDifference = totalDifference / 6;
    calculationDifference = Math.ceil(Math.max(dividedDifference, 0));

    cellDimen = dimen;
    tileDimen = dimen;

    let state = {
        realBoardDimen: boardDimen,
        realCellDimen: cellDimen,
        boardDimen,
        cellDimen,
        tileDimen,
        top: container.top,
        left: container.left,
        height: container.height,
        width: container.width,
        fontSize: cellDimen / 2.3,
        calculationDifference,
        step,
    };

    return getChangedConfig(state);
};

const getChangedConfig = (state) => {
    let changedConfig = {
        layoutSidePanelFontSize: state.fontSize,
        layoutCellDimen: state.cellDimen,
        layoutBoardLeft: state.left,
        layoutBoardTop: state.top,
        layoutBoardWidth: state.boardDimen,
        layoutWindowWidth: state.width,
        layoutWindowHeight: state.height,
    };

    let realBoardDimen = state.realBoardDimen;
    let orginalBoardDimen = state.width;
    let difference = orginalBoardDimen - realBoardDimen;
    let extraMarginRequired = Config.RIGHT_LEFT_MARGIN - difference;

    let res = {
        ...(state || {}),
        extraMarginRequired,
        ...changedConfig,
    };

    return res;
};

export default layoutReducer;
