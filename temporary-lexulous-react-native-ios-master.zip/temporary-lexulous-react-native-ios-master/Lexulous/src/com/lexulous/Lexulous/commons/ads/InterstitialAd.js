// @flow

import rewardedAdNF from './RewardedAdNF';
import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class InterstitialAd {
    retryAttempt = 0;
    onCompletion: () => void = () => {};
    constructor() {}
    onAppInit = (): void => {};

    showInterstitialAd = (rewardedPreferred: boolean, onCompletion: () => void): void => {
        this.onCompletion = onCompletion;
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            this.onAdCompletion(false);
            return;
        }
        if (rewardedPreferred && rewardedAdNF.canShowRewardedNFInterstitial()) {
            let rewardedCompletion = (): void => {
                this.onAdCompletion(false);
            };
            rewardedAdNF.showRewardedNFInterstitialAd(rewardedCompletion);
        } else {
            this.onAdCompletion(false);
        }
    };

    onAdCompletion = (shown: boolean) => {
        let temp = this.onCompletion;
        this.onCompletion = () => {};
        if (temp) {
            temp();
        }
    };
}

const interstitialAd: InterstitialAd = new InterstitialAd();

export default interstitialAd;
