// @flow

import type { AppState, ProfileInfo, GamesListGameData } from '../commons/RJTypes';

export const getGLPlayersInfo = (state: AppState, game: GamesListGameData): { [string]: ProfileInfo } | null => {
    let plyinfo: { [string]: ProfileInfo } | null = null;
    if (game !== null && game !== undefined) {
        let plys = game.players.map((rr) => rr.uid);
        let plyarr: Array<ProfileInfo> = plys.map((rr) => state.gamesList.playersinfo[rr]);
        plyinfo = plyarr.reduce((acc, profile) => {
            if (profile.guid !== null && profile.guid !== undefined) {
                acc[profile.guid] = profile;
            }
            return acc;
        }, {});
    }
    return plyinfo;
};

export const getMyProfile = (state: AppState): ProfileInfo => {
    return state.gamesList.profile;
};
