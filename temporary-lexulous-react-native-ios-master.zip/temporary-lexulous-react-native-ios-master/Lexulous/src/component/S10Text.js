import React from 'react';
import { Text } from 'react-native';
import omit from 'lodash/omit';

export default class S10Text extends React.Component {
    render = () => (
        <Text
            {...omit(this.props, 'style')}
            style={[{ fontSize: 10 }, this.props.style]}
        />
    );
}
