import Config from '../configs/Config';
import ConfigurationWrapper from './ConfigurationWrapper';

const Mousetrap = require('mousetrap');
const eventBus = require('js-event-bus')();

const keys = [
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'l',
    'm',
    'n',
    'o',
    'p',
    'q',
    'r',
    's',
    't',
    'u',
    'v',
    'w',
    'x',
    'y',
    'z',
    'enter',
    'backspace',
    'escape',
];

export default class EventWrapper {
    //App.js
    static addKeyListener = (listener) => {
        Mousetrap.bind(keys, listener, 'keydown');
    };
    static removeKeyListener = () => {
        Mousetrap.reset();
    };
    //

    //Board.js
    static addSdkCompletedEventListener = (listener) =>
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'ad_sdk_completed_event'
        ) &&
        window.addEventListener(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'ad_sdk_completed_event'
            ),
            listener
        );
    static removeSdkCompletedEventListener = (listener) =>
        ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
            'ad_sdk_completed_event'
        ) &&
        window.removeEventListener(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'ad_sdk_completed_event'
            ),
            listener
        );

    //LiveGameChat.js
    static addKeyDownListener = (listener) =>
        document.addEventListener('keydown', listener);
    static removeKeyDownListener = (listener) =>
        document.removeEventListener('keydown', listener);
    //
    //Shuffle button right click
    static addRightClickListener = (listener) =>
        document.addEventListener('contextmenu', listener);
    static removeRightClickListener = (listener) =>
        document.removeEventListener('contextmenu', listener);
    //

    static passiveOpt = undefined;
    static setPassiveOpt = () => {
        let supportsPassive = false;
        try {
            window.addEventListener(
                'test',
                null,
                Object.defineProperty({}, 'passive', {
                    get: () => {
                        supportsPassive = { passive: true };
                    },
                })
            );
        } catch (err) {}
        EventWrapper.passiveOpt = supportsPassive ? { passive: false } : false;
    };
    static addEventTouchListener = (listener) => {
        EventWrapper.setPassiveOpt();
        window.addEventListener(
            'touchstart',
            listener,
            EventWrapper.passiveOpt
        );
    };
    static removeEventTouchListener = (listener) => {
        window.removeEventListener(
            'touchstart',
            listener,
            EventWrapper.passiveOpt
        );
    };

    //Custom event handle
    static addCustomeEventListener = (listener) =>
        document.addEventListener(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'reactNotifyEventName'
            ),
            listener
        );
    static removeCustomeEventListener = (listener) =>
        document.removeEventListener(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'reactNotifyEventName'
            ),
            listener
        );

    static dispatchCustomEvent = (eventObj) => {
        let customEvent = new CustomEvent(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'reactNotifyEventName'
            ),
            { detail: eventObj }
        );
        document.dispatchEvent(customEvent);
    };

    //Custom event handle
    static _scrollNode = undefined;
    static _invertedWheelEvent = (e) => {
        if (EventWrapper._scrollNode) {
            EventWrapper._scrollNode.scrollTop -= e.deltaY;
            e.preventDefault();
        }
    };
    static addScrollInvertListener = (scrollNode) => {
        EventWrapper._scrollNode = scrollNode;
        EventWrapper._scrollNode.addEventListener(
            'wheel',
            EventWrapper._invertedWheelEvent
        );
    };
    static removeScrollInvertListener = () =>
        EventWrapper._scrollNode.removeEventListener(
            'wheel',
            EventWrapper._invertedWheelEvent
        );

    static onAppStateChange = (appstate, func) => null;
}
