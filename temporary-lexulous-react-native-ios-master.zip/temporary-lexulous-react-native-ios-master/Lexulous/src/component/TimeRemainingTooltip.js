import { StyleSheet, Text, View } from 'react-native';
import Timer from 'react-compound-timer';
import Config from '../configs/Config';
import { formatToTwoDigits } from '../utils/Utils';
import React from 'react';
import { connect } from 'react-redux';
import S14Text from './S14Text';

class TimeRemainingTooltip extends React.Component {
    state = {};
    time = 0;

    getInitialTime = () => {
        let baseTime = Config.OFFLINE_PLAYER_COUNTDOWN_TIME;

        let timeNow =
            Date.now() - (this.props.config.serverTimeDifference || 0);

        let startTime =
            this.props.game['start_time_' + this.props.playerData.guid] ||
            Date.now() - (this.props.config.serverTimeDifference || 0);

        let res = baseTime - (timeNow - startTime);

        return Math.max(0, res);
    };

    render = () => (
        <View style={[styles.alignItemsCenter]}>
            {this.props.moveCount && this.props.moveCount >= 2 ? (
                <S14Text>
                    {(this.props.isPlaying ? 'You' : 'Opp') +
                        ' will get win in '}
                </S14Text>
            ) : (
                <S14Text>Game will be deleted in </S14Text>
            )}

            <View>
                <Timer
                    id={'player_timer_' + this.props.playerData.guid}
                    key={'player_timer_' + this.props.playerData.guid}
                    initialTime={this.getInitialTime()}
                    direction="backward"
                    startImmediately={true}
                    lastUnit={'s'}
                >
                    {({ getTime }) => {
                        this.getTime = getTime;
                        return (
                            <S14Text
                                style={[
                                    styles.boldFont,
                                    this.props.getPanelFontSize(),
                                ]}
                            >
                                <Timer.Seconds
                                    formatValue={formatToTwoDigits}
                                />
                            </S14Text>
                        );
                    }}
                </Timer>
            </View>

            <S14Text>seconds</S14Text>
        </View>
    );
}

const styles = StyleSheet.create({
    boldFont: { fontWeight: 'bold' },
    alignItemsCenter: {
        alignItems: 'center',
    },
});

const mapStateToProps = (state) => ({ config: state.config });

export default connect(mapStateToProps)(TimeRemainingTooltip);
