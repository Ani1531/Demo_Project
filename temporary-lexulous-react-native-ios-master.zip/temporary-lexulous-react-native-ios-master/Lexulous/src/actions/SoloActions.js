import * as ActionIdentifiers from '../configs/ActionIdentifiers';

export const gameSoloGameLogin = (res) => (dispatch, getState) =>
    dispatch({
        type: ActionIdentifiers.GAME_SOLO_GAME_LOGIN,
        payload: res,
        globalState: getState(),
    });

export const gameSoloNewGame = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_NEW_GAME,
    payload: res,
});

export const gameSoloSavedRules = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SAVED_RULES,
    payload: res,
});

export const gameSoloGetRandomBoard = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_GET_RANDOM_BOARD,
    payload: res,
});

export const gameSoloResetBoard = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_RESET_CREATE_BOARD,
    payload: res,
});

export const gameSoloSetBoardDisable = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SET_BOARD_DISABLE,
    payload: res,
});

export const gameSoloResetResumeGame = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_RESET_RESUME_GAME,
    payload: res,
});

export const gameSoloResetSlotData = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_RESET_SLOT_DATA,
    payload: res,
});

export const gameSoloCreateGameData = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_CREATE_GAME_DATA,
    payload: res,
});

export const gameSoloMenuShowHide = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_MENU_SHOW_HIDE,
    payload: res,
});

export const gameSoloSetCurrentMenuOpt = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SET_CURRENT_MENU_OPT,
    payload: res,
});

export const gameSoloSetFormType = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SET_FORM_TYPE,
    payload: res,
});

export const gameSoloSetFormData = (res) => ({
    type: ActionIdentifiers.GAME_SOLO_SET_FORM_DATA,
    payload: res,
});
