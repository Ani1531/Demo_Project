import React from 'react';
import Timer from 'react-compound-timer/build';
import { StyleSheet, Text, View } from 'react-native';
import { connect } from 'react-redux';
import Config from '../configs/Config';
import { formatToTwoDigits } from '../utils/Utils';
import S14Text from './S14Text';

class ConnectionIndicator extends React.Component {
    state = {
        serverRestartMessage: 'Server is going to restart in ',
        serverRestartTimer: true,
    };
    isServerRestarting = () => this.props.config.connectionStatus === Config.ACTION_RESTART_SERVER;

    isConnectingOrNotConnected = () => ['connecting', 'disconnected'].includes(this.props.config.connectionStatus);

    isDuplicateConnection = () => ['duplicate'].includes(this.props.config.connectionStatus);

    isConnected = () => ['connected'].includes(this.props.config.connectionStatus);

    shouldShowPleaseRefresh = () => this.props.config.showPleaseRefresh;

    shouldHaveConnectionIndicator = () => this.props.game.request_url_type === 'web_socket';

    render = () =>
        this.shouldHaveConnectionIndicator() &&
        (this.isDuplicateConnection() ||
            this.shouldShowPleaseRefresh() ||
            this.isConnectingOrNotConnected() ||
            this.isServerRestarting()) ? (
            <View style={[this.isServerRestarting() ? styles.serverRestartMessage : StyleSheet.absoluteFill]}>
                {this.isServerRestarting()
                    ? this.renderServerRestartMesage()
                    : this.isDuplicateConnection()
                    ? this.renderMessage(
                          'Lexulous is active on multiple devices / browser tabs. Please maintain a single connection.'
                      )
                    : this.props.config.showPleaseRefresh
                    ? this.renderMessage('Unable to connect, please refresh the page ')
                    : !this.isConnected()
                    ? this.renderMessage('Connection lost, Reconnecting...')
                    : null}
            </View>
        ) : null;

    getMessageContainerStyles = () =>
        !(
            this.isConnectingOrNotConnected() ||
            this.isDuplicateConnection() ||
            this.shouldShowPleaseRefresh() ||
            this.isServerRestarting()
        )
            ? styles.connection_indicator_root_style
            : styles.connection_indicator_root_style_offline;

    renderMessage = (msg) => (
        <S14Text style={[styles.connection_indicator_text_style_offline, this.getMessageContainerStyles()]}>{msg}</S14Text>
    );

    renderServerRestartMesage = () => (
        <View style={[this.getMessageContainerStyles()]}>
            <S14Text style={styles.connection_indicator_text_style_offline}>{this.state.serverRestartMessage}</S14Text>
            {this.state.serverRestartTimer && (
                <Timer
                    initialTime={this.props.config.restartServer}
                    startImmediately={true}
                    direction={'backward'}
                    checkpoints={[
                        {
                            time: 0,
                            callback: () =>
                                this.setState({
                                    serverRestartMessage: 'Server will restart now.',
                                    serverRestartTimer: false,
                                }),
                        },
                    ]}
                >
                    <S14Text style={[{ flexDirection: 'row' }, styles.timerText]}>
                        <Timer.Minutes formatValue={formatToTwoDigits} />
                        <S14Text style={styles.timerText}>{':'}</S14Text>
                        <Timer.Seconds formatValue={formatToTwoDigits} />
                    </S14Text>
                </Timer>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    connection_indicator_root_style: {
        flexDirection: 'row',
        width: '100%',
        backgroundColor: 'rgb(226, 226, 226)',
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
    },
    connection_indicator_root_style_offline: {
        flexDirection: 'row',
        width: '100%',
        backgroundColor: '#d00000',
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
    },
    connection_indicator_text_style_offline: {
        color: '#FFF',
        padding: 2,
    },
    connection_indicator_text_style: {
        padding: 2,
    },
    timerText: {
        color: '#FFF',
        alignSelf: 'center',
    },
    serverRestartMessage: {
        position: 'absolute',
        width: '100%',
    },
});

const mapStateToProps = (state) => ({
    config: state.config,
    game: state.game,
});
export default connect(mapStateToProps)(ConnectionIndicator);
