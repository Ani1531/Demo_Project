// @flow
import { createStackNavigator } from '@react-navigation/stack';
import { Platform } from 'react-native';
import type { us_dictionary } from './RJTypes';
import Config from 'react-native-config';

//====================Begin constants dev/production===========================

export const appType: string = Config.appType;
export const appVersion = Platform.select({
    ios: `${Config.shortVersion}(${Config.version})`,
    android: `${Config.shortVersion}(${Config.version})`,
    default: `${Config.shortVersion}(${Config.version})`,
});

export const kEmailBaseUrl: string = Config.kEmailBaseUrl;
//export const kEmailBaseUrl: string = 'https://emailgame.lexulous.com/new';

export const kBaseUrl: string = Config.kBaseUrl;
//export const kBaseUrl: string = 'http://api.lexulous.com';
export const kLxEmUrl: string = Config.kLxEmUrl;
//export const kLxEmUrl: string = 'https://emailgame.lexulous.com/new/emailgame/';
export const kLxEmNameAvailability: string = Config.kLxEmNameAvailability;
//export const kLxEmNameAvailability: string = 'https://www.lexulous.com/ajax/availability?';
export const forumLink: string = Config.forumLink;
export const kDeepLinkDomain: string = Config.kDeepLinkDomain;
export const kStatsDeepLinkPath: string = Config.kStatsDeepLinkPath;
export const statShareLink: string = kDeepLinkDomain + kStatsDeepLinkPath;
export const kWordDefinationUrl = Config.kWordDefinationUrl;
export const kPrivacyPolicyUrl = Config.kPrivacyPolicyUrl;

export const kLoggingEnabled: boolean = false;
export const kLegacyIosLiteToProPrdctId = 'lexlitetopro';
export const kLexAnalizerPrdctId: string = Platform.select({
    ios: 'lexlite_analizer_10',
    android: 'analyze_ten_games',
});

export const packageName: string = Platform.select({
    ios: 'com.lexulous.LexulousLite',
    android: 'com.lexulous.Lexulous',
});

export const kLexProOneMonthSubsPrdctId: string = Platform.select({
    ios: 'ad_free_subs_1m',
    android: 'no_ads_one_month',
});

export const kLexProOneYearSubsPrdctId: string = Platform.select({
    ios: 'ad_free_subs_1y',
    android: 'ad_free_499_one_year_sub',
});

export const kGoogleLoginConfig = JSON.parse(Config.kGoogleLoginConfig);

export const kApplovinSdkKey: string = Config.NBaXeQRw;
export const kBannerAdUnit = Config.LpygTGPf;
export const kInterStitialAdUnit = Config.PWDnmRgH;
export const kRewardedNFInterStitialAdUnit = Config.XeYjdQhH;

export const subscriptionBufferDurationMillis = 21600000;
export const aglFetchLimit = '20';
export const aglCacheDurationSec: number = 1800;

export const kNtfPinResendDurationSec: number = 3600;

export const kFriendCacheDurationSeconds = 7200;
export const kStatsUpdateDurationSec: number = 3600;
export const kUpdateSettingDurationSec: number = 3600;

export const kInitialRvwTrgCnt = 4;
export const kExtendedRvwTrgCnt = 8;
export const kInitialShareTrgCnt = 2;
export const kExtendedShareTrgCnt = 8;

export const kMaxUserNameLength = 20;
export const kMinUserNameLength = 6;
export const kMaxPwdLength = 20;
export const kMinPwdLenght = 6;

export const kStatsBatchCount = 5;

//fb app id dev: 208702452505827
//fb app id prod: 3052170175
//fb id change [strings.xml,info.plist[FacebookAppID,CFBundleURLTypes]]
//google-services.json/GoogleService-Info.plist [replace file][kGoogleLoginConfig,info.plist[CFBundleURLTypes]]
//AdsConstants [kApplovinSdkKey, kBannerAdUnit, kInterStitialAdUnit, kRewardedNFInterStitialAdUnit, plugin.properties][ensure test mode off, ensure verbose logging off]
//[info.plist GADApplicationIdentifier, strings.xml][]

//Version change [appVersion, app build.gradle, xcode target]
//signing changes [app build.gradle, xcode target]

//deep linking [kDeepLinkDomain, kStatsDeepLinkPath, AndroidManifest.xml, CFBundleURLSchemes]
//analytics [google-services.json/GoogleService-Info.plist, firebase.json]
//crashlytics [google-services.json/GoogleService-Info.plist, firebase.json]

//====================End constants dev/production===========================
export const kTabBarHeight = 50;
export const Stack = createStackNavigator();
export const isAppleLoginSupported = () => {
    if (Platform.OS === 'ios') {
        const majrver = parseInt(Platform.Version, 10);
        return majrver >= 13;
    } else if (Platform.OS === 'android') {
        return false;
    } else {
        return false;
    }
};

export const getOSPlatformString = () => {
    if (Platform.OS === 'ios') return 'IP';
    else if (Platform.OS === 'android') return 'AP';
    else return 'WB';
};

export const kMinGlobalIdLen = 12;

export const kPsistGUID = 'LkfpyASB';
export const kPsistUUID = 'Hw5czx6m';
export const kPsistApplUserID = 'Nj5gcwQp';
export const kPsistApplAuthCode = 'vGjMTFyH';
export const kPsistApplIdttyToken = 'WSWNXKef';
export const kPsistApplEmail = 'v2kzr4Gx';
export const kPsistApplFmlyName = 'wChmQ8WG';
export const kPsistApplGivenName = 'jeMmrNBh';
export const kPsistApplNickName = 'HUftpVEP';
export const kPsistAppNwUser = 'HUft9RT';
export const kPsistRvwTrgCnt = 'j7JYqNnB';
export const kPsistRvwAtCnt = 'YBTQwDMm';
export const kPsistShrTrgCnt = 'DTWsa8hq';
export const kPsistShrAtCnt = 'NwhADfMY';

export const kPsistLexAuthUser = 'PGxqt6EE';
export const kPsistLexAuthSecret = 'f8RHUF8s';
export const kPsistLexUid = '7k6G8rSB';
export const kPsistLexEmail = 'hjczHsEJ';

export const kPsistDevicePin = 'kFDPGQeh';

export const kPsistAppleRefTkn = 'avDRfhr4';
export const kPsistPendingAssociation = 'hzyaWYEP';

export const kPsistTempLexAuthUser = 'kWVuQ4Sb';
export const kPsistTempLexAuthSecret = 'S5gPpKJ7';
export const kPsistTempLexUid = 'YhhQfLsm';
export const kPsistTempLexEmail = 'Cvc46UTf';
export const kPsistNtfPermState = 'XYyUDcmN';

export const kStatsUpdate = 'BCR2ZRqk';
export const kUpdateSettings = 'TrUcDmwd';

export const PsistNtfPermState = {
    Shown: 'shown',
    Denied: 'denied',
};
Object.freeze(PsistNtfPermState);

export const AccountSecureMedium = {
    AccountSecureMediumLXLS: 'LXLSLgnMgr',
    AccountSecureMediumFB: 'FBLgnMgr',
    AccountSecureMediumGGL: 'GGLgnMgr',
    AccountSecureMediumAAPL: 'ApplLgnMgr',
};
Object.freeze(AccountSecureMedium);

export const prefferedFndSearchMode = {
    prefferedFndSearchModeNone: 0,
    prefferedFndSearchModeLexID: 1,
};
Object.freeze(prefferedFndSearchMode);

export const kPsistDidSignedInWithAppl = 'AdrNEAN6';
export const kName = 'name';
export const kAvtar = 'avtar';
export const kAuthUser = 'authuser';
export const kAuthSecret = 'authsecret';
export const kUid = 'uid';
export const kProUSer = 'prouser';
export const kRefTkn = 'refresh_token';
export const kPin = 'pin';
export const kFBInstantApp = 'fb_instant';
export const kDeskTopApp = 'desktop';
export const kLXWebApp = 'lex_web';

export const kVer = 'ver';
export const kAck = 'ack';

export const kFbSigUser = 'fb_sig_user';
export const kFbSigSessionKey = 'fb_sig_session_key';

export const kChannel = 'lxls';

export const kUserApiPath = '/api/user';
export const kGamesListApiPath = '/api/gameslist';
export const kArchiveGamesListApiPath = '/api/archivegameslist';
export const kFriendApiPath = '/api/friend';
export const kStatsApiPath = '/api/stats';
export const kDeviceLXLSPath = '/device/';
export const kGameApiPath = '/api/game';
export const kFeedBackPath = '/api/feedback';
export const kEmailDeviceApiPath = '/device/';
export const kEmailGameApiPath = '/emailgame/';
export const kHostGamePath = '/api/hostedgames';

export const kActionRegisterUser = 'registerglobaluser';
export const kGetProfile = 'getprofile';
export const kGetDefinationAction = 'get_word_meaning';
export const kSuccess = 'success';
export const HTTPSuccessStatus = 200;
export const kFailure = 'failure';
export const kParams = 'params';
export const kJson = 'json';
export const kParamChannel = 'channel';
export const kParamAction = 'action';
export const kParamGuid = 'guid';
export const kParamGuids = 'guids';
export const kParamUuid = 'uuid';
export const kActionRegisterGlobalUser = 'registerglobaluser';
export const kActionArchiveGamesList = 'archivegameslist';
export const kActionGetHostedGames = 'gethostedgames';

export const kPlatform = 'platform';
export const kPlatformFB = 'fb';
export const kPlatformGoog = 'gglid';
export const kPlatformLexCom = 'lexcom';
export const kPlatformGlobal = 'glbl';

export const kParamUser = 'user';
export const kParamAuthCode = 'authcode';
export const kParamToken = 'token';
export const kParamRefreshToken = 'refresh_token';
export const kParamEmail = 'email';
export const kParamFamilyName = 'familyName';
export const kParamGivenName = 'givenName';
export const kParamNickName = 'nickname';
export const kParamPkg = 'pkg';
export const kUrlMdfrAppleLgn = 'applelogin';
export const kUserEntry = 'userentry';

export const kParamReceiptData = 'receiptdata';

export const kParamDevice = 'device';
export const kParamAccounts = 'accounts';
export const kParamReqFields = 'reqfields';
export const kParamOther = 'other';
export const kRetryCount = 3;

export const kParamUserEmail = 'useremail';
export const kParamSubject = 'subject';
export const kParamMsg = 'msg';

export const kLongestWordPlayed = 'LWP';

export const tmpLexLgnSym: Array<string> = ['ApplLgnMgr', 'GGLgnMgr', 'LXLSLgnMgr'];
Object.freeze(tmpLexLgnSym);

export const lexAppleLgnErrCodes = {
    lexAppleLgnErrCodeNull: -1,
    lexAppleLgnErrCodeMissingParams: 1,
    lexAppleLgnErrCodeRefTknFailed: 2,
    lexAppleLgnErrCodeAuthCodeFailed: 3,
    lexAppleLgnErrCodeEmailVfctionFailed: 4,
    lexAppleLgnErrCodeEmailAlreadyRegistered: 5,
    lexAppleLgnErrCodeLexcomRegistrationFailed: 6,
    lexAppleLgnErrCodeServerNetworkError: 7,
    lexAppleLgnErrCodeInvalidJsonReceived: 8,
    lexAppleLgnErrCodeAuthDataIncomplete: 9,
    lexAppleLgnErrCodeClientNetworkError: 10,
};
Object.freeze(lexAppleLgnErrCodes);

export const lexAssociationStatusCode = {
    lexAssociationStatusCodeMerge: '10',
    lexAssociationStatusCodeConflict: '11',
    lexAssociationStatusCodeMergeNotPossible: '16',
    lexAssociationStatusCodeSwitchNotPossible: '17',
};
Object.freeze(lexAssociationStatusCode);

export const LNRVwCode = {
    LNRVwCodeUserNameOREmail: 'UserNameOREmail', //
    LNRVwCodeRegUserName: 'RegUserName', //
    LNRVwCodeRegPwd: 'RegPwd',
    LNRVwCodeExstPwd: 'ExstPwd', //
};
Object.freeze(LNRVwCode);

export const NtfReceiveState = {
    NtfForeground: 'fg',
    NtfOpened: 'opnd',
};
Object.freeze(NtfReceiveState);

export const NtfReceiveType = {
    NtfReceiveTypeACK: 'ACK',
    NtfReceiveTypeMove: 'MOVE',
    NtfReceiveTypePass: 'PASS',
    NtfReceiveTypeSwap: 'SWAP',
    NtfReceiveTypeNewGame: 'NEWGAME',
    NtfReceiveTypeChat: 'CHAT',
    NtfReceiveTypeDelGame: 'DELGAME',
    NtfReceiveTypeResign: 'RESIGN',
    NtfReceiveTypeGameOver: 'GAMEOVER',
};
Object.freeze(NtfReceiveType);

export const kHeader = {
    'Content-Type': 'application/x-www-form-urlencoded',
    Accept: '*/*',
    ...Platform.select({
        native: { 'Accept-Encoding': 'gzip, deflate, br' },
        web: null,
    }),
};
export const kRequestOptions = {
    method: 'POST',
    headers: kHeader,
};

export const avtarIcons: { [key: string]: number } = {
    '1': require('../assets/avatars/1.png'),
    '2': require('../assets/avatars/2.png'),
    '3': require('../assets/avatars/3.png'),
    '4': require('../assets/avatars/4.png'),
    '5': require('../assets/avatars/5.png'),
    '6': require('../assets/avatars/6.png'),
    '7': require('../assets/avatars/7.png'),
    '8': require('../assets/avatars/8.png'),
    '9': require('../assets/avatars/9.png'),
    '10': require('../assets/avatars/10.png'),
    '11': require('../assets/avatars/11.png'),
    '12': require('../assets/avatars/12.png'),
    '13': require('../assets/avatars/13.png'),
    '14': require('../assets/avatars/14.png'),
    '15': require('../assets/avatars/15.png'),
    '16': require('../assets/avatars/16.png'),
    '17': require('../assets/avatars/17.png'),
    '18': require('../assets/avatars/18.png'),
    '19': require('../assets/avatars/19.png'),
    '20': require('../assets/avatars/20.png'),
    '21': require('../assets/avatars/21.png'),
    '22': require('../assets/avatars/22.png'),
    '23': require('../assets/avatars/23.png'),
    '24': require('../assets/avatars/24.png'),
    '25': require('../assets/avatars/25.png'),
    '26': require('../assets/avatars/26.png'),
    '27': require('../assets/avatars/27.png'),
    '28': require('../assets/avatars/28.png'),
    '29': require('../assets/avatars/29.png'),
    '30': require('../assets/avatars/30.png'),
    '31': require('../assets/avatars/31.png'),
    '32': require('../assets/avatars/32.png'),
    '33': require('../assets/avatars/33.png'),
    '34': require('../assets/avatars/34.png'),
    '35': require('../assets/avatars/35.png'),
    '36': require('../assets/avatars/36.png'),
    '37': require('../assets/avatars/37.png'),
    '38': require('../assets/avatars/38.png'),
    '39': require('../assets/avatars/39.png'),
    '40': require('../assets/avatars/40.png'),
    '41': require('../assets/avatars/41.png'),
    '42': require('../assets/avatars/42.png'),
    '43': require('../assets/avatars/43.png'),
    '44': require('../assets/avatars/44.png'),
    '45': require('../assets/avatars/45.png'),
    '46': require('../assets/avatars/46.png'),
    '47': require('../assets/avatars/47.png'),
    '48': require('../assets/avatars/48.png'),
    '49': require('../assets/avatars/49.png'),
    '50': require('../assets/avatars/50.png'),
    '51': require('../assets/avatars/51.png'),
    '52': require('../assets/avatars/52.png'),
    '53': require('../assets/avatars/53.png'),
    '54': require('../assets/avatars/54.png'),
    '55': require('../assets/avatars/55.png'),
    '56': require('../assets/avatars/56.png'),
    '57': require('../assets/avatars/57.png'),
    '58': require('../assets/avatars/58.png'),
    '59': require('../assets/avatars/59.png'),
    '60': require('../assets/avatars/60.png'),
    '61': require('../assets/avatars/61.png'),
    '62': require('../assets/avatars/62.png'),
    '63': require('../assets/avatars/63.png'),
    '64': require('../assets/avatars/64.png'),
    '65': require('../assets/avatars/65.png'),
    '66': require('../assets/avatars/66.png'),
    '67': require('../assets/avatars/67.png'),
    '68': require('../assets/avatars/68.png'),
    '69': require('../assets/avatars/69.png'),
    '70': require('../assets/avatars/70.png'),
    '71': require('../assets/avatars/71.png'),
    '72': require('../assets/avatars/72.png'),
    '73': require('../assets/avatars/73.png'),
    '74': require('../assets/avatars/74.png'),
    '75': require('../assets/avatars/75.png'),
    '76': require('../assets/avatars/76.png'),
    '77': require('../assets/avatars/77.png'),
    '78': require('../assets/avatars/78.png'),
    '79': require('../assets/avatars/79.png'),
    '80': require('../assets/avatars/80.png'),
    '81': require('../assets/avatars/81.png'),
    '82': require('../assets/avatars/82.png'),
    '83': require('../assets/avatars/83.png'),
    '84': require('../assets/avatars/84.png'),
    '85': require('../assets/avatars/85.png'),
    '86': require('../assets/avatars/86.png'),
    '87': require('../assets/avatars/87.png'),
    '88': require('../assets/avatars/88.png'),
    '89': require('../assets/avatars/89.png'),
    '90': require('../assets/avatars/90.png'),
    '91': require('../assets/avatars/91.png'),
    '92': require('../assets/avatars/92.png'),
    '93': require('../assets/avatars/93.png'),
    '94': require('../assets/avatars/94.png'),
    '95': require('../assets/avatars/95.png'),
    '96': require('../assets/avatars/96.png'),
    '97': require('../assets/avatars/97.png'),
    '98': require('../assets/avatars/98.png'),
    '99': require('../assets/avatars/99.png'),
    '100': require('../assets/avatars/100.png'),
    '101': require('../assets/avatars/101.png'),
    '102': require('../assets/avatars/102.png'),
    '103': require('../assets/avatars/103.png'),
    '104': require('../assets/avatars/104.png'),
    '105': require('../assets/avatars/105.png'),
    '106': require('../assets/avatars/106.png'),
    '107': require('../assets/avatars/107.png'),
};

export const boardThemes: { [key: string]: number } = {
    '0': require('../assets/board_theme/th_lexulous.png'),
    '1': require('../assets/board_theme/th_classic.png'),
    '2': require('../assets/board_theme/th_adventure.png'),
    '3': require('../assets/board_theme/th_essence.png'),
    '4': require('../assets/board_theme/th_spirit.png'),
    '5': require('../assets/board_theme/th_dark.png'),
};

export const tileThemes: { [key: string]: number } = {
    '0': require('../assets/tile_theme/tl_lexulous.png'),
    '1': require('../assets/tile_theme/tl_classic.png'),
    '2': require('../assets/tile_theme/tl_adventure.png'),
    '3': require('../assets/tile_theme/tl_essence.png'),
    '4': require('../assets/tile_theme/tl_dark.png'),
};

const Greeting: Array<string> = [
    'Haai,Afrikaans,https://forum.lexulous.com/topic/747/haai-hello-in-afrikaans',
    'Hallo,Alsatian,https://forum.lexulous.com/topic/749/hallo-hello-in-alsatian',
    'Ola,Aragonese,https://forum.lexulous.com/topic/750/ola-hello-in-aragonese',
    'Barev,Armenian (Eastern),https://forum.lexulous.com/topic/752/barev-hello-in-armenian',
    'Werte,Arrernte,https://forum.lexulous.com/topic/755/werte-hello-in-arrernte',
    'Nomoskaar,Assamese,https://forum.lexulous.com/topic/756/nomoskaar-hello-in-assamese',
    'Hola,Asturian,https://forum.lexulous.com/topic/757/hola-hello-in-asturian',
    'Salam,Azeri,https://forum.lexulous.com/topic/760/salam-hello-in-azeri',
    'Kaixo,Basque,https://forum.lexulous.com/topic/761/kaixo-hello-in-basque',
    'Vitayu,Belarusian,https://forum.lexulous.com/topic/762/vitayu-hello-in-belarusian',
    'Dobar dan,Bosnian,https://forum.lexulous.com/topic/764/dobar-dan-hello-in-bosnian',
    'Salud,Breton,https://forum.lexulous.com/topic/765/salud-hello-in-breton',
    'Zdravejte,Bulgarian,https://forum.lexulous.com/topic/743/zdravejte-hello-in-bulgarian',
    'Hola,Catalan,https://forum.lexulous.com/topic/768/hola-hello-in-catalan',
    'Osiyo,Cherokee,https://forum.lexulous.com/topic/769/osiyo-hello-in-cherokee',
    'Moni,Chichewa,https://forum.lexulous.com/topic/770/moni-hello-in-chichewa',
    'Halito,Choctaw,https://forum.lexulous.com/topic/772/halito-hello-in-choctaw',
    'Guuten takh,Cimbrian,https://forum.lexulous.com/topic/771/guuten-takh-hello-in-cimbrian',
    'Dydh da,Cornish,https://forum.lexulous.com/topic/774/dydh-da-hello-in-cornish',
    'Salute,Corsican,https://forum.lexulous.com/topic/775/salute-hello-in-corsican',
    'Bok,Croatian,https://forum.lexulous.com/topic/778/bok-hello-in-croatian',
    'Ahoj,Czech,https://forum.lexulous.com/topic/779/ahoj-hello-in-czech',
    'Hej,Dalecarlian,https://forum.lexulous.com/topic/785/hej-hello-in-dalecarlian',
    'Hej,Danish,https://forum.lexulous.com/topic/786/hej-hello-in-danish',
    'Hallo,Dutch,https://forum.lexulous.com/topic/787/hallo-hello-in-dutch',
    'Tere,Estonian,https://forum.lexulous.com/topic/788/tere-hello-in-estonian',
    'Hallo,Faroese,https://forum.lexulous.com/topic/794/hallo-hello-in-faroese',
    'Bula,Fijian,https://forum.lexulous.com/topic/798/bula-hello-in-fijian',
    'Terve,Finnish,https://forum.lexulous.com/topic/799/terve-hello-in-finnish',
    'Salut,French,https://forum.lexulous.com/topic/790/salut-hello-in-french',
    'Ola,Galician,https://forum.lexulous.com/topic/800/ola-hello-in-galician',
    'Gamarjoba,Georgian,https://forum.lexulous.com/topic/791/gamarjoba-hello-in-georgian',
    'Hallo,German,https://forum.lexulous.com/topic/801/hallo-hello-in-german',
    'Ya,Greek,https://forum.lexulous.com/topic/792/ya-hello-in-greek',
    'Aluu,Greenlandic,https://forum.lexulous.com/topic/802/aluu-hello-in-greenlandic',
    'Bonjou,Haitian Creole,https://forum.lexulous.com/topic/803/bonjou-hello-in-haitian-creole',
    'Tjike,Herero,https://forum.lexulous.com/topic/804/tjike-hello-in-herero',
    'Selamat,Indonesian,https://forum.lexulous.com/topic/805/selamat-hello-in-indonesian',
    'Ai,Inuktitut,https://forum.lexulous.com/topic/814/ai-hello-in-inuktitut',
    'Dia dhuit,Irish (Gaelic),https://forum.lexulous.com/topic/815/dia-dhuit-hello-in-irish-gaelic',
    'Ciao,Italian,https://forum.lexulous.com/topic/795/ciao-hello-in-italian',
    'Konnichiwa,Japanese,https://forum.lexulous.com/topic/796/konnichiwa-hello-in-japanese',
    'Johm riab sua,Khmer,https://forum.lexulous.com/topic/816/johm-riab-sua-hello-in-khmer',
    'Annyeonghashipnikka,Korean,https://forum.lexulous.com/topic/806/annyeonghashipnikka-hello-in-korean',
    'Sillaw,Kurdish,https://forum.lexulous.com/topic/822/sillaw-hello-in-kurdish',
    'Heus,Latin,https://forum.lexulous.com/topic/866/heus-hello-in-latin',
    'Sveiki,Latvian,https://forum.lexulous.com/topic/807/sveiki-hello-in-latvian',
    'Hallo,Limburgish,https://forum.lexulous.com/topic/823/hallo-hello-in-limburgish',
    'Labas,Lithuanian,https://forum.lexulous.com/topic/824/labas-hello-in-lithuanian',
    'Moien,Luxembourgish,https://forum.lexulous.com/topic/809/moien-hello-in-luxembourgish',
    'Zdravo,Macedonian,https://forum.lexulous.com/topic/848/zdravo-hello-in-serbian',
    'Selamat pagi,Malay,https://forum.lexulous.com/topic/826/selamat-pagi-hello-in-malay',
    'Namaste,Malayalam,https://forum.lexulous.com/topic/885/namaste-hello-in-malayalam/1',
    'Sain uu,Mongolian,https://forum.lexulous.com/topic/828/sain-uu-hello-in-mongolian',
    'Namaste,Nepali,https://forum.lexulous.com/topic/906/namaste-hello-in-nepali',
    'Goddag,Norwegian,https://forum.lexulous.com/topic/817/goddag-hello-in-norwegian',
    'Bonjorn!,Occitan,https://forum.lexulous.com/topic/855/velkomnir-hello-in-icelandic',
    'Bon dia,Pashto,https://forum.lexulous.com/topic/829/bon-dia-hello-in-pashto',
    'Dorood,Persian,https://forum.lexulous.com/topic/845/dorood-hello-in-persian',
    'Wai,Pitjantjatjara,https://forum.lexulous.com/topic/839/wai-hello-in-pitjantjatjara',
    'Sat sri akal,Punjabi,https://forum.lexulous.com/topic/840/sat-sri-akal-hello-in-punjabi',
    'Rimaykullayki,Quechua,https://forum.lexulous.com/topic/841/rimaykullayki-hello-in-quechua',
    'Salut,Romanian,https://forum.lexulous.com/topic/818/salut-hello-in-romanian',
    'Ciao,Romansh,https://forum.lexulous.com/topic/864/ciao-hello-in-romansh',
    'Zdravstvujte,Russian,https://forum.lexulous.com/topic/842/zdravstvujte-hello-in-russian',
    'Talofa,Samoan,https://forum.lexulous.com/topic/844/talofa-hello-in-samoan',
    'Ciau,Sicilian,https://forum.lexulous.com/topic/856/ciau-hello-in-sicilian',
    'Lumela,Sesotho,https://forum.lexulous.com/topic/882/lumela-hello-in-sesotho/1',
    'Ahoj,Slovak,https://forum.lexulous.com/topic/849/ahoj-hello-in-slovak',
    'Pozdravljeni,Slovenian,https://forum.lexulous.com/topic/860/pozdravljeni-hello-in-slovenian',
    'Is ka warran,Somali,https://forum.lexulous.com/topic/862/is-ka-warran-hello-in-somali',
    'Hoj,Stellingwarfs,https://forum.lexulous.com/topic/880/hoj-hello-in-stellingwarfs',
    'Hej,Swedish,https://forum.lexulous.com/topic/821/hej-hello-in-swedish',
    'Mabuhay!,Tagalog,https://forum.lexulous.com/topic/887/mabuhay-hello-in-tagalog/1',
    'Ia ora na,Tahitian,https://forum.lexulous.com/topic/827/ia-ora-na-hello-in-tahitian',
    'Vanakkam,Tamil,https://forum.lexulous.com/topic/867/vanakkam-hello-in-tamil',
    'Ola,Tetum,https://forum.lexulous.com/topic/873/ola-hello-in-tetum',
    'Selam,Tigrinya,https://forum.lexulous.com/topic/872/selam-hello-in-tigrinya',
    'Gude,Tok Pisin,https://forum.lexulous.com/topic/876/gude-hello-in-tok-pisin/1',
    'Malo e lelei,Tongan,https://forum.lexulous.com/topic/881/malo-e-lelei-hello-in-tongan',
    'Dumela,Tswana,https://forum.lexulous.com/topic/905/dumela-hello-in-tswana',
    'Asalamu?aleykum!,Tsez,https://forum.lexulous.com/topic/877/asalamu-aleykum-hello-in-tsez/1',
    'Merhaba,Turkish,https://forum.lexulous.com/topic/830/merhaba-hello-in-turkish',
    'Vitayu,Ukrainian,https://forum.lexulous.com/topic/832/vitayu-hello-in-ukrainian',
    'Assalomu Alaykum!,Uzbek,https://forum.lexulous.com/topic/837/assalomu-alaykum-hello-in-uzbekistan',
    'I nhlikanhi,Venda,https://forum.lexulous.com/topic/878/i-nhlikanhi-hello-in-venda',
    'Ciao!,Venetian,https://forum.lexulous.com/topic/861/ciao-hello-in-venetian',
    'Ngurrju mayinpa,Warlpiri,https://forum.lexulous.com/topic/875/ngurrju-mayinpa-hello-in-warlpiri',
    'Na nga def,Wolof,https://forum.lexulous.com/topic/883/na-nga-def-hello-in-wolof/1',
    'Sawubona,Zulu,https://forum.lexulous.com/topic/854/sawubona-hello-in-zulu/1',
    'Hi,English,https://forum.lexulous.com/topic/871/hi-hello-in-english',
    'Velkomnir,Icelandic,https://forum.lexulous.com/topic/855/velkomnir-hello-in-icelandic',
    'Bem-vindo,Portuguese,https://forum.lexulous.com/topic/838/bem-vindo-hello-in-portuguese',
    'Bienvenida,Spanish,https://forum.lexulous.com/topic/833/bienvenida-hello-in-spanish/1',
    'Kuwakaribisha,Swahili,https://forum.lexulous.com/topic/904/kuwakaribisha-hello-in-swahili',
    'Gouden Dai,Frisian (Saterfrisian),https://forum.lexulous.com/topic/896/gouden-dai-hello-in-frisian-saterfrisian/1',
    'Sannu,Hausa,https://forum.lexulous.com/topic/879/sannu-hello-in-hausa/1',
    'Aloha,Hawaiian,https://forum.lexulous.com/topic/836/aloha-hello-in-hawaiian/1',
    'Mono,Himba,https://forum.lexulous.com/topic/886/mono-hello-in-himba',
    'Dy bannee diu,Manx,https://forum.lexulous.com/topic/907/dy-bannee-diu-hello-in-manx',
    'Aniin,Ojibwe,https://forum.lexulous.com/topic/865/aniin-hello-in-ojibwe',
    'Bone die,Sardinian(Logudorese),https://forum.lexulous.com/topic/893/bone-die-hello-in-sardinian/1',
    'Zdravo,Serbian,https://forum.lexulous.com/topic/848/zdravo-hello-in-serbian',
    'Mhoro,Shona,https://forum.lexulous.com/topic/863/mhoro-hello-in-shona',
    'Miga,Teribe,https://forum.lexulous.com/topic/789/miga-hello-in-teribe',
    'Molo,Xhosa,https://forum.lexulous.com/topic/781/molo-hello-in-xhosa',
    'Mogethin,Yapese,https://forum.lexulous.com/topic/776/mogethin-hello-in-yapese',
    'A gutn tog,Yiddish,https://forum.lexulous.com/topic/773/a-gutn-tog-hello-in-yiddish',
    'Powitanie,Polish,https://forum.lexulous.com/topic/754/powitanie-hello-in-polish',
    'Godaw,Jutish,https://forum.lexulous.com/topic/758/godaw-hello-in-jutish',
    'Goondach,Plautdietsch,https://forum.lexulous.com/topic/759/goondach-hello-in-plautdietsch',
];

export const greetingInfo: string = Greeting[Math.floor(Math.random() * Greeting.length)];

export const US_English: us_dictionary = 'twl';
export const UK_English: us_dictionary = 'sow';
export const Italian: us_dictionary = 'it';
export const French: us_dictionary = 'fr';
export const Normal: string = 'N';
export const Super: string = 'S';
export const Email_Regular: string = 'ER';
export const Email_Challange: string = 'EC';

export const Board_sz_n: number = 16;
export const Board_sz_s: number = 21;
export const server_S: string = 'super';
export const server_N: string = 'normal';

export const settingsDescriptor: Array<{
    key: string,
    title: string,
    content: Array<{
        key: string,
        lbl: string,
        type: string,
        editable?: string,
        def_value: string,
    }>,
}> = [
    {
        key: 'us_account',
        title: 'account',
        content: [
            {
                key: 'ac_facebook',
                lbl: 'Facebook',
                type: 'kLgn',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'ac_google',
                lbl: 'Google',
                type: 'kLgn',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ac_lexulous',
                lbl: 'Lexulous.com',
                type: 'kLgn',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ac_apple',
                lbl: 'Apple',
                type: 'kLgn',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ac_logout',
                lbl: 'Logout',
                type: 'kLgnout',
                editable: 'true',
                def_value: 'y',
            },
        ],
    },
    {
        key: 'us_email',
        title: 'email_noti',
        content: [
            {
                key: 'em_gamestarted',
                lbl: 'nwgame_strtd',
                type: 'kBool',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'em_myturn',
                lbl: 'turn_played',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'em_chat',
                lbl: 'msg_revcd',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'em_gamecompleted',
                lbl: 'gmcomplt',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'em_dailydigest',
                lbl: 'summary',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'em_recnudgerequest',
                lbl: 'nrequest',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'em_enableautologinlinks',
                lbl: 'autologin',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
        ],
    },
    {
        key: 'us_pushntf',
        title: 'ntf',
        content: [
            {
                key: 'Game started',
                lbl: 'some label',
                type: 'kBool',
                def_value: 'y',
            },
            {
                key: 'ntf_myturn',
                lbl: 'turn_played',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ntf_chat',
                lbl: 'msg_revcd',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ntf_gamecompleted',
                lbl: 'gmcomplt',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'ntf_dailydigest',
                lbl: 'some label',
                type: 'kBool',
                def_value: 'y',
            },
            {
                key: 'ntf_recnudgerequest',
                lbl: 'nrequest',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'get_test_ntf',
                lbl: 'get_test_ntf',
                type: 'kBtnNtf',
                editable: 'true',
                def_value: 'y',
            },
        ],
    },
    {
        key: 'us_gameplay',
        title: 'board_optn',
        content: [
            {
                key: 'gp_magictiles',
                lbl: 'mtiles',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_moveconfirmation',
                lbl: 'mvconfirm',
                type: 'kBool',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'gp_numbrdboard',
                lbl: 'numbrdboard',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_gamesounds',
                lbl: 'sound',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_autozoomboard',
                lbl: 'autozm',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_boardtheme',
                lbl: 'btheme',
                type: 'kSwipe',
                editable: 'true',
                def_value: '0',
            },
            {
                key: 'gp_tiletheme',
                lbl: 'ttheme',
                type: 'kSwipe',
                editable: 'true',
                def_value: '0',
            },
            {
                key: 'gp_homepage',
                lbl: 'deflt_page',
                type: 'kSel',
                def_value: 'email',
            },
            {
                key: 'gp_homecountry',
                lbl: 'hcntry',
                type: 'kSel',
                editable: 'false',
                def_value: 'KH',
            },
            {
                key: 'gp_darktheme',
                lbl: 'dark_mode',
                type: 'kBool',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'gp_scoregraph',
                lbl: 'graph',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_showtooltip',
                lbl: 'tooltip',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_chtfntsze',
                lbl: 'chatfont',
                type: 'kWindow',
                editable: 'true',
                def_value: '14',
            },
            {
                key: 'gp_showforum',
                lbl: 'forum',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'gp_brdcntrimg',
                lbl: 'brdcntrimg',
                type: 'kWindow',
                editable: 'true',
                def_value: 'plus',
            },
        ],
    },
    {
        key: 'us_privacy',
        title: 'privacy_sttg',
        content: [
            {
                key: 'pvc_showonlinestatus',
                lbl: 'disply_online',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'pvc_showprostatus',
                lbl: 'disply_prostatus',
                type: 'kBool',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'pvc_disablechat',
                lbl: 'enableGchat',
                type: 'kBool',
                editable: 'true',
                def_value: 'n',
            },
            {
                key: 'pvc_sgstplys',
                lbl: 'some label',
                type: 'kBool',
                def_value: 'y',
            },
            {
                key: 'pvc_showlbycht',
                lbl: 'enableLchat',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'pvc_showlbygmupdt',
                lbl: 'enableLupdt',
                type: 'kBool',
                editable: 'true',
                def_value: 'y',
            },
            {
                key: 'del_user',
                lbl: 'del_user',
                type: 'kBtnDelUser',
                editable: 'true',
                def_value: 'y',
            },
        ],
    },
    {
        key: 'us_gamestart',
        title: 'gmsetting',
        content: [
            {
                key: 'gs_showinit',
                lbl: 'some label',
                type: 'kBool',
                def_value: 'n',
            },
            {
                key: 'gs_prefdic',
                lbl: 'dictpref',
                type: 'kSel',
                editable: 'true',
                def_value: 'twl',
            },
            {
                key: 'gs_ratingrange',
                lbl: 'ratingrange',
                type: 'kSlider',
                editable: 'true',
                def_value: '600-4200',
            },
            {
                key: 'gs_boardtype',
                lbl: 'brdpref',
                type: 'kSel',
                editable: 'true',
                def_value: 'N',
            },
            {
                key: 'gs_gametype',
                lbl: 'gtype',
                type: 'kSel',
                editable: 'true',
                def_value: 'ER',
            },
            {
                key: 'gs_speed',
                lbl: 'gspeed',
                type: 'kSel',
                editable: 'true',
                def_value: '5',
            },
            {
                key: 'gs_maxreq',
                lbl: 'greqst',
                type: 'kSel',
                editable: 'true',
                def_value: '5',
            },
            {
                key: 'gs_numplayers',
                lbl: 'some label',
                type: 'kSel',
                def_value: '2',
            },
            {
                key: 'gs_rated',
                lbl: 'some label',
                type: 'kBool',
                def_value: 'n',
            },
            {
                key: 'gs_lvduration',
                lbl: 'some label',
                type: 'kSel',
                def_value: '420',
            },
            {
                key: 'gs_lvincrmnt',
                lbl: 'some label',
                type: 'kSel',
                def_value: '10',
            },
        ],
    },
    {
        key: 'us_prouser',
        title: 'pro_feature',
        content: [
            {
                key: 'pro_analizegamesleft',
                lbl: 'credits',
                type: 'kPchse',
                editable: 'true',
                def_value: '0',
            },
            {
                key: 'pro_till',
                lbl: 'active_untill',
                type: 'kDate',
                editable: 'true',
                def_value: '0',
            },
            {
                key: 'anlz_till',
                lbl: 'analizeactive_untill',
                type: 'kDate',
                editable: 'true',
                def_value: '0',
            },
            {
                key: 'ad_free',
                lbl: 'adfree_subs',
                type: 'kSubs',
                editable: 'true',
                def_value: '0',
            },
        ],
    },
    {
        key: 'us_censor',
        title: 'censor_player',
        content: [],
    },
];

export const kSetting: string = 'settings';

export const supportRequestEmailID: string = 'supportRequestEmailID';

export const getLexIdWithDash = (guid: string): string => {
    let value: Array<string> = [];
    for (let i = 0, o = 0; i < 3; ++i, o += 4) {
        value[i] = guid.substr(o, 4);
    }
    return value.join('-');
};

export const SET_BUSY: string = 'SET_BUSY';
export const SET_FREE: string = 'SET_FREE';

export const UPDATE_COLOR_SCHEME: string = 'UPDATE_COLOR_SCHEME';

export const Default_Avtar: string = '16';
export const Default_name: string = 'Anonymous User';
export const Default_guid: string = '000000000000';
export const Default_Dictionary: us_dictionary = 'twl';
export const Default_rating: string = '1500';
export const Default_userType: string = 'u';

export const aglSkip: number = 20;
export const aglRecallDurationMilisec: number = 5000;

export const kNtfPinTimestampInSec: string = 'txd9SRSK';

export const AlertBoxButtonType = {
    SHOWBUTTONONLY: 'SHOWBUTTONONLY',
    SHOWCANCELONLY: 'SHOWCANCELONLY',
    SHOWBOTH: 'SHOWBOTH',
};
Object.freeze(AlertBoxButtonType);

export const COLOR = {
    AlertBoxButtonColor: {
        POSITIVEBUTTONCOLOR: {
            bgColor: '#1d9df1',
            textColor: '#f2f2f2',
        },
        NEGATIVEBUTTONCOLOR: {
            bgColor: '#e8e8e8',
            textColor: '#1d9df1',
        },
    },
};
Object.freeze(COLOR);

export const BOARD_CENTER_ICONS = {
    ICON_GHOST: 'ghost',
    ICON_SMILE: 'smile',
    ICON_PLUS: 'plus',
    ICON_CAT: 'cat',
    ICON_DOG: 'dog',
};
Object.freeze(BOARD_CENTER_ICONS);

export const FONT_SIZES = {
    TINY: '10',
    SMALL: '12',
    MEDIUM: '14',
    BIG: '16',
    BIGGER: '18',
};
Object.freeze(FONT_SIZES);

export const SectionListWindowSize = {
    For_Native: 21,
    For_Web: 5,
};
Object.freeze(SectionListWindowSize);

export const SliderLowerRange = 600;
export const SliderUpperRange = 4200;
