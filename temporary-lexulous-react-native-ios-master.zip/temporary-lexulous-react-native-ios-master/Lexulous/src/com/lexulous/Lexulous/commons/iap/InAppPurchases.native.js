// @flow
import * as RNIap from 'react-native-iap';
import { Platform } from 'react-native';
import {
    kLexAnalizerPrdctId,
    kLexProOneMonthSubsPrdctId,
    kLexProOneYearSubsPrdctId,
    kLegacyIosLiteToProPrdctId,
    HTTPSuccessStatus,
    kSuccess,
    subscriptionBufferDurationMillis,
} from '../Constants';
import requestManager from '../../commons/RequestManager';
import dataServer from '../../store/Store';
import { actionSetIdle, actionSetBusy } from '../../commons/RJTypes';
import type { ServerResponse } from '../../commons/RJTypes';
import netManager from '../../commons/RJNetInfo';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { handleException } from '../RJUtils';
import userDefault from '../UserDefault';

class InAppPurchases {
    _unsubscribeTransactionListener = null;
    _unsubscribeTransactionErrorListener = null;
    _callback: ((data: ServerResponse | null, sku: string) => void) | null = null;
    _subscriptions: Array<string> = [];
    _nonconsumables: Array<string> = [];

    constructor() {
        this.onAppInit();
    }

    isAdFreeSubsActive = (): boolean => {
        return (
            this._subscriptions.includes(kLexProOneMonthSubsPrdctId) ||
            this._subscriptions.includes(kLexProOneYearSubsPrdctId) ||
            this._nonconsumables.includes(kLegacyIosLiteToProPrdctId)
        );
    };

    onAppInit = (): void => {
        this.onDestroy();
        RNIap.initConnection().then(() => {
            // we make sure that "ghost" pending payment are removed
            // (ghost = failed pending payment that are still marked as pending in Google's native Vending module cache)
            this.flushTransaction()
                .catch(() => {
                    // exception can happen here if:
                    // - there are pending purchases that are still pending (we can't consume a pending purchase)
                    // in any case, you might not want to do anything special with the error
                })
                .then(() => {
                    this._unsubscribeTransactionListener = RNIap.purchaseUpdatedListener(
                        (purchase: RNIap.InAppPurchase | RNIap.SubscriptionPurchase) => {
                            this.purchaseCompleted(purchase);
                        }
                    );

                    this._unsubscribeTransactionErrorListener = RNIap.purchaseErrorListener((error: RNIap.PurchaseError) => {
                        console.warn('purchaseErrorListener', error);
                    });
                });
        });
    };

    onDestroy = (): void => {
        //cleanup
        if (this._unsubscribeTransactionListener) {
            this._unsubscribeTransactionListener.remove();
            this._unsubscribeTransactionListener = null;
        }
        if (this._unsubscribeTransactionErrorListener) {
            this._unsubscribeTransactionErrorListener.remove();
            this._unsubscribeTransactionErrorListener = null;
        }
        RNIap.endConnection();
    };

    getPurchaseHistory = () => {
        RNIap.getAvailablePurchases().then((purchases) => {
            console.log('getPurchaseHistory purchases :: ' + JSON.stringify(purchases));
            this._subscriptions = [];
            this._nonconsumables = [];
            if (purchases && purchases.length > 0) {
                purchases
                    .sort((a, b) => a.transactionDate - b.transactionDate)
                    .forEach((purchase) => {
                        console.log('getPurchaseHistory purchase :: ' + JSON.stringify(purchase));
                        switch (purchase.productId) {
                            case kLexProOneMonthSubsPrdctId: {
                                console.log('will set or unset kLexProOneMonthSubsPrdctId');
                                this.verifySubscriptionReceipt(purchase);
                                break;
                            }
                            case kLexProOneYearSubsPrdctId: {
                                console.log('will set or unset kLexProOneYearSubsPrdctId');
                                this.verifySubscriptionReceipt(purchase);
                                break;
                            }
                            case kLegacyIosLiteToProPrdctId: {
                                console.log('will set or unset verifyLegacyIosLiteToProDummy');
                                this.verifyLegacyIosLiteToProDummy(purchase);
                                break;
                            }
                        }
                    });
            } else {
                this.resetSubscriptions([kLexProOneMonthSubsPrdctId, kLexProOneYearSubsPrdctId]);
            }
        });
    };

    flushTransaction = (): Promise<void | Array<string>> => {
        let clearTransaction: () => Promise<void> | Promise<Array<string>> = Platform.select({
            ios: RNIap.clearTransactionIOS,
            android: RNIap.flushFailedPurchasesCachedAsPendingAndroid,
        });
        return clearTransaction();
    };

    purchaseCompleted = (purchase: RNIap.InAppPurchase | RNIap.SubscriptionPurchase) => {
        switch (purchase.productId) {
            case kLexAnalizerPrdctId: {
                this.verifyAnalizerReceipt(purchase);
                break;
            }
            case kLexProOneMonthSubsPrdctId: {
                this.verifySubscriptionReceipt(purchase);
                break;
            }
            case kLexProOneMonthSubsPrdctId: {
                this.verifySubscriptionReceipt(purchase);
                break;
            }
            case kLegacyIosLiteToProPrdctId: {
                this.verifyLegacyIosLiteToProDummy(purchase);
                break;
            }
        }
    };

    storeSubscriptionDataToUserDefaults = (purchase: RNIap.InAppPurchase | RNIap.SubscriptionPurchase) => {
        switch (purchase.productId) {
            case kLexProOneMonthSubsPrdctId: {
                console.log('will set subscription.............' + kLexProOneMonthSubsPrdctId);
                userDefault.set(kLexProOneMonthSubsPrdctId, 'true');
                this._subscriptions.push(kLexProOneMonthSubsPrdctId);
                break;
            }
            case kLexProOneYearSubsPrdctId: {
                console.log('will set subscription.............' + kLexProOneYearSubsPrdctId);
                userDefault.set(kLexProOneYearSubsPrdctId, 'true');
                this._subscriptions.push(kLexProOneYearSubsPrdctId);
                break;
            }
        }
        this._subscriptions = [...new Set(this._subscriptions)];
    };

    resetSubscriptions = (skus: Array<string>) => {
        console.log('will reset subscription.............');
        skus.forEach((sku) => {
            const idx = this._subscriptions.indexOf(sku);
            if (idx > -1) {
                this._subscriptions.splice(idx, 1);
            }
        });
        userDefault.clearMultiple(skus);
    };

    verifyAnalizerReceipt = (purchase: RNIap.ProductPurchase) => {
        const receipt: string = purchase.transactionReceipt;
        if (receipt) {
            dataServer.getStore().dispatch(actionSetBusy());
            console.log('verifyAnalizerReceipt receipt :: ' + receipt);
            let rq: AxiosPromise<ServerResponse> = requestManager.verifyAnalizerReceipt(receipt);
            rq.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then(async (srvresp: ServerResponse) => {
                    if (srvresp.check === kSuccess) {
                        await RNIap.finishTransaction(purchase, true);
                        if (this._callback !== null) {
                            this._callback(srvresp, purchase.productId);
                            this._callback = null;
                        }
                    } else {
                        console.log('verifyAnalizerReceipt error', srvresp);
                    }
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    verifyLegacyIosLiteToProDummy = (purchase: RNIap.ProductPurchase) => {
        const receipt: string = purchase.transactionReceipt;
        if (receipt) {
            this._nonconsumables.push(purchase.productId);
            RNIap.finishTransaction(purchase, true);
            if (this._callback !== null) {
                this._callback(null, purchase.productId);
                this._callback = null;
            }
        }
    };

    verifySubscriptionReceipt = (purchase: RNIap.SubscriptionPurchase) => {
        const receipt: any = purchase.transactionReceipt ? purchase.transactionReceipt : purchase.originalJson;
        if (receipt) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rq: Promise<boolean> = this.dummyPostForSubscriptionValidation(purchase);
            rq.then(async (isvalid) => {
                if (isvalid) {
                    this.storeSubscriptionDataToUserDefaults(purchase);
                    dataServer.debouncedDispatch(actionSetIdle());
                    await RNIap.finishTransaction(purchase, false);
                    console.info('subscription receipt-data :: ' + receipt);
                    if (this._callback !== null) {
                        this._callback(null, purchase.productId);
                        console.info('will call callback..........');
                        this._callback = null;
                    }
                } else {
                    this.resetSubscriptions([purchase.productId]);
                }
            })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    dummyPostForSubscriptionValidation = async (purchase: RNIap.SubscriptionPurchase): Promise<boolean> => {
        let isvalid = false;
        let bufftstmpduration = subscriptionBufferDurationMillis;
        try {
            switch (purchase.productId) {
                case kLexProOneMonthSubsPrdctId:
                    {
                        let pdate = new Date(purchase.transactionDate);
                        if (__DEV__) {
                            bufftstmpduration = 1000;
                            pdate.setMinutes(pdate.getMinutes() + 5);
                        } else {
                            pdate.setMonth(pdate.getMonth() + 1);
                        }

                        let exptstmp: number = pdate.getTime() + bufftstmpduration;
                        let ctstmp: number = Date.now();
                        console.log('exptstmp :: ' + exptstmp);
                        console.log('ctstmp :: ' + ctstmp);
                        isvalid = exptstmp > ctstmp;
                    }
                    break;
                case kLexProOneYearSubsPrdctId:
                    {
                        let pdate = new Date(purchase.transactionDate);
                        if (__DEV__) {
                            bufftstmpduration = 1000;
                            pdate.setMinutes(pdate.getMinutes() + 5);
                        } else {
                            pdate.setMonth(pdate.getMonth() + 12);
                        }
                        let exptstmp: number = pdate.getTime() + bufftstmpduration;
                        let ctstmp: number = Date.now();
                        isvalid = exptstmp > ctstmp;
                    }
                    break;
            }
        } catch (err) {
            handleException(err);
        }
        return isvalid;
    };

    requestPurchase = async (sku: string, callback: ((ServerResponse | null, sku: string) => void) | null) => {
        if (netManager.isConnected()) {
            try {
                dataServer.getStore().dispatch(actionSetBusy());
                this._callback = callback;
                const products: RNIap.Product[] = await RNIap.getProducts([sku]);
                await RNIap.requestPurchase(sku, false);
            } catch (err) {
                dataServer.debouncedDispatch(actionSetIdle());
                handleException(err);
            }
        }
    };

    requestSubscription = async (sku: string, callback: ((ServerResponse | null, sku: string) => void) | null) => {
        if (netManager.isConnected()) {
            try {
                dataServer.getStore().dispatch(actionSetBusy());
                this._callback = callback;
                const products: RNIap.Product[] = await RNIap.getSubscriptions([sku]);
                await RNIap.requestSubscription(sku, false);
            } catch (err) {
                dataServer.debouncedDispatch(actionSetIdle());
                handleException(err);
            }
        }
    };

    getProductsDisplayDetails = async (skus: Array<string>): Promise<{ [string]: { [string]: string } }> => {
        let products: RNIap.Product[] = await RNIap.getSubscriptions(skus);
        let productDetails = {};
        products.forEach((items, index) => {
            productDetails[items.productId] = { ...items };
        });
        return productDetails;
    };
}

const inAppPurchases: InAppPurchases = new InAppPurchases();

export default inAppPurchases;
