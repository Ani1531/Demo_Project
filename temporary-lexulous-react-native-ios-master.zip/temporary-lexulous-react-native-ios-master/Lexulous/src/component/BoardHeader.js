import React from 'react';
import { StyleSheet, TouchableOpacity, Text, View } from 'react-native';
import Config from '../configs/Config';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import Timer from 'react-compound-timer';
import ColorConfig from '../configs/ColorConfig';
import { isPuzzleGame } from '../service/GamePlayService';
import StandardButton from './StandardButton';
import { connect } from 'react-redux';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';
import { lastArrayElement } from '../utils/Utils';
import LiveGameTimerScoreCard from './LiveGameTimer';
import LiveGameTimerDefault from './LiveGameTimerDefault';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const eventBus = require('js-event-bus')();

function SafeAreaInsetsComponent(props) {
    const safeAreaInsets = useSafeAreaInsets();
    props.setSafeAreaInsets(safeAreaInsets);
    return null;
}

class BoardHeader extends React.Component {
    state = {
        lastMoveTxtColor: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
        tileInBagTxtColor: ColorConfig.LIVE_GAMES_TIMER_CARD_TILES_IN_BAG,
        safeAreaInsetsTop: 0,
    };

    componentDidMount = () => {
        eventBus.on(Config.KEYBOARD_SHORTCUT_SHOW_UNSEEN_TILES, this.onLeftoverTilesClick);
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(this.props, nextProps) || !isEqual(this.state, nextState);

    componentWillUnmount = () => {
        eventBus.detach(Config.KEYBOARD_SHORTCUT_SHOW_UNSEEN_TILES, this.onLeftoverTilesClick);
    };

    onTileBagIn = () => {
        this.setState({
            tileInBagTxtColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR,
        });
    };
    onTileBagOut = () => {
        this.setState({
            tileInBagTxtColor: ColorConfig.LIVE_GAMES_TIMER_CARD_TILES_IN_BAG,
        });
    };

    onLastMoveIn = () => {
        this.setState({
            lastMoveTxtColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR,
        });
    };
    onLastMoveOut = () => {
        this.setState({
            lastMoveTxtColor: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
        });
    };

    setSafeAreaInsets = (insetsValue) => {
        this.setState({ safeAreaInsetsTop: insetsValue.top });
    };

    renderForNative = () => (
        <View
            onLayout={(event) => {
                let headerHeight = event.nativeEvent.layout.height + this.state.safeAreaInsetsTop;
                LayoutWrapper.setBoardHeaderHeight(headerHeight);
            }}
        >
            <SafeAreaInsetsComponent setSafeAreaInsets={this.setSafeAreaInsets} />
            {(this.props.game.players || []).length === 0 ? (
                <LiveGameTimerDefault />
            ) : (
                <LiveGameTimerScoreCard playersDataOnly />
            )}
        </View>
    );

    render = () =>
        DimensionUtils.isNative() ? (
            this.renderForNative()
        ) : (
            <View
                style={[
                    styles.mainContainer,
                    ...(this.props.lastMoveTilesRemainingOnly ? [styles.topBorders, styles.aboveViewContainerStyles] : [null]),
                    LayoutUtils.getScoreTimerMainContainerDimension(),
                ]}
                key={this.state.key}
                onLayout={(event) => {
                    LayoutWrapper.setBoardHeaderHeight(event.nativeEvent.layout.height);
                }}
            >
                {this.renderBoardData()}
            </View>
        );

    getCurrentTurn = () => this.props.game.currentTurn;

    getTilesInBagNumber = () => this.props.game.unseenTileCount;

    getVowelCount = () => (!isNaN(this.props.game.unseenVowelCount) ? this.props.game.unseenVowelCount || 0 : 0);

    getVowelPercentage = () => Math.round((this.getVowelCount() * 100) / (this.getTilesInBagNumber() || 1));

    getTilesInBag = () => this.getTilesInBagNumber() + ' unseen, ' + this.getVowelPercentage() + '% V';

    haveInitialMovesCompleted = () => {
        let i,
            isCompleted = false;
        for (i = 1; i <= (this.props.game.players || []).length; i++) {
            if (typeof get(this.props, 'game.moveListCompleteData.0.' + i) === 'object') {
                isCompleted = true;
            } else {
                isCompleted = false;
                break;
            }
        }
        return isCompleted;
    };

    shouldShowFirstMoveTimer = () => {
        let isPuzzleGame = this.props.game.game_type === 'puzzle';
        let isEmailGame = this.props.game.game_type === 'email';
        let isSoloGame = this.props.game.game_type === 'solo';
        let isBlitzGame = this.props.game.game_type === Config.GAME_TYPE_BLITZ;

        let isObserving = !this.props.game.pid;

        let firstMoveOver = this.haveInitialMovesCompleted();

        let gameHasEnded = this.props.game.gameHasEnded;

        return !gameHasEnded && !(isPuzzleGame || isEmailGame || isSoloGame || isObserving || isBlitzGame) && !firstMoveOver;
    };

    hasLastWordData = () => {
        let moveListCompleteData = this.props.game.moveListCompleteData;

        return moveListCompleteData && moveListCompleteData.length > 0;
    };

    getLastWordData = () => {
        let moveListCompleteData = this.props.game.moveListCompleteData;

        let lastMoveSet = moveListCompleteData && (lastArrayElement(moveListCompleteData) || []);

        let keySet = Object.keys(lastMoveSet || {}) || [];
        let lastPid = Math.max(...keySet.map((item) => Number(item)));

        return lastMoveSet[String(lastPid)];
    };

    renderBoardData = () => (
        <View style={[styles.scoreTimerContainerForTopBar, isPuzzleGame() ? null : styles.rowReverse, styles.overflowHidden]}>
            {/* Tiles in Bag */}
            {isPuzzleGame() ? (
                <View
                    style={[
                        {
                            width: get(this.props, 'layout.layoutBoardWidth'),
                            height: get(this.props, 'layout.layoutCellDimen'),
                        },
                        DimensionUtils.isMobile()
                            ? {
                                  marginVertical: Math.max(8 - (get(this.props, 'layout.calculationDifference') ?? 0), 4),
                              }
                            : null,
                        styles.justifyCenter,
                    ]}
                >
                    <S14Text
                        style={[
                            styles.boldFont,
                            {
                                paddingLeft: 10,
                            },
                            LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                        ]}
                    >
                        {'Created from Game #' + this.props.game.gid}
                    </S14Text>
                </View>
            ) : (
                <View
                    style={[
                        {
                            flexDirection: 'row',
                            flex: 1,
                            justifyContent: 'flex-end',
                            marginVertical: Math.max(8 - (get(this.props, 'layout.calculationDifference') ?? 0), 4),
                            marginRight: 10,
                        },
                    ]}
                >
                    <StandardButton
                        style={[
                            //styles.tilesInBagContainer,
                            //styles.justifyCenter,
                            styles.boldFont,
                            styles.alignItemsCenter,
                        ]}
                        onPress={this.onLeftoverTilesClick}
                        onMouseOver={this.onTileBagIn}
                        onMouseOut={this.onTileBagOut}
                        text={this.getTilesInBag()}
                        textStyle={[
                            styles.boldFont,
                            styles.directionRow,
                            LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                            styles.textColor,
                        ]}
                        tooltip={'Click to see tiles remaining'}
                    />
                </View>
            )}
            {DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb') ? (
                <TouchableOpacity
                    activeOpacity={1}
                    style={[styles.backButton]}
                    onPress={() => this.props.gameBoardGoBack && this.props.gameBoardGoBack()}
                >
                    <FontAwesomeIcon
                        icon={faArrowLeft}
                        size={LayoutUtils.getPanelStatsSmallerThanToolTipFontSize().fontSize}
                        color={ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR}
                    />
                    <S14Text
                        style={[
                            styles.boldFont,
                            LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                            styles.textColor,
                            { marginLeft: 2 },
                        ]}
                    >
                        {'Back'}
                    </S14Text>
                </TouchableOpacity>
            ) : null}
            {/* Score and First Move Timer */}
            <View style={[styles.scoreMainContainer]}>
                {this.shouldShowFirstMoveTimer() ? (
                    <S14Text
                        style={[
                            styles.boldFont,
                            styles.directionRow,
                            LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                            styles.textColor,
                        ]}
                    >
                        {this.renderPlayerFirstMoveGameDeleteIndicator()}
                    </S14Text>
                ) : null}
                {!this.shouldShowFirstMoveTimer() && this.hasLastWordData() ? (
                    <StandardButton
                        style={[
                            styles.lastWordDataContainer,
                            styles.justifyCenter,
                            styles.boldFont,
                            styles.row,
                            styles.alignItemsCenter,
                        ]}
                        onPress={this.openMovesList}
                        onMouseOver={this.onLastMoveIn}
                        onMouseOut={this.onLastMoveOut}
                        text={
                            this.getLastWordData()
                                ? this.getLastWordData().words +
                                  ' (' +
                                  (this.getLastWordData().swapTileCount
                                      ? this.getLastWordData().swapTileCount +
                                        (Number(this.getLastWordData().swapTileCount) > 1 ? ' tiles' : ' tile')
                                      : (!isNaN(Number(get(this.getLastWordData() || {}, 'score')))
                                            ? get(this.getLastWordData() || {}, 'score')
                                            : ''
                                        ).toString()) +
                                  ')'
                                : null
                        }
                        textStyle={[
                            styles.boldFont,
                            this.getLastWordStyle(),
                            LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                        ]}
                        tooltip={'Click to see moves list'}
                    />
                ) : null}
            </View>
        </View>
    );

    getIconStyleObj = () => ({
        fontSize: get(this.props, 'layout.layoutFontAwesomeIconSize'),
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
    });

    getLastWordStyle = () => ({
        color: this.state.lastMoveTxtColor,
    });

    renderPlayerFirstMoveGameDeleteIndicator = () => {
        let firstMoveDuration = this.props.user.firstMoveDuration
            ? this.props.user.firstMoveDuration * 1000
            : Config.FIRST_MOVE_PLAYER_COUNTDOWN_TIME;
        let playerData = (this.props.game.players || []).find(
            (player) => String(player.pid) === String(this.props.game.currentTurn)
        );
        let elapsedTime = playerData && !!playerData.turnStartTime ? Date.now() - playerData.turnStartTime : 0;
        let timeLeft = firstMoveDuration - elapsedTime;
        this['player_first_move'] && this['player_first_move'].setTime(timeLeft);
        return (
            <Timer
                timeToUpdate={1000}
                initialTime={firstMoveDuration}
                direction="backward"
                lastUnit="s"
                startImmediately={true}
            >
                {({ start, resume, pause, stop, reset, setTime }) => {
                    this['player_first_move'] = {
                        start,
                        stop,
                        pause,
                        reset,
                        setTime,
                    };
                    return (
                        <S14Text
                            style={[
                                styles.boldFont,
                                styles.directionRow,
                                LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                                styles.textColor,
                            ]}
                        >
                            {this.props.game.pid === this.props.game.currentTurn
                                ? 'Play first turn within '
                                : 'Opponent to play first turn within '}
                            <S14Text
                                style={[
                                    styles.boldFont,
                                    styles.directionRow,
                                    LayoutUtils.getPanelStatsSmallerThanToolTipFontSize(),
                                    styles.textColor,
                                ]}
                            >
                                <Timer.Seconds />s
                            </S14Text>
                        </S14Text>
                    );
                }}
            </Timer>
        );
    };

    openMovesList = () => eventBus.emit(Config.SHOW_MOVES_LIST);

    onLeftoverTilesClick = () => {
        eventBus.emit(Config.SHOW_UNSEEN_TILES_DIALOG, null);
    };
}

const styles = StyleSheet.create({
    mainContainer: {
        flexDirection: 'column',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: 0,
        overflow: 'hidden',
    },
    topBorders: {
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    directionRow: {
        flexDirection: 'row',
    },
    scoreTimerContainerForTopBar: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    boldFont: {
        fontWeight: 'bold',
    },
    tilesInBag: {
        alignSelf: 'center',
    },
    tilesInBagContainer: {
        flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexBasis: '0%',
    },
    lastWordDataContainer: {
        flex: 1,
    },
    row: {
        flexDirection: 'row',
    },
    rowReverse: {
        flexDirection: 'row-reverse',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    alignItemsCenter: {
        alignItems: 'center',
    },
    scoreMainContainer: {
        alignItems: 'flex-start',
        justifyContent: 'center',
        flex: 1,
        paddingLeft: 10,
        flexDirection: 'column-reverse',
        flexBasis: '0%',
    },
    aboveViewContainerStyles: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    textColor: {
        color: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
    },
    firstTurnCountdownStyle: {
        width: 20,
        marginLeft: 3,
    },
    pl3: {
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
    },
    ph3: {
        marginHorizontal: Config.RIGHT_LEFT_MARGIN,
    },
    backButton: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        marginHorizontal: 10,
        flexDirection: 'row',
        flexBasis: '0%',
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: state.layout,
    user: state.user,
    config: state.config,
});

export default connect(mapStateToProps)(BoardHeader);
