// @flow

import type { HostedGameElement, ActionGeneric, ActionHostedGameType } from '../../commons/RJTypes';
import * as CONSTANTS from '../../commons/Constants';
import { RESET_HOSTED_GAMES } from './HostedGameEvents';

export const actionResetHostedGames = (data: Array<HostedGameElement>, guid: ?string): ActionHostedGameType => {
    let myguid = guid ?? CONSTANTS.Default_guid;
    return {
        type: RESET_HOSTED_GAMES,
        payload: data,
        guid: myguid,
    };
};
