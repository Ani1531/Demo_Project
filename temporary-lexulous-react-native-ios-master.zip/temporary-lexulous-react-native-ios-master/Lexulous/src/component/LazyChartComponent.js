import React from 'react';
import { StyleSheet, View } from 'react-native';
import { LineChart, YAxis, XAxis, Grid } from 'react-native-svg-charts';
import { Circle, Rect, Text, Svg } from 'react-native-svg';
import GameBoardUtils from '../utils/GameBoardUtils';
import { connect } from 'react-redux';
import cloneDeep from 'lodash/cloneDeep';
import Config from '../configs/Config';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import LayoutUtils from '../utils/LayoutUtils';

function handleTooltipShown() {
    this.onMouseEnter(this.index, this.yPonit);
}

class Tooltip extends React.Component {
    getTooltipCoordinates = (length) => {
        const { x, y, xPoint, yPoint, maxYAxisPoint, totalMoves } = this.props;
        let rectHeight = 0;
        let rectWidth = 100;
        let adjustValue = 5;

        if (length === 4) {
            rectHeight = 83;
        } else if (length === 3) {
            rectHeight = 67;
        } else if (length === 2) {
            rectHeight = 55;
        } else {
            rectHeight = 40;
        }

        let moves = parseInt(totalMoves) + 5;
        let half = Math.round(moves / 2);

        let tooltipX =
            xPoint >= half
                ? x(xPoint) - (rectWidth + adjustValue)
                : x(xPoint) + adjustValue;

        let tooltipY = y(yPoint) - rectHeight;
        if (yPoint >= parseInt(maxYAxisPoint * (2 / 3))) {
            tooltipY = y(yPoint) + adjustValue;
        }

        return {
            tooltipX: tooltipX,
            tooltipY: tooltipY,
            tooltipWidth: rectWidth,
            tooltipHeight: rectHeight,
        };
    };

    render = () => {
        const { playersData } = this.props;

        let arr = [];
        for (let key in playersData) {
            if (key !== 'move') {
                let data = playersData[key];
                arr.push({
                    pid: data.player.pid,
                    name: data.player.name,
                    score: data.totalScore,
                    strokeColor: data.strokeColor,
                });
            }
        }

        let textY = 0;
        const coordinates = this.getTooltipCoordinates(parseInt(arr.length));

        return (
            <Svg x={coordinates.tooltipX} y={coordinates.tooltipY}>
                <Rect
                    height={coordinates.tooltipHeight}
                    width={coordinates.tooltipWidth}
                    stroke={'#666666'}
                    fill={'#ffffff'}
                />
                <Text
                    x={7}
                    y={textY}
                    dy={15}
                    fontSize={'11'}
                    stroke={'#555555'}
                    fill={'#555555'}
                >
                    {'Move ' + playersData.move}
                </Text>
                {arr.map((v, i) => {
                    textY = textY + 15;
                    return (
                        <Text
                            x={7}
                            y={textY}
                            dy={16}
                            stroke={
                                LiveGamePlayUtils.isBlitzGame()
                                    ? v.strokeColor
                                    : GameBoardUtils.getPlayerWiseStrokeColor(
                                          v.pid
                                      )
                            }
                            fill={
                                LiveGamePlayUtils.isBlitzGame()
                                    ? v.strokeColor
                                    : GameBoardUtils.getPlayerWiseStrokeColor(
                                          v.pid
                                      )
                            }
                            fontSize={'9'}
                        >
                            {v.name + ': ' + v.score}
                        </Text>
                    );
                })}
            </Svg>
        );
    };
}

class Marker extends React.Component {
    render = () => {
        const { x, y, scores, pid, strokeColor } = this.props;
        return scores.map((v, i) => {
            return (
                <Circle
                    key={i}
                    cx={x(i)}
                    cy={y(v)}
                    r={3}
                    stroke={
                        LiveGamePlayUtils.isBlitzGame()
                            ? strokeColor
                            : GameBoardUtils.getPlayerWiseStrokeColor(pid)
                    }
                    strokeWidth={1}
                    fill={
                        LiveGamePlayUtils.isBlitzGame()
                            ? strokeColor
                            : GameBoardUtils.getPlayerWiseStrokeColor(pid)
                    }
                    style={[LayoutUtils.getCursorPointerStyle()]}
                    onMouseEnter={handleTooltipShown.bind({
                        onMouseEnter: this.props.onMouseEnter,
                        index: i,
                        yPonit: v,
                    })}
                    onMouseOut={this.props.onMouseOut}
                />
            );
        });
    };
}

class LazyChartComponent extends React.Component {
    state = {
        chartData: [],
        showTooltip: false,
        xPoint: 0,
        yPoint: 0,
        playersData: {},
    };

    getBlitzGameData = () =>
        (this.props.gamelist.observableGamesList || []).find(
            (game) => game.gid === this.props.game.gid
        ) ||
        this.props.gamelist.standingGameData ||
        {};

    getBlitzGameMoveCount = () => {
        let players = this.getBlitzGameData().jndplys || [];
        let maxMoveCount = 0;
        players.forEach((v, i) => {
            if (v.cnseqtvscr.length > maxMoveCount)
                maxMoveCount = v.cnseqtvscr.length;
        });
        return maxMoveCount;
    };

    getGraphData = () => {
        let arr = [];
        if (LiveGamePlayUtils.isBlitzGame()) {
            let players = this.getBlitzGameData().jndplys || [];
            players.forEach((v, i) => {
                if (v.hasOwnProperty('guid')) {
                    let tempScore = 0;
                    let scoresInGame = v.cnseqtvscr.map((item) => {
                        tempScore = tempScore + Number(item);
                        return tempScore;
                    });
                    arr.push({
                        pid: v.guid,
                        data: scoresInGame,
                        strokeColor: v.strokeColor,
                        svg: {
                            stroke: v.strokeColor,
                        },
                    });
                }
            });
        } else {
            this.props.game.players.forEach((v, i) => {
                if (v.hasOwnProperty('pid')) {
                    arr.push({
                        pid: v.pid,
                        data: v.scoresInGame,
                        svg: {
                            stroke: GameBoardUtils.getPlayerWiseStrokeColor(
                                v.pid
                            ),
                        },
                    });
                }
            });
        }
        return arr;
    };

    renderToolTip = (index, yPoint) => {
        let playersData = {};
        if (LiveGamePlayUtils.isBlitzGame()) {
            let players = this.getBlitzGameData().jndplys || [];
            players.forEach((v, i) => {
                if (v.cnseqtvscr.length > index) {
                    playersData = {
                        ...playersData,
                        ...{
                            [v.guid]: {
                                totalScore: v.cnseqtvscr
                                    .slice(0, index + 1)
                                    .reduce((a, b) => Number(a) + Number(b), 0),
                                player: { pid: v.guid, name: v.player.name },
                                strokeColor: v.strokeColor,
                            },
                        },
                    };
                }
            });
        } else {
            playersData = cloneDeep(
                this.props.game.moveListCompleteData[index]
            );
        }
        playersData.move = index + 1;

        this.setState({
            showTooltip: true,
            xPoint: index,
            yPoint: yPoint,
            playersData: playersData,
        });
    };

    hideTooltip = () => {
        this.setState({
            showTooltip: false,
        });
    };

    getAxisSvgStyle = () => ({
        fontSize: 10,
        fill: 'grey',
    });

    getChartContentIset = () => ({
        top: 5,
        left: 0,
        right: 0,
        bottom: 5,
    });

    getXAxisContentInset = () => ({
        left: 10,
        right: 10,
    });

    getXAxisData = () => {
        const { moveListCompleteData } = this.props.game;
        let moveCount = LiveGamePlayUtils.isBlitzGame()
            ? this.getBlitzGameMoveCount()
            : parseInt(moveListCompleteData.length);

        let arr = [];

        for (let i = 0; i <= moveCount + 5; i++) {
            arr.push(i);
        }
        return arr;
    };

    getYAxisData = () => {
        let maxPoint = 0;
        let yData = [];
        let chartData = this.getGraphData();

        (chartData || []).forEach((value, index) => {
            if (LiveGamePlayUtils.isBlitzGame()) {
                value.data = value.data.map(Number);
            }
            let max = Math.max(...(value.data || []));
            if (max > maxPoint) {
                yData = value.data || [];
                maxPoint = max;
            }
        });

        yData = [...(yData || []), 0, maxPoint + 50];
        return yData;
    };

    render() {
        const { moveListCompleteData } = this.props.game;
        let chartData = this.getGraphData();

        return (
            <View style={styles.chartContainer}>
                <YAxis
                    data={this.getYAxisData()}
                    style={styles.yAxisStyle}
                    contentInset={this.getChartContentIset()}
                    svg={this.getAxisSvgStyle()}
                    numberOfTicks={5}
                />

                <View style={styles.flex1}>
                    <LineChart
                        style={styles.flex1}
                        data={chartData}
                        numberOfTicks={5}
                        contentInset={this.getChartContentIset()}
                        yMin={0}
                        yMax={Math.max(...this.getYAxisData())}
                        xMin={-1}
                        xMax={Math.max(...this.getXAxisData())}
                    >
                        <Grid />
                        {chartData.map((v, i) => {
                            return (
                                <Marker
                                    key={String(v.pid)}
                                    scores={v.data || []}
                                    pid={v.pid}
                                    strokeColor={v.strokeColor}
                                    onMouseEnter={this.renderToolTip}
                                    onMouseOut={this.hideTooltip}
                                />
                            );
                        })}
                        {this.state.showTooltip ? (
                            <Tooltip
                                xPoint={this.state.xPoint}
                                yPoint={this.state.yPoint}
                                maxYAxisPoint={Math.max(
                                    ...(this.getYAxisData() || [])
                                )}
                                totalMoves={
                                    this.props.game.game_type ===
                                    Config.GAME_TYPE_BLITZ
                                        ? this.getBlitzGameMoveCount()
                                        : moveListCompleteData.length
                                }
                                playersData={this.state.playersData}
                            />
                        ) : null}
                    </LineChart>
                    <XAxis
                        style={styles.xAxisStyle}
                        data={this.getXAxisData()}
                        formatLabel={(value, index) => value}
                        contentInset={this.getXAxisContentInset()}
                        svg={this.getAxisSvgStyle()}
                        numberOfTicks={5}
                    />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    marginLeftMinus30: { marginLeft: -30 },
    chartContainer: {
        flex: 1,
        padding: 10,
        flexDirection: 'row',
    },
    yAxisStyle: {
        marginBottom: 15,
        paddingRight: 3,
        borderRightWidth: 1,
        borderRightColor: 'rgba(0,0,0,0.2)',
    },
    flex1: {
        flex: 1,
    },
    xAxisStyle: {
        marginHorizontal: -10,
        height: 15,
        paddingTop: 5,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    gamelist: state.gamelist,
});

export default connect(mapStateToProps)(LazyChartComponent);
