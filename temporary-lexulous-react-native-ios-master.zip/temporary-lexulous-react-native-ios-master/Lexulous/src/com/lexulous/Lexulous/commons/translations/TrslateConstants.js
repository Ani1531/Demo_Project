// @flow

import { translate } from '../translations/LangTransator';
import * as CONSTANTS from '../Constants';

class TrslateConstants {
    DictionaryNames = (): Array<string> => [
        translate('dict_us'),
        translate('dict_uk'),
        translate('dict_it'),
        translate('dict_fr'),
    ];
    BoardTypes = (): Array<string> => [translate('board_clsc'), translate('board_lx')];
    GameTypes = (): Array<string> => [translate('game_reglr'), translate('game_chlg')];
    BoardCenterImgTypes = (): Array<string> => [
        CONSTANTS.BOARD_CENTER_ICONS.ICON_GHOST,
        CONSTANTS.BOARD_CENTER_ICONS.ICON_SMILE,
        CONSTANTS.BOARD_CENTER_ICONS.ICON_PLUS,
        CONSTANTS.BOARD_CENTER_ICONS.ICON_CAT,
        CONSTANTS.BOARD_CENTER_ICONS.ICON_DOG,
    ];
    FontSizeTypes = (): Array<string> => [
        CONSTANTS.FONT_SIZES.TINY,
        CONSTANTS.FONT_SIZES.SMALL,
        CONSTANTS.FONT_SIZES.MEDIUM,
        CONSTANTS.FONT_SIZES.BIG,
        CONSTANTS.FONT_SIZES.BIGGER,
    ];
    DictionaryValues = (): { [key: string]: string } => {
        return {
            twl: translate('dict_us'),
            sow: translate('dict_uk'),
            it: translate('dict_it'),
            fr: translate('dict_fr'),
        };
    };
    GameTypeValues = (): { [key: string]: string } => {
        return {
            ER: translate('game_reglr'),
            EC: translate('game_chlg'),
        };
    };
    BoardTypeValues = (): { [key: string]: string } => {
        return {
            N: translate('board_clsc'),
            S: translate('board_lx'),
        };
    };
    DictionaryServervalues = (): { [key: string]: string } => {
        return {
            [translate('dict_us')]: CONSTANTS.US_English,
            [translate('dict_uk')]: CONSTANTS.UK_English,
            [translate('dict_it')]: CONSTANTS.Italian,
            [translate('dict_fr')]: CONSTANTS.French,
        };
    };
    BoardServervalues = (): { [key: string]: string } => {
        return {
            [translate('board_clsc')]: CONSTANTS.Normal,
            [translate('board_lx')]: CONSTANTS.Super,
        };
    };
    gameServervalues = (): { [key: string]: string } => {
        return {
            [translate('game_reglr')]: CONSTANTS.Email_Regular,
            [translate('game_chlg')]: CONSTANTS.Email_Challange,
        };
    };
}

const trslateConstants = new TrslateConstants();

export default trslateConstants;
