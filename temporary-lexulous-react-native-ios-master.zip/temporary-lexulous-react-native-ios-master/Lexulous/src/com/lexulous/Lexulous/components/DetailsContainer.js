// @flow

import React from 'react';
import { StyleSheet, Text, View, Image, Pressable, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { avtarIcons, getLexIdWithDash, Default_Avtar, Default_guid } from '../commons/Constants';
import type { ProfileInfo, ProfileAssociations } from '../commons/RJTypes';
import { translate } from '../commons/translations/LangTransator';
import themeConfigutation from '../commons/ThemeConfiguration';

type DetailsContainerProps = {
    closePopupHandler: () => void,
    details: { profile: ProfileInfo, ProfileVw: ProfileAssociations },
    detailTypeKey: string,
};

class DetailsContainer extends React.Component<DetailsContainerProps> {
    renderFBDetails = () => {
        let uri = '';
        let username = '';
        let userID = '';
        let Lex_ID = this.props.details.profile.guid ?? Default_guid;

        if (this.props.details.ProfileVw.fbLoginInfo !== null && this.props.details.ProfileVw.fbLoginInfo !== undefined) {
            if (
                this.props.details.ProfileVw.fbLoginInfo.username !== null &&
                this.props.details.ProfileVw.fbLoginInfo.username !== undefined
            ) {
                username = Platform.select({
                    native: this.props.details.ProfileVw.fbLoginInfo.username,
                    default: this.props.details.profile.name,
                });
            }
            if (
                this.props.details.ProfileVw.fbLoginInfo.fbAccessToken !== null &&
                this.props.details.ProfileVw.fbLoginInfo.fbAccessToken !== undefined
            ) {
                uri =
                    this.props.details.profile.picurl ??
                    `https://graph.facebook.com/v12.0/${this.props.details.ProfileVw.fbLoginInfo.fbAccessToken.userID}/picture`;
                userID = this.props.details.ProfileVw.fbLoginInfo.fbAccessToken.userID;
            }
        }
        let getFBDetailsforNative = () => {
            if (userID != null && userID != '') {
                return (
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.detailsTextstyle, { color: themeConfigutation.getColor('#000') }]}>
                            {translate('u_id')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {userID}
                        </Text>
                    </View>
                );
            } else {
                return null;
            }
        };
        let getFBDetailsforWeb = () => {
            return (
                <View style={{ flexDirection: 'row' }}>
                    <Text style={[styles.detailsTextstyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('lx_id')}
                    </Text>
                    <Text
                        style={[styles.detailsTextstyle, styles.infoTextStyle, { color: themeConfigutation.getColor('#000') }]}
                    >
                        {getLexIdWithDash(Lex_ID)}
                    </Text>
                </View>
            );
        };
        return (
            <View style={styles.detailsFeildsStyle}>
                <Image
                    source={{
                        uri: uri,
                    }}
                    style={[styles.avatarFieldStyle]}
                />
                <View style={styles.eachDetailFeild}>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('dtl_nm')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {username}
                        </Text>
                    </View>
                    {Platform.select({
                        native: getFBDetailsforNative(),
                        default: getFBDetailsforWeb(),
                    })}
                </View>
            </View>
        );
    };

    renderGoogleDetails = () => {
        let uri = this.props.details.ProfileVw.gglLoginInfo?.userInfo?.user.photo;
        let username =
            this.props.details.ProfileVw.gglLoginInfo?.userInfo?.user.name ?? this.props.details.profile.name ?? 'Google User';
        let Lex_ID = this.props.details.profile.guid ?? Default_guid;
        let email = this.props.details.ProfileVw.gglLoginInfo?.userInfo?.user.email ?? '';
        let G_ID = this.props.details.ProfileVw.gglLoginInfo?.userInfo?.user.id ?? '';

        return (
            <View style={styles.detailsFeildsStyle}>
                <Image source={{ uri: uri }} style={[styles.avatarFieldStyle]} />
                <View style={styles.eachDetailFeild}>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('dtl_nm')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {username}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.detailsTextstyle, { marginBottom: 6 }]}>{translate('lx_id')}</Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {getLexIdWithDash(Lex_ID)}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('lx_mail')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {email}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.detailsTextstyle, { color: themeConfigutation.getColor('#000') }]}>
                            {translate('g_id')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {G_ID}
                        </Text>
                    </View>
                </View>
            </View>
        );
    };

    renderLxlxDetails = () => {
        let avtar: string = this.props.details.profile.avtar ?? Default_Avtar;
        let timg: number | {| uri: string |} = this.props.details.profile.picurl
            ? { uri: this.props.details.profile.picurl }
            : avtarIcons[avtar];
        let name = this.props.details.profile.name ?? 'Lexuous User';
        let Lex_ID = this.props.details.profile.guid ?? Default_guid;
        let email = this.props.details.ProfileVw.lxlsLoginInfo?.email ?? '';

        return (
            <View style={styles.detailsFeildsStyle}>
                <Image source={timg} style={[styles.avatarFieldStyle]} />
                <View style={styles.eachDetailFeild}>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('dtl_nm')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {name}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('lx_id')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {getLexIdWithDash(Lex_ID)}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.detailsTextstyle, { color: themeConfigutation.getColor('#000') }]}>
                            {translate('lx_mail')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {email}
                        </Text>
                    </View>
                </View>
            </View>
        );
    };

    renderLxlxDetails_Apple = () => {
        let avtar = this.props.details.profile.avtar ?? Default_Avtar;
        let name =
            this.props.details.ProfileVw.appleLoginInfo?.nickname ??
            this.props.details.ProfileVw.appleLoginInfo?.gvnname ??
            this.props.details.profile.name ??
            '';
        let appleid = this.props.details.ProfileVw.appleLoginInfo?.appluserid ?? '';
        let email = this.props.details.ProfileVw.appleLoginInfo?.applemail ?? '';
        let Lex_ID = this.props.details.profile.guid ?? Default_guid;
        return (
            <View style={styles.detailsFeildsStyle}>
                <Image source={avtarIcons[avtar]} style={[styles.avatarFieldStyle]} />
                <View style={styles.eachDetailFeild}>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('dtl_nm')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {name}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('lx_id')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {getLexIdWithDash(Lex_ID)}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text
                            style={[styles.detailsTextstyle, { marginBottom: 6, color: themeConfigutation.getColor('#000') }]}
                        >
                            {translate('apl_id')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { marginBottom: 6, color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {appleid}
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.detailsTextstyle, { color: themeConfigutation.getColor('#000') }]}>
                            {translate('lx_mail')}
                        </Text>
                        <Text
                            style={[
                                styles.detailsTextstyle,
                                styles.infoTextStyle,
                                { color: themeConfigutation.getColor('#000') },
                            ]}
                        >
                            {email}
                        </Text>
                    </View>
                </View>
            </View>
        );
    };

    renderDetails = () => {
        if (this.props.detailTypeKey === 'ac_facebook') {
            return this.renderFBDetails();
        }
        if (this.props.detailTypeKey === 'ac_google') {
            return this.renderGoogleDetails();
        }
        if (this.props.detailTypeKey === 'ac_lexulous') {
            return this.renderLxlxDetails();
        }
        if (this.props.detailTypeKey === 'ac_apple') {
            return this.renderLxlxDetails_Apple();
        }
        return null;
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.detailsContainer,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.props.closePopupHandler()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Text style={[styles.PopupHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('details')}
                    </Text>
                    {this.renderDetails()}
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    xBtnContainerStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 2,
    },
    detailsContainer: {
        flexDirection: 'column',
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        width: '95%',
        maxWidth: 320,
    },
    detailsFeildsStyle: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingBottom: 4,
        marginBottom: 20,
    },
    avatarFieldStyle: {
        width: 50,
        height: 50,
    },
    eachDetailFeild: {
        marginLeft: 14,
        flexGrow: 1,
    },
    detailsTextstyle: {
        fontSize: 14,
    },
    infoTextStyle: {
        flex: 1,
        flexWrap: 'wrap',
        maxWidth: 160,
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    PopupHeaderStyle: {
        color: '#ffffff',
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
        marginBottom: 8,
        textDecorationLine: 'underline',
    },
});

export default DetailsContainer;
