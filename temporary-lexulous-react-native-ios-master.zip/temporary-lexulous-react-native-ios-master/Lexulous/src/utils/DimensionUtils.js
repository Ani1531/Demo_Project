import DocumentWrapper from './DocumentWrapper';

export default class DimensionUtils {
    /* static getWindowDimensions = getNull;

    static isMobile = getNull;

    static getContainerPosition = getNull;

    static isSmallScreen = getNull;

    static isDivSmall = getNull;

    static isLandscape = getNull;

    static isInContainer = getNull;

    static getParentContainer = getNull;

    static getInitValues = getNull; */

    static getInitValues = () => {
        let isMobile = DimensionUtils.isMobile();
        let boardWidthDimen = DocumentWrapper.getBodyWidth();
        return {
            boardWidthDimen,
            layoutBoardDimenWidth: boardWidthDimen,
            isMobile,
        };
    };

    static getWindowDimensions = ({ divDimensOnly = false } = {}) => {
        let width = DocumentWrapper.getScreenWidth();
        let height = DocumentWrapper.getScreenHeight();
        return { width, height };
    };

    static isMobile = () => true;

    static isNative = () => true;

    static getContainerPosition = () => ({
        top: 0,
        left: 0,
    });
}
