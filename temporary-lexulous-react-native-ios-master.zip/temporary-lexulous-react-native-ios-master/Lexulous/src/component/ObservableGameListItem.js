import React, { Fragment } from 'react';
import get from 'lodash/get';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import PlayerAvatarNameRating from './PlayerAvatarNameRating';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faEye } from '@fortawesome/pro-regular-svg-icons';
import Indicator from './Indicator';
import isEqual from 'lodash/isEqual';
import DimensionUtils from '../utils/DimensionUtils';
import TooltipWrapper from './TooltipWrapper';
import isNumber from 'lodash/isNumber';
import FontAwesomeSpin from './FontAwesomeSpin';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import { lastArrayElement } from '../utils/Utils';

export default class ObservableGameListItem extends React.Component {
    state = {
        observeBtnColor: ColorConfig.BUTTON_TEXT_COLOR,
        loaderVisible: false,
    };

    componentDidMount() {
        TooltipActionWrapper.rebuild();
    }

    shouldComponentUpdate = (nextProps, nextState) =>
        !isEqual(get(this.props, 'item'), get(nextProps, 'item')) ||
        !isEqual(
            get(this.state, 'loaderVisible'),
            get(nextState, 'loaderVisible')
        ) ||
        !isEqual(
            get(this.state, 'observeBtnColor'),
            get(nextState, 'observeBtnColor')
        ) ||
        !isEqual(get(this.props, 'rowColor'), get(nextProps, 'rowColor'));

    onPress = () => {
        TooltipActionWrapper.hide();
        this.setState({ loaderVisible: true });
        this.props.onObserveGame(this.props.item);
    };

    onWatchGameItemHoverIn = () =>
        this.setState({ observeBtnColor: ColorConfig.NEW_GAME_BUTTON_COLOR });

    onWatchGameItemHoverOut = () =>
        this.setState({ observeBtnColor: ColorConfig.BUTTON_TEXT_COLOR });

    //onAvatarPress = (event) => event.stopPropagation();

    getStyleWhenMobileAndWhenNotMobile = () =>
        DimensionUtils.isMobile() ? styles.buttonMobile : styles.button;

    getBackgroundColor = () => ({ backgroundColor: this.props.rowColor });

    render = () => {
        return (
            <TouchableOpacity
                key={'inner_' + this.props.key}
                activeOpacity={1}
                onPress={(event) => {
                    //event.nativeEvent.stopImmediatePropagation();
                    this.onPress();
                }}
                disabled={this.props.isMyself}
                style={[
                    this.getStyleWhenMobileAndWhenNotMobile(),
                    styles.observeGame,
                    this.getBackgroundColor(),
                ]}
                onMouseEnter={this.onWatchGameItemHoverIn}
                onMouseLeave={this.onWatchGameItemHoverOut}
            >
                <View style={styles.indicatorIconContainer}>
                    <View style={[styles.watchGameSymbolTouchable]}>
                        {this.state.loaderVisible ? (
                            <FontAwesomeSpin />
                        ) : (
                            <TooltipWrapper
                                tooltip={'Watch Game'}
                                onPress={this.onPress}
                            >
                                <FontAwesomeIcon
                                    id={'observeicon'}
                                    key={'observeicon'}
                                    size={20}
                                    style={{
                                        color: this.state.observeBtnColor,
                                    }}
                                    icon={faEye}
                                />
                            </TooltipWrapper>
                        )}
                    </View>
                    <Indicator
                        numberOfPlayers={
                            (get(this.props.item, 'players') || []).length
                        }
                        isRated={get(this.props.item, 'livegame.rated') === 'y'}
                        dictionary={get(this.props.item, 'dic')}
                        time={get(this.props.item, 'livegame')}
                        observe={true}
                        tooltipID={'appTooltip'}
                    />
                </View>

                <View style={styles.playersContainer}>
                    {(get(this.props.item, 'players') || []).length > 2 ? (
                        <Fragment>
                            <View style={styles.width50}>
                                {lastArrayElement(
                                    get(this.props.item, 'players') || []
                                ) ? (
                                    <PlayerAvatarNameRating
                                        player={
                                            lastArrayElement(
                                                get(
                                                    this.props.item,
                                                    'players'
                                                ) || []
                                            ).fullInfo
                                        }
                                        flexDirection={'row'}
                                        watchGame={true}
                                        observe={true}
                                        onObserveGame={this.onPress}
                                        watchGameListItem={true}
                                        //avatarClick={this.onAvatarPress}
                                        tooltipID={'appTooltip'}
                                    />
                                ) : null}
                            </View>
                            <View style={(styles.width50, styles.pl3)}>
                                {get(this.props.item, 'players.1.fullInfo') ? (
                                    <PlayerAvatarNameRating
                                        player={get(
                                            this.props.item,
                                            'players.1.fullInfo'
                                        )}
                                        flexDirection={'row'}
                                        watchGame={true}
                                        observe={true}
                                        onObserveGame={this.onPress}
                                        watchGameListItem={true}
                                        //avatarClick={this.onAvatarPress}
                                        tooltipID={'appTooltip'}
                                    />
                                ) : null}
                            </View>
                        </Fragment>
                    ) : (
                        <Fragment>
                            <View style={styles.width50}>
                                {get(this.props.item, 'players.1.fullInfo') ? (
                                    <PlayerAvatarNameRating
                                        player={get(
                                            this.props.item,
                                            'players.1.fullInfo'
                                        )}
                                        flexDirection={'row'}
                                        watchGame={true}
                                        observe={true}
                                        onObserveGame={this.onPress}
                                        watchGameListItem={true}
                                        //avatarClick={this.onAvatarPress}
                                        tooltipID={'appTooltip'}
                                    />
                                ) : null}
                            </View>
                            <View style={(styles.width50, styles.pl3)}>
                                {get(this.props.item, 'players.0.fullInfo') ? (
                                    <PlayerAvatarNameRating
                                        player={get(
                                            this.props.item,
                                            'players.0.fullInfo'
                                        )}
                                        flexDirection={'row'}
                                        watchGame={true}
                                        observe={true}
                                        onObserveGame={this.onPress}
                                        watchGameListItem={true}
                                        //avatarClick={this.onAvatarPress}
                                        tooltipID={'appTooltip'}
                                    />
                                ) : null}
                            </View>
                        </Fragment>
                    )}
                </View>
            </TouchableOpacity>
        );
    };
}

const styles = StyleSheet.create({
    generalDimension: {
        height: 0,
        width: 5,
    },
    hostNameRowStyle: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
    },
    width50Percent: { width: '50%' },
    hostNameSeconNameView: { width: '50%', alignItems: 'flex-start' },
    button: {
        width: '100%',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: ColorConfig.PLAYER_LIST_ITEM_BORDER_COLOR,
        //overflow: "hidden"
    },
    buttonMobile: {
        width: '100%',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: ColorConfig.PLAYER_LIST_ITEM_BORDER_COLOR,
        //overflow: "hidden"
    },
    observeGame: {
        flexDirection: 'row-reverse',
        paddingVertical: 1,
        paddingLeft: 12,
        paddingRight: 5,
        alignItems: 'center',
    },
    observeGameViewPosition: {
        position: 'absolute',
        top: 0,
        left: '33%',
        right: '33%',
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    },
    columnDirection: {
        flexDirection: 'column',
    },
    watchGameSymbolTouchable: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    flex2: { flex: 2 },
    flex1: { flex: 1 },
    widthRightLeftMargin: { width: Config.RIGHT_LEFT_MARGIN },
    indicatorIconContainer: {
        width: '35%',
        flexDirection: 'row-reverse',
    },
    playersContainer: {
        width: '65%',
        flexDirection: 'row',
    },
    width50: {
        width: '50%',
    },
    pl3: {
        paddingLeft: 3,
    },
});
