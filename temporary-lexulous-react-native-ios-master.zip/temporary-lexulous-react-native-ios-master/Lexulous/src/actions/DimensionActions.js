import { DIMENSION_SCREEN_RESIZE } from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import DimensionUtils from '../utils/DimensionUtils';
import Config from '../configs/Config';

const eventBus = require('js-event-bus')();

export const screenResized = (event) => (dispatch, getState) => {
    let forCreateGame = !!get(event, 'forCreateGame');
    if (event && !forCreateGame) {
        dispatch({
            type: DIMENSION_SCREEN_RESIZE,
            payload: event,
            globalState: getState(),
        });
        eventBus.emit(Config.REFRESH_APP_ROOT_COMPONENT);
    } else {
        let globalState = getState();
        let gid = get(globalState, 'game.gid');
        let puzzle_id = get(globalState, 'game.puzzle_id');
        let windowDimens = {
            ...DimensionUtils.getWindowDimensions({
                divDimensOnly: true,
            }),
            ...(forCreateGame ? { top: 0, left: 0 } : {}),
        };

        if (gid || puzzle_id || forCreateGame) {
            dispatch({
                type: DIMENSION_SCREEN_RESIZE,
                payload: windowDimens,
                globalState,
            });
        }
    }
};
