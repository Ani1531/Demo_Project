//@flow

import React from 'react';
import { Switch, Platform } from 'react-native';
import type { BooleanToggleContainerProps } from '../commons/RJTypes';

type BooleanToggleContainerState = {
    switchValue: boolean,
};
export default class BooleanToggleContainer extends React.Component<BooleanToggleContainerProps, BooleanToggleContainerState> {
    constructor(props: BooleanToggleContainerProps) {
        super(props);
        this.state = {
            switchValue: this.props.value,
        };
    }
    getValue = () => {
        let updated_data = !this.props.value;
        this.setState({
            switchValue: !this.state.switchValue,
        });
        let key = this.props.tag;

        this.props.onValueSelect(key, updated_data == true ? 'y' : 'n');
    };
    render() {
        return (
            <Switch
                trackColor={{ false: '#abb8c3', true: '#bbdefb' }}
                thumbColor={this.state.switchValue ? this.props.true_col : this.props.false_col}
                {...Platform.select({
                    web: {
                        activeThumbColor: this.props.true_col,
                    },
                })}
                onValueChange={() => {
                    this.getValue();
                }}
                value={this.state.switchValue}
            />
        );
    }
}
