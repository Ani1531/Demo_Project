// @flow

import { kLoggingEnabled, COLOR, AlertBoxButtonType } from './Constants';
import crashlytics from '@react-native-firebase/crashlytics';
import dataServer from '../store/Store';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { translate } from '../commons/translations/LangTransator';
import type { AlertBoxType } from '../commons/RJTypes';
import rjAnalytics from '../../../../RJAnalytics';

export function rjLog(message: string, identifier: string = 'rjslog') {
    if (kLoggingEnabled === true) {
        console.log(JSON.stringify(identifier) + ' :: ' + JSON.stringify(message));
    }
}

export function isStrEmpty(str?: string): boolean {
    return !str || 0 === str.length;
}

export const handleException = (error: any): void => {
    crashlytics().recordError(error);
};

export const showMessage = (msg: string, source_file: string): void => {
    rjAnalytics.sendAnalyticsEvent('error_msg_alert_opened', source_file);
    let alertBoxInfo: AlertBoxType = {
        message: msg,
        actions: [
            {
                text: translate('ok'),
                action: () => {
                    rjAnalytics.sendAnalyticsEvent('error_msg_alert_closed', source_file);
                    dataServer.getStore().dispatch(clearAlert());
                },
                color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                type: AlertBoxButtonType.SHOWBUTTONONLY,
            },
        ],
    };
    dataServer.getStore().dispatch(showAlert(alertBoxInfo));
};
