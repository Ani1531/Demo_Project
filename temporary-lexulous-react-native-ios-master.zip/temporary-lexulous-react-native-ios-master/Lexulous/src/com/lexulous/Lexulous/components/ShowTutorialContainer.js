//@flow

import React, { Component } from 'react';
import { StyleSheet, View, Text, Pressable } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import userDefault from '../commons/UserDefault';
import * as CONSTANTS from '../commons/Constants';
import type { TutorialPopupProps } from '../commons/RJTypes';
import { translate } from '../commons/translations/LangTransator';
import themeConfigutation from '../commons/ThemeConfiguration';

export default class ShowTutorialContainer extends Component<TutorialPopupProps> {
    constructor(props: TutorialPopupProps) {
        super(props);
    }

    closePopup = () => {
        this.props.closePopupHandler();
        userDefault.set(CONSTANTS.kPsistAppNwUser, 'false');
    };

    showTutorial = () => {
        this.props.closePopupHandler();
        userDefault.set(CONSTANTS.kPsistAppNwUser, 'false');
        this.props.showTutorialHandler();
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.container,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.closePopup()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Text style={[styles.PopupHeaderStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {translate('ttrl_hd')}
                    </Text>
                    <Text style={[styles.discpTextStyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                        {translate('ttrl_msg')}
                    </Text>
                    <Pressable
                        style={[styles.btnStyle, { shadowColor: themeConfigutation.getColor('#000') }]}
                        onPress={() => this.showTutorial()}
                    >
                        <Text style={[styles.BtnTextStyle]}>{translate('ttrl_shw')}</Text>
                    </Pressable>
                </View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        maxWidth: 320,
        maxHeight: 350,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    btnStyle: {
        marginVertical: 20,
        padding: 8,
        borderRadius: 5,
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        backgroundColor: '#54A4E7',
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    PopupHeaderStyle: {
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
        marginBottom: 8,
    },
    BtnTextStyle: {
        color: '#ffffff',
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
    },
    discpTextStyle: {
        textAlign: 'center',
        fontSize: 12,
        paddingHorizontal: 16,
    },
});
