//@flow
import React from 'react';
import { StyleSheet, View, Pressable, Text } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCat, faDog, faGhost, faPlus, faSmile } from '@fortawesome/free-solid-svg-icons';
import * as CONSTANTS from '../commons/Constants';
import type { SectionElementContent } from '../commons/RJTypes';
import themeConfigutation from '../commons/ThemeConfiguration';

type SlidingWindowContainerProps = {
    defaultFrame: SectionElementContent,
    renderType: string,
    frameItems: Array<string>,
    onValueSelect: (string, string) => void,
};
export default class SlidingWindowContainer extends React.Component<SlidingWindowContainerProps> {
    getBoardCntrIcon = () => {
        let boardCenterIcon = this.props.defaultFrame.def_value;
        switch (boardCenterIcon) {
            case CONSTANTS.BOARD_CENTER_ICONS.ICON_CAT:
                return faCat;

            case CONSTANTS.BOARD_CENTER_ICONS.ICON_DOG:
                return faDog;

            case CONSTANTS.BOARD_CENTER_ICONS.ICON_GHOST:
                return faGhost;

            case CONSTANTS.BOARD_CENTER_ICONS.ICON_PLUS:
                return faPlus;

            case CONSTANTS.BOARD_CENTER_ICONS.ICON_SMILE:
                return faSmile;

            default:
                return faPlus;
        }
    };

    getFontText = () => {
        let fontSize = this.props.defaultFrame.def_value;
        switch (fontSize) {
            case CONSTANTS.FONT_SIZES.TINY:
                return 'Tiny';

            case CONSTANTS.FONT_SIZES.SMALL:
                return 'Small';

            case CONSTANTS.FONT_SIZES.MEDIUM:
                return 'Medium';

            case CONSTANTS.FONT_SIZES.BIG:
                return 'Big';

            case CONSTANTS.FONT_SIZES.BIGGER:
                return 'Bigger';

            default:
                return 'Medium';
        }
    };

    getSeletedValue = () => {
        let availableBoardCenterIcons = this.props.frameItems;
        let iconIndex = availableBoardCenterIcons.findIndex((item) => item === this.props.defaultFrame.def_value);
        let nextIconIndex = iconIndex + 1;
        if (nextIconIndex >= availableBoardCenterIcons.length) {
            nextIconIndex = 0;
        }
        let val: string = availableBoardCenterIcons[nextIconIndex];
        this.props.onValueSelect(this.props.defaultFrame.key, val);
    };

    renderIconSlidingWindow = () => {
        return (
            <Pressable style={styles.sliderBtnStyle} onPress={() => this.getSeletedValue()}>
                <View style={{ alignItems: 'center' }}>
                    <FontAwesomeIcon icon={this.getBoardCntrIcon()} size={30} color={themeConfigutation.getColor('#000')} />
                </View>
            </Pressable>
        );
    };

    renderTextSlidingWindow = () => {
        return (
            <Pressable style={styles.sliderBtnStyle} onPress={() => this.getSeletedValue()}>
                <View style={{ alignItems: 'center' }}>
                    <Text
                        style={[
                            {
                                fontSize: parseInt(this.props.defaultFrame.def_value),
                                color: themeConfigutation.getColor('#000'),
                            },
                        ]}
                    >
                        {this.getFontText()}
                    </Text>
                </View>
            </Pressable>
        );
    };

    render() {
        if (this.props.renderType === 'icon') {
            return this.renderIconSlidingWindow();
        } else if (this.props.renderType === 'text') {
            return this.renderTextSlidingWindow();
        } else {
            return null;
        }
    }
}

const styles = StyleSheet.create({
    sliderBtnStyle: {
        margin: 4,
    },
});
