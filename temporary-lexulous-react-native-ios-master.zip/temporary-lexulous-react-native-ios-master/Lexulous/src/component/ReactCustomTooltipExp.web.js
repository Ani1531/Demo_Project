import React from 'react';
import ReactTooltip from 'react-tooltip';

export default class ReactCustomTooltipExp extends React.PureComponent {
    render = () => (
        <ReactTooltip
            id="expTooltip"
            place="bottom"
            className="customTooltip"
        />
    );
}
