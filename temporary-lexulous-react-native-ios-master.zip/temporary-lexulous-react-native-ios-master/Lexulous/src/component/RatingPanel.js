import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import StandardButton from './StandardButton';
import { connect } from 'react-redux';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';

class RatingPanel extends React.Component {
    getPanelHeadStyles = () => ({
        padding: this.props.layout.layoutSidePanelTitleBarPadding,
    });

    getPanelFontSizeObj = () => ({
        fontSize: this.props.layout.layoutSidePanelFontSize,
    });

    getPanelBodyPaddingObj = () => ({
        padding: this.props.layout.layoutSidePanelBodyPadding,
    });

    getBodyFontColorObj = () => ({
        color:
            this.props.game.changeInRating === undefined
                ? ColorConfig.SIDE_PANEL_SECONDARY_TEXT_COLOR
                : this.props.game.changeInRating === 'increase'
                ? '#5eb42c'
                : '#c23742',
    });

    render = () => (
        <View style={[styles.mainContainer, styles.container]}>
            {/* Rating Heading */}
            <S14Text
                style={[
                    styles.headingData,
                    this.getPanelFontSizeObj(),
                    this.getPanelHeadStyles(),
                    LayoutUtils.getCursorDefaultStyle(),
                ]}
            >
                {'Your Puzzle Rating' +
                    (!!this.props.game.puzzleRanking ? ' / Ranking' : '')}
            </S14Text>

            {/* Rating Data */}
            <StandardButton
                style={[this.getPanelBodyPaddingObj()]}
                text={this.getRatingRankingText()}
                textStyle={[
                    styles.ratingData,
                    this.getPanelFontSizeObj(),
                    this.getBodyFontColorObj(),
                ]}
            />
            <View style={styles.seperationLineStyle} />
        </View>
    );

    getRatingRankingText = () => {
        if (
            this.props.game.puzzleRating ||
            Number(this.props.game.puzzleRating) === 0
        ) {
            return (
                this.props.game.puzzleRating +
                (!!this.props.game.puzzleRanking
                    ? ' / ' + this.props.game.puzzleRanking
                    : '')
            );
        }
        return 'No Rating Available';
    };
}

const styles = StyleSheet.create({
    ratingData: {
        alignSelf: 'center',
    },
    headingData: {
        color: ColorConfig.SIDE_PANEL_HEADING_TEXT_COLOR,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    container: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    mainContainer: {
        marginBottom: Config.SIDE_PANEL_WRAPPER_PADDING,
        width: '100%',
    },
    seperationLineStyle: {
        borderTopWidth: 1,
        borderTopColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    game: state.game,
});

export default connect(mapStateToProps)(RatingPanel);
