import React from 'react';
import { FlatList } from 'react-native';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import { connect } from 'react-redux';
import log from 'loglevel';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import OnlinePlayerListItem from './OnlinePlayerListItem';
import GameBoardUtils from '../utils/GameBoardUtils';
import { formatName } from '../utils/StringUtils';
import ColorConfig from '../configs/ColorConfig';

require('format-unicorn');

class OnlinePlayerListFlatList extends React.Component {
    shouldComponentUpdate = (nextProps) =>
        !isEqual(
            get(nextProps, 'user.myData'),
            get(this.props, 'user.myData')
        ) ||
        !isEqual(
            get(nextProps, 'user.onlinePlayerBuddies'),
            get(this.props, 'user.onlinePlayerBuddies')
        ) ||
        !isEqual(
            get(nextProps, 'user.onlinePlayerOthers'),
            get(this.props, 'user.onlinePlayerOthers')
        ) ||
        !isEqual(
            get(nextProps, 'user.buddyRequestList'),
            get(this.props, 'user.buddyRequestList')
        );

    getPlayerListData = () => {
        log.info(
            'in OnlinePlayerListFlatList, in getPlayerListData, this.props.user.onlinePlayerOthers is:\n' +
                JSON.stringify(this.props.user.onlinePlayerOthers, null, 2)
        );
        return [
            ...(this.props.user.myData || []),
            ...(this.props.user.onlinePlayerBuddies || []).filter(
                (element) => element.usrtype === 'u'
            ),
            ...(this.props.user.onlinePlayerOthers || []).filter(
                (element) => element.usrtype === 'u'
            ),
        ];
    };

    getCursor = (isPlaying, item) => ({
        cursor:
            isPlaying || GameBoardUtils.isMyself(item) ? 'default' : 'pointer',
    });

    renderPlayerListItem = ({ item, index }) => {
        let isPlaying = LiveGamePlayUtils.isPlayerPlaying(item.status);
        return (
            <OnlinePlayerListItem
                item={item}
                rowColor={
                    index % 2 !== 0
                        ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN
                        : null
                }
                hasBuddyReq={(
                    get(this.props, 'user.buddyRequestList') || []
                ).find((player) => player.guid === item.guid)}
                isPlaying={isPlaying}
                onObserveGame={this.props.onObserveGame}
                isMyself={GameBoardUtils.isMyself(item)}
                cursor={this.getCursor(isPlaying, item)}
                avatarUrl={this.props.config['avatar_url_format'].formatUnicorn(
                    { id: get(item, 'avtar') }
                )}
                avatarId={get(item, 'avtar')}
                formattedName={formatName(get(item, 'name'))}
                rating={
                    get(item, 'rating') ||
                    LiveGamePlayUtils.getRatingForPlayer(item.guid)
                }
                statusText={LiveGamePlayUtils.getStatusTextFromCode(
                    item.status
                )}
            />
        );
    };

    render = () => (
        <FlatList
            data={this.getPlayerListData()}
            renderItem={this.renderPlayerListItem}
            keyExtractor={(item) => item.guid}
            removeClippedSubviews={true}
            initialNumToRender={30}
            maxToRenderPerBatch={30}
            showsVerticalScrollIndicator={true}
            className={'appFlatList'}
            style={{
                width: '100%',
                height: '100%',
                backgroundColor: ColorConfig.PLAYER_LIST_BACKGROUND_COLOR,
            }}
        />
    );
}

const mapStateToProps = (state) => ({
    config: state.config,
    user: state.user,
});

export default connect(mapStateToProps)(OnlinePlayerListFlatList);
