import 'animated-value';

export default class AnimatedValueWrapped {
    static create = (params) => new window.AnimatedValue(params);
    static compose = (params) => window.AnimatedValue.compose(params);
}
