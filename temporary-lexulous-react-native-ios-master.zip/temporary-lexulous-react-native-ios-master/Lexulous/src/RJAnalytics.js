// @flow

import ReactGA from 'react-ga4';

//remove any debug test options in rjanalytics
const kGATrackingID = 'G-F4EN1KPEGE';

class RJAnalytics {
    constructor() {
        ReactGA.initialize(kGATrackingID, { gtagOptions: { debug_mode: true } });
    }

    sendAnalyticsEvent = async (event: string, category: string) => {
        let params = {
            category: category,
            action: event,
        };
        await ReactGA.event(params);
    };
}

const rjAnalytics: RJAnalytics = new RJAnalytics();

export default rjAnalytics;
