// @flow

import type { AppState, ServerResponse, ProfileInfo, AppCfg } from '../commons/RJTypes';
import dataServer from '../store/Store';
import * as CONSTANTS from '../commons/Constants';
import { actionSetProfile } from '../userprofile/PFLAction';
import { Platform } from 'react-native';

export const getProfile = (state: AppState): ProfileInfo => state.profile;

export const getAvtar = (state: AppState): string => {
    return state.profile?.avtar ?? CONSTANTS.Default_Avtar;
};

export const getName = (state: AppState): string => {
    return state.profile?.name ?? CONSTANTS.Default_name;
};

const getUsrType = (state: AppState): string => {
    return state.profile?.usrtype ?? CONSTANTS.Default_userType;
};

export const getGUID = (state: AppState): string | null => {
    return state.profile?.guid ?? null;
};

export const getUUID = (state: AppState): string | null => {
    return state.profile?.uuid ?? null;
};

const getSocialPlatform = (state: AppState, platform): string | null => {
    //plf glbl will return null
    return state.profile?.[platform] ?? null;
};
