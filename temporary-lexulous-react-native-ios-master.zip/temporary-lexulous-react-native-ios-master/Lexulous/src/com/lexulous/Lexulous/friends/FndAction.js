// @flow

import type {
    GLBLFriendsAndFoes,
    ActionAddGLBLFriendsAndFoes,
    ActionGLBLFndRefreshStarted,
    ActionGLBLFndRefreshFinished,
    ActionGLBLFndClearData,
    ActionGLBLFndAdEvent,
    ActionMkFriend,
    ActionRmFriendReq,
    ActionInsertSentFndReq,
    ActionCancelSentFndReq,
    ActionCensorReq,
    ActionRmAddedFriendReq,
    ActionUncensorReq,
    ProfileInfo,
} from '../commons/RJTypes';

import {
    ADD_GLBL_FND_AND_FOES,
    GLBL_FND_REFRESH_STARTED,
    GLBL_FND_REFRESH_FINISHED,
    GLBL_FND_AD_EVT,
    CLR_GLBL_FND_DATA,
    MK_FRIEND,
    RM_FRIEND_REQ,
    INST_SENT_FND_REQ,
    CANCEL_SENT_FND_REQ,
    CENSOR_REQ,
    RM_ADDED_FRIEND_REQ,
    UNCENSOR_REQ,
} from './FndEventTypes';

export const actionAddGLBLFriendsAndFoes = (data: GLBLFriendsAndFoes): ActionAddGLBLFriendsAndFoes => {
    return {
        type: ADD_GLBL_FND_AND_FOES,
        payload: data,
    };
};

export const actionGLBLFndRefreshStarted = (): ActionGLBLFndRefreshStarted => {
    return {
        type: GLBL_FND_REFRESH_STARTED,
    };
};

export const actionGLBLFndRefreshFinished = (): ActionGLBLFndRefreshFinished => {
    return {
        type: GLBL_FND_REFRESH_FINISHED,
    };
};

export const actionGLBLFndClearData = (): ActionGLBLFndClearData => {
    return {
        type: CLR_GLBL_FND_DATA,
    };
};

export const actionGLBLFndAdEvent = (data: boolean): ActionGLBLFndAdEvent => {
    return {
        type: GLBL_FND_AD_EVT,
        payload: data,
    };
};

export const actionGLBLMkFriendEvent = (data: ProfileInfo): ActionMkFriend => {
    return {
        type: MK_FRIEND,
        payload: data,
    };
};

export const actionGLBLRmFriendReqEvent = (data: ProfileInfo): ActionRmFriendReq => {
    return {
        type: RM_FRIEND_REQ,
        payload: data,
    };
};

export const actionGLBLRmAddedFriendReqEvent = (data: ProfileInfo): ActionRmAddedFriendReq => {
    return {
        type: RM_ADDED_FRIEND_REQ,
        payload: data,
    };
};

export const actionGLBLInsertSentFriendRequest = (data: ProfileInfo): ActionInsertSentFndReq => {
    return {
        type: INST_SENT_FND_REQ,
        payload: data,
    };
};

export const actionGLBLCancelSentFriendRequest = (data: ProfileInfo): ActionCancelSentFndReq => {
    return {
        type: CANCEL_SENT_FND_REQ,
        payload: data,
    };
};

export const actionGLBLCensorEvent = (data: ProfileInfo): ActionCensorReq => {
    return {
        type: CENSOR_REQ,
        payload: data,
    };
};
export const actionGLBLUncensorEvent = (data: ProfileInfo): ActionUncensorReq => {
    return {
        type: UNCENSOR_REQ,
        payload: data,
    };
};
