// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { translate } from '../commons/translations/LangTransator';
import themeConfigutation from '../commons/ThemeConfiguration';

type UserNameContainerProps = {
    userName: string,
    btnTxt: string,
    btnAutoEnable: boolean,
    avoidKeyboard: boolean,
    editingFinishedHandler: (string) => void,
    editingCancledHandler: () => void,
};

type UserNameContainerState = {
    editedName: string,
    checkEditedName: boolean,
};

class UserNameContainer extends React.Component<UserNameContainerProps, UserNameContainerState> {
    constructor(props: UserNameContainerProps) {
        super(props);
        this.state = {
            editedName: this.props.userName,
            checkEditedName: false,
        };
    }

    setEditedName = (data: string) => {
        this.setState({ checkEditedName: false });
        this.setState({ editedName: data });
    };

    verifyUser = () => {
        if (this.state.editedName !== '') {
            this.props.editingFinishedHandler(this.state.editedName);
        } else {
            this.setState({ checkEditedName: true });
        }
    };

    btnDisabledOnSameName = (): boolean => {
        let isEnable: boolean = this.props.btnAutoEnable || this.props.userName !== this.state.editedName;
        let disabled: boolean = !isEnable; //Pressable takes disabled
        return disabled;
    };

    render() {
        if (Platform.OS === 'ios' || this.props.avoidKeyboard == true) {
            return this.renderOniOS();
        } else {
            return this.renderOthers();
        }
    }

    renderOthers() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.popupMainView,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.props.editingCancledHandler()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <View>
                        <Text style={(styles.labelText, { color: themeConfigutation.getColor('#000') })}>
                            {translate('type_ncNm_Title')}
                        </Text>
                        {this.state.checkEditedName ? (
                            <Text style={(styles.warningText, { color: themeConfigutation.getColor('#000') })}>
                                {translate('type_ncNm_ErrMsg')}
                            </Text>
                        ) : null}
                        <TextInput
                            style={[
                                styles.inputBoxStyle,
                                {
                                    borderColor: themeConfigutation.getColor('#5f6368'),
                                    backgroundColor: themeConfigutation.getColor('#e5e7e9'),
                                    color: themeConfigutation.getColor('#000'),
                                },
                            ]}
                            value={this.state.editedName}
                            autoCapitalize={'none'}
                            autoCorrect={false}
                            autoFocus={true}
                            onChangeText={(value) => this.setEditedName(value)}
                        />
                    </View>
                    <View style={styles.btnContainer}>
                        <Pressable
                            disabled={this.btnDisabledOnSameName()}
                            style={[
                                styles.buttonStyle,
                                {
                                    backgroundColor: this.btnDisabledOnSameName() ? '#a4d8f5' : '#1d9df1',
                                    borderColor: this.btnDisabledOnSameName() ? '#a4d8f5' : '#1d9df1',
                                },
                            ]}
                            onPress={this.verifyUser}
                        >
                            <Text style={styles.saveBtnText}>{this.props.btnTxt}</Text>
                        </Pressable>
                    </View>
                </View>
            </View>
        );
    }

    renderOniOS() {
        return (
            <View style={styles.popupView}>
                <KeyboardAvoidingView behavior="padding">
                    <View style={[styles.popupMainView, { backgroundColor: themeConfigutation.getColor('#fafafa') }]}>
                        <Pressable onPress={() => this.props.editingCancledHandler()} style={[styles.xBtnStyle]}>
                            <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                        </Pressable>
                        <View>
                            <Text style={[styles.labelText, { color: themeConfigutation.getColor('#000') }]}>
                                {translate('type_ncNm_Title')}
                            </Text>
                            {this.state.checkEditedName ? (
                                <Text style={styles.warningText}>{translate('type_ncNm_ErrMsg')}</Text>
                            ) : null}
                            <TextInput
                                style={[
                                    styles.inputBoxStyle,
                                    {
                                        borderColor: themeConfigutation.getColor('#5f6368'),
                                        color: themeConfigutation.getColor('#5f6368'),
                                    },
                                ]}
                                value={this.state.editedName}
                                placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                                autoCapitalize={'none'}
                                autoCorrect={false}
                                autoFocus={true}
                                onChangeText={(value) => this.setEditedName(value)}
                            />
                        </View>
                        <View style={styles.btnContainer}>
                            <Pressable
                                disabled={this.btnDisabledOnSameName()}
                                style={[
                                    styles.buttonStyle,
                                    {
                                        backgroundColor: this.btnDisabledOnSameName() ? '#a4d8f5' : '#1d9df1',
                                        borderColor: this.btnDisabledOnSameName() ? '#a4d8f5' : '#1d9df1',
                                    },
                                ]}
                                onPress={this.verifyUser}
                            >
                                <Text style={styles.saveBtnText}>{this.props.btnTxt}</Text>
                            </Pressable>
                        </View>
                    </View>
                </KeyboardAvoidingView>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        justifyContent: 'center',
    },
    popupMainView: {
        width: 250,
        alignSelf: 'center',
        justifyContent: 'center',
        borderRadius: 10,
        padding: 18,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    labelText: {
        marginTop: 12,
        marginBottom: 2,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    warningText: {
        textAlign: 'center',
        color: '#ff6347',
    },
    saveBtnText: {
        color: '#FFFFFF',
        textAlign: 'center',
        paddingLeft: 10,
        paddingRight: 10,
    },
    btnContainer: { flexDirection: 'row', justifyContent: 'center' },
    buttonStyle: {
        alignSelf: 'center',
        margin: 2,
        padding: 5,
        backgroundColor: '#0288D1',
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#0288D1',
    },
    xBtnStyle: {
        width: '100%',
        height: 25,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-end',
    },
    inputBoxStyle: {
        alignSelf: 'center',
        height: 40,
        width: 200,
        margin: 12,
        borderWidth: 1,
        padding: 10,
    },
});

export default UserNameContainer;
