import get from 'lodash/get';
import cloneDeep from 'lodash/cloneDeep';
import Config from '../configs/Config';
import {
    CONFIG_SET_MENU_VISIBILITY,
    CONFIG_SETTINGS_RETRIEVED,
    SET_SERVER_TIME_DIFFERENCE,
    CONFIG_SET_SETTING,
    CONFIG_SETTINGS_CHANGED,
    RELOAD_APP,
    DIMENSION_SCREEN_RESIZE,
    CONNECTIVITY_REDUCER_CONNECTION_LOST,
    CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
    CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
    CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE,
    CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
    CONNECTIVITY_REDUCER_RESTART_SERVER,
    GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
} from '../configs/ActionIdentifiers';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import log from 'loglevel';
import DimensionUtils from '../utils/DimensionUtils';

const INITIAL_STATE = {
    ...ConfigurationWrapper.getLexulousGeneralConfiguration(),
    isSettingsChanged: false,
    gp_chtfntsze: 10,
    lobby_game_update: false,
    show_lobby_chat: false,
    show_game_chat: true,
    isConnected: true,
};

const configReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case RELOAD_APP: {
            state = cloneDeep(state);
            state.isMenuVisible = false;
            break;
        }
        case SET_SERVER_TIME_DIFFERENCE:
            state = cloneDeep(state);
            log.info('ConfigReducer: ' + action.type);
            if (action.payload !== undefined) {
                state.serverTimeDifference = action.payload;
            }
            break;
        case CONFIG_SETTINGS_RETRIEVED: {
            state = cloneDeep(state);
            log.info('ConfigReducer: ' + action.type);
            state = {
                ...(state || Config.LIVE_DEFAULT_SETTINGS),
                ...action.payload,
            };
            state.autozoom =
                get(action.payload, 'us_gameplay.gp_autozoomboard') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_autozoomboard') === 'y'
                    : state.autozoom;
            state.numbered_plain =
                get(action.payload, 'us_gameplay.gp_numbrdboard') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_numbrdboard') === 'y'
                    : state.numbered_plain;
            state.tap_to_play =
                get(action.payload, 'us_gameplay.gp_magictiles') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_magictiles') === 'y'
                    : state.tap_to_play;
            state.sounds_enabled =
                get(action.payload, 'us_gameplay.gp_gamesounds') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_gamesounds') === 'y'
                    : state.sounds_enabled;
            state.scoregraph_enabled =
                get(action.payload, 'us_gameplay.gp_scoregraph') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_scoregraph') === 'y'
                    : state.scoregraph_enabled;
            state.theme =
                get(action.payload, 'us_gameplay.gp_gametheme') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_gametheme')
                    : state.theme;
            state.isDarkMode =
                get(action.payload, 'us_gameplay.gp_darktheme') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_darktheme') === 'y'
                    : state.isDarkMode;
            state.tooltip_enabled =
                get(action.payload, 'us_gameplay.gp_showtooltip') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_showtooltip') === 'y'
                    : state.tooltip_enabled;
            state.move_confirmation =
                get(action.payload, 'us_gameplay.gp_moveconfirmation') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_moveconfirmation') === 'y'
                    : state.move_confirmation;
            state.gp_chtfntsze =
                get(action.payload, 'us_gameplay.gp_chtfntsze') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_chtfntsze')
                    : state.gp_chtfntsze;
            if (state.gp_chtfntsze < 10) state.gp_chtfntsze = 10;
            state.lobby_game_update =
                get(action.payload, 'us_privacy.pvc_showlbygmupdt') !== undefined
                    ? get(action.payload, 'us_privacy.pvc_showlbygmupdt') === 'y'
                    : state.lobby_game_update;
            state.show_lobby_chat =
                get(action.payload, 'us_privacy.pvc_showlbycht') !== undefined
                    ? get(action.payload, 'us_privacy.pvc_showlbycht') === 'y'
                    : state.show_lobby_chat;
            state.show_game_chat =
                get(action.payload, 'us_privacy.pvc_disablechat') !== undefined
                    ? get(action.payload, 'us_privacy.pvc_disablechat') === 'n'
                    : state.show_game_chat;
            state.gp_brdcntrimg =
                get(action.payload, 'us_gameplay.gp_brdcntrimg') !== undefined
                    ? get(action.payload, 'us_gameplay.gp_brdcntrimg')
                    : state.gp_brdcntrimg;
            break;
        }
        case CONFIG_SET_MENU_VISIBILITY: {
            state = cloneDeep(state);
            log.info('ConfigReducer: ' + action.type);
            state.isMenuVisible = action.payload;
            break;
        }
        case CONFIG_SET_SETTING: {
            state = cloneDeep(state);
            log.info('ConfigReducer: ' + action.type);
            state = {
                ...state,
                ...(action.payload || {}),
            };
            break;
        }
        case CONFIG_SETTINGS_CHANGED: {
            state = cloneDeep(state);
            log.info('ConfigReducer: ' + action.type);
            state.isSettingsChanged = action.payload;
            break;
        }
        case CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY: {
            state.isConnected = get(action, 'payload.isConnected');
            break;
        }
        case CONNECTIVITY_REDUCER_CONNECTION_LOST: {
            log.info('ConfigReducer: ' + action.type);
            state = cloneDeep(state);
            state.connectionStatus = 'disconnected';
            state.showPleaseRefresh = get(action, 'payload.showPleaseRefresh');
            break;
        }
        case CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED: {
            log.info('ConfigReducer: ' + action.type);
            state.reconnectCount = 0;
            state.connectionStatus = 'connected';
            break;
        }

        case CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING: {
            log.info('ConfigReducer: ' + action.type);
            state.reconnectCount = (state.reconnectCount || 0) + 1;
            state.connectionStatus = 'connecting';
            break;
        }

        case CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE: {
            log.info('ConfigReducer: ' + action.type);
            state.connectionStatus = 'duplicate';
            break;
        }

        case CONNECTIVITY_REDUCER_RESTART_SERVER: {
            log.info('ConfigReducer: ' + action.type);
            state.connectionStatus = Config.ACTION_RESTART_SERVER;
            state.restartServer = get(action.payload, 'data.restrttstmp') * 1000 - Date.now();
            break;
        }

        case DIMENSION_SCREEN_RESIZE: {
            log.info('ConfigReducer: ' + action.type);
            state.isMobile = DimensionUtils.isMobile();
            break;
        }

        case GAME_SIDE_LAYOUT_ACTIVE_TAB_SET: {
            state = cloneDeep(state);
            state.isMenuVisible = false;
            break;
        }
    }
    return { ...state };
};

export default configReducer;
