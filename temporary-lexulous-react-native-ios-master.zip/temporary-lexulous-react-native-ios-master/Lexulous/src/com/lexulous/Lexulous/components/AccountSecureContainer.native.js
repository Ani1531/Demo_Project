// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { AppleButton } from '@invertase/react-native-apple-authentication';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faFacebookSquare, faGoogle } from '@fortawesome/free-brands-svg-icons';
import { faEnvelopeSquare } from '@fortawesome/free-solid-svg-icons';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import * as CONSTANTS from '../commons/Constants';
import { translate } from '../commons/translations/LangTransator';
import gglLgnMgr from '../commons/GGLgnMgr';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type SecureAccountProps = {
    fbLoginHandler: () => void,
    googleLoginHandler: () => void,
    lxlsLoginHandler: () => void,
    appleLoginHandler: () => void,
    closePopupHandler: () => void,
};

class AccountSecureContainer extends React.Component<SecureAccountProps> {
    renderGoogleButton = () => {
        if (gglLgnMgr.hasPlayServices()) {
            return (
                <Pressable
                    style={[styles.signinBtn, { marginTop: 20 }, styles.googleBtn]}
                    onPress={() => {
                        rjAnalytics.sendAnalyticsEvent('acc_secure_container_closed', 'account_secure_container');
                        this.props.googleLoginHandler();
                    }}
                >
                    <View style={[styles.iconContainer]}>
                        <FontAwesomeIcon icon={faGoogle} size={30} color={'#ffffff'} />
                    </View>
                    <Text style={[styles.signinBtnText]}>{translate('ggl')}</Text>
                </Pressable>
            );
        } else {
            return null;
        }
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.container,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('acc_secure_container_closed', 'account_secure_container');
                            this.props.closePopupHandler();
                        }}
                        style={[styles.xBtnStyle]}
                    >
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Pressable
                        style={[styles.signinBtn, styles.facebookBtn]}
                        onPress={() => {
                            this.props.fbLoginHandler();
                        }}
                    >
                        <View style={[styles.iconContainer]}>
                            <FontAwesomeIcon icon={faFacebookSquare} size={30} color={'#ffffff'} />
                        </View>
                        <Text style={[styles.signinBtnText]}>{translate('fb')}</Text>
                    </Pressable>
                    {this.renderGoogleButton()}
                    <Pressable
                        style={[styles.signinBtn, { marginTop: 20, marginBottom: 20 }, styles.LexBtn]}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('lexulous_login_btn_pressed', 'account_secure_container');
                            this.props.lxlsLoginHandler();
                        }}
                    >
                        <View style={[styles.iconContainer]}>
                            <FontAwesomeIcon icon={faEnvelopeSquare} size={33} color={'#ffffff'} />
                        </View>
                        <Text
                            style={[
                                styles.signinBtnText,
                                {
                                    paddingLeft: 26,
                                    alignSelf: 'center',
                                },
                            ]}
                        >
                            {translate('lex')}
                        </Text>
                    </Pressable>
                    {CONSTANTS.isAppleLoginSupported() ? (
                        <AppleButton
                            buttonStyle={AppleButton.Style.BLACK}
                            buttonType={AppleButton.Type.SIGN_IN}
                            style={[styles.signinBtn, { marginBottom: 20 }]}
                            onPress={() => this.props.appleLoginHandler()}
                        />
                    ) : null}
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        maxWidth: 320,
        maxHeight: 350,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    signinBtn: {
        width: 250,
        height: 45,
        flexDirection: 'row',
        alignSelf: 'center',
        justifyContent: 'flex-start',
        padding: 8,
        borderRadius: 5,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        marginHorizontal: 10,
    },
    facebookBtn: {
        backgroundColor: '#149AFF',
        borderWidth: 1,
        borderColor: '#149AFF',
    },
    googleBtn: {
        backgroundColor: '#E13834',
    },
    LexBtn: {
        backgroundColor: '#1d9df1',
        borderWidth: 1,
        borderColor: '#1d9df1',
    },
    iconContainer: {
        flexDirection: 'row',
        alignSelf: 'center',
        justifyContent: 'flex-start',
        paddingLeft: 15,
        paddingRight: 10,
    },
    signinBtnText: {
        color: '#ffffff',
        alignSelf: 'center',
        fontSize: 18,
        paddingLeft: 30,
        paddingRight: 10,
    },
});

export default AccountSecureContainer;
