import React from 'react';
import ReactTooltip from 'react-tooltip';
import { connect } from 'react-redux';
import DimensionUtils from '../utils/DimensionUtils';

class ReactCustomTooltip extends React.PureComponent {
    render = () =>
        !DimensionUtils.isMobile() && this.props.tooltipEnabled ? (
            <ReactTooltip
                id="appTooltip"
                place="bottom"
                className="customTooltip"
            />
        ) : null;
}
const mapStateToProps = (state) => ({
    tooltipEnabled: state.config.tooltip_enabled,
});

export default connect(mapStateToProps)(ReactCustomTooltip);
