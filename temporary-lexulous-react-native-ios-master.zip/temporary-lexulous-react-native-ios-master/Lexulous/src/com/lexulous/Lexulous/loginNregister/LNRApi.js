// @flow

import * as CONSTANTS from '../commons/Constants';
import { rjLog } from '../commons/RJUtils.js';
import type { LNRResponse, LXLSForgotPasswordResponse } from '../commons/RJTypes';
import type { AxiosPromise } from 'axios';
import requestManager from '../commons/RequestManager';
const qs = require('qs');

class LNRApi {
    constructor() {}

    doRegisterUser = (
        email: string,
        authuser: string,
        authsecret: string,
        pin: string = '',
        xpass: string = 'a'
    ): AxiosPromise<LNRResponse> => {
        let reqdata = {
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kAuthUser]: authuser,
            [CONSTANTS.kAuthSecret]: authsecret,
            [CONSTANTS.kParamEmail]: email,
            [CONSTANTS.kPin]: pin,
            xpass: 'a',
        };

        let params = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(reqdata) });

        rjLog(params, 'register');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmUrl + 'register?ver=IPH_4_0',
            data: params,
        });
    };

    doLogin = (authuser: string, authsecret: string, pin: string = ''): AxiosPromise<LNRResponse> => {
        let reqdata = {
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kAuthUser]: authuser,
            [CONSTANTS.kAuthSecret]: authsecret,
            [CONSTANTS.kPin]: pin,
        };

        let params = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(reqdata) });

        rjLog(params, 'login');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmUrl + 'login?ver=IPH_4_0',
            data: params,
        });
    };

    doSimpleAuthEmailOrName = (email: string): AxiosPromise<LNRResponse> => {
        let reqdata = {
            [CONSTANTS.kParamDevice]: CONSTANTS.getOSPlatformString(),
            [CONSTANTS.kParamEmail]: email,
        };

        let params = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(reqdata) });

        rjLog(params, 'getdeviceuser');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kEmailBaseUrl + CONSTANTS.kDeviceLXLSPath + 'getdeviceuser?ver=IPH_4_0',
            data: params,
        });
    };

    doCheckNameAvailability = (username: string): AxiosPromise<string> => {
        let reqdata = {
            valid: 'REG',
            uname: username,
        };
        let params = qs.stringify(reqdata);
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmNameAvailability + params,
            responseType: 'text',
            transitional: { forcedJSONParsing: false },
            data: params,
        });
    };

    // getArchivedGamesList = () => {
    //     let currenttime = Math.floor(Date.now() / 1000);
    //     let epochtime = currenttime - 90 * 24 * 60 * 60;

    //     let sguid = PFLSelector.getGUID(GLApi.store.getState());
    //     let suuid = PFLSelector.getUUID(GLApi.store.getState());

    //     let reqdata = {
    //         [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
    //         [CONSTANTS.kParamGuid]: sguid,
    //         [CONSTANTS.kParamUuid]: suuid,
    //         epoch: epochtime.toString(),
    //         currenttime: currenttime.toString(),
    //         skip: '0',
    //         limit: '3',
    //     };

    //     let action = { [CONSTANTS.kParamAction]: 'archivegameslist' };
    //     let mdata = { ...action, ...reqdata };
    //     let params = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

    //     let pp = { body: params };
    //     let requestOptions = { ...CONSTANTS.kRequestOptions, ...pp };
    //     rjLog(requestOptions, 'getArchivedGamesList');
    //     return fetch(CONSTANTS.kBaseUrl + CONSTANTS.kArchiveGamesListApiPath, requestOptions);
    // };

    doForgotPassword = (username: string): AxiosPromise<LXLSForgotPasswordResponse> => {
        let reqdata = {
            [CONSTANTS.kUserEntry]: username,
        };
        let params = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(reqdata) });
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmUrl + 'forgotpassword?ver=IPH_4_0',
            data: params,
        });
    };
}

const lnrApi: LNRApi = new LNRApi();
export default lnrApi;
