import LiveGameChat from './LiveGameChat';
import React, { Fragment } from 'react';
import ResourcesPanel from './ResourcesPanel';
import TabPanel from './TabPanel';
import { StyleSheet, Text, TouchableOpacity, ScrollView, View } from 'react-native';
import Config from '../configs/Config';
import LiveGameTimerScoreCard from './LiveGameTimer';
import GameSettingsMenu from './GameSettingsMenu';
import ColorConfig from '../configs/ColorConfig';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCog, faTimes, faCommentAlt, faBook, faTools } from '@fortawesome/free-solid-svg-icons';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import LastMoveDefinitionPanel from './LastMoveDefinitionPanel';
import GameBoardUtils, { getDictionaryDetails, setSidePanelTabWidthHeight } from '../utils/GameBoardUtils';
import GameNotesPanel from './GameNotesPanel';
import HintSection from './HintSection';
import ScoreToBeatPanel from './ScoreToBeatPanel';
import RatingPanel from './RatingPanel';
import PlayerLastGamesStatusBar from './PlayerLastGamesStatusBar';
import { isEmailGame, isLiveGame, isSoloGame, getGameType, isPuzzleGame } from '../service/GamePlayService';
import debounce from 'lodash/debounce';
import MoveScoreGraphPanel from './MoveScoreGraphPanel';
import StandardButton from './StandardButton';
import GameObserverCount from './GameObserverCount';
import { connect } from 'react-redux';
import {
    CONFIG_SET_MENU_VISIBILITY,
    GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
    CONFIG_SETTINGS_CHANGED,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import SettingsUtil from '../utils/SettingsUtil';
import log from 'loglevel';
import GameHistory from './GameHistory';
import ReactResizeDetector from 'react-resize-detector';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';
import Standings from './Standings';
import TooltipWrapper from './TooltipWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

class GameBoardSideLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value: isPuzzleGame() ? 1 : 0,
            key: Math.random(),
            marginLeft: 0,
            gid: this.props.game.gid,
            dic: this.props.game.dic,
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: isPuzzleGame()
                ? ColorConfig.TOOL_CHAT_TAB_TEXT_HOVER_COLOR
                : ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            chatTabCursor: 'default',
            dictionaryTabCursor: 'pointer',
            gameTabCursor: 'pointer',
            settingTabCursor: 'pointer',
            toolsTabCursor: isPuzzleGame() ? 'default' : 'pointer',
            isOpen: false,
        };
        this.hintSectionContainer = React.createRef();
    }

    componentDidMount() {
        eventBus.on(Config.FOCUS_TEXTFIELD_IN_CHAT, this.focusTextFieldInChat);
        eventBus.on(Config.FOCUS_NOTES_IN_TOOLS, this.focusNotesFieldInTools);
    }

    componentWillUnmount() {
        eventBus.detach(Config.FOCUS_TEXTFIELD_IN_CHAT, this.focusTextFieldInChat);

        eventBus.detach(Config.FOCUS_NOTES_IN_TOOLS, this.focusNotesFieldInTools);
    }

    componentDidUpdate(prevProps, prevState) {
        let previouslyActiveTab = prevProps.game.gameBoardSideLayoutActiveTab;
        if (previouslyActiveTab === 3 && this.getCurrentTab() !== previouslyActiveTab) {
            this.saveSettingsData();
        }
        if (!isEqual(this.props.chat.messages, prevProps.chat.messages) && this.getCurrentTab() !== 0) {
            this.setState({
                chatTabTxtColor: ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
            });
        }
    }

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(nextProps, this.props) || !isEqual(nextState, this.state);

    focusTextFieldInChat = () => {
        this.handleTabChange(0);
    };

    focusSearchFieldInDictionary = () => {
        this.handleTabChange({ fromClick: true, value: 1 });
    };

    focusNotesFieldInTools = () => {
        this.handleTabChange(2);
    };

    onStartAnalyse = () => {
        if (DimensionUtils.isMobile()) {
            this.setState({ lastRendered: Date.now() });
        } else {
            this.handleTabChange(2);
            this.hintSectionContainer.current.setVisibility(true);
        }
    };

    onCloseMenuPopover = () => eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);

    onMenuMouseOut = debounce(() => {
        if (!this.isMenuVisible()) {
            this.onCloseMenuPopover();
        }
    }, 100);

    handleChange = (event, value) => eventBus.emit(GAME_SIDE_LAYOUT_ACTIVE_TAB_SET, null, value);

    handleTabChange = (value) => {
        eventBus.emit(GAME_SIDE_LAYOUT_ACTIVE_TAB_SET, null, value);
    };

    getHeading = () => {
        switch (getGameType()) {
            case Config.GAME_TYPE_EMAIL:
            case Config.GAME_TYPE_LIVE_GAME:
            case Config.GAME_TYPE_BLITZ:
            case Config.GAME_TYPE_PUZZLE:
                let gid = (this.props.game.game_type === 'puzzle' ? this.props.game.puzzle_id : this.props.game.gid)
                    ? '#' + (this.props.game.game_type === 'puzzle' ? this.props.game.puzzle_id : this.props.game.gid)
                    : '';
                let dic = this.props.game.dic ? ', ' + getDictionaryDetails(this.props.game.dic).abreviations : '';
                let time =
                    this.props.game.game_type === Config.GAME_TYPE_LIVE_GAME
                        ? ', ' +
                          Math.floor(Number(get(this.props.game, 'duration')) / 60) +
                          '/' +
                          get(this.props.game, 'increament')
                        : '';
                let heading =
                    (isPuzzleGame() ? 'Puzzle ' : this.props.game.game_type === Config.GAME_TYPE_BLITZ ? 'Blitz ' : 'Game ') +
                    gid +
                    dic +
                    time;
                return heading;
            case Config.GAME_TYPE_SOLO:
                return 'Practice Mode';
            default:
                return '';
        }
    };

    render = () => (DimensionUtils.isNative() ? null : this.renderNormal());
    /* this.props.config.isMobile ? this.renderMobile() : */

    onGameButtonCustomPopOverPressOutside = () => {
        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);
    };

    onChatTabPress = (event) => this.handleChange(event, 0);

    onDictionaryTabPress = (event) => {
        this.handleChange(event, 1);
    };

    onGameTabPress = (event) => this.handleChange(event, 2);

    onGraphTabPress = (event) => this.handleChange(event, 3);

    onDefinitionTabPress = (event) => this.handleChange(event, 4);

    onNotesTabPress = (event) => this.handleChange(event, 5);

    onAnalyzeTabPress = (event) => this.handleChange(event, 6);

    getTabPanelDimension = (type) => ({
        height: type === 'dictionary' ? '52%' : '38%',
        width: '100%',
    });

    getTabContainerPaddingStyle = () => ({
        paddingVertical: DimensionUtils.isMobile() ? 2 : 'clamp(2px, 1.6%, 6px)',
        paddingHorizontal: DimensionUtils.isMobile() ? 8 : 'clamp(8px, 3%, 16px)',
    });

    toggle = () => this.setState({ isOpen: !this.state.isOpen });

    close = () => this.setState({ isOpen: false });

    open = () => this.setState({ isOpen: true });

    onGameButtonHoverIn = () => {
        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, true);
    };

    onGameButtonHoverOut = () => {
        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);
    };

    saveSettingsData = async () => {
        let obj = {};
        let us_gameplay = this.props.config.us_gameplay;

        let theme = this.props.config.theme;
        let sounds_enabled = this.props.config.sounds_enabled ? 'y' : 'n';
        let numbered_plain = this.props.config.numbered_plain ? 'y' : 'n';
        let tap_to_play = this.props.config.tap_to_play ? 'y' : 'n';
        let autozoom = this.props.config.autozoom ? 'y' : 'n';
        let move_confirmation = this.props.config.move_confirmation ? 'y' : 'n';
        let tooltip_enabled = this.props.config.tooltip_enabled ? 'y' : 'n';

        if (us_gameplay.gp_gametheme !== theme) {
            obj.theme = this.props.config.theme;
        }
        if (us_gameplay.gp_gamesounds !== sounds_enabled) {
            obj.sounds_enabled = this.props.config.sounds_enabled;
        }
        if (us_gameplay.gp_numbrdboard !== numbered_plain) {
            obj.numbered_plain = this.props.config.numbered_plain;
        }
        if (us_gameplay.gp_magictiles !== tap_to_play) {
            obj.tap_to_play = this.props.config.tap_to_play;
        }
        if (us_gameplay.gp_autozoomboard !== autozoom) {
            obj.autozoom = this.props.config.autozoom;
        }
        if (us_gameplay.gp_moveconfirmation !== move_confirmation) {
            obj.move_confirmation = this.props.config.move_confirmation;
        }
        if (us_gameplay.gp_showtooltip !== tooltip_enabled) {
            obj.tooltip_enabled = this.props.config.tooltip_enabled;
        }
        if (us_gameplay.gp_brdcntrimg !== this.props.config.gp_brdcntrimg) {
            obj.gp_brdcntrimg = this.props.config.gp_brdcntrimg;
        }

        let keys = Object.keys(obj);
        if (keys.length > 0) {
            let data = {
                theme: this.props.config.theme,
                sounds_enabled: this.props.config.sounds_enabled,
                numbered_plain: this.props.config.numbered_plain,
                tap_to_play: this.props.config.tap_to_play,
                autozoom: this.props.config.autozoom,
                move_confirmation: this.props.config.move_confirmation,
                tooltip_enabled: this.props.config.tooltip_enabled,
                gp_brdcntrimg: this.props.config.gp_brdcntrimg,
            };
            await SettingsUtil.sendSetting(data);
        }
        eventBus.emit(CONFIG_SETTINGS_CHANGED, null, false);
    };

    onChatPress = () => {
        this.handleTabChange({ fromClick: true, value: 0 });
        this.setState({
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabCursor: 'pointer',
            chatTabCursor: 'default',
            dictionaryTabCursor: 'pointer',
            gameTabCursor: 'pointer',
            settingTabCursor: 'pointer',
        });
    };

    onGamePress = () => {
        this.handleTabChange({ fromClick: true, value: 4 });
        this.setState({
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabCursor: 'pointer',
            chatTabCursor: 'pointer',
            dictionaryTabCursor: 'pointer',
            gameTabCursor: 'default',
            settingTabCursor: 'pointer',
        });
    };

    onDictionaryPress = () => {
        this.focusSearchFieldInDictionary();
        this.setState({
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabCursor: 'pointer',
            dictionaryTabCursor: 'default',
            chatTabCursor: 'pointer',
            gameTabCursor: 'pointer',
            settingTabCursor: 'pointer',
        });
    };

    onGameOrToolsPress = () => {
        this.handleTabChange({ fromClick: true, value: 2 });
        this.setState({
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabCursor: 'default',
            dictionaryTabCursor: 'pointer',
            chatTabCursor: 'pointer',
            gameTabCursor: 'pointer',
            settingTabCursor: 'pointer',
        });
    };

    onSettingsPress = () => {
        this.handleTabChange({ fromClick: true, value: 3 });
        this.setState({
            chatTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            dictionaryTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            gameTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            settingsTabTxtColor: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
            toolsTabCursor: 'pointer',
            dictionaryTabCursor: 'pointer',
            chatTabCursor: 'pointer',
            gameTabCursor: 'pointer',
            settingTabCursor: 'default',
        });
    };

    getAllTabTotalWidthAndFlexDirection = () => ({
        width: '100%',
        flexDirection: isPuzzleGame() && !DimensionUtils.isMobile() ? 'row-reverse' : 'row',
    });

    getChatTabBackgroundColorAndCursor = () => ({
        backgroundColor: this.getCurrentTab() === 0 ? ColorConfig.TAB_SELECTED_COLOR : undefined,
        cursor: this.getCurrentTab() === 0 ? 'default' : 'pointer',
    });

    getGameTabBackgroundColorAndCursor = () => ({
        backgroundColor:
            (DimensionUtils.isMobile() && isPuzzleGame() && this.getCurrentTab() === 2) || this.getCurrentTab() === 4
                ? ColorConfig.TAB_SELECTED_COLOR
                : undefined,
        cursor: this.state.gameTabCursor,
    });

    getChatTabTextStyle = () => {
        let obj = { color: this.state.chatTabTxtColor };
        if (this.state.chatTabTxtColor === ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR) {
            obj.fontWeight = 'bold';
        }
        return obj;
    };

    getGameTabTextStyle = () => {
        let obj = {
            color: this.state.gameTabTxtColor,
            ...(DimensionUtils.isMobile() ? { fontSize: 13 } : {}),
        };
        if (this.state.gameTabTxtColor === ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR) {
            obj.fontWeight = 'bold';
        }
        return obj;
    };

    getDictionaryTabBackgroundColorAndCursor = () => ({
        backgroundColor: this.getCurrentTab() === 1 ? ColorConfig.TAB_SELECTED_COLOR : undefined,
        cursor: this.getCurrentTab() === 1 ? 'default' : 'pointer',
    });

    getDictionaryTabTextColor = () => ({
        color: this.state.dictionaryTabTxtColor,
    });

    getToolsTabBackgroundColorAndCursor = () => ({
        backgroundColor: this.getCurrentTab() === 2 ? ColorConfig.TAB_SELECTED_COLOR : undefined,
        cursor: this.getCurrentTab() === 2 ? 'default' : 'pointer',
    });

    getSettingsTabBackgroundColorAndCursor = () => ({
        backgroundColor: this.getCurrentTab() === 3 ? ColorConfig.TAB_SELECTED_COLOR : undefined,
        cursor: this.getCurrentTab() === 3 ? 'default' : 'pointer',
    });

    getToolsTabTextColor = () => ({ color: this.state.toolsTabTxtColor });

    getSettingsTabTextStyle = () => ({ color: this.state.settingsTabTxtColor });

    getHistorySectionHeight = () => ({
        height: LiveGamePlayUtils.isGameHistoryAvailable() ? get(this.props, 'layout.layoutCellDimen', 0) * 3 : 0,
    });

    getCurrentTab = () =>
        GameBoardUtils.isMenuAtTheBottom() && this.isMenuVisible()
            ? 3
            : this.props.game.gameBoardSideLayoutActiveTab || (this.isChatTabEnable() ? 0 : 1);

    toggleGameMenu = () => {
        let isMenuVisible = !this.isMenuVisible();
        let isSettingsChanged = this.props.config.isSettingsChanged;

        eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, isMenuVisible);

        log.info('isMenuVisible: ' + JSON.stringify(isMenuVisible));
        log.info('isSettingsChanged: ' + JSON.stringify(isSettingsChanged));

        if (!isMenuVisible && isSettingsChanged) {
            log.info('save settings called');
            this.saveSettingsData();
        }
    };

    getPlayerLastGamesStatusBarDimension = ({ extraMarignHeight } = {}) => {
        return {
            height: get(this.props, 'layout.boardWidthDimen') * 0.12 - (extraMarignHeight || 0),
            width: '100%',
        };
    };

    tabOnResize = (width, height) => {
        setSidePanelTabWidthHeight(width, height);
    };

    onMenuClose = () => eventBus.emit(Config.SET_SHOW_SIDE_MENU, null, false);

    isMenuVisible = () => this.props.config.isMenuVisible || this.props.game.gameBoardSideLayoutActiveTab === 3;

    renderSideMenuHeader = () => (
        <TouchableOpacity
            variant="contained"
            activeOpacity={1}
            style={[styles.w100, styles.gameButtonTouchableStyle]}
            onPress={this.toggleGameMenu}
        >
            <TouchableOpacity activeOpacity={1} style={{ flexDirection: Config.ROW }} onPress={this.toggleGameMenu}>
                <TooltipWrapper tooltip={this.isMenuVisible() ? '' : 'Click for menu'} onPress={this.toggleGameMenu}>
                    <S14Text style={[styles.titleBarHeadingTextStyle]}>
                        {this.isMenuVisible() ? 'Close' : this.getHeading()}
                    </S14Text>
                </TooltipWrapper>
                {this.isMenuVisible() ? null : <GameObserverCount />}
            </TouchableOpacity>
            <TooltipWrapper tooltip={this.isMenuVisible() ? '' : 'Click for menu'} onPress={this.toggleGameMenu}>
                <FontAwesomeIcon icon={this.isMenuVisible() ? faTimes : faCog} size={14} style={this.getIconStyleObj()} />
            </TooltipWrapper>
        </TouchableOpacity>
    );

    renderLastGameHistory = () => (
        <View>
            {LiveGamePlayUtils.isGameHistoryAvailable() && [
                <View style={[styles.historySectionWrappingBorderStyle, this.getHistorySectionHeight()]}>
                    <GameHistory height={this.getHistorySectionHeight()} />
                </View>,
                <View style={styles.seperationLineStyle} />,
            ]}
        </View>
    );

    renderLiveGameTimerScorecard = () => (
        <LiveGameTimerScoreCard
            id={'timer_score_card'}
            key={'timer_score_card'}
            isInSideMenu
            emailGame={(isSoloGame() && !!get(this.props, 'game.player.0.timeleft') === '-1') || isEmailGame()}
            isAtBottom={GameBoardUtils.isMenuAtTheBottom()}
            playersDataOnly
            width={'100%'}
        />
    );

    renderTabs = () => (
        <Fragment>
            {GameBoardUtils.isMenuAtTheBottom() ? (
                <StandardButton
                    style={[styles.tabContainer, this.getTabContainerPaddingStyle(), this.getGameTabBackgroundColorAndCursor()]}
                    onPress={DimensionUtils.isMobile() && isPuzzleGame() ? this.onGameOrToolsPress : this.onGamePress}
                    text={this.getHeading()}
                    textStyle={this.getGameTabTextStyle()}
                />
            ) : null}

            {this.isChatTabEnable() ? (
                <StandardButton
                    style={[styles.tabContainer, this.getTabContainerPaddingStyle(), this.getChatTabBackgroundColorAndCursor()]}
                    onPress={this.onChatPress}
                    text={DimensionUtils.isMobile() ? undefined : 'Chat'}
                    textStyle={this.getChatTabTextStyle()}
                >
                    {DimensionUtils.isMobile() ? (
                        <FontAwesomeIcon icon={faCommentAlt} style={this.getChatTabTextStyle()} />
                    ) : undefined}
                </StandardButton>
            ) : null}
            {this.isDictionaryTabEnabled() ? (
                <StandardButton
                    style={[
                        styles.tabContainer,
                        this.getTabContainerPaddingStyle(),
                        this.getDictionaryTabBackgroundColorAndCursor(),
                    ]}
                    onPress={this.onDictionaryPress}
                    text={DimensionUtils.isMobile() ? undefined : 'Dictionary'}
                    textStyle={this.getDictionaryTabTextColor()}
                >
                    {DimensionUtils.isMobile() ? (
                        <FontAwesomeIcon icon={faBook} style={this.getChatTabTextStyle()} />
                    ) : undefined}
                </StandardButton>
            ) : null}

            {DimensionUtils.isMobile() && isPuzzleGame() ? null : (
                <StandardButton
                    style={[
                        styles.tabContainer,
                        this.getTabContainerPaddingStyle(),
                        this.getToolsTabBackgroundColorAndCursor(),
                    ]}
                    onPress={this.onGameOrToolsPress}
                    text={
                        DimensionUtils.isMobile()
                            ? undefined
                            : this.props.game.game_type === Config.GAME_TYPE_BLITZ
                            ? 'Standings'
                            : 'Tools'
                    }
                    textStyle={this.getToolsTabTextColor()}
                >
                    {DimensionUtils.isMobile() ? (
                        <FontAwesomeIcon icon={faTools} style={this.getChatTabTextStyle()} />
                    ) : undefined}
                </StandardButton>
            )}
            {GameBoardUtils.isMenuAtTheBottom() ? (
                <StandardButton
                    style={[
                        styles.tabContainer,
                        this.getTabContainerPaddingStyle(),
                        this.getSettingsTabBackgroundColorAndCursor(),
                    ]}
                    onPress={this.onSettingsPress}
                    text={DimensionUtils.isMobile() ? undefined : 'Settings'}
                    textStyle={this.getSettingsTabTextStyle()}
                >
                    {DimensionUtils.isMobile() ? (
                        <FontAwesomeIcon icon={faCog} style={this.getChatTabTextStyle()} />
                    ) : undefined}
                </StandardButton>
            ) : null}
        </Fragment>
    );

    getTabBarHeight = () => 35;

    renderNormal = () => (
        <View
            style={[
                styles.sidePanelStyle,
                GameBoardUtils.isMenuAtTheBottom()
                    ? styles.puzzleSidePanelMobileScrollContainer
                    : styles.puzzleSidePanelScrollContainer,
                {
                    width: GameBoardUtils.isMenuAtTheBottom()
                        ? get(this.props, 'layout.boardDimen')
                        : get(this.props, 'layout.layoutSidePanelWidth'),
                    height: GameBoardUtils.isMenuAtTheBottom()
                        ? DimensionUtils.getWindowDimensions({
                              divDimensOnly: true,
                          }).height /
                              2 +
                          (DimensionUtils.getWindowDimensions({
                              divDimensOnly: true,
                          }).height /
                              2 -
                              Math.max(
                                  0,
                                  this.props.layout.layoutBoardAboveViewsHeight +
                                      this.props.layout.boardWidth +
                                      (DimensionUtils.isMobile() ? 3.5 : 1.5) * this.props.layout.layoutCellDimen
                              ))
                        : get(this.props, 'layout.layoutTileBoardRackHeight'),
                },
            ]}
        >
            {GameBoardUtils.isMenuAtTheBottom() ? null : this.renderSideMenuHeader()}

            <View style={[styles.flex1]}>
                {isPuzzleGame() || GameBoardUtils.isMenuAtTheBottom() ? null : this.renderLiveGameTimerScorecard()}
                <View style={[this.getTabLayoutStyle()]}>
                    {DimensionUtils.isMobile() ? (
                        <View
                            style={[
                                GameBoardUtils.isMenuAtTheBottom()
                                    ? {
                                          borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
                                          borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
                                      }
                                    : null,
                                {
                                    height: this.getTabBarHeight(),
                                    overflow: 'hidden',
                                    backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
                                },
                            ]}
                        >
                            <ScrollView
                                horizontal={true}
                                style={[
                                    {
                                        flex: 1,
                                    },
                                ]}
                                contentContainerStyle={[
                                    styles.allTabInnerViewScrollView,
                                    this.getAllTabTotalWidthAndFlexDirection(),
                                ]}
                            >
                                {this.renderTabs()}
                            </ScrollView>
                        </View>
                    ) : (
                        <View
                            key={this.state.key + 3}
                            style={[
                                styles.allTabInnerView,
                                this.getAllTabTotalWidthAndFlexDirection(),
                                GameBoardUtils.isMenuAtTheBottom()
                                    ? {
                                          borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
                                          borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
                                      }
                                    : null,
                                {
                                    height: this.getTabLayoutStyle().height,
                                    backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
                                },
                            ]}
                        >
                            {this.renderTabs()}
                        </View>
                    )}
                    <View style={[styles.flex1]}>
                        {this.isChatTabEnable() ? (
                            <TabPanel value={this.getCurrentTab()} style={{ flex: 1 }} index={0}>
                                <LiveGameChat
                                    ref={this.liveGameChat}
                                    width={
                                        GameBoardUtils.isMenuAtTheBottom()
                                            ? get(this.props, 'layout.boardDimen')
                                            : get(this.props, 'layout.layoutSidePanelWidth')
                                    }
                                />
                            </TabPanel>
                        ) : null}
                        <TabPanel
                            value={this.getCurrentTab()}
                            index={1}
                            style={[isPuzzleGame() ? [styles.additionalStylesForLiveGame] : null, { flex: 1 }]}
                        >
                            {!GameBoardUtils.isChallengeMode() ? (
                                <View style={{ flex: 1 }}>
                                    <ResourcesPanel id={'dictionaryPanel'} key={'dictionaryPanel'} />
                                    {isPuzzleGame() ? null : (
                                        <View style={styles.lastMoveDefinition}>
                                            <LastMoveDefinitionPanel
                                                id={'last_move_definition_panel'}
                                                key={'last_move_definition_panel'}
                                            />
                                        </View>
                                    )}
                                </View>
                            ) : (
                                <View style={[styles.gameBoardStyleAtUnchallengedMode]} />
                            )}
                        </TabPanel>
                        <TabPanel
                            value={this.getCurrentTab()}
                            index={2}
                            style={[
                                !isEmailGame() ? styles.additionalStylesForLiveGame : { flex: 1 },
                                isSoloGame() ? styles.additionalTabPanelStyleForSoloGame : null,
                                isLiveGame() || isPuzzleGame() ? { flex: 1 } : null,
                            ]}
                        >
                            {isPuzzleGame() ? (
                                <View style={{ width: '100%' }}>
                                    <ScoreToBeatPanel id={'scoreToBeatPanel'} key={'scoreToBeatPanel'} />
                                    <RatingPanel id={'ratingPanel'} key={'ratingPanel'} />
                                    <PlayerLastGamesStatusBar
                                        panelDimension={this.getPlayerLastGamesStatusBarDimension({
                                            extraMarignWidth: this.state.marginLeft,
                                        })}
                                        id={'playerLastGamesStatusBar'}
                                        key={'playerLastGamesStatusBar'}
                                    />
                                </View>
                            ) : (
                                <ReactResizeDetector handleHeight handleWidth onResize={this.tabOnResize}>
                                    <View
                                        style={[styles.flex1]}
                                        onLayout={(event) => {
                                            LayoutWrapper.setSidePanelTabWidthHeight(
                                                event.nativeEvent.layout.width,
                                                event.nativeEvent.layout.height
                                            );
                                        }}
                                    >
                                        {this.props.game.game_type === Config.GAME_TYPE_BLITZ && [
                                            <View
                                                style={[
                                                    styles.w100,
                                                    {
                                                        height: get(this.props, 'layout.tabHeight', 0) / 2,
                                                    },
                                                ]}
                                            >
                                                <Standings />
                                            </View>,
                                            <View style={styles.seperationLineStyle} />,
                                        ]}
                                        <View
                                            style={[
                                                styles.w100,
                                                {
                                                    height: get(this.props, 'layout.tabHeight', 0) / 2,
                                                },
                                                this.getGraphPnaelBorderStyle(),
                                            ]}
                                        >
                                            <MoveScoreGraphPanel
                                                width={'100%'}
                                                id={'move_score_graph'}
                                                key={'move_score_graph'}
                                            />
                                        </View>
                                        {this.props.game.game_type !== Config.GAME_TYPE_BLITZ && (
                                            <View style={styles.seperationLineStyle} />
                                        )}
                                        {!GameBoardUtils.isMenuAtTheBottom() ? this.renderLastGameHistory() : null}
                                        {isEmailGame() && !this.props.game.showingAnalyseMove ? (
                                            <View
                                                style={[
                                                    styles.w100,
                                                    {
                                                        height:
                                                            get(this.props, 'layout.tabHeight', 0) / 2 -
                                                            2 * StyleSheet.hairlineWidth -
                                                            (GameBoardUtils.isMenuAtTheBottom()
                                                                ? 0
                                                                : this.getHistorySectionHeight().height),
                                                    },
                                                ]}
                                            >
                                                <GameNotesPanel
                                                    ref={this.gameNotesPanel}
                                                    bottomCornerStyle={this.getNotesBottomCornerStyleObj}
                                                />
                                            </View>
                                        ) : this.props.game.showingAnalyseMove || isSoloGame() ? (
                                            <View
                                                ref={this.hintSectionContainer}
                                                style={[
                                                    styles.w100,
                                                    {
                                                        height: get(this.props, 'layout.tabHeight', 0) / 2,
                                                    },
                                                ]}
                                            >
                                                <HintSection forSoloGameHintSection={isSoloGame()} />
                                            </View>
                                        ) : (
                                            <View
                                                style={[
                                                    styles.w100,
                                                    {
                                                        height: get(this.props, 'layout.tabHeight', 0) / 2,
                                                    },
                                                ]}
                                            />
                                        )}
                                    </View>
                                </ReactResizeDetector>
                            )}
                        </TabPanel>
                        <TabPanel
                            value={this.getCurrentTab()}
                            style={[{ flex: 1 }, styles.additionalStylesForLiveGame]}
                            index={3}
                        >
                            <GameSettingsMenu />
                        </TabPanel>
                        <TabPanel
                            value={this.getCurrentTab()}
                            style={[{ flex: 1 }, styles.additionalStylesForLiveGame]}
                            index={4}
                        >
                            <Fragment>
                                {this.renderLiveGameTimerScorecard()}
                                {this.renderLastGameHistory()}
                            </Fragment>
                        </TabPanel>
                    </View>
                </View>
                {this.isMenuVisible() && !GameBoardUtils.isMenuAtTheBottom() ? (
                    <View style={styles.menuContainer}>
                        <GameSettingsMenu />
                    </View>
                ) : null}
            </View>
        </View>
    );

    getTabLayoutStyle = () => ({
        flex: 1,
        width: '100%',
    });

    getGameBoardDimensionsAtUnchallengedMode = () => ({
        height: '100%',
        width: '100%',
    });

    getMoveScoreStyleObj = () => ({
        flex: isEmailGame() && !this.props.game.showingAnalyseMove ? 0.5 : undefined,
    });

    getMoveScoreBottomCornerStyleObj = () => ({
        borderBottomLeftRadius: isLiveGame() && !this.props.game.showingAnalyseMove ? 5 : null,
        borderBottomRightRadius: isLiveGame() && !this.props.game.showingAnalyseMove ? 5 : null,
    });

    getNoteViewStyleObj = () => ({
        flex: !this.props.game.showingAnalyseMove && !isSoloGame() ? 1 : 0.5,
        marginTop: Config.HEADER_CONTAINER_PADDING,
    });

    getNotesBottomCornerStyleObj = () => ({
        borderBottomLeftRadius: !this.props.game.showingAnalyseMove && !isSoloGame() ? 5 : null,
        borderBottomRightRadius: !this.props.game.showingAnalyseMove && !isSoloGame() ? 5 : null,
    });

    getIconStyleObj = () => ({
        fontSize: 14,
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
    });

    isChatTabEnable = () =>
        !LiveGamePlayUtils.isObserving() &&
        !isSoloGame() &&
        !isPuzzleGame() &&
        this.props.game.game_type !== Config.GAME_TYPE_BLITZ &&
        !get(this.props, 'game.archiveGameView');

    isDictionaryTabEnabled = () => !GameBoardUtils.isChallengeMode();

    getGraphPnaelBorderStyle = () => ({
        borderLeftWidth: isEmailGame() ? StyleSheet.hairlineWidth : null,
        borderLeftColor: isEmailGame() ? ColorConfig.SIDE_PANEL_BORDER_COLOR : null,
        borderRightWidth: isEmailGame() ? StyleSheet.hairlineWidth : null,
        borderRightColor: isEmailGame() ? ColorConfig.SIDE_PANEL_BORDER_COLOR : null,
    });
}

const styles = StyleSheet.create({
    titleBarHeadingTextStyle: {
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        fontWeight: 'bold',
    },
    tabBarOuterStyle: { padding: Config.HEADER_CONTAINER_PADDING },
    tabBarInnerStyle: {
        width: '100%',
        paddingLeft: Config.TAB_RIGHT_LEFT_MARGIN,
        paddingRight: Config.TAB_RIGHT_LEFT_MARGIN,
        paddingTop: Config.TAB_RIGHT_LEFT_MARGIN,
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    tabBarAllTabsOuterStyle: {
        flexDirection: 'row',
        height: '100%',
    },
    sidePanelStyle: {
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
    },
    gameButtonTouchableStyle: {
        paddingVertical: Config.TAB_RIGHT_LEFT_MARGIN,
        paddingHorizontal: 10,
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flexDirection: Config.ROW,
        alignItems: Config.CENTER,
        justifyContent: 'space-between',
    },
    gameButtonTextStyle: {
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        marginLeft: 8,
        fontWeight: 'bold',
    },
    tabCommonStyle: {
        alignItems: 'center',
        justifyContent: 'center',
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
    },
    styleTitleBar: {
        padding: Config.TAB_RIGHT_LEFT_MARGIN,
        color: ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR,
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flexDirection: Config.ROW,
        alignItems: Config.CENTER,
        justifyContent: Config.CENTER,
    },
    puzzleSidePanelScrollContainer: {
        position: 'absolute',
        right: 0,
    },
    puzzleSidePanelMobileScrollContainer: {
        position: 'absolute',
        bottom: 0,
        overflow: 'hidden',
    },
    tabPanelOuterStyle: {
        paddingBottom: Config.SIDE_PANEL_WRAPPER_PADDING,
    },
    tabPanelInnerStyle: {
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    tabContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        /* paddingVertical: 2,
        paddingHorizontal: 8, */
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
    },
    allTabOuterView: { flex: 1 },
    allTabInnerView: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: Config.TAB_RIGHT_LEFT_MARGIN,
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    allTabInnerViewScrollView: {
        alignItems: 'flex-end',
        justifyContent: 'flex-start',
        paddingTop: Config.TAB_RIGHT_LEFT_MARGIN,
        paddingHorizontal: Config.TAB_RIGHT_LEFT_MARGIN,
    },
    gameBoardStyleAtUnchallengedMode: {
        paddingBottom: Config.SIDE_PANEL_WRAPPER_PADDING,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        height: '100%',
        width: '100%',
    },
    lastMoveDefinition: {
        flex: 1,
        padding: 8,
        overflow: 'hidden',
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderLeftColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    },
    headingView: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    additionalStylesForLiveGame: {
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomLeftRadius: Config.SIDE_PANEL_BORDER_RADIUS,
        borderBottomRightRadius: Config.SIDE_PANEL_BORDER_RADIUS,
        borderLeftColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderRightColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderBottomColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
    },
    additionalTabPanelStyleForSoloGame: {
        borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderLeftColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderRightColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        overflow: 'hidden',
        flex: 1,
    },
    seperationLineStyle: {
        borderTopWidth: 1,
        borderTopColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    w100: {
        width: '100%',
    },
    h100: {
        height: '100%',
    },
    h50: {
        height: '50%',
    },
    menuContainer: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        borderWidth: StyleSheet.hairlineWidth,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    flex1: { flex: 1, width: '100%' },
    historySectionWrappingBorderStyle: {
        borderLeftWidth: isEmailGame() ? StyleSheet.hairlineWidth : 0,
        borderRightWidth: isEmailGame() ? StyleSheet.hairlineWidth : 0,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    cells: state.cells,
    layout: state.layout,
    config: state.config,
    chat: state.chat,
});

export default connect(mapStateToProps)(GameBoardSideLayout);
