import get from 'lodash/get';

let isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development' || get(window, '__DEV__');
const Config = {
    isDev,

    MONTH_NAMES: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

    ALPHABET_PICKER_ARRANGEMENT: [
        ['A', 'B', 'C', 'D', 'E'],
        ['F', 'G', 'H', 'I', 'J'],
        ['K', 'L', 'M', 'N', 'O'],
        ['P', 'Q', 'R', 'S', 'T'],
        ['U', 'V', 'W', 'X', 'Y'],
        ['Z'],
    ],

    GAME_TYPE_LIVE_GAME: 'live_room',
    GAME_TYPE_PUZZLE: 'puzzle',
    GAME_TYPE_EMAIL: 'email',
    GAME_TYPE_SOLO: 'solo',
    GAME_TYPE_BLITZ: 'blitz',

    LOGIN_ACTION: 'login',

    BOARD_PUZZLE_DATA_READY: 'BOARD_PUZZLE_DATA_READY',
    BOARD_LOAD_START: 'BOARD_LOAD_START',
    SEND_PLAY_MOVE_DATA_ACTION: 'puzzlemove',
    SEND_LIVE_GAME_MOVE_DATA_ACTION: 'move',
    SEND_LIVE_GAME_MOVE_DATA_RESPONSE_ACTION: 'move',

    SEND_EMAIL_GAME_MOVE_DATA_ACTION: 'move',
    SEND_EMAIL_GAME_MOVE_SUCCESSFUL: 'SEND_EMAIL_GAME_MOVE_DATA_SUCCESSFUL',

    ACTION_SOLO_QUICK_GAME_START: 'recreategame',
    ACTION_SOLO_GET_ROBOT_MOVE: 'getbotsmove',
    ACTION_SOLO_GET_SAVED_BOARD: 'loadboarddetails',
    ACTION_SOLO_GET_RANDOM_BOARD: 'getrandomboard',
    ACTION_SOLO_SAVE_CREATE_GAME: 'saveboarddata',
    ACTION_SOLO_SLOT_GAME_EDIT: 'loadboarddata',

    ACTION_SOLO_GET_HINTS: 'gethints',
    GET_HINTS_REQUEST_STARTING: 'GET_HINTS_REQUEST_STARTING',

    ACTION_SOLO_GET_STATS: 'stat',

    EVENT_SOLO_TIME_OVER_RESIGN: 'SOLO_TIME_OVER_RESIGN',
    EVENT_SOLO_SHOW_START_GAME_OPTIONS: 'SOLO_SHOW_START_GAME_OPTIONS',
    EVENT_SOLO_SEND_SAVED_GAME_START: 'SOLO_SEND_SAVED_GAME_START',
    EVENT_SOLO_NO_LOGIN_GAME_START: 'SOLO_NO_LOGIN_GAME_START',
    SHOW_START_GAME_OPTIONS: 'SHOW_START_GAME_OPTIONS',
    START_NEW_GAME_ACTION: 'startnewgame',
    ACCEPT_MATCH_RESPONSE_ACTION: 'acceptmatch',
    GAME_FEED_REPSONSE_ACTION: 'gamefeed',
    START_NEW_SAVED_GAME_ACTION: 'recreatefromslot',
    START_NEW_GAME_INVITATION_RECEIVED: 'START_NEW_GAME_INVITATION_RECEIVED',
    START_GAME_REQUEST_ACCEPTED: 'START_GAME_REQUEST_ACCEPTED',

    GAME_HAS_ENDED: 'GAME_HAS_ENDED',

    ON_HOSTED_GAME_ITEM_SELECTED: 'ON_HOSTED_GAME_ITEM_SELECTED',
    ON_PLAYER_ITEM_SELECTED: 'ON_PLAYER_ITEM_SELECTED',

    RESTART_APP: 'RESTART_APP',

    MATCH_REMATCH_RESPONSE_EVENT: 'MATCH_REMATCH_REQUEST_EVENT',
    MATCH_REQUEST_REJECTED_EVENT: 'MATCH_REQUEST_REJECTED_EVENT',

    SEND_LIVE_GAME_MOVE_SUCCESSFUL: 'SEND_LIVE_GAME_MOVE_SUCCESSFUL',

    GET_GAME_LIST_REQUEST_COMPLETE: 'GET_GAME_LIST_REQUEST_COMPLETE',
    GET_GAME_LIST_REQUEST_FAILED: 'GET_GAME_LIST_REQUEST_FAILED',

    GET_LIVE_GAME_LIST_REQUEST_SUCCESSFUL: 'GET_LIVE_GAME_LIST_REQUEST_SUCCESSFUL',
    GET_LIVE_GAME_LIST_ACTION: 'getlvgmlst',

    GET_HOSTED_GAME_LIST_ACTION: 'gethostedgames',

    GET_ONLINE_PLAYER_LIST_REQUEST_SUCCESSFUL: 'GET_ONLINE_PLAYER_LIST_REQUEST_SUCCESSFUL',
    GET_ONLINE_PLAYER_LIST_REQUEST_ACTION: 'getplayerlist',
    ADD_ONLINE_PLAYER: 'addply',
    REMOVE_ONLINE_PLAYER: 'rmply',

    ACCEPT_MATCH_ACTION: 'acceptmatch',
    ACCEPT_GAME_REQUEST_SUCCESSFUL: 'ACCEPT_GAME_REQUEST_SUCCESSFUL',
    ACCEPT_GAME_REQUEST_FAILED: 'ACCEPT_GAME_REQUEST_FAILED',

    CANCEL_GAME_INVITATION_ACTION: 'cancelmatch',
    CANCEL_GAME_INVITATION_EVENT: 'CANCEL_GAME_INVITATION_EVENT',

    HOST_GAME_ACTION: 'hostagame',
    HOST_GAME_REQUEST_SUCCESSFUL: 'HOST_GAME_REQUEST_SUCCESSFUL',
    HOST_GAME_REQUEST_FAILED: 'HOST_GAME_REQUEST_FAILED',

    SWAP_TILES_ACTION: 'swap',
    SWAP_TILES_RESPONSE_ACTION: 'swap',
    SWAP_TILES_REQUEST_FAILED: 'SWAP_TILES_REQUEST_FAILED',
    SWAP_TILES_EMAIL_GAME_REQUEST_SUCCESSFUL: 'SWAP_TILES_EMAIL_GAME_REQUEST_SUCCESSFUL',
    SWAP_TILES_EMAIL_GAME_REQUEST_FAILED: 'SWAP_TILES_EMAIL_GAME_REQUEST_FAILED',

    PASS_MOVE_ACTION: 'pass',
    PASS_MOVE_RESPONSE_ACTION: 'pass',

    SEND_EMAIL_GAME_PASS_ACTION: 'pass',
    SEND_EMAIL_GAME_PASS_SUCCESSFUL: 'SEND_EMAIL_GAME_PASS_SUCCESSFUL',

    RESIGN_GAME_ACTION: 'resign',
    RESIGN_GAME_REQUEST_STARTING: 'RESIGN_GAME_REQUEST_STARTING',
    RESIGN_GAME_REQUEST_SUCCESSFUL: 'RESIGN_GAME_REQUEST_SUCCESSFUL',
    RESIGN_GAME_REQUEST_FAILED: 'RESIGN_GAME_REQUEST_FAILED',

    RESIGN_EMAIL_GAME_REQUEST_FAILED: 'RESIGN_EMAIL_GAME_REQUEST_FAILED',
    RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL: 'RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL',
    DELETE_EMAIL_GAME_REQUEST_FAILED: 'DELETE_EMAIL_GAME_REQUEST_FAILED',
    DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL: 'DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL',

    OBSERVE_GAME_ACTION: 'observe',
    OBSERVE_GAME_RESPONSE_ACTION: 'observe',

    UNOBSERVE_GAME_ACTION: 'unobserve',
    UNOBSERVE_GAME_REQUEST_FAILED: 'UNOBSERVE_GAME_REQUEST_FAILED',

    ADD_HOSTED_GAMES_REQUEST_ACTION: 'addhostedgame',
    ADD_HOSTED_GAMES_ACTION: 'ADD_HOSTED_GAMES_ACTION',

    DELETE_HOSTED_GAME_REQUEST_ACTION: 'deletehostedgame',
    DELETE_HOSTED_GAME_ACTION: 'DELETE_HOSTED_GAME_ACTION',
    DELETE_HOSTED_GAME_REQUEST_SUCCESSFUL: 'DELETE_HOSTED_GAME_REQUEST_SUCCESSFUL',

    GAME_CHAT_ACTION: 'gamechat',
    GAME_CHAT_RESPONSE_ACTION: 'gamechat',

    LIVE_GAME_STATS_ACTION: 'getstats',

    LIVE_GAME_LIST_SENSOR_ACTION: 'lstcensor',

    LIVE_GAME_CENSOR_PLAYER_REQUEST_FAILED: 'LIVE_GAME_CENSOR_PLAYER_REQUEST_FAILED',
    LIVE_GAME_UNCENSOR_PLAYER_REQUEST_FAILED: 'LIVE_GAME_UNCENSOR_PLAYER_REQUEST_FAILED',

    DELETE_GAME: 'deletegame',
    DELETE_GAME_EVENT: 'DELETE_GAME_EVENT',

    RESIGN_GAME: 'resign',
    RESIGN_GAME_EVENT: 'RESIGN_GAME_EVENT',

    REQ_JOIN_HOSTED_GAME_ACTION: 'reqjnhstdgm',
    REQ_JOIN_HOSTED_GAME_REPSPONSE_ACTION: 'rspjnhstdgm',
    JOIN_HOSTED_GAME_ACTION: 'joinhostedgame',
    JOIN_HOSTED_GAME_EVENT: 'JOIN_HOSTED_GAME_EVENT',
    JOIN_HOSTED_GAME_REPSPONSE_ACTION: 'joinhostedgame',
    JOIN_HOSTED_GAME_REQUEST_FAILED: 'JOIN_HOSTED_GAME_REQUEST_FAILED',

    LEAVE_HOSTED_GAME_ACTION: 'leavehostedgame',
    LEAVE_HOSTED_GAME_EVENT: 'LEAVE_HOSTED_GAME_EVENT',
    LEAVE_HOSTED_GAME_REPSPONSE_ACTION: 'leavehostedgame',

    ADD_GAME_ACTION: 'addgame',
    REMOVE_GAME_ACTION: 'rmgame',
    INP_GAME_OVER_ACTION: 'inpgameover',
    EVENT_INP_GAME_OVER: 'EVENT_INP_GAME_OVER',
    UPDATE_JNDPLY_ACTION: 'updtjndplys',
    REMOVE_JNDPLY_ACTION: 'rmjndply',

    MESSAGE_RECEIVED_EVENT: 'MESSAGE_RECEIVED_EVENT',

    KEY_PRESS_EVENT_FOR_BOARD: 'KEY_PRESS_EVENT_FOR_BOARD',

    TILE_MAX_LENGTH: 9,

    DIALOG_GENERAL_MARGIN: 32,

    SHOW_DIALOG_MODAL: 'SHOW_DIALOG_MODAL',

    HIDE_DIALOG_MODAL: 'HIDE_DIALOG_MODAL',

    BOARD_LOAD_FAIL: 'BOARD_LOAD_FAIL',

    SEND_PUZZLE_MOVE_FAIL: 'SEND_PUZZLE_MOVE_FAIL',

    SEND_PUZZLE_MOVE_SUCCESS: 'SEND_PUZZLE_MOVE_SUCCESS',

    SHOW_CONTEXT_MENU: 'SHOW_CONTEXT_MENU',

    GET_PUZZLE_DATA_ACTION: 'getpuzzle',

    MENU_OPTION_TOGGLED: 'MENU_OPTION_TOGGLED',

    LOADER_OVERLAY: 'LOADER_OVERLAY',

    BOARD_SHOW_PUZZLE_SOLUTION: 'BOARD_SHOW_PUZZLE_SOLUTION',

    HYPOTENUSE: 6 * 96,

    CLASSIC_BOARD_SIZE_FIFTEEN: 15,
    SUPER_BOARD_SIZE_TWENTYONE: 21,

    RACK_LENGTH_INCLUDING_EMPTY_SPACE: 9,

    TEXT_INPUT_FOCUSSED: 'TEXT_INPUT_FOCUSSED',

    BOARD_DIMENSION_SET: 'BOARD_DIMENSION_SET',

    BOARD_BORDER_WIDTH: 1,

    SIDE_PANEL_BORDER_WIDTH: 1,

    LIVE_GAME_CHAT_CHARACTER_LIMIT: 500,

    SIDE_PANEL_WRAPPER_PADDING: 10,

    NO_TILES_PLAYED: 'NO_TILES_PLAYED',

    HANDLED_BY_INCOMING_METHOD: ['joinhostedgame', 'acceptmatch', 'observe', 'hostagame'],

    SHOW_UNSEEN_TILES_DIALOG: 'SHOW_UNSEEN_TILES_DIALOG',

    GET_HEAD_TO_HEAD_STATS_ACTION: 'geth2hstats',

    GET_SETTINGS_REQUEST_SUCCESSFUL: 'GET_SETTINGS_REQUEST_SUCCESSFUL',
    GET_SETTINGS_ACTION: 'getusersettings',

    SET_SETTINGS_ACTION: 'setusersettings',

    ALWAYS_USE_REST_METHODS: ['getDictionaryData', 'getUniqueWordsPlayedCount'],

    UNSEEN_TILES_MODAL_COLUMN_COUNT: 13,

    NO_VALID_USER: 'NO_VALID_USER',

    GAME_OVER: 'GAME_OVER',

    LIVE_DEFAULT_SETTINGS: {
        us_gameplay: {
            gp_magictiles: 'n',
            gp_moveconfirmation: 'n',
            gp_numbrdboard: 'y',
            gp_gamesounds: 'y',
            gp_premovevalidation: 'y',
            gp_autozoomboard: 'y',
            gp_gametheme: '0-1',
            gp_scoregraph: 'y',
        },
        us_gamestart: {
            gs_showinit: 'y',
            gs_prefdic: 'twl',
            gs_ratingrange: '0-4000',
            gs_numplayers: '2',
            gs_rated: 'y',
            gs_lvduration: '600',
            gs_lvincrmnt: '10',
        },
    },

    PUZZLE_PASS_ACTION: 'puzzlepass',
    PUZZLE_PASS_SUCCESS: 'PUZZLE_PASS_SUCCESS',

    GET_ARCHIVED_PUZZLE_ACTION: 'getarchivedpuzzle',
    GET_ARCHIVED_PUZZLE_SUCCESS: 'GET_ARCHIVED_PUZZLE_SUCCESS',

    REVEAL_SOLUTION_MODE_COUNT: 3,
    REVEAL_SOLUTION_MODE_SELF: 0,
    REVEAL_SOLUTION_MODE_PREVIOUS_PLAYER: 1,
    REVEAL_SOLUTION_MODE_BEST_MOVE: 2,

    SHOW_MOVES_LIST: 'SHOW_MOVES_LIST',

    GET_ONLINE_STATUS: 'getonlinestatus',
    ONLINE_STATUS_CHANGED_EVENT: 'ONLINE_STATUS_CHANGED_EVENT',

    ON_SEND_GAME_REQUEST: 'ON_SEND_GAME_REQUEST',

    SHOW_SCORING_DETAILS_MODAL: 'SHOW_SCORING_DETAILS_MODAL',

    SIZE_OF_RACK_ELEMENTS: 9,

    ASYNC_POLLING_TIMEOUT: 55000,
    RESIZE_POLLING_TIMEOUT: 3000,

    OFFLINE_PLAYER_COUNTDOWN_TIME: 60000,

    FIRST_MOVE_PLAYER_COUNTDOWN_TIME: 60000,

    DIALOG_TYPE_REMATCH: 'DIALOG_TYPE_REMATCH',
    DIALOG_TYPE_REMATCH_CONFIG_CONFIRM: 'DIALOG_TYPE_REMATCH_CONFIG_CONFIRM',

    SHOW_HOST_INVITE_DIALOG: 'SHOW_HOST_INVITE_DIALOG',

    NOT_AUTO_CANCELLABLE_DIALOG_TYPES: ['DIALOG_TYPE_REMATCH'],

    PLAY_WORD_FORMED_SOUND_ACTIONS: ['move', 'pass', 'swap'],
    RESET_MESSAGE_LIST_ACTIONS: ['observe', 'gamefeed', 'joinhostedgame', 'acceptmatch'],
    SET_PLAYER_COUNT_ACTIONS: [
        'gamefeed',
        'joinhostedgame',
        'acceptmatch',
        'observe',
        'recreategame',
        'startnewgame',
        'recreatefromslot',
        'archivegameview',
    ],

    GET_WORD_VALIDITY_REQUEST_SUCCESSFUL: 'GET_WORD_VALIDITY_REQUEST_SUCCESSFUL',
    PAGE_VISIBILITY_CHANGED: 'PAGE_VISIBILITY_CHANGED',

    HAS_ACTIVE_GAME: 'hasactivegame',
    HAS_ACTIVE_GAME_EVENT: 'HAS_ACTIVE_GAME_EVENT',

    NATIVE_BACK_PRESS_HANDLE: 'NATIVE_BACK_PRESS_HANDLE',

    RESIGN_DELETE_GAME: 'RESIGN_DELETE_GAME',
    CLOSE_MENU_POPOVER: 'CLOSE_MENU_POPOVER',
    EVENT_SCORE_GRAPH_TOGGLE_BUTTON: 'SCORE_GRAPH_TOGGLE_BUTTON',

    EVENT_PING_POLLING: 'EVENT_PING_POLLING',

    MORE_TIME_ACTION_RESPONSE_ACTION: 'moretime',

    DELETE_GAME_REQUEST_SUCCESSFUL: 'DELETE_GAME_REQUEST_SUCCESSFUL',
    DELETE_GAME_REQUEST_FAILED: 'DELETE_GAME_REQUEST_FAILED',

    CHECK_RATING_CHANGE_REQUEST_ACTION: 'chkratingchng',

    NEXT_GAME_REQUEST_ACTION: 'nextgame',

    GET_GAME_FEED_REQUEST_ACTION: 'gamefeed',
    GET_ARCHIVED_GAME_ACTION: 'archivegamefeed',
    GET_ARCHIVED_GAME_VIEW_ACTION: 'archivegameview',
    GET_GAME_FEED_REQUEST_SUCCESSFUL: 'GET_GAME_FEED_REQUEST_SUCCESSFUL',

    MAX_RECONNECT_TRIES: 10,

    REMATCH_REQUEST_ACTION: 'rematch',

    NEXT_GAME_URL_REQUEST_ACTION: 'nextgame',

    PING_ACTION: 'ping',

    LIVE_GAME_REQUEST_TIMEOUT_TIME: 60000,

    LIVE_GAME_POLLING_REQUEST_FREQUENCY_TIME: 25000,

    IMAGE_RESIZE_CONFIG: {
        quality: 0.5,
        maxWidth: 1024,
        maxHeight: 1024,
        autoRotate: true,
        debug: isDev,
    },

    COLOR_CELLS_CONTAINER_BOTTOM_DIMENSION_MULTIPLIER: 0.1,
    COLOR_CELLS_CONTAINER_TOP_DIMENSION_MULTIPLIER: 0.5,

    GET_BUDDY_LIST_REQUEST_ACTION: 'lstbuddy',

    BUDDY_REQUEST_LIST_ACTION: 'lstbuddyrequestpending',

    ADD_TO_BUDDY_LIST_REQUEST_ACTION: 'mkrequest',

    REMOVE_FROM_BUDDY_LIST_CONFIRMED_REQUEST_ACTION: 'rmfriend',
    REMOVE_FROM_BUDDY_LIST_REQUESTED_REQUEST_ACTION: 'cancelrequest',

    BUDDY_REQUEST_ACCEPT_ACTION: 'mkfriend',
    BUDDY_REQUEST_REJECT_ACTION: 'rmrequest',

    RIGHT_LEFT_MARGIN: 16,

    TAB_RIGHT_LEFT_MARGIN: 10,

    COMMON_BORDER_RADIUS: 4,

    ROW: 'row',

    CENTER: 'center',

    HEADER_CONTAINER_PADDING: 10,

    HOST_ACCEPT_OBSERVE_BUTTON_WIDTH: 42,

    DIALOG_HEADER_TEXT: 'Lexulous',

    ON_MATCH_OR_WATCH: 'ON_MATCH_OR_WATCH',

    MOVE_LIST_INITIATE_ACTIONS: [
        'gamefeed',
        'joinhostedgame',
        'acceptmatch',
        'observe',
        'recreategame',
        'startnewgame',
        'recreatefromslot',
    ],

    ICON_SIZE_CELL_DIMEN_MULTIPLIER: 0.7,

    CHALLENGE_MODE: ['LC', 'EC'],

    BINGO_TILES_COUNT: 7,

    DUPLICATE_CONNECTION_RESPONSE_ACTION: 'term',
    DUPLICATE_CONNECTION_OCCURENCE: 'DUPLICATE_CONNECTION_OCCURENCE',

    SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION: 'challenge',
    SEND_EMAIL_GAME_CHALLENGE_MOVE_FAILED: 'SEND_EMAIL_GAME_CHALLENGE_MOVE_FAILED',
    SEND_EMAIL_GAME_CHALLENGE_MOVE_SUCCESSFUL: 'SEND_EMAIL_GAME_CHALLENGE_MOVE_SUCCESSFUL',

    SHOW_BOARD_CONTAINER: 'SHOW_BOARD_CONTAINER',
    HIDE_BOARD_CONTAINER: 'HIDE_BOARD_CONTAINER',

    SET_GAME_NOTES_REQUEST_ACTION: 'setgamenotes',

    GET_GAME_NOTES_REQUEST_ACTION: 'getgamenotes',

    READ_ALL_CHAT_MESSAGES_ACTION: 'readallmsgs',

    CELL_ON_TILE_SET: 'CELL_ON_TILE_SET',

    LIVE_TIME_OUT_RESIGN_MESSAGE: 'Timed Out',
    PLAYER_SELF_RESIGN_MESSAGE: 'Resigned',
    PLAYER_SELF_DELETE_MESSAGE: 'Deleted',
    LIVE_DISCONNECT_TIME_OUT_RESIGN: 'Offline',

    SHOW_VIEW_STATS_MODAL_ON_MULTIPLAYER_SELF_HOST_GAME: 'SHOW_VIEW_STATS_MODAL_ON_MULTIPLAYER_SELF_HOST_GAME',
    ON_SHOW_VIEW_STATS_MODAL_FOR_SELF_HOST: 'ON_SHOW_VIEW_STATS_MODAL_FOR_SELF_HOST',

    PLAY_BUTTON_SET_SELF_TO_CLOSE: 'PLAY_BUTTON_SET_SELF_TO_CLOSE',

    HINT_WORD_SELECTED: 'HINT_WORD_SELECTED',

    ANALYSE_DISPLAY_MOVE_RACK: 'ANALYSE_DISPLAY_MOVE_RACK',
    RESET_ANALYSE_HINT: 'REST_ANALYSE_HINT',

    GAMEOVER_EVENT_ACTION: 'gameover',

    SHOW_SOLO_STATS_DIALOG: 'SHOW_SOLO_STATS_DIALOG',

    SOLO_NO_LOGIN_NEW_GAME: 'SOLO_NO_LOGIN_NEW_GAME',
    SOLO_NEW_GAME: 'SOLO_NEW_GAME',
    SOLO_REMATCH: 'SOLO_REMATCH',

    MIN_DESKTOP_CONSIDERABLE_WIDTH: 640,

    MINIMUM_AVAILABLE_TILES_FOR_EXCHANGE: 8,

    DETACH_ALL_EVENT: 'DETACH_ALL_EVENT',
    FOCUS_TEXTFIELD_IN_CHAT: 'FOCUS_TEXTFIELD_IN_CHAT',
    FOCUS_SEARCH_IN_DICTIONARY: 'FOCUS_SEARCH_IN_DICTIONARY',
    FOCUS_NOTES_IN_TOOLS: 'FOCUS_NOTES_IN_TOOLS',

    DISABLE_SCORE_GRAPH_TOGGLE: true,

    KEYBOARD_SHORTCUT_SHOW_UNSEEN_TILES: 'KEYBOARD_SHORTCUT_SHOW_UNSEEN_TILES',

    DEFAULT_RATING_VALUE: '1200',

    ADD_OBSERVER: 'addobserver',

    REMOVE_OBSERVER: 'rmobserver',

    MOVE_LIST_TABLE_CELL_FONT_SIZE: 12,

    SIDE_PANEL_BORDER_RADIUS: 5,

    DICTIONARY_TAB_PANEL_BUTTON_CONTAINER_FIXED_HEIGHT: 28,
    DICTIONARY_TAB_PANEL_BUTTON_CONTAINER_FIXED_WIDTH: 44,
    PLAY_BUTTON_FIXED_WIDTH: 64,
    PLAY_BUTTON_FIXED_HEIGHT: 28,
    PLAY_BUTTON_FIXED_FONT_SIZE: 12,
    BOARD_FIXED_DIMENSION: 436,

    LOBBY_CHAT_ACTION: 'lbycht',
    MOVE_STRENGTH_ACTION: 'movestrength',

    SOLO_DEFAULT_MENU_OPT: 1,
    SOLO_BOARD_TYPE_STANDARD: 'standard',
    SOLO_BOARD_TYPE_SUPER: 'super',
    SOLO_BOARD_TYPE_MANUAL: 'manual',
    SOLO_BOARD_TYPE_RANDOM: 'random',
    SOLO_CREATE_BOARD_CELL: ['2L', '2W', '3L', '3W', '4L', '4W', '5L', '5W'],
    SOLO_SLOT_SAVE: 'SLOT_SAVE',
    SOLO_SLOT_PLAY_EDIT: 'SLOT_PLAY_EDIT',
    SOLO_SLOT_PLAY_BUTTON: 'SLOT_PLAY_BUTTON',
    SOLO_SLOT_EDIT_BUTTON: 'SLOT_EDIT_BUTTON',
    DEFAULT_BDSQVAL: 'R,3W|P,2W|B,3L|L,2L|F,4L|G,4W|H,5L|I,5W|W,0',
    DEFAULT_TILE_COUNT:
        'A,8|B,2|C,2|D,3|E,11|F,2|G,2|H,2|I,8|J,1|K,1|L,3|M,2|N,5|O,7|P,2|Q,1|R,5|S,3|T,5|U,3|V,2|W,2|X,1|Y,3|Z,1|blank,2',
    DEFAULT_TILE_SCORE:
        'A,1|B,4|C,4|D,2|E,1|F,5|G,2|H,5|I,1|J,8|K,6|L,1|M,4|N,1|O,1|P,4|Q,12|R,1|S,1|T,2|U,1|V,5|W,5|X,8|Y,5|Z,12|a,0|b,0|c,0|d,0|e,0|f,0|g,0|h,0|i,0|j,0|k,0|l,0|m,0|n,0|o,0|p,0|q,0|r,0|s,0|t,0|u,0|v,0|w,0|x,0|y,0|z,0',

    LOBBY_CHAT_MESSAGE_TYPE_NORMAL: 'lby',
    LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE: 'gmupdt',
    LOBBY_CHAT_MESSAGE_TYPE_PRIVATE: 'pvtcht',
    LOBBY_CHAT_MESSAGE_LIMIT: 100,
    LOBBY_CHAT_VIEW_HEIGHT: 350,
    LOBBY_SCREEN_CONTAINER_HEIGHT: '882px',
    NORMAL_SCREEN_CONTAINER_HEIGHT: '532px',
    LOBBY_SCREEN_MOBILE_CONTAINER_HEIGHT: '1400px',
    MOBILE_CONTAINER_HEIGHT: '1200px',

    HIDE_PUZZLE_BOARD_HEADER: 'HIDE_PUZZLE_BOARD_HEADER',

    ON_TILE_PLACED_HANDLER_EVENT: 'ON_TILE_PLACED_HANDLER_EVENT',
    ON_TILE_REMOVED_EVENT: 'ON_TILE_REMOVED_EVENT',

    UPDATE_MOVE_VALIDITY: 'UPDATE_MOVE_VALIDITY',
    DISPLAY_LETTER_PICKER: 'DISPLAY_LETTER_PICKER',

    SOLO_SOURCE_ROBOT: 'robot',
    GET_UNIQUE_WORDS_PLAYED_COUNT: 'getuqewdpldcnt',

    EVENT_GET_GAME_HISTORY: 'EVENT_GET_GAME_HISTORY',

    CUSTOM_BOARD_NEXT_OPTION: 'CUSTOM_BOARD_NEXT_OPTION',

    SHOW_REVEAL_SOLUTION: 'SHOW_REVEAL_SOLUTION',

    CHAT_SHORT_MESSAGES: ['hi', 'gl', 'u2', 'gg', 'ty', 'n1', 'wd'],

    SET_SHOW_SIDE_MENU: 'SET_SHOW_SIDE_MENU',

    SET_SHOW_INNER_SIDE_MENU: 'SET_SHOW_INNER_SIDE_MENU',

    ACTION_RESTART_SERVER: 'restrt',

    REFRESH_APP_ROOT_COMPONENT: 'REFRESH_APP_ROOT_COMPONENT',

    HOSTED_GAME_TYPES: { rnd: 'RND', hstd: 'HSTD' },

    SELECT_OPTION_TYPES: {
        players: 'PLAYERS',
        dictionary: 'DICTIONARY',
        gameType: 'GAME_TYPE',
        rated: 'RATED',
        time: 'TIME',
        increments: 'INCREMENTS',
        robotLevel: 'ROBOT_LEVEL',
        timeRobot: 'TIME_ROBOT',
    },

    BOARD_SPINNER: 'BOARD_SPINNER',

    EVENT_BOARD_CLOSE_LOBBY_SHOW: 'EVENT_BOARD_CLOSE_LOBBY_SHOW',

    FITFEEN_BY_FIFTEEN_BOARD: [
        {
            type: '3W',
            positions: [
                [0, 0],
                [0, 7],
                [0, 14],
                [7, 0],
                [7, 14],
                [14, 0],
                [14, 7],
                [14, 14],
            ],
        },
        {
            type: '2W',
            positions: [
                [1, 2],
                [1, 12],
                [2, 1],
                [2, 13],
                [3, 4],
                [3, 10],
                [4, 3],
                [4, 11],
                [7, 7],
                [10, 3],
                [10, 11],
                [11, 4],
                [11, 10],
                [12, 1],
                [12, 13],
                [13, 2],
                [13, 12],
            ],
        },
        {
            type: '3L',
            positions: [
                [2, 5],
                [2, 9],
                [5, 2],
                [5, 12],
                [9, 2],
                [9, 12],
                [12, 5],
                [12, 9],
            ],
        },
        {
            type: '2L',
            positions: [
                [0, 3],
                [0, 11],
                [1, 6],
                [1, 8],
                [3, 0],
                [3, 14],
                [5, 6],
                [5, 8],
                [6, 1],
                [6, 5],
                [6, 9],
                [6, 13],
                [8, 1],
                [8, 5],
                [8, 9],
                [8, 13],
                [9, 6],
                [9, 8],
                [11, 0],
                [11, 14],
                [13, 6],
                [13, 8],
                [14, 3],
                [14, 11],
            ],
        },
    ],
    TWENTYONE_BY_TWENTYONE_BOARD: [
        {
            type: '4W',
            positions: [
                [0, 0],
                [20, 0],
                [0, 20],
                [20, 20],
            ],
        },
        {
            type: '4L',
            positions: [
                [5, 2],
                [15, 2],
                [2, 5],
                [18, 5],
                [2, 15],
                [18, 15],
                [5, 18],
                [15, 18],
            ],
        },
        {
            type: '3W',
            positions: [
                [7, 0],
                [13, 0],
                [3, 3],
                [10, 3],
                [17, 3],
                [0, 7],
                [20, 7],
                [3, 10],
                [17, 10],
                [0, 13],
                [20, 13],
                [3, 17],
                [10, 17],
                [17, 17],
                [7, 20],
                [13, 20],
            ],
        },
        {
            type: '2W',
            positions: [
                [1, 1],
                [8, 1],
                [12, 1],
                [19, 1],

                [2, 2],
                [9, 2],
                [11, 2],
                [18, 2],

                [5, 4],
                [15, 4],

                [4, 5],
                [16, 5],

                [7, 6],
                [13, 6],

                [6, 7],
                [14, 7],

                [1, 8],
                [19, 8],

                [2, 9],
                [18, 9],

                [2, 11],
                [18, 11],

                [1, 12],
                [19, 12],

                [6, 13],
                [14, 13],

                [7, 14],
                [13, 14],

                [4, 15],
                [16, 15],

                [5, 16],
                [15, 16],

                [2, 18],
                [9, 18],
                [11, 18],
                [18, 18],

                [1, 19],
                [8, 19],
                [12, 19],
                [19, 19],
            ],
        },
        {
            type: '3L',
            positions: [
                [4, 1],
                [16, 1],

                [1, 4],
                [19, 4],

                [8, 5],
                [12, 5],

                [5, 8],
                [15, 8],

                [5, 12],
                [15, 12],

                [8, 15],
                [12, 15],

                [1, 16],
                [19, 16],

                [4, 19],
                [16, 19],
            ],
        },
        {
            type: '2L',
            positions: [
                [3, 0],
                [10, 0],
                [17, 0],

                [0, 3],
                [6, 3],
                [14, 3],
                [20, 3],

                [9, 4],
                [11, 4],

                [3, 6],
                [17, 6],

                [9, 8],
                [11, 8],

                [4, 9],
                [8, 9],
                [12, 9],
                [16, 9],

                [0, 10],
                [20, 10],

                [4, 11],
                [8, 11],
                [12, 11],
                [16, 11],

                [9, 12],
                [11, 12],

                [3, 14],
                [17, 14],

                [9, 16],
                [11, 16],

                [0, 17],
                [6, 17],
                [14, 17],
                [20, 17],

                [3, 20],
                [10, 20],
                [17, 20],
            ],
        },
    ],

    LOCAL_STORAGE_DO_NOT_SHOW_SCAM_ALERT: 'doNotShowScamAlert',
    LOCAL_STORAGE_DO_NOT_SHOW_SCAM_LOBBY_ALERT: 'doNotShowScamLobbyAlert',
    CACHE_NAME: 'LexulousCache',
    CACHE_USER_SETTINGS: 'LexEmailUserSettings',
    URL_REGEX:
        /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi,

    ANALYTICS_EVENT_ACTION: {
        GAMEBOARD_CHAT_BUTTON: 'GAMEBOARD_CHAT_BUTTON',
        GAMEBOARD_CHAT_BUTTON_ALLOW: 'GAMEBOARD_CHAT_BUTTON_ALLOW',
        GAMEBOARD_SHUFFLE_BUTTON: 'GAMEBOARD_SHUFFLE_BUTTON',
        GAMEBOARD_LONG_SHUFFLE_BUTTON: 'GAMEBOARD_LONG_SHUFFLE_BUTTON',
        GAMEBOARD_RECALL_BUTTON: 'GAMEBOARD_RECALL_BUTTON',
        GAMEBOARD_SWAP_BUTTON: 'GAMEBOARD_SWAP_BUTTON',
        GAMEBOARD_PASS_BUTTON: 'GAMEBOARD_PASS_BUTTON',
        GAMEBOARD_NEXT_BUTTON: 'GAMEBOARD_NEXT_BUTTON',
        GAMEBOARD_CLOSE_BUTTON: 'GAMEBOARD_CLOSE_BUTTON',
        GAMEBOARD_SOLO_CLOSE_BUTTON: 'GAMEBOARD_SOLO_CLOSE_BUTTON',
        GAMEBOARD_UNOBSERVE: 'GAMEBOARD_UNOBSERVE',
        GAMEBOARD_PLAY_BUTTON: 'GAMEBOARD_PLAY_BUTTON',
        GAMEBOARD_MENU_BUTTON: 'GAMEBOARD_MENU_BUTTON',
        GAMEBOARD_REMATCH_BUTTON: 'GAMEBOARD_REMATCH_BUTTON',
        GAMEBOARD_UNSEEN_TILE_BUTTON: 'GAMEBOARD_UNSEEN_TILE_BUTTON',
        GAMEBOARD_RESIGN_BUTTON: 'GAMEBOARD_RESIGN_BUTTON',
        GAMEBOARD_DELETE_BUTTON: 'GAMEBOARD_DELETE_BUTTON',
        GAMEBOARD_TWO_LETTER_BUTTON: 'GAMEBOARD_TWO_LETTER_BUTTON',
        GAMEBOARD_DICTIONARY_BUTTON: 'GAMEBOARD_DICTIONARY_BUTTON',
        GAMEBOARD_FRIEND_ADD_BLOCK: 'GAMEBOARD_FRIEND_ADD_BLOCK',
        GAMEBOARD_MOVE_LIST_BUTTON: 'GAMEBOARD_MOVE_LIST_BUTTON',
        GAMEBOARD_MOVE_GRAPH_BUTTON: 'GAMEBOARD_MOVE_GRAPH_BUTTON',
        GAMEBOARD_FEEDBACK_BUTTON: 'GAMEBOARD_FEEDBACK_BUTTON',
        GAMEBOARD_NUDGE_BUTTON: 'GAMEBOARD_NUDGE_BUTTON',
    },
    BOARD_CENTER_ICONS: {
        ICON_GHOST: 'ghost',
        ICON_SMILE: 'smile',
        ICON_PLUS: 'plus',
        ICON_CAT: 'cat',
        ICON_DOG: 'dog',
    },
};
export default Config;
