// @flow

import { ADD_ARCHIVE_GAMES, AGL_REFRESH_STARTED, CLR_ARCHIVE_GAMES } from './AGLEventTypes';

import type { GLAction, ActionGLRefreshStarted, ProfileInfo, GamesListItemData, GamesListResponse } from '../commons/RJTypes';

type ArchiveGamesListProps = {
    archivegames: Array<ArchiveGameListType>,
    playersinfo: { [string]: ProfileInfo },
    timestamp: number,
    skip: number,
};

type ArchiveGameListType = {
    title: string,
    data: Array<GamesListItemData>,
};

type ActionType = {
    type: string,
    payload: GamesListResponse,
    timestamp: number,
    skip: number,
};

const aglinistate = {
    timestamp: 0,
    skip: 0,
    playersinfo: {},
    archivegames: [],
};

export default function AGLReducer(state: ArchiveGamesListProps = aglinistate, taction: GLAction) {
    switch (taction.type) {
        case ADD_ARCHIVE_GAMES: {
            let action = ((taction: any): ActionType);
            let newList: Array<GamesListItemData> = action.payload.games.map((item) => {
                return {
                    type: 'game',
                    key: item.gid,
                    data: item,
                };
            });

            let newData = [];
            if (state.archivegames.length < 1) {
                newData = [...newList];
            } else {
                newData = [...state.archivegames[0].data, ...newList];
            }

            let newstate: {
                timestamp: number,
                skip: number,
                playersinfo: { [string]: ProfileInfo },
                archivegames: Array<ArchiveGameListType>,
            } = {
                timestamp: action.timestamp,
                skip: action.skip,
                playersinfo: { ...state.playersinfo, ...action.payload.playersinfo },
                archivegames: [{ title: 'recent_games', data: [...newData] }],
            };
            return newstate;
        }
        case AGL_REFRESH_STARTED: {
            let action = ((taction: any): ActionGLRefreshStarted);
            let games: Array<ArchiveGameListType> = [];

            let newstate: {
                timestamp: number,
                skip: number,
                playersinfo: { [string]: ProfileInfo },
                archivegames: Array<ArchiveGameListType>,
            } = {
                timestamp: 0,
                skip: 0,
                playersinfo: {},
                archivegames: games,
            };
            return newstate;
        }
        case CLR_ARCHIVE_GAMES: {
            let action = ((taction: any): ActionGLRefreshStarted);
            let games: Array<ArchiveGameListType> = [];

            let newstate: {
                timestamp: number,
                skip: number,
                playersinfo: { [string]: ProfileInfo },
                archivegames: Array<ArchiveGameListType>,
            } = {
                timestamp: 0,
                skip: 0,
                playersinfo: {},
                archivegames: games,
            };
            return newstate;
        }
        default:
            return state;
    }
}
