// @flow

import type { AppState } from '../../commons/RJTypes';
import type { UserStats } from '../../commons/RJTypes';

export const getMinStats = (guid: string, state: AppState): UserStats => {
    return state.minStats[guid];
};
