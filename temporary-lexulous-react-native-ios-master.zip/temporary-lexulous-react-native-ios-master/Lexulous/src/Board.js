import React, { Fragment } from 'react';
import { Animated, PanResponder, StyleSheet, View, TouchableOpacity } from 'react-native';
import Tile from './component/Tile';
import Cell from './component/Cell';
import GameBoardUtils, {
    createMoveTilesArr,
    getGameRequestText,
    getRackData,
    onStartAnalyse,
    showAnalysePurchaseDialog,
} from './utils/GameBoardUtils';
import get from 'lodash/get';
import times from 'lodash/times';
import constant from 'lodash/constant';
import zip from 'lodash/zip';
import debounce from 'lodash/debounce';
import cloneDeep from 'lodash/cloneDeep';
import omit from 'lodash/omit';
import isEqual from 'lodash/isEqual';
import isArray from 'lodash/isArray';
import isString from 'lodash/isString';
import isObject from 'lodash/isObject';
//import './css/tile.css';
import TileTouchableOpacity from './component/TileTouchableOpacity';
import SoundUtils from './utils/SoundUtils';
import {
    getGameType,
    getWordValidity,
    isEmailGame,
    isLiveGame,
    isSoloGame,
    passMove,
    resignGame,
    sendChallengeMove,
    sendPuzzlePass,
    sendUnobserveGame,
} from './service/GamePlayService';
import Config from './configs/Config';
import ConfigurationWrapper from './utils/ConfigurationWrapper';
import { createDialogInstance, createGeneralRequestFailureDialog } from './utils/MessageUtils';
import LongPress from 'react-long';
import ColorConfig, { StandardButtonMouseHoverEffect } from './configs/ColorConfig';
import RevealSolutionView from './component/RevealSolutionView';
import SwapTilesModal from './modal/SwapTilesModal';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import to from 'await-to-js';
import SettingsUtil from './utils/SettingsUtil';
import { getEventKeyCode, getNull, invokeGlobalMethod, is2dArray, lastArrayElement } from './utils/Utils';
import LiveGamePlayUtils from './utils/LiveGamePlayUtils';
import { reactLocalStorage } from 'reactjs-localstorage';
import { getNextGameUrl } from './service/EmailGamePlayService';
import { formatName } from './utils/StringUtils';
import { faBars, faCog, faRedoAlt, faSearch } from '@fortawesome/free-solid-svg-icons';
import { faForward, faRandom, faSyncAlt, faUndoAlt } from '@fortawesome/pro-duotone-svg-icons';
import PlayButton from './component/PlayButton';
import { getRobotMove } from './service/LiveGamePlayService';
import { proChangeUrl, replaceLocation } from './utils/UrlUtils';
import LayoutWrapper from './utils/LayoutWrapper';
import AnimatedValueWrapped from './utils/AnimatedValueWrapped';
import EventWrapper from './utils/EventWrapper';
import DocumentWrapper from './utils/DocumentWrapper';
import DimensionUtils from './utils/DimensionUtils';
import {
    CELL_REDUCER_CLEAR_DIRECTION,
    CELL_REDUCER_EMPTY_GAMEBOARD,
    CELL_REDUCER_ON_TILE_CLICKED,
    CELL_REDUCER_SET_TILE,
    CHAT_CLEAR_LIST,
    CONFIG_SET_MENU_VISIBILITY,
    GAME_BOARD_PUZZLE_RECEIVED,
    GAME_PLAY_BUTTON_SCORE_TEXT,
    GAME_PLAY_BUTTON_WORD_VALIDITY,
    GAME_REDUCER_SET_MOVE_STRENGTH,
    GAME_REDUCER_UPDATE_TILES,
    GAME_SHOW_PLAY_BUTTON_LOADER,
    GAME_SIDE_LAYOUT_ACTIVE_TAB_SET,
    GAME_SOLO_NEW_GAME,
    GAME_TILE_BEING_DRAGGED,
    REDUCER_ON_TILE_REMOVED,
    REDUCER_UPDATE_BLANK_TILE_LETTER,
    UPDATE_TILES_AND_SET_CELL,
} from './configs/ActionIdentifiers';
import { connect } from 'react-redux';
import log from 'loglevel';
import StandardButton from './component/StandardButton';
import TooltipWrapper from './component/TooltipWrapper';
import PText from './component/PText';
import S14Text from './component/S14Text';
import LayoutUtils from './utils/LayoutUtils';
import TooltipActionWrapper from './utils/TooltipActionWrapper';
import MenuButton from './component/MenuButton';
import ServiceWrapper from './utils/ServiceWrapper';
import rjAnalytics from './RJAnalytics';

const eventBus = require('js-event-bus')();

//const BOARD_MAX_SIZE = 750;

export function addUpdateRack({
    gameId = get(this.props, 'game.gid'),
    pid = get(this.props, 'game.pid'),
    guid = get(this.props, 'game.guid'),
    channel = get(this.props, 'game.channel'),
    rack,
} = {}) {
    try {
        let rackObj = {
            gameId,
            pid,
            guid,
            channel,
            rack,
        };
        reactLocalStorage.setObject(gameId, rackObj);
    } catch (error) {
        ServiceWrapper.handleCrashReport(error);
    }
}

function getRack({ gameId = get(this.props, 'game.gid') } = {}) {
    let rack = undefined;
    try {
        let res = reactLocalStorage.getObject(gameId);
        rack =
            !!res &&
            res.gameId === get(this.props, 'game.gid') &&
            res.guid === get(this.props, 'game.guid') &&
            res.pid === get(this.props, 'game.pid') &&
            res.channel === get(this.props, 'game.channel')
                ? get(res, 'rack')
                : undefined;
        rack = (rack || []).map((tile) => {
            tile.position = undefined;
            return tile;
        });
    } catch (error) {
        ServiceWrapper.handleCrashReport(error);
    }
    return rack;
}

function rearrangeRack(newRack) {
    let oldRackOrder = getRack.bind({ props: this.props })();

    let newRackLetterFrequencies = rackToLetterFrequencies(newRack);
    let oldRackLetterFrequencies = rackToLetterFrequencies(oldRackOrder);

    let isSame = isEqual(newRackLetterFrequencies, oldRackLetterFrequencies);

    if (isSame) {
        newRack.splice(0, oldRackOrder.length, ...oldRackOrder);
        newRack.length = oldRackOrder.length;
    }
}

function getMoveTilesForMode(mode, result) {
    result = cloneDeep(result);
    switch (mode) {
        case Config.REVEAL_SOLUTION_MODE_SELF:
            return getCurrentMoveTiles.bind({ props: this.props })(result);
        case Config.REVEAL_SOLUTION_MODE_PREVIOUS_PLAYER:
            return getLastMoveTiles.bind({ props: this.props })(result);
        case Config.REVEAL_SOLUTION_MODE_BEST_MOVE:
            return getBestMoveTiles.bind({ props: this.props })(result);
        default:
            throw new Error('Invalid Mode');
    }
}

function getLastMoveTiles(result) {
    let data = get(result, 'data.' + get(this.props, 'game.channel') + '.boarddata.lastmovetiles') || [];
    return GameBoardUtils.appendDataToMoveTileArr([], data);
}

function getCurrentMoveTiles(result) {
    let data = get(result, 'data.' + get(this.props, 'game.channel') + '.boarddata.movetiles') || [];
    if (!is2dArray(data)) data = [data];
    data = data.splice(-1);
    let ret = GameBoardUtils.appendDataToMoveTileArr([], data.flat());
    return ret;
}

function getBestMoveTiles(result) {
    let data = get(get(result, 'data.' + get(this.props, 'game.channel') + '.boarddata.bestmove') || [], '0.movetiles') || [];
    return GameBoardUtils.appendDataToMoveTileArr([], data);
}

const rackToLetterFrequencies = (rack) => {
    let rackFrequencies = {};
    (rack || []).forEach((letter) => {
        let alphabet = '';
        if (letter.letter) alphabet = letter.letter;
        else if (letter.isBlankTile) alphabet = 'blank';
        else if (letter.isEmptySpace) alphabet = 'empty';
        rackFrequencies[alphabet] = (rackFrequencies[alphabet] || 0) + 1;
    });
    return rackFrequencies;
};

const isSingleLetterWordInWordsArray = (words = []) => words.some((word) => word.length < 2);

class Board extends React.Component {
    clearOutputs = getNull;

    constructor(props) {
        super(props);

        this.pan = new Animated.ValueXY({ x: 0, y: 0 });
        this.scale = new Animated.Value(1);
        let container = {
            top: this.props.top,
            left: this.props.left,
            height: this.props.height,
            width: this.props.width,
        };
        this.state = {
            boardAdditionalTopDimension: 0,
            tiles: [],
            tileLength: Config.TILE_MAX_LENGTH,
            suffleBtnColor: ColorConfig.BUTTON_TEXT_COLOR,
            recallBtnColor: ColorConfig.BUTTON_TEXT_COLOR,
            passBtnColor: ColorConfig.BUTTON_TEXT_COLOR,
            swapBtnColor: ColorConfig.BUTTON_TEXT_COLOR,
            ...container,
            gameScoringData: null,
            showAnalyseButtonLoader: false,
            tempTiles: [],
            tileTouch: false,
        };

        let panMoveEvent = Animated.event(
            [
                null,
                {
                    dx: this.pan.x,
                    dy: this.pan.y,
                },
            ],
            {
                useNativeDriver: true,
            }
        );
        this._panResponder = PanResponder.create({
            onMoveShouldSetPanResponder: (e, gesture) => false,
            /* {
                let isClickingDroppedTile = false;
                if (
                    e.nativeEvent.touches &&
                    e.nativeEvent.touches.length === 1
                ) {
                    let droppedTiles = this.getTiles({
                        caller: 'onMoveShouldSetPanResponder',
                    }).filter((tile) => !!tile.position);
                    if (droppedTiles)
                        isClickingDroppedTile = !!get(
                            this.props,
                            'tiles.tileBeingDragged'
                        );
                }
                return (
                    (!isClickingDroppedTile && this.scale._value > 1) ||
                    (e.nativeEvent.touches &&
                        e.nativeEvent.touches.length === 2)
                );
            }*/ onPanResponderGrant: (e, gesture) => {
                this.pan.setOffset({
                    x: this.pan.x._value,
                    y: this.pan.y._value,
                });
                this.pan.setValue({ x: 0, y: 0 });
                if (e.nativeEvent.touches.length === 2) {
                    this.startHypot = Math.hypot(
                        e.nativeEvent.touches[0].pageX - e.nativeEvent.touches[1].pageX,
                        e.nativeEvent.touches[0].pageY - e.nativeEvent.touches[1].pageY
                    );

                    let x =
                        this.props.layout.layoutBoardWidth / 2 -
                        (e.nativeEvent.touches[0].pageX + e.nativeEvent.touches[1].pageX) / 2;
                    let y =
                        this.props.layout.layoutBoardWidth / 2 -
                        (e.nativeEvent.touches[0].pageY + e.nativeEvent.touches[1].pageY) / 2;
                    this.zoomInPoint = {
                        x,
                        y,
                    };
                }
            },
            onPanResponderMove: (e, gesture) => {
                if (e.nativeEvent.touches.length === 2) {
                    this.endHypot = Math.hypot(
                        e.nativeEvent.touches[0].pageX - e.nativeEvent.touches[1].pageX,
                        e.nativeEvent.touches[0].pageY - e.nativeEvent.touches[1].pageY
                    );
                } else if (e.nativeEvent.touches.length === 1 && !this.startHypot) panMoveEvent(e, gesture);
            },
            onPanResponderRelease: (e, gestures) => {
                this.pan.flattenOffset();
                if (ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isMobile') && this.scale._value > 1) {
                    this.adjustXPan();
                    this.adjustYPan();
                }
                if (!isNaN(this.startHypot) && !isNaN(this.endHypot)) {
                    if (this.startHypot > this.endHypot) {
                        this.zoomOut();
                    } else if (this.endHypot > this.startHypot) {
                        if (this.zoomInPoint.x > this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.x = this.props.layout.layoutBoardWidth / 2;
                        } else if (this.zoomInPoint.x < 0 - this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.x = 0 - this.props.layout.layoutBoardWidth / 2;
                        }
                        if (this.zoomInPoint.y > this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.y = this.props.layout.layoutBoardWidth / 2;
                        } else if (this.zoomInPoint.y < 0 - this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.y = 0 - this.props.layout.layoutBoardWidth / 2;
                        }
                        this.scaleAndPanTo(2.0, this.zoomInPoint.x, this.zoomInPoint.y);
                    }
                }
                this.startHypot = undefined;
                this.endHypot = undefined;
                this.zoomInPoint = undefined;
                this.repositionAllTiles();
            },
        });
        //this.moveCount = 0;
    }

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(omit(nextProps, ['cells']), omit(this.props, ['cells'])) || !isEqual(nextState, this.state);

    onNoUser = getNull;

    onFlashOpponentTurnMessage = () => {
        this.setState({ showPlayButtonOverlay: true });
        setTimeout(() => this.setState({ showPlayButtonOverlay: false }), 2000);
    };

    getTiles = ({ includeEmptySpace = false, forRendering = false, caller } = {}) => {
        let currentRackArr = [];
        if (get(this.props, 'game.showingAnalyseMove')) {
            let movesObjs = this.props.game.movesObjs;
            let currentPosition = this.props.game.currPosition;
            let moveObj = (movesObjs || [])[currentPosition];
            currentRackArr = cloneDeep(get(moveObj, 'rackArr'));
        } else if (get(this.props, 'tiles.rackArr')) {
            currentRackArr = cloneDeep(get(this.props, 'tiles.rackArr'));
        } else {
            let players = get(this.props, 'tiles.players');
            let selfPid = get(this.props, 'game.pid');
            let currentTurn = get(this.props, 'game.currentTurn');
            let pidToUse = isString(selfPid) && selfPid.length > 0 ? selfPid : currentTurn;
            let player = (players || []).find((player) => player.pid === pidToUse);
            currentRackArr = cloneDeep(get(player, 'currentRackArr') || []);
        }

        let nonNullTiles = currentRackArr.filter(Boolean);
        if (includeEmptySpace) {
            return nonNullTiles;
        }
        let actualTiles = nonNullTiles.filter((tile) => !tile.isEmptySpace);
        if (forRendering && actualTiles.length > 2) return nonNullTiles;
        return actualTiles;
    };

    adjustXPan = debounce(() => {
        if (this._animatedValueX > this.props.layout.layoutBoardWidth / 2) {
            this.pan.x.setValue(this.props.layout.layoutBoardWidth / 2);
        } else if (this._animatedValueX < 0 - this.props.layout.layoutBoardWidth / 2) {
            this.pan.x.setValue(0 - this.props.layout.layoutBoardWidth / 2);
        }
    }, 100);
    adjustYPan = debounce(() => {
        if (this._animatedValueY > this.props.layout.layoutBoardWidth / 2) {
            this.pan.y.setValue(this.props.layout.layoutBoardWidth / 2);
        } else if (this._animatedValueY < 0 - this.props.layout.layoutBoardWidth / 2) {
            this.pan.y.setValue(0 - this.props.layout.layoutBoardWidth / 2);
        }
    }, 100);

    getContainerDimensions = () => ({
        height: this.props.layout.layoutBoardDimenWidth,
        width: this.props.layout.layoutBoardDimenWidth,
        top: this.state.top,
        left: this.state.left,
    });

    componentDidMount = () => {
        TooltipActionWrapper.rebuild();
        eventBus.on(Config.BOARD_PUZZLE_DATA_READY, this.boardPuzzleReceived);
        eventBus.on(Config.MENU_OPTION_TOGGLED, this.onConfigChange);
        eventBus.on(Config.SEND_PUZZLE_MOVE_SUCCESS, this.onShowPuzzleSolution);
        eventBus.on(Config.GET_ARCHIVED_PUZZLE_SUCCESS, this.onShowPuzzleSolution);
        eventBus.on(Config.PUZZLE_PASS_SUCCESS, this.onShowPuzzleSolution);
        eventBus.on(Config.TEXT_INPUT_FOCUSSED, this.clearDirection);
        eventBus.on(Config.BOARD_SHOW_PUZZLE_SOLUTION, this.onShowPuzzleSolution);
        eventBus.on(Config.START_GAME_REQUEST_ACCEPTED, this.startLiveGame);
        eventBus.on(Config.ACCEPT_GAME_REQUEST_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.DELETE_GAME_EVENT, this.onDeleteGame);
        eventBus.on(Config.DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onDeleteGame);
        eventBus.on(Config.RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onResignGame);
        eventBus.on(Config.SEND_LIVE_GAME_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.SEND_EMAIL_GAME_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.SEND_EMAIL_GAME_PASS_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.RESIGN_GAME_EVENT, this.onResignGame);
        eventBus.on(Config.KEY_PRESS_EVENT_FOR_BOARD, this.onKeyUp);
        eventBus.on(Config.NO_VALID_USER, this.onNoUser);
        eventBus.on(Config.PAGE_VISIBILITY_CHANGED, this.checkAndSetPageTitle);
        eventBus.on(Config.HAS_ACTIVE_GAME_EVENT, this.reloadPageInGameMode);
        eventBus.on(Config.RESIGN_DELETE_GAME, this.onResignDeleteGame);
        eventBus.on(Config.NATIVE_BACK_PRESS_HANDLE, this.backPressHandle);
        eventBus.on(Config.RESIGN_GAME_REQUEST_FAILED, this.resignGameOnFail);
        eventBus.on(Config.DELETE_GAME_REQUEST_FAILED, this.deleteGameOnFail);
        eventBus.on(Config.RESIGN_EMAIL_GAME_REQUEST_FAILED, this.resignGameOnFail);
        eventBus.on(Config.DELETE_EMAIL_GAME_REQUEST_FAILED, this.deleteGameOnFail);
        eventBus.on(Config.UNOBSERVE_GAME_REQUEST_FAILED, this.onRequestFailure);
        eventBus.on(Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.on(Config.GET_HINTS_REQUEST_STARTING, this.onHintRequestStarting);
        eventBus.on(Config.HINT_WORD_SELECTED, this.onHintWordSelected);
        eventBus.on(Config.ANALYSE_DISPLAY_MOVE_RACK, this.onAnalyseDisplayMoveRack);
        eventBus.on(Config.RESET_ANALYSE_HINT, this.onAnalyseDisplayMoveRack);
        eventBus.on(Config.EVENT_SOLO_TIME_OVER_RESIGN, this.resignGameOnAction);
        eventBus.on(Config.UPDATE_MOVE_VALIDITY, this.updateMoveValidityScoreEvent);
        eventBus.on(Config.DISPLAY_LETTER_PICKER, this.displayLetterPickerEvent);
        eventBus.on(Config.EVENT_INP_GAME_OVER, this.checkAndShowWinnerDialog);

        this._animatedValueX = 0;
        this._animatedValueY = 0;
        this.pan.x.addListener((value) => {
            this._animatedValueX = value.value;
        });
        this.pan.y.addListener((value) => {
            this._animatedValueY = value.value;
        });
        EventWrapper.addSdkCompletedEventListener(this.puzzlePassProceed);
        EventWrapper.addRightClickListener(this.onRightClickEvent);
        EventWrapper.addEventTouchListener(this.onTouchListener);
    };

    onTouchListener = (event) => {
        if (this.state.tileTouch) {
            event.preventDefault();
        }
    };

    onHintRequestStarting = () => this.onRecallPressWithSoundControl(false, false);

    onHintWordSelected = (word) => {
        if (get(this.props, 'game.showingAnalyseMove')) {
            log.info('CELL_REDUCER_SET_TILE 001');
            eventBus.emit(CELL_REDUCER_SET_TILE, null, {
                word,
                emptyGameBoard: {
                    nonLockedTilesOnly: true,
                    letRevealSolutionRemain: false,
                    forAnalyseMove: true,
                },
            });
        } else {
            let alreadyPickedTiles = [];
            let tilesPositionsObjs = (word.set || word.movetiles || []).map((letter, index) => {
                let parts = letter.split(',');
                log.info(
                    'in Board, in onHintWordSelected, alreadyPickedTiles is:\n' + JSON.stringify(alreadyPickedTiles, null, 2)
                );
                return {
                    tile: this.placeLetter({
                        letterPressed: parts[2],
                        fromKeyUp: false,
                        forHintWord: true,
                        alreadyPickedTiles,
                        index,
                    }),
                    positionX: Number(parts[1]),
                    positionY: Number(parts[0]),
                };
            });
            this.onTilePlacedHandlerForHintWord(tilesPositionsObjs);
        }
    };

    onConfigChange = () => {
        if (!get(this.props, 'config.tap_to_play')) this.clearDirection();
    };

    setBoardForResult = (moveTilesArr) => {
        this.emptyGameBoard();
        //Render All Move Tiles
        this.setTiles(moveTilesArr, this.lockTile);
    };

    boardPuzzleReceived = () => {
        //let rackArr = get(this.props, "game.rackArr");

        eventBus.emit(GAME_BOARD_PUZZLE_RECEIVED);

        //Render Rack
        this.setState({ lastRendered: Date.now() });

        let moveTilesArr = get(this.props, 'game.moveTilesArr');

        this.setBoardForResult(moveTilesArr);

        //Load Hide
        this.hideOverlay();

        eventBus.emit(Config.SHOW_REVEAL_SOLUTION, null, {
            visible: false,
            results: undefined,
            viewingRemote: Config.REVEAL_SOLUTION_MODE_SELF,
        });

        this.checkAndSetBoardGameplayButtons();
    };

    lockTile = (tile, x, y) => {
        let cell = this.getCell(x, y);
        if (cell) {
            cell.currentTile = tile;
            cell.locked = true;
        }
        return cell;
    };

    onShowPuzzleSolution = (result) => {
        this.hideOverlay();
        let tiles = this.getTiles({ includeEmptySpace: true });
        tiles.forEach((tile) => {
            Object.assign(tile, {
                position: undefined,
                zIndex: undefined,
                opacity: undefined,
                borderWidth: undefined,
                currentLetter: undefined,
            });
        });
        eventBus.emit(GAME_TILE_BEING_DRAGGED, null, {
            unset: true,
            tiles,
            puzzleIsComplete: true,
        });
        let already_attempted = get(this.props, 'game.already_attempted');
        let moveTiles = get(this.props, 'game.moveTilesArr');
        already_attempted && this.setBoardForResult(moveTiles);
        this.onToggleBoard(result, Config.REVEAL_SOLUTION_MODE_SELF);
        result.tileSet = this.getTiles({ caller: 'onShowPuzzleSolution' });
        if (!result.tileSet || result.tileSet.length < 1)
            result.tileSet = getRack
                .bind({ props: this.props })(result)
                .filter((tile) => !tile.isEmptySpace);

        eventBus.emit(Config.SHOW_REVEAL_SOLUTION, null, {
            visible: true,
            results: result,
            viewingRemote: Config.REVEAL_SOLUTION_MODE_SELF,
        });
    };

    onToggleBoard = (result, currentViewingMode) => {
        let lastMode = currentViewingMode - 1;
        lastMode < 0 && (lastMode = Config.REVEAL_SOLUTION_MODE_COUNT - 1);
        let tilesToBeHidden = get(this.props, 'cells.cells')
            .flat(8)
            .filter((cell) => cell.currentTile && cell.currentTile.forRevealSolution)
            .map((cell) => cell.currentTile);
        let tilesToBeShown = getMoveTilesForMode.bind({ props: this.props })(currentViewingMode, result) || [];
        this.setTiles(tilesToBeHidden, this.hideTiles);
        this.setTiles(tilesToBeShown, this.showTiles);
    };

    hideTiles = (tile, x, y) => {
        let cell = this.getCell(x, y);
        if (cell) {
            cell.currentTile = undefined;
            cell.locked = false;
        }
        return cell;
    };

    showTiles = (tile, x, y) => {
        tile.forRevealSolution = true;
        let cell = this.getCell(x, y);
        if (cell) {
            cell.currentTile = tile;
            cell.locked = true;
        }
        return cell;
    };

    setTiles = (moveTilesArr = [], callback) => {
        let cells = [];
        for (let i = 0; i < moveTilesArr.length; i++) {
            let element = moveTilesArr[i];
            let x = element.position.x;
            let y = element.position.y;
            cells.push(callback(element['tile'], x, y));
        }
        log.info('CELL_REDUCER_SET_TILE 002');
        eventBus.emit(CELL_REDUCER_SET_TILE, null, { cells });
    };

    hideOverlay = () => {
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            visible: false,
        });
    };

    emptyGameBoard = ({
        nonLockedTilesOnly = false,
        letRevealSolutionRemain = false,
        letNonLockedTilesRemain = false,
        forAnalyseMove,
    } = {}) =>
        eventBus.emit(CELL_REDUCER_EMPTY_GAMEBOARD, null, {
            nonLockedTilesOnly,
            letRevealSolutionRemain,
            letNonLockedTilesRemain,
            forAnalyseMove,
        });
    onCancel = () => {
        this.setState({
            isOpen: false,
        });
    };

    isLetterSelectionModalVisible = () =>
        this.props.letterSelectorModalRef &&
        this.props.letterSelectorModalRef.current &&
        this.props.letterSelectorModalRef.current.isVisible();

    placeLetter = ({ letterPressed, fromKeyUp, position, forHintWord, alreadyPickedTiles } = {}) => {
        if (!forHintWord)
            if (
                this.props.letterSelectorModalRef &&
                this.props.letterSelectorModalRef.current &&
                this.props.letterSelectorModalRef.current.isVisible()
            ) {
                this.props.letterSelectorModalRef.current.onLetterSelected('' + letterPressed);
                return;
            }

        let unplacedTiles = this.getTiles().filter(
            (tile) =>
                (forHintWord &&
                    !(alreadyPickedTiles || []).some(
                        (alreadyPickedTile) => get(alreadyPickedTile, 'id') === get(tile, 'id')
                    )) ||
                (!forHintWord && !tile.position && !tile.placed)
        );
        //check if regular blank is available
        let unplacedTile = unplacedTiles.find((tile) => tile.letter === '' + letterPressed);

        //if regular tile is not available, check if blank tile is available
        if (!unplacedTile) {
            unplacedTile = unplacedTiles.find((tile) => tile.isBlankTile);
            if (unplacedTile) {
                Object.assign(unplacedTile, this.setCurrentLetter(unplacedTile, letterPressed));
            }
        }

        if (unplacedTile) {
            if (forHintWord) {
                unplacedTile.placed = true;
                alreadyPickedTiles.push(unplacedTile);
                return unplacedTile;
            } else {
                eventBus.emit(CELL_REDUCER_ON_TILE_CLICKED, null, {
                    tileType: unplacedTile,
                    fromKeyUp,
                    position,
                });
            }
        }
    };

    onKeyUp = (event) => {
        if (
            ([Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL].includes(getGameType()) &&
                this.hasGameEnded()) ||
            get(this.props, 'game.showingAnalyseMove')
        )
            return;

        let code = getEventKeyCode(event);
        if (
            (code.startsWith('Key') || code.length === 1) &&
            (this.getCellDirection() ||
                (this.props.letterSelectorModalRef &&
                    this.props.letterSelectorModalRef.current &&
                    this.props.letterSelectorModalRef.current.isVisible())) &&
            !get(this.props, 'tiles.puzzleIsComplete')
        ) {
            let letterPressed = code.charAt(code.length - 1);

            this.placeLetter({ letterPressed, fromKeyUp: true });
        } else if (code.includes('Enter')) {
            if (this.isMyTurn()) this.onPlayPress();
        } else if (code.includes('Escape')) {
            if (this.props.letterSelectorModalRef.current.isVisible()) {
                this.props.letterSelectorModalRef.current.onClose();
            } else if (this.isMoveStarted()) {
                this.onRecallPress();
            }
        } else if (code.includes('Backspace') && this.getCellDirection()) {
            let constantCoordinate =
                this.getCellDirection() === 'x' ? this.getCellDirectionTileY() : this.getCellDirectionTileX();
            let varyingCoordinate =
                this.getCellDirection() === 'x' ? this.getCellDirectionTileX() : this.getCellDirectionTileY();

            let edgeTile = this.getEndTileXYpos();

            if (!constantCoordinate && !varyingCoordinate && edgeTile) {
                constantCoordinate = this.getCellDirection() === 'x' ? edgeTile.y : edgeTile.x;
                varyingCoordinate = this.getCellDirection() === 'x' ? edgeTile.x + 1 : edgeTile.y + 1;
            }
            do {
                let x = this.getCellDirection() === 'x' ? varyingCoordinate : constantCoordinate;
                let y = this.getCellDirection() === 'x' ? constantCoordinate : varyingCoordinate;
                if (this.hasTile(x, y) && !this.isLocked(x, y)) {
                    let direction = this.getCellDirection();
                    eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
                        tileOrTiles: this.getCurrentTile(x, y),
                        direction,
                        position: {
                            x,
                            y,
                        },
                        showArrow: true,
                    });
                    this.panToPositionDebounced(x, y);
                    break;
                }
                varyingCoordinate--;
            } while (varyingCoordinate >= 0);
        }
    };

    getEndTileXYpos = () => {
        let gameBoard = zip(...get(this.props, 'cells.cells'));
        let edgeTile = undefined;
        if (gameBoard) {
            let gameBoardFlat = gameBoard.flat(8);
            let playedTilesCells = gameBoardFlat.filter((cell) => cell.currentTile && !cell.locked);
            if (playedTilesCells.length > 0) {
                edgeTile = {
                    x: playedTilesCells[playedTilesCells.length - 1].tileX,
                    y: playedTilesCells[playedTilesCells.length - 1].tileY,
                };
            }
        }
        return edgeTile;
    };

    hasGameEnded = () => get(this.props, 'game.gameHasEnded');

    isMyTurn = () =>
        String(get(this.props, 'game.currentTurn')) === String(get(this.props, 'game.pid')) ||
        getGameType() === Config.GAME_TYPE_PUZZLE;

    getStyle = () => [
        {
            transform: [
                {
                    translateX: this.pan.x,
                },
                {
                    translateY: this.pan.y,
                },
                {
                    scale: this.scale,
                },
            ],
        },
    ];

    componentWillUnmount = () => {
        eventBus.detach(Config.BOARD_PUZZLE_DATA_READY, this.boardPuzzleReceived);
        eventBus.detach(Config.GET_ARCHIVED_PUZZLE_SUCCESS, this.onShowPuzzleSolution);
        eventBus.detach(Config.MENU_OPTION_TOGGLED, this.onConfigChange);
        eventBus.detach(Config.ACCEPT_GAME_REQUEST_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.START_GAME_REQUEST_ACCEPTED, this.startLiveGame);
        eventBus.detach(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.DELETE_GAME_EVENT, this.onDeleteGame);
        eventBus.detach(Config.RESIGN_GAME_EVENT, this.onResignGame);
        eventBus.detach(Config.DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onDeleteGame);
        eventBus.detach(Config.RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onResignGame);
        eventBus.detach(Config.SEND_LIVE_GAME_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.SEND_EMAIL_GAME_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.SEND_EMAIL_GAME_PASS_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.SEND_PUZZLE_MOVE_SUCCESS, this.onShowPuzzleSolution);
        eventBus.detach(Config.PUZZLE_PASS_SUCCESS, this.onShowPuzzleSolution);
        eventBus.detach(Config.BOARD_SHOW_PUZZLE_SOLUTION, this.onShowPuzzleSolution);
        eventBus.detach(Config.TEXT_INPUT_FOCUSSED, this.clearDirection);
        eventBus.detach(Config.KEY_PRESS_EVENT_FOR_BOARD, this.onKeyUp);
        eventBus.detach(Config.NO_VALID_USER, this.onNoUser);
        eventBus.detach(Config.PAGE_VISIBILITY_CHANGED, this.checkAndSetPageTitle);
        eventBus.detach(Config.HAS_ACTIVE_GAME_EVENT, this.reloadPageInGameMode);
        eventBus.detach(Config.RESIGN_DELETE_GAME, this.onResignDeleteGame);
        eventBus.detach(Config.NATIVE_BACK_PRESS_HANDLE, this.backPressHandle);
        eventBus.detach(Config.RESIGN_GAME_REQUEST_FAILED, this.resignGameOnFail);
        eventBus.detach(Config.DELETE_GAME_REQUEST_FAILED, this.deleteGameOnFail);
        eventBus.detach(Config.RESIGN_EMAIL_GAME_REQUEST_FAILED, this.resignGameOnFail);
        eventBus.detach(Config.DELETE_EMAIL_GAME_REQUEST_FAILED, this.deleteGameOnFail);
        eventBus.detach(Config.UNOBSERVE_GAME_REQUEST_FAILED, this.onRequestFailure);
        eventBus.detach(Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_SUCCESSFUL, this.startLiveGame);
        eventBus.detach(Config.ANALYSE_DISPLAY_MOVE_RACK, this.onAnalyseDisplayMoveRack);
        eventBus.detach(Config.RESET_ANALYSE_HINT, this.onAnalyseDisplayMoveRack);
        eventBus.detach(Config.EVENT_SOLO_TIME_OVER_RESIGN, this.resignGameOnAction);
        eventBus.detach(Config.GET_HINTS_REQUEST_STARTING, this.onHintRequestStarting);
        eventBus.detach(Config.HINT_WORD_SELECTED, this.onHintWordSelected);
        eventBus.detach(Config.UPDATE_MOVE_VALIDITY, this.updateMoveValidityScoreEvent);
        eventBus.detach(Config.DISPLAY_LETTER_PICKER, this.displayLetterPickerEvent);
        eventBus.detach(Config.EVENT_INP_GAME_OVER, this.checkAndShowWinnerDialog);

        EventWrapper.removeSdkCompletedEventListener(this.puzzlePassProceed);
        EventWrapper.removeRightClickListener(this.onRightClickEvent);
        EventWrapper.removeEventTouchListener(this.preventDefault);
        this.pan.x.removeAllListeners();
        this.pan.y.removeAllListeners();
    };

    onAnalyseDisplayMoveRack = ({
        movesObjs = get(this.props, 'game.movesObjs'),
        position = get(this.props, 'game.currPosition'),
    } = {}) => {
        this.emptyGameBoard({
            nonLockedTilesOnly: false,
            letRevealSolutionRemain: false,
            forAnalyseMove: true,
        });
        let movesObj;
        for (let i = 0; i <= position; i++) {
            movesObj = movesObjs[i];
            let move = movesObj.move;
            let isLastItem = i === position;
            let moveTilesArr = (move || []).map((moveStr) => {
                let moveParts = moveStr.split(',');
                return {
                    tile: GameBoardUtils.tileCreation(moveParts[3], isLastItem),
                    position: {
                        x: Number(moveParts[2]),
                        y: Number(moveParts[1]),
                    },
                };
            });
            this.setTiles(moveTilesArr, this.lockCurrentTileToCell);
            if (isLastItem) {
                this.setRack({ rack: movesObj.rack, forAnalyse: true });
            }
        }
    };

    onRequestFailure = () => {
        createGeneralRequestFailureDialog();
    };

    checkAndSetPageTitle = (isVisible = get(this.props, 'game.isPageVisible')) => {
        if (!isVisible && this.isMyTurn() && [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(getGameType())) {
            DocumentWrapper.setDocumentTitle('Your Turn');
        } else {
            let title = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('initialPageTitle');
            if (get(this.props, 'game.onProNext')) {
                title = 'Game #' + get(this.props, 'game.gid') + ' Lexulous';
            }
            DocumentWrapper.setDocumentTitle(title);
        }
    };

    getIsGameMultiplayer = () => (get(this.props, 'game.players') || []).length > 2;

    onDeleteGame = () => {
        let guid = get(this.props, 'game.gameDeleterGuid') || get(this.props, 'game.guid');
        let isObserver = LiveGamePlayUtils.isObserving();
        let isMyself = guid === get(this.props, 'game.guid');
        let reason = get(this.props, 'game.gameover_reason');
        let opponent = (
            (get(this.props, 'game.players') || []).filter((player) => player.guid !== get(this.props, 'game.guid')) || []
        ).find((oppInArr) => oppInArr.guid === guid);
        this.getAndSetCurrentTurn();
        let isMultiPlayer = this.getIsGameMultiplayer();

        createDialogInstance({
            title: 'Game Deleted',
            actionButtonText: isObserver || isMultiPlayer ? 'OK' : 'REMATCH',
            onAction: getNull,
            body: GameBoardUtils.getDeleteReasonText({
                gameover_reason: reason,
                isMyself,
                opponentName: formatName(get(opponent, 'name')),
            }),
            notDismissable: true,
            isConfirmableByKey: true,
            cancelButtonText: isObserver || isMultiPlayer ? undefined : 'REMATCH',
            dialogType: isObserver || isMultiPlayer ? undefined : Config.DIALOG_TYPE_REMATCH,
            hideCancel: isObserver || isMultiPlayer,
            isMultiPlayer,
        });
        this.setPlayToClose();
        SoundUtils.gameStartSound();
    };

    onResignGame = (data) => {
        if (LiveGamePlayUtils.hasGameEnded()) this.checkAndShowWinnerDialog();
        else this.startLiveGame(data);
    };

    getSelfScore = (data) => GameBoardUtils.getCurrentScore(GameBoardUtils.getSelf(data));

    getPlayerOnePid = (data) => GameBoardUtils.getPid(GameBoardUtils.getPlayerAtPosition(data, 0));

    getPlayerOneName = (data) => GameBoardUtils.getName(GameBoardUtils.getPlayerAtPosition(data, 0));

    getPlayerOneScore = (data) => GameBoardUtils.getCurrentScore(GameBoardUtils.getPlayerAtPosition(data, 0));

    getPlayerOneTileValue = (data) => GameBoardUtils.evaluateRackTotalValue(GameBoardUtils.getPlayerOneRack(data));

    getPlayerOneResign = (data) => GameBoardUtils.isResigned(GameBoardUtils.getPlayerAtPosition(data, 0));

    checkAndShowWinnerDialog = ({ isSelf = false, noGameOverSound = false, setTurn = true, resigner } = {}) => {
        log.info('in Board, in checkAndShowWinnerDialog');
        this.setState({ tempTiles: [] });
        this.setTileTouchStatus(false);

        let winner = get(this.props, 'game.winner');
        if (setTurn) this.getAndSetCurrentTurn();
        let selfPid = get(this.props, 'game.pid');
        let isObserver = !selfPid;
        let myself = isObserver ? null : get(this.props, 'game.players').find((player) => player.pid === selfPid);
        let firstPlayer = isObserver ? get(this.props, 'game.players.0') : null;
        let playerToQuery = isObserver ? firstPlayer : myself;

        let playersInCurrentData = get(this.props, 'game.players') || [];

        let isPlayerResigned =
            get(this.props, 'game.players').some((player) => get(player, 'resigned') === 'y') ||
            !!get(this.props, 'game.gameDeleterGuid');

        log.info('in Board, in checkAndShowWinnerDialog, winner is:\n' + JSON.stringify(winner, null, 2));

        if (isArray(winner)) {
            let isGameDrawn = winner.length > 1;
            let playerScoreData = [];
            let selfObj = {};
            selfObj.pid = isObserver ? get(firstPlayer, 'pid') : get(this.props, 'game.pid');
            selfObj.playerName = get(playerToQuery, 'name');
            selfObj.playerGrossScore = GameBoardUtils.getCurrentScore(playerToQuery, 'scoresInGame');
            selfObj.playerRack = GameBoardUtils.getRack(playerToQuery);
            selfObj.playerTileValue = GameBoardUtils.evaluateRackTotalValue(selfObj.playerRack);
            selfObj.isResigned = GameBoardUtils.isResigned(playerToQuery);
            playerScoreData.push(selfObj);

            let isWinner = !isGameDrawn && winner.includes(get(playerToQuery, 'pid'));
            let isSelfResign = selfObj.isResigned;
            let isMultiPlayer = (get(this.props, 'game.players') || []).length > 2;

            playersInCurrentData.forEach((player, index) => {
                if ((!isObserver && player.pid !== get(this.props, 'game.pid')) || (isObserver && index !== 0)) {
                    let playerObj = {};
                    playerObj.pid = player.pid;
                    playerObj.playerName = GameBoardUtils.getName(player);
                    playerObj.playerGrossScore = GameBoardUtils.getCurrentScore(player);
                    playerObj.playerRack = GameBoardUtils.getRack(player);
                    playerObj.playerTileValue = GameBoardUtils.evaluateRackTotalValue(playerObj.playerRack);
                    playerObj.isResigned = GameBoardUtils.isPlayerResigned(player);
                    playerScoreData.push(playerObj);
                }
            });

            let opponent =
                isWinner || isGameDrawn ? playerScoreData[1] : playerScoreData.find((player) => winner.includes(player.pid));

            let scoringData = playerScoreData.filter((playerInScoreData) => !playerInScoreData.isResigned);

            let gameover_reason = get(this.props, 'game.gameover_reason') || '';

            let isResign = gameover_reason.toLowerCase().includes('resign');
            let isSoloSingle = isSoloGame() && get(this.props, 'game.sourceType') !== 'robot';
            let isArchiveGameView = isEmailGame() && get(this.props, 'game.archiveGameView');

            let bestMoves = LiveGamePlayUtils.getBestMoves();
            let winReasonText = GameBoardUtils.getWinReasonText({
                gameover_reason,
                isGameDrawn,
                isWinner,
                isObserver,
                selfName: formatName(selfObj.playerName),
                selfScore: selfObj.playerGrossScore,
                opponentScore: opponent ? opponent.playerGrossScore : null,
                opponentName: formatName(opponent ? opponent.playerName : null),
                isSelfResign,
                isMultiPlayer,
                isSoloSingle,
                isSoloGame: isSoloGame(),
                myBestMoves: bestMoves.myBestMoves || 0,
                oppBestMoves: bestMoves.oppBestMoves || 0,
                totalMoves: this.props.game.moveListCompleteData.length,
                isArchiveGameView,
            });
            let gameReqMessage = getGameRequestText({
                gameover_reason,
                isObserver,
                opponentName: formatName(opponent ? opponent.playerName : null),
                isMultiPlayer,
                isSoloSingle,
                isArchiveGameView,
            });
            this.setPlayToClose();

            createDialogInstance({
                title: 'Game Over',
                actionButtonText: isObserver || isArchiveGameView || isMultiPlayer ? 'OK' : 'REMATCH',
                onAction: getNull,
                body: winReasonText,
                notDismissable: true,
                isConfirmableByKey: true,
                cancelButtonText: isObserver || isArchiveGameView || isMultiPlayer ? undefined : 'REMATCH',
                dialogType: isObserver || isArchiveGameView ? undefined : Config.DIALOG_TYPE_REMATCH,
                hideCancel: isObserver || isArchiveGameView || isMultiPlayer,
                scoringData,
                isResign,
                isMultiPlayer,
                gameReqMessage,
            });
            if (!noGameOverSound)
                (isWinner && !isObserver && !isArchiveGameView ? SoundUtils.userWinsGame : SoundUtils.gameStartSound)();

            if (isResign) {
            } else {
                this.setState({ gameScoringData: scoringData });
            }
        } else if (this.hasGameEnded()) {
            if (this.props.game.game_type === Config.GAME_TYPE_BLITZ) {
                let blitz_players = get(this.props, 'game.blitz_players');
                let isWinner = get(blitz_players, '0.guid') === get(this.props, 'game.guid');
                let opponentScore = isWinner ? get(blitz_players, '1.score') || '0' : get(blitz_players, '0.score');
                let selfScore = get(get(this.props, 'game.players'), '0.current_score');
                let bestMoves = LiveGamePlayUtils.getBestMoves();
                let winReasonText = GameBoardUtils.getWinReasonText({
                    gameover_reason: get(this.props, 'game.gameover_reason'),
                    isBlitzGame: true,
                    isWinner,
                    selfScore,
                    opponentScore,
                    myBestMoves: bestMoves.myBestMoves || 0,
                    totalMoves: this.props.game.moveListCompleteData.length,
                });
                this.setPlayToClose();
                createDialogInstance({
                    title: 'Game Over',
                    actionButtonText: 'OK',
                    onAction: getNull,
                    body: winReasonText,
                    notDismissable: true,
                    isConfirmableByKey: true,
                    hideCancel: true,
                });
            } else if (isPlayerResigned) {
                let winReasonText = GameBoardUtils.getWinReasonText({
                    gameover_reason: get(this.props, 'game.players.0.reason') || get(this.props, 'game.gameover_reason'),
                    isSelfResign: true,
                    selfScore: get(this.props, 'game.playerSelfCurrentScore'),
                    isMultiPlayer: true,
                });
                this.setPlayToClose();
                createDialogInstance({
                    title: 'Game Over',
                    actionButtonText: 'OK',
                    onAction: getNull,
                    body: winReasonText,
                    notDismissable: true,
                    isConfirmableByKey: true,
                    hideCancel: true,
                });
            }
        }
    };

    setPlayToClose = () => {
        !this.hasGameEnded() && this.setState({ currentTurn: Config.GAME_OVER });
        this.hideAllTiles();
        this.clearOutputs();
        this.emptyGameBoard({
            nonLockedTilesOnly: true,
            letRevealSolutionRemain: this.hasGameEnded(),
        });
        this.clearDirection();
    };

    hideAllTiles = () => {
        let tiles = this.getTiles({ caller: 'hideAllTiles' }) || [];
        tiles.forEach((tile) => (tile.locked = true));
        this.updateTiles(tiles, 'hideAllTiles');
        this.repositionAllTiles();
    };

    onGoToNextLocation = async () => {
        eventBus.emit(GAME_SHOW_PLAY_BUTTON_LOADER, null, {
            visible: true,
            backgroundColor: ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
            loaderColor: ColorConfig.NEXT_BUTTON_LOADER_COLOR,
        });
        let isProUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isProUser');
        let isRNWeb = !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb');
        let nextGameUrl = await to(getNextGameUrl(isProUser || isRNWeb));
        if (isProUser || isRNWeb || DimensionUtils.isNative()) {
            eventBus.emit(CHAT_CLEAR_LIST);
            if (get(nextGameUrl, '1.data')) {
                if (!isRNWeb) {
                    proChangeUrl(get(nextGameUrl, '1.data.gid'));
                }
                this.reloadPage({
                    ...get(nextGameUrl, '1.data'),
                    caller: 'onGoToNextLocation',
                });
            } else {
                if (isRNWeb || DimensionUtils.isNative()) {
                    this.props.gameBoardGoBack && this.props.gameBoardGoBack();
                } else {
                    replaceLocation(ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('email_games_homepage'));
                }
            }
        } else {
            replaceLocation(
                !!nextGameUrl[1]
                    ? nextGameUrl[1]
                    : ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('email_games_homepage')
            );
            nextGameUrl[0] && this.hideOverlay();
        }
    };

    setPlayButton = () => {
        this.checkAndSetBoardGameplayButtons();
    };

    getAndSetCurrentTurn = (doSetState = true, forFailure = false) => {
        let currentTurn = undefined;

        if (forFailure) {
            currentTurn = Number(get(this.props, 'game.pid'));
        } else {
            currentTurn = Number(get(this.props, 'game.currentTurn'));
        }

        if (isNaN(Number(currentTurn)) || Number(currentTurn) < 1) {
            currentTurn = Config.GAME_OVER;
        }

        if (doSetState) {
            this.setState({ currentTurn });
        }
        return currentTurn;
    };

    setRack = ({ rack, action, currentTurn, forAnalyse } = {}) => {
        let rackArr = getRackData(rack, forAnalyse);
        if (isEmailGame() && [Config.GAME_FEED_REPSONSE_ACTION].includes(action)) {
            rearrangeRack.bind({ props: this.props })(rackArr);
        }
        this.setState({
            ...(!isNaN(currentTurn) && { currentTurn }),
        });
        return rackArr;
    };

    startLiveGame = async ({ action, piggyback, extcode, data, nextLocation }) => {
        let moveTiles = get(this.props, 'game.moveTiles');

        let removeMoveTiles = [];

        let players = get(this.props, 'game.players');

        let myself = players.find((player) => player.guid === get(this.props, 'game.guid'));

        log.info('in Board, in startLiveGame, get(this.props, "game.brdtype") is: ' + get(this.props, 'game.brdtype'));

        if (this.hasGameEnded()) {
            if (!!data && !get(data, get(this.props, 'game.channel') + '.winner')) {
                log.info('in Board,  in startLiveGame, in startLiveGame, returning');
                return this.reloadPage({
                    gameRestartData: { action, extcode, data },
                    caller: 'startLiveGame_' + action,
                });
            } else {
                this.setPlayToClose();
                log.info(
                    'in Board.startLiveGame, in startLiveGame, about to show winner dialog, data is:\n' +
                        JSON.stringify(data, null, 2)
                );
                this.checkAndShowWinnerDialog();
                if (get(this.props, 'game.brdtype') !== 'ARCHIVEGAMEFEED') {
                    log.info('in Board, in startLiveGame, returning');
                    //return;
                    moveTiles = moveTiles.slice(moveTiles.length - 1, moveTiles.length);
                }
            }
        }

        let currentTurn = get(this.props, 'game.currentTurn');
        let previousTurn = get(this.props, 'game.previousTurn');

        let isGameFeed = action === Config.GAME_FEED_REPSONSE_ACTION;
        let isObserve = action === Config.OBSERVE_GAME_RESPONSE_ACTION;
        let isChallenge = action === Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION;

        let hasGameEnded = this.hasGameEnded();

        let letRevealSolutionRemain = !isLiveGame() && !isEmailGame() && hasGameEnded;

        log.info('in Board, in startLiveGame, letRevealSolutionRemain is:' + letRevealSolutionRemain);

        let placedTiles = this.getTiles().filter((tile) => tile.position);

        let letNonLockedTilesRemain = !LiveGamePlayUtils.isObserving();

        if (letNonLockedTilesRemain) {
            let moveTilesFlat = moveTiles.flat(8);

            for (let i = 0; i < placedTiles.length; i++) {
                let tile = placedTiles[i];

                for (let j = 0; j < moveTilesFlat.length; j++) {
                    let moveTile = moveTilesFlat[j];

                    let moveTileObj = moveTile.split(',');

                    letNonLockedTilesRemain =
                        Number(moveTileObj[1]) !== tile.position.y || Number(moveTileObj[2]) !== tile.position.x;

                    if (!letNonLockedTilesRemain) {
                        break;
                    }
                }
                if (!letNonLockedTilesRemain) {
                    break;
                }
            }
        }

        this.emptyGameBoard({
            nonLockedTilesOnly: true,
            letRevealSolutionRemain,
            letNonLockedTilesRemain,
        });

        if (Config.PLAY_WORD_FORMED_SOUND_ACTIONS.includes(action) && !piggyback) {
            let soundFunc = isEmailGame() && !myself ? SoundUtils.userSubmits : SoundUtils.oppSubmits;
            if (action === 'move') {
                let moveTileCount = get(moveTiles, '0.length');
                if (moveTileCount >= Config.BINGO_TILES_COUNT) soundFunc = SoundUtils.bingoSound;
            }
            soundFunc();
        }

        log.info('in Board, in startLiveGame, about to make moveTilesArr 4');

        let othersArr = players.filter((player) => !(player.guid === get(this.props, 'game.guid')));
        let opponents =
            (get(this.props, 'game.players') || []).filter((player) => player.guid !== get(this.props, 'game.guid')) || [];
        if (!opponents || opponents.length < 1) {
            opponents = othersArr;
        } else {
            othersArr.forEach((playerInOthersArr) => {
                let playerInOpponents = opponents.find((player) => {
                    let isSame = String(player.pid) === String(playerInOthersArr.pid);
                    return isSame;
                });
                if (!playerInOpponents) {
                    opponents.push(playerInOthersArr);
                } else {
                    Object.assign(playerInOpponents, playerInOthersArr);
                }
            });
        }

        let currentTurnPlayer = get(this.props, 'game.players').find(
            (player) => player.pid === get(this.props, 'game.currentTurn')
        );

        log.info('in Board, in startLiveGame, about to make moveTilesArr 3');

        if (!get(myself, 'currentrack')) {
            let isObserver = !get(this.props, 'game.pid');
            this.setState({
                currentTurn,
                ...(isObserver
                    ? {
                          tiles: getRackData(get(currentTurnPlayer, 'currentrack') || ''),
                      }
                    : {}),
            });
            this.checkPlayerIdForPlayButtonSet(currentTurn);
        }

        this.checkAndSetBoardGameplayButtons();

        log.info('in Board, in startLiveGame, about to make moveTilesArr 2');

        if (GameBoardUtils.isChallengeMode()) {
            //Check and Show Challenge Overlay
            let wordsPlayed = get(this.props, 'game.wordsPlayed');
            let lastWordPlayedElement = wordsPlayed[wordsPlayed.length - 1];
            let lastWordPlayedElementArr = lastWordPlayedElement && JSON.stringify(lastWordPlayedElement).split(',');
            if (
                this.isMyTurn() &&
                wordsPlayed.length > 0 &&
                !(lastWordPlayedElementArr[3] === 's') &&
                !(lastWordPlayedElementArr[3] === 'p') &&
                moveTiles[moveTiles.length - 1].length > 0
            ) {
                this.setState({
                    challengeViewVisible: true,
                });
            }
        }

        log.info('in Board, in startLiveGame, about to make moveTilesArr 1');

        let moveTilesArr = createMoveTilesArr({
            data: moveTiles,
            forRevealSolution:
                action === Config.SEND_LIVE_GAME_MOVE_DATA_RESPONSE_ACTION || action === Config.RESIGN_GAME_ACTION,
            isGameFeed,
            isObserve,
        });

        log.info('in Board, in startLiveGame, moveTilesArr is:\n' + JSON.stringify(moveTilesArr, null, 2));
        log.info(
            'in Board, in startLiveGame, GameBoardUtils.isChallengeMode() is:\n' +
                JSON.stringify(GameBoardUtils.isChallengeMode(), null, 2)
        );

        if (GameBoardUtils.isChallengeMode()) {
            if (isChallenge) {
                this.setState({
                    challengeViewVisible: false,
                });

                let turnChanged = currentTurn !== previousTurn || false;
                let myTurn = currentTurn === get(this.props, 'game.pid') || false;
                let wasMyTurn = previousTurn === get(this.props, 'game.pid');

                let isMultiplayerGame = (get(this.props, 'game.players') || []).length > 2;

                log.info(
                    `in Board, in startLiveGame, currentTurn is ${currentTurn}, previousTurn is ${previousTurn}, turnChanged is ${turnChanged}, myTurn is ${myTurn}, wasMyTurn is ${wasMyTurn}`
                );
                log.info(`in Board, in startLiveGame, moveTilesArr is:\n${JSON.stringify(moveTilesArr, null, 2)}`);
                log.info(`in Board, in startLiveGame, turnChanged is:\n${JSON.stringify(turnChanged, null, 2)}`);

                if (!turnChanged) {
                    log.info(`in Board, in startLiveGame, removing tiles from board`);
                    this.setTiles(moveTilesArr, this.hideTiles);
                    if (!LiveGamePlayUtils.isObserving()) {
                        if (!myTurn) {
                            createDialogInstance({
                                title: 'Move Challenged',
                                actionButtonText: 'OK',
                                onAction: getNull,
                                body: isMultiplayerGame
                                    ? "The word played in the last move was challenged by your opponent has been removed from the board for being invalid.\nIt is now your opponent's turn."
                                    : "The word played by you was challenged by your opponent has been removed from the board for being invalid.\nIt is now your opponent's turn.",
                                hideCancel: true,
                                isConfirmableByKey: true,
                            });
                        } else {
                            createDialogInstance({
                                title: 'Challenge Successful!',
                                actionButtonText: 'OK',
                                onAction: getNull,
                                body: isMultiplayerGame
                                    ? 'The word played by your opponent has been removed from the board.\nIt is now your turn.'
                                    : 'The word played in the last move has been removed from the board.\nIt is now your turn.',
                                hideCancel: true,
                                isConfirmableByKey: true,
                            });
                        }
                        return;
                    }
                } else if (!LiveGamePlayUtils.isObserving()) {
                    if (!wasMyTurn && myTurn) {
                        createDialogInstance({
                            title: 'Its your turn!',
                            actionButtonText: 'OK',
                            onAction: getNull,
                            body: isMultiplayerGame
                                ? 'The word in the last move was wrongly challenged by your opponent.\nIt is now your turn.'
                                : 'The word played by you was wrongly challenged by your opponent.\nIt is now your turn.',
                            hideCancel: true,
                            isConfirmableByKey: true,
                        });
                    } else {
                        createDialogInstance({
                            title: 'Challenge Failed!',
                            actionButtonText: 'OK',
                            onAction: getNull,
                            body: isMultiplayerGame
                                ? 'The word played in the last move' +
                                  (!wasMyTurn ? ' was challenged but' : '') +
                                  " was acceptable.\nIt is now your opponent's turn."
                                : "The word played by your opponent was acceptable.\nYou have lost this turn, it is now your opponent's turn.",
                            hideCancel: true,
                            isConfirmableByKey: true,
                        });
                    }
                }
            } else if (action === Config.SEND_LIVE_GAME_MOVE_DATA_RESPONSE_ACTION) {
                this.setState({
                    lastMoveBeforeChallenge: lastArrayElement(moveTiles || []),
                });
            } else if (isGameFeed) {
                this.setState({
                    lastMoveBeforeChallenge: lastArrayElement(moveTiles || []),
                });
                let removeMoveArr = createMoveTilesArr({
                    data: [removeMoveTiles],
                });
                this.setTiles(removeMoveArr, this.hideTiles);
            }
        }

        //Render All Move Tiles
        if (!isChallenge) this.setTiles(moveTilesArr, this.lockCurrentTileToCell);
        //this.moveCount = this.moveCount + moveTiles.length;

        await this.clearDirection();

        if (isGameFeed && this.hasGameEnded() && isEmailGame() && !get(this.state, 'firstGameFeedDone')) {
            let noGameOverSound = true;
            await this.checkAndShowWinnerDialog({
                isSelf: false,
                noGameOverSound,
                setTurn: false,
            });
        } else {
            let players = get(this.props, 'game.players');
            await this.checkAndShowWinnerDialog({
                isSelf: undefined,
                noGameOverSound: players.length > 2 ? undefined : true,
                setTurn: false,
            });
        }

        if (isGameFeed) {
            if (!get(this.state, 'firstGameFeedDone')) this.setState({ firstGameFeedDone: true });
        }

        this.checkAndSetPageTitle();
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'Board.startLiveGame',
            visible: false,
        });
    };

    getCell = (x, y) => cloneDeep(get(this.props, `cells.cells.${x}.${y}`));

    lockCurrentTileToCell = (tile, x, y) => {
        let cell = this.getCell(x, y);
        if (cell) {
            cell.currentTile = tile;
            cell.locked = true;
        }
        return cell;
    };

    checkPlayerIdForPlayButtonSet = () => {
        if (LiveGamePlayUtils.isPlaying()) {
            this.setPlayButton({ enable: this.isMyTurn() });
        } else {
            //There is no "myself" and the pid was not set, so assuming that is a observe game
            this.setPlayButton({ enable: true, isForUnobserve: true });
        }
    };

    onResignDeleteGame = (data) => {
        let firstRound = get(this.props, 'game.moveListCompleteData.0') || {};
        let firstRoundKeys = Object.keys(firstRound) || [];
        return firstRoundKeys.length >= Number((get(this.props, 'game.players') || []).length) ||
            this.props.game.game_type === Config.GAME_TYPE_BLITZ
            ? this.resignGameButtonPress(data)
            : this.deleteGameButtonPress(data);
    };

    isFirstTileDropped = () =>
        (this.getTiles({ caller: 'isFirstTileDropped' }) || []).every((tile) => !this.isDroppedTile(tile));

    isDroppedTile = (tile, { position = false } = {}) => {
        let cell = (get(this.props, 'cells.cells') || [])
            .flat(8)
            .find((cell) => get(cell, 'currentTile.id') === get(tile, 'id'));
        if (position) {
            let ret = !!cell ? { x: cell.tileX, y: cell.tileY } : undefined;
            return ret;
        }
        return !!cell;
    };

    displayLetterPicker = (tile, cell) =>
        this.props.letterSelectorModalRef.current.show(
            () => {
                eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
                    tileOrTiles: tile,
                });
            },
            (letter) => {
                if (this.isDroppedTile(tile)) {
                    tile.currentLetter = letter;
                    tile.position = { x: cell.tileX, y: cell.tileY };
                    cell.currentTile = tile;
                    eventBus.emit(REDUCER_UPDATE_BLANK_TILE_LETTER, null, {
                        cell,
                        tile,
                        locked: false,
                    });
                }
            }
        );

    setCurrentLetter = (tile, letter, skipUpdateCall = false) => {
        let tileInTiles = null;
        if (tile) {
            let tiles = this.getTiles({
                caller: 'setCurrentLetter',
                includeEmptySpace: true,
            });
            tileInTiles = tiles.find((tileInTilesTemp) => get(tileInTilesTemp, 'id') === get(tile, 'id'));
            if (!!tileInTiles) tileInTiles.currentLetter = letter;
            if (!skipUpdateCall) this.updateTiles(tiles, 'setCurrentLetter');
        }
        return tileInTiles;
    };

    panToPosition = (x, y) => {
        if (get(this.props, 'config.autozoom') && this.scale._value > 1) {
            let boardSize = this.props.game.board_size;
            let cell = get(this.props, 'layout.cellDimensions')
                .flat(8)
                .find((cell) => cell.tileX === x && cell.tileY === y);
            let yPos =
                this.props.layout.layoutBoardWidth / 2 -
                (cell.tileStartYUnscaledUnoffset + Math.round(y / boardSize) * this.props.layout.cellDimen);
            let xPos =
                this.props.layout.layoutBoardWidth / 2 -
                (cell.tileStartXUnscaledUnoffset + Math.round(x / boardSize) * this.props.layout.cellDimen);
            this.scaleAndPanTo(2, xPos, yPos);
        }
    };

    render = () => {
        return LayoutWrapper.isSafariMobile() ? this.renderSafariMobile() : this.renderCommon();
    };

    renderSafariMobile = () => (
        <LongPress time={500} onLongPress={EventWrapper.onLongPressInSafariMobile}>
            {this.renderCommon()}
        </LongPress>
    );

    static getRackStartMargin = () =>
        get(this.props, 'layout.layoutBoardLeft') +
        get(this.props, 'layout.layoutBoardWidth') * 0.1 +
        get(this.props, 'layout.layoutCellDimen') * 2;

    getButtonAndRackContainerPaddingRightObj = () => ({
        paddingRight: get(this.props, 'layout.layoutRackStartMargin') + get(this.props, 'layout.layoutTileMarginInRack'),
    });

    getButtonFontSizeObj = () => ({
        fontSize: this.getButtonStyles().fontSize,
    });

    getPlayButtonContainerStyles = () => ({
        height: this.getButtonStyles().height,
        marginLeft: this.getButtonStyles().height * 0.1,
        marginRight: get(this.props, 'game.gameover_reason') ? 5 : 0,
    });

    getButtonStyles = () => ({
        width: get(this.props, 'layout.cellDimen') + 2 * (get(this.props, 'layout.cellDimen') / 3.5),
        height: Math.min(this.props.layout.layoutCellDimen, this.props.layout.layoutRackContainerHeight * 0.8),
        fontSize: get(this.props, 'layout.cellDimen') / 2.3,
        minWidth: get(this.props, 'layout.cellDimen') + 2 * (get(this.props, 'layout.cellDimen') / 3.5),
        paddingHorizontal: (get(this.props, 'layout.cellDimen') + 2 * (get(this.props, 'layout.cellDimen') / 3.5)) * 0.1,
    });

    getAnalyseButtonStyles = () => ({
        // width: LayoutUtils.getButtonStyles().width * 1.4,
        height: DimensionUtils.isMobile() ? '84%' : this.getButtonStyles().height,
        paddingHorizontal: Config.SIDE_PANEL_WRAPPER_PADDING / 2,
    });

    getScoringButtonStyles = () => ({
        // width: get(this.props, "layout.cellDimen") * 1.8,
        height: DimensionUtils.isMobile() ? '84%' : this.getButtonStyles().height,
        paddingHorizontal: Config.SIDE_PANEL_WRAPPER_PADDING / 2 - 1,
    });

    getBelowBoardContainerStyles = () => ({
        width: this.props.layout.layoutBoardWidth,
        top: this.state.top + this.props.layout.layoutBoardWidth,
        left: this.state.left,
    });

    getCommonButtonDimension = ({ noMinWidth } = {}) => ({
        minHeight: get(this.props, 'layout.layoutCellDimen'),
        ...(noMinWidth ? {} : { minWidth: get(this.props, 'layout.layoutCellDimen') }),
        paddingLeft: get(this.props, 'layout.layoutCellDimen') / 4.5,
    });

    getSmallerCommonButtonDimension = ({ noMinWidth } = {}) => ({
        height: get(this.props, 'layout.layoutCellDimen') * 0.75,
        ...(noMinWidth ? {} : { width: get(this.props, 'layout.layoutCellDimen') * 0.75 }),
        paddingLeft: get(this.props, 'layout.layoutCellDimen') / 4.5,
        marginLeft: 12,
        marginRight: 1,
        marginTop: 1,
        marginBottom: 1,
    });

    renderCellsBackground = () => (
        <View style={[styles.boardMobileTileContainer, this.getBelowBoardCellsBackgroundMobileStyle()]} />
    );

    onMenuPress = () => eventBus.emit(Config.SET_SHOW_SIDE_MENU, null, true);

    onInnerMenuPress = () => eventBus.emit(Config.SET_SHOW_INNER_SIDE_MENU, null, true);

    renderMenuButton = () => {
        return (
            <MenuButton
                openMenuHandler={this.props.showMenuPopUp}
                getCellDimenSizeIconStyleObj={this.getCellDimenSizeIconStyleObj}
            />
        );
    };

    renderBottomLayout = () =>
        DimensionUtils.isMobile() ? (
            <View
                key={'bottomLayout'}
                style={[
                    styles.boardButtonsAndRackContainer,
                    styles.bottomBorders,
                    this.getBelowBoardPartMobileStyle(),
                    styles.alignItemCenter,
                    styles.directionRow,
                    { justifyContent: 'space-between' },
                ]}
            >
                {!this.hasGameEnded() ? (
                    <TooltipWrapper
                        key={'shuffleContainer'}
                        onPress={this.shuffleButtonOnPress}
                        onLongPress={this.shuffleButtonOnLongPress}
                        style={[styles.commonButtonMobile, { width: '20%', backgroundColor: 'transparent' }]}
                    >
                        <FontAwesomeIcon
                            id={'shufflebuttonicon'}
                            key={'shufflebuttonicon'}
                            icon={faRandom}
                            size={this.getCellDimenSizeIconStyleObj().fontSize}
                            style={{
                                ...this.getCellDimenSizeIconStyleObj(),
                                color: this.state.suffleBtnColor,
                            }}
                        />
                    </TooltipWrapper>
                ) : null}
                {!this.hasGameEnded() ? (
                    <TooltipWrapper
                        id={'recallContainer'}
                        key={'recallContainer'}
                        style={[styles.commonButtonMobile, { width: '20%', backgroundColor: 'transparent' }]}
                        onPress={this.onRecallPress}
                    >
                        <FontAwesomeIcon
                            id={'recallbuttonicon'}
                            key={'recallbuttonicon'}
                            icon={faUndoAlt}
                            size={this.getCellDimenSizeIconStyleObj().fontSize}
                            style={{
                                ...this.getCellDimenSizeIconStyleObj(),
                                color: this.state.recallBtnColor,
                            }}
                        />
                    </TooltipWrapper>
                ) : null}

                {this.hasGameEnded() &&
                [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_EMAIL].includes(get(this.props, 'game.game_type'))
                    ? [
                          !(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('delete') &&
                          !(get(this.props, 'game.gameover_reason') || '').includes('LIVETIMEOUTNOFIRSTMOVE') &&
                          get(this.props, 'game.pid') &&
                          !get(this.props, 'game.showingAnalyseMove') ? (
                              <StandardButton
                                  key={'analyseButtonContainer'}
                                  style={[
                                      styles.otherBtn,
                                      this.getAnalyseButtonStyles(),
                                      {
                                          //width: 'calc(25% - 8px)',
                                          width: '20%',
                                          marginBottom: 2,
                                      },
                                  ]}
                                  onPress={this.onAnalyseBtnPress}
                                  text={'Analyse'}
                                  textStyle={[styles.otherBtnText, this.getButtonFontSizeObj()]}
                                  loaderVisible={this.state.showAnalyseButtonLoader}
                                  mouseHoverEffect={StandardButtonMouseHoverEffect}
                              />
                          ) : (
                              <View
                                  style={[
                                      {
                                          width: '20%',
                                          backgroundColor: 'transparent',
                                      },
                                  ]}
                                  key={'analyseButtonContainer_empty'}
                              />
                          ),

                          !(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('delete') &&
                          !(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('resign') &&
                          !(get(this.props, 'game.gameover_reason') || '').includes('LIVETIMEOUTNOFIRSTMOVE') ? (
                              <StandardButton
                                  key={'scoringButtonContainer'}
                                  style={[
                                      styles.otherBtn,
                                      this.getScoringButtonStyles(),
                                      {
                                          //width: 'calc(25% - 8px)',
                                          width: '20%',
                                          marginBottom: 2,
                                      },
                                  ]}
                                  onPress={this.onScoringBtnPress}
                                  text={'Scoring'}
                                  textStyle={[styles.otherBtnText, this.getButtonFontSizeObj()]}
                                  mouseHoverEffect={StandardButtonMouseHoverEffect}
                              />
                          ) : (
                              <View
                                  style={[
                                      {
                                          width: '20%',
                                          backgroundColor: 'transparent',
                                      },
                                  ]}
                                  key={'scoringButtonContainer_empty'}
                              />
                          ),
                      ]
                    : null}
                <View
                    id={'playbutton_container'}
                    key={'playbutton_container'}
                    style={[
                        styles.overflowHidden,
                        styles.alignItemCenter,
                        styles.justifyCenter,
                        {
                            width: '40%',
                            height: '100%',
                            paddingHorizontal: 5,
                            paddingBottom: 4,
                            paddingTop: 1,
                            marginRight: 5,
                        },
                    ]}
                >
                    <PlayButton
                        id={'playbutton'}
                        key={'playbutton'}
                        onPlayPress={this.onPlayPress}
                        getTiles={this.getTiles}
                        outputs={this.state.outputs}
                        playButtonText={'Play'}
                    />
                    {this.getGameSpecificButtons()}
                    {this.state.showPlayButtonOverlay ? (
                        <View
                            style={[
                                styles.alignItemCenter,
                                styles.justifyCenter,
                                styles.overflowHidden,
                                StyleSheet.absoluteFill,
                                styles.bottomBackgroundColor,
                            ]}
                            hidden={true}
                            key={'play_button_overlay'}
                        >
                            <PText style={[styles.playButtonOverlayText, LayoutUtils.getCursorPointerStyle()]}>Opp. Turn</PText>
                        </View>
                    ) : null}
                </View>
                {!this.hasGameEnded() ? this.renderMenuButton() : null}
            </View>
        ) : (
            <View
                key={'bottomLayout'}
                style={[
                    styles.boardButtonsAndRackContainer,
                    styles.bottomBorders,
                    this.getBelowBoardPartStyle(),
                    styles.alignItemCenter,
                    styles.directionRow,
                ]}
            >
                <View
                    key={'shuffleRecallContainer'}
                    styles={[
                        {
                            marginRight: get(this.props, 'layout.layoutTileMarginInRack'),
                        },
                        this.getButtonStyles(),
                    ]}
                >
                    {!this.hasGameEnded() ? (
                        <TooltipWrapper
                            key={'shuffleContainer'}
                            onPress={this.shuffleButtonOnPress}
                            onLongPress={this.shuffleButtonOnLongPress}
                            style={[
                                styles.commonButton,
                                styles.shuffleLeftPosition,
                                this.shouldShowRecallButtonContainer()
                                    ? this.getSmallerCommonButtonDimension()
                                    : this.getCommonButtonDimension(),
                            ]}
                            onMouseOver={this.onShuffleBtnIn}
                            onMouseOut={this.onShuffleBtnOut}
                            tooltip={'Left click Shuffle.<br/> Right click A-Z.'}
                            multiline={true}
                        >
                            <FontAwesomeIcon
                                id={'shufflebuttonicon'}
                                key={'shufflebuttonicon'}
                                icon={faRandom}
                                size={
                                    this.shouldShowRecallButtonContainer()
                                        ? this.getSmallerCellDimenSizeIconStyleObj().fontSize
                                        : this.getCellDimenSizeIconStyleObj().fontSize
                                }
                                style={{
                                    ...(this.shouldShowRecallButtonContainer()
                                        ? this.getSmallerCellDimenSizeIconStyleObj()
                                        : this.getCellDimenSizeIconStyleObj()),
                                    color: this.state.suffleBtnColor,
                                }}
                            />
                        </TooltipWrapper>
                    ) : null}
                    {this.shouldShowRecallButtonContainer() ? (
                        <TooltipWrapper
                            id={'recallContainer'}
                            key={'recallContainer'}
                            style={[styles.commonButton, styles.shuffleLeftPosition, this.getSmallerCommonButtonDimension()]}
                            onPress={this.onRecallPress}
                            onMouseOver={this.onRecallBtnIn}
                            onMouseOut={this.onRecallBtnOut}
                            tooltip="Recall"
                        >
                            <FontAwesomeIcon
                                id={'recallbuttonicon'}
                                key={'recallbuttonicon'}
                                icon={faUndoAlt}
                                size={this.getSmallerCellDimenSizeIconStyleObj().fontSize}
                                style={{
                                    ...this.getSmallerCellDimenSizeIconStyleObj(),
                                    color: this.state.recallBtnColor,
                                }}
                            />
                        </TooltipWrapper>
                    ) : null}
                </View>

                {get(this.props, 'game.gameHasEnded') &&
                [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_EMAIL].includes(get(this.props, 'game.game_type')) ? (
                    <Fragment>
                        <View style={styles.marginLeft}></View>
                        {!(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('delete') &&
                        !(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('resign') ? (
                            <StandardButton
                                key={'scoringButtonContainer'}
                                style={[styles.otherBtn, this.getScoringButtonStyles()]}
                                onPress={this.onScoringBtnPress}
                                text={'Scoring'}
                                textStyle={[styles.otherBtnText, this.getButtonFontSizeObj()]}
                                mouseHoverEffect={StandardButtonMouseHoverEffect}
                            />
                        ) : null}
                        {!(get(this.props, 'game.gameover_reason') || '').toLowerCase().includes('delete') &&
                        get(this.props, 'game.pid') &&
                        !get(this.props, 'game.showingAnalyseMove') &&
                        !get(this.props, 'game.archiveGameView') ? (
                            <StandardButton
                                key={'analyseButtonContainer'}
                                style={[styles.otherBtn, this.getAnalyseButtonStyles()]}
                                onPress={this.onAnalyseBtnPress}
                                text={'Analyse'}
                                textStyle={[styles.otherBtnText, this.getButtonFontSizeObj()]}
                                loaderVisible={this.state.showAnalyseButtonLoader}
                                mouseHoverEffect={StandardButtonMouseHoverEffect}
                            />
                        ) : null}
                    </Fragment>
                ) : null}

                <View
                    id={'playbutton_container'}
                    key={'playbutton_container'}
                    style={[
                        styles.overflowHidden,
                        styles.alignItemFlexEnd,
                        styles.justifyFlexEnd,
                        styles.postionAbsolute,
                        this.getPlayButtonContainerStyles(),
                        styles.playButtonRightPosition,
                        get(this.props, 'game.gameover_reason') && styles.closeButtonRightPositionOnGameOver,
                    ]}
                >
                    <PlayButton
                        id={'playbutton'}
                        key={'playbutton'}
                        onPlayPress={this.onPlayPress}
                        getTiles={this.getTiles}
                        outputs={this.state.outputs}
                        playButtonText={'Play'}
                    />
                    {this.getGameSpecificButtons()}
                    {this.state.showPlayButtonOverlay ? (
                        <View
                            style={[
                                styles.alignItemCenter,
                                styles.justifyCenter,
                                styles.overflowHidden,
                                StyleSheet.absoluteFill,
                                styles.bottomBackgroundColor,
                            ]}
                            hidden={true}
                        >
                            <S14Text
                                style={[
                                    StyleSheet.absoluteFill,
                                    styles.playButtonOverlayText,
                                    LayoutUtils.getCursorPointerStyle(),
                                ]}
                            >
                                Opp. Turn
                            </S14Text>
                        </View>
                    ) : null}
                </View>
            </View>
        );

    renderCommon = () => (
        <View key={'boardRootSafeAreaVew'} style={[styles.mainContainer]}>
            {this.renderBottomLayout()}
            {DimensionUtils.isMobile() ? this.renderCellsBackground() : null}
            {this.renderCells()}
            {(!this.hasGameEnded() || !!get(this.props, 'game.showingAnalyseMove')) &&
                this.getTiles({
                    caller: 'render',
                    includeEmptySpace: true,
                }).map((tileType, index) => this.renderTiles(tileType, index, false))}

            {this.getRevealSolutionView()}
            {this.getChallengeView()}
        </View>
    );

    getMenuIconStyleObj = () => ({
        fontSize: get(this.props, 'layout.layoutFontAwesomeIconSize') * 2,
    });

    getReloadButtonPosition = () => ({
        position: 'absolute',
        top: 0,
        right: 0,
    });

    getIconStyleObj = () => ({
        fontSize: get(this.props, 'layout.layoutFontAwesomeIconSize'),
        color: ColorConfig.BUTTON_TEXT_COLOR,
    });

    getCellDimenSizeIconStyleObj = () => ({
        fontSize: get(this.props, 'layout.layoutCellDimen') * Config.ICON_SIZE_CELL_DIMEN_MULTIPLIER,
    });

    getSmallerCellDimenSizeIconStyleObj = () => ({
        fontSize: Math.round(get(this.props, 'layout.layoutCellDimen') * Config.ICON_SIZE_CELL_DIMEN_MULTIPLIER * 0.75),
    });

    getFlexDirectionStyle = () => ({
        flexDirection: DimensionUtils.isMobile() ? 'column' : 'row',
    });

    zoomOnPress = () => {
        if (this.scale._value > 1) {
            this.zoomOut();
        } else {
            this.scaleAndPanTo(2, 0, 0);
        }
    };

    onSwapTilesDialogAction = () => {
        this.setState({ hideExchangeButton: true });
    };

    swapTiles = () => {
        let tilesInBag = Number(get(this.props, 'game.tilesInBag'));
        if (tilesInBag >= Config.MINIMUM_AVAILABLE_TILES_FOR_EXCHANGE) {
            this.props.swapTilesModal.current.setOnSwapSuccess(this.startLiveGame);
            this.props.swapTilesModal.current.show(this.getTiles({ caller: 'swapTiles' }));
        } else {
            createDialogInstance({
                title: 'Not Enough Tiles',
                actionButtonText: 'OK',
                onAction: this.onSwapTilesDialogAction,
                body: 'There are not enough tiles available for exchange.',
            });
        }
        rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_SWAP_BUTTON, 'BOARD');
    };

    passMove = () => {
        if (isLiveGame()) {
            this.passMoveOnAction();
        } else {
            createDialogInstance({
                title: 'Pass Turn',
                actionButtonText: 'Yes',
                onAction: this.passMoveOnAction,
                body: 'Are you sure you wish to pass your turn?',
                cancelButtonText: 'No',
            });
        }
        rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_PASS_BUTTON, 'BOARD');
    };

    passMoveOnAction = async () => {
        this.showSpinnerOverlay();
        let res = await to(passMove());
        if (res[1]) {
            this.startLiveGame(res[1]);
            SoundUtils.userSubmits();
        }
        this.hideOverlay();
    };

    resignGameButtonPress = (data) => {
        createDialogInstance({
            title: 'Resign Game',
            actionButtonText: 'Yes',
            onAction: () => this.resignGameOnAction(data),
            body: 'Are you sure you wish to resign this game?',
            cancelButtonText: 'No',
        });
    };

    resignGameOnAction = async (data) => {
        if (!LiveGamePlayUtils.isMyTurn() && isLiveGame() && this.getIsGameMultiplayer()) {
            createDialogInstance({
                title: Config.DIALOG_HEADER_TEXT,
                actionButtonText: 'OK',
                onAction: getNull,
                body: "It's not your turn",
                hideCancel: true,
                isConfirmableByKey: true,
            });
            return;
        }

        this.showSpinnerOverlay();
        let res = await to(resignGame(false));
        if (!!get(data, 'backPress')) {
            this.reloadPage({ caller: 'backPress.resignGameOnAction' });
        } else {
            if (!res[0]) this.setPlayToClose();

            isEmailGame() && this.setPlayButton({ nextLocation: res[1].nextLocation });
            this.hideOverlay();
            // if (!LiveGamePlayUtils.isBlitzGame()) this.handleResponse(Config.RESIGN_GAME);
        }
    };

    deleteGameButtonPress = (data) => {
        createDialogInstance({
            title: 'Delete Game',
            actionButtonText: 'Yes',
            onAction: () => this.deleteGameOnAction(data),
            body: 'Are you sure you wish to delete this game?',
            cancelButtonText: 'No',
        });
    };

    deleteGameOnAction = async (data) => {
        this.showSpinnerOverlay();
        let res = await to(resignGame(true));
        if (!!get(data, 'backPress')) {
            this.reloadPage({ caller: 'backPress.deleteGameOnAction' });
        } else {
            if (!res[0]) this.setPlayToClose();
            isEmailGame() && this.setPlayButton({ nextLocation: res[1].nextLocation });
            this.hideOverlay();
            this.handleResponse(Config.DELETE_GAME);
        }
    };

    resignGameOnFail = (data) => {
        createGeneralRequestFailureDialog({
            onAction: data.extcode !== '1041' ? this.resignGameOnAction : undefined,
            body: data.extcode === '1041' ? data.msg : undefined,
        });
    };

    deleteGameOnFail = (data) => {
        createGeneralRequestFailureDialog({
            onAction: data.extcode !== '1041' ? this.deleteGameOnAction : undefined,
            body: data.extcode === '1041' ? data.msg : undefined,
        });
    };

    reloadPage = (data) => {
        log.info('in App, in setLoaderOverlayVisibility, in reloadPage, data.caller is: ' + data.caller);
        //eventBus.emit(Config.RESTART_APP, null, data);
        eventBus.emit(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, null, data);
    };

    reloadPageForSoloClose = () => {
        eventBus.emit(GAME_SOLO_NEW_GAME, null, {
            soloNewGame: this.props.game.soloDemoAcc ? Config.SOLO_NO_LOGIN_NEW_GAME : Config.SOLO_NEW_GAME,
        });
        this.reloadPage({ caller: 'reloadPageForSoloClose' });
    };

    reloadPageInGameMode = (data) => {
        if (get(this.props, 'game.inGameMode')) this.reloadPage(data);
    };

    handleResponse = (action) => {
        if (action) {
            switch (action) {
                case Config.DELETE_GAME: {
                    return this.onDeleteGame(action);
                }
                case Config.RESIGN_GAME: {
                    return this.checkAndShowWinnerDialog({ isSelf: true });
                }
                default:
                    throw new Error('Invalid action');
            }
        } else {
            //TODO: show error and retry dialog
        }
    };

    backPressHandle = () => {
        if (
            get(this.props, 'game.gameHasEnded') ||
            (![Config.GAME_TYPE_PUZZLE].includes(get(this.props, 'game.game_type')) &&
                get(this.props, 'game.gid') &&
                !get(this.props, 'game.pid'))
        ) {
            if (this.props.showMenu) {
                this.props.closeMenuPopUp();
            } else {
                this.onPlayPress();
            }
        } else {
            if (this.props.showMenu) {
                this.props.closeMenuPopUp();
            } else {
                eventBus.emit(Config.RESIGN_DELETE_GAME, null, {
                    doResign: true,
                    backPress: true,
                });
            }
        }
    };

    getRevealSolutionStyles = () => ({
        width: this.props.layout.layoutBoardWidth,
        position: 'absolute',
        top:
            DimensionUtils.isMobile() || get(this.props, 'game.board_type') === 'super'
                ? this.props.top + this.getRenderCellContainerStyles().height - StyleSheet.hairlineWidth
                : this.props.top + this.props.layout.layoutBoardWidth,
        left: this.props.left,
        height:
            DimensionUtils.isMobile() || get(this.props, 'game.board_type') === 'super'
                ? (DimensionUtils.isMobile() ? 2 : 1) *
                  (Math.min(this.props.layout.layoutCellDimen * 1.5, this.props.layout.layoutRackContainerHeight * 0.8) +
                      2 * get(this.props, 'layout.layoutTileMarginInRack'))
                : this.props.layout.layoutRevealSolutionHeight,
        borderBottomRightRadius: Config.COMMON_BORDER_RADIUS,
        borderBottomLeftRadius: Config.COMMON_BORDER_RADIUS,
    });

    getRevealSolutionView = () => (
        <RevealSolutionView
            key={'reveal_solution_view'}
            onToggleBoard={this.onToggleBoard}
            cellDimen={this.props.layout.cellDimen}
            style={[this.getRevealSolutionStyles()]}
        />
    );

    onConfirm = () => {
        sendChallengeMove();
    };

    onReject = () => {
        this.setState({ challengeViewVisible: false });
    };

    getChallengeView = () =>
        GameBoardUtils.isChallengeMode() && this.state.challengeViewVisible && !get(this.props, 'game.gameHasEnded') ? (
            <View style={[styles.root, this.getFlexDirectionStyle(), this.getRevealSolutionStyles()]} key={'challange_view'}>
                <S14Text style={[styles.titleContainer]}>Would you like to challenge the last turn? &nbsp; &nbsp;</S14Text>
                <View style={[styles.buttons_conatiner]}>
                    <TouchableOpacity
                        style={[
                            styles.commonChallengeViewButton,
                            {
                                height: this.getButtonStyles().height,
                                paddingHorizontal: Math.round(Config.TAB_RIGHT_LEFT_MARGIN / 2),
                            },
                            { backgroundColor: 'rgb(0, 130, 34)' },
                        ]}
                        onPress={this.onConfirm}
                        activeOpacity={1}
                    >
                        <S14Text
                            style={[
                                styles.commonChallengeViewButtonText,
                                {
                                    fontSize: get(this.props, 'layout.layoutSidePanelFontSize'),
                                },
                                { color: ColorConfig.PLAY_BUTTON_TEXT_COLOR },
                            ]}
                        >
                            Yes
                        </S14Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[
                            styles.commonChallengeViewButton,
                            {
                                minHeight: this.props.layout.cellDimen,
                                paddingHorizontal: Math.round(Config.TAB_RIGHT_LEFT_MARGIN / 2) + 1,
                            },
                            this.getChallengeViewButtonMargin(),
                            { backgroundColor: '#c23742' },
                        ]}
                        onPress={this.onReject}
                        activeOpacity={1}
                    >
                        <S14Text
                            style={[
                                styles.commonChallengeViewButtonText,
                                {
                                    fontSize: get(this.props, 'layout.layoutSidePanelFontSize'),
                                },
                                this.getChallengeViewButtonMargin(),
                                { color: ColorConfig.PLAY_BUTTON_TEXT_COLOR },
                            ]}
                        >
                            No
                        </S14Text>
                    </TouchableOpacity>
                </View>
            </View>
        ) : null;

    getGameSpecificButtons = () => {
        switch (getGameType()) {
            case Config.GAME_TYPE_PUZZLE:
                return this.getPuzzleSpecificButtons();
            case Config.GAME_TYPE_EMAIL:
            case Config.GAME_TYPE_LIVE_GAME:
            case Config.GAME_TYPE_BLITZ:
            case Config.GAME_TYPE_SOLO:
                return this.getLiveGameSpecificButtons();
            default:
                return null;
        }
    };

    getChallengeViewButtonMargin = () => ({
        margin: DimensionUtils.isNative() ? 3 : 'min(1%, 3px)',
    });

    getGiveUpButtonIconStyles = () => ({
        fontSize: get(this.props, 'layout.layoutFontAwesomeIconSize'),
        color: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
    });

    getPuzzleSpecificButtons = () =>
        this.shouldShowGiveUpButtonContainer() ? (
            <TileTouchableOpacity
                style={[styles.commonButton, this.getCommonButtonDimension(), styles.nonPuzzleModeButtonConatiner]}
                activeOpacity={1}
                onPress={this.puzzlePassOnPress}
                hoverEffect={true}
            >
                <FontAwesomeIcon
                    icon={faRedoAlt}
                    size={this.getGiveUpButtonIconStyles().fontSize}
                    style={{ ...this.getGiveUpButtonIconStyles() }}
                />

                <S14Text style={[styles.giveUpButtonText, this.getButtonFontSizeObj()]}>Give up</S14Text>
            </TileTouchableOpacity>
        ) : null;

    puzzlePassOnPress = () => {
        createDialogInstance({
            title: 'Puzzle',
            actionButtonText: ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('ad_sdk_enable')
                ? 'Yes (30 second video)'
                : 'Yes',
            onAction: this.puzzlePassOnPressAction,
            body: 'Are you sure you wish to give up on this puzzle?\n',
            cancelButtonText: 'No',
            onCancel: () => null,
        });
    };

    puzzlePassOnPressAction = async () => {
        if (
            !ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('ad_sdk_enable') ||
            !invokeGlobalMethod('ad_sdk_method_name', 'ad_sdk_method_params')
        )
            return await this.puzzlePassProceed();
    };

    puzzlePassProceed = async (event) => {
        let secret = get(event, 'detail');
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            visible: true,
            caller: 'Board.puzzlePassProceed',
            failureDetail: null,
            transparentLoader: true, //for transparency; true in 3rd param
            transparentSpinner: false,
        });
        await sendPuzzlePass(secret);
        this.hideOverlay();
    };

    getLiveGameSpecificButtons = () => (
        <View
            style={[
                styles.nonPuzzleModeButtonConatiner,
                DimensionUtils.isMobile() ? styles.alignItemCenter : undefined,
                DimensionUtils.isMobile() ? styles.justifyCenter : undefined,
                DimensionUtils.isMobile() ? { flex: 1, width: '100%', height: '100%' } : undefined,
            ]}
            key={'game_specific_button'}
        >
            {this.shouldShowPassButtonContainer() ? (
                <TooltipWrapper
                    id={'passbutton'}
                    key={'passbutton'}
                    style={[
                        DimensionUtils.isMobile() ? styles.commonButtonMobile : styles.commonButton,
                        this.getCommonButtonDimension(),
                        DimensionUtils.isMobile() ? { flex: 1 } : null,
                    ]}
                    onPress={this.passMove}
                    onMouseOver={this.onPassBtnIn}
                    onMouseOut={this.onPassBtnOut}
                    tooltip={'Pass Turn'}
                >
                    <FontAwesomeIcon
                        id={'passbuttonicon'}
                        key={'passbuttonicon'}
                        icon={faForward}
                        size={this.getCellDimenSizeIconStyleObj().fontSize}
                        style={{
                            ...this.getCellDimenSizeIconStyleObj(),
                            color: this.state.passBtnColor,
                        }}
                    />
                </TooltipWrapper>
            ) : null}

            {this.shouldShowSwapButtonContainer() ? (
                <TooltipWrapper
                    id={'swapbutton'}
                    key={'swapbutton'}
                    style={[
                        DimensionUtils.isMobile() ? styles.commonButtonMobile : styles.commonButton,
                        this.getCommonButtonDimension(),
                        DimensionUtils.isMobile() ? { flex: 1 } : null,
                    ]}
                    onPress={this.swapTiles}
                    onMouseOver={this.onSwapBtnIn}
                    onMouseOut={this.onSwapBtnOut}
                    tooltip={'Exchange Tiles'}
                >
                    <FontAwesomeIcon
                        id={'swapbuttonicon'}
                        key={'swapbuttonicon'}
                        size={this.getCellDimenSizeIconStyleObj().fontSize}
                        style={{
                            ...this.getCellDimenSizeIconStyleObj(),
                            color: this.state.swapBtnColor,
                        }}
                        icon={faSyncAlt}
                    />
                </TooltipWrapper>
            ) : null}
        </View>
    );

    onRightClickEvent = (event) => {
        if (this.state.suffleBtnColor === ColorConfig.BUTTON_TEXT_HOVER_COLOR) {
            event.preventDefault();
            let tiles = this.getTiles({ caller: 'shuffleButtonOnPress' });
            if (tiles.length > 0) this.shuffleAtoZ();
        }
    };

    shuffleButtonOnLongPress = () => {
        let tiles = this.getTiles({ caller: 'shuffleButtonOnLongPress' });
        if (tiles.length > 0) this.shuffleAtoZ();
        rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_LONG_SHUFFLE_BUTTON, 'BOARD');
    };

    shuffleButtonOnPress = () => {
        let tiles = this.getTiles({ caller: 'shuffleButtonOnPress' });
        if (tiles.length > 0) {
            this.shuffleTiles();
        }
        rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_SHUFFLE_BUTTON, 'BOARD');
    };

    compare = (tile1, tile2) => {
        if (tile1.letter < tile2.letter) {
            return -1;
        } else if (tile1.letter > tile2.letter) {
            return 1;
        }
        return 0;
    };

    shuffleAtoZ = () => {
        SoundUtils.playShuffleSound();
        let tiles = this.getTiles({
            caller: 'shuffleTiles',
            includeEmptySpace: true,
        });
        let newTileOrder = tiles.filter((tile) => !tile.isBlankTile).sort(this.compare);
        tiles.map((tile) => {
            if (tile.isBlankTile) {
                newTileOrder.unshift(tile);
            }
        });
        this.updateTiles(newTileOrder, 'shuffleTiles');
    };

    zoomOut = () => {
        this.panToPositionDebounced('zoomout');
        this.clearDirection();
    };

    shuffleTiles = () => {
        SoundUtils.playShuffleSound();
        let newTileOrder = GameBoardUtils.shuffleTilesCopy(
            this.getTiles({
                caller: 'shuffleTiles',
                includeEmptySpace: true,
            })
        );
        this.updateTiles(newTileOrder, 'shuffleTiles');
    };

    repositionAllTiles = () => null;

    scaleAndPanTo = (scale, x, y) => {
        let currentXPan = this._animatedValueX;
        let currentYPan = this._animatedValueY;
        let currentScale = this.scale._value;

        let animTime = currentScale === scale && currentScale > 1 ? 0 : 300;

        if (animTime > 0) {
            let scaleOut = AnimatedValueWrapped.create({
                start: currentScale,
                end: scale,
            });

            let animateXToOrigin = AnimatedValueWrapped.create({
                start: currentXPan,
                end: x,
            });

            let animateYToOrigin = AnimatedValueWrapped.create({
                start: currentYPan,
                end: y,
            });

            let combinedAnim = AnimatedValueWrapped.compose(animateXToOrigin, animateYToOrigin, scaleOut);

            /* combinedAnim.play(animTime, () => {
                this.pan.setOffset({
                    x: animateXToOrigin.value(),
                    y: animateYToOrigin.value(),
                });
                this.pan.setValue({ x: 0, y: 0 });
                this.scale.setValue(scaleOut.value());
            }); */
        }

        this.pan.setOffset({ x, y });
        this.pan.setValue({ x: 0, y: 0 });
        this.pan.flattenOffset();
        this.scale.setValue(scale);

        this.repositionAllTiles();
    };

    panToPositionDebounced = debounce((x, y) => {
        if (x === 'zoomout') {
            this.scaleAndPanTo(1, 0, 0);
        } else {
            this.panToPosition(x, y);
        }
    }, 200);

    isMoveStarted = () => this.getTiles({ caller: 'isMoveStarted' }).some((tile) => !!tile.position);

    beforePlayMove = (words, score) =>
        new Promise((accept, reject) => {
            let longestWord = (words || []).reduce((acc, currVal) =>
                (currVal || '').length > (acc || '').length ? currVal : acc
            );
            if (SettingsUtil.get('move_confirmation')) {
                createDialogInstance({
                    title: 'Confirm Move',
                    actionButtonText: 'Yes',
                    onAction: accept,
                    body: 'Play "' + longestWord + '" for ' + score + ' points?',
                    cancelButtonText: 'No',
                    isConfirmableByKey: true,
                    onCancel: () => {
                        this.updateMoveValidityScore(false, true);
                        reject(new Error('User Cancelled'));
                    },
                });
            } else {
                accept();
            }
        });

    onRecallPress = () => {
        this.onRecallPressWithSoundControl(true);
        setTimeout(() => {
            TooltipActionWrapper.hide();
            TooltipActionWrapper.rebuild();
        }, 100);
        rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_RECALL_BUTTON, 'BOARD');
    };

    onRecallPressWithSoundControl = (playSound, skipUpdateMoveValidation) => {
        let tileOrTiles = this.getTiles({
            caller: 'onRecallPressWithSoundControl',
            includeEmptySpace: true,
        });
        log.info('in Board, in onRecallPressWithSoundControl, tileOrTiles is:\n' + JSON.stringify(tileOrTiles, null, 2));
        eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
            tileOrTiles,
            doEmptyBlankTile: true,
            skipUpdateMoveValidation,
            caller: 'BoardOnRecallPressWithSoundControl',
        });
        playSound && SoundUtils.recallAllSound();
        let currentScale = this.scale._value;
        if (currentScale > 1) {
            this.zoomOut();
        }
        this.clearDirection();
    };

    onUnobserve = async (sendRequest = true) => {
        if (sendRequest) {
            let res = await to(sendUnobserveGame(get(this.props, 'game.gid')));
            if (res[1] && Number(res[1].extcode) === 1) {
                this.reloadPage({ caller: 'onUnobserve' });
            }
        } else {
            this.reloadPage({ caller: 'onUnobserve' });
        }
    };

    showSpinnerOverlay = (caller) =>
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            visible: true,
            caller: 'Board.showSpinnerOverlay_' + caller,
            boardSpinner: Config.BOARD_SPINNER,
            failureDetail: null,
            transparentLoader: true, //for transparency; true in 3rd param
            transparentSpinner: false,
        });

    updateTiles = (newTiles, caller, updateCellData, tile, cell, forHintWordPlacement, emptyGameBoard) => {
        // correct approach - this.setState({tiles: newTiles});
        log.info(`in Board, in updateTiles, caller is: ${caller}`);
        if (updateCellData) {
            eventBus.emit(UPDATE_TILES_AND_SET_CELL, null, {
                cells: updateCellData,
                tile,
                cell,
                tiles: { rack: newTiles, caller },
                forHintWordPlacement,
                caller: 'BoardUpdateTiles',
                emptyGameBoard,
            });
        } else {
            log.info(`in TileReducer, in Board, in updateTiles, caller is: ${caller}`);
            eventBus.emit(GAME_REDUCER_UPDATE_TILES, null, {
                rack: newTiles,
                caller,
            });
        }
        isEmailGame() && addUpdateRack.bind({ props: this.props })({ rack: newTiles });
    };

    updateMoveValidityScoreEvent = (param) => {
        log.info('in Board, in updateMoveValidityScoreEvent, param is:\n' + JSON.stringify(param, null, 2));
        this.updateMoveValidityScore(get(param, 'finalise'), get(param, 'doPlayBtnCheckWordValidityReq'));
    };

    updateMoveValidityScore = async (finalise, doPlayBtnCheckWordValidityReq) => {
        this.checkAndSetBoardGameplayButtons();
        let tiles = this.getTiles({
            caller: 'updateMoveValidityScore',
            includeEmptySpace: true,
        });

        let result = await GameBoardUtils.validateAndSendMove({
            gameBoard: zip(...get(this.props, 'cells.cells')),
            tiles,
            refs: finalise,
            preconfirm: this.beforePlayMove,
        });
        if (isObject(result)) {
            if (finalise) {
                await this.clearOutputs();
                await this.zoomOut();
            } else {
                if (this.isMyTurn() && !GameBoardUtils.isChallengeMode() && doPlayBtnCheckWordValidityReq) {
                    if (!(get(result, 'playedTiles') || []).some((tile) => tile.isBlankTile && !tile.currentLetter))
                        this.setValidWordsPlayButtonColor(result);
                }
                eventBus.emit(GAME_PLAY_BUTTON_SCORE_TEXT, null, result.outputs || null);
            }
        } else if (isString(result)) {
            this.setValidWordsPlayButtonColor();
            eventBus.emit(GAME_PLAY_BUTTON_SCORE_TEXT, null, null);
            if (finalise) {
                await this.clearDirection();
                createDialogInstance({
                    title: 'Invalid Move',
                    body: result,
                    cancelButtonText: 'OK',
                    isConfirmableByKey: true,
                });
                SoundUtils.invalidWord();
                throw new Error(result);
            }
        } else if (result === undefined) {
            this.setValidWordsPlayButtonColor();
            eventBus.emit(GAME_PLAY_BUTTON_SCORE_TEXT, null, null);
            this.hideOverlay();
        }

        let finalUnplacedTileCount = this.getTiles({
            caller: 'updateMoveValidityScore',
        }).filter((tiles) => !tiles.position).length;
        let finalPlacedTileCount = this.getTiles({ caller: 'updateMoveValidityScore' }).length - finalUnplacedTileCount;

        if (finalPlacedTileCount > 0) {
        } else {
            if (!this.getCellDirection()) {
                await this.zoomOut();
            }
        }
        if (typeof result === 'undefined') {
            return Config.NO_TILES_PLAYED;
        }
    };

    setValidWordsPlayButtonColor = async (param) => {
        log.info(
            'movestrengthissue, in GamePlayService, in Board, in setValidWordsPlayButtonColor, param is:\n' +
                JSON.stringify(param, null, 2)
        );
        if (get(this.props, 'game.showingAnalyseMove')) return;
        let isSingleLetterWord = isSingleLetterWordInWordsArray(get(param, 'words') || []);
        let isTilePostionChanged = this.checkAndSetTempTilePostion();

        if (param && param.words && !isSingleLetterWord) {
            if (isTilePostionChanged) {
                //Api Request, for all Words are valid or not
                let data = await getWordValidity({
                    word: param.words,
                    actionToEmit: GAME_PLAY_BUTTON_WORD_VALIDITY,
                });
                if (get(data, 'data.error') !== '0') {
                    eventBus.emit(GAME_REDUCER_SET_MOVE_STRENGTH);
                }
            }
        } else {
            eventBus.emit(GAME_PLAY_BUTTON_WORD_VALIDITY);
        }
    };

    checkAndSetTempTilePostion = () => {
        let { tempTiles } = this.state;
        let tiles = this.getTiles();

        if (tempTiles.length > 0) {
            let flag = false;
            for (let i = 0; i < tiles.length; i++) {
                let id = tiles[i].id;
                let arr = tempTiles.filter((element) => element.id === id);

                if (
                    arr.length > 0 &&
                    (!isEqual(arr[0].position, tiles[i].position) ||
                        (arr[0].isBlankTile && !isEqual(arr[0].currentLetter, tiles[i].currentLetter)))
                ) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                this.setState({ tempTiles: tiles });
            }
            return flag;
        } else {
            this.setState({ tempTiles: tiles });
            return true;
        }
    };

    getRenderCellContainerStyles = () => ({
        width: this.props.layout.layoutBoardWidth,
        height:
            this.props.layout.layoutBoardWidth +
            (DimensionUtils.isMobile() || get(this.props, 'game.board_type') === 'super' ? 0 : StyleSheet.hairlineWidth) -
            (DimensionUtils.isMobile() || get(this.props, 'game.board_type') === 'super'
                ? this.props.game.board_size * StyleSheet.hairlineWidth
                : 0),
        left: this.state.left,
        top: this.state.top,
    });

    getRenderCellAnimatedViewDimensions = () => ({
        width: this.props.layout.layoutBoardWidth,
        height: this.props.layout.layoutBoardWidth,
    });

    getBoardRowDimensions = (indexY) => ({
        position: 'absolute',
        left: 0,
        top: indexY * this.props.layout.layoutCellDimen,
        height: this.props.layout.layoutCellDimen + StyleSheet.hairlineWidth,
        width: '100%',
    });

    getSpecialCellsContainerStyles = (specialCellType, data) => ({
        left: data['0'] * this.props.layout.layoutCellDimen,
        width: this.props.layout.layoutCellDimen,
        height:
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_TOP_DIMENSION_MULTIPLIER +
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_BOTTOM_DIMENSION_MULTIPLIER,
        top:
            data['1'] * this.props.layout.layoutCellDimen +
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_TOP_DIMENSION_MULTIPLIER,
        backgroundColor: GameBoardUtils.getCellBackgroundColor({
            specialCellType,
        }),
    });

    renderCells = () => (
        <View
            id={'boardRoot'}
            key={'boardRoot'}
            class={'boardRows'}
            style={[styles.boardRoot, styles.postionAbsolute, this.getRenderCellContainerStyles()]}
        >
            <Animated.View
                style={[styles.animatedView, this.getRenderCellAnimatedViewDimensions(), this.getStyle()]}
                {...this._panResponder.panHandlers}
                class={'boardRows'}
            >
                {times(get(this.props, 'game.board_size'), constant(null)).map((boardRow, indexY) => (
                    <View
                        key={'boardRows_' + indexY}
                        class={'boardRows'}
                        style={[styles.insideAnimatedView, this.getBoardRowDimensions(indexY)]}
                    >
                        {times(get(this.props, 'game.board_size'), constant(null)).map((cell, indexX) => (
                            <Cell
                                key={'cell_' + indexX + '_' + indexY}
                                idStr={'cell' + indexX + '_' + indexY}
                                tileX={indexX}
                                tileY={indexY}
                            />
                        ))}
                    </View>
                ))}
            </Animated.View>
        </View>
    );

    getBelowBoardPartStyle = () => ({
        width: this.props.layout.layoutBoardWidth,
        height:
            get(this.props, 'game.board_type') === 'super'
                ? Math.min(this.props.layout.layoutCellDimen * 1.5, this.props.layout.layoutRackContainerHeight * 0.8) +
                  get(this.props, 'layout.layoutTileMarginInRack')
                : this.props.layout.layoutRackContainerHeight - StyleSheet.hairlineWidth,
        position: 'absolute',
        top: this.props.top + this.getRenderCellContainerStyles().height,
        left: this.props.left,
    });

    getBelowBoardPartMobileStyle = () => ({
        width: this.props.layout.layoutBoardWidth,
        height:
            Math.min(this.props.layout.layoutCellDimen * 1.5, this.props.layout.layoutRackContainerHeight * 0.8) +
            get(this.props, 'layout.layoutTileMarginInRack'),
        position: 'absolute',
        top:
            this.props.top +
            this.getRenderCellContainerStyles().height +
            Math.min(this.props.layout.layoutCellDimen * 1.5, this.props.layout.layoutRackContainerHeight * 0.8) +
            2 * get(this.props, 'layout.layoutTileMarginInRack') -
            StyleSheet.hairlineWidth,

        left: this.props.left,
    });

    getBelowBoardCellsBackgroundMobileStyle = () => ({
        width: this.props.layout.layoutBoardWidth,
        height:
            Math.min(this.props.layout.layoutCellDimen * 1.5, this.props.layout.layoutRackContainerHeight * 0.8) +
            2 * get(this.props, 'layout.layoutTileMarginInRack'),
        position: 'absolute',
        top: this.props.top + this.getRenderCellContainerStyles().height - StyleSheet.hairlineWidth,
        left: this.props.left,
    });

    getCellDirection = () => get(this.props, 'cells.direction');
    getCellDirectionTileX = () => get(this.props, 'cells.directionPositionX');
    getCellDirectionTileY = () => get(this.props, 'cells.directionPositionY');

    clearDirection = (exceptX, exceptY) => {
        if (this.getCellDirection()) {
            eventBus.emit(CELL_REDUCER_CLEAR_DIRECTION, null, {
                exceptX,
                exceptY,
            });
        }
    };

    shouldShowRecallButtonContainer = () => {
        if (DimensionUtils.isMobile()) return true;
        let placedTilesCount = (this.getTiles({ caller: 'shouldShowRecallButtonContainer' }) || []).filter(
            (tile) => tile.position
        ).length;
        return placedTilesCount > 0 && !get(this.props, 'game.gameHasEnded') && get(this.props, 'game.guid');
    };

    shouldShowGiveUpButtonContainer = () => {
        let placedTilesCount = (this.getTiles({ caller: 'shouldShowGiveUpButtonContainer' }) || []).filter(
            (tile) => tile.position
        ).length;
        return (
            [Config.GAME_TYPE_PUZZLE].includes(get(this.props, 'game.game_type')) &&
            placedTilesCount < 1 &&
            !get(this.props, 'game.showingAnalyseMove') &&
            get(this.props, 'game.guid')
        );
    };

    shouldShowPassButtonContainer = () => {
        let tiles = this.getTiles({ caller: 'shouldShowPassButtonContainer' });

        let placedTilesCount = (tiles || []).filter((tile) => tile.position).length;

        return (
            [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL, Config.GAME_TYPE_SOLO].includes(
                get(this.props, 'game.game_type')
            ) &&
            this.isMyTurn() &&
            placedTilesCount < 1 &&
            !this.hasGameEnded() &&
            !get(this.props, 'game.showingAnalyseMove') &&
            !!get(this.props, 'game.guid') &&
            !!get(this.props, 'game.pid')
        );
    };

    shouldShowSwapButtonContainer = () => {
        let placedTilesCount = (this.getTiles({ caller: 'shouldShowSwapButtonContainer' }) || []).filter(
            (tile) => tile.position
        ).length;
        return (
            [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL, Config.GAME_TYPE_SOLO].includes(
                get(this.props, 'game.game_type')
            ) &&
            this.isMyTurn() &&
            placedTilesCount < 1 &&
            !this.hasGameEnded() &&
            !get(this.props, 'game.showingAnalyseMove') &&
            !!get(this.props, 'game.guid') &&
            !!get(this.props, 'game.pid')
        );
    };

    checkAndSetBoardGameplayButtons = () => {
        setTimeout(() => {
            TooltipActionWrapper.rebuild();
        }, 100);
    };

    onTilePlacedHandlerForHintWord = (tilesPositionsObjs) => {
        let tiles = (
            this.getTiles({
                caller: 'setTileToCell',
                includeEmptySpace: true,
            }) || []
        ).map((tile) => {
            tile.position = undefined;
            tile.placed = undefined;
            return tile;
        });
        let updateCellData = [];
        tilesPositionsObjs.forEach(({ tile, positionX, positionY }) => {
            let cell = get(this.props, 'layout.cellDimensions')
                .flat(8)
                .find((cell) => cell.tileX === positionX && cell.tileY === positionY);
            let tileFromArr = (tiles || []).find((tileInArr) => get(tileInArr, 'id') === get(tile, 'id'));
            if (!!tileFromArr) {
                tileFromArr.position = {
                    x: cell.tileX,
                    y: cell.tileY,
                    cellStartPositionX: cell.tileStartXUnscaledUnoffset,
                    cellEndPositionX: cell.tileEndXUnscaledUnoffset,
                    cellStartPositionY: cell.tileStartYUnscaledUnoffset,
                    cellEndPositionY: cell.tileEndYUnscaledUnoffset,
                    cellStartPositionXAdjusted: cell.tileStartX,
                    cellEndPositionXAdjusted: cell.tileEndX,
                    cellStartPositionYAdjusted: cell.tileStartY,
                    cellEndPositionYAdjusted: cell.tileEndY,
                };
                tileFromArr.getLetter = tile.getLetter;
                tileFromArr.opacity = 0;
            }
            cell.currentTile = tile;
            updateCellData.push(cell);
        });
        this.updateTiles(tiles, 'setTileToCell', updateCellData, undefined, undefined, true, {
            nonLockedTilesOnly: true,
            letRevealSolutionRemain: true,
            forAnalyseMove: false,
        });
    };

    displayLetterPickerEvent = (params) => this.displayLetterPicker(get(params, 'tile'), get(params, 'cell'));

    onPlayPress = async () => {
        if (get(this.props, 'game.gameHasEnded')) {
            if (get(this.props, 'game.game_type') === Config.GAME_TYPE_EMAIL) {
                this.onGoToNextLocation();
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_NEXT_BUTTON, 'BOARD');
            } else if (get(this.props, 'game.game_type') === Config.GAME_TYPE_SOLO) {
                this.reloadPageForSoloClose();
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_SOLO_CLOSE_BUTTON, 'BOARD');
            } else {
                this.reloadPage({ caller: 'onPlayPress' });
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_CLOSE_BUTTON, 'BOARD');
            }
        } else if (
            ![Config.GAME_TYPE_PUZZLE].includes(get(this.props, 'game.game_type')) &&
            get(this.props, 'game.gid') &&
            !get(this.props, 'game.pid')
        ) {
            this.onUnobserve();
            rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_UNOBSERVE, 'BOARD');
        } else {
            if (!this.isMyTurn()) {
                if (get(this.props, 'game.game_type') === Config.GAME_TYPE_EMAIL) {
                    this.onGoToNextLocation();
                    rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_NEXT_BUTTON, 'BOARD');
                } else {
                    this.onFlashOpponentTurnMessage();
                }
            } else {
                this.clearDirection();
                eventBus.emit(GAME_SHOW_PLAY_BUTTON_LOADER, null, {
                    visible: true,
                });
                await to(this.updateMoveValidityScore(true, false));
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_PLAY_BUTTON, 'BOARD');
            }
        }

        setTimeout(() => {
            TooltipActionWrapper.rebuild();
        }, 100);
    };

    renderTiles = (tileType, index, droppedTile) => (
        <Tile
            key={'tile_' + index}
            scale={this.scale}
            pan={this.pan}
            tileType={tileType}
            index={index}
            style={droppedTile ? { zIndex: 100 } : null}
            containerDimensions={this.getContainerDimensions()}
            isCreateBoard={false}
            onTileTouch={this.setTileTouchStatus}
        />
    );

    setTileTouchStatus = (status) => this.setState({ tileTouch: status });

    getCellDimen = () => {
        return this.props.layout.cellDimen;
    };

    getBoardHeight = () => {
        return this.props.layout.layoutBoardWidth;
    };

    getCurrentScale = () => this.scale._value;

    hasTile = (x, y) => {
        let cell = get(this.props, 'cells.cells.' + x + '.' + y);
        return !!cell && !!cell.currentTile;
    };

    getCurrentTile = (x, y) => {
        let cell = get(this.props, 'cells.cells.' + x + '.' + y);
        return get(cell, 'currentTile');
    };

    isLocked = (x, y) => {
        let cell = get(this.props, 'cells.cells.' + x + '.' + y);
        return !!cell && !!cell.currentTile && !!cell.locked;
    };

    refreshPosition = (y, x) => {
        let cell = get(this.props, 'layout.cellDimensions.' + x + '.' + y);

        let result = {
            x: cell.tileStartXUnscaledUnoffset,
            y: cell.tileStartYUnscaledUnoffset,
            endX: cell.tileEndXUnscaledUnoffset,
            endY: cell.tileEndYUnscaledUnoffset,
        };

        return result;
    };

    getScale = () => this.scale._value;

    onMoveShouldSetPanResponder = (e, gesture) => {
        let isClickingDroppedTile = false;
        if (e.nativeEvent.touches && e.nativeEvent.touches.length === 1) {
            let droppedTiles = this.getTiles({
                caller: 'onMoveShouldSetPanResponder',
            }).filter((tile) => !!tile.position);
            if (droppedTiles) isClickingDroppedTile = !!get(this.props, 'tiles.tileBeingDragged');
        }
        return (
            (!isClickingDroppedTile && this.scale._value > 1) || (e.nativeEvent.touches && e.nativeEvent.touches.length === 2)
        );
    };

    onCellDoubleTap = (cell, indexX, indexY) => {
        this.scaleAndPanTo(
            this.scale._value > 1 ? 1 : 2,
            this.scale._value > 1
                ? 0
                : this.props.layout.layoutBoardWidth / 2 -
                      (cell.tileStartXUnscaledUnoffset +
                          Math.round(indexX / get(this.props, 'game.board_size')) * this.props.layout.cellDimen),
            this.scale._value > 1
                ? 0
                : this.props.layout.layoutBoardWidth / 2 -
                      (cell.tileStartYUnscaledUnoffset +
                          Math.round(indexY / get(this.props, 'game.board_size')) * this.props.layout.cellDimen)
        );
    };

    getCurrentScoreStyles = () => ({
        fontSize: get(this.props, 'layout.layoutCellDimen') / 2.3,
    });

    setBoardAdditionalTopDimension = (boardAdditionalTopDimension) => {
        this.setState({ boardAdditionalTopDimension });
        this.repositionAllTiles();
    };

    onShuffleBtnIn = () => {
        this.setState({ suffleBtnColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR });
    };
    onShuffleBtnOut = () => {
        this.setState({ suffleBtnColor: ColorConfig.BUTTON_TEXT_COLOR });
    };
    onRecallBtnIn = () => {
        this.setState({ recallBtnColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR });
    };
    onRecallBtnOut = () => {
        this.setState({ recallBtnColor: ColorConfig.BUTTON_TEXT_COLOR });
    };
    onPassBtnIn = () => {
        this.setState({ passBtnColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR });
    };
    onPassBtnOut = (event) => {
        this.setState({ passBtnColor: ColorConfig.BUTTON_TEXT_COLOR });
    };
    onSwapBtnIn = () => {
        this.setState({ swapBtnColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR });
    };
    onSwapBtnOut = () => {
        this.setState({ swapBtnColor: ColorConfig.BUTTON_TEXT_COLOR });
    };

    onAnalyseBtnPress = async () => {
        let isProUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isProUser');
        let isAnalyseUser = ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isAnalyseUser');

        if (isProUser || isAnalyseUser) {
            this.setState({ showAnalyseButtonLoader: true });
            await onStartAnalyse();
            eventBus.emit(CONFIG_SET_MENU_VISIBILITY, null, false);
            eventBus.emit(GAME_SIDE_LAYOUT_ACTIVE_TAB_SET, null, 2);
        } else {
            showAnalysePurchaseDialog();
        }
    };

    onScoringBtnPress = () => {
        eventBus.emit(Config.SHOW_SCORING_DETAILS_MODAL, null, this.state.gameScoringData);
    };
}

const styles = StyleSheet.create({
    //Main Renders Styles

    mainContainer: {
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'flex-start',
    },
    boardContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        overflow: 'hidden',
    },
    boardButtonsAndRackContainer: {
        backgroundColor: ColorConfig.BUTTON_CONTAINER_BACKGROUND_COLOR,
        borderColor: ColorConfig.BUTTON_CONTAINER_BORDER_COLOR,
        borderWidth: Config.BOARD_BORDER_WIDTH,
        borderTopWidth: 0,
    },
    boardMobileTileContainer: {
        backgroundColor: ColorConfig.BUTTON_CONTAINER_BACKGROUND_COLOR,
        borderColor: ColorConfig.BUTTON_CONTAINER_BORDER_COLOR,
        borderRightWidth: Config.BOARD_BORDER_WIDTH,
        borderLeftWidth: Config.BOARD_BORDER_WIDTH,
        borderTopWidth: 0,
        borderBottomWidth: 0,
    },
    bottomBorders: {
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    },
    buttonContainer: {
        flexDirection: 'row',
        width: '100%',
    },
    playButton: {
        backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        flexDirection: 'row',
        borderRadius: 5,
        overflow: 'hidden',
    },
    playButtonOverlayText: {
        textAlign: 'center',
        color: ColorConfig.BUTTON_TEXT_COLOR,
        fontWeight: 'bold',
        paddingTop: 5,
    },
    giveUpButtonText: {
        marginLeft: 3,
        color: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
        fontWeight: 'bold',
    },
    commonButton: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        margin: 3,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        flexDirection: 'row',
    },
    commonButtonMobile: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    reloadButton: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        flexDirection: 'row',
    },

    scoreText: {
        color: ColorConfig.PLAY_BUTTON_TEXT_COLOR,
        fontWeight: 'bold',
    },

    //renderCells styles

    boardRoot: {
        overflow: 'hidden',
        flexDirection: 'column',
        zIndex: undefined,
        top: 0,
        backgroundColor: ColorConfig.DEFAULT_CELL_BACKGROUND_COLOR,
    },
    animatedView: {
        flexDirection: 'column',
        zIndex: undefined,
    },
    insideAnimatedView: {
        flexDirection: 'row',
        zIndex: undefined,
    },
    puzzleIndicators: {
        margin: 2,
    },
    nonPuzzleModeButtonConatiner: {
        flexDirection: 'row',
    },
    postionAbsolute: {
        position: 'absolute',
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    bottomBackgroundColor: {
        backgroundColor: ColorConfig.BUTTON_CONTAINER_BACKGROUND_COLOR,
    },
    directionRow: {
        flexDirection: 'row',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    justifyFlexEnd: {
        justifyContent: 'center',
    },
    alignItemCenter: {
        alignItems: 'center',
    },
    alignItemFlexEnd: {
        alignItems: 'flex-end',
    },
    widthHundred: {
        width: '100%',
    },
    customPopOverBackgroundColor: {
        backgroundColor: '#FFF',
    },
    spaceBetweenRowStyle: { justifyContent: 'space-between' },

    playButtonRightPosition: {
        right: 20,
    },
    shuffleLeftPosition: {
        marginLeft: 12,
    },

    root: {
        backgroundColor: ColorConfig.BUTTON_CONTAINER_BACKGROUND_COLOR,
        borderColor: ColorConfig.BUTTON_CONTAINER_BORDER_COLOR,
        borderWidth: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttons_conatiner: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        color: ColorConfig.TILE_TEXT_COLOR,
        position: 'absolute',
    },
    notVisible: {
        height: 0,
        width: 0,
    },
    titleContainer: {
        textAlign: 'center',
    },

    commonChallengeViewButton: {
        backgroundColor: ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        flexDirection: 'row',
    },

    commonChallengeViewButtonText: {
        color: ColorConfig.BUTTON_TEXT_COLOR,
        fontWeight: 'bold',
    },
    otherBtn: {
        backgroundColor: ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        marginHorizontal: 5,
    },
    otherBtnText: {
        textAlign: 'center',
        color: ColorConfig.PLAY_BUTTON_TEXT_COLOR,
    },
    closeButtonRightPositionOnGameOver: { right: 5 },
    marginLeft: { marginLeft: 5 },
});

const mapStateToProps = (state) => ({
    config: state.config,
    game: state.game,
    layout: state.layout,
    tiles: state.tiles,
    cells: state.cells,
});

export default connect(mapStateToProps)(Board);
