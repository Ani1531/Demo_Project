// @flow

import dataServer from '../store/Store';
import { batch } from 'react-redux';
import LgnMgr from './LgnMgr';
import fndApi from '../friends/FndApi';
import fbLgnMgr from '../commons/FBLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import applLgnMgr from '../commons/ApplLgnMgr';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import userDefault from './UserDefault';
import * as CONSTANTS from './Constants';
import requestManager from '../commons/RequestManager';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import type {
    RegisterAppleUserRequest,
    RegisterAppleUserSuccessResponse,
    LexComAuthData,
    FBAuthData,
    AssociationRequestData,
    AssociationResponse,
    AssociationResponseInfo,
    AssociationResponseData,
    ServerResponse,
    GenGlobalIDRequest,
    GenGlobalIDResponseData,
    RegisterGoogleUserResponse,
    RegisterGoogleUserSuccessResponse,
    RegisterGoogleUserErrorResponse,
    FBLoginInfo,
    LXLSLoginInfo,
    GGLLoginInfo,
    GamesListResponse,
    AppState,
    PsistData,
    AlertBoxType,
} from '../commons/RJTypes';
import minStatsApi from '../stats/minimalstats/MinStatsApi';
import { actionClearProfile, actionUpdateLXLSLgnInfo } from '../userprofile/PFLAction';
// import type { User } from '@react-native-google-signin/google-signin'; // Change for react native web
import type { AppleCredentialState, AppleRequestResponse } from '@invertase/react-native-apple-authentication';
import { actionAddGames, glClearData } from '../gameslist/GLAction';
import { aglClearData } from '../archivegameslist/AGLAction';
import glApi from '../gameslist/GLApi';
import { actionClearMinStats } from '../stats/minimalstats/MinStatsAction';
import { actionGLBLFndClearData } from '../friends/FndAction';
import { actionLNRClearData } from '../loginNregister/LNRAction';
import netManager from './RJNetInfo';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import pushNtfMgr from './PushNtfMgr';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';
import { handleException } from './RJUtils';
import inAppPurchases from './iap/InAppPurchases';
import WordValidityWebSocketProvider from '../../../../provider/WordValidityWebSocketProvider';
import { actionResetHostedGames } from '../gamesfactory/hostedgames/HostedGameAction';

class LoginCoordinator {
    _lgnMgr: ?LgnMgr = null;
    _onCompletionCallback: ?() => void = null;

    constructor() {
        this._lgnMgr = null;
        this._onCompletionCallback = null;
    }

    get lgnMgr(): ?LgnMgr {
        return this._lgnMgr;
    }

    set lgnMgr(value: ?LgnMgr) {
        this._lgnMgr = value;
    }

    onFBFastLogin = (onCompletionCallback: ?() => void) => {
        this._lgnMgr = fbLgnMgr;
        this._onCompletionCallback = onCompletionCallback;
        let data: ?FBLoginInfo = dataServer.getFbLoginInfo();
        if (data !== null && data !== undefined) {
            if (data.fbAccessToken !== null && data.fbAccessToken !== undefined) {
                dataServer.debouncedDispatch(actionSetIdle());
                if (this._onCompletionCallback) {
                    this._onCompletionCallback();
                    this._onCompletionCallback = null;
                    this._lgnMgr = null;
                }
            } else {
                dataServer.debouncedDispatch(actionSetIdle());
                this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
            }
        } else {
            dataServer.debouncedDispatch(actionSetIdle());
            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
        }
    };

    onFBLogin = (onCompletionCallback: ?() => void) => {
        this._lgnMgr = fbLgnMgr;
        this._onCompletionCallback = onCompletionCallback;
        let data: ?FBLoginInfo = dataServer.getFbLoginInfo();
        if (data !== null && data !== undefined) {
            if (data.fbAccessToken !== null && data.fbAccessToken !== undefined) {
                let userid: string = data.fbAccessToken.userID;
                let accessToken: string = data.fbAccessToken.accessToken;
                let bulkdata = {};
                bulkdata[CONSTANTS.kPsistPendingAssociation] = CONSTANTS.AccountSecureMedium.AccountSecureMediumFB;
                let finsrted: Promise<void> = userDefault.setMultiple(bulkdata);
                finsrted
                    .then(() => {
                        let assocdata: FBAuthData = {
                            [CONSTANTS.kPlatformFB]: {
                                [CONSTANTS.kFbSigUser]: userid,
                                [CONSTANTS.kFbSigSessionKey]: accessToken,
                            },
                        };
                        this.doAssociation(assocdata);
                    })
                    .catch((error) => {
                        handleException(error);
                        dataServer.debouncedDispatch(actionSetIdle());
                    });
            } else {
                dataServer.debouncedDispatch(actionSetIdle());
                this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
            }
        } else {
            dataServer.debouncedDispatch(actionSetIdle());
            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
        }
    };

    onLXLSDotComFastLogin = async (onCompletionCallback: ?() => void): Promise<void> => {
        const { lnrVw }: AppState = dataServer.getStore().getState();
        if (lnrVw !== null && lnrVw !== undefined && lnrVw.lrnVwLgnInfo !== null && lnrVw.lrnVwLgnInfo !== undefined) {
            let lgninfo: LXLSLoginInfo = lnrVw.lrnVwLgnInfo;
            if (
                lgninfo.authuser !== null &&
                lgninfo.authuser !== undefined &&
                lgninfo.authsecret !== null &&
                lgninfo.authsecret !== undefined &&
                lgninfo.email !== null &&
                lgninfo.email !== undefined
            ) {
                this._onCompletionCallback = onCompletionCallback;
                let authuser = lgninfo.authuser;
                let authsecret = lgninfo.authsecret;
                let email = lgninfo.email;

                let tempauthdata = {
                    authuser: authuser,
                    authsecret: authsecret,
                    uid: lgninfo.uid,
                    email: email,
                };
                dataServer.getStore().dispatch(actionUpdateLXLSLgnInfo(tempauthdata));
                await lxlsLgnMgr.storeLoginInfo(tempauthdata);
                if (this._onCompletionCallback) {
                    this._onCompletionCallback();
                    this._onCompletionCallback = null;
                    this._lgnMgr = null;
                }
            } else {
                dataServer.debouncedDispatch(actionSetIdle());
                this.doSignOutMostRecentLogin(false, null);
            }
        } else {
            this.doSignOutMostRecentLogin(false, null);
        }
    };

    onLXLSDotComLogin = async (onCompletionCallback: ?() => void): Promise<void> => {
        const { lnrVw }: AppState = dataServer.getStore().getState();
        if (lnrVw !== null && lnrVw !== undefined && lnrVw.lrnVwLgnInfo !== null && lnrVw.lrnVwLgnInfo !== undefined) {
            let lgninfo: LXLSLoginInfo = lnrVw.lrnVwLgnInfo;
            if (
                lgninfo.authuser !== null &&
                lgninfo.authuser !== undefined &&
                lgninfo.authsecret !== null &&
                lgninfo.authsecret !== undefined &&
                lgninfo.email !== null &&
                lgninfo.email !== undefined
            ) {
                this._onCompletionCallback = onCompletionCallback;
                let authuser = lgninfo.authuser;
                let authsecret = lgninfo.authsecret;
                let email = lgninfo.email;
                let bulkdata = {};
                bulkdata[CONSTANTS.kPsistPendingAssociation] = CONSTANTS.AccountSecureMedium.AccountSecureMediumLXLS;
                await userDefault.setMultiple(bulkdata);
                let tempauthdata = {
                    authuser: authuser,
                    authsecret: authsecret,
                    uid: lgninfo.uid,
                    email: email,
                };
                dataServer.getStore().dispatch(actionUpdateLXLSLgnInfo(tempauthdata));
                await lxlsLgnMgr.storeTempLoginInfo(tempauthdata);
                let assocdata: LexComAuthData = {
                    [CONSTANTS.kPlatformLexCom]: {
                        [CONSTANTS.kAuthUser]: authuser,
                        [CONSTANTS.kAuthSecret]: authsecret,
                    },
                };
                this.doAssociation(assocdata);
            } else {
                dataServer.debouncedDispatch(actionSetIdle());
                this.doSignOutMostRecentLogin(false, null);
            }
        } else {
            this.doSignOutMostRecentLogin(false, null);
        }
    };

    onGoogleFastLogin = (onCompletionCallback: ?() => void) => {
        this._lgnMgr = gglLgnMgr;
        this._onCompletionCallback = onCompletionCallback;
        let gglinfo: GGLLoginInfo | null = dataServer.getGGLLoginInfo();
        if (gglinfo !== null && gglinfo !== undefined && (gglinfo.error == null || gglinfo.error == undefined)) {
            if (gglinfo.userInfo !== null && gglinfo.userInfo !== undefined) {
                let userinfo: any = gglinfo.userInfo; //Change for react native web
                let onCompletion = async (srvdata: RegisterGoogleUserSuccessResponse | null) => {
                    if (srvdata !== null) {
                        let tempauthdata = {
                            authuser: srvdata[CONSTANTS.kAuthUser],
                            authsecret: srvdata[CONSTANTS.kAuthSecret],
                            uid: srvdata[CONSTANTS.kUid],
                            email: srvdata[CONSTANTS.kParamEmail],
                        };
                        dataServer.getStore().dispatch(actionUpdateLXLSLgnInfo(tempauthdata));
                        let lexauthdatainserted = await lxlsLgnMgr.storeLoginInfo(tempauthdata);

                        if (lexauthdatainserted) {
                            if (this._onCompletionCallback) {
                                this._onCompletionCallback();
                                this._onCompletionCallback = null;
                                this._lgnMgr = null;
                            }
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
                        }
                    } else {
                        dataServer.debouncedDispatch(actionSetIdle());
                        this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
                    }
                };
                this.doRegisterGoogleUser(userinfo, onCompletion);
            } else {
                this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
            }
        } else {
            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
        }
    };

    onGoogleLogin = (onCompletionCallback: ?() => void) => {
        this._lgnMgr = gglLgnMgr;
        this._onCompletionCallback = onCompletionCallback;
        let gglinfo: GGLLoginInfo | null = dataServer.getGGLLoginInfo();
        if (gglinfo !== null && gglinfo !== undefined && (gglinfo.error == null || gglinfo.error == undefined)) {
            if (gglinfo.userInfo !== null && gglinfo.userInfo !== undefined) {
                let userinfo: any = gglinfo.userInfo; // Change for react native web
                let onCompletion = async (srvdata: RegisterGoogleUserSuccessResponse | null) => {
                    if (srvdata !== null) {
                        let bulkdata = {};
                        bulkdata[CONSTANTS.kPsistPendingAssociation] = CONSTANTS.AccountSecureMedium.AccountSecureMediumGGL;
                        await userDefault.setMultiple(bulkdata);

                        let tempauthdata = {
                            authuser: srvdata[CONSTANTS.kAuthUser],
                            authsecret: srvdata[CONSTANTS.kAuthSecret],
                            uid: srvdata[CONSTANTS.kUid],
                            email: srvdata[CONSTANTS.kParamEmail],
                        };

                        let lexauthdatainserted = await lxlsLgnMgr.storeTempLoginInfo(tempauthdata);

                        if (lexauthdatainserted) {
                            let assocdata: LexComAuthData = {
                                [CONSTANTS.kPlatformLexCom]: {
                                    [CONSTANTS.kAuthUser]: srvdata[CONSTANTS.kAuthUser],
                                    [CONSTANTS.kAuthSecret]: srvdata[CONSTANTS.kAuthSecret],
                                },
                            };
                            this.doAssociation(assocdata);
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
                        }
                    } else {
                        dataServer.debouncedDispatch(actionSetIdle());
                        this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
                    }
                };
                this.doRegisterGoogleUser(userinfo, onCompletion);
            } else {
                this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
            }
        } else {
            this.doSignOutMostRecentLogin(true, translate('error_loggingin_msg'));
        }
    };

    doRegisterGoogleUser = (regdata: any, onCompletion: (RegisterGoogleUserSuccessResponse | null) => Promise<void>) => {
        //Change for react native web
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<RegisterGoogleUserResponse> = requestManager.doRegisterGoogleUser(regdata);
            rsp.then((response: AxiosResponse<RegisterGoogleUserResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((qq: RegisterGoogleUserResponse) => {
                    if ((qq?.check ?? CONSTANTS.kFailure).toUpperCase() === CONSTANTS.kSuccess.toUpperCase()) {
                        let tmpsrvresp: RegisterGoogleUserSuccessResponse = ((qq: any): RegisterGoogleUserSuccessResponse);
                        if (onCompletion ?? null !== null) {
                            onCompletion(tmpsrvresp);
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                        }
                    } else {
                        dataServer.debouncedDispatch(actionSetIdle());
                        let tmpsrvresp = ((qq: any): RegisterGoogleUserErrorResponse);
                        let errormsg = 'Unknown Error';
                        let errorcode = tmpsrvresp.errorcode ?? CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeNull;
                        switch (parseInt(errorcode)) {
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeMissingParams:
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeRefTknFailed:
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeAuthCodeFailed:
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeEmailVfctionFailed:
                                errormsg = translate('signUp_err_msg');
                                break;
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeEmailAlreadyRegistered:
                                errormsg = translate('exits_email_mgs');
                                break;
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeLexcomRegistrationFailed:
                                errormsg = translate('regist_fail_err');
                                break;
                            case CONSTANTS.lexAppleLgnErrCodes.lexAppleLgnErrCodeServerNetworkError:
                                errormsg = translate('server_err');
                                break;
                        }
                        this.doSignOutMostRecentLogin(true, errormsg);
                        // if (onCompletion ?? null !== null) {
                        //     onCompletion(regdata, null);
                        // }
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                });
        }
    };

    onAppleFastLogin = async (
        onCompletionCallback: ?() => void,
        credentialState: AppleCredentialState,
        appleAuthRequestResponse: AppleRequestResponse
    ): Promise<void> => {};

    onAppleLogin = async (
        onCompletionCallback: ?() => void,
        credentialState: AppleCredentialState,
        appleAuthRequestResponse: AppleRequestResponse
    ): Promise<void> => {};

    doRegisterAppleUser = (
        regdata: RegisterAppleUserRequest,
        onCompletion: (RegisterAppleUserRequest, RegisterAppleUserSuccessResponse | null) => Promise<void>
    ) => {};

    doAssociation = (assocdata: LexComAuthData | FBAuthData) => {
        let tempdata: {|
            channel: string,
            guid: string,
            uuid: string,
        |} = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: dataServer.getGUID() ?? '',
            [CONSTANTS.kParamUuid]: dataServer.getUUID() ?? '',
        };
        let reqdata: AssociationRequestData = { ...tempdata, ...assocdata };
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.doAssociation(reqdata);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => this.onAssociationResposeReceive(reqdata, result))
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                });
        }
    };

    onAssociationResposeReceive = (request: AssociationRequestData, response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let tempdata = ((response.data: any): AssociationResponse);
            if (tempdata.hasOwnProperty('status')) {
                let tempmrgrsp = ((tempdata: any): AssociationResponseInfo);
                let msgcode = tempmrgrsp?.messageCode ?? null;
                switch (msgcode) {
                    case CONSTANTS.lexAssociationStatusCode.lexAssociationStatusCodeMerge: {
                        this.onAssociationCodeMerge(request, tempmrgrsp);
                        break;
                    }
                    case CONSTANTS.lexAssociationStatusCode.lexAssociationStatusCodeConflict: {
                        this.onAssociationCodeConflict(request, tempmrgrsp);
                        break;
                    }
                    case CONSTANTS.lexAssociationStatusCode.lexAssociationStatusCodeMergeNotPossible:
                        this.onAssociationCodeMergeNotPossible(request, tempmrgrsp);
                        break;
                    case CONSTANTS.lexAssociationStatusCode.lexAssociationStatusCodeSwitchNotPossible:
                        this.onAssociationCodeSwitchingNotPossible(request, tempmrgrsp);
                        break;
                }
            } else if (tempdata.hasOwnProperty('guid')) {
                let tempmrgrsp = ((tempdata: any): AssociationResponseData);
                this.onAssociation(request, tempmrgrsp);
            } else {
                dataServer.debouncedDispatch(actionSetIdle());
            }

            // if (tempdata.hasOwnProperty('guid') && tempdata.hasOwnProperty('uuid')) {
            // }
        } else {
            dataServer.debouncedDispatch(actionSetIdle());
        }
    };

    onAssociation = (request: AssociationRequestData, response: AssociationResponseData) => {
        //RESET GUID UUID
        //PROFILE INFO CHANGE INCLUDING GUID, UUID, NAME, AVTAR ETC
        //GAMELIST REFRESH IS NEEDED
        //THE EXECUTION ENDS AFTER THAT
        this.onAssociationWindup();
        let guid = response.guid;
        let uuid = response.uuid;
        if (netManager.isConnected()) {
            requestManager.updatePsistDataGuidUuid(guid, uuid);
            let data = { channel: CONSTANTS.kChannel, guid: guid, uuid: uuid };

            requestManager.doGetProfile(data, (request, response) => {
                requestManager.onDoGetProfileResponse(request, response);
                WordValidityWebSocketProvider.getWebSocketConnection();
                fndApi.getFriendListCumulative(false);
                requestManager.fetchUserSettings();
                minStatsApi.getLoggedInUserStats();
                pushNtfMgr.doUpdateDevicePin(true);
                inAppPurchases.getPurchaseHistory();

                let profile = dataServer.getProfile();
                let promises: Array<AxiosPromise<ServerResponse>> = [];
                let p1: AxiosPromise<ServerResponse> = glApi.getActiveGamesList();
                promises.push(p1);
                let p2: AxiosPromise<ServerResponse> = glApi.getArchivedGamesList();
                promises.push(p2);
                Promise.all(promises)
                    .then(async ([a, b]) => {
                        let a1: ServerResponse = await a.data;
                        let b1: ServerResponse = await b.data;
                        if (a1.check === CONSTANTS.kSuccess && b1.check === CONSTANTS.kSuccess) {
                            let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                            let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                                dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                            });
                        } else if (a1.check === CONSTANTS.kSuccess) {
                            let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                            });
                        } else if (b1.check === CONSTANTS.kSuccess) {
                            let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                            });
                        }
                        this.onAssociationCompletion();
                        // a.text()
                        //     .then((result) => this.onActiveGamesListResposeReceive(JSON.parse(result)))
                        //     .catch((error) => handleException( error));
                        // b.text()
                        //     .then((result) => this.onArchiveGamesListResposeReceive(JSON.parse(result)))
                        //     .catch((error) => handleException( error));
                    })
                    .catch((error) => {
                        this.onAssociationCompletion();
                        dataServer.debouncedDispatch(actionSetIdle());
                    });
            });
        } else {
            this.onAssociationCompletion();
        }
    };

    onAssociationCodeMerge = (request: AssociationRequestData, response: AssociationResponseInfo) => {
        let showinfo = response?.continue ?? null;
        if (showinfo === '0') {
            dataServer.debouncedDispatch(actionSetIdle());
            let tmsg = response?.message ?? '';
            let tttl = response?.title ?? '';
            let alertBoxInfo: AlertBoxType = {
                title: tttl,
                message: tmsg,
                actions: [
                    {
                        text: translate('cancel'),
                        action: () => {
                            this.onAssociationCodeMergeCancel(request, response);
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBOTH,
                    },
                    {
                        text: translate('continue'),
                        action: () => {
                            this.onAssociationCodeMergeContinue(request, response);
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBUTTONONLY,
                    },
                ],
            };
            dataServer.getStore().dispatch(showAlert(alertBoxInfo));
        } else {
            this.onAssociationCodeMergeContinue(request, response);
        }
    };

    onAssociationCodeMergeCancel = async (request: AssociationRequestData, response: AssociationResponseInfo) => {
        /**
         * ASSOCIATION
         * SIGN OUT FROM THE ACCOUNT WHICH LED US HERE
         */
        await this.doSignOutMostRecentLogin(false, null);
        if (this._onCompletionCallback) {
            this._onCompletionCallback();
            this._onCompletionCallback = null;
        }
    };

    onAssociationCodeMergeContinue = (reqest: AssociationRequestData, response: AssociationResponseInfo) => {
        let tt = { domerge: 'y' };
        let mdata = { ...reqest, ...tt };
        this.doAssociation(mdata);
    };

    onAssociationCodeConflict = (request: AssociationRequestData, response: AssociationResponseInfo) => {
        dataServer.debouncedDispatch(actionSetIdle());
        let tmsg = response.message ?? '';
        let tttl = response.title ?? '';
        let alertBoxInfo: AlertBoxType = {
            title: tttl,
            message: tmsg,
            actions: [
                {
                    text: translate('cancel'),
                    action: () => {
                        this.onAssociationCodeConflictCancel(request, response);
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBOTH,
                },
                {
                    text: translate('continue'),
                    action: () => {
                        this.onAssociationCodeConflictContinue(request, response);
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    onAssociationCodeConflictCancel = async (
        request: AssociationRequestData,
        response: AssociationResponseInfo
    ): Promise<void> => {
        /**
         *
         * ASSOCIATION
         * SIGN OUT FROM THE ACCOUNT WHICH LED US HERE
         */
        await this.doSignOutMostRecentLogin(false, null);
        if (this._onCompletionCallback) {
            this._onCompletionCallback();
            this._onCompletionCallback = null;
        }
    };

    onAssociationCodeConflictContinue = async (
        requestassoc: AssociationRequestData,
        response: AssociationResponseInfo
    ): Promise<void> => {
        /**
         * ASSOCIATION
         * SIGN OUT FROM ALL OTHER ACCOUNTS LEAVING THIS LOGIN AS IT IS
         */
        await this.doSignOutOtherLogins();
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            pushNtfMgr.deleteDevicePin();
            requestManager.doGenGlobalID((request: GenGlobalIDRequest, response: ServerResponse) => {
                if (response.check === CONSTANTS.kSuccess) {
                    let respdata: GenGlobalIDResponseData = ((response.data: any): GenGlobalIDResponseData);
                    if (respdata.guid !== undefined && respdata.uuid !== undefined) {
                        let guid = respdata.guid;
                        let uuid = respdata.uuid;
                        requestManager.onGenGlobalIDResponse(request, response);
                        let data = { channel: CONSTANTS.kChannel, guid: guid, uuid: uuid };
                        requestManager.doGetProfile(data, (request, response) => {
                            requestManager.onDoGetProfileResponse(request, response);
                            let assocdata: LexComAuthData = {
                                [CONSTANTS.kPlatformLexCom]: requestassoc.lexcom,
                            };
                            this.doAssociation(assocdata);
                        });
                    } else {
                        dataServer.debouncedDispatch(actionSetIdle());
                    }
                } else {
                    dataServer.debouncedDispatch(actionSetIdle());
                }
            });
        }
    };

    onAssociationCodeMergeNotPossible = async (
        requestassoc: AssociationRequestData,
        response: AssociationResponseInfo
    ): Promise<void> => {
        /**
         * ASSOCIATION
         * SIGN OUT FROM THE ACCOUNT WHICH LED US HERE
         */
        dataServer.debouncedDispatch(actionSetIdle());
        await this.doSignOutMostRecentLogin(false, null);
        if (this._onCompletionCallback) {
            this._onCompletionCallback();
            this._onCompletionCallback = null;
        }
        let tmsg = response.message ?? '';
        let alertBoxInfo: AlertBoxType = {
            message: tmsg,
            actions: [
                {
                    text: translate('ok'),
                    action: () => {
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    onAssociationCodeSwitchingNotPossible = async (
        requestassoc: AssociationRequestData,
        response: AssociationResponseInfo
    ): Promise<void> => {
        /**
         * ASSOCIATION
         * SIGN OUT FROM THE ACCOUNT WHICH LED US HERE
         */
        dataServer.debouncedDispatch(actionSetIdle());
        await this.doSignOutMostRecentLogin(false, null);
        if (this._onCompletionCallback) {
            this._onCompletionCallback();
            this._onCompletionCallback = null;
        }
        let tmsg = response.message ?? '';
        let alertBoxInfo: AlertBoxType = {
            message: tmsg,
            actions: [
                {
                    text: translate('ok'),
                    action: () => {
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    onAssociationWindup = async (): Promise<void> => {
        pushNtfMgr.deleteDevicePin();
        this.cleanOldOrInvalidData();
        WordValidityWebSocketProvider.disconnect();
        if (this._lgnMgr) {
            let tlg = this._lgnMgr;
            await tlg.onAssociationCompletion(null);
            if (CONSTANTS.tmpLexLgnSym.indexOf(tlg.type) >= 0) {
                await lxlsLgnMgr.promoteTempLoginInfo();
                await lxlsLgnMgr.deleteTempLoginData();
            }
            this._lgnMgr = null;
        }
    };

    onAssociationCompletion = async (): Promise<void> => {
        if (this._onCompletionCallback) {
            this._onCompletionCallback();
            this._onCompletionCallback = null;
        }
    };

    doSignOutMostRecentLogin = async (showerror: boolean, msg: ?string): Promise<void> => {
        if (this._lgnMgr) {
            let onCompletion = null;
            let tlg = this._lgnMgr;

            if (CONSTANTS.tmpLexLgnSym.indexOf(this._lgnMgr.type) >= 0) {
                onCompletion = () => {
                    lxlsLgnMgr.deleteTempLoginData();
                };
            }
            await tlg.doSignOut(onCompletion);
            this._lgnMgr = null;
        }
        if (showerror) {
            let tmsg = msg ?? '';
            let alertBoxInfo: AlertBoxType = {
                message: tmsg,
                actions: [
                    {
                        text: translate('ok'),
                        action: () => {
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBUTTONONLY,
                    },
                ],
            };
            dataServer.getStore().dispatch(showAlert(alertBoxInfo));
        }
    };

    doSignOutOtherLogins = async (): Promise<void> => {
        if (this._lgnMgr) {
            switch (this._lgnMgr.type) {
                case 'GGLgnMgr': {
                    applLgnMgr.doSignOut(null);
                    fbLgnMgr.doSignOut(null);
                    lxlsLgnMgr.doSignOut(null);
                    break;
                }
                case 'FBLgnMgr': {
                    lxlsLgnMgr.deleteTempLoginData();
                    applLgnMgr.doSignOut(null);
                    gglLgnMgr.doSignOut(null);
                    lxlsLgnMgr.doSignOut(null);
                    break;
                }
                case 'ApplLgnMgr': {
                    fbLgnMgr.doSignOut(null);
                    gglLgnMgr.doSignOut(null);
                    lxlsLgnMgr.doSignOut(null);
                    break;
                }
                case 'LXLSLgnMgr': {
                    applLgnMgr.doSignOut(null);
                    gglLgnMgr.doSignOut(null);
                    fbLgnMgr.doSignOut(null);
                    break;
                }
            }
        }
    };

    cleanOldOrInvalidData = () => {
        batch(() => {
            dataServer.getStore().dispatch(actionClearProfile());
            dataServer.getStore().dispatch(glClearData());
            dataServer.getStore().dispatch(aglClearData());
            dataServer.getStore().dispatch(actionGLBLFndClearData());
            dataServer.getStore().dispatch(actionLNRClearData());
            dataServer.getStore().dispatch(actionClearMinStats());
            dataServer.getStore().dispatch(actionResetHostedGames([]));
        });
    };

    fetchInitDataFromUserPrefs = async (): Promise<PsistData> => {
        let reqdata = [CONSTANTS.kPsistGUID, CONSTANTS.kPsistUUID];

        let result = await userDefault.getMultiple(reqdata);
        let data: PsistData = {};
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    switch (reqdata[index]) {
                        case CONSTANTS.kPsistGUID:
                            data.guid = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistUUID:
                            data.uuid = JSON.parse(JSON.stringify(value));
                            break;
                    }
                }
            });
        }
        return data;
    };
}

const loginCoordinator = new LoginCoordinator();

export default loginCoordinator;
