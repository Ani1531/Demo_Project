import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, Pressable } from 'react-native';
import { connect } from 'react-redux';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import TwoLetterWordsPassages from '../component/TwoLetterWordsPassages';
import DimensionUtils from '../utils/DimensionUtils';
import MoveScoreGraphPanel from './MoveScoreGraphPanel';
import { createDialogInstance } from '../utils/MessageUtils';
import get from 'lodash/get';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import ServiceWrapper from '../utils/ServiceWrapper';
import SettingsUtil from '../utils/SettingsUtil';
import rjAnalytics from '../RJAnalytics';

const eventBus = require('js-event-bus')();

const menuForLiveGame = [
    {
        key: 'Del_N_Rsgn_game',
        title: 'Delete Game',
    },
    {
        key: 'two_letter',
        title: '2 Letter Words',
    },
    {
        key: 'dictionary',
        title: 'Dictionary',
    },
    {
        key: 'unseenTile',
        title: 'Unseen tiles',
    },
    {
        key: 'addfrnd_block',
        title: 'Add friend / Block',
    },
    {
        key: 'chat',
        title: 'Chat',
    },
    {
        key: 'move_list',
        title: 'Move List',
    },
    {
        key: 'movegraph',
        title: 'Move graph',
    },
    {
        key: 'feedback',
        title: 'Feedback',
    },
];

const menuForObserveGame = [
    {
        key: 'Del_N_Rsgn_game',
        title: 'Delete Game',
    },
    {
        key: 'two_letter',
        title: '2 Letter Words',
    },
    {
        key: 'dictionary',
        title: 'Dictionary',
    },
    {
        key: 'unseenTile',
        title: 'Unseen tiles',
    },
    {
        key: 'move_list',
        title: 'Move List',
    },
    {
        key: 'movegraph',
        title: 'Move graph',
    },
    {
        key: 'feedback',
        title: 'Feedback',
    },
];

class MenuContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            submennu: '',
        };
    }

    getDimension = () => {
        let height =
            get(this.props, 'layout.layoutBoardDimenWidth') + 2 * get(this.props, 'layout.layoutBoardAboveViewsHeight');
        return {
            width: '100%',
            height: height,
            backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
            position: 'absolute',
            zIndex: 1,
            paddingHorizontal: this.state.submennu === 'dictionary' ? 8 : null,
        };
    };

    getOpponentData = () => {
        let oppData = get(this.props, 'game.players');
        let opponent = oppData.find((item) => item.guid !== get(this.props, 'game.guid'));
        return opponent;
    };

    isMyFriend = () => {
        let buddyList = get(this.props, 'user.buddyList') || {};
        let player = this.getOpponentData();
        return !!(
            (buddyList.buddies || []).find((buddy) => buddy.guid === player.guid) ||
            (buddyList.reqsent || []).find((request) => request.guid === player.guid) ||
            (buddyList.online || []).find((onlinePlayer) => onlinePlayer.guid === player.guid)
        );
    };

    toggleFriendshipConfirmation = () => {
        this.props.closeMenuHandler();
        let player = this.getOpponentData();
        createDialogInstance({
            title: this.isMyFriend() ? 'Remove Friend' : 'Add Friend',
            actionButtonText: 'Yes',
            onAction: () => this.toggleFriendship(player),
            body: 'Are you sure you wish to ' + (this.isMyFriend() ? 'remove' : 'add') + ' ' + player.name + ' as friend?',
            cancelButtonText: 'No',
        });
    };

    toggleFriendship = async (item = this.props.item) => {
        await LiveGamePlayUtils.toggleFriendship(item);
        this.setState({ lastRendered: Date.now() });
    };

    isBlockedByMe = () => {
        let sensorList = get(this.props, 'user.sensorList') || [];
        let player = this.getOpponentData();
        return sensorList.some((sensored) => sensored.guid === (get(player, 'guid') || get(player, 'uid')));
    };

    toggleBlockConfirmation = (hostedGame) => {
        this.props.closeMenuHandler();
        let player = this.getOpponentData();
        createDialogInstance({
            title: this.isBlockedByMe() ? 'Uncensor Player' : 'Censor Player',
            actionButtonText: 'Yes',
            onAction: () => this.toggleBlock(player),
            body: 'Are you sure you wish to ' + (this.isBlockedByMe() ? 'uncensor' : 'censor') + ' ' + player.name + '?',
            cancelButtonText: 'No',
        });
    };

    toggleBlock = async (item = this.props.item) => {
        await LiveGamePlayUtils.toggleBlock(item);
        this.setState({ lastRendered: Date.now() });
    };

    setSubMenuType = (type) => {
        this.setState({ submennu: type });
    };

    getDictionaryType = () => {
        switch (get(this.props, 'game.dic')) {
            case 'twl':
                return 'US';
            case 'sow':
                return 'UK';
            case 'it':
                return 'IT';
            case 'fr':
                return 'FR';
            default:
                return 'US';
        }
    };

    getCrossCloseBtn = () => {
        return (
            <TouchableOpacity style={[styles.btnStyle, styles.padRightFour]} onPress={() => this.props.closeMenuHandler()}>
                <FontAwesomeIcon icon={faTimes} size={20} colo={ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR} />
            </TouchableOpacity>
        );
    };

    getDialogHeader = (title) => {
        return (
            <View style={[styles.dialogheaderStyle, { marginTop: 8 }]}>
                <Text style={styles.headerText}>{title}</Text>
                {this.getCrossCloseBtn()}
            </View>
        );
    };

    renderTwoLetterWords = () => {
        return (
            <Pressable style={[styles.popUpEffect, styles.mainView]}>
                {this.getDialogHeader(`Two Letter Words  (${this.getDictionaryType()})`)}
                <View style={styles.dialogBodyStyle}>
                    <TwoLetterWordsPassages />
                    <Text style={styles.gameidText}>{`Game #${get(this.props, 'game.gid')}`}</Text>
                </View>
            </Pressable>
        );
    };

    renderAddfrndAndBlock = () => {
        return (
            <Pressable style={[styles.popupMainView, styles.popUpEffect]}>
                <View style={styles.buttonField}>
                    <TouchableOpacity style={[styles.btnStyle]} onPress={this.toggleFriendshipConfirmation}>
                        <Text style={[styles.btnText]}>{this.isMyFriend() ? 'Remove Friend' : 'Add friend'}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.btnStyle]} onPress={this.toggleBlockConfirmation}>
                        <Text style={[styles.btnText]}>{this.isBlockedByMe() ? 'Unblock' : 'Block'}</Text>
                    </TouchableOpacity>
                </View>
            </Pressable>
        );
    };

    renderMoveScoreGraph = () => {
        return (
            <Pressable style={[styles.popUpEffect, styles.mainView]}>
                {this.getDialogHeader('Move Score Graph')}
                <View style={styles.dialogBodyStyle}>
                    <MoveScoreGraphPanel />
                </View>
            </Pressable>
        );
    };

    renderFeedback = () => {
        return (
            <Pressable style={[styles.popUpEffect, styles.mainView]}>
                {this.getDialogHeader('Feedback')}
                <View style={styles.feedbackBody}>
                    <View>
                        <Text style={styles.textStylefdbck}>Your Email ID</Text>
                        <View style={[styles.inputContainerStyle]}>
                            <View style={styles.emailInputStyle}>
                                <TextInput style={[styles.textInputStyle]} />
                            </View>
                        </View>
                    </View>
                    <View>
                        <Text style={styles.textStylefdbck}>Comments</Text>
                        <View style={[styles.inputContainerStyle]}>
                            <View style={styles.commentInputStyle}>
                                <TextInput multiline={true} numberOfLines={4} style={[styles.textInputStyle]} />
                            </View>
                        </View>
                    </View>
                    <View style={styles.btnStyleFdbckcontainer}>
                        <TouchableOpacity style={styles.btnStyleFdbck} onPress={() => {}}>
                            <Text style={styles.textStylefdbck}>Send</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Pressable>
        );
    };

    setUserSettings = () => {
        let settingsData = { us_privacy: { pvc_disablechat: 'n' } };
        SettingsUtil.sendSetting(settingsData);
    };

    showEnableChatDialogModal = () => {
        let isChatEnabled = this.props.config.show_game_chat;
        if (isChatEnabled) {
            this.props.openChatorDictionary('chat');
            rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_CHAT_BUTTON, 'BOARD');
        } else {
            createDialogInstance({
                title: 'Chat is disabled',
                actionButtonText: 'Enable',
                secondButtonText: 'Cancel',
                onAction: () => {
                    this.setUserSettings();
                    this.props.openChatorDictionary('chat');
                    rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_CHAT_BUTTON_ALLOW, 'MenuContainer');
                },
                body: 'Would you like to enable?',
            });
        }
    };

    haveInitialMovesCompleted = () => {
        let i,
            isCompleted = 'no';
        let playersArray = this.props.game.players;
        if (playersArray != undefined && playersArray != null) {
            if (this.props.game.moveListCompleteData.length !== 0) {
                for (i = 1; i <= playersArray.length; i++) {
                    if (typeof this.props.game.moveListCompleteData[0][i] === 'object') {
                        isCompleted = 'yes';
                    } else {
                        isCompleted = 'no';
                        return isCompleted;
                    }
                }
            }
        }

        return isCompleted;
    };

    getSubmenu = (element) => {
        let setSubeMenu = () => {
            switch (element.key) {
                case 'feedback':
                    ServiceWrapper.openSupport(this.props.openSupport);
                    break;
                case 'back':
                    this.props.gameBoardGoBack && this.props.gameBoardGoBack();
                    break;
                default:
                    this.setSubMenuType(element.key);
                    break;
            }
        };

        if (element.key === 'chat' || element.key === 'dictionary') {
            ServiceWrapper.nativeShowInterstitialAd(setSubeMenu());
        } else {
            setSubeMenu();
        }
    };

    renderMainMenu = () => {
        let menuList =
            (![Config.GAME_TYPE_PUZZLE].includes(get(this.props, 'game.game_type')) &&
                !get(this.props, 'game.pid') &&
                get(this.props, 'game.gid')) ||
            [Config.GAME_TYPE_SOLO, Config.GAME_TYPE_BLITZ].includes(get(this.props, 'game.game_type'))
                ? menuForObserveGame
                : menuForLiveGame;
        if (![Config.GAME_TYPE_LIVE_GAME].includes(get(this.props, 'game.game_type'))) {
            menuList = [
                ...menuList,
                {
                    key: 'back',
                    title: 'Back',
                },
            ];
        }
        return (
            <Pressable style={[styles.popupMainView, styles.popUpEffect]}>
                <View style={styles.buttonField}>
                    {menuList.map((element, index) => {
                        if (element.key === 'Del_N_Rsgn_game') {
                            element.title = this.haveInitialMovesCompleted() === 'yes' ? 'Resign Game' : 'Delete Game';
                        }
                        return (
                            <TouchableOpacity key={index} style={[styles.btnStyle]} onPress={() => this.getSubmenu(element)}>
                                <Text style={[styles.btnText]}>{element.title}</Text>
                            </TouchableOpacity>
                        );
                    })}
                </View>
            </Pressable>
        );
    };

    renderBody = () => {
        switch (this.state.submennu) {
            case 'Del_N_Rsgn_game':
                let willResign = this.haveInitialMovesCompleted() === 'yes';
                eventBus.emit(Config.RESIGN_DELETE_GAME, null, { doResign: willResign });
                this.props.closeMenuHandler();
                rjAnalytics.sendAnalyticsEvent(
                    willResign
                        ? Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_RESIGN_BUTTON
                        : Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_DELETE_BUTTON,
                    'BOARD'
                );
                break;

            case 'two_letter':
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_TWO_LETTER_BUTTON, 'BOARD');
                return this.renderTwoLetterWords();

            case 'dictionary':
                this.props.closeMenuHandler();
                this.props.openChatorDictionary('dictionary');
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_DICTIONARY_BUTTON, 'BOARD');
                break;

            case 'unseenTile':
                eventBus.emit(Config.SHOW_UNSEEN_TILES_DIALOG, null);
                this.props.closeMenuHandler();
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_UNSEEN_TILE_BUTTON, 'BOARD');
                break;

            case 'addfrnd_block':
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_FRIEND_ADD_BLOCK, 'BOARD');
                return this.renderAddfrndAndBlock();

            case 'chat':
                this.props.closeMenuHandler();
                this.showEnableChatDialogModal();
                break;

            case 'move_list':
                eventBus.emit(Config.SHOW_MOVES_LIST);
                this.props.closeMenuHandler();
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_MOVE_LIST_BUTTON, 'BOARD');
                break;

            case 'movegraph':
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_MOVE_GRAPH_BUTTON, 'BOARD');
                return this.renderMoveScoreGraph();

            case 'feedback':
                rjAnalytics.sendAnalyticsEvent(Config.ANALYTICS_EVENT_ACTION.GAMEBOARD_FEEDBACK_BUTTON, 'BOARD');
                return this.renderFeedback();

            default:
                return this.renderMainMenu();
        }
    };

    mainRender = () => (
        <View style={styles.popupView}>
            <Pressable
                onPress={() => {
                    this.props.closeMenuHandler();
                }}
                style={styles.popupContainer}
            >
                {this.renderBody()}
            </Pressable>
        </View>
    );

    render = () => (DimensionUtils.isNative() ? this.mainRender() : null);
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        backgroundColor: 'rgba(45, 52, 54,0.5)',
    },
    popupContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    popupMainView: {
        width: '60%',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderRadius: 4,
        paddingVertical: 16,
        paddingHorizontal: 24,
    },
    mainView: {
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        height: 300,
        width: 300,
        borderRadius: 4,
        padding: 8,
    },
    fullView: { width: '100%', height: '100%' },
    dialogheaderStyle: {
        height: '12%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 8,
    },
    dialogBodyStyle: {
        height: '80%',
        paddingHorizontal: 8,
    },
    headerText: {
        color: ColorConfig.DIALOG_MODAL_HEADING_TEXT_COLOR,
        fontSize: 18,
    },
    gameidText: {
        marginLeft: 8,
        fontWeight: 'bold',
    },
    buttonField: {
        justifyContent: 'center',
    },
    btnStyle: {
        marginVertical: 4,
    },
    btnText: {
        marginVertical: 4,
    },
    popUpEffect: {
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    padRightFour: { paddingRight: 4 },
    feedbackBody: {
        paddingLeft: 8,
        paddingRight: 16,
    },
    inputContainerStyle: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottomColor: 'black',
        borderBottomWidth: 1,
    },
    textInputStyle: {
        textAlignVertical: 'top',
        fontSize: 16,
        paddingBottom: 0,
    },
    btnStyleFdbckcontainer: {
        display: 'flex',
        flexDirection: 'row',
        paddingVertical: 12,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    btnStyleFdbck: {
        height: 30,
        width: 60,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
    },
    textStylefdbck: {
        padding: 4,
        fontSize: 15,
    },
    emailInputStyle: {
        height: 40,
        width: '100%',
    },
    commentInputStyle: {
        height: 90,
        width: '100%',
    },
});

const mapStateToProps = (state) => ({
    user: state.user,
    game: state.game,
    layout: state.layout,
    config: state.config,
});

export default connect(mapStateToProps)(MenuContainer);
