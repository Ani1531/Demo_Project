import React from 'react';
import { FlatList, StyleSheet } from 'react-native';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import set from 'lodash/set';
import { connect } from 'react-redux';
import GameBoardUtils from '../utils/GameBoardUtils';
import ColorConfig from '../configs/ColorConfig';
import ObservableGameListItem from './ObservableGameListItem';
import DimensionUtils from '../utils/DimensionUtils';

class WatchGameListFlatList extends React.Component {
    shouldComponentUpdate = (nextProps) =>
        !isEqual(
            get(nextProps, 'gamelist.observableGamesList'),
            get(this.props, 'gamelist.observableGamesList')
        );

    getCursor = (isPlaying, item) => ({
        cursor:
            isPlaying || GameBoardUtils.isMyself(item) ? 'default' : 'pointer',
    });

    renderObserveGame = ({ item, index }) => {
        (get(item, 'players') || []).forEach((player) =>
            set(player, 'fullInfo.status', 'ply')
        );
        return (
            <ObservableGameListItem
                onObserveGame={this.props.onObserveGame}
                isMyself={GameBoardUtils.isMyself(item)}
                item={item}
                rowColor={
                    index % 2 !== 0
                        ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN
                        : null
                }
                isMobile={DimensionUtils.isMobile()}
                layoutCellDimen={this.props.layout.layoutCellDimen}
            />
        );
    };

    render = () => (
        <FlatList
            data={get(this.props, 'gamelist.observableGamesList')}
            renderItem={this.renderObserveGame}
            style={[
                {
                    width: '100%',
                    height: '100%',
                },
                styles.hostedGameListBackgroundColor,
            ]}
            keyExtractor={(item) => item.gid}
            removeClippedSubviews={true}
            initialNumToRender={8}
            showsVerticalScrollIndicator={true}
            className={'appFlatList'}
        />
    );
}

const styles = StyleSheet.create({
    hostedGameListBackgroundColor: {
        backgroundColor: ColorConfig.HOSTED_GAMES_LIST_BACKGROUND_COLOR,
    },
});

const mapStateToProps = (state) => ({
    config: state.config,
    gamelist: state.gamelist,
    layout: { layoutCellDimen: get(state, 'layout.layoutCellDimen') },
});

export default connect(mapStateToProps)(WatchGameListFlatList);
