// @flow

import React from 'react';
import { Pressable, StyleSheet } from 'react-native';
import * as CONSTANTS from '../commons/Constants';
import { bindActionCreators } from 'redux';
import { actionUpdateUserSettings } from '../userprofile/PFLAction';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import type { userSettings, ServerResponse, AppUtilsTypes } from '../commons/RJTypes';
import requestManager from '../commons/RequestManager';
import netManager from '../commons/RJNetInfo';
import dataServer from '../store/Store';
import { connect } from 'react-redux';
import SwiperContainer from './SwiperContainer';
import type { NavigationStackProp } from '@react-navigation/native';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { handleException } from '../commons/RJUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import rjAnalytics from '../../../../RJAnalytics';
import { SafeAreaView } from 'react-native-safe-area-context';

type RJSHRpickerprops = {
    ...NavigationStackProp,
    profileSettings: userSettings,
    utils: AppUtilsTypes,
};

class RJSHRpicker extends React.Component<RJSHRpickerprops> {
    constructor(props: RJSHRpickerprops) {
        super(props);
    }
    componentDidMount() {
        this.props.navigation.setOptions({
            headerLeft: () => {
                return (
                    <Pressable
                        style={styles.backButton}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('rjshrpicker_theme_closed', 'rjshrpicker');
                            this.props.navigation.goBack();
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
                    </Pressable>
                );
            },
        });
    }

    didSelectedBoardOrTile = (userdata: { [string]: string }, selectedItem: string) => {
        let idx = userdata.idx;
        let sectiontag: string = 'us_gameplay';
        let sectionelementtag: string = 'gp_gametheme';
        let theme_server_value = this.props.profileSettings[sectiontag][sectionelementtag]?.split('-') ?? ['0', '0'];
        theme_server_value[idx] = selectedItem;
        let updated_value: string = theme_server_value.join('-');

        let setting_lbl = {
            [sectiontag]: {
                [sectionelementtag]: updated_value,
            },
        };
        this.updateUserSetting(setting_lbl);
    };

    updateUserSetting = (settings: userSettings) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateUserSetting(settings);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    dataServer.getStore().dispatch(actionUpdateUserSettings(settings));
                    this.props.navigation.goBack();
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    renderBoardOrTileSelector = (userdata: { [string]: string }, item: { [string]: any }) => {
        return (
            <SwiperContainer
                userData={userdata}
                themeArr={Object.keys(item)}
                header={this.props.route.params.header}
                currentSelection={this.props.route.params.currentSelection}
                didSelectedItem={(userdata: { [string]: string }, selectedItem: string) => {
                    this.didSelectedBoardOrTile(userdata, selectedItem);
                    rjAnalytics.sendAnalyticsEvent('rjshrpicker_theme_select_closed', 'rjshrpicker');
                }}
                themeSource={item}
            />
        );
    };

    renderSelections() {
        switch (this.props.route.params.tag) {
            case 'gp_boardtheme':
                return this.renderBoardOrTileSelector({ idx: '0' }, CONSTANTS.boardThemes);
            case 'gp_tiletheme':
                return this.renderBoardOrTileSelector({ idx: '1' }, CONSTANTS.tileThemes);
            default:
                return this.renderBoardOrTileSelector({ idx: '0' }, CONSTANTS.boardThemes);
        }
    }

    render() {
        return (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                {this.renderSelections()}
            </SafeAreaView>
        );
    }
}
const styles = StyleSheet.create({
    backButton: {
        padding: 10,
    },
});
function mapStateToProps(state) {
    const { profileSettings, utils } = state;
    return { profileSettings, utils };
}
const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionUpdateUserSettings,
        },
        dispatch
    );
export default connect(mapStateToProps, mapDispatchToProps)(RJSHRpicker);
