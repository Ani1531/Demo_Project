// @flow

import {
    kPsistDevicePin,
    HTTPSuccessStatus,
    kSuccess,
    Super,
    server_S,
    server_N,
    Board_sz_s,
    Board_sz_n,
    kNtfPinTimestampInSec,
    kNtfPinResendDurationSec,
    NtfReceiveState,
    NtfReceiveType,
} from '../commons/Constants';
import { Notifications } from 'react-native-notifications';
import type { Notification, Registered, RegistrationError } from 'react-native-notifications';
import type EmitterSubscription from 'react-native/Libraries/vendor/emitter/EmitterSubscription';
import type { AxiosPromise, AxiosResponse } from 'axios';
import type { ServerResponse, NtfAndroidData, NtfIOSData, NtfGameData, NtfIOSGameData, AlertBoxType } from '../commons/RJTypes';
import requestManager from '../commons/RequestManager';
import { Platform } from 'react-native';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import dataServer from '../store/Store';
import { setEmailData } from '../../../../actions/GameActions';
import * as PFLSelector from '../userprofile/PFLSelector';
import * as RootNavigation from '../commons/RootNavigation';
import { translate } from '../commons/translations/LangTransator';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';
import { handleException } from './RJUtils';
import userDefault from './UserDefault';

class PushNtfMgr {
    _currentDevicePin: string = '';
    _incommingPin: string = '';

    ntfForegoundListener: ?EmitterSubscription = null;
    ntfOpenedListener: ?EmitterSubscription = null;
    ntfRegisteredListener: ?EmitterSubscription = null;
    ntfRegistrationFailedListener: ?EmitterSubscription = null;

    constructor() {
        userDefault.get(kPsistDevicePin).then((value) => {
            this._currentDevicePin = value ?? '';
        });
    }

    mountPushNotification = (callback: ?(boolean) => void) => {
        this.unmountPushNotification();

        Notifications.registerRemoteNotifications();

        this.ntfForegoundListener = Notifications.events().registerNotificationReceivedForeground(
            (notification: Notification, completion) => {
                this.doHandleNotification(notification, NtfReceiveState.NtfForeground);
                completion({ alert: false, sound: false, badge: false });
            }
        );

        this.ntfOpenedListener = Notifications.events().registerNotificationOpened((notification: Notification, completion) => {
            this.doHandleNotification(notification, NtfReceiveState.NtfOpened);
            completion();
        });

        this.ntfRegisteredListener = Notifications.events().registerRemoteNotificationsRegistered((event: Registered) => {
            this._incommingPin = event.deviceToken;
            if (callback != null && callback != undefined) {
                callback(true);
                callback = null;
            }
        });

        this.ntfRegistrationFailedListener = Notifications.events().registerRemoteNotificationsRegistrationFailed(
            (event: RegistrationError) => {
                if (callback != null && callback != undefined) {
                    callback(false);
                    callback = null;
                }
            }
        );
    };

    doGetInitialNotification = () => {
        Notifications.getInitialNotification().then((notification: ?Notification) => {
            if (notification != null && notification != undefined) {
                this.doHandleNotification(notification);
            }
        });
    };

    unmountPushNotification = () => {
        if (this.ntfForegoundListener) {
            this.ntfForegoundListener.remove();
            this.ntfForegoundListener = null;
        }
        if (this.ntfOpenedListener) {
            this.ntfOpenedListener.remove();
            this.ntfOpenedListener = null;
        }
        if (this.ntfRegisteredListener) {
            this.ntfRegisteredListener.remove();
            this.ntfRegisteredListener = null;
        }
        if (this.ntfRegistrationFailedListener) {
            this.ntfRegistrationFailedListener.remove();
            this.ntfRegistrationFailedListener = null;
        }
    };

    shouldUpdatePin = (pin: string): boolean => {
        return this.isPinValid(pin) && !this.isPinSame(pin);
    };

    shouldDeletePin = (pin: string): boolean => {
        return this.isPinValid(pin);
    };

    isPinValid = (pin: string): boolean => {
        return pin != null && pin != undefined && pin.length > 0;
    };

    isPinSame = (pin: string): boolean => {
        return pin == this._currentDevicePin;
    };

    doUpdateDevicePin = (forceupdate?: boolean) => {
        if (this.isPinValid(this._incommingPin) && (forceupdate || !this.isPinSame(this._incommingPin))) {
            if (this.shouldDeletePin(this._currentDevicePin) && !this.isPinSame(this._incommingPin)) {
                this.deleteDevicePin(this._currentDevicePin);
            }
            this.updateDevicePin(this._incommingPin, 'n');
        }
    };

    updateDevicePin = (pin: string, ack: string) => {
        if (pin) {
            let rq: AxiosPromise<ServerResponse> = requestManager.updateDevicePin(pin, ack);
            rq.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then(async (srvresp: ServerResponse) => {
                    if (srvresp.check === kSuccess) {
                        userDefault.set(kPsistDevicePin, pin);
                        let pinTimestampInSec = Math.floor(Date.now() / 1000);
                        userDefault.set(kNtfPinTimestampInSec, pinTimestampInSec.toString());
                        this._currentDevicePin = pin;
                    } else {
                        console.log('updateDevicePin error', srvresp);
                    }
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {});
        }
    };

    deleteDevicePin = (pin: ?string) => {
        let resetlastsuccessfulsend = pin == null || pin == undefined;
        if (resetlastsuccessfulsend) {
            userDefault.set(kNtfPinTimestampInSec, '0');
        }
        let todelete = pin ?? this._currentDevicePin;
        if (this.shouldDeletePin(todelete)) {
            let rq: AxiosPromise<ServerResponse> = requestManager.deleteDevicePin(todelete);
            rq.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then(async (srvresp: ServerResponse) => {
                    if (srvresp.check != kSuccess) {
                        console.log('deleteDevicePin error', srvresp);
                    }
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {});
        }
    };

    doHandleNotification = (notification: Notification, ntfstate?: string) => {
        let showAlertPopup = ntfstate != null && ntfstate != undefined && ntfstate == NtfReceiveState.NtfForeground;
        if (Platform.OS == 'android') {
            let ntfdata: NtfAndroidData = ((notification.payload: any): NtfAndroidData);
            if (ntfdata.type == NtfReceiveType.NtfReceiveTypeACK) {
                let ntfMsg = ntfdata.title;
                if (showAlertPopup) {
                    this.showAleartForTestNtf(ntfMsg);
                }
            } else {
                if (
                    !showAlertPopup &&
                    ntfdata.data != null &&
                    ntfdata.data != undefined &&
                    (ntfdata.data.includes('gbd') || ntfdata.data.includes('cht'))
                ) {
                    let gdata: NtfGameData = JSON.parse(ntfdata.json)['games'];
                    let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
                    let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
                    if (
                        gdata != null &&
                        gdata != undefined &&
                        sguid != null &&
                        sguid != undefined &&
                        suuid != null &&
                        suuid != undefined
                    ) {
                        let boardType = 'N';
                        let mypid = Object.keys(gdata.players).find((key) => gdata.players[key].includes(sguid));
                        if (mypid != null && mypid != undefined) {
                            const gameBoardData: gameBoardDataExchng = {
                                gid: gdata.gameid,
                                pid: mypid,
                                dic: gdata.dic, //sow, fr, it
                                boarddes: 'n',
                                already_attempted: false,
                                game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                                board_type: boardType == Super ? server_S : server_N,
                                guid: sguid,
                                uuid: suuid,
                                board_size: boardType == Super ? Board_sz_s : Board_sz_n,
                            };
                            gameBoardDataExchanger.gameBoardData = gameBoardData;
                            dataServer.getStore().dispatch(setEmailData(gameBoardData));
                            RootNavigation.navigationRef.current?.navigate('BoardScreen');
                        }
                    }
                }
            }
        } else if (Platform.OS == 'ios') {
            let ntfdata: NtfIOSData = ((notification.payload: any): NtfIOSData);
            if (ntfdata.pldata != null && ntfdata.pldata != undefined) {
                let pldata: NtfIOSGameData = JSON.parse(ntfdata.pldata);
                if (pldata != null && pldata != undefined) {
                    let type = pldata.type ?? null;
                    if (type == NtfReceiveType.NtfReceiveTypeACK) {
                        let ntfMsg = notification.payload.aps.alert ?? '';
                        if (showAlertPopup) {
                            this.showAleartForTestNtf(ntfMsg);
                        }
                    } else if (
                        !showAlertPopup &&
                        (type == NtfReceiveType.NtfReceiveTypeMove ||
                            type == NtfReceiveType.NtfReceiveTypePass ||
                            type == NtfReceiveType.NtfReceiveTypeSwap ||
                            type == NtfReceiveType.NtfReceiveTypeNewGame ||
                            type == NtfReceiveType.NtfReceiveTypeChat ||
                            type == NtfReceiveType.NtfReceiveTypeDelGame ||
                            type == NtfReceiveType.NtfReceiveTypeResign ||
                            type == NtfReceiveType.NtfReceiveTypeGameOver)
                    ) {
                        if (pldata.games != null && pldata.games != undefined) {
                            let gdata: NtfGameData = pldata.games;
                            let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
                            let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
                            if (sguid != null && sguid != undefined && suuid != null && suuid != undefined) {
                                let boardType = 'N';
                                let mypid = Object.keys(gdata.players).find((key) => gdata.players[key].includes(sguid));
                                if (mypid != null && mypid != undefined) {
                                    const gameBoardData: gameBoardDataExchng = {
                                        gid: gdata.gameid,
                                        pid: mypid,
                                        dic: gdata.dic, //sow, fr, it
                                        boarddes: 'n',
                                        already_attempted: false,
                                        game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                                        board_type: boardType == Super ? server_S : server_N,
                                        guid: sguid,
                                        uuid: suuid,
                                        board_size: boardType == Super ? Board_sz_s : Board_sz_n,
                                    };
                                    gameBoardDataExchanger.gameBoardData = gameBoardData;
                                    dataServer.getStore().dispatch(setEmailData(gameBoardData));
                                    RootNavigation.navigationRef.current?.navigate('BoardScreen');
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    showAleartForTestNtf = (msg: string) => {
        let alertBoxInfo: AlertBoxType = {
            message: msg,
            actions: [
                {
                    text: translate('ok'),
                    action: () => {
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    pinMayHaveExpired = async (): Promise<boolean> => {
        let lastsuccessfulltstmp: string = await userDefault.get(kNtfPinTimestampInSec);
        let currentTimestampInSec = Math.floor(Date.now() / 1000);
        let isNtfPinExpired = currentTimestampInSec - Number(lastsuccessfulltstmp ?? 0) > kNtfPinResendDurationSec;
        return isNtfPinExpired;
    };

    notificationChecking = async (): Promise<boolean> => {
        return await Notifications.isRegisteredForRemoteNotifications();
    };
}

const pushNtfMgr: PushNtfMgr = new PushNtfMgr();

export default pushNtfMgr;
