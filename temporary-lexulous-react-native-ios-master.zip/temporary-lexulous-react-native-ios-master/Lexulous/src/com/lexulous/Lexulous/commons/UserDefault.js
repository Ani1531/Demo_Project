// @flow
import AsyncStorage from '@react-native-async-storage/async-storage';

class UserDefault {
    get = async (key: string): Promise<any> => {
        let jsonValue = await AsyncStorage.getItem(key);
        return jsonValue;
    };

    set = async (key: string, value: string) => {
        await AsyncStorage.setItem(key, value);
    };

    clear = async (key: string) => {
        await AsyncStorage.removeItem(key);
    };

    getMultiple = async (keys: Array<string>) => {
        let values = await AsyncStorage.multiGet(keys);
        let valueArray = [];
        values.forEach((item) => {
            valueArray.push(item[1]);
        });
        return valueArray;
    };

    setMultiple = async (data: { [key: string]: string }) => {
        let dataArray = [];
        Object.keys(data).forEach((item) => {
            let arrayValue = [item, data[item]];
            dataArray.push(arrayValue);
        });
        await AsyncStorage.multiSet(dataArray);
    };

    clearMultiple = async (keys: Array<string>) => {
        await AsyncStorage.multiRemove(keys);
    };

    clearAll = async () => {
        await AsyncStorage.clear();
    };

    // /** Gets and sets the current preferences file name (android) or user default suite name (ios) **/
    getName = async () => {};

    setName = async (name: any) => {};
}

const userDefault = new UserDefault();

export default userDefault;
