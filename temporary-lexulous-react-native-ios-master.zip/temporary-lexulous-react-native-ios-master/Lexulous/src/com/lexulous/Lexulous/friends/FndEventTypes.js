// @flow

export const ADD_GLBL_FND_AND_FOES: string = 'ADD_GLBL_FND_AND_FOES';
export const CLR_GLBL_FND: string = 'CLR_GLBL_FND';
export const GLBL_FND_REFRESH_STARTED: string = 'GLBL_FND_REFRESH_STARTED';
export const GLBL_FND_REFRESH_FINISHED: string = 'GLBL_FND_REFRESH_FINISHED';
export const GLBL_FND_AD_EVT: string = 'GLBL_FND_AD_EVT';
export const CLR_GLBL_FND_DATA: string = 'CLR_GLBL_FND_DATA';
export const MK_FRIEND = 'MK_FRIEND';
export const RM_FRIEND_REQ = 'RM_FRIEND_REQ';
export const RM_ADDED_FRIEND_REQ = 'RM_ADDED_FRIEND_REQ';
export const INST_SENT_FND_REQ = 'INST_SENT_FND_REQ';
export const CANCEL_SENT_FND_REQ = 'CANCEL_SENT_FND_REQ';
export const CENSOR_REQ = 'CENSOR_REQ';
export const UNCENSOR_REQ = 'UNCENSOR_REQ';
