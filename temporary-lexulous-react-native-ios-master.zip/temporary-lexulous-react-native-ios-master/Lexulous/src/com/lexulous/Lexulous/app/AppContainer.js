// @flow

import 'react-native-gesture-handler';
import React from 'react';
import { AppState } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider } from 'react-redux';
import dataServer from '../store/Store';
import { NavigationContainer, type Theme, DefaultTheme } from '@react-navigation/native';
import * as RootNavigation from '../commons/RootNavigation';
import AppSplash from './AppSplash';
import RJSLinks from '../commons/RJSLinks';
import { Stack } from '../commons/Constants';
import themeConfigutation from '../commons/ThemeConfiguration';

type AppContainerState = {
    apptheme: Theme,
};

class AppContainer extends React.Component<{}, AppContainerState> {
    appstate = 'inactive';
    constructor() {
        super();
        this.state = {
            apptheme: {
                ...DefaultTheme,
                colors: {
                    ...DefaultTheme.colors,
                    background: '#f4f3ef',
                },
            },
        };
    }

    initApp = () => {
        return (
            <Provider store={dataServer.getStore()}>
                <SafeAreaProvider>
                    <NavigationContainer ref={RootNavigation.navigationRef} linking={RJSLinks} theme={this.state.apptheme}>
                        {/*Change for react native web */}
                        {this.installNavigatorWithAppSplash()}
                    </NavigationContainer>
                </SafeAreaProvider>
            </Provider>
        );
    };

    componentDidMount() {
        AppState.addEventListener('change', this.handleAppStateChange);
        this.handleAppStateChange('active');
    }

    componentWillUnmount() {
        AppState.removeEventListener('change', this.handleAppStateChange);
        themeConfigutation.onDestroy();
    }

    handleThemeChange = () => {
        this.setState({
            apptheme: {
                ...DefaultTheme,
                colors: {
                    ...DefaultTheme.colors,
                    background: themeConfigutation.getColor('#f4f3ef'),
                },
            },
        });
    };

    handleAppStateChange = (nextAppState: string): void => {
        if (this.appstate.match(/inactive|background/) && nextAppState === 'active') {
            //APP SWITCHED TO FOREGROUND
            themeConfigutation.onAppInit();
            themeConfigutation.callback = this.handleThemeChange;
        }
        this.appstate = nextAppState;
    };

    installNavigatorWithAppSplash() {
        return <Stack.Navigator>{this.getAppSplashScreen()}</Stack.Navigator>;
    }

    getAppSplashScreen() {
        return (
            <Stack.Screen
                name="AppSplash"
                component={AppSplash}
                options={{
                    title: '',
                    headerShown: false,
                    animationEnabled: false,
                }}
            />
        );
    }

    render() {
        return this.initApp();
    }
}

export default AppContainer;
