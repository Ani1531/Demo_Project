import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import ColorConfig from '../configs/ColorConfig';
import PuzzleGamePlayService from '../service/PuzzleGamePlayService';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
    faCubes,
    faForward,
    faSignal,
} from '@fortawesome/free-solid-svg-icons';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import Config from '../configs/Config';
import RackTile from '../component/RackTile';
import { connect } from 'react-redux';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';

const isPuzzlePassed = (results) =>
    results && results.action && results.action === Config.PUZZLE_PASS_ACTION;

const eventBus = require('js-event-bus')();

class RevealSolutionView extends React.Component {
    state = {
        visible: false,
        textRackToggleState: true,
        viewingRemote: Config.REVEAL_SOLUTION_MODE_SELF,
    };

    showRevealSolution = (params) => this.setState(params);

    componentDidMount = () => {
        eventBus.on(Config.SHOW_REVEAL_SOLUTION, this.showRevealSolution);
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.SHOW_REVEAL_SOLUTION, this.showRevealSolution);
    };

    isVisible = () => !!this.state.visible;

    getToggledState = () => {
        let viewingRemote = this.state.viewingRemote + 1;
        if (viewingRemote >= Config.REVEAL_SOLUTION_MODE_COUNT)
            viewingRemote = 0;
        return viewingRemote;
    };

    getButtonLabelForRevealMode = () => {
        switch (this.state.viewingRemote) {
            case Config.REVEAL_SOLUTION_MODE_SELF:
                return "Player's Move";
            case Config.REVEAL_SOLUTION_MODE_PREVIOUS_PLAYER:
                return 'AI Score';
            case Config.REVEAL_SOLUTION_MODE_BEST_MOVE:
                return 'Your Move';
            default:
                return '';
        }
    };

    toggleMoves = () => {
        let toggledState = !this.state.viewingRemote;
        this.setState({ viewingRemote: toggledState });
        this.props.onToggleBoard(this.state.results, toggledState);
    };

    toggleRackAndResults = () => {
        let textRackToggleState = !this.state.textRackToggleState;
        this.setState({ textRackToggleState });
    };

    getContainerWidthObj = () => ({ width: this.props.style.width });

    getPaddingLeftObj = () => ({ paddingLeft: this.props.cellDimen / 4.5 });

    getRevealTextStyles = (differential) => ({
        color: differential > 0 ? '#5eb42c' : '#c23742',
        fontSize: this.props.cellDimen / 2.3,
        marginBottom: this.props.cellDimen / 2.3,
    });

    getResultInfoStyles = () => ({
        fontSize: this.props.cellDimen / 2.3,
        marginBottom: this.props.cellDimen / 2.3,
    });

    togglePuzzle = () => {
        let viewingRemote = this.getToggledState();
        this.setState({ viewingRemote });
        this.props.onToggleBoard(this.state.results, viewingRemote);
    };

    render = () => {
        if (!this.isVisible()) return <View style={[styles.notVisible]} />;

        let currentScore;
        this.props.game.myScore !== undefined
            ? (currentScore = parseInt(this.props.game.myScore))
            : (currentScore = 0);

        let lastPlayerScore;
        this.props.game.scoreToBeat !== undefined
            ? (lastPlayerScore = parseInt(
                  this.props.game.scoreToBeat.split(' (')[0]
              ))
            : (lastPlayerScore = 0);

        let differential = currentScore - lastPlayerScore;
        return (
            <View style={[this.props.style, styles.root]}>
                <View
                    style={[
                        styles.buttons_conatiner,
                        this.getContainerWidthObj(),
                    ]}
                >
                    {this.renderButton({
                        icon: faForward,
                        onPress: PuzzleGamePlayService.onRequestNextPuzzle,
                        outputs: 'Next Puzzle',
                        color: '#5eb42c',
                    })}
                    {this.renderButton({
                        onPress: this.togglePuzzle,
                        icon: faSignal,
                        outputs: this.getButtonLabelForRevealMode(),
                    })}
                    {this.renderButton({
                        onPress: this.toggleRackAndResults,
                        icon: faCubes,
                        outputs: this.state.textRackToggleState
                            ? 'Rack'
                            : 'Results',
                    })}
                </View>
                {this.state.textRackToggleState ? (
                    <View
                        style={[
                            styles.result_text_conatiner,
                            this.getPaddingLeftObj(),
                        ]}
                    >
                        <S14Text
                            style={[
                                styles.defaultCursor,
                                styles.boldFont,
                                this.getRevealTextStyles(differential),
                                LayoutUtils.getCursorDefaultStyle(),
                            ]}
                        >
                            {isPuzzlePassed(this.state.results)
                                ? 'Puzzle Passed '
                                : 'Puzzle Completed! '}
                        </S14Text>
                        <S14Text
                            style={[
                                styles.defaultCursor,
                                styles.revealExplanationColor,
                                this.getResultInfoStyles(),
                                LayoutUtils.getCursorDefaultStyle(),
                            ]}
                        >
                            {'You scored ' +
                                currentScore +
                                ' ' +
                                'point' +
                                (currentScore === 1 ? '' : 's') +
                                '. ' +
                                (differential === 0
                                    ? ''
                                    : Math.abs(differential) +
                                      (differential > 0
                                          ? ' more than the last player.'
                                          : ' less than the last player.'))}
                        </S14Text>
                    </View>
                ) : (
                    this.renderRack()
                )}
            </View>
        );
    };

    renderRack = () => (
        <View style={[{ flex: 1 }, styles.result_rack_outer_container]}>
            <View style={[styles.result_rack_inner_container]}>
                {this.getTileSet().map((tile) => (
                    <RackTile
                        tile={tile}
                        showTileScore={true}
                        containerHeight={
                            this.props.layout.layoutRevealSolutionHeight
                        }
                    />
                ))}
            </View>
        </View>
    );

    getRevealSolutionRackStartMargin = (tileLength) => {
        let totalRackSpace =
            this.props.cellDimen * tileLength +
            this.props.layout.layoutTileRackMargin * tileLength;
        let remainingSpace =
            this.props.layout.layoutBoardWidth - totalRackSpace;
        let startMargin = remainingSpace / 2;

        return this.props.layout.layoutBoardLeft + startMargin;
    };

    getTileSet = () => get(this.state, 'results.tileSet') || [];

    getButtonStyles = () => ({
        paddingHorizontal: this.props.cellDimen / 5.5,
    });

    getIconColor = (color) => ({
        color: color || ColorConfig.BUTTON_TEXT_COLOR,
    });

    getFontSize = () => ({
        fontSize: this.props.cellDimen / 2.3,
    });

    getOutputTextColor = (color) => (color ? { color } : {});

    renderButton = ({ icon, outputs, onPress, color }) => (
        <TouchableOpacity
            style={[styles.commonButton, this.getButtonStyles()]}
            onPress={onPress}
            activeOpacity={1}
        >
            <FontAwesomeIcon
                icon={icon}
                size={this.getFontSize().fontSize}
                style={{
                    ...this.getIconColor(color),
                }}
            />

            <S14Text
                style={[
                    styles.commonButtonText,
                    this.getFontSize(),
                    this.getOutputTextColor(color),
                ]}
            >
                {outputs}
            </S14Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    root: {
        backgroundColor: ColorConfig.BUTTON_CONTAINER_BACKGROUND_COLOR,
        borderColor: ColorConfig.BUTTON_CONTAINER_BORDER_COLOR,
        borderWidth: 1,
        flexDirection: 'column',
    },
    buttons_conatiner: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    result_text_conatiner: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    result_rack_outer_container: {
        flexDirection: 'column',
        justifyContent: 'center',
    },
    result_rack_inner_container: {
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },

    cancelButton: {
        height: 30,
        backgroundColor: ColorConfig.ALERT_BUTTON_BACKGROUND_COLOR,
    },

    actionButton: {
        height: 30,
        backgroundColor: ColorConfig.ALERT_BUTTON_BACKGROUND_COLOR,
    },

    commonButton: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        flexDirection: 'row',
    },

    commonButtonText: {
        color: ColorConfig.BUTTON_TEXT_COLOR,
        margin: 3,
        fontWeight: 'bold',
    },

    alignContentCenterJustified: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    locked_text: {
        color: ColorConfig.LOCKED_TEXT_COLOR,
    },
    reveal_cell_text_style: {
        color: ColorConfig.JUST_PLAYED_TILE_TEXT_COLOR,
    },
    locked_text_red: {
        color: ColorConfig.LOCKED_TEXT_RED_COLOR,
    },
    locked_cell: {
        backgroundColor: ColorConfig.LOCKED_CELL_BACKGROUND_COLOR,
        borderColor: '#fcba27',
        borderWidth: StyleSheet.hairlineWidth,
        alignItems: 'center',
        justifyContent: 'center',
    },
    placed_cell: {
        backgroundColor: ColorConfig.RACK_TILE_BACKGROUND_COLOR,
        borderColor: ColorConfig.RACK_TILE_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        alignItems: 'center',
        justifyContent: 'center',
    },
    text: {
        color: ColorConfig.TILE_TEXT_COLOR,
        position: 'absolute',
    },
    notVisible: {
        height: 0,
        width: 0,
    },
    boldFont: {
        fontWeight: 'bold',
    },
    revealExplanationColor: {
        color: '#6C707F',
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    game: state.game,
});

export default connect(mapStateToProps)(RevealSolutionView);
