import { reactLocalStorage } from 'reactjs-localstorage';
import store from '../store';
import { gameBoardDataExchanger } from './GameBoardDataExchange';
import { channels } from '../shared/constants';
const { ipcRenderer } = window;

export default class ServiceWrapper {
    static getLocalStorage = (key) => reactLocalStorage.get(key);

    static setLocalStorage = (key, value) => reactLocalStorage.set(key, value);

    static openSupport = (onSupportFunc) => null;

    static nativeGameListUpdate = (data) =>
        store.dispatch({
            type: 'GL_SVCCON_ADD_GAME',
            payload: data,
        });

    static getNativeGUID = (data) => store.getState().profile?.guid ?? null;

    static getNativeUUID = (data) => store.getState().profile?.uuid ?? null;

    static nativeUpdateUserSettings = (settings) =>
        store.dispatch({
            type: 'UPDT_SETTINGS',
            payload: settings,
        });

    static nativeGameListUpdateViaBoardInfo = (data) =>
        store.dispatch({
            type: 'GL_UPDT_VIA_BOARD_INFO',
            payload: data,
        });

    static nativeGameListReadChat = (data) =>
        store.dispatch({
            type: 'GL_READ_CHAT',
            payload: data,
        });

    static nativeGetBannerAdsHeight = () => null;

    static nativeShowBannerAds = () => null;

    static nativeHideBannerAds = () => null;

    static nativeShowInterstitialAd = (nextFunc) => {
        nextFunc();
    };

    static getDataFromCache = async (cacheName, cacheKey) => {
        let cacheStorage = await caches.open(cacheName);
        let cachedResponse = await cacheStorage.match(cacheKey);
        return cachedResponse ? await cachedResponse.json() : {};
    };

    static setDataIntoCache = (cacheName, cacheKey, response) => {
        const data = new Response(JSON.stringify(response));
        if ('caches' in window) {
            caches.open(cacheName).then((cache) => {
                cache.put(cacheKey, data);
            });
        }
    };

    static handleCrashReport = (error) => null;

    static onBlindGameMove = () => {
        let onBlindGameMove = gameBoardDataExchanger.gameBoardData?.onBlindGameMove ?? null;
        if (onBlindGameMove != null) {
            onBlindGameMove();
        }
    };

    static notifyContextStore = (data) => {
        let notifyFBContext = gameBoardDataExchanger.gameBoardData?.notifyFBContext ?? null;
        if (notifyFBContext != null) {
            notifyFBContext(data);
        }
    };

    static updateContextStore = (data) => {
        let updateContextStore = gameBoardDataExchanger.gameBoardData?.updateContextStore ?? null;
        if (updateContextStore != null) {
            updateContextStore(data);
        }
    };

    static showDesktopNotification = (notificationInfo) => {
        ipcRenderer.send(channels.NOTIFICATION_INFO, notificationInfo);
    };

    static sendFriendRequest = (data) => {
        store.dispatch({
            type: 'INST_SENT_FND_REQ',
            payload: data,
        });
    };

    static cancelFriendRequest = (data) => {
        store.dispatch({
            type: 'CANCEL_SENT_FND_REQ',
            payload: data,
        });
    };

    static rejectFriendRequest = (data) => {
        store.dispatch({
            type: 'RM_FRIEND_REQ',
            payload: data,
        });
    };

    static acceptFriendRequest = (data) => {
        store.dispatch({
            type: 'MK_FRIEND',
            payload: data,
        });
    };

    static removeFriend = (data) => {
        store.dispatch({
            type: 'RM_ADDED_FRIEND_REQ',
            payload: data,
        });
    };

    static censorPlayer = (data) => {
        store.dispatch({
            type: 'CENSOR_REQ',
            payload: data,
        });
    };

    static uncensorPlayer = (data) => {
        store.dispatch({
            type: 'UNCENSOR_REQ',
            payload: data,
        });
    };

    static getDeskChatScamAlertStatus = (isLobbyChat, func) => {
        ipcRenderer.send(channels.APP_INFO, {
            action: isLobbyChat ? channels.ACTION_LOBBY_CHAT_SCAM_ALERT : channels.ACTION_CHAT_SCAM_ALERT,
            returnRes: true,
        });
        ipcRenderer.on(channels.APP_INFO, (event, arg) => {
            ipcRenderer.removeAllListeners(channels.APP_INFO);
            func(arg);
        });
    };

    static setDeskChatScamAlertStatus = (isLobbyChat) => {
        ipcRenderer.send(channels.APP_INFO, {
            action: isLobbyChat ? channels.ACTION_LOBBY_CHAT_SCAM_ALERT : channels.ACTION_CHAT_SCAM_ALERT,
        });
    };
}
