import React from 'react';
import { Animated, PanResponder, StyleSheet, View } from 'react-native';
import get from 'lodash/get';
import isNil from 'lodash/isNil';
import isObject from 'lodash/isObject';
import isEqual from 'lodash/isEqual';
import isNumber from 'lodash/isNumber';
import isString from 'lodash/isString';
import cloneDeep from 'lodash/cloneDeep';
import GameBoardUtils from '../utils/GameBoardUtils';
import SoundUtils from '../utils/SoundUtils';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { connect } from 'react-redux';
import {
    CELL_REDUCER_ON_TILE_CLICKED,
    GAME_REDUCER_UPDATE_TILES,
    GAME_TILE_BEING_DRAGGED,
    REDUCER_ON_TILE_REMOVED,
    REDUCER_UPDATE_MOUSE_MOVE_TILE,
    TILE_REDUCER_SET_HOVERING_CELL,
    UPDATE_TILES_AND_SET_CELL,
} from '../configs/ActionIdentifiers';
import LayoutWrapper from '../utils/LayoutWrapper';
import { arrayMove, arraySwap } from '../utils/Utils';
import DimensionUtils from '../utils/DimensionUtils';
import zip from 'lodash/zip';
import { isEmailGame } from '../service/GamePlayService';
import { addUpdateRack } from '../Board';
import log from 'loglevel';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';

const eventBus = require('js-event-bus')();

class Tile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            //pan: new Animated.ValueXY(),
            borderWidth: 0,
        };
        this.pan = new Animated.ValueXY();
        this.panResponder = PanResponder.create({
            onStartShouldSetPanResponder: this.setPanResponder,
            onMoveShouldSetPanResponder: this.setPanResponder,
            onPanResponderGrant: this.onTileDragStarted,
            onPanResponderMove: Animated.event(
                [
                    null,
                    {
                        dx: this.pan.x,
                        dy: this.pan.y,
                    },
                ],
                {
                    useNativeDriver: LayoutWrapper.getNativeDriverValue(),
                    /*listener: (event, gesture) => {
                        let cell = this.onTileDropped(
                            this.props.tileType,
                            gesture
                        );
                        if (
                            get(this.props, 'tileDrag.cellDraggedToX') !==
                                get(cell, 'tileX') ||
                            get(this.props, 'tileDrag.cellDraggedToY') !==
                                get(cell, 'tileY')
                        ) {
                            eventBus.emit(
                                TILE_REDUCER_SET_HOVERING_CELL,
                                null,
                                {
                                    cell,
                                }
                            );
                        }
                    },*/
                }
            ),
            onPanResponderRelease: this.onTileRelease,
        });
        this.props.tileType.getLetter = this.getLetter;
    }

    shouldComponentUpdate = (nextProps, nextState, nextContext) => {
        return (
            !isEqual(
                get(this.state, 'borderWidth'),
                get(nextState, 'borderWidth')
            ) ||
            !isEqual(get(this.state, 'index'), get(nextState, 'index')) ||
            !isEqual(get(this.props, 'tileType'), get(nextProps, 'tileType')) ||
            !isEqual(get(this.props, 'layout'), get(nextProps, 'layout')) ||
            !isEqual(
                get(this.props, 'config.theme'),
                get(nextProps, 'config.theme')
            ) ||
            (!isEqual(
                get(this.props, 'tiles.tileBeingDragged'),
                get(nextProps, 'tiles.tileBeingDragged')
            ) &&
                [
                    get(this.props, 'tiles.tileBeingDragged.id'),
                    get(nextProps, 'tiles.tileBeingDragged.id'),
                ].includes(get(this.props, 'tileType.id'))) ||
            !isEqual(
                get(this.props, 'cells.cells')
                    .flat(8)
                    .find(
                        (cell) =>
                            get(cell, 'currentTile') &&
                            get(cell, 'currentTile.id') ===
                                get(this.props, 'tileType.id')
                    ),
                get(nextProps, 'cells.cells')
                    .flat(8)
                    .find(
                        (cell) =>
                            get(cell, 'currentTile') &&
                            get(cell, 'currentTile.id') ===
                                get(this.props, 'tileType.id')
                    )
            )
        );
    };

    getTiles = ({
        includeEmptySpace = false,
        forRendering = false,
        caller,
    } = {}) => {
        let currentRackArr = [];
        if (get(this.props, 'game.showingAnalyseMove')) {
            let movesObjs = this.props.game.movesObjs;
            let currentPosition = this.props.game.currPosition;
            let moveObj = (movesObjs || [])[currentPosition];
            currentRackArr = cloneDeep(get(moveObj, 'rackArr'));
        } else if (get(this.props, 'tiles.rackArr')) {
            currentRackArr = cloneDeep(get(this.props, 'tiles.rackArr'));
        } else {
            let players = get(this.props, 'tiles.players');
            let selfPid = get(this.props, 'game.pid');
            let currentTurn = get(this.props, 'game.currentTurn');
            let pidToUse =
                isString(selfPid) && selfPid.length > 0 ? selfPid : currentTurn;
            let player = (players || []).find(
                (player) => player.pid === pidToUse
            );
            currentRackArr = cloneDeep(get(player, 'currentRackArr') || []);
        }

        let nonNullTiles = currentRackArr.filter(Boolean);
        if (includeEmptySpace) {
            return nonNullTiles;
        }
        let actualTiles = nonNullTiles.filter((tile) => !tile.isEmptySpace);
        if (forRendering && actualTiles.length > 2) return nonNullTiles;
        return actualTiles;
    };

    hasTile = (x, y) => {
        let cell = get(this.props, 'cells.cells.' + x + '.' + y);
        return !!cell && !!cell.currentTile;
    };

    updateTiles = (newTiles, caller, updateCellData, tile, cell) => {
        // correct approach - this.setState({tiles: newTiles});
        if (updateCellData) {
            eventBus.emit(UPDATE_TILES_AND_SET_CELL, null, {
                cells: updateCellData,
                tile,
                cell,
                tiles: { rack: newTiles, caller },
                caller: 'TileUpdateTiles',
            });
        } else {
            eventBus.emit(GAME_REDUCER_UPDATE_TILES, null, {
                rack: newTiles,
                caller,
            });
        }
        isEmailGame() &&
            addUpdateRack.bind({ props: this.props })({ rack: newTiles });
    };

    getAdjustment = () => {
        let cell = this.isDroppedTile({ retCell: true });

        let cellDimen = get(this.props, 'layout.layoutCellDimen');
        let cellWidth = cellDimen;
        let cellHeight = cellDimen;

        cell = get(this.props, 'layout.cellDimensions')
            .flat(8)
            .find(
                (cellInArr) =>
                    cellInArr.tileX === cell.tileX &&
                    cellInArr.tileY === cell.tileY
            );

        let res = {
            x:
                cell.tileStartXUnscaledUnoffset +
                (DimensionUtils.isMobile() ||
                get(this.props, 'game.board_type') === 'super'
                    ? cell.tileX * StyleSheet.hairlineWidth
                    : 0),
            y: cell.tileStartYUnscaledUnoffset,
            width: cellWidth,
            height: cellHeight,
        };
        return res;
    };

    getPosition = ({
        index = this.props.index,
        tile = this.props.tileType,
        isCreateBoard = this.props.isCreateBoard,
    } = {}) => {
        let length = this.getTiles({
            includeEmptySpace: true,
            caller: 'getPosition',
        }).length;

        let cell = this.isDroppedTile({ retCell: true });
        let isDroppedTile = !!cell;

        let container = get(this.props, 'containerDimensions');

        let boardHeight =
            get(this.props, 'layout.layoutBoardWidth') -
            (DimensionUtils.isMobile() ||
            get(this.props, 'game.board_type') === 'super'
                ? this.props.game.board_size * StyleSheet.hairlineWidth
                : 0);
        let boardStartY = container.top;

        // noinspection JSSuspiciousNameCombination - we have a square board, so same width and height
        let boardWidth = get(this.props, 'layout.layoutBoardWidth');
        let dimensionsForTileNotDropped =
            this.getDimensionsForTilesNotDropped();

        log.info(
            'fixing_layoutRackContainerHeight, in Tile, in getPosition, dimensionsForTileNotDropped is:\n' +
                JSON.stringify(dimensionsForTileNotDropped, null, 2)
        );

        let unplacedCellDimen = dimensionsForTileNotDropped.height;

        log.info(
            'fixing_layoutRackContainerHeight, in Tile, in getPosition, unplacedCellDimen is ' +
                unplacedCellDimen
        );

        let cellDimen = unplacedCellDimen; // get(this.props, 'layout.layoutCellDimen');

        let margin =
            get(this.props, 'layout.layoutTileMarginInRack') +
            (this.props.isCreateBoard ? 20 : 0);

        let rackStartX =
            container.left +
            (DimensionUtils.isMobile() ? 0 : 2 * unplacedCellDimen);

        let boardEndX = container.left + boardWidth;

        let rackEndX =
            container.left +
            boardEndX -
            (DimensionUtils.isMobile() ? 0 : 3 * unplacedCellDimen);

        let CIRCLE_RADIUS = cellDimen / 2;

        let stateObject = {
            height: CIRCLE_RADIUS * 2,
            width: CIRCLE_RADIUS * 2,
            CIRCLE_RADIUS,
        };

        if (isCreateBoard) {
            rackStartX = get(
                this.props,
                'layout.layoutRackStartMarginOriginal'
            );
            cellDimen = get(this.props, 'layout.layoutCellDimen');
            boardEndX = container.left + boardWidth - 3 * cellDimen;
            stateObject.unplacedTop = boardStartY + 70 + (index > 3 ? 50 : 0);
            let tempIndex = index < 4 ? index : index - 4;
            stateObject.unplacedLeft =
                (rackStartX + boardEndX + this.props.layout.screenWidth) / 2 -
                2 * (2 * CIRCLE_RADIUS + margin + 1.3 * CIRCLE_RADIUS) +
                (2 * CIRCLE_RADIUS * tempIndex + margin * tempIndex) +
                1.3 * CIRCLE_RADIUS +
                30;
        } else {
            stateObject.unplacedTop =
                DimensionUtils.isMobile() ||
                get(this.props, 'game.board_type') === 'super'
                    ? boardStartY +
                      boardHeight +
                      (!DimensionUtils.isMobile() &&
                      get(this.props, 'game.board_type') === 'super'
                          ? Math.min(
                                this.props.layout.layoutCellDimen * 1.5,
                                this.props.layout.layoutRackContainerHeight *
                                    0.8
                            ) /
                                2 -
                            unplacedCellDimen / 2
                          : margin)
                    : (boardStartY +
                          boardHeight +
                          (boardStartY +
                              boardHeight +
                              get(
                                  this.props,
                                  'layout.layoutRackContainerHeight'
                              ))) /
                          2 -
                      unplacedCellDimen / 2;

            stateObject.unplacedLeft = GameBoardUtils.isMenuAtTheBottom()
                ? (rackStartX + rackEndX) / 2 -
                  ((unplacedCellDimen + margin) * length) / 2 +
                  (unplacedCellDimen + margin) * index
                : rackStartX + (unplacedCellDimen + margin) * index;
        }

        if (isDroppedTile) {
            let cellPosition = this.getAdjustment(tile);
            stateObject.top = cellPosition.y;
            stateObject.left = cellPosition.x;
            stateObject.cellDimen = cellPosition.height;
            stateObject.height = stateObject.cellDimen;
            stateObject.width = stateObject.cellDimen;
        } else {
            stateObject.top = stateObject.unplacedTop;
            stateObject.left = stateObject.unplacedLeft;
        }

        return stateObject;
    };

    isTileDroppedBeforeMe = (tile, index, moveX) => {
        let position = this.getPosition({ tile, index });
        let side = position['CIRCLE_RADIUS'] * 2;
        let containerPosition = DimensionUtils.getContainerPosition();
        let tileEndX = position.unplacedLeft + side + containerPosition.left;
        return moveX + LayoutWrapper.getScrollX() <= tileEndX;
    };

    isYInRange = (tile, index, moveY, moveX) => {
        index = this.props.isCreateBoard
            ? Config.SOLO_CREATE_BOARD_CELL.indexOf(tile.letter)
            : index;
        let position = this.getPosition({ tile, index });
        let side = position['CIRCLE_RADIUS'] * 2;
        let containerPosition = DimensionUtils.getContainerPosition();
        let tileStartX =
            position.unplacedLeft - side * 0.25 + containerPosition.left;
        let tileStartY =
            position.unplacedTop - side * 0.25 + containerPosition.top;
        let tileEndY =
            position.unplacedTop + side + side * 0.25 + containerPosition.top;

        return this.props.isCreateBoard
            ? moveX + LayoutWrapper.getScrollX() >= tileStartX
            : moveY + LayoutWrapper.getScrollY() >= tileStartY &&
                  moveY + LayoutWrapper.getScrollY() <= tileEndY;
    };

    getDifferenceFromEnd = (tile, index, moveX) => {
        let position = this.getPosition({ tile, index });
        let side = position['CIRCLE_RADIUS'] * 2;
        let containerPosition = DimensionUtils.getContainerPosition();
        let tileEndX = position.unplacedLeft + side + containerPosition.left;
        let result = tileEndX - moveX;
        return result;
    };

    isTileDroppedAfterMe = (tile, index, moveX) => {
        let position = this.getPosition({ tile, index });
        let containerPosition = DimensionUtils.getContainerPosition();
        let tileStartX = position.unplacedLeft + containerPosition.left;
        return moveX + LayoutWrapper.getScrollX() > tileStartX;
    };

    getDifferenceFromStart = (tile, index, moveX) => {
        let position = this.getPosition({ tile, index });
        let containerPosition = DimensionUtils.getContainerPosition();
        let tileStartX = position.unplacedLeft + containerPosition.left;
        let result = moveX - tileStartX;
        return result;
    };

    onDroppedWithinRack = ({ tile, oldPosition, moveX, moveY }) => {
        let tiles = this.getTiles({
            includeEmptySpace: true,
            caller: 'onDroppedWithinRack 1',
        });
        let positionPlacedTo = undefined;
        let tilesArr = this.getTiles({
            includeEmptySpace: true,
            caller: 'onDroppedWithinRack 2',
        });
        let firstTile = tilesArr[0];

        let x = LayoutWrapper.getScrollX();
        let y =
            LayoutWrapper.getScrollY() +
            get(this.props, 'layout.layoutBoardAboveViewsHeight');

        if (
            !this.isYInRange(
                !!tile.position,
                tiles.findIndex(
                    (tileInArr) => get(tileInArr, 'id') === get(tile, 'id')
                ),
                moveY - y,
                moveX - x
            )
        ) {
            return undefined;
        }

        if (this.isTileDroppedBeforeMe(firstTile, 0, moveX - x)) {
            positionPlacedTo = 0;
        }

        if (positionPlacedTo === undefined) {
            for (let i = 0; i < tilesArr.length - 1; i++) {
                let tileInArrBefore = tilesArr[i];
                let tileInArrAfter = tilesArr[i + 1];

                if (
                    this.isTileDroppedAfterMe(tileInArrBefore, i, moveX - x) &&
                    this.isTileDroppedBeforeMe(tileInArrAfter, i + 1, moveX - x)
                ) {
                    positionPlacedTo = i + 1;
                    break;
                }
            }
        }

        if (positionPlacedTo === undefined) {
            let lastTile = tilesArr[tilesArr.length - 1];

            if (
                this.isTileDroppedAfterMe(lastTile, tiles.length - 1, moveX - x)
            ) {
                positionPlacedTo = tilesArr.length - 1;
            }
        }

        if (isNumber(positionPlacedTo)) {
            let tileRef = tilesArr[positionPlacedTo];
            let isDroppedTilePosition = (get(this.props, 'cells.cells') || [])
                .flat(8)
                .some(
                    (cell) => get(cell, 'currentTile.id') === get(tileRef, 'id')
                );
            if (isDroppedTilePosition || tileRef.isEmptySpace)
                tilesArr = arraySwap(tilesArr, oldPosition, positionPlacedTo);
            else arrayMove(tilesArr, oldPosition, positionPlacedTo);
        }
        return isNumber(positionPlacedTo)
            ? { tilesArr, positionPlacedTo }
            : undefined;
    };

    onTileDropped = (tileType, gesture) => {
        let boardDimen = get(this.props, 'layout.boardWidth');

        let containerDimensions = get(this.props, 'containerDimensions');
        let containerPosition = DimensionUtils.getContainerPosition();

        let boardStartX = containerDimensions.left + containerPosition.left;
        let boardEndX = boardStartX + boardDimen;
        let boardStartY =
            containerDimensions.top +
            containerPosition.top +
            get(this.props, 'layout.layoutBoardAboveViewsHeight');
        let boardEndY = boardStartY + boardDimen;

        let dx = get(gesture, 'dx');
        let dy = get(gesture, 'dy');
        let moveX = get(gesture, 'moveX');
        let moveY = get(gesture, 'moveY');

        if (
            gesture &&
            ((dx === 0 && dy === 0) ||
                moveX < boardStartX ||
                moveX > boardEndX ||
                moveY < boardStartY ||
                moveY > boardEndY)
        ) {
            return null;
        }

        let gameBoard = zip(...get(this.props, 'layout.cellDimensions'));

        loop1: for (let i = 0; i < gameBoard.length; i++) {
            let row = gameBoard[i];
            for (let j = 0; j < row.length; j++) {
                let cell = row[j];

                let adjustCellStartX =
                    cell.tileStartX +
                    (DimensionUtils.isMobile() ||
                    get(this.props, 'game.board_type') === 'super'
                        ? cell.tileX * StyleSheet.hairlineWidth
                        : 0);
                let adjustCellEndX =
                    cell.tileEndX +
                    (DimensionUtils.isMobile() ||
                    get(this.props, 'game.board_type') === 'super'
                        ? cell.tileX * StyleSheet.hairlineWidth
                        : 0);
                let adjustCellStartY = cell.tileStartY;
                let adjustCellEndY = cell.tileEndY;

                if (
                    gesture &&
                    !(moveY >= adjustCellStartY && moveY <= adjustCellEndY)
                ) {
                    continue loop1;
                }

                if (
                    gesture &&
                    moveX >= adjustCellStartX &&
                    moveX <= adjustCellEndX
                ) {
                    let cellInCellReducer = get(this.props, 'cells.cells')
                        .flat(8)
                        .find(
                            (cellInArr) =>
                                cellInArr.tileX === cell.tileX &&
                                cellInArr.tileY === cell.tileY
                        );
                    if (
                        tileType &&
                        (!cellInCellReducer.currentTile ||
                            (cellInCellReducer.currentTile &&
                                !cellInCellReducer.locked))
                    ) {
                        return { ...cellInCellReducer, ...cell };
                    }
                }
            }
        }
    };

    onTileRelease = (e, gesture) => {
        let tileBeingDragged = get(this.props, 'tileType');

        Object.assign(tileBeingDragged, {
            zIndex: undefined,
            opacity: undefined,
            borderWidth: undefined,
        });
        if (gesture.dx === 0 && gesture.dy === 0) {
            if (
                !get(this.props, 'game.showingAnalyseMove') &&
                !this.isDroppedTile()
            ) {
                if (this.props.isCreateBoard) {
                    eventBus.emit(REDUCER_UPDATE_MOUSE_MOVE_TILE, null, {
                        tileType: tileBeingDragged,
                    });
                } else {
                    eventBus.emit(CELL_REDUCER_ON_TILE_CLICKED, null, {
                        tileType: tileBeingDragged,
                    });
                }
            } else {
                eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
                    tileOrTiles: tileBeingDragged,
                });
            }
        } else {
            let positionDroppedTo = this.onDroppedWithinRack({
                tile: this.props.tileType,
                oldPosition: this.props.index,
                moveX: gesture.moveX,
                moveY: gesture.moveY,
                forAnalyse: this.props.forAnalyse,
            });
            let isValidPosition = isObject(positionDroppedTo);
            if (
                !get(this.props, 'game.showingAnalyseMove') &&
                !isValidPosition
            ) {
                let cellDroppedTo = this.onTileDropped(
                    this.props.tileType,
                    gesture
                );

                if (!!cellDroppedTo) {
                    this.goBackToOrigin();
                    let tiles = this.getTiles({ includeEmptySpace: true });
                    let tileInArr = tiles.find(
                        (aTileInArr) =>
                            get(aTileInArr, 'id') ===
                            get(tileBeingDragged, 'id')
                    );
                    tileInArr.position = {
                        x: get(cellDroppedTo, 'tileX'),
                        y: get(cellDroppedTo, 'tileY'),
                    };
                    let existingTile = get(cellDroppedTo, 'currentTile');
                    if (existingTile) {
                        if (
                            get(existingTile, 'id') !==
                                get(this.props, 'tileType.id') &&
                            get(existingTile, 'isBlankTile')
                        ) {
                            let exisitingTileInArr = tiles.find(
                                (aTileInArr) =>
                                    get(aTileInArr, 'id') ===
                                    get(existingTile, 'id')
                            );
                            exisitingTileInArr.currentLetter = undefined;
                        } else if (
                            !isEqual(
                                get(cellDroppedTo, 'currentTile.letter'),
                                get(tileBeingDragged, 'letter')
                            )
                        ) {
                            let exisitingTileInArr = tiles.find(
                                (aTileInArr) =>
                                    get(aTileInArr, 'id') ===
                                    get(existingTile, 'id')
                            );
                            exisitingTileInArr.position = undefined;
                        }
                    }
                    tileInArr.opacity = 0;
                    eventBus.emit(UPDATE_TILES_AND_SET_CELL, null, {
                        tile: tileBeingDragged,
                        position: {
                            x: cellDroppedTo.tileX,
                            y: cellDroppedTo.tileY,
                        },
                        cell: cellDroppedTo,
                        rack: tiles,
                        caller: 'TileOnTileRelease',
                        isCreateBoard: this.props.isCreateBoard,
                    });
                } else {
                    this.clearFromBoard();
                    eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
                        tileOrTiles: tileBeingDragged,
                    });
                }
            } else {
                this.goBackToOrigin();
                tileBeingDragged.currentLetter = undefined;
                tileBeingDragged.position = undefined;
                let tiles = get(positionDroppedTo, 'tilesArr');
                tiles.forEach((tile) => {
                    if (get(tile, 'id') === get(tileBeingDragged, 'id')) {
                        tile.position = undefined;
                    }
                    Object.assign(tile, {
                        zIndex: undefined,
                        opacity: undefined,
                        borderWidth: undefined,
                        currentLetter: undefined,
                    });
                });
                eventBus.emit(GAME_TILE_BEING_DRAGGED, null, {
                    tileBeingDragged,
                    unset: true,
                    tiles,
                    droppedInRack: true,
                });
                eventBus.emit(REDUCER_ON_TILE_REMOVED, null, {
                    tileOrTiles: tileBeingDragged,
                });
            }
        }
        SoundUtils.playDropTileSound();
        this.props.onTileTouch && this.props.onTileTouch(false);
    };

    setPanResponder = () => {
        if (
            !this.props.game.showingAnalyseMove &&
            !this.props.tileType.locked &&
            !this.props.tileType.isEmptySpace
        ) {
            this.props.onTileTouch && this.props.onTileTouch(true);
            return true;
        }
        return false;
    };

    onTileDragStarted = () => {
        SoundUtils.playClickTileSound();
        eventBus.emit(GAME_TILE_BEING_DRAGGED, null, {
            tileBeingDragged: get(this.props, 'tileType'),
            unset: false,
        });
        if (this.props.isCreateBoard) {
            eventBus.emit(REDUCER_UPDATE_MOUSE_MOVE_TILE);
        }
    };

    clearFromBoard = () => {
        this.goBackToOrigin();
    };

    isDroppedTile = ({ position = false, retCell = false } = {}) => {
        let cell = (get(this.props, 'cells.cells') || [])
            .flat(8)
            .find(
                (cell) =>
                    get(cell, 'currentTile.id') ===
                    get(this.props, 'tileType.id')
            );
        if (position) {
            let ret = !!cell ? { x: cell.tileX, y: cell.tileY } : undefined;
            return ret;
        } else if (retCell) return cell;
        return !!cell;
    };

    getFromStateOrProps = (field) => {
        let valueInState = get(this.state, field);
        if (!isNil(valueInState)) return valueInState;
        return get(this.props, field);
    };

    goBackToOrigin = () => {
        Animated.timing(this.pan, {
            toValue: { x: 0, y: 0 },
            duration: 0,
        }).start();
    };

    componentDidMount = () => {
        eventBus.on(
            Config.ON_TILE_PLACED_HANDLER_EVENT,
            this.onTilePlacedHandlerEvent
        );
    };

    componentWillUnmount = () => {
        eventBus.detach(
            Config.ON_TILE_PLACED_HANDLER_EVENT,
            this.onTilePlacedHandlerEvent
        );
    };

    getDimensionsForDroppedTiles = () => ({
        height:
            get(this.props, 'layout.layoutCellDimen') * this.props.scale._value,
        width:
            get(this.props, 'layout.layoutCellDimen') * this.props.scale._value,
    });

    getDimensionsForTilesNotDropped = () => {
        return {
            height: this.props.isCreateBoard
                ? this.props.layout.layoutCellDimen
                : Math.min(
                      DimensionUtils.isMobile()
                          ? this.props.layout.layoutCellDimen * 1.5
                          : this.props.layout.layoutCellDimen,
                      this.props.layout.layoutRackContainerHeight * 0.8
                  ),
            width: this.props.isCreateBoard
                ? this.props.layout.layoutCellDimen
                : Math.min(
                      DimensionUtils.isMobile()
                          ? this.props.layout.layoutCellDimen * 1.5
                          : this.props.layout.layoutCellDimen,
                      this.props.layout.layoutRackContainerHeight * 0.8
                  ),
            borderRadius:
                (this.props.isCreateBoard
                    ? this.props.layout.layoutCellDimen
                    : Math.min(
                          this.props.layout.layoutCellDimen,
                          this.props.layout.layoutRackContainerHeight * 0.8
                      )) / 8,
        };
    };

    getStyleForCellLetterFlex = () =>
        this.props.tileType.isBlankTile || this.props.isCreateBoard
            ? styles.flexOne
            : GameBoardUtils.getTileBasicScore(this.props.tileType) > 9
            ? styles.flexTwo
            : GameBoardUtils.getTileBasicScore(this.props.tileType) > 1
            ? styles.flexFour
            : styles.flexSix;

    getBackgroundAndBorder = () => {
        return {
            backgroundColor: GameBoardUtils.getTheme().tileRack,
            borderColor: GameBoardUtils.getTheme().tileRackBorder,
        };
    };

    renderCreateBoardTileBG = (style) => {
        return this.props.isCreateBoard ? (
            <View
                style={[
                    styles.postionAbsolute,
                    style,
                    this.pan.getLayout(),
                    this.props.isCreateBoard ? this.getBgColorStyles() : null,
                ]}
            >
                <S14Text
                    class="smooth_font"
                    style={[
                        this.getStyleForCellLetterFlex(),
                        styles.textAlignCenterAlignSelfCenter,
                        LayoutUtils.getCursorPointerStyle(),
                        this.getLetterStyles(),
                    ]}
                >
                    {this.getLetter(true)}
                </S14Text>
            </View>
        ) : null;
    };

    render = () => {
        if (
            get(this.props, 'tileType.locked') ||
            this.props.tiles.puzzleIsComplete
        ) {
            return null;
        }
        let isDroppedTile = this.isDroppedTile();

        let adjustment = isDroppedTile
            ? this.getAdjustment(this.props.tileType)
            : undefined;

        let style = isDroppedTile
            ? [
                  styles.droppedTileTrue,
                  this.getBackgroundAndBorder(),
                  this.getDimensionsForDroppedTiles(),
              ]
            : [
                  styles.droppedTileFalse,
                  this.getBackgroundAndBorder(),
                  this.getDimensionsForTilesNotDropped(),
              ];
        return (
            <View
                key={this.props.tileX + ',' + this.props.tileY}
                style={[
                    styles.postionAbsolute,
                    this.getContainerStyles(adjustment),
                    this.getOpacity(),
                ]}
            >
                {this.renderCreateBoardTileBG(style)}
                <Animated.View
                    {...this.panResponder.panHandlers}
                    style={[
                        style,
                        this.pan.getLayout(),
                        this.props.isCreateBoard
                            ? this.getBgColorStyles()
                            : null,
                    ]}
                >
                    <S14Text
                        class="smooth_font"
                        style={[
                            this.getStyleForCellLetterFlex(),
                            styles.textAlignCenterAlignSelfCenter,
                            //LayoutUtils.getCursorPointerStyle(),
                            this.getLetterStyles(),
                        ]}
                    >
                        {this.getLetter(true)}
                    </S14Text>
                    {this.props.tileType.isBlankTile ||
                    this.props.tileType.isEmptySpace ||
                    this.props.isCreateBoard ? null : (
                        <S14Text
                            style={[
                                styles.tilesViewStyle,
                                //LayoutUtils.getCursorPointerStyle(),
                                this.getScoreStyles(),
                            ]}
                        >
                            {GameBoardUtils.getTileBasicScore(
                                this.props.tileType
                            )}
                        </S14Text>
                    )}
                </Animated.View>
            </View>
        );
    };

    getLetter = (render = false) => {
        if (render) {
            return (
                get(this.props, 'tileType.letter') ||
                (get(this.props, 'tileType.currentLetter') || '').toUpperCase()
            );
        } else {
            return (
                this.props.tileType.letter ||
                (this.props.tileType.currentLetter &&
                    this.props.tileType.currentLetter.toLowerCase())
            );
        }
    };

    getScoreStyles = () => {
        let isDroppedTile = this.isDroppedTile();
        let cellDimen = get(this.props, 'layout.layoutCellDimen');
        let fontSize =
            (isDroppedTile
                ? cellDimen
                : this.getDimensionsForTilesNotDropped().height) *
            (isDroppedTile ? this.props.scale._value : 1) *
            0.2833;
        return {
            bottom: cellDimen / 12,
            right: cellDimen / 12,
            fontSize: fontSize,
            color: GameBoardUtils.getTheme().tileRackKey,
        };
    };

    getLetterStyles = () => ({
        fontSize: this.props.isCreateBoard
            ? 12
            : (get(this.props, 'layout.layoutCellDimen') *
                  (this.isDroppedTile() ? this.props.scale._value : 1) *
                  2) /
              3,
        fontWeight: this.props.tileType.isBlankTile ? 'bold' : undefined,
        color: this.props.tileType.isBlankTile
            ? ColorConfig.LOCKED_TEXT_RED_COLOR
            : GameBoardUtils.getTheme().tileRackKey,
    });

    getContainerStyles = (adjustment) => {
        let position = this.getPosition();
        let ret = {
            top: !!adjustment ? adjustment.y : position.top,
            left: !!adjustment ? adjustment.x : position.left,
            zIndex:
                get(this.props, 'tiles.tileBeingDragged.id') ===
                get(this.props, 'tileType.id')
                    ? 100
                    : this.props.tileType.zIndex,
            cursor: this.props.tileType.isEmptySpace ? 'default' : 'pointer',
        };

        return ret;
    };

    getOpacity = () =>
        this.props.isCreateBoard
            ? null
            : {
                  opacity: this.props.tileType.opacity
                      ? this.props.tileType.opacity
                      : this.isDroppedTile() || this.props.tileType.isEmptySpace
                      ? 0
                      : 1,
              };

    getBgColorStyles = () => ({
        backgroundColor: GameBoardUtils.getCellBackgroundColor({
            specialCellType: this.props.tileType.letter,
        }),
        borderColor: GameBoardUtils.getCellBackgroundColor({
            specialCellType: this.props.tileType.letter,
        }),
    });
}

const styles = StyleSheet.create({
    droppedTileFalse: {
        borderWidth: StyleSheet.hairlineWidth,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        overflow: 'hidden',
        paddingRight: 1,
    },
    droppedTileTrue: {
        borderWidth: StyleSheet.hairlineWidth,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        paddingRight: 1,
    },
    panBorderColor: {
        borderColor: '#000',
    },
    postionAbsolute: {
        position: 'absolute',
    },
    tilesViewStyle: {
        alignSelf: 'flex-end',
    },
    flexOne: { flex: 1 },
    flexTwo: { flex: 2 },
    flexFour: { flex: 4 },
    flexSix: { flex: 6 },
    textAlignCenterAlignSelfCenter: {
        textAlign: 'center',
        alignSelf: 'center',
    },
});

const mapStateToProps = (state, props) => ({
    game: state.game,
    tiles: state.tiles,
    cells: state.cells,
    config: state.config,
    layout: state.layout,
    tileDrag: state.tileDrag,
});
export default connect(mapStateToProps)(Tile);
