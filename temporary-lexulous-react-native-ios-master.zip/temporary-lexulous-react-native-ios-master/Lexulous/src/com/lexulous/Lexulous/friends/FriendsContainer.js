// @flow

import React from 'react';
import { connect, batch } from 'react-redux';
import { bindActionCreators } from 'redux';
import { StyleSheet, Text, View, SectionList, Image, TextInput, Pressable, Platform } from 'react-native';

import dataServer from '../store/Store';
import fndApi from './FndApi';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import * as CONSTANTS from '../commons/Constants';

import FndElementView from './FndElementView';
import type {
    ProfileInfo,
    Friends,
    FriendsVwState,
    ServerResponse,
    ErrorResponse,
    UserStats,
    PopupData,
    matchFriendData,
    WinLossStatsBarType,
    userSettings,
    userSettingsGameStart,
    ActionPopupVisibility,
    AlertBoxType,
    ActionClearPopups,
    AppUtilsTypes,
} from '../commons/RJTypes';
import type { NavigationProp } from '@react-navigation/native';
import { actionUpdateMinStats } from '../stats/minimalstats/MinStatsAction';
import fbLgnMgr from '../commons/FBLgnMgr';
import requestManager from '../commons/RequestManager';
import { Keyboard } from 'react-native';
import loginCoordinator from '../commons/LoginCoordinator';
import ProfileShareContainer from '../components/ProfileShareContainer';
import {
    actionGLBLFndRefreshStarted,
    actionGLBLFndRefreshFinished,
    actionAddGLBLFriendsAndFoes,
    actionGLBLFndClearData,
    actionGLBLFndAdEvent,
    actionGLBLInsertSentFriendRequest,
    actionGLBLCensorEvent,
} from '../friends/FndAction';
import netManager from '../commons/RJNetInfo';

import ProfileBarContainer from '../components/ProfileBarContainer';
import { updatePopupVisibility, clearPopups, showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import MatchFriendContainer from '../components/MatchFriendContainer';
import * as MinStatsSelector from '../stats/minimalstats/MinStatsSelector';
import bannerAd from '../commons/ads/BannerAd';
import { handleException, showMessage } from '../commons/RJUtils';
import appConfiguration from '../commons/AppConfiguration';
import rjAnalytics from '../../../../RJAnalytics';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import themeConfigutation from '../commons/ThemeConfiguration';
import LiveGamePlayUtils from '../../../../utils/LiveGamePlayUtils';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';
import Clipboard from '@react-native-clipboard/clipboard';
import * as PFLSelector from '../userprofile/PFLSelector';

class FriendsContainer extends React.Component<
    {
        friends: Friends,
        minStats: { [string]: UserStats },
        lastupdated: number,
        popups: PopupData,
        utils: AppUtilsTypes,
        navigation: NavigationProp,
        updatePopupVisibility: (data: PopupData) => ActionPopupVisibility,
        showAlert: (data: AlertBoxType) => void,
        clearPopups: () => void,
        clearAlert: () => ActionClearPopups,
    },
    FriendsVwState
> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    sectionListWindowSize: number = CONSTANTS.SectionListWindowSize.For_Native;
    disableActionBtn: boolean = false;

    constructor(props) {
        super(props);
        this.state = {
            fndAddFriendInpData: '',
            isFocused: false,
            txtInpRef: React.createRef(),
            friendsStats: null,
            AccountSelection: false,
            matchFriendDictionary: CONSTANTS.US_English,
            prefferedFndSearchMode: CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeNone,
            bannerHt: 0,
        };
    }

    componentDidMount() {
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            this.props.clearPopups();
            if (this.props.lastupdated + CONSTANTS.kFriendCacheDurationSeconds < Math.floor(Date.now() / 1000)) {
                if (netManager.isConnected()) {
                    fndApi.getFriendListCumulative(false);
                }
            }
            if (this.state.isFocused == false) {
                bannerAd.showBannerAd(CONSTANTS.kTabBarHeight, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ isFocused: false });
            }
        });
        let updateSectionListWndwSize = Platform.select({
            native: () => null,
            default: () => {
                let source: string | null = appConfiguration.getApplicationSource();
                if (source != null) {
                    if (source == CONSTANTS.kDeskTopApp || source == CONSTANTS.kFBInstantApp) {
                        this.sectionListWindowSize = CONSTANTS.SectionListWindowSize.For_Web;
                    }
                    if (source == CONSTANTS.kDeskTopApp) {
                        this.disableActionBtn = true;
                    }
                }
            },
        });
        updateSectionListWndwSize();
    }

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }
    openProfileShareContainer = () => {
        this.props.updatePopupVisibility({ showSharePopup: true });
    };

    closeProfileShareContainer = () => {
        this.props.clearPopups();
    };

    renderProfileShareContainer = () => {
        if (this.props.popups.showSharePopup) {
            return (
                <ProfileShareContainer
                    closePopupHandler={() => {
                        rjAnalytics.sendAnalyticsEvent('profile_share_container_closed', 'friends_container');
                        this.closeProfileShareContainer();
                    }}
                />
            );
        } else {
            return null;
        }
    };
    onImagePress = (guid: string) => {
        rjAnalytics.sendAnalyticsEvent('profile_stats_opened', 'friends_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + guid } });
    };
    openMatchfrnd = (profileData: ProfileInfo) => {
        if (profileData) {
            let rating = '0';
            let statdata: WinLossStatsBarType = {};
            let name = CONSTANTS.Default_name;
            let avtar = CONSTANTS.Default_Avtar;
            let guid: string = profileData.guid ?? CONSTANTS.Default_guid;
            if (profileData.name !== null && profileData.name !== undefined) {
                name = profileData.name;
            }
            if (profileData.avtar !== null && profileData.avtar !== undefined) {
                avtar = profileData.avtar;
            }
            let profile = {
                name: name,
                avtar: avtar,
            };
            let stats = MinStatsSelector.getMinStats(guid, dataServer.getStore().getState());
            if (stats?.rating_stats?.rating !== null && stats?.rating_stats?.rating !== undefined) {
                rating = stats.rating_stats.rating;
            }

            let played = 0;
            if (stats?.game_stats?.played !== null && stats?.game_stats?.played !== undefined) {
                played = stats.game_stats.played;
            }
            let bingos = 0;
            if (stats?.game_stats?.bingo_count !== null && stats?.game_stats?.bingo_count !== undefined) {
                bingos = stats.game_stats.bingo_count;
            }

            let won = 0;
            if (stats?.game_stats?.won !== null && stats?.game_stats?.won !== undefined) {
                won = stats.game_stats.won;
            }

            let lost = 0;
            if (stats?.game_stats?.lost !== null && stats?.game_stats?.lost !== undefined) {
                lost = stats.game_stats.lost;
            }

            statdata = {
                won: Number(won),
                games: Number(played),
                lost: Number(lost),
                drawn: Number(played) - (Number(won) + Number(lost)),
                bingos: Number(bingos),
            };
            let userStats: matchFriendData = {
                barstats: statdata,
                guid: guid,
                profile: profile,
                rating: rating,
            };
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = requestManager.getUserSetting([guid]);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        let usersttings: { [string]: userSettings } = {};
                        if (jresp.check === CONSTANTS.kSuccess) {
                            usersttings = ((jresp.data: any): { [string]: userSettings });
                            let dictionary: userSettingsGameStart = usersttings[guid]['us_gamestart'] ?? {
                                gs_prefdic: CONSTANTS.US_English,
                            };
                            dataServer.debouncedDispatch(actionSetIdle());
                            this.setState(
                                {
                                    matchFriendDictionary: dictionary.gs_prefdic ?? CONSTANTS.US_English,
                                    friendsStats: userStats,
                                },
                                () => {
                                    this.props.updatePopupVisibility({ showMatchFriendPopup: true });
                                }
                            );
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            this.setState(
                                {
                                    friendsStats: userStats,
                                },
                                () => {
                                    this.props.updatePopupVisibility({ showMatchFriendPopup: true });
                                }
                            );
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    getMatchFriendUI = () => {
        if (this.props.popups.showMatchFriendPopup) {
            let profile = this.state.friendsStats?.profile;
            let stats = this.state.friendsStats;
            if (profile != null && profile != undefined && stats != null && stats != undefined) {
                return (
                    <MatchFriendContainer
                        cancelMatch={() => {
                            this.props.clearPopups();
                            rjAnalytics.sendAnalyticsEvent('match_friend_container_closed', 'friends_container');
                        }}
                        profile={profile}
                        userStats={stats}
                        opponentDict={this.state.matchFriendDictionary}
                        navigation={this.props.navigation}
                    />
                );
            } else {
                return null;
            }
        } else {
            return null;
        }
    };

    renderAdViewPlaceHolder = () => {
        return <View style={{ backgroundColor: themeConfigutation.getColor('#f4f3ef'), height: this.state.bannerHt }} />;
    };

    render() {
        return this.state.isFocused && this.props ? (
            <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                {this.getMatchFriendUI()}
                <ProfileBarContainer
                    canShare={true}
                    openPopupHandler={() => {
                        rjAnalytics.sendAnalyticsEvent('profile_share_container_opened', 'friends_container');
                        this.openProfileShareContainer();
                    }}
                    disableActionBtn={this.disableActionBtn}
                />
                {this.renderProfileShareContainer()}
                <View style={[styles.srchmodeview, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    {/*this.renderAddFriendImgIcon()*/}
                    {this.renderUserNameInput()}
                    {this.getValidInputActions()}
                    {this.renderInviteFriendOption()}
                </View>

                <SectionList
                    sections={this.getFriendListWithoutCensorData()}
                    renderItem={({ item }) => (
                        <FndElementView
                            element={item}
                            imageHandler={this.onImagePress}
                            openpopup={(profileData: ProfileInfo) => {
                                rjAnalytics.sendAnalyticsEvent('match_friend_container_opened', 'friends_container');
                                this.openMatchfrnd(profileData);
                            }}
                        />
                    )}
                    stickySectionHeadersEnabled
                    keyExtractor={(item) => item.key}
                    renderSectionHeader={({ section: { title } }) => (
                        <Text
                            style={[
                                styles.header,
                                {
                                    backgroundColor: themeConfigutation.getColor('#e5e7e9'),
                                    color: themeConfigutation.getColor('#5f6368'),
                                },
                            ]}
                        >
                            {title}
                        </Text>
                    )}
                    ItemSeparatorComponent={separator}
                    ListFooterComponent={separator}
                    onRefresh={() => this.onRefresh()}
                    refreshing={false}
                    style={{
                        flexGrow: 1,
                        backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                    }}
                    windowSize={this.sectionListWindowSize}
                />
                {this.renderAdViewPlaceHolder()}
            </View>
        ) : null;
    }
    getFriendListWithoutCensorData = () => {
        let friendsList: any = this.props.friends;
        let friendsListWithoutCensorData = friendsList.filter((item) => item.type !== 'censored');
        return friendsListWithoutCensorData;
    };

    getValidInputActions = () => {
        let btntxt: string = translate('fnd_by_lexid');
        let flxstyle = { flex: 1 };
        let bkgcolor = { backgroundColor: '#1d9df1' };
        if (this.state.prefferedFndSearchMode == CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID) {
            btntxt = translate('fnd_plr');
            flxstyle = {};
        }

        return (
            <Pressable
                style={[styles.invitefbfriendbtn, { borderColor: themeConfigutation.getColor('#fff') }, flxstyle, bkgcolor]}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('find_player_btn_pressed', 'friends_container');
                    if (this.state.prefferedFndSearchMode == CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID) {
                        this.doFindPlayer();
                    } else {
                        this.setState({ prefferedFndSearchMode: CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID });
                    }
                }}
            >
                <Text style={styles.invitefbfriendtext}>{btntxt}</Text>
            </Pressable>
        );
    };

    showShareOrInviteText = () => {
        let guid: ?string = PFLSelector.getGUID(dataServer.getStore().getState());
        if (guid != null && guid != undefined) {
            let sharelink: string = CONSTANTS.statShareLink + guid;
            let alertBoxInfo: AlertBoxType = {
                message: `Click on copy and share the link with your friends\n ${sharelink}`,
                actions: [
                    {
                        text: translate('cancel'),
                        action: () => {
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBUTTONONLY,
                    },
                    {
                        text: translate('copy'),
                        action: () => {
                            Clipboard.setString(sharelink);
                            dataServer.getStore().dispatch(clearAlert());
                        },
                        color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                        type: AlertBoxButtonType.SHOWBUTTONONLY,
                    },
                ],
            };
            dataServer.getStore().dispatch(showAlert(alertBoxInfo));
        }
    };

    renderInviteFriendOption = () => {
        let btntxt = <Text style={styles.invitefbfriendtext}>{translate('invt_FB_Frnds')}</Text>;
        let flxstyle = { flex: 1 };
        let bkgcolor = { backgroundColor: '#1d9df1' };
        if (this.state.prefferedFndSearchMode == CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID) {
            btntxt = <FontAwesomeIcon icon={faTimes} size={22} color={themeConfigutation.getColor('#212121')} />;
            flxstyle = {};
            bkgcolor = {};
        }

        return (
            <Pressable
                style={[styles.invitefbfriendbtn, { borderColor: themeConfigutation.getColor('#fff') }, flxstyle, bkgcolor]}
                onPress={() => {
                    if (this.state.prefferedFndSearchMode == CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID) {
                        this.setState({
                            prefferedFndSearchMode: CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeNone,
                            fndAddFriendInpData: '',
                        });
                    } else {
                        let source: string | null = appConfiguration.getApplicationSource();
                        if (source != null && source == CONSTANTS.kDeskTopApp) {
                            this.showShareOrInviteText();
                        } else {
                            this.onInviteFriendTap();
                        }
                    }
                    rjAnalytics.sendAnalyticsEvent('invite_fb_friend_btn_pressed', 'friends_container');
                }}
            >
                {btntxt}
            </Pressable>
        );
    };

    renderAddFriendImgIcon = () => {
        return <Image style={styles.imageStyle} source={require('../assets/icons/email_home_icon.png')} />;
    };

    renderUserNameInput = () => {
        if (this.state.prefferedFndSearchMode == CONSTANTS.prefferedFndSearchMode.prefferedFndSearchModeLexID) {
            return (
                <View style={styles.inputBoxStyle}>
                    <TextInput
                        ref={this.state.txtInpRef}
                        placeholder={translate('type_glbId')}
                        autoCompleteType={'off'}
                        autoCapitalize={'none'}
                        autoCorrect={false}
                        autoFocus={false}
                        returnKeyType={'done'}
                        placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                        style={[styles.textinputstyle, { color: themeConfigutation.getColor('#5f6368') }]}
                        onChangeText={(value) => this.setFndAddFriendInpData(value)}
                        onSubmitEditing={this.doFindPlayer}
                        value={this.state.fndAddFriendInpData}
                    />
                </View>
            );
        } else {
            return null;
        }
    };

    onInviteFriendFbLoginCompletionCallback = () => {
        let p1 = fbLgnMgr.isUserLoggedIn();
        p1.then((result) => {
            let isloggedin: boolean = fbLgnMgr.accessToken != null && fbLgnMgr.accessToken != undefined;
            if (isloggedin) {
                fbLgnMgr.doInviteFbFriends();
            }
        }).catch((error) => {
            handleException(error);
        });
    };

    onInviteFriendTap = () => {
        let inviteFriend = Platform.select({
            native: () => {
                let p1 = fbLgnMgr.isUserLoggedIn();
                p1.then((result) => {
                    let isloggedin: boolean = fbLgnMgr.accessToken != null && fbLgnMgr.accessToken != undefined;
                    if (isloggedin) {
                        fbLgnMgr.doInviteFbFriends();
                    } else {
                        let onInviteFriendFbLoginCompletionCallback = () => {
                            let p2 = fbLgnMgr.isUserLoggedIn();
                            p2.then((result2) => {
                                if (isloggedin) {
                                    fbLgnMgr.doInviteFbFriends();
                                }
                            }).catch((error) => {
                                handleException(error);
                            });
                        };
                        let callback = () => {
                            loginCoordinator.onFBLogin(onInviteFriendFbLoginCompletionCallback);
                        };
                        fbLgnMgr.doFbLogin(callback);
                    }
                }).catch((error) => {
                    handleException(error);
                });
            },
            default: () => {
                let invite: string | null = appConfiguration.getInvitePlugin();
                if (invite != null) {
                    let onCompletion = (error: Error | null, value: string | null): void => {
                        if (error != null) {
                            console.log('invite error :: ' + JSON.stringify(error));
                        } else if (value != null) {
                            console.log('invite success :: ' + value);
                        }
                    };
                    console.log('will call invite');
                    window[invite](onCompletion);
                } else {
                    console.log('invite is null');
                }
            },
        });
        inviteFriend();
    };

    doFindPlayer = () => {
        Keyboard.dismiss();
        let isvalidglobalid = false;
        let value = '';
        if (this.state.fndAddFriendInpData !== null && this.state.fndAddFriendInpData !== undefined) {
            value = this.state.fndAddFriendInpData;
        }
        let glblregex = /^\d+$/;
        isvalidglobalid = glblregex.test(value) && value.length == CONSTANTS.kMinGlobalIdLen;
        if (value == '') {
            showMessage(translate('blank_idMsg'), 'friends_container');
        } else {
            this.doGetGuidFromEmailOrName(value, isvalidglobalid, this.goToSearchPlayerStat);
        }
    };

    doSendCensorRequest = () => {
        Keyboard.dismiss();
        let isvalidglobalid = false;
        let value = '';
        if (this.state.fndAddFriendInpData !== null && this.state.fndAddFriendInpData !== undefined) {
            value = this.state.fndAddFriendInpData;
        }
        let glblregex = /^\d+$/;
        isvalidglobalid = glblregex.test(value) && value.length == CONSTANTS.kMinGlobalIdLen;
        if (value == '') {
            showMessage(translate('blank_idMsg'), 'friends_container');
        } else {
            this.doGetGuidFromEmailOrName(value, isvalidglobalid, this.doCensorRequest);
        }
    };

    doGetGuidFromEmailOrName = (data: string, isvalidglobalid: boolean, callback: (string) => void) => {
        let glblid = data;
        if (isvalidglobalid) {
            callback(glblid);
        } else {
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<any> = fndApi.getGuidFromEmailOrName(data);
                p1.then((response: AxiosResponse<any, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((dd: any) => {
                        if (dd.check == 'success' && dd.data.length != 0) {
                            glblid = dd.data.other[data];
                            callback(glblid);
                        } else {
                            let msg = dd.msg ?? translate('lxlsusrntfnt');
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(msg, 'friends_container');
                            this.state.txtInpRef.current?.focus();
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    doMkFriendRequest = (glblid: string) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p1: AxiosPromise<ServerResponse> = fndApi.mkFriendRequest(glblid);
            p1.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((jresp: ServerResponse) => {
                    if (jresp.check === CONSTANTS.kSuccess) {
                        let p2: AxiosPromise<ServerResponse> = requestManager.getProfileOtherUser([glblid]);
                        let p3: AxiosPromise<ServerResponse> = fndApi.getStats([glblid], ['game_stats', 'rating_stats']);
                        let promises: Array<AxiosPromise<ServerResponse>> = [];
                        promises.push(p2);
                        promises.push(p3);
                        Promise.all(promises)
                            .then(async ([a, b]) => {
                                let a1: ServerResponse = await a.data;
                                let b1: ServerResponse = await b.data;
                                let userstats: { [string]: UserStats } = {};
                                let pflinfo: { [string]: ProfileInfo } = {};

                                if (b1.check === CONSTANTS.kSuccess) {
                                    let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                                    let uu: { [string]: UserStats } = temp.reduce((pp, qq) => {
                                        pp[qq.guid] = qq;
                                        return pp;
                                    }, {});
                                    userstats = { ...uu };
                                }

                                if (a1.check === CONSTANTS.kSuccess) {
                                    pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                                }

                                let isempty = Object.keys(pflinfo).length === 0 && pflinfo.constructor === Object;
                                if (!isempty) {
                                    batch(() => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        dataServer.getStore().dispatch(actionUpdateMinStats(userstats));
                                        dataServer.getStore().dispatch(actionGLBLInsertSentFriendRequest(pflinfo[glblid]));
                                        LiveGamePlayUtils.addRemoveBuddyUpdate(true, pflinfo[glblid]);
                                    });
                                    this.setFndAddFriendInpData(''); //reset
                                }
                            })
                            .catch((error) => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.state.txtInpRef.current?.focus();
                                handleException(error);
                            });
                    } else {
                        let err: ErrorResponse = (jresp: ErrorResponse);
                        dataServer.debouncedDispatch(actionSetIdle());
                        showMessage(err.msg, 'friends_container');
                        this.state.txtInpRef.current?.focus();
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                });
        }
    };

    goToSearchPlayerStat = (glblid: string) => {
        rjAnalytics.sendAnalyticsEvent('profile_stats_opened', 'friends_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + glblid } });
    };

    doCensorRequest = (glblid: string): void => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p1: AxiosPromise<ServerResponse> = fndApi.censorRequest(glblid);

            p1.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((jresp: ServerResponse) => {
                    if (jresp.check === CONSTANTS.kSuccess) {
                        let p2: AxiosPromise<ServerResponse> = requestManager.getProfileOtherUser([glblid]);
                        let p3: AxiosPromise<ServerResponse> = fndApi.getStats([glblid], ['game_stats', 'rating_stats']);
                        let promises: Array<AxiosPromise<ServerResponse>> = [];
                        promises.push(p2);
                        promises.push(p3);
                        Promise.all(promises)
                            .then(async ([a, b]) => {
                                let a1: ServerResponse = await a.data;
                                let b1: ServerResponse = await b.data;
                                let userstats: { [string]: UserStats } = {};
                                let pflinfo: { [string]: ProfileInfo } = {};

                                if (b1.check === CONSTANTS.kSuccess) {
                                    let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                                    let uu: { [string]: UserStats } = temp.reduce((pp, qq) => {
                                        pp[qq.guid] = qq;
                                        return pp;
                                    }, {});
                                    userstats = { ...uu };
                                }

                                if (a1.check === CONSTANTS.kSuccess) {
                                    pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                                }

                                let isempty = Object.keys(pflinfo).length === 0 && pflinfo.constructor === Object;
                                if (!isempty) {
                                    batch(() => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        dataServer.getStore().dispatch(actionUpdateMinStats(userstats));
                                        dataServer.getStore().dispatch(actionGLBLCensorEvent(pflinfo[glblid]));
                                        LiveGamePlayUtils.censorUncensorPlayerUpdate(true, pflinfo[glblid]);
                                    });
                                    this.setFndAddFriendInpData(''); //reset
                                }
                            })
                            .catch((error) => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.state.txtInpRef.current?.focus();
                                handleException(error);
                            });
                    } else {
                        let err: ErrorResponse = (jresp: ErrorResponse);
                        dataServer.debouncedDispatch(actionSetIdle());
                        this.state.txtInpRef.current?.focus();

                        showMessage(err.msg, 'friends_container');
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                });
        }
    };

    setFndAddFriendInpData = (data) => {
        this.setState({ fndAddFriendInpData: data.trim() });
    };

    onRefresh = () => {
        if (netManager.isConnected()) {
            fndApi.getFriendListCumulative(true);
        }
    };

    // getFriendList = (withrefresh: boolean) => {
    //     if (withrefresh) {
    //         FriendsContainer.store.dispatch(actionGLBLFndRefreshStarted());
    //     }
    //     let promises: Array<Promise<Response>> = [];
    //     let p1 = FriendsContainer.fndApi.getFriendList();
    //     promises.push(p1);
    //     Promise.all(promises).then(([a]) => {
    //         if (withrefresh) {
    //             FriendsContainer.store.dispatch(actionGLBLFndRefreshFinished());
    //         }
    //         a.text()
    //             .then((result) => {
    //                 this.onFriendsResposeReceive(JSON.parse(result));
    //             })
    //             .catch((error) => handleException( error));
    //     });
    // };

    // onFriendsResposeReceive = (response: ServerResponse) => {
    //     if (response.check === CONSTANTS.kSuccess) {
    //         let respdata: GLBLFriends = ((response.data: any): GLBLFriends);
    //         FriendsContainer.store.dispatch(actionAddGLBLFriends(respdata));
    //     }
    // };
}

const separator = () => {
    return <View style={[styles.separatorStyle, { backgroundColor: themeConfigutation.getColor('#a6a6a6') }]} />;
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'stretch',
        justifyContent: 'flex-start',
    },
    header: {
        fontSize: 12,
        paddingLeft: 8,
        paddingTop: 4,
        paddingBottom: 4,
    },
    imageStyle: {
        width: 40,
        height: 40,
        borderRadius: 3,
        marginLeft: 8,
        marginRight: 8,
    },
    textinputstyle: {
        fontSize: 20,
        ...Platform.select({
            native: {},
            default: { width: '100%', height: '100%', outlineStyle: 'none' },
        }),
    },
    srchmodeview: {
        flexDirection: 'row',
        alignItems: 'stretch',
    },
    invitefbfriendbtn: {
        height: 50,
        justifyContent: 'center',
        margin: 8,
        borderRadius: 4,
        borderWidth: 1,
    },
    invitefbfriendtext: {
        color: '#fff',
        ...Platform.select({
            native: { fontSize: 16 },
            default: { fontSize: 20 },
        }),
        textAlign: 'center',
        paddingTop: 8,
        paddingBottom: 8,
        paddingLeft: 8,
        paddingRight: 8,
    },
    inputBoxStyle: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        marginLeft: 8,
        ...Platform.select({
            native: {},
            default: { height: '100%' },
        }),
    },
    separatorStyle: {
        height: 1,
        width: '100%',
    },
});

function mapStateToProps(state) {
    const { friends, minStats, popups, utils } = state;
    return { ...friends, minStats, popups, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionAddGLBLFriendsAndFoes,
            actionGLBLFndRefreshStarted,
            actionGLBLFndRefreshFinished,
            actionGLBLFndClearData,
            actionGLBLFndAdEvent,
            updatePopupVisibility,
            clearPopups,
            showAlert,
            clearAlert,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(FriendsContainer);
