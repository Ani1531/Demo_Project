// @flow
import dataServer from '../store/Store';
import { Platform } from 'react-native';
import * as CONSTANTS from '../commons/Constants';
import { rjLog } from '../commons/RJUtils.js';
import * as PFLSelector from '../userprofile/PFLSelector';
const qs = require('qs');
import { actionGLBLFndRefreshStarted, actionGLBLFndRefreshFinished, actionAddGLBLFriendsAndFoes } from '../friends/FndAction';
import type { ServerResponse, UserStats, ProfileInfo, GLBLFriendsAndFoes } from '../commons/RJTypes';
import { actionUpdateMinStats } from '../stats/minimalstats/MinStatsAction';
import { batch } from 'react-redux';
import { actionSetBusy, actionSetIdle } from '../commons/RJTypes';
import type { AxiosPromise } from 'axios';
import requestManager from '../commons/RequestManager';
import appConfiguration from '../commons/AppConfiguration';
import ServiceUtils from '../../../../utils/ServiceUtils';

class FndApi {
    constructor() {}

    getFriendListCumulative = (withrefresh: boolean) => {
        let extFriends = Platform.select({
            native: () => {
                this.getFriendListGlobalCumulative(withrefresh, []);
            },
            default: () => {
                let friendsHelper: string | null = appConfiguration.getFriendsPlugin();
                if (friendsHelper != null) {
                    let onCompletion = (data: Array<ProfileInfo>): void => {
                        console.log('ext friends on completion :: ' + JSON.stringify(data));
                        this.getFriendListGlobalCumulative(withrefresh, data);
                    };
                    window[friendsHelper](onCompletion);
                } else {
                    this.getFriendListGlobalCumulative(withrefresh, []);
                }
            },
        });
        extFriends();
    };

    getFriendListGlobalCumulative = (withrefresh: boolean, extbuddies: Array<ProfileInfo>) => {
        if (withrefresh) {
            dataServer.getStore().dispatch(actionGLBLFndRefreshStarted());
        }
        dataServer.getStore().dispatch(actionSetBusy());

        let promises: Array<AxiosPromise<ServerResponse>> = [];

        let p1: AxiosPromise<ServerResponse> = fndApi.getFriendList();
        promises.push(p1);

        let p2: AxiosPromise<ServerResponse> = fndApi.getPendingFriendList();
        promises.push(p2);

        let p3: AxiosPromise<ServerResponse> = fndApi.getCensorList();
        promises.push(p3);

        Promise.all(promises)
            .then((result) => {
                return Promise.all(result.map((res) => res.data));
            })
            .then((data) => {
                if (withrefresh) {
                    dataServer.getStore().dispatch(actionGLBLFndRefreshFinished());
                }
                let result = data;
                let frienddata: GLBLFriendsAndFoes = {
                    buddies: [],
                    reqsent: [],
                    pending: [],
                    censored: [],
                };
                result.forEach((p: ServerResponse) => {
                    if (p.check === CONSTANTS.kSuccess) {
                        switch (p.action) {
                            case 'lstbuddy':
                                {
                                    let temp: GLBLFriendsAndFoes = ((p.data: any): GLBLFriendsAndFoes);
                                    frienddata = { ...frienddata, ...temp };
                                    frienddata.buddies.push(...extbuddies);
                                    const uniquebuddies = [
                                        ...new Map(frienddata.buddies.map((item) => [item.guid, item])).values(),
                                    ];
                                    frienddata.buddies = uniquebuddies;
                                    ServiceUtils.buddyListUpdate(p.data);
                                }
                                break;
                            case 'lstbuddyrequestpending':
                                {
                                    let pending: Array<ProfileInfo> = ((p.data: any): Array<ProfileInfo>);
                                    frienddata = { ...frienddata, ...{ pending: pending } };
                                    ServiceUtils.pendingRequestListUpdate(p.data);
                                }
                                break;
                            case 'lstcensor':
                                {
                                    let censored: Array<ProfileInfo> = ((p.data: any): Array<ProfileInfo>);
                                    frienddata = { ...frienddata, ...{ censored: censored } };
                                    ServiceUtils.censorListUpdate(p.data);
                                }
                                break;
                        }
                    } else {
                        switch (p.action) {
                            case 'lstbuddy': {
                                frienddata.buddies.push(...extbuddies);
                                break;
                            }
                        }
                    }
                });
                let buddiesguids: Array<string> = frienddata.buddies.map((p) => p.guid ?? '0').filter((q) => q != '0');
                let reqsentguids: Array<string> = frienddata.reqsent.map((p) => p.guid ?? '0').filter((q) => q != '0');
                let pendingguids: Array<string> = frienddata.pending.map((p) => p.guid ?? '0').filter((q) => q != '0');
                let censoredguids: Array<string> = frienddata.censored.map((p) => p.guid ?? '0').filter((q) => q != '0');
                let statsguids = buddiesguids.concat(reqsentguids).concat(pendingguids).concat(censoredguids);
                let p4: Array<AxiosPromise<ServerResponse>> = fndApi.getStatsBatched(statsguids, [
                    'game_stats',
                    'rating_stats',
                ]);
                Promise.all(p4)
                    .then((result) => {
                        return Promise.all(result.map((res) => res.data));
                    })
                    .then((result) => {
                        let userstats: { [string]: UserStats } = {};
                        result.forEach((p: ServerResponse) => {
                            if (p.check === CONSTANTS.kSuccess) {
                                let temp: Array<UserStats> = ((p.data: any): Array<UserStats>);
                                let uu: { [string]: UserStats } = temp.reduce((pp, qq) => {
                                    pp[qq.guid] = qq;
                                    return pp;
                                }, {});
                                userstats = { ...userstats, ...uu };
                            }
                        });
                        batch(() => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            dataServer.getStore().dispatch(actionUpdateMinStats(userstats));
                            dataServer.getStore().dispatch(actionAddGLBLFriendsAndFoes(frienddata));
                        });
                    })
                    .catch((e) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                    });
            });
    };

    getFriendList = (): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        let action = { [CONSTANTS.kParamAction]: 'lstbuddy' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'lstbuddy');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    getCensorList = (): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        let action = { [CONSTANTS.kParamAction]: 'lstcensor' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'lstcensor');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //censor
    censorRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'censor' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'censor');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //censor
    uncensorRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'uncensor' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'uncensor');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //mkrequest being rejected by receiver
    rmFriendRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'rmrequest' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'rmrequest');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    rmAddedFriendRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'rmfriend' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'rmfriend');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //mkrequest being accepted by receiver
    mkFriend = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'mkfriend' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'mkfriend');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //mkrequest being sent
    mkFriendRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'mkrequest' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'mkrequest');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    //mkrequest being canceled by sender
    cancelFriendRequest = (otherguid: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamOther]: otherguid,
        };

        let action = { [CONSTANTS.kParamAction]: 'cancelrequest' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'cancelrequest');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    getPendingFriendList = (): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        let action = { [CONSTANTS.kParamAction]: 'lstbuddyrequestpending' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'lstbuddyrequestpending');
        return requestManager.axiosinst({
            url: CONSTANTS.kFriendApiPath,
            data: params,
        });
    };

    getStatsBatched = (guids: Array<string>, reqfields: Array<string>): Array<AxiosPromise<ServerResponse>> => {
        let promises: Array<AxiosPromise<ServerResponse>> = [];
        if (guids !== null && guids !== undefined && guids.length > 0) {
            let i = 0;
            let arrlen = guids.length;
            let slidingwin = CONSTANTS.kStatsBatchCount;
            while (i < arrlen) {
                let batch = guids.slice(i, (i += slidingwin));
                let promise: AxiosPromise<ServerResponse> = this.getStats(batch, reqfields);
                promises.push(promise);
            }
        } else {
            let promise: AxiosPromise<ServerResponse> = this.getStats(guids, reqfields);
            promises.push(promise);
        }
        return promises;
    };

    getStats = (guids: Array<string>, reqfields: Array<string>): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        if (guids !== null && guids !== undefined && guids.length > 0) {
            reqdata = { ...reqdata, ...{ [CONSTANTS.kParamAccounts]: guids } };
        }

        if (reqfields !== null && reqfields !== undefined && reqfields.length > 0) {
            reqdata = { ...reqdata, ...{ [CONSTANTS.kParamReqFields]: reqfields } };
        }

        let action = { [CONSTANTS.kParamAction]: 'getstats' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'getstats');
        return requestManager.axiosinst({
            url: CONSTANTS.kStatsApiPath,
            data: params,
        });
    };

    getGuidFromEmailOrName = (other: string): AxiosPromise<any> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        if (other !== null && other !== undefined && other.length > 0) {
            reqdata = { ...reqdata, ...{ [CONSTANTS.kParamOther]: other } };
        }

        let action = { [CONSTANTS.kParamAction]: 'getGuid' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kJson]: JSON.stringify(mdata) });

        rjLog(params, 'getGuid');
        return requestManager.axiosinst({
            baseURL: CONSTANTS.kLxEmUrl + 'getGuid?ver=IPH_4_0',
            data: params,
        });
    };
}
const fndApi: FndApi = new FndApi();
export default fndApi;
