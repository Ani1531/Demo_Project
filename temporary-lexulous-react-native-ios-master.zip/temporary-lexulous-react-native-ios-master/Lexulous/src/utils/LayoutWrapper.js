import {
    setBoardAboveViewsHeight,
    setSidePanelTabWidthHeight,
} from './GameBoardUtils';
import { getNull } from './Utils';

export default class LayoutWrapper {
    static getScrollX = getNull;
    static getScrollY = getNull;
    static isSafariMobile = getNull;
    static isSafari = getNull;
    static getMobileLobbyTabHeight = () => 30;
    static getDialogTransformValue = () => [{ scale: 0.9 }];
    static getDialogTopValue = () => null;
    static getDialogLeftValue = () => null;
    static getSparkTransformValue = () => [{ scaleX: 2 }];
    static getPuzzleBoardHeaderTransformValue = () => [{ scaleY: 2 }];
    static getHistoryCellPadding = () => ({
        padding: 2,
    });
    static getBoardContainerHeight = () => ({
        height: '100%',
    });
    static getNativeDriverValue = () => false;
    static setBoardHeaderHeight = (height) => {
        setBoardAboveViewsHeight(height);
    };
    static setSidePanelTabWidthHeight = (width, height) => {
        setSidePanelTabWidthHeight(width, height);
    };
    static getLoaderContainerHeight = () => null;
}
