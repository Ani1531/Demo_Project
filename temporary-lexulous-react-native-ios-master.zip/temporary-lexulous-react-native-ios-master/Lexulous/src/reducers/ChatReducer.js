import get from 'lodash/get';
import { CHAT_APPEND_LIST_ITEM, CHAT_CLEAR_LIST, CHAT_APPEND_LIST_ITEM_MORE_TIME } from '../configs/ActionIdentifiers';
import * as d3 from 'd3-time-format';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import log from 'loglevel';
import cloneDeep from 'lodash/cloneDeep';
// import { parseEmojis } from '../utils/StringUtils';

const INITIAL_STATE = {
    messages: [],
};

const formatMessageData = (item) => {
    let formatDate = d3.timeFormat('%b %d, %Y, %I:%M %p');
    item.message.formattedTime = formatDate(new Date(get(item, 'message.time') * 1000));
    let copyFormatDate = d3.timeFormat('%Y-%m-%d %H:%M');
    item.message.copyFormattedTime = copyFormatDate(new Date(get(item, 'message.time') * 1000));
    if (!item.hasOwnProperty('general_announce')) {
        // item.message.msg = parseEmojis(get(item, 'message.msg'));
        item.message.msg = get(item, 'message.msg');
    }
    return item;
};

const chatReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case CHAT_APPEND_LIST_ITEM:
            log.info('ChatReducer: ' + action.type);
            state = cloneDeep(state);
            let { messages } = state;
            if (Array.isArray(action.payload)) {
                let revisedList = action.payload.map(formatMessageData);
                messages.unshift(...revisedList.reverse());
            } else {
                messages.unshift(formatMessageData(action.payload));
            }
            break;
        case CHAT_CLEAR_LIST:
            log.info('ChatReducer: ' + action.type);
            state = cloneDeep(state);
            state.messages = [];
            break;
        case CHAT_APPEND_LIST_ITEM_MORE_TIME:
            log.info('ChatReducer: ' + action.type);
            state = cloneDeep(state);
            let guid = get(action.payload, 'data.guid');
            let additionText =
                get(action.payload, 'data.time', 10) +
                's ' +
                (guid === ConfigurationWrapper.getSpecificLexulousGameConfiguration('guid') ? 'given to opp.' : 'received');
            let messageObj = {
                general_announce: additionText,
                id: Date.now(),
                message: {
                    sender: guid,
                    time: Date.now() / 1000,
                },
            };
            state.messages.unshift(formatMessageData(messageObj));
            break;
    }
    return { ...state };
};

export default chatReducer;
