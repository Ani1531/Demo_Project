// @flow

import type { UserStats, MinStatsAction, ActionUpdateMinStats } from '../../commons/RJTypes';
import { UPDATE_MINSTATS, CLR_MINSTATS } from './MinStatsEventTypes';

const INITIAL_MINSTAT: { [string]: UserStats } = {};

export default function MinStatsReducer(state: { [string]: UserStats } = INITIAL_MINSTAT, action: MinStatsAction) {
    switch (action.type) {
        case UPDATE_MINSTATS: {
            let mdfdaction = ((action: any): ActionUpdateMinStats);
            return { ...state, ...mdfdaction.payload };
        }
        case CLR_MINSTATS: {
            return {};
        }
        default:
            return state;
    }
}
