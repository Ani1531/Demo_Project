// @flow

import type { UserStats, ActionUpdateMinStats, ActionClearMinStats } from '../../commons/RJTypes';
import { UPDATE_MINSTATS, CLR_MINSTATS } from './MinStatsEventTypes';

export const actionUpdateMinStats = (stats: { [string]: UserStats }): ActionUpdateMinStats => {
    return {
        type: UPDATE_MINSTATS,
        payload: stats,
    };
};

export const actionClearMinStats = (): ActionClearMinStats => {
    return {
        type: CLR_MINSTATS,
    };
};
