// @flow

import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { StyleSheet, Text, View, Pressable, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import * as CONSTANTS from '../commons/Constants';
import netManager from '../commons/RJNetInfo';
import requestManager from '../commons/RequestManager';
import dataServer from '../store/Store';
import { translate } from '../commons/translations/LangTransator';
import SelectDropdown from 'react-native-select-dropdown';
import trslateConstants from '../commons/translations/TrslateConstants';
import SliderContainer from '../profileview/SliderContainer';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { actionUpdateUserSettings } from '../userprofile/PFLAction';
import i18n from 'i18n-js';
import fndApi from '../friends/FndApi';
import hostedGamesApi from '../gamesfactory/hostedgames/HostedGamesApi';
import * as PFLSelector from '../userprofile/PFLSelector';
import type {
    userSettings,
    ServerResponse,
    PopupData,
    us_dictionary,
    HostGameRequestConfig,
    UserStats,
} from '../commons/RJTypes';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import { handleException } from '../commons/RJUtils';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type HostAGameContainerProps = {
    profileSettings: userSettings,
    minStats: { [string]: UserStats },
    popups: PopupData,
    closePopupHandler: () => void,
};

type HostAGameContainerState = {
    playerNum: Array<string>,
    boardType: Array<string>,
    gameType: Array<string>,
    dictionary: Array<string>,
    maxReq: Array<string>,
    dayPrTurn: Array<string>,
    range: string,
    selectedPlyrNum: string,
    selectedBoardType: string,
    selectedGmtype: string,
    selectedDictionary: string,
    selectedMaxReq: string,
    selectedDayPrTurn: string,
    seletedRange: string,
};

class HostAGameContainer extends React.Component<HostAGameContainerProps, HostAGameContainerState> {
    constructor(props: HostAGameContainerProps) {
        super(props);
        this.state = {
            playerNum: ['2', '3', '4'],
            boardType: [translate('board_clsc'), translate('board_lx')],
            gameType: [translate('game_reglr'), translate('game_chlg')],
            dictionary: [translate('dict_us'), translate('dict_uk'), translate('dict_fr'), translate('dict_it')],
            maxReq: ['1', '2', '3', '4', '5'],
            dayPrTurn: ['1', '2', '5', '7', '14'],
            range: this.props.profileSettings.us_gamestart?.gs_ratingrange ?? '600-4200',
            selectedPlyrNum: '2',
            selectedBoardType: translate('board_clsc'),
            selectedGmtype:
                trslateConstants.GameTypeValues()[
                    this.props.profileSettings.us_gamestart?.gs_gametype ?? CONSTANTS.Email_Regular
                ] ?? translate('game_reglr'),
            selectedDictionary:
                trslateConstants.DictionaryValues()[
                    this.props.profileSettings.us_gamestart?.gs_prefdic ?? CONSTANTS.US_English
                ] ?? translate('dict_us'),
            selectedMaxReq: this.props.profileSettings.us_gamestart?.gs_maxreq ?? '1',
            selectedDayPrTurn: this.props.profileSettings.us_gamestart?.gs_speed ?? '1',
            seletedRange: '600-4200',
        };
    }

    getLoggedInRating = () => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        if (sguid != null && sguid != undefined) {
            return this.props.minStats[sguid].rating_stats?.rating;
        }
        return '1500';
    };

    getDropDownIcon = () => {
        return <FontAwesomeIcon icon={faCaretDown} size={20} color={themeConfigutation.getColor('#000')} />;
    };

    updateUserSetting = () => {
        let dictmapping: { [key: string]: us_dictionary } = {
            [translate('dict_us')]: CONSTANTS.US_English,
            [translate('dict_uk')]: CONSTANTS.UK_English,
            [translate('dict_it')]: CONSTANTS.Italian,
            [translate('dict_fr')]: CONSTANTS.French,
        };
        let dict: us_dictionary = dictmapping[this.state.selectedDictionary] ?? CONSTANTS.US_English;
        let gametypemapping: { [key: string]: string } = {
            [translate('game_reglr')]: CONSTANTS.Email_Regular,
            [translate('game_chlg')]: CONSTANTS.Email_Challange,
        };
        let gmtype: string = gametypemapping[this.state.selectedGmtype] ?? CONSTANTS.Email_Regular;
        let gameSettingConfig = {
            us_gamestart: {
                gs_prefdic: dict,
                gs_ratingrange: this.state.seletedRange,
                gs_gametype: gmtype,
                gs_speed: this.state.selectedDayPrTurn,
                gs_maxreq: this.state.selectedMaxReq,
            },
        };
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateUserSetting(gameSettingConfig);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    dataServer.getStore().dispatch(actionUpdateUserSettings(gameSettingConfig));
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    doHostAGame = () => {
        let dictmapping: { [key: string]: us_dictionary } = {
            [translate('dict_us')]: CONSTANTS.US_English,
            [translate('dict_uk')]: CONSTANTS.UK_English,
            [translate('dict_it')]: CONSTANTS.Italian,
            [translate('dict_fr')]: CONSTANTS.French,
        };
        let dict: us_dictionary = dictmapping[this.state.selectedDictionary] ?? CONSTANTS.US_English;

        let gametypemapping: { [key: string]: string } = {
            [translate('game_reglr')]: CONSTANTS.Email_Regular,
            [translate('game_chlg')]: CONSTANTS.Email_Challange,
        };
        let gmtype: string = gametypemapping[this.state.selectedGmtype] ?? CONSTANTS.Email_Regular;

        let boardtypemapping: { [key: string]: string } = {
            [translate('board_clsc')]: CONSTANTS.Normal,
            [translate('board_lx')]: CONSTANTS.Super,
        };
        let boardtype: string = boardtypemapping[this.state.selectedBoardType] ?? CONSTANTS.Normal;

        let range_value = this.state.seletedRange.split('-');

        let hostGameConfig: HostGameRequestConfig = {
            ['fftdays']: this.state.selectedDayPrTurn,
            ['adult']: 'n',
            ['brag']: '',
            ['dic']: dict,
            ['fromrating']: range_value[0],
            ['torating']: range_value[1],
            ['maxrequest']: this.state.selectedMaxReq,
            ['ver']: CONSTANTS.appVersion,
            ['gametype']: gmtype,
            ['boardtype']: boardtype,
            ['device']: CONSTANTS.getOSPlatformString(),
            ['speed']: 's',
            ['numplys']: this.state.selectedPlyrNum,
        };
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = hostedGamesApi.hostGame(hostGameConfig);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    if (result.check == CONSTANTS.kSuccess) {
                        this.updateUserSetting();
                        hostedGamesApi.getHostedGamesList();
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                });
        }
    };

    getSelectedItemValues = (data: string, title: string) => {
        if (title == translate('players')) {
            this.setState({ selectedPlyrNum: data });
        }
        if (title == translate('board_size')) {
            this.setState({ selectedBoardType: data });
        }
        if (title == translate('game_type')) {
            this.setState({ selectedGmtype: data });
        }
        if (title == translate('dictionary')) {
            this.setState({ selectedDictionary: data });
        }
        if (title == translate('max_req')) {
            this.setState({ selectedMaxReq: data });
        }
        if (title == translate('day_per_turns')) {
            this.setState({ selectedDayPrTurn: data });
        }
    };

    onRangeValueSelect = (min: number, max: number, key: string) => {
        let updated_range = min.toString() + '-' + max.toString();
        console.log('setting_lbl', updated_range);
        this.setState({ seletedRange: updated_range });
    };

    getSliderContainer = (data: string) => {
        let range_value = data.split('-');
        let min_range = Number(range_value[0]);
        let max_range = Number(range_value[1]);
        if (min_range < CONSTANTS.SliderLowerRange) {
            min_range = CONSTANTS.SliderLowerRange;
        }
        if (max_range > CONSTANTS.SliderUpperRange) {
            max_range = CONSTANTS.SliderUpperRange;
        }
        return (
            <View
                style={{
                    justifyContent: 'flex-start',
                    flexDirection: 'row',
                }}
            >
                <SliderContainer
                    min={min_range}
                    max={max_range}
                    style={styles.slider_container}
                    onValueSelect={this.onRangeValueSelect}
                    tag={'gs_prefdic'}
                />
            </View>
        );
    };

    getSelectDropdown = (title: string, dropDwnData: Array<string>, seletedItem: string, maxWidth: number) => {
        return (
            <>
                <Text style={{ textAlign: 'center', paddingBottom: 4, color: themeConfigutation.getColor('#000') }}>
                    {title}
                </Text>
                <SelectDropdown
                    rowStyle={{
                        backgroundColor: themeConfigutation.getColor('#fff'),
                        ...Platform.select({
                            native: {},
                            default: { paddingVertical: 13 },
                        }),
                    }}
                    buttonStyle={[
                        styles.drillDown_pickerStyle,
                        { backgroundColor: themeConfigutation.getColor('#d6d6d7'), maxWidth: maxWidth },
                    ]}
                    dropdownIconPosition={'right'}
                    dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                    renderDropdownIcon={this.getDropDownIcon}
                    data={dropDwnData}
                    onSelect={(selectedItem: string, index: number) => this.getSelectedItemValues(selectedItem, title)}
                    renderCustomizedButtonChild={() => {
                        return (
                            <Text style={{ alignSelf: 'center', color: themeConfigutation.getColor('#000') }}>
                                {seletedItem}
                            </Text>
                        );
                    }}
                    renderCustomizedRowChild={(item: string) => {
                        return (
                            <Text
                                style={{
                                    alignSelf: 'center',
                                    flexWrap: 'wrap',
                                    padding: 3,
                                    color: themeConfigutation.getColor('#000'),
                                }}
                            >
                                {item}
                            </Text>
                        );
                    }}
                    rowTextStyle={{ color: themeConfigutation.getColor('#000') }}
                    buttonTextStyle={{ color: themeConfigutation.getColor('#000') }}
                />
            </>
        );
    };

    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.container,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('host_game_container_closed', 'host_game_container');
                            this.props.closePopupHandler();
                        }}
                        style={[styles.xBtnStyle]}
                    >
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <View style={styles.drpdwnContainer}>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(translate('players'), this.state.playerNum, this.state.selectedPlyrNum, 50)}
                        </View>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(
                                translate('board_size'),
                                this.state.boardType,
                                this.state.selectedBoardType,
                                140
                            )}
                        </View>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(
                                translate('game_type'),
                                this.state.gameType,
                                this.state.selectedGmtype,
                                120
                            )}
                        </View>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(
                                translate('dictionary'),
                                this.state.dictionary,
                                this.state.selectedDictionary,
                                120
                            )}
                        </View>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(translate('max_req'), this.state.maxReq, this.state.selectedMaxReq, 50)}
                        </View>
                        <View style={{ padding: 4 }}>
                            {this.getSelectDropdown(
                                translate('day_per_turns'),
                                this.state.dayPrTurn,
                                this.state.selectedDayPrTurn,
                                60
                            )}
                        </View>
                    </View>
                    <View style={{ width: '100%', paddingVertical: 16, paddingHorizontal: 8 }}>
                        <Text style={{ textAlign: 'left', paddingBottom: 12 }}>
                            {i18n.t('slide_title', {
                                rating: this.getLoggedInRating(),
                            })}
                        </Text>
                        {this.getSliderContainer(this.state.range)}
                    </View>
                    <View style={styles.btnContainer}>
                        <Pressable
                            style={styles.buttonStyle}
                            onPress={() => {
                                this.doHostAGame();
                                this.props.closePopupHandler();
                            }}
                        >
                            <Text style={{ textAlign: 'center', color: 'white' }}>{translate('host_game')}</Text>
                        </Pressable>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        maxWidth: 360,
        maxHeight: 450,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 12,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    drillDown_pickerStyle: {
        height: 30,
        alignSelf: 'center',
        justifyContent: 'center',
        borderWidth: 1,
    },
    slider_container: {
        width: '100%',
        justifyContent: 'center',
    },
    drpdwnContainer: {
        flexWrap: 'wrap',
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    btnContainer: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingBottom: 16,
        paddingHorizontal: 8,
    },
    buttonStyle: {
        backgroundColor: '#1d9df1',
        justifyContent: 'center',
        width: 100,
        height: 40,
        borderRadius: 4,
    },
});

function mapStateToProps(state) {
    const { profileSettings, popups, minStats, utils } = state;
    return { profileSettings, popups, minStats, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionUpdateUserSettings,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(HostAGameContainer);
