// @flow
import dataServer from '../store/Store';
import { appleAuth } from '@invertase/react-native-apple-authentication';
import type { AppleRequestResponse, AppleCredentialState } from '@invertase/react-native-apple-authentication';
import * as CONSTANTS from './Constants';
import userDefault from '../commons/UserDefault';
import LgnMgr from './LgnMgr';
import lxlsLgnMgr from './LXLSLgnMgr';
import { actionUpdateAppleLgnInfo } from '../userprofile/PFLAction';
import type { AppleLoginInfo, RegisterAppleUserRequest } from './RJTypes';
import { handleException } from './RJUtils';

class ApplLgnMgr extends LgnMgr {
    type = 'ApplLgnMgr';
    appleAuthCredentialListener = null;

    constructor() {
        super();
        this.onAppInit();
    }

    onAppInit = (): void => {
        //eventlistener will be called by apple
        if (CONSTANTS.isAppleLoginSupported()) {
            this.appleAuthCredentialListener = appleAuth.onCredentialRevoked(async () => {
                let delkeys = [
                    CONSTANTS.kPsistApplUserID,
                    CONSTANTS.kPsistApplAuthCode,
                    CONSTANTS.kPsistApplIdttyToken,
                    CONSTANTS.kPsistApplEmail,
                    CONSTANTS.kPsistApplFmlyName,
                    CONSTANTS.kPsistApplGivenName,
                    CONSTANTS.kPsistApplNickName,
                ];
                userDefault.clearMultiple(delkeys).then((result) => {
                    dataServer.getStore().dispatch(actionUpdateAppleLgnInfo(null));
                    lxlsLgnMgr.deleteLoginData();
                });
            });
        }
    };

    //apple login started check if logged in previously
    fetchAndUpdateAppleCredentialState = async (user: string) => {
        const credentialState: AppleCredentialState = await appleAuth.getCredentialStateForUser(user);
        if (credentialState !== appleAuth.State.AUTHORIZED) {
            let delkeys = [
                CONSTANTS.kPsistApplUserID,
                CONSTANTS.kPsistApplAuthCode,
                CONSTANTS.kPsistApplIdttyToken,
                CONSTANTS.kPsistApplEmail,
                CONSTANTS.kPsistApplFmlyName,
                CONSTANTS.kPsistApplGivenName,
                CONSTANTS.kPsistApplNickName,
            ];
            userDefault.clearMultiple(delkeys);
            dataServer.getStore().dispatch(actionUpdateAppleLgnInfo(null));
            lxlsLgnMgr.deleteLoginData();
        }
    };

    checkLoginSilentMode = async (): Promise<void> => {
        let p1 = this.getLoginData();
        p1.then((lgninfo: AppleLoginInfo) => {
            if (lgninfo != null && lgninfo != undefined) {
                let appleuser = lgninfo.appluserid ?? null;
                if (appleuser !== null) {
                    dataServer.getStore().dispatch(actionUpdateAppleLgnInfo(lgninfo));
                    this.fetchAndUpdateAppleCredentialState(appleuser);
                }
            }
        }).catch((err) => handleException(err));
    };

    signInWithApple = async (
        onCompletion: ?(c: ?() => void, a: AppleCredentialState, b: AppleRequestResponse) => Promise<void>,
        onCompletionCallback: ?() => void
    ): Promise<void> => {
        const appleAuthRequestResponse: AppleRequestResponse = await appleAuth
            .performRequest({
                requestedOperation: appleAuth.Operation.LOGIN,
                requestedScopes: [appleAuth.Scope.EMAIL, appleAuth.Scope.FULL_NAME],
            })
            .catch((e) => {
                handleException(e);
            });
        if (appleAuthRequestResponse != null && appleAuthRequestResponse != undefined) {
            const credentialState: AppleCredentialState = await appleAuth
                .getCredentialStateForUser(appleAuthRequestResponse.user)
                .catch((e) => {
                    handleException(e);
                });
            if (onCompletion) {
                onCompletion(onCompletionCallback, credentialState, appleAuthRequestResponse);
            }
        }
    };

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        let deletedaaplinfo = await this.deleteAppleLoginInfo();
        let delpendingassoc = await this.deletePendingAssociation();
        if (onCompletion) {
            onCompletion();
        }
        dataServer.getStore().dispatch(actionUpdateAppleLgnInfo(null));
    };

    deleteAppleLoginInfo = async (): Promise<boolean> => {
        let delkeys = [
            CONSTANTS.kPsistApplUserID,
            CONSTANTS.kPsistApplAuthCode,
            CONSTANTS.kPsistApplIdttyToken,
            CONSTANTS.kPsistApplEmail,
            CONSTANTS.kPsistApplFmlyName,
            CONSTANTS.kPsistApplGivenName,
            CONSTANTS.kPsistApplNickName,
            CONSTANTS.kPsistAppleRefTkn,
        ];
        await userDefault.clearMultiple(delkeys);
        return true;
    };

    getDataFromAppleCredential = (appleAuthRequestResponse: AppleRequestResponse) => {
        let bulkdata = {};
        let rdxdata: AppleLoginInfo = {};
        let regdata: RegisterAppleUserRequest = {};
        if (appleAuthRequestResponse.user !== null && appleAuthRequestResponse.user !== undefined) {
            bulkdata[CONSTANTS.kPsistApplUserID] = appleAuthRequestResponse.user;
            rdxdata.appluserid = appleAuthRequestResponse.user;
            regdata[CONSTANTS.kParamUser] = appleAuthRequestResponse.user;
        }
        if (appleAuthRequestResponse.authorizationCode !== null && appleAuthRequestResponse.authorizationCode !== undefined) {
            bulkdata[CONSTANTS.kPsistApplAuthCode] = appleAuthRequestResponse.authorizationCode;
            rdxdata.applauthcode = appleAuthRequestResponse.authorizationCode;
            regdata[CONSTANTS.kParamAuthCode] = appleAuthRequestResponse.authorizationCode;
        }
        if (appleAuthRequestResponse.identityToken !== null && appleAuthRequestResponse.identityToken !== undefined) {
            bulkdata[CONSTANTS.kPsistApplIdttyToken] = appleAuthRequestResponse.identityToken;
            rdxdata.applidttytkn = appleAuthRequestResponse.identityToken;
            regdata[CONSTANTS.kParamToken] = appleAuthRequestResponse.identityToken;
        }
        if (appleAuthRequestResponse.email !== null && appleAuthRequestResponse.email !== undefined) {
            bulkdata[CONSTANTS.kPsistApplEmail] = appleAuthRequestResponse.email;
            rdxdata.applemail = appleAuthRequestResponse.email;
            regdata[CONSTANTS.kParamEmail] = appleAuthRequestResponse.email;
        }
        if (
            appleAuthRequestResponse.fullName.familyName !== null &&
            appleAuthRequestResponse.fullName.familyName !== undefined
        ) {
            bulkdata[CONSTANTS.kPsistApplFmlyName] = appleAuthRequestResponse.fullName.familyName;
            rdxdata.fmlyname = appleAuthRequestResponse.fullName.familyName;
            regdata[CONSTANTS.kParamFamilyName] = appleAuthRequestResponse.fullName.familyName;
        }
        if (appleAuthRequestResponse.fullName.givenName !== null && appleAuthRequestResponse.fullName.givenName !== undefined) {
            bulkdata[CONSTANTS.kPsistApplGivenName] = appleAuthRequestResponse.fullName.givenName;
            rdxdata.gvnname = appleAuthRequestResponse.fullName.givenName;
            regdata[CONSTANTS.kParamGivenName] = appleAuthRequestResponse.fullName.givenName;
        }
        if (appleAuthRequestResponse.fullName.nickname !== null && appleAuthRequestResponse.fullName.nickname !== undefined) {
            bulkdata[CONSTANTS.kPsistApplNickName] = appleAuthRequestResponse.fullName.nickname;
            rdxdata.nickname = appleAuthRequestResponse.fullName.nickname;
            regdata[CONSTANTS.kParamNickName] = appleAuthRequestResponse.fullName.nickname;
        }
        return { bulkdata, rdxdata, regdata };
    };

    getLoginData = async (): Promise<AppleLoginInfo> => {
        let reqdata = [
            CONSTANTS.kPsistApplUserID,
            CONSTANTS.kPsistApplAuthCode,
            CONSTANTS.kPsistApplIdttyToken,
            CONSTANTS.kPsistApplEmail,
            CONSTANTS.kPsistApplFmlyName,
            CONSTANTS.kPsistApplGivenName,
            CONSTANTS.kPsistApplNickName,
        ];

        let result = await userDefault.getMultiple(reqdata);
        let data: AppleLoginInfo = {};
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    switch (reqdata[index]) {
                        case CONSTANTS.kPsistApplUserID:
                            data.appluserid = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplAuthCode:
                            data.applauthcode = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplIdttyToken:
                            data.applidttytkn = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplEmail:
                            data.applemail = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplFmlyName:
                            data.fmlyname = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplGivenName:
                            data.gvnname = JSON.parse(JSON.stringify(value));
                            break;
                        case CONSTANTS.kPsistApplNickName:
                            data.nickname = JSON.parse(JSON.stringify(value));
                            break;
                    }
                }
            });
        }
        return data;
    };
}
const applLgnMgr: ApplLgnMgr = new ApplLgnMgr();

export default applLgnMgr;
