import React from 'react';
import { Text } from 'react-native';

export default class ChatMessage extends React.PureComponent {
    render = () => <Text>{this.props.message}</Text>;
}
