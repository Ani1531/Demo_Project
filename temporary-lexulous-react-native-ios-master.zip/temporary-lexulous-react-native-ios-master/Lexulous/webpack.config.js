const path = require('path');

const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ReactWebConfig = require('react-web-config/lib/ReactWebConfig').ReactWebConfig;

const appDirectory = path.resolve(__dirname);
const envFilePath = path.resolve(appDirectory, '.env');

const compileNodeModules = [
    // Add every react-native package that needs compiling
    'react-native-gesture-handler',
    'react-native-loading-spinner-overlay',
    'rn-range-slider',
    'react-native-collapsible',
    'react-native-select-dropdown',
    'react-native-fbsdk-next',
].map((moduleName) => path.resolve(appDirectory, `node_modules/${moduleName}`));

const babelLoaderConfiguration = {
    test: /\.js$|tsx?$/,
    // Add every directory that needs to be compiled by Babel during the build.
    include: [
        path.resolve(__dirname, 'index.web.js'), // Entry to your application
        path.resolve(__dirname, './src/com/lexulous/Lexulous/app/AppContainer.js'), // Change this to your main App file
        path.resolve(__dirname, 'src'),
        ...compileNodeModules,
    ],
    use: {
        loader: 'babel-loader',
        options: {
            cacheDirectory: true,
            presets: ['module:metro-react-native-babel-preset', '@babel/preset-react', '@babel/preset-flow'],
            plugins: ['react-native-web'],
        },
    },
};

const imageLoaderConfiguration = {
    test: /\.(gif|jpe?g|png)$/,
    use: {
        loader: 'url-loader',
        options: {
            name: '[name].[ext]',
            esModule: false,
        },
    },
};

const svgLoaderConfiguration = {
    test: /\.svg$/,
    use: ['@svgr/webpack', 'url-loader'],
};

const cssLoaderConfiguration = {
    test: /\.css$/i,
    use: ['style-loader', 'css-loader'],
};

module.exports = {
    entry: {
        app: path.join(__dirname, 'index.web.js'),
    },
    output: {
        path: path.resolve(appDirectory, 'build'),
        publicPath: 'auto',
        filename: 'lexulous.bundle.js',
    },
    resolve: {
        extensions: ['.web.tsx', '.web.ts', '.tsx', '.ts', '.web.js', '.js'],
        alias: {
            'react-native-config': 'react-web-config',
            'react-native$': 'react-native-web',
            'react-native/Libraries/vendor/emitter/EventEmitter$':
                'react-native-web/build/vendor/react-native/emitter/EventEmitter',
        },
    },
    module: {
        rules: [babelLoaderConfiguration, imageLoaderConfiguration, svgLoaderConfiguration, cssLoaderConfiguration],
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: path.join(__dirname, 'index.html'),
        }),
        new webpack.HotModuleReplacementPlugin(),
        new webpack.DefinePlugin({
            // See: https://github.com/necolas/react-native-web/issues/349
            __DEV__: JSON.stringify(true),
        }),
        ReactWebConfig(envFilePath),
    ],
};
