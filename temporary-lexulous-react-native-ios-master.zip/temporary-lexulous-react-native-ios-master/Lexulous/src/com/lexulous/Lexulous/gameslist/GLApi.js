// @flow

import dataServer from '../store/Store';
import * as CONSTANTS from '../commons/Constants';
import { rjLog } from '../commons/RJUtils.js';
import * as PFLSelector from '../userprofile/PFLSelector';
import type { ServerResponse } from '../commons/RJTypes';
import type { AxiosPromise } from 'axios';
import requestManager from '../commons/RequestManager';
const qs = require('qs');

class GLApi {
    constructor() {}

    getActiveGamesList = (): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
        };

        let action = { [CONSTANTS.kParamAction]: 'gameslist' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });
        rjLog(params, 'getActiveGamesList');
        return requestManager.axiosinst({
            url: CONSTANTS.kGamesListApiPath,
            data: params,
        });
    };

    getArchivedGamesList = (): AxiosPromise<ServerResponse> => {
        let currenttime = Math.floor(Date.now() / 1000);
        let epochtime = currenttime - 90 * 24 * 60 * 60;

        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let reqdata = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            epoch: epochtime.toString(),
            currenttime: currenttime.toString(),
            skip: '0',
            limit: '3',
        };

        let action = { [CONSTANTS.kParamAction]: 'archivegameslist' };
        let mdata = { ...action, ...reqdata };
        let params: string = qs.stringify({ [CONSTANTS.kParams]: JSON.stringify(mdata) });

        rjLog(params, 'getArchivedGamesList');
        return requestManager.axiosinst({
            url: CONSTANTS.kArchiveGamesListApiPath,
            data: params,
        });
    };
}
const glApi = new GLApi();
export default glApi;
