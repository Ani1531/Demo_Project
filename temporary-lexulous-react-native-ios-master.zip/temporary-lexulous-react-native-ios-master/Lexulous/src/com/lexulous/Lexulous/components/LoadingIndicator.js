// @flow

import React from 'react';
import { connect } from 'react-redux';
import Spinner from 'react-native-loading-spinner-overlay';
import type { busyIndicator } from '../commons/RJTypes';
import themeConfigutation from '../commons/ThemeConfiguration';

class LoadingContainer extends React.Component<busyIndicator> {
    shouldComponentUpdate(nextProps: busyIndicator, nextState: Object) {
        let update = nextProps.busyIndicator.busy != this.props.busyIndicator.busy;
        return update;
    }
    render() {
        return (
            <Spinner
                visible={this.props.busyIndicator.busy}
                overlayColor={'rgba(0, 0, 0, 0.02)'}
                color={themeConfigutation.getColor('#0000ff')}
            />
        );
    }
}
function mapStateToProps(state) {
    const { busyIndicator, utils } = state;
    return { busyIndicator, utils };
}

export default connect(mapStateToProps)(LoadingContainer);
