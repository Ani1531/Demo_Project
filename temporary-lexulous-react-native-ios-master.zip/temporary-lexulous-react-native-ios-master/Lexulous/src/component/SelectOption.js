import React from 'react';
import { StyleSheet } from 'react-native';
import SelectDropdown from 'react-native-select-dropdown';
import Config from '../configs/Config';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronDown } from '@fortawesome/free-solid-svg-icons';

const players = {
    2: '2',
    3: '3',
    4: '4',
};
const dictionary = {
    twl: 'US English',
    sow: 'UK English',
    it: 'Italian',
    fr: 'French',
};
const gameType = {
    LR: 'Regular',
    LC: 'Challenge',
};
const rated = {
    y: 'Yes',
    n: 'No',
};
const time = {
    60: '1 minute',
    120: '2 minute',
    180: '3 minute',
    240: '4 minute',
    300: '5 minute',
    420: '7 minute',
    600: '10 minute',
    900: '15 minute',
    1200: '20 minute',
    1800: '30 minute',
    3600: '60 minute',
};
const increments = {
    0: 'None',
    1: '1 second',
    5: '5 second',
    10: '10 second',
    15: '15 second',
    30: '30 second',
};
const robotLevel = {
    1: '1 (Easiest)',
    2: '2',
    3: '3',
    4: '4',
    5: '5',
    6: '6',
    7: '7',
    8: '8',
    9: '9',
    10: '10 (Toughest)',
};
const timeRobot = {
    0: 'Untimed',
    1: '1 minute',
    2: '2 minute',
    3: '3 minute',
    4: '4 minute',
    5: '5 minute',
    7: '7 minute',
    10: '10 minute',
    15: '15 minute',
    20: '20 minute',
    30: '30 minute',
    60: '60 minute',
};

export default class SelectOption extends React.Component {
    getSelectOptions = () => {
        if (this.props.type === Config.SELECT_OPTION_TYPES.players) {
            return Object.values(players);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.dictionary) {
            return Object.values(dictionary);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.gameType) {
            return Object.values(gameType);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.rated) {
            return Object.values(rated);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.time) {
            return Object.values(time);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.increments) {
            return Object.values(increments);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.robotLevel) {
            return Object.values(robotLevel);
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.timeRobot) {
            return Object.values(timeRobot);
        }
    };

    getSelectOptionKey = (index) => {
        if (this.props.type === Config.SELECT_OPTION_TYPES.players) {
            return Object.keys(players)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.dictionary) {
            return Object.keys(dictionary)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.gameType) {
            return Object.keys(gameType)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.rated) {
            return Object.keys(rated)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.time) {
            return Object.keys(time)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.increments) {
            return Object.keys(increments)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.robotLevel) {
            return Object.keys(robotLevel)[index];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.timeRobot) {
            return Object.keys(timeRobot)[index];
        }
    };

    getDefaultSelection = (selectedValue) => {
        if (this.props.type === Config.SELECT_OPTION_TYPES.players) {
            return players[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.dictionary) {
            return dictionary[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.gameType) {
            return gameType[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.rated) {
            return rated[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.time) {
            return time[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.increments) {
            return increments[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.robotLevel) {
            return robotLevel[selectedValue];
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.timeRobot) {
            return timeRobot[selectedValue];
        }
    };

    render = () => (
        <SelectDropdown
            data={this.getSelectOptions()}
            onSelect={(selectedItem, index) => {
                let optionKey = this.getSelectOptionKey(index);
                this.props.onSelectChange(optionKey);
            }}
            defaultButtonText={this.getDefaultSelection(
                this.props.selectedValue
            )}
            buttonTextAfterSelection={(selectedItem, index) => {
                return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
                return item;
            }}
            buttonStyle={styles.dropdown1BtnStyle}
            buttonTextStyle={styles.dropdown1BtnTxtStyle}
            renderDropdownIcon={() => {
                return (
                    <FontAwesomeIcon
                        icon={faChevronDown}
                        size={16}
                        color={'#444'}
                    />
                );
            }}
            dropdownIconPosition={'right'}
            dropdownStyle={styles.dropdown1DropdownStyle}
            rowStyle={styles.dropdown1RowStyle}
            rowTextStyle={styles.dropdown1RowTxtStyle}
        />
    );
}

const styles = StyleSheet.create({
    dropdown1BtnStyle: {
        width: '100%',
        height: 30,
        backgroundColor: 'transparent',
        borderColor: '#444',
        borderBottomColor: '#444',
        borderBottomWidth: 1,
    },
    dropdown1BtnTxtStyle: { color: '#444', textAlign: 'left' },
    dropdown1DropdownStyle: { backgroundColor: '#EFEFEF' },
    dropdown1RowStyle: {
        backgroundColor: '#EFEFEF',
        borderBottomColor: '#C5C5C5',
    },
    dropdown1RowTxtStyle: { color: '#444', textAlign: 'left' },
});
