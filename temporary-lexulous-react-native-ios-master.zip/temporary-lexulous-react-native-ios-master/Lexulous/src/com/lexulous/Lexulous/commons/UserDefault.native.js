// @flow
import DefaultPreference from 'react-native-default-preference';

class UserDefault {
    get = async (key: string): Promise<any> => {
        let jsonValue = await DefaultPreference.get(key);
        return jsonValue;
    };

    set = async (key: string, value: string) => {
        await DefaultPreference.set(key, value);
    };

    clear = async (key: string) => {
        await DefaultPreference.clear(key);
    };

    getMultiple = async (keys: Array<string>) => {
        return await DefaultPreference.getMultiple(keys);
    };

    setMultiple = async (data: { [key: string]: string }) => {
        await DefaultPreference.setMultiple(data);
    };

    clearMultiple = async (keys: Array<string>) => {
        await DefaultPreference.clearMultiple(keys);
    };

    clearAll = async () => {
        await DefaultPreference.clearAll();
    };

    // /** Gets and sets the current preferences file name (android) or user default suite name (ios) **/
    getName = async () => {
        await DefaultPreference.getName();
    };

    setName = async (name: string) => {
        return await DefaultPreference.setName(name);
    };
}

const userDefault = new UserDefault();

export default userDefault;
