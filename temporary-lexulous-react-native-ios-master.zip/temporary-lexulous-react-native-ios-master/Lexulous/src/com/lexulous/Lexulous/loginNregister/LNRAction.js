// @flow

import { LRN_UPDT_UNAME, LRN_UPDT_EMAIL, LRN_UPDT_LGN_INFO, LRN_CLR_DATA } from './LNREventTypes';

import type {
    ActionLrnUpdateName,
    ActionLrnUpdateEmail,
    ActionLrnUpdatePwd,
    LXLSLoginInfo,
    ActionLrnClearData,
} from '../commons/RJTypes';

export const actionLNRUpdateUserName = (data: string): ActionLrnUpdateName => {
    return {
        type: LRN_UPDT_UNAME,
        payload: data,
    };
};

export const actionLNRUpdateUserEmail = (data: string): ActionLrnUpdateEmail => {
    return {
        type: LRN_UPDT_EMAIL,
        payload: data,
    };
};

export const actionLNRUpdateLgnInfo = (data: LXLSLoginInfo): ActionLrnUpdatePwd => {
    return {
        type: LRN_UPDT_LGN_INFO,
        payload: data,
    };
};

export const actionLNRClearData = (): ActionLrnClearData => {
    return {
        type: LRN_CLR_DATA,
    };
};
//LRN_UPDT_LGN_INFO
