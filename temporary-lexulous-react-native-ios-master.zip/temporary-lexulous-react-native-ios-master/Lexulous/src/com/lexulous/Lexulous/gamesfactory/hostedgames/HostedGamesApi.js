// @flow

import dataServer from '../../store/Store';
import * as CONSTANTS from '../../commons/Constants';
import netManager from '../../commons/RJNetInfo';
import { rjLog } from '../../commons/RJUtils.js';
import * as PFLSelector from '../../userprofile/PFLSelector';
import requestManager from '../../commons/RequestManager';
import type { ServerResponse, HostGameRequestConfig, HostedGameElement, HostedGameActionType } from '../../commons/RJTypes';
import { actionResetHostedGames } from '../../gamesfactory/hostedgames/HostedGameAction';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { gameLiveGameHostedGamesListRetrieved } from '../../../../../actions/GameActions';
const qs = require('qs');

class HostedGamesApi {
    fetchHostedGames = () => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let data = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamAction]: CONSTANTS.kActionGetHostedGames,
            multi: 'y',
        };

        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(data),
        });
        rjLog(params, CONSTANTS.kActionGetHostedGames);
        return requestManager.axiosinst({
            url: CONSTANTS.kHostGamePath,
            data: params,
        });
    };

    getHostedGamesList = () => {
        if (netManager.isConnected()) {
            let rsp: AxiosPromise<ServerResponse> = this.fetchHostedGames();
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((res: ServerResponse) => {
                    if (res.check === CONSTANTS.kSuccess) {
                        let resData: { hostedgames: Array<HostedGameElement> } = ((res.data: any): {
                            hostedgames: Array<HostedGameElement>,
                        });
                        let myguid = PFLSelector.getGUID(dataServer.getStore().getState());
                        dataServer.getStore().dispatch(actionResetHostedGames(resData.hostedgames, myguid));
                        
                        dataServer.getStore().dispatch(gameLiveGameHostedGamesListRetrieved(res));
                    } else {
                        dataServer.getStore().dispatch(actionResetHostedGames([]));
                    }
                })
                .catch((error) => {
                    console.log('Error while fetching hosted games...');
                });
        }
    };

    hostGame = (data: HostGameRequestConfig): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'hostagame',
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
        };
        let mdata = { ...data, ...reqdata };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(mdata),
        });

        rjLog(params, 'hostagame');
        return requestManager.axiosinst({
            url: CONSTANTS.kHostGamePath,
            data: params,
        });
    };

    deleteHostedGames = (data: string): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: 'deletehostedgame',
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            ['reqgameid']: data,
        };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });

        rjLog(params, 'deletehostedgame');
        return requestManager.axiosinst({
            url: CONSTANTS.kHostGamePath,
            data: params,
        });
    };

    hostedGamesAction = (data: string, action: HostedGameActionType): AxiosPromise<ServerResponse> => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());
        let reqdata = {
            [CONSTANTS.kParamAction]: action,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            ['reqgameid']: data,
        };
        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(reqdata),
        });

        rjLog(params, action);
        return requestManager.axiosinst({
            url: CONSTANTS.kHostGamePath,
            data: params,
        });
    };
}
const hostedGamesApi = new HostedGamesApi();
export default hostedGamesApi;
