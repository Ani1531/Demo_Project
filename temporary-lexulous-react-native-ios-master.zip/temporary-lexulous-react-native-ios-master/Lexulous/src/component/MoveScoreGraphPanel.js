import React from 'react';
import { StyleSheet, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import S14Text from './S14Text';
import loadable from '@loadable/component';

const LazyChartComponent = loadable(() => import('./LazyChartComponent'));

export default class MoveScoreGraphPanel extends React.Component {
    getLoadingText = () => (
        <View style={styles.loadingTextContainer}>
            <S14Text style={styles.loadingText}>Loading...</S14Text>
        </View>
    );

    render = () => (
        <View
            style={[
                styles.mainContainer,
                this.getGraphPanelDimen(),
                this.props.bottomCornerStyle && this.props.bottomCornerStyle(),
                styles.additionalStyles,
            ]}
        >
            <LazyChartComponent
                width={'100%'}
                height={'100%'}
                fallback={this.getLoadingText()}
            />
        </View>
    );

    getGraphPanelDimen = () => ({
        flex: 1,
    });
}

const styles = StyleSheet.create({
    mainContainer: {
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        overflow: 'hidden',
    },
    tooltipContainer: {
        flexDirection: 'column',
        alignContent: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        borderColor: '#cccccc',
        borderWidth: 1,
        padding: 8,
    },
    loadingTextContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    loadingText: {
        opacity: 0.7,
    },
    additionalStyles: {
        borderBottomRightRadius: 0,
        borderBottomLeftRadius: 0,
    },
});
