import {
    CHAT_CLEAR_LIST,
    CHAT_APPEND_LIST_ITEM,
    CHAT_APPEND_LIST_ITEM_MORE_TIME,
} from '../configs/ActionIdentifiers';

export const clearMessageList = (globalState) => ({
    type: CHAT_CLEAR_LIST,
    globalState,
});

export const appendToMessageList = (chatObj) => ({
    type: CHAT_APPEND_LIST_ITEM,
    payload: chatObj,
});

export const appendToMessageListMoreTime = (chatObj) => ({
    type: CHAT_APPEND_LIST_ITEM_MORE_TIME,
    payload: chatObj,
});
