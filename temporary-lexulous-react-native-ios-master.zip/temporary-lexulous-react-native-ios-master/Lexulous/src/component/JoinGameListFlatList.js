import React from 'react';
import { FlatList, StyleSheet } from 'react-native';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import set from 'lodash/set';
import { connect } from 'react-redux';
import GameBoardUtils from '../utils/GameBoardUtils';
import AcceptHostedGameRequestListItem from '../component/AcceptHostedGameRequestListItem';
import ColorConfig from '../configs/ColorConfig';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import DimensionUtils from '../utils/DimensionUtils';

class JoinGameListFlatList extends React.Component {
    shouldComponentUpdate = (nextProps) =>
        !isEqual(
            get(nextProps, 'gamelist.hostedGamesList'),
            get(this.props, 'gamelist.hostedGamesList')
        ) ||
        !isEqual(
            get(nextProps, 'gamelist.normalGameOptionsModalShowRobots'),
            get(this.props, 'gamelist.normalGameOptionsModalShowRobots')
        ) ||
        (LiveGamePlayUtils.isBlitzGame() &&
            !isEqual(
                get(nextProps, 'gamelist.observableGamesList'),
                get(this.props, 'gamelist.observableGamesList')
            ));

    getCursor = (isPlaying, item) => ({
        cursor:
            isPlaying || GameBoardUtils.isMyself(item) ? 'default' : 'pointer',
    });

    getHostedGamesListData = () => {
        let hostedGamesList = this.props.gamelist.hostedGamesList || [];
        if (LiveGamePlayUtils.isBlitzGame()) {
            return hostedGamesList;
        } else {
            let hostedByMe = [];
            let hostedByUsers = [];
            if (
                DimensionUtils.isMobile() ||
                !this.props.gamelist.normalGameOptionsModalShowRobots
            ) {
                // hosted by player
                hostedByMe = hostedGamesList.filter(
                    (player) =>
                        GameBoardUtils.isMyself(get(player, 'uid')) === true
                );

                // hosted by human players
                hostedByUsers = hostedGamesList.filter(
                    (player) =>
                        get(player, 'uid.usrtype') === 'u' &&
                        !GameBoardUtils.isMyself(get(player, 'uid'))
                );
            }
            // hosted by robots
            let hostedByRobots = [];
            if (this.props.gamelist.normalGameOptionsModalShowRobots) {
                hostedByRobots = hostedGamesList.filter(
                    (player) => get(player, 'uid.usrtype') === 'r'
                );
            }
            return [...hostedByMe, ...hostedByUsers, ...hostedByRobots];
        }
    };

    selfHasJoinedBlitzGame = () => {
        let hostedGame = this.props.gamelist.hostedGamesList.find(
            (hostedGameInList) => {
                let jndplys =
                    (hostedGameInList && hostedGameInList.jndplys) || [];
                return jndplys.find((player) =>
                    GameBoardUtils.isMyself(player)
                );
            }
        );
        return hostedGame;
    };

    isBlitzInp = () =>
        LiveGamePlayUtils.isBlitzGame() &&
        (get(this.props, 'gamelist.observableGamesList') || []).length > 0;

    renderAcceptHostedGameRequest = ({ item, index }) => {
        let player = get(item, 'uid');
        set(player, 'rating', get(item, 'rating'));
        set(player, 'status', 'avl');
        return (
            <AcceptHostedGameRequestListItem
                player={player}
                item={item}
                rowColor={
                    index % 2 !== 0
                        ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN
                        : null
                }
                onJoinGameWith={this.props.onJoinGameWith}
                isMyself={
                    LiveGamePlayUtils.isBlitzGame()
                        ? this.selfHasJoinedBlitzGame()
                        : GameBoardUtils.isMyself(player)
                }
                isNormalUser={get(item, 'uid.usrtype') === 'u'}
                showRobots={
                    this.props.gamelist.normalGameOptionsModalShowRobots
                }
                renderPlayerAvatarNameRating={
                    this.props.renderPlayerAvatarNameRating
                }
                renderRatedIndicator={this.props.renderRatedIndicator}
                renderDictionaryIndicator={this.props.renderDictionaryIndicator}
                renderTime={this.props.renderTime}
                isBlitzInp={this.isBlitzInp()}
            />
        );
    };

    render = () => (
        <FlatList
            data={
                this.isBlitzInp()
                    ? get(this.props, 'gamelist.observableGamesList')
                    : this.getHostedGamesListData()
            }
            renderItem={this.renderAcceptHostedGameRequest}
            style={[
                {
                    width: '100%',
                    height: '100%',
                },
                styles.hostedGameListBackgroundColor,
            ]}
            keyExtractor={(item) =>
                LiveGamePlayUtils.isBlitzGame()
                    ? get(item, 'gamereqid')
                    : item.uid.guid
            }
            removeClippedSubviews={true}
            initialNumToRender={8}
            showsVerticalScrollIndicator={true}
            className={'appFlatList'}
        />
    );
}

const styles = StyleSheet.create({
    hostedGameListBackgroundColor: {
        backgroundColor: ColorConfig.HOSTED_GAMES_LIST_BACKGROUND_COLOR,
    },
});

const mapStateToProps = (state) => ({
    config: state.config,
    gamelist: state.gamelist,
});

export default connect(mapStateToProps)(JoinGameListFlatList);
