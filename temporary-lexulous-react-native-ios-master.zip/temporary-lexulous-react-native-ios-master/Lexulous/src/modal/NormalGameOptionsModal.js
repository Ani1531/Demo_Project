import React from 'react';
import { StyleSheet, View, Pressable, TouchableOpacity } from 'react-native';
import DimensionUtils from '../utils/DimensionUtils';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import {
    getGameList,
    getOnlinePlayerList,
    getLiveGameList,
    getGameType,
    getSelfStats,
    getSensorListOnce,
    sendObserveGameRequest,
    sendJoinGameRequest,
    getBuddyRequestList,
} from '../service/GamePlayService';
import get from 'lodash/get';
import debounce from 'lodash/debounce';
import isObject from 'lodash/isObject';
import { to } from 'await-to-js';
import WebSocketProvider from '../provider/WebSocketProvider';
import SettingsUtil from '../utils/SettingsUtil';
import TileTouchableOpacity from '../component/TileTouchableOpacity';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCaretDown, faCaretUp } from '@fortawesome/free-solid-svg-icons';
import { getNull, queueWithPromisifiedPush } from '../utils/Utils';
import GameBoardUtils from '../utils/GameBoardUtils';
//import posed from 'react-pose';
import { createDialogInstance } from '../utils/MessageUtils';
import { getBuddyListOnce } from '../service/LiveGamePlayService';
import HostInviteGameModal from './HostInviteGameModal';
import LayoutUtils from '../utils/LayoutUtils';
import TabPanel from '../component/TabPanel';
import AvatarImage from '../component/AvatarImage';
import StandardButton from '../component/StandardButton';
import SimpleTouchableOpacity from '../component/SimpleTouchableOpacity';
import {
    GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED,
    GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
    GAME_LIVE_OBSERVABLE_GAME_REMOVE,
    GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET,
    GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_GAME_LIST,
    GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST,
    GAME_REDUCER_UNSET_GAME_RESTART_DATA,
} from '../configs/ActionIdentifiers';
import { connect } from 'react-redux';
import log from 'loglevel';
import OnlinePlayerListFlatList from '../component/OnlinePlayerListFlatList';
import JoinGameListFlatList from '../component/JoinGameListFlatList';
import WatchGameListFlatList from '../component/WatchGameListFlatList';
import LobbyChat from '../component/LobbyChat';
import S14Text from '../component/S14Text';
import S16Text from '../component/S16Text';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import DocumentWrapper from '../utils/DocumentWrapper';
import CheckBoxWrapper from '../component/CheckBoxWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';

require('format-unicorn');
// const optionsCursorTrueWithMargin = {
//     followCursor: true,
//     shiftX: 20,
//     shiftY: 0
// };

const startObservingQueue = queueWithPromisifiedPush();

const eventBus = require('js-event-bus')();

// const Modal = posed.div({
//     enter: {y: 0, opacity: 1, delay: 300},
//     exit: {y: 50, opacity: 0, delay: 300}
// });

function onTabPressed() {
    this.handleChangeInTabMobile(this.tabId);
}

function bindFunction() {
    this.bindRequest(this.params);
}

class NormalGameOptionsModal extends React.Component {
    state = {
        isOpen: false,
        isHostGameExpansionPanelOpen: false,
        isGameFeed: false,
        currentTab: 0,
        width: DimensionUtils.getWindowDimensions().width,
        players: 2,
        gametype: 'y',
        time: 600,
        increment: 10,
        dictionary: SettingsUtil.get('us_gamestart.gs_prefdic'),
        wordcheck: 'regular',
        minRating: SettingsUtil.getMinRatingRange(),
        maxRating: SettingsUtil.getMaxRatingRange(),
        keyRightSideLayout: Math.random(),
        keyLeftSideLayout: Math.random(),
        lastRendered: '',
        failureDetail: null,
        overlayBackgroundColor: ColorConfig.TRANSPARENT,
        showWatchGameOverlay: false,
        hoverJoinEffect: false,
        hoverWatchEffect: false,
        hoverRobotEffect: false,
    };

    constructor(props) {
        super(props);
        this.new_game_options_overlay = React.createRef();
        this.playerListOrderByNameButtonRef = React.createRef();
        this.playerListOrderByRatingButtonRef = React.createRef();
        this.playerListOrderByStatusButtonRef = React.createRef();
        this.hostGameButtonRef = React.createRef();
        this.newGameCollapsibleRef = React.createRef();
    }

    showNormalGameOptions = () => {
        this.setState({
            isOpen: true,
        });
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'NormalGameOptionsModal.showNormalGameOptions',
            visible: false,
        });
    };

    /* fetchNormalGameOptions = () => {
        if (!this.props.user.buddyList) {
            eventBus.emit(Config.LOADER_OVERLAY, null, {
                caller: 'NormalGameOptionsModal.fetchNormalGameOptions',
                visible: true,
            });
            getBuddyListOnce();
            getBuddyRequestList();
        }
        if (!this.props.user.sensorList) {
            eventBus.emit(Config.LOADER_OVERLAY, null, {
                caller: 'NormalGameOptionsModal.fetchNormalGameOptions',
                visible: true,
            });
            getSensorListOnce();
        } 
    };*/

    /* hide = () => {
        let wasOpen = this.state.isOpen;
        this.setState({ isOpen: false, dismissAfter: false });
        return wasOpen;
    }; */

    isOpen = () => this.state.isOpen;

    componentDidMount = () => {
        eventBus.on(Config.GET_GAME_LIST_REQUEST_COMPLETE, this.onGetGameListSuccessful);
        if (DimensionUtils.isMobile()) {
            eventBus.on(Config.BOARD_DIMENSION_SET, this.refreshSize);
        }
        this.initRequests();
        if (!DimensionUtils.isMobile() && !LiveGamePlayUtils.isBlitzGame()) {
            if (this.props.gamelist.showGameList === 1) {
                this.onBoxChecked(false);
            }
        }
    };

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.getGameRestartData();
    }

    initRequests = async () => {
        if ([Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(getGameType())) {
            eventBus.emit(Config.LOADER_OVERLAY, null, {
                caller: 'NormalGameOptionsModal.initRequests',
                visible: true,
            });
            await to(
                Promise.all([
                    !this.getGameRestartData() && !this.state.isGameFeed ? this.getGameOptionsList() : null,
                    getSelfStats(),
                ])
            );
            let obj = {
                dictionary: SettingsUtil.get('us_gamestart.gs_prefdic'),
                minRating: SettingsUtil.getMinRatingRange(),
                maxRating: SettingsUtil.getMaxRatingRange(),
            };
            this.setState(obj);
        }
    };

    setGameFeed = (status) => {
        this.setState({ isGameFeed: status });
    };

    getGameRestartData = () => {
        let data = this.peekHasGameRestartData();
        log.info('in App, in setLoaderOverlayVisibility, in NormalGameOptionsModal, in getGameRestartData');
        data.hasGameRestartData && setTimeout(() => WebSocketProvider.handleIncomingMessage(data.gameRestartData, true), 100);
        return data.hasGameRestartData;
    };

    peekHasGameRestartData = () => {
        let gameRestartData = get(this.props, 'game.gameRestartData');
        let hasGameRestartData = isObject(gameRestartData) && Object.keys(gameRestartData).length > 0;
        hasGameRestartData && eventBus.emit(GAME_REDUCER_UNSET_GAME_RESTART_DATA);
        return { gameRestartData, hasGameRestartData };
    };

    componentWillUnmount = () => {
        eventBus.detach(Config.GET_GAME_LIST_REQUEST_COMPLETE, this.onGetGameListSuccessful);
        if (DimensionUtils.isMobile()) {
            eventBus.detach(Config.BOARD_DIMENSION_SET, this.refreshSize);
        }
    };

    refreshSize = () => {
        this.setState({ lastRendered: Date.now() });
    };

    getGameOptionsList = () => {
        if (!this.props.gamelist.hostedGamesList || this.props.reloadNative) {
            getGameList();
        }
        if (!this.props.user.onlinePlayerBuddies || !this.props.user.onlinePlayerOthers || this.props.reloadNative) {
            getOnlinePlayerList();
        }
        if (!this.props.gamelist.observableGamesList || this.props.reloadNative) {
            getLiveGameList();
        }
        if (
            (this.props.gamelist.hostedGamesList ||
                this.props.user.onlinePlayerBuddies ||
                this.props.user.onlinePlayerOthers ||
                this.props.gamelist.observableGamesList) &&
            !this.props.reloadNative
        ) {
            this.showNormalGameOptions();
        }

        if (!this.props.user.buddyList || this.props.reloadNative) {
            getBuddyListOnce();
            getBuddyRequestList();
        }
        if (!this.props.user.sensorList || this.props.reloadNative) {
            getSensorListOnce();
        }
    };

    onGetGameListSuccessful = () => {
        if (!this.getGameRestartData() && !this.state.isGameFeed) {
            this.showNormalGameOptions();
        }
    };

    /* onGetGameListFailed = (extObj) => {
        this.setState({
            showOverlay: true,
            failureDetail: {
                message: extObj.msg,
                btnText: 'Retry',
            },
            overlayBackgroundColor: ColorConfig.WHITE,
        });
    };

    onGetGameListFailedBtnClick = () => {
        this.setState({
            showOverlay: false,
            overlayBackgroundColor: ColorConfig.TRANSPARENT,
        });
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'NormalGameOptionsModal.onGetGameListFailedBtnClick',
            visible: true,
        });
        getGameList();
    }; */

    getLeftSideContainerStyles = () => ({
        width: 'calc(50% - ' + Config.RIGHT_LEFT_MARGIN / 2 + 'px)',
        height: '100%',
    });

    getRightSideContainerStyles = () => ({
        width: 'calc(50% - ' + Config.RIGHT_LEFT_MARGIN / 2 + 'px)',
        height: '100%',
    });

    handleChangeInTabMobile = (value) => {
        eventBus.emit(GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST, null, value);
    };

    getPlayersTileStyle = () => ({
        width: '25%',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        backgroundColor:
            this.props.gamelist.showMobileTablist === 0 ? ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR : undefined,
    });

    getPlayersTileTextStyle = () => ({
        color:
            this.props.gamelist.showMobileTablist === 0
                ? ColorConfig.BUTTON_TEXT_COLOR
                : this.props.config.isDarkMode
                ? ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR
                : ColorConfig.BUTTON_TEXT_COLOR,
    });

    getGamesTileStyle = () => ({
        width: '25%',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        backgroundColor:
            this.props.gamelist.showMobileTablist === 1 ? ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR : undefined,
    });
    getGamesTileTextStyle = () => ({
        color:
            this.props.gamelist.showMobileTablist === 1
                ? ColorConfig.BUTTON_TEXT_COLOR
                : this.props.config.isDarkMode
                ? ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR
                : ColorConfig.BUTTON_TEXT_COLOR,
    });
    getWatchTileStyle = () => ({
        width: '25%',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        backgroundColor:
            this.props.gamelist.showMobileTablist === 2 ? ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR : undefined,
    });
    getWatchTileTextStyle = () => ({
        color:
            this.props.gamelist.showMobileTablist === 2
                ? ColorConfig.BUTTON_TEXT_COLOR
                : this.props.config.isDarkMode
                ? ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR
                : ColorConfig.BUTTON_TEXT_COLOR,
    });
    getNewTileStyle = () => ({
        width: '25%',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'center',
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        backgroundColor:
            this.props.gamelist.showMobileTablist === 3 ? ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR : undefined,
    });
    getNewTileTextStyle = () => ({
        color:
            this.props.gamelist.showMobileTablist === 3
                ? ColorConfig.BUTTON_TEXT_COLOR
                : this.props.config.isDarkMode
                ? ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR
                : ColorConfig.BUTTON_TEXT_COLOR,
    });

    renderMobile = () =>
        !this.state.isOpen ? null : (
            <View
                style={[
                    {
                        width: '100%',
                        height: '100%',
                        backgroundColor: 'yellow',
                    },
                    styles.mainContainer,
                    styles.bodyContainer,
                ]}
            >
                <View
                    style={[
                        styles.tileContainer,
                        //{ height: LayoutWrapper.getMobileLobbyTabHeight() },
                    ]}
                >
                    <StandardButton
                        style={this.getPlayersTileStyle()}
                        onPress={onTabPressed.bind({
                            tabId: 0,
                            handleChangeInTabMobile: this.handleChangeInTabMobile,
                        })}
                        textStyle={this.getPlayersTileTextStyle()}
                        hoverEffect={true}
                        text={'Players'}
                    />
                    {!LiveGamePlayUtils.isBlitzGame() && (
                        <StandardButton
                            style={this.getWatchTileStyle()}
                            onPress={onTabPressed.bind({
                                tabId: 2,
                                handleChangeInTabMobile: this.handleChangeInTabMobile,
                            })}
                            textStyle={this.getWatchTileTextStyle()}
                            hoverEffect={true}
                            text={'Watch'}
                        />
                    )}
                    <StandardButton
                        style={this.getGamesTileStyle()}
                        onPress={onTabPressed.bind({
                            tabId: 1,
                            handleChangeInTabMobile: this.handleChangeInTabMobile,
                        })}
                        textStyle={this.getGamesTileTextStyle()}
                        hoverEffect={true}
                        text={'Join'}
                    />
                    <StandardButton
                        style={this.getNewTileStyle()}
                        onPress={onTabPressed.bind({
                            tabId: 3,
                            handleChangeInTabMobile: this.handleChangeInTabMobile,
                        })}
                        textStyle={this.getNewTileTextStyle()}
                        hoverEffect={true}
                        text={'Chat'}
                    />
                </View>
                <View style={{ flex: 1 }}>
                    <TabPanel
                        style={{
                            flex: 1,
                            width: '100%',
                        }}
                        value={this.props.gamelist.showMobileTablist}
                        index={0}
                    >
                        {this.renderPlayersTab()}
                    </TabPanel>
                    <TabPanel
                        style={{
                            flex: 1,
                            width: '100%',
                        }}
                        value={this.props.gamelist.showMobileTablist}
                        index={1}
                    >
                        {this.renderHostInviteTabs()}
                        {this.renderGamesList()}
                    </TabPanel>
                    <TabPanel
                        style={{
                            flex: 1,
                            width: '100%',
                        }}
                        value={this.props.gamelist.showMobileTablist}
                        index={2}
                    >
                        {this.renderObservableGamesList()}
                    </TabPanel>
                    <TabPanel
                        style={{
                            flex: 1,
                            width: '100%',
                        }}
                        value={this.props.gamelist.showMobileTablist}
                        index={3}
                    >
                        <LobbyChat />
                    </TabPanel>
                </View>
            </View>
        );

    render = () =>
        DimensionUtils.isMobile() ? (
            this.renderMobile()
        ) : !this.state.isOpen ? null : (
            <TileTouchableOpacity
                style={[
                    {
                        height: get(this.props, 'layout.layoutGamePlayAreaHeight'),
                    },
                    StyleSheet.absoluteFill,
                    styles.mainContainer,
                ]}
            >
                <View style={[styles.overflowHidden, styles.heightHundred, styles.maxHeightHundred, styles.rowDirection]}>
                    <View style={[this.getLeftSideContainerStyles(), styles.leftSideContainer, styles.hairlineBorderWidth]}>
                        {this.renderPlayersTab()}
                    </View>
                    <View style={[styles.containerDivider]} />
                    <View
                        style={[
                            this.getRightSideContainerStyles(),
                            styles.rightSideContainer,
                            styles.observeGameListBackgroundColor,
                        ]}
                    >
                        <View style={[styles.columnDirection, styles.flex1, StyleSheet.absoluteFill]}>
                            {this.renderHostInviteTabs()}
                            {this.renderJoinWatchRobotGame()}
                            {this.props.gamelist.showGameList === 2 ? this.renderObservableGamesList() : this.renderGamesList()}
                        </View>
                    </View>
                </View>
                {/* this.state.showOverlay ? (
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            styles.overlayContainer,
                            {
                                backgroundColor:
                                    this.state.overlayBackgroundColor,
                            },
                        ]}
                    >
                        {this.state.failureDetail !== null ? (
                            <View style={styles.failureDetailLayout}>
                                <S14Text
                                    style={LayoutUtils.getCursorDefaultStyle()}
                                >
                                    {this.state.failureDetail.message}
                                </S14Text>
                                {this.state.failureDetail.btnText ? (
                                    <View style={styles.directionRow}>
                                        <TouchableOpacity
                                            activeOpacity={1}
                                            style={styles.btn}
                                            onPress={
                                                this.onGetGameListFailedBtnClick
                                            }
                                        >
                                            <S14Text
                                                style={[
                                                    styles.btnTextStyle,
                                                    styles.cursorPointer,
                                                ]}
                                            >
                                                {
                                                    this.state.failureDetail
                                                        .btnText
                                                }
                                            </S14Text>
                                        </TouchableOpacity>
                                    </View>
                                ) : null}
                            </View>
                        ) : (
                            <S14Text
                                style={LayoutUtils.getLoaderTextColorStyle()}
                            >
                                Connecting ...
                            </S14Text>
                        )}
                    </View>
                ) : null */}
            </TileTouchableOpacity>
        );

    renderHeader = (str) => (
        <View style={[styles.headerContainer, styles.widthHundred]}>
            <S14Text style={[styles.headerText]}>{str}</S14Text>
        </View>
    );

    renderJoinWatchRobotGame = () =>
        LiveGamePlayUtils.isBlitzGame() ? null : (
            <View style={[styles.menuJoinWatch]}>
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={this.onJoinGameClick}
                    onMouseEnter={bindFunction.bind({
                        bindRequest: this.onJoinHoverInOut,
                        params: true,
                    })}
                    onMouseLeave={bindFunction.bind({
                        bindRequest: this.onJoinHoverInOut,
                        params: false,
                    })}
                    style={[
                        styles.headerContainer,
                        {
                            borderBottomColor:
                                this.props.gamelist.showGameList === 1 || this.state.hoverJoinEffect ? 'black' : null,
                            borderBottomWidth: 2,
                            flex: 1,
                        },
                    ]}
                >
                    <S14Text style={[styles.headerText]}>Join Game</S14Text>
                </TouchableOpacity>
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={this.onObserveGameClick}
                    onMouseEnter={bindFunction.bind({
                        bindRequest: this.onWatchHoverInOut,
                        params: true,
                    })}
                    onMouseLeave={bindFunction.bind({
                        bindRequest: this.onWatchHoverInOut,
                        params: false,
                    })}
                    style={[
                        styles.headerContainer,
                        {
                            borderBottomColor:
                                this.props.gamelist.showGameList === 2 || this.state.hoverWatchEffect ? 'black' : null,
                            borderBottomWidth: 2,
                            flex: 1,
                            marginHorizontal: 8,
                        },
                    ]}
                >
                    <S14Text style={[styles.headerText]}>Watch</S14Text>
                </TouchableOpacity>
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={this.onRobotGameClick}
                    onMouseEnter={bindFunction.bind({
                        bindRequest: this.onRobotHoverInOut,
                        params: true,
                    })}
                    onMouseLeave={bindFunction.bind({
                        bindRequest: this.onRobotHoverInOut,
                        params: false,
                    })}
                    style={[
                        styles.headerContainer,
                        {
                            borderBottomColor:
                                this.props.gamelist.showGameList === 3 || this.state.hoverRobotEffect ? 'black' : null,
                            borderBottomWidth: 2,
                            flex: 1,
                        },
                    ]}
                >
                    <S14Text style={[styles.headerText]}>Robots</S14Text>
                </TouchableOpacity>
            </View>
        );

    renderPlayersTab = () => (
        <View
            key={this.state.keyLeftSideLayout}
            style={
                DimensionUtils.isMobile()
                    ? {
                          flex: 1,
                          overflow: 'hidden',
                      }
                    : {
                          height: '100%',
                      }
            }
        >
            {this.renderPlayersHeader()}
            <OnlinePlayerListFlatList onObserveGame={this.onObserveGame} />
        </View>
    );

    onStartNewGameLayout = (event) => {
        let { height } = event.nativeEvent.layout;
        this.setState({ startNewGameHeight: height });
    };

    renderPlayersHeader = () => (
        <View style={[styles.button, styles.headerContainerNoPadding, styles.playerListHeader]}>
            <TileTouchableOpacity
                toggle={true}
                toggleState={'name' === this.props.user.playerListDataOn && this.props.user.playerListDataOrder === 'asc'}
                style={[styles.flexFour, styles.minHeightTwenty]}
                onPress={this.playerListOrderByName}
                ref={this.playerListOrderByNameButtonRef}
            >
                <S14Text style={[styles.boldFont]}>Player</S14Text>
                <View style={styles.headerSectionMinWidth}>{this.getSortOrderText('name')}</View>
            </TileTouchableOpacity>
            <View style={[styles.playerImageSmall]} />
            <TileTouchableOpacity
                toggle={true}
                toggleState={'rating' === this.props.user.playerListDataOn && this.props.user.playerListDataOrder === 'asc'}
                style={[styles.playerRatingText, styles.minHeightTwenty]}
                onPress={this.playerListOrderByRating}
                ref={this.playerListOrderByRatingButtonRef}
            >
                <S14Text style={[styles.boldFont]}>{LiveGamePlayUtils.isBlitzGame() ? 'Score' : 'Rating'}</S14Text>
                <View style={styles.headerSectionMinWidth}>{this.getSortOrderText('rating')}</View>
            </TileTouchableOpacity>
            <TileTouchableOpacity
                toggle={true}
                toggleState={'status' === this.props.user.playerListDataOn && this.props.user.playerListDataOrder === 'asc'}
                style={[styles.playerStatusTextHeader, styles.minHeightTwenty]}
                onPress={this.playerListOrderByStatus}
                ref={this.playerListOrderByStatusButtonRef}
            >
                <View style={[styles.flexRowReverse]}>
                    <View>
                        <S14Text style={{ opacity: 0 }}>Available</S14Text>
                        <View style={[StyleSheet.absoluteFill, { flexDirection: 'row' }]}>
                            <S14Text style={[styles.boldFont]}>Status</S14Text>
                            <View style={styles.headerSectionMinWidth}>{this.getSortOrderText('status')}</View>
                        </View>
                    </View>
                </View>
            </TileTouchableOpacity>
        </View>
    );

    getSortOrderText = (on) => {
        let playerListDataOn = this.props.user.playerListDataOn;
        let playerListDataOrder = this.props.user.playerListDataOrder;
        return on === playerListDataOn ? (
            <FontAwesomeIcon
                icon={playerListDataOrder === 'asc' ? faCaretUp : faCaretDown}
                size={14}
                style={{
                    ...this.getGeneralIconStyles(),
                }}
            />
        ) : null;
    };

    playerListOrderByName = () => {
        let currentNameOrder = this.playerListOrderByNameButtonRef.current.getToggledState() ? 'asc' : 'desc';
        this.sortAndUpdatePlayersList('name', currentNameOrder);
    };

    playerListOrderByRating = () => {
        let currentRatingOrder = this.playerListOrderByRatingButtonRef.current.getToggledState() ? 'asc' : 'desc';
        this.sortAndUpdatePlayersList('rating', currentRatingOrder);
    };

    playerListOrderByStatus = () => {
        let currentStatusOrder = this.playerListOrderByStatusButtonRef.current.getToggledState() ? 'asc' : 'desc';
        this.sortAndUpdatePlayersList('status', currentStatusOrder);
    };

    sortAndUpdatePlayersList = (on, order) => {
        eventBus.emit(GAME_LIVE_GAME_ONLINE_PLAYER_LIST_SORT_CRITERIA_CHANGED, null, {
            playerListDataOn: on,
            playerListDataOrder: order,
        });

        this.setState({ lastRendered: Date.now() });
    };

    renderHostInviteTabs = () =>
        LiveGamePlayUtils.isBlitzGame() ? null : (
            <View
                style={[
                    styles.columnDirection,
                    {
                        backgroundColor: DimensionUtils.isMobile()
                            ? ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR
                            : ColorConfig.OBSERVABLE_GAMES_LIST_BACKGROUND_COLOR,
                    },
                ]}
            >
                <View style={[styles.rowDirection, styles.paddingSixteen]}>
                    {this.renderButton('New Game', this.onHostGameClick, this.hostGameButtonRef)}
                </View>

                {this.state.isHostGameExpansionPanelOpen ? (
                    <HostInviteGameModal
                        key={'new_game_host'}
                        renderBodyOnly={true}
                        isForHosting={true}
                        onDoneInviting={this.hideCollapsible}
                        onCancel={this.onHostGameClick}
                        goToJoinGame={this.onJoinGameClick}
                    />
                ) : null}
            </View>
        );

    hideCollapsible = () => {
        this.setState({ isHostGameExpansionPanelOpen: false });
    };

    onHostGameClick = () => {
        this.setState({
            isHostGameExpansionPanelOpen: !this.state.isHostGameExpansionPanelOpen,
        });
    };
    onJoinGameClick = () => {
        this.setGameList(1);
        this.onBoxChecked(false);
    };

    onObserveGameClick = () => {
        this.setGameList(2);
    };

    onRobotGameClick = () => {
        this.setGameList(3);
        this.onBoxChecked(true);
    };
    onJoinHoverInOut = (status) => {
        this.setState({ hoverJoinEffect: status });
    };
    onWatchHoverInOut = (status) => {
        this.setState({ hoverWatchEffect: status });
    };
    onRobotHoverInOut = (status) => {
        this.setState({ hoverRobotEffect: status });
    };

    getRenderButtonStyle = () => ({
        maxWidth: '100%',
        maxHeight: '100%',
        minWidth: '100%',
        minHeight: '100%',
        color: ColorConfig.NEW_GAME_BUTTON_TEXT_COLOR,
        backgroundColor: ColorConfig.NEW_GAME_BUTTON_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        borderRadius: 5,
    });

    renderButton = (text, onPress, ref) => (
        <Pressable style={this.getRenderButtonStyle()} onPress={onPress} ref={ref}>
            <S16Text style={LayoutUtils.getBottonTextStyle()}>{text}</S16Text>
        </Pressable>
    );

    onBoxChecked = (value) => {
        eventBus.emit(GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET, null, value);
    };

    setGameList = (value) => {
        eventBus.emit(GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_GAME_LIST, null, value);
    };

    renderGamesList = () => (
        <View
            key={this.state.keyRightSideLayout}
            style={[styles.gameListContainer, styles.observeGameListBackgroundColor, styles.flex1]}
        >
            <View>
                {DimensionUtils.isMobile() || LiveGamePlayUtils.isBlitzGame() ? this.renderHeader('Join Game') : null}
                {!LiveGamePlayUtils.isBlitzGame() && (
                    <SimpleTouchableOpacity
                        hidden={!this.props.config.showRobotsToggle}
                        style={[StyleSheet.absoluteFill, styles.robotContainer]}
                    >
                        <CheckBoxWrapper
                            value={this.props.gamelist.normalGameOptionsModalShowRobots}
                            onValueChange={this.onBoxChecked}
                        />
                        <View style={[styles.inputLabelDivider]} />
                        <S14Text>Show Robots</S14Text>
                    </SimpleTouchableOpacity>
                )}
            </View>
            <JoinGameListFlatList
                renderPlayerAvatarNameRating={this.renderPlayerAvatarNameRating}
                renderRatedIndicator={this.renderRatedIndicator}
                renderDictionaryIndicator={this.renderDictionaryIndicator}
                renderTime={this.renderTime}
                onJoinGameWith={this.onJoinGameWith}
            />
        </View>
    );
    renderObservableGamesList = () =>
        LiveGamePlayUtils.isBlitzGame() ? null : (
            <View style={[styles.observeListContainer, styles.flex1]}>
                {DimensionUtils.isMobile() || LiveGamePlayUtils.isBlitzGame() ? this.renderHeader('Watch Games') : null}
                <WatchGameListFlatList onObserveGame={this.onObserveGame} />
                {this.state.showWatchGameOverlay ? <View style={[StyleSheet.absoluteFill, styles.watchGameOverlay]} /> : null}
            </View>
        );

    renderAvatar = ({ player, styleType } = {}) => {
        return (
            <AvatarImage
                style={[styles[styleType]]}
                show={get(player, 'avtar')}
                uri={this.props.config.avatar_url_format.formatUnicorn({
                    id: get(player, 'avtar'),
                })}
            />
        );
    };

    getCursor = (isPlaying, item) => ({
        cursor: isPlaying || GameBoardUtils.isMyself(item) ? 'default' : 'pointer',
    });

    renderGameListItem = ({ item, index }) => {
        if (item.gid) {
            return this.renderObserveGame(item, index);
        } else {
            return this.renderAcceptHostedGameRequest({ item, index });
        }
    };

    getGeneralIconStyles = () => ({
        fontSize: 14,
        margin: 2,
    });

    onMatchOrWatchPlayer = async (player) => {
        switch (player.status) {
            case 'avl': {
                await this.onSendInviteClick(player);
                break;
            }
            case 'ply': {
                let game = !!get(player, 'players')
                    ? player
                    : (this.props.gamelist.observableGamesList || []).find((game) =>
                          (get(game, 'players') || []).some(
                              (playerInGame) => player.guid === get(playerInGame, 'fullInfo.guid')
                          )
                      );
                game && (await this.onObserveGame(game));
                break;
            }
            default:
                throw new Error('Invalid status');
        }
    };

    onObserveGame = async (item) =>
        await startObservingQueue.promisifiedPush(async () => {
            if (!this.state.showWatchGameOverlay) {
                await this.setState({ showWatchGameOverlay: true });
                let res = await to(sendObserveGameRequest(item));
                if (res[0]) {
                    eventBus.emit(GAME_LIVE_OBSERVABLE_GAME_REMOVE, null, {
                        data: { gameid: item.gid },
                    });
                    createDialogInstance({
                        title: 'Game Over',
                        actionButtonText: 'OK',
                        onAction: getNull,
                        body: 'Unable to observe game as its over.',
                        isConfirmableByKey: true,
                    });
                } else {
                }
                await this.setState({ showWatchGameOverlay: false });
                return !res[0];
            }
        });

    onJoinGameWith = async (item) => {
        if (LiveGamePlayUtils.isBlitzGame()) {
            let res = await to(sendJoinGameRequest(item));
            if (!res[0] && res[1].extcode === '1000') {
                eventBus.emit(GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME, null, {
                    jndply: {
                        guid: this.props.game.guid,
                    },
                    gamereqid: get(item, 'gamereqid'),
                });
            }
        } else {
            this.setState({ showWatchGameOverlay: true });
            eventBus.emit(Config.ON_HOSTED_GAME_ITEM_SELECTED, null, item);
            this.setState({ showWatchGameOverlay: false });
        }
    };

    onSendInviteClick = async (item) => {
        eventBus.emit(Config.ON_HOSTED_GAME_ITEM_SELECTED, null, {
            uid: item,
            isInviting: true,
        });
    };

    /* onBtnClickHideOverlay = () =>
        this.state.dismissAfter ? this.hide() : this.hideGameOptionsOverlay();

    hideGameOptionsOverlay = () =>
        this.new_game_options_overlay.current.setVisibility({
            visible: false,
        }); */
}

const styles = StyleSheet.create({
    //Main Renders Styles
    mainContainer: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    bodyContainer: {
        flexDirection: 'column',
    },
    playerImageSmall: {
        height: 16,
        width: 16,
        marginRight: 5,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    playerNameText: {
        flex: 3,
        marginLeft: 10,
        justifyContent: 'center',
    },
    playerRatingText: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        textAlign: 'left',
    },
    minHeightTwenty: {
        minHeight: 20,
    },
    playerStatusTextHeader: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    playerStatusText: {
        textAlign: 'left',
    },
    transparent: {
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    rowDirection: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    button: {
        //width: 'calc(100% - 20)',
        overflow: 'hidden',
    },
    playerListHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    heightHundred: {
        height: '100%',
    },
    widthHundred: {
        width: '100%',
    },
    maxHeightHundred: {
        maxHeight: '100%',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    headerSectionMinWidth: { minWidth: 14, overflow: 'hidden' },
    leftSideContainer: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.PLAYER_LIST_BACKGROUND_COLOR,
        borderRadius: 5,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        overflow: 'hidden',
    },
    containerDivider: {
        width: Config.RIGHT_LEFT_MARGIN,
        height: Config.RIGHT_LEFT_MARGIN,
    },
    columnDirection: {
        flexDirection: 'column',
        padding: 0,
        margin: 0,
    },
    headerContainer: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        padding: Config.HEADER_CONTAINER_PADDING,
        alignItems: 'center',
        justifyContent: 'center',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    headerContainerNoPadding: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 10,
        borderBottomWidth: StyleSheet.hairlineWidth,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    headerText: {
        fontWeight: 'bold',
        color: ColorConfig.GAME_OPTIONS_TEXT_COLOR,
    },
    paddingFive: {
        padding: 5,
    },
    paddingSixteen: {
        padding: Config.RIGHT_LEFT_MARGIN,
        height: 3.5 * Config.RIGHT_LEFT_MARGIN + 2 * Config.RIGHT_LEFT_MARGIN,
        borderWidth: 0,
        borderColor: 'rgba(0,0,0,0)',
    },
    rightSideContainer: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        borderTopRightRadius: 5,
        borderTopLeftRadius: 5,
        borderBottomRightRadius: 5,
        borderBottomLeftRadius: 5,
        overflow: 'hidden',
    },
    gameListContainer: {
        overflow: 'hidden',
        flexBasis: '0%',
    },
    inputLabelDivider: {
        height: 0,
        width: 5,
    },
    observeListContainer: {
        overflow: 'hidden',
        flexBasis: '0%',
    },
    observeGameListBackgroundColor: {
        backgroundColor: ColorConfig.OBSERVABLE_GAMES_LIST_BACKGROUND_COLOR,
    },
    observeGame: {
        flexDirection: 'row',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    hairlineBorderWidth: {
        borderWidth: StyleSheet.hairlineWidth,
    },
    flexFour: {
        width: '50%',
        flexDirection: 'row',
        alignItems: 'center',
    },
    tileContainer: {
        width: '100%',
        flexDirection: 'row',
        overflow: 'hidden',
        paddingLeft: 5,
        paddingRight: 5,
        paddingTop: 5,
    },
    flexRowReverse: {
        flex: 1,
        flexDirection: 'row-reverse',
    },
    robotContainer: {
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row',
        padding: 5,
    },
    watchGameOverlay: {
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        overflow: 'hidden',
    },
    directionRow: {
        flexDirection: 'row',
    },
    overlayContainer: {
        height: '100%',
        width: '100%',
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
    },
    failureDetailLayout: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    btn: {
        marginTop: 5,
        padding: 5,
        borderRadius: 3,
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
    },
    btnTextStyle: {
        color: '#000',
    },
    flex1: {
        flex: 1,
    },
    menuJoinWatch: {
        display: 'flex',
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
});

const mapStateToProps = (state) => ({
    user: state.user,
    config: state.config,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
    gamelist: state.gamelist,
    game: state.game, //{ gameRestartData: get(state, 'game.gameRestartData') },
});

export default connect(mapStateToProps, null, null, { forwardRef: true })(NormalGameOptionsModal);
