import get from 'lodash/get';
import set from 'lodash/set';
import cloneDeep from 'lodash/cloneDeep';
import Config from '../configs/Config';
import { setSettings } from '../service/GamePlayService';
import { CONFIG_SET_SETTING } from '../configs/ActionIdentifiers';
import store from '../store';
import debounce from 'lodash/debounce';

const eventBus = require('js-event-bus')();
export default class SettingsUtil {
    static get = (key, useFallback = true, globalState = store.getState()) => {
        let settings = cloneDeep(get(globalState, 'config'));
        let val = get(settings, key);
        if (!useFallback || (val !== undefined && val !== null)) {
            return val;
        }
        return get(Config.LIVE_DEFAULT_SETTINGS, key);
    };

    static set = (key, value, globalState = store.getState()) => {
        let settings = cloneDeep(get(globalState, 'config'));
        set(settings, key, value);
        eventBus.emit(CONFIG_SET_SETTING, null, settings);
        SettingsUtil.sendSetting({ [key]: value });
    };

    static applySettings = (settings = {}) => {
        let applySafely = (searchKey, configKey) => {
            settings[configKey] = settings[searchKey];
        };
        applySafely('us_gameplay.gp_autozoomboard', 'autozoom');
        applySafely('us_gameplay.gp_numbrdboard', 'numbered_plain');
        applySafely('us_gameplay.gp_magictiles', 'tap_to_play');
        applySafely('us_gameplay.gp_gamesounds', 'sounds_enabled');
        applySafely('us_gameplay.gp_scoregraph', 'scoregraph_enabled');
        applySafely('us_gameplay.gp_gametheme', 'theme');
        applySafely('us_gameplay.gp_moveconfirmation', 'move_confirmation');
        eventBus.emit(CONFIG_SET_SETTING, null, settings);
    };

    static sendSetting = async (obj = {}) => {
        if (obj) {
            let remappedObject = {};
            let isChatFontSize = false;
            let remapFunction = (oldKey, newKey) => {
                let value = get(obj, oldKey);
                set(
                    remappedObject,
                    newKey,
                    value === true ? 'y' : value === false ? 'n' : isNaN(value) ? value : String(value)
                );
            };
            (Object.keys(obj || {}) || []).forEach((key) => {
                switch (key) {
                    case 'autozoom':
                        return remapFunction('autozoom', 'us_gameplay.gp_autozoomboard');
                    case 'numbered_plain':
                        return remapFunction('numbered_plain', 'us_gameplay.gp_numbrdboard');
                    case 'tap_to_play':
                        return remapFunction('tap_to_play', 'us_gameplay.gp_magictiles');
                    case 'sounds_enabled':
                        return remapFunction('sounds_enabled', 'us_gameplay.gp_gamesounds');
                    case 'scoregraph_enabled':
                        return remapFunction('scoregraph_enabled', 'us_gameplay.gp_scoregraph');
                    case 'dictionary':
                        return remapFunction('dictionary', 'us_gamestart.gs_prefdic');
                    case 'ratingrange':
                        return remapFunction('ratingrange', 'us_gamestart.gs_ratingrange');
                    case 'players':
                        return remapFunction('players', 'us_gamestart.gs_numplayers');
                    case 'gametype':
                        return remapFunction('gametype', 'us_gamestart.gs_rated');
                    case 'challengeregular':
                        return remapFunction('challengeregular', 'us_gamestart.gs_gametype');
                    case 'time':
                        return remapFunction('time', 'us_gamestart.gs_lvduration');
                    case 'increment':
                        return remapFunction('increment', 'us_gamestart.gs_lvincrmnt');
                    case 'theme':
                        return remapFunction('theme', 'us_gameplay.gp_gametheme');
                    case 'tooltip_enabled':
                        return remapFunction('tooltip_enabled', 'us_gameplay.gp_showtooltip');
                    case 'move_confirmation':
                        return remapFunction('move_confirmation', 'us_gameplay.gp_moveconfirmation');
                    case 'gp_chtfntsze':
                        isChatFontSize = true;
                        return remapFunction('gp_chtfntsze', 'us_gameplay.gp_chtfntsze');
                    case 'lobby_game_update':
                        return remapFunction('lobby_game_update', 'us_privacy.pvc_showlbygmupdt');
                    case 'show_lobby_chat':
                        return remapFunction('show_lobby_chat', 'us_privacy.pvc_showlbycht');
                    case 'gp_brdcntrimg':
                        return remapFunction('gp_brdcntrimg', 'us_gameplay.gp_brdcntrimg');
                    default:
                        return remapFunction(key, key);
                }
            });

            if (isChatFontSize) SettingsUtil.debounceChatFontSizeSend(remappedObject);
            else await setSettings(remappedObject);
        }
    };

    static debounceChatFontSizeSend = debounce((remappedObject) => {
        setSettings(remappedObject);
    }, 1000);

    static getRatingRange = () => SettingsUtil.get('us_gamestart.gs_ratingrange').split('-');

    static getMinRatingRange = () => SettingsUtil.getRatingRange()[0];

    static getMaxRatingRange = () => SettingsUtil.getRatingRange()[1];

    static setMinRatingRange = (min) => {
        let ratingParts = SettingsUtil.getRatingRange();
        ratingParts[0] = String(min);
        SettingsUtil.setRatingRangeAndSend(ratingParts);
    };

    static setMaxRatingRange = (max) => {
        let ratingParts = SettingsUtil.getRatingRange();
        ratingParts[1] = String(max);
        SettingsUtil.setRatingRangeAndSend(ratingParts);
    };

    static setRatingRangeAndSend = (ratingParts) => {
        let gs_ratingrange = ratingParts.join('-');
        SettingsUtil.set('us_gamestart.gs_ratingrange', gs_ratingrange);
    };

    static emitPromise = async () => {
        eventBus.emit(Config.MENU_OPTION_TOGGLED);
        return true;
    };
}
