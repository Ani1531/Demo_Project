const { app, BrowserWindow, ipcMain, shell, Notification, screen, Menu } = require('electron');
const path = require('path');
const url = require('url');
const { channels } = require('../src/shared/constants');
const Store = require('electron-store');
const generateMenuTemplate = require('./menu_template');
const store = new Store();
const STORE_KEY_WIDTH = 'STORE_KEY_WIDTH';
const STORE_KEY_HEIGHT = 'STORE_KEY_HEIGHT';
const CHAT_SCAM_ALERT = 'CHAT_SCAM_ALERT';
const LOBBY_CHAT_SCAM_ALERT = 'LOBBY_CHAT_SCAM_ALERT';
let mainWindow;
let notificationCount = 0;
let wResizedId;

function createWindow() {
    const { width, height } = screen.getPrimaryDisplay().workAreaSize;
    let mwWidth = store.get(STORE_KEY_WIDTH) || width * 0.6;
    let mwHeight = store.get(STORE_KEY_HEIGHT) || height;
    const startUrl =
        process.env.ELECTRON_START_URL ||
        url.format({
            pathname: path.join(__dirname, process.env.APP_DEV ? '../build/index.html' : '../index.html'),
            protocol: 'file:',
            slashes: true,
        });
    mainWindow = new BrowserWindow({
        title: 'Lexulous Word Game',
        width: mwWidth,
        height: mwHeight,
        minWidth: 460,
        minHeight: 740,
        webPreferences: {
            contextIsolation: false,
            webSecurity: false,
            preload: path.join(__dirname, 'preload.js'),
        },
        show: false,
    });
    let splashWindow = new BrowserWindow({
        width: mwWidth,
        height: mwHeight,
        transparent: true,
        frame: false,
        alwaysOnTop: true,
    });
    splashWindow.loadURL(path.join(__dirname, '../electron/splash.html'));
    mainWindow.loadURL(startUrl);
    mainWindow.once('ready-to-show', () => {
        splashWindow.destroy();
        mainWindow.show();
    });
    mainWindow.on('focus', () => {
        resetBadgeIcon();
    });
    mainWindow.on('page-title-updated', function (event, title, explicitSet) {
        event.preventDefault();
    });
    mainWindow.on('closed', function () {
        mainWindow = null;
    });
    mainWindow.webContents.on('new-window', (event, url) => {
        event.preventDefault();
        shell.openExternal(url);
    });
    mainWindow.on('resize', function () {
        clearTimeout(wResizedId);
        wResizedId = setTimeout(resizedWindow, 500);
    });
}

function resizedWindow() {
    let size = mainWindow.getSize();
    let width = size[0];
    let height = size[1];
    store.set(STORE_KEY_WIDTH, width);
    store.set(STORE_KEY_HEIGHT, height);
}

function showNotification(data) {
    if (data != null && data != undefined) {
        mainWindow.webContents.executeJavaScript("window.localStorage.getItem('XYyUDcmN');").then((status) => {
            if (status != 'denied') {
                let title = data.title;
                let body = data.message;
                //if (!mainWindow.isFocused()) {
                setBadgeIcon();
                new Notification({ title, body }).show();
                //}
            }
        });
    } else {
        //trigger a notification permission
        new Notification();
    }
}

function setBadgeIcon() {
    notificationCount++;
    app.setBadgeCount(notificationCount);
}
function resetBadgeIcon() {
    notificationCount = 0;
    app.setBadgeCount(notificationCount);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', function () {
    if (mainWindow === null) {
        createWindow();
    }
});

// Data send to renderer
ipcMain.on(channels.APP_INFO, (event, data) => {
    switch (data.action) {
        case channels.ACTION_CHAT_SCAM_ALERT:
            if (data.returnRes) {
                event.sender.send(channels.APP_INFO, {
                    chatScamAlert: store.get(CHAT_SCAM_ALERT),
                });
            } else {
                store.set(CHAT_SCAM_ALERT, true);
            }
            break;
        case channels.ACTION_LOBBY_CHAT_SCAM_ALERT:
            if (data.returnRes) {
                event.sender.send(channels.APP_INFO, {
                    lobbyChatScamAlert: store.get(LOBBY_CHAT_SCAM_ALERT),
                });
            } else {
                store.set(LOBBY_CHAT_SCAM_ALERT, true);
            }
            break;
    }
});

// Data receive from renderer
ipcMain.on(channels.NOTIFICATION_INFO, (event, data) => {
    showNotification(data);
});

//creating menu template
const cust_menu_template = generateMenuTemplate(app);
const menu = Menu.buildFromTemplate(cust_menu_template);
Menu.setApplicationMenu(menu);
