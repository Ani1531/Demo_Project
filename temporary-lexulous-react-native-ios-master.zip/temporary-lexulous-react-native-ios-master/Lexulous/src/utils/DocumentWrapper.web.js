import ConfigurationWrapper from './ConfigurationWrapper';

export default class DocumentWrapper {
    static setDocumentTitle = (title) => (document.title = title);

    static getContainer = () =>
        document.getElementById &&
        document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        );

    static getContainerWidth = () =>
        document.getElementById &&
        document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        ).offsetWidth;

    static getContainerHeight = () =>
        document.getElementById &&
        document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        ).offsetHeight;

    static setContainerHeight = (height) =>
        (document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        ).style.height = height);

    static getScreenWidth = () => document.documentElement.clientWidth;

    static getScreenHeight = () => document.documentElement.clientHeight;

    static getBodyWidth = () => document.body.clientWidth;

    static hasContainerElement = () =>
        !!document.getElementById &&
        document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        );

    static getContainerOffsetWidth = () =>
        document.getElementById(
            ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                'container_name'
            )
        ).offsetWidth;

    static isPageVisible = () => document.visibilityState === 'visible';
}
