import React from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import ColorConfig, {
    StandardButtonMouseHoverEffect,
} from '../configs/ColorConfig';
import Config from '../configs/Config';
import TwoLetterWordsPassages from './TwoLetterWordsPassages';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCheck, faTimes } from '@fortawesome/free-solid-svg-icons';
import { getWordValidity, isPuzzleGame } from '../service/GamePlayService';
import { getEventKeyCode } from '../utils/Utils';
import debounce from 'lodash/debounce';
import { getNull } from '../../src/utils/Utils';
import StandardButton from './StandardButton';
import { spawnWindow } from '../utils/UrlUtils';
import { connect } from 'react-redux';
import {
    CELL_REDUCER_CLEAR_DIRECTION,
    GAME_RESOURCE_PANEL_WORD_VALIDITY,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import DimensionUtils from '../utils/DimensionUtils';
const eventBus = require('js-event-bus')();

const getStringRemovingSpecialCharacter = (data) =>
    data && data.replace(/[^a-zA-Z]/gi, '');

class ResourcesPanel extends React.Component {
    state = {
        searchWord: undefined,
        message: undefined,
        dictionaryWordSubmitByEnter: false,
    };

    onTextInputBlur = getNull;

    constructor(props) {
        super(props);
        this.dictionary_field_ref = React.createRef();
    }

    getPanelBodyPadding = () =>
        this.props.layout.layoutSidePanelTitleBarPadding;

    componentDidMount = () => {
        if (
            get(this.props, 'game.tabWasSetByClicking') &&
            get(this.props, 'game.gameBoardSideLayoutActiveTab') === 1
        ) {
            this.clearDictionaryWordAndReturnFocus();
        }
    };

    searchWordInDictionary = async (setBackFocus = false) => {
        let word = getStringRemovingSpecialCharacter(this.state.searchWord);
        if (word) {
            await getWordValidity({
                word: [word],
                doEmit: true,
                actionToEmit: GAME_RESOURCE_PANEL_WORD_VALIDITY,
            });
            if (setBackFocus === true)
                this.dictionary_field_ref.current.focus();
        } else eventBus.emit(GAME_RESOURCE_PANEL_WORD_VALIDITY);
    };

    delayedSearch = debounce(() => {
        this.searchWordInDictionary(true);
    }, 500);

    displayDictionaryData = (data) => {
        this.setState({
            validity:
                !(
                    data.err === null &&
                    data.err === undefined &&
                    data.error === null &&
                    data.error === undefined
                ) &&
                (Number(data.err) === 0 || Number(data.error) === 0),
            message: data.result,
        });
    };

    getDictionaryPanelBottomCornerStyle = () => ({
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    });

    getPanelButtonContainerStyles = () => ({
        marginLeft: 8,
        height:
            Object.keys(this.props.layout).length != 0
                ? this.props.layout.layoutButtonStyles.height
                : Config.DICTIONARY_TAB_PANEL_BUTTON_CONTAINER_FIXED_HEIGHT,
        alignSelf: 'center',
        paddingHorizontal: Math.round(Config.RIGHT_LEFT_MARGIN / 2),
    });

    getPanelButtonColorStyles = () => ({
        backgroundColor: this.props.game.resourcePanelWordValid
            ? DimensionUtils.isNative()
                ? ColorConfig.NATIVE_BUTTON_BACKGROUND_BLUE_COLOR
                : ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR
            : ColorConfig.PLAY_BUTTON_BACKGROUND_COLOR_DISABLED,
    });

    getValidationIconAlignStyle = () => ({
        alignSelf: 'center',
        marginLeft: 2,
    });

    getValidationContainerStyles = () => ({
        marginRight: 8,
        flexDirection: 'row',
    });

    getPanelTitleBarPaddingObj = () => ({
        padding: this.props.layout.layoutSidePanelTitleBarPadding,
    });

    getPanelFontSizeObj = () => ({
        fontSize: this.props.layout.layoutSidePanelFontSize,
    });

    getPanelBodyPaddingObj = () => ({
        padding: this.getPanelBodyPadding(),
    });

    getTextInputStyles = () => ({
        position: 'absolute',
        width: '100%',
        height: 32,
        backgroundColor: '#FFF',
        borderRadius: 5,
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderColor:
            this.props.game.resourcePanelWordValid === undefined
                ? ColorConfig.SIDE_PANEL_BORDER_COLOR
                : this.props.game.resourcePanelWordValid
                ? ColorConfig.DICTIONARY_VALID_TEXT_COLOR
                : ColorConfig.DICTIONARY_INVALID_TEXT_COLOR,
    });

    goToResourcesPage = () =>
        this.props.game.resources_page_url &&
        spawnWindow(this.props.game.resources_page_url);

    onSearchBarTextChange = (searchWord) => {
        this.setState({ searchWord });
        this.delayedSearch();
    };

    getBorder = () =>
        DimensionUtils.isNative()
            ? null
            : {
                  borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
                  borderLeftWidth: Config.SIDE_PANEL_BORDER_WIDTH,
                  borderRightWidth: Config.SIDE_PANEL_BORDER_WIDTH,
                  borderLeftColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
                  borderRightColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
                  borderBottomColor: ColorConfig.CHAT_BOX_BORDER_COLOR,
              };

    getBottomBorder = () =>
        DimensionUtils.isNative()
            ? null
            : {
                  borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
                  borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
              };

    render = () => (
        <View
            style={[
                styles.container,
                styles.w100,
                this.getBorder(),
                isPuzzleGame() ? styles.additionalStylesForPuzzleMode : null,
            ]}
        >
            {/* ResourcesPanel Word Validate Section */}
            <View style={[styles.dictionaryInput, this.getBottomBorder()]}>
                <View
                    style={[
                        styles.flex3,
                        {
                            alignItems: 'flex-end',
                            justifyContent: 'center',
                        },
                    ]}
                >
                    <TextInput
                        placeholder={'Type a word here'}
                        style={[
                            this.getPanelFontSizeObj(),
                            this.getPanelBodyPaddingObj(),
                            this.getTextInputStyles(),
                        ]}
                        onChangeText={this.onSearchBarTextChange}
                        onFocus={this.onTextInputFocussed}
                        onKeyPress={this.onDictionaryKeyPressHandle}
                        ref={this.dictionary_field_ref}
                        autoComplete={'off'}
                        autoCompleteType={'off'}
                    />
                    {this.props.game.resourcePanelWordValid ===
                    undefined ? null : (
                        <View style={this.getValidationContainerStyles()}>
                            <Text
                                style={{
                                    ...this.getValidationIconStyles(),
                                    ...this.getPanelFontSizeObj(),
                                }}
                            >
                                is{' '}
                                {this.props.game.resourcePanelWordValid
                                    ? 'valid '
                                    : 'not valid '}
                            </Text>
                            <FontAwesomeIcon
                                icon={
                                    this.props.game.resourcePanelWordValid
                                        ? faCheck
                                        : faTimes
                                }
                                size={this.getPanelFontSizeObj().fontSize}
                                style={{
                                    ...this.getValidationIconStyles(),
                                    ...this.getPanelFontSizeObj(),
                                    ...this.getValidationIconAlignStyle(),
                                }}
                            />
                        </View>
                    )}
                </View>
                <StandardButton
                    style={[
                        styles.button,
                        this.getPanelButtonColorStyles(),
                        styles.center,
                        this.getPanelButtonContainerStyles(),
                    ]}
                    onPress={
                        this.props.game.resourcePanelWordValid
                            ? this.searchWordInEncyclopediaAPI
                            : getNull
                    }
                    text="Define"
                    textStyle={[styles.buttonText, this.getPanelFontSizeObj()]}
                    mouseHoverEffect={
                        this.props.game.resourcePanelWordValid
                            ? StandardButtonMouseHoverEffect
                            : { hoverBackgroundColor: '#313131' }
                    }
                />
            </View>
            {/* Dictionary Section */}
            <TwoLetterWordsPassages />
        </View>
    );

    getValidationIconStyles = () => ({
        color: this.props.game.resourcePanelWordValid
            ? ColorConfig.DICTIONARY_VALID_TEXT_COLOR
            : ColorConfig.DICTIONARY_INVALID_TEXT_COLOR,
    });

    getPassageContainerStyles = () => ({
        paddingLeft: this.getPanelBodyPadding(),
        paddingRight: this.getPanelBodyPadding(),
    });

    onDictionaryChangeText = (searchWord) => this.setState({ searchWord });

    onTextInputFocussed = () => {
        eventBus.emit(Config.TEXT_INPUT_FOCUSSED);
        eventBus.emit(CELL_REDUCER_CLEAR_DIRECTION);
    };

    onDictionaryKeyPressHandle = (event) => {
        event.stopPropagation();
        let code = getEventKeyCode(event);
        if (code.includes('Escape')) {
            event.preventDefault();
        } else if (code.includes('Enter')) {
            this.searchWordInDictionary(true);
            this.dictionary_field_ref.current.focus();
        }
    };

    getDictionaryWordSubmitByEnterState = () => {
        let retState = this.state.dictionaryWordSubmitByEnter;
        this.setState({ dictionaryWordSubmitByEnter: false });
        return retState;
    };

    getDictionaryWordSubmitByEscapeState = () => {
        let retState = this.state.dictionaryWordSubmitByEscape;
        this.setState({ dictionaryWordSubmitByEscape: false });
        return retState;
    };

    clearDictionaryWordAndReturnFocus = () => {
        this.dictionary_field_ref.current.clear();
        this.dictionary_field_ref.current.focus();
    };

    onLanguageSet = () => this.setState({ lastRendered: Date.now() });

    searchWordInEncyclopediaAPI = () => {
        let word = getStringRemovingSpecialCharacter(this.state.searchWord);
        if (word) {
            if (DimensionUtils.isNative()) {
                this.props.getWordDefination(word);
                this.clearDictionaryWordAndReturnFocus();
                eventBus.emit(GAME_RESOURCE_PANEL_WORD_VALIDITY);
            } else {
                spawnWindow(this.props.config.encyclopedia_url + word);
                //this.setState({searchWord: ""});}
            }
        }
    };
}

const styles = StyleSheet.create({
    flex3: { flex: 3 },
    flex1: { flex: 1 },
    textInput: {
        borderWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        backgroundColor: '#FFF',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    buttonText: {
        color: '#FFF',
        alignSelf: 'center',
    },
    button: {
        alignContent: 'center',
        justifyContent: 'center',
        borderRadius: 5,
    },
    plusButtonStyle: {
        paddingHorizontal: 10,
        marginRight: 5,
        marginVertical: 2,
    },
    center: {
        alignContent: 'center',
        justifyContent: 'center',
    },
    dictionaryInput: {
        width: '100%',
        flexDirection: 'row',
        padding: 8,
    },
    resourceContainer: {
        alignItems: 'center',
        flexDirection: 'column',
    },
    heading: {
        color: ColorConfig.SIDE_PANEL_HEADING_TEXT_COLOR,
        fontWeight: 'bold',
    },
    headingContainer: {
        borderBottomWidth: Config.SIDE_PANEL_BORDER_WIDTH,
        borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
    },
    headingOverlayContainer: {
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
    },
    w100: {
        width: '100%',
    },
    additionalStylesForPuzzleMode: {
        borderLeftWidth: 0,
        borderRightWidth: 0,
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
    game: state.game,
    config: state.config,
});

export default connect(mapStateToProps)(ResourcesPanel);
