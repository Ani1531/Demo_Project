// @flow

import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class RewardedAdNF {
    retryAttempt = 0;
    onCompletion: (boolean) => void = (shown: boolean) => {};
    constructor() {}
    onAppInit = (): void => {};

    showRewardedNFInterstitialAd = (onCompletion: (boolean) => void): void => {
        this.onCompletion = onCompletion;
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            this.onAdCompletion(false);
            return;
        }
        this.onAdCompletion(true);
    };

    canShowRewardedNFInterstitial = () => {};

    onAdCompletion = (shown: boolean) => {
        let temp = this.onCompletion;
        this.onCompletion = (shown: boolean) => {};
        if (temp) {
            temp(shown);
        }
    };
}

const rewardedAdNF: RewardedAdNF = new RewardedAdNF();

export default rewardedAdNF;
