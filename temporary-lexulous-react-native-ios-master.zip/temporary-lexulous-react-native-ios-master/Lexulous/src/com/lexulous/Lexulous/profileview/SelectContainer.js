//@flow
import React from 'react';
import { Platform } from 'react-native';
import SelectDropdown from 'react-native-select-dropdown';
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import type { SelectContainerProps } from '../commons/RJTypes';
import themeConfigutation from '../commons/ThemeConfiguration';

type SelectContainerState = {
    selectValue: string,
};
export default class SelectContainer extends React.Component<SelectContainerProps, SelectContainerState> {
    constructor(props: SelectContainerProps) {
        super(props);
        this.state = {
            selectValue: this.props.defaultButtonText,
        };
    }
    getIcon = () => {
        return <FontAwesomeIcon icon={faCaretDown} size={20} color={themeConfigutation.getColor('#000')} />;
    };
    getValue = (selectedItem: string) => {
        if (this.props.defaultButtonText !== selectedItem) {
            let key = this.props.tag;
            let updated_setting_val: string = selectedItem;
            this.setState({ selectValue: updated_setting_val });
            this.props.onValueSelect(key, updated_setting_val);
        }
    };

    renderTextDropdown = () => {
        return (
            <SelectDropdown
                buttonStyle={this.props.drillDown_pickerStyle}
                dropdownIconPosition={'right'}
                dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                renderDropdownIcon={this.getIcon}
                data={this.props.selectItem}
                defaultButtonText={this.props.defaultButtonText}
                onSelect={(selectedItem: string) => this.getValue(selectedItem)}
                rowStyle={{
                    backgroundColor: themeConfigutation.getColor('#fff'),
                    ...Platform.select({
                        native: {},
                        default: { paddingVertical: 14 },
                    }),
                }}
                rowTextStyle={{ color: themeConfigutation.getColor('#000') }}
                buttonTextStyle={{ color: themeConfigutation.getColor('#000') }}
            />
        );
    };

    render() {
        if (this.props.renderType === 'text') {
            return this.renderTextDropdown();
        } else {
            return null;
        }
    }
}
