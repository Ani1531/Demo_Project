import React from 'react';
import { Animated, PanResponder, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import Tile from './Tile';
import Cell from './Cell';
import GameBoardUtils from '../utils/GameBoardUtils';
import get from 'lodash/get';
import debounce from 'lodash/debounce';
import cloneDeep from 'lodash/cloneDeep';
import isEqual from 'lodash/isEqual';
//import '../css/tile.css';
import Config from '../configs/Config';
import LongPress from 'react-long';
import ColorConfig from '../configs/ColorConfig';
import DimensionUtils from '../utils/DimensionUtils';
import AnimatedValueWrapped from '../utils/AnimatedValueWrapped';
import EventWrapper from '../utils/EventWrapper';
import StandardButton from './StandardButton';
import { createDialogInstance } from '../utils/MessageUtils';
import { getRandomBoard, getCustomSavedBoard } from '../service/LiveGamePlayService';
import { connect } from 'react-redux';
import {
    CELL_REDUCER_HIDE_TILE,
    CELL_REDUCER_SET_TILE,
    GAME_SOLO_GET_RANDOM_BOARD,
    GAME_SOLO_RESET_CREATE_BOARD,
    GAME_SOLO_SET_BOARD_DISABLE,
    GAME_SOLO_CREATE_GAME_DATA,
    CELL_REDUCER_EMPTY_GAMEBOARD,
    REDUCER_UPDATE_MOUSE_MOVE_TILE,
} from '../configs/ActionIdentifiers';
import once from 'lodash/once';
import constant from 'lodash/constant';
import times from 'lodash/times';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import DocumentWrapper from '../utils/DocumentWrapper';
import S14Text from './S14Text';

const eventBus = require('js-event-bus')();

const SidePanelView = {
    PlaceBoardTile: 1,
    TileDistribute: 2,
    TileValue: 3,
    GameStart: 4,
};

function bindFunction() {
    this.bindRequest(this.params);
}

class CustomBoard extends React.Component {
    constructor(props) {
        super(props);
        this.pan = new Animated.ValueXY({ x: 0, y: 0 });
        this.scale = new Animated.Value(1);
        let container = {
            top: this.props.top,
            left: this.props.left,
            height: this.props.height,
            width: this.props.width,
        };
        this.state = {
            sidePanelView: SidePanelView.PlaceBoardTile,
            boardAdditionalLeftDimension: 0,
            boardAdditionalTopDimension: 0,
            boardSize: get(this.props, 'game.board_size'),
            ...container,
        };

        let panMoveEvent = Animated.event(
            [
                null,
                {
                    dx: this.pan.x,
                    dy: this.pan.y,
                },
            ],
            {
                useNativeDriver: true,
            }
        );
        this._panResponder = PanResponder.create({
            onMoveShouldSetPanResponder: (e, gesture) => {
                let isClickingDroppedTile = false;
                if (e.nativeEvent.touches && e.nativeEvent.touches.length === 1) {
                    let droppedTiles = this.getTiles({
                        caller: 'onMoveShouldSetPanResponder',
                    }).filter((tile) => !!tile.position);
                    if (droppedTiles) isClickingDroppedTile = !!get(this.props, 'tiles.tileBeingDragged');
                }
                return (
                    (!isClickingDroppedTile && this.scale._value > 1) ||
                    (e.nativeEvent.touches && e.nativeEvent.touches.length === 2)
                );
            },
            onPanResponderGrant: (e, gesture) => {
                this.pan.setOffset({
                    x: this.pan.x._value,
                    y: this.pan.y._value,
                });
                this.pan.setValue({ x: 0, y: 0 });
                if (e.nativeEvent.touches.length === 2) {
                    this.startHypot = Math.hypot(
                        e.nativeEvent.touches[0].pageX - e.nativeEvent.touches[1].pageX,
                        e.nativeEvent.touches[0].pageY - e.nativeEvent.touches[1].pageY
                    );

                    let x =
                        this.props.layout.layoutBoardWidth / 2 -
                        (e.nativeEvent.touches[0].pageX + e.nativeEvent.touches[1].pageX) / 2;
                    let y =
                        this.props.layout.layoutBoardWidth / 2 -
                        (e.nativeEvent.touches[0].pageY + e.nativeEvent.touches[1].pageY) / 2;
                    this.zoomInPoint = {
                        x,
                        y,
                    };
                }
            },
            onPanResponderMove: (e, gesture) => {
                if (e.nativeEvent.touches.length === 2) {
                    this.endHypot = Math.hypot(
                        e.nativeEvent.touches[0].pageX - e.nativeEvent.touches[1].pageX,
                        e.nativeEvent.touches[0].pageY - e.nativeEvent.touches[1].pageY
                    );
                } else if (e.nativeEvent.touches.length === 1 && !this.startHypot) panMoveEvent(e, gesture);
            },
            onPanResponderRelease: (e, gestures) => {
                this.pan.flattenOffset();
                if (ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isMobile') && this.scale._value > 1) {
                    this.adjustXPan();
                    this.adjustYPan();
                }
                if (!isNaN(this.startHypot) && !isNaN(this.endHypot)) {
                    if (this.startHypot > this.endHypot) {
                        this.zoomOut();
                    } else if (this.endHypot > this.startHypot) {
                        if (this.zoomInPoint.x > this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.x = this.props.layout.layoutBoardWidth / 2;
                        } else if (this.zoomInPoint.x < 0 - this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.x = 0 - this.props.layout.layoutBoardWidth / 2;
                        }
                        if (this.zoomInPoint.y > this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.y = this.props.layout.layoutBoardWidth / 2;
                        } else if (this.zoomInPoint.y < 0 - this.props.layout.layoutBoardWidth / 2) {
                            this.zoomInPoint.y = 0 - this.props.layout.layoutBoardWidth / 2;
                        }
                        this.scaleAndPanTo(2.0, this.zoomInPoint.x, this.zoomInPoint.y);
                    }
                }
                this.startHypot = undefined;
                this.endHypot = undefined;
                this.zoomInPoint = undefined;
                this.repositionAllTiles();
            },
        });
    }

    componentDidMount = () => {
        this.resetBoardData();
        eventBus.on(Config.CUSTOM_BOARD_NEXT_OPTION, this.getBoardNextOption);
    };

    componentWillUnmount() {
        eventBus.detach(Config.CUSTOM_BOARD_NEXT_OPTION, this.getBoardNextOption);
    }

    setRandomBoard = () => {
        if (this.props.boarddes) {
            this.emptyGameBoard();

            let tilesPositionsObjs = [];
            let alreadyPickedTiles = [];
            this.props.bdsqvalSlot.split('|').forEach((val) => {
                let valInfoArr = val.split(',');
                if (valInfoArr[0] !== 'W') {
                    for (let i = 0; i < this.props.boarddes.length; i++) {
                        if (this.props.boarddes[i] === valInfoArr[0]) {
                            let x = i % get(this.props, 'game.board_size');
                            let y = Math.floor(i / get(this.props, 'game.board_size'));

                            let tile = this.placeLetter({
                                letterPressed: valInfoArr[1],
                                alreadyPickedTiles,
                            });
                            if (tile) {
                                tilesPositionsObjs.push({
                                    tile,
                                    positionX: Number(x),
                                    positionY: Number(y),
                                });
                            }
                        }
                    }
                }
            });
            this.setTiles(tilesPositionsObjs);
            eventBus.emit(GAME_SOLO_RESET_CREATE_BOARD);
        }
    };

    placeLetter = ({ letterPressed, fromKeyUp, position, forHintWord, alreadyPickedTiles } = {}) => {
        let unplacedTile = GameBoardUtils.tileCreation(letterPressed);
        if (unplacedTile) {
            return unplacedTile;
        }
    };

    getTiles = ({ includeEmptySpace = false, forRendering = false, caller } = {}) => {
        let currentRackArr = cloneDeep(get(this.props, 'tiles.rackArr')) || [];
        let nonNullTiles = currentRackArr.filter(Boolean);
        if (includeEmptySpace) {
            return nonNullTiles;
        }
        let actualTiles = nonNullTiles.filter((tile) => !tile.isEmptySpace);
        if (forRendering && actualTiles.length > 2) return nonNullTiles;
        return actualTiles;
    };

    adjustXPan = debounce(() => {
        if (this._animatedValueX > this.props.layout.layoutBoardWidth / 2) {
            this.pan.x.setValue(this.props.layout.layoutBoardWidth / 2);
        } else if (this._animatedValueX < 0 - this.props.layout.layoutBoardWidth / 2) {
            this.pan.x.setValue(0 - this.props.layout.layoutBoardWidth / 2);
        }
    }, 100);

    adjustYPan = debounce(() => {
        if (this._animatedValueY > this.props.layout.layoutBoardWidth / 2) {
            this.pan.y.setValue(this.props.layout.layoutBoardWidth / 2);
        } else if (this._animatedValueY < 0 - this.props.layout.layoutBoardWidth / 2) {
            this.pan.y.setValue(0 - this.props.layout.layoutBoardWidth / 2);
        }
    }, 100);

    getContainerDimensions = () => ({
        height: this.props.layout.layoutBoardDimenWidth,
        width: this.props.layout.layoutBoardDimenWidth,
        top: this.state.top,
        left: this.state.left,
    });

    emptyGameBoard = ({ nonLockedTilesOnly = false, letRevealSolutionRemain = false, forAnalyseMove } = {}) =>
        eventBus.emit(CELL_REDUCER_EMPTY_GAMEBOARD, null, {
            nonLockedTilesOnly,
            letRevealSolutionRemain,
            forAnalyseMove,
        });

    getStyle = () => [
        {
            transform: [
                {
                    translateX: this.pan.x,
                },
                {
                    translateY: this.pan.y,
                },
                {
                    scale: this.scale,
                },
            ],
        },
    ];

    panToPosition = (x, y) => {
        if (get(this.props, 'config.autozoom') && this.scale._value > 1) {
            let boardSize = get(this.props, 'cells.cells').length;
            let cell = get(this.props, 'layout.cellDimensions')
                .flat(8)
                .find((cell) => cell.tileX === x && cell.tileY === y);
            let yPos =
                this.props.layout.layoutBoardWidth / 2 -
                (cell.tileStartYUnscaledUnoffset + Math.round(y / boardSize) * this.props.layout.layoutCellDimen);
            let xPos =
                this.props.layout.layoutBoardWidth / 2 -
                (cell.tileStartXUnscaledUnoffset + Math.round(x / boardSize) * this.props.layout.layoutCellDimen);
            this.scaleAndPanTo(2, xPos, yPos);
        }
    };

    unsetMouseMoveTile = () => {
        eventBus.emit(REDUCER_UPDATE_MOUSE_MOVE_TILE);
    };

    getPuzzleSidePanelDimension = () => ({
        width: this.getSidePanelWidth(),
        height: this.getBoardHeight(),
    });

    getSidePanelZIndex = () => ({
        zIndex: this.state.sidePanelView !== SidePanelView.PlaceBoardTile ? 10 : undefined,
    });

    getTileRemainingColor = () => ({
        color:
            this.state.tileRemainCount === 0
                ? ColorConfig.SOLO_CREATE_GAME_TILES_REMAINING_COLOR
                : ColorConfig.SOLO_CREATE_GAME_TILES_REMAINING_LESS_COLOR,
    });

    getTitleIndex = (tileType) => {
        let tileArr = Config.SOLO_CREATE_BOARD_CELL;
        return tileArr.indexOf(tileType.letter);
    };

    render = () => /* LayoutWrapper.isSafariMobile() ? this.renderSafariMobile() : */ this.renderCommon();

    renderSafariMobile = () => (
        <LongPress time={500} onLongPress={EventWrapper.onLongPressInSafariMobile}>
            {this.renderCommon()}
        </LongPress>
    );

    renderCommon = () => {
        this.setRandomBoard();
        return (
            <View key={'boardRootSafeAreaVew'} style={[styles.mainContainer]}>
                {this.renderSidePanel()}
                {this.renderCells()}
                {this.renderMouseMoveTile()}
                {this.getTiles({ includeEmptySpace: true })
                    .filter(Boolean)
                    .map((tileType, index) => this.renderTiles(tileType, this.getTitleIndex(tileType), false))}
            </View>
        );
    };

    renderMouseMoveTile = () => (this.props.tiles.selectedTile ? <View style={this.getMouseMoveTileStyle()} /> : null);

    renderSidePanel = () => (
        <TouchableOpacity
            style={[styles.sidePanelContainer, this.getPuzzleSidePanelDimension(), this.getSidePanelZIndex()]}
            activeOpacity={1}
            onPress={this.unsetMouseMoveTile}
        >
            <View style={[styles.sidePanelTitle]} variant="contained">
                <S14Text style={styles.titleBarHeadingTextStyle}>{this.getTitle()}</S14Text>
            </View>

            <View style={styles.sideDetailsContainer}>{this.getSideDetailsView()}</View>
        </TouchableOpacity>
    );

    getTitle = () => {
        switch (this.state.sidePanelView) {
            case SidePanelView.PlaceBoardTile:
                return 'Create Your Board';
            case SidePanelView.TileDistribute:
                return 'Tile Distribution';
            case SidePanelView.TileValue:
            case SidePanelView.GameStart:
                return 'Tile Value';
            default:
                throw new Error('Invalid status');
        }
    };

    autoComplete = () => {
        this.unsetMouseMoveTile();
        let gameBoardTiles = cloneDeep(get(this.props, 'cells.cells'));
        let blankPos = [
            [7, 0],
            [0, 7],
        ];
        let tilesPositionsObjs = [];
        let alreadyPickedTiles = [];
        for (let y = 0; y < gameBoardTiles.length; y++) {
            for (let x = 0; x < gameBoardTiles.length; x++) {
                let cell = gameBoardTiles[y][x];
                let tile = cell.currentTile;
                if (tile) {
                    if (
                        x < gameBoardTiles.length / 2 &&
                        y < gameBoardTiles.length / 2 &&
                        x !== y &&
                        !blankPos.find((pos) => pos[0] === x && pos[1] === y)
                    ) {
                        let newX = gameBoardTiles.length - 1 - x;
                        let newY = gameBoardTiles.length - 1 - y;

                        let posArr = [[x, y]];
                        if (newX !== x && !posArr.find((pos) => pos[0] === newX && pos[1] === y)) posArr.push([newX, y]);
                        if (newY !== y && !posArr.find((pos) => pos[0] === x && pos[1] === newY)) posArr.push([x, newY]);
                        if (newX !== x && newY !== y && !posArr.find((pos) => pos[0] === newX && pos[1] === newY))
                            posArr.push([newX, newY]);

                        for (let k = 0; k < posArr.length; k++) {
                            let pos = posArr[k];
                            let tileInfo = this.placeLetter({
                                letterPressed: tile.letter,
                                alreadyPickedTiles,
                            });
                            if (tileInfo) {
                                tilesPositionsObjs.push({
                                    tile: tileInfo,
                                    positionX: Number(pos[1]),
                                    positionY: Number(pos[0]),
                                });
                            }
                        }
                    } else {
                        if (!tilesPositionsObjs.find((tile) => tile.positionX === y && tile.positionY === x)) {
                            tilesPositionsObjs.push({
                                tile: undefined,
                                positionX: Number(y),
                                positionY: Number(x),
                            });
                        }
                    }
                }
            }
        }
        this.setTiles(tilesPositionsObjs);
    };

    boardStatusResponse = (res) => {
        if (res.status) {
            this.setNextBoardOption(1);
        } else {
            createDialogInstance({
                title: 'Board not acceptable',
                cancelButtonText: 'Ok',
                body: res.reason ? res.reason : 'Sorry, this board is not allowed',
            });
        }
    };

    checkBoardStatus = () => {
        let blankPos = [
            [7, 0],
            [0, 7],
            [14, 7],
            [7, 14],
        ];
        let reason = 'Sorry, Diagonally placed tiles are not allowed';
        let validStatus = true;
        let boarddes = '';
        let tileTypeInfo = this.props.bdsqvalSlot.split('|').map((type, index) => {
            let valueArr = type.split(',');
            return {
                type: valueArr[0],
                letter: valueArr[1],
            };
        });
        let gameBoardTiles = cloneDeep(get(this.props, 'cells.cells'));
        for (let y = 0; y < gameBoardTiles.length; y++) {
            for (let x = 0; x < gameBoardTiles.length; x++) {
                let cell = gameBoardTiles[y][x];
                let tile = cell.currentTile;
                let newX = gameBoardTiles.length - 1 - x;
                let newY = gameBoardTiles.length - 1 - y;
                if (tile && (x === y || newX === y || newY === x)) {
                    validStatus = false;
                    break;
                } else if (tile && blankPos.find((pos) => pos[0] === x && pos[1] === y)) {
                    reason =
                        'Sorry, Tiles placed on center of first row, last row, first column and last column are not allowed';
                    validStatus = false;
                    break;
                }
                boarddes += tile ? tileTypeInfo.find((tileType) => tileType.letter === tile.letter).type : 'W';
            }
        }
        if (validStatus) {
            eventBus.emit(GAME_SOLO_CREATE_GAME_DATA, null, {
                createBoardDes: boarddes,
            });
        }
        return this.boardStatusResponse({ status: validStatus, reason });
        //getCreateBoardStatus({action: Config.ACTION_SOLO_CHECK_CREATE_BOARD, data: boarddes});
    };

    checkTileCountScoreStatus = () => {
        let diffCount = 0;
        let scrableStats =
            this.state.sidePanelView === SidePanelView.TileDistribute
                ? GameBoardUtils.SCRABLE_TILE_COUNT_DEF
                : GameBoardUtils.SCRABLE_TILE_SCORE_DEF.slice(0, 26);
        let tileStats = '';
        let tileStatsDef =
            this.state.sidePanelView === SidePanelView.TileDistribute ? this.props.tilecountSlot : this.props.tilevaluesSlot;
        tileStatsDef.split('|').map((tileInfo, index) => {
            let valueArr = tileInfo.split(',');
            tileStats +=
                (index !== 0 ? '|' : '') +
                valueArr[0] +
                ',' +
                (valueArr[0] !== 'blank' && valueArr[0] >= 'a' && valueArr[0] <= 'z'
                    ? this.state['a']
                    : this.state[valueArr[0]] || 0);
            if (
                (valueArr[0] === 'blank' || !(valueArr[0] >= 'a' && valueArr[0] <= 'z')) &&
                scrableStats[index] != this.state[valueArr[0]]
            ) {
                diffCount++;
            }
        });
        let reason = 'Sorry, ';
        let validStatus = true;
        if (Math.floor(scrableStats.length / 2) > diffCount) {
            reason += 'tile value is invalid.';
            validStatus = false;
        } else if (this.state.sidePanelView === SidePanelView.TileDistribute && this.state.tileRemainCount !== 0) {
            reason += 'tile distribution is invalid.';
            validStatus = false;
        } else if (
            tileStats.split('|').some((tileInfo) => {
                let valueArr = tileInfo.split(',');
                return (valueArr[0] === 'blank' || !(valueArr[0] >= 'a' && valueArr[0] <= 'z')) && valueArr[1] === '0';
            })
        ) {
            let tiles = tileStats
                .split('|')
                .filter(
                    (tileInfo) =>
                        (tileInfo.split(',')[0] === 'blank' ||
                            !(tileInfo.split(',')[0] >= 'a' && tileInfo.split(',')[0] <= 'z')) &&
                        tileInfo.split(',')[1] === '0'
                );
            reason +=
                (this.state.sidePanelView === SidePanelView.TileDistribute ? 'tile count' : 'tile value') +
                ' 0 not allowed. [' +
                tiles.map((tileInfo) => ' ' + tileInfo.replace(',', '=').replace('blank', '#')) +
                ' ]';
            validStatus = false;
        } else if (
            this.state.sidePanelView === SidePanelView.TileValue &&
            tileStats.split('|').some((tileInfo) => {
                let valueArr = tileInfo.split(',');
                return valueArr[1] > GameBoardUtils.MAX_TILE_VALUE;
            })
        ) {
            let tiles = tileStats
                .split('|')
                .slice(0, 27)
                .filter((tileInfo) => tileInfo.split(',')[1] > GameBoardUtils.MAX_TILE_VALUE);
            reason +=
                'tile value more than ' +
                GameBoardUtils.MAX_TILE_VALUE +
                ' not allowed. [' +
                tiles.map((tileInfo) => ' ' + tileInfo.replace(',', '=').replace('a', '#')) +
                ' ]';
            validStatus = false;
        }
        if (validStatus) {
            if (this.state.sidePanelView === SidePanelView.TileDistribute) {
                eventBus.emit(GAME_SOLO_CREATE_GAME_DATA, null, {
                    createBoardTileCount: tileStats,
                });
            } else {
                eventBus.emit(GAME_SOLO_CREATE_GAME_DATA, null, {
                    createBoardTilevalues: tileStats,
                });
            }
        }
        return this.boardStatusResponse({ status: validStatus, reason });
        /* getCreateBoardStatus({
            action: (this.state.sidePanelView === SidePanelView.TileDistribute)? Config.ACTION_SOLO_CHECK_TILE_COUNT : Config.ACTION_SOLO_CHECK_TILE_VALUE, 
            data: tileStats
        }); */
    };

    getBoardNextOption = (val) => {
        if (val > 0) {
            switch (this.state.sidePanelView) {
                case SidePanelView.PlaceBoardTile:
                    return this.checkBoardStatus();
                case SidePanelView.TileDistribute:
                case SidePanelView.TileValue:
                    return this.checkTileCountScoreStatus();
                case SidePanelView.GameStart:
                    return this.setNextBoardOption(val);
                default:
                    throw new Error('Invalid status');
            }
        } else {
            this.setNextBoardOption(val);
        }
    };

    setNextBoardOption = (val) => {
        let sidePanelOpt = Number(this.state.sidePanelView) + val;
        if (sidePanelOpt > SidePanelView.GameStart) {
            this.props.nextAction && this.props.nextAction();
        } else if (sidePanelOpt < SidePanelView.PlaceBoardTile) {
            this.props.previousAction && this.props.previousAction();
        } else if (sidePanelOpt > SidePanelView.TileValue) {
            this.setState({ sidePanelView: sidePanelOpt });
            getCustomSavedBoard(true);
        } else {
            this.resetTileStats(sidePanelOpt);
            this.setState({
                sidePanelView: sidePanelOpt,
            });
        }
    };

    resetTileStats = (sidePanelOpt) => {
        if (sidePanelOpt === SidePanelView.TileDistribute || sidePanelOpt === SidePanelView.TileValue) {
            let tileStats =
                sidePanelOpt === SidePanelView.TileDistribute ? this.props.tilecountSlot : this.props.tilevaluesSlot;
            tileStats.split('|').map((tileInfo, index) => {
                let valueArr = tileInfo.split(',');
                this.setState({ [valueArr[0]]: valueArr[1] });
            });
            this.setState({ tileStats, tileRemainCount: 0 });
        }
    };

    checkTileRemainCount = () => {
        if (this.state.sidePanelView === SidePanelView.TileDistribute) {
            let tileStats = this.props.tilecountSlot;
            let usedTileCount = 0;
            tileStats.split('|').map((tileInfo, index) => {
                let valueArr = tileInfo.split(',');
                usedTileCount += Number(this.state[valueArr[0]]);
            });
            let tileRemainCount = ConfigurationWrapper.getSpecificLexulousGameConfiguration('total_tile_count') - usedTileCount;
            this.setState({ tileRemainCount });
        }
    };

    getSideDetailsView = () => {
        switch (this.state.sidePanelView) {
            case SidePanelView.PlaceBoardTile:
                return this.renderPlaceBoardTilesView();
            case SidePanelView.TileDistribute:
            case SidePanelView.TileValue:
            case SidePanelView.GameStart:
                return this.renderTileCountView();
            default:
                throw new Error('Invalid status');
        }
    };

    renderPlaceBoardTilesView = () => (
        <View style={styles.buttonContainer}>
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={this.helpDialogShow}
                text="Help"
                textStyle={[styles.buttonText]}
            />
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={this.randomBoard}
                text="Random"
                textStyle={[styles.buttonText]}
            />
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={this.preSetBoardData}
                text="Pre-set"
                textStyle={[styles.buttonText]}
            />
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={this.autoComplete}
                text="Auto Complete"
                textStyle={[styles.buttonText]}
            />
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={this.resetBoardData}
                text="Reset"
                textStyle={[styles.buttonText]}
            />
        </View>
    );

    renderTileCountView = () => (
        <View style={styles.tileCountContainer}>
            <StandardButton
                style={[styles.button]}
                hoverEffect
                onPress={bindFunction.bind({
                    params: this.state.sidePanelView,
                    bindRequest: this.resetTileStats,
                })}
                text="Restore Default"
                textStyle={[styles.buttonText]}
            />
            <View style={styles.tileStatsContainer}>
                {[this.getTileCountView(0, 10), this.getTileCountView(10, 20), this.getTileCountView(20, 27)]}
            </View>
            {this.state.sidePanelView === SidePanelView.TileDistribute ? (
                <S14Text style={[styles.tileRemainingText, this.getTileRemainingColor()]}>
                    {(this.state.tileRemainCount || 0) + ' tiles remaining'}
                </S14Text>
            ) : null}
        </View>
    );

    getTileCountView = (startIndex, endIndex) => {
        return (
            <View key={'tileCount_' + startIndex}>
                {this.state.tileStats
                    .split('|')
                    .slice(startIndex, endIndex)
                    .map((tileCount, index) => {
                        let valueArr = tileCount.split(',');
                        return (
                            <View style={styles.tileCountValueContainer}>
                                <S14Text>{valueArr[0] === 'blank' || valueArr[0] === 'a' ? '#' : valueArr[0]}</S14Text>
                                <View style={styles.tileStatsflex}>
                                    <TextInput
                                        style={styles.tileCountValueText}
                                        keyboardType={'numeric'}
                                        value={this.state[valueArr[0]]}
                                        onChangeText={this.onTileValueChange(valueArr[0])}
                                        autoComplete={'off'}
                                        autoCompleteType={'off'}
                                    />
                                </View>
                            </View>
                        );
                    })}
            </View>
        );
    };

    onTileValueChange = (name) => {
        return (text) => {
            this.setState({ [name]: text }, this.checkTileRemainCount);
        };
    };

    helpDialogShow = () => {
        this.unsetMouseMoveTile();
        createDialogInstance({
            title: 'Help',
            cancelButtonText: 'Ok',
            body: this.getHelpBody(),
        });
    };

    getHelpBody = () => (
        <View>
            <S14Text style={styles.helpTitle}>How To Build Boards</S14Text>
            <S14Text>
                Drag the special square of your choice on the board. The score of the first word is always doubled.
                {'\n\n'}
            </S14Text>

            <S14Text style={styles.helpTitle}>What's AutoComplete</S14Text>
            <S14Text>
                It automagically configures the rest of the board after you design the TOP LEFT portion of the board. Place one
                special square on it, then click on autocomplete. You'll understand!
                {'\n\n'}
            </S14Text>

            <S14Text style={styles.helpTitle}>What Should I Build</S14Text>
            <S14Text>
                Anything you want! Try using wild designs, create a high scoring board, or perhaps a christmas theme! Oh and you
                can save it for later too.
            </S14Text>
        </View>
    );

    randomBoard = () => {
        this.unsetMouseMoveTile();
        if (this.props.setBoardButton) {
            eventBus.emit(GAME_SOLO_SET_BOARD_DISABLE);
            getRandomBoard();
        }
    };

    preSetBoardData = () => {
        this.unsetMouseMoveTile();
        if (this.props.setBoardButton) {
            eventBus.emit(GAME_SOLO_SET_BOARD_DISABLE);
            eventBus.emit(GAME_SOLO_GET_RANDOM_BOARD, null, {
                boarddes: GameBoardUtils.preSetBoardDes,
            });
        }
    };

    resetBoardData = () => {
        this.unsetMouseMoveTile();
        this.emptyGameBoard();
        eventBus.emit(GAME_SOLO_RESET_CREATE_BOARD);
    };

    repositionAllTiles = () => null;

    scaleAndPanTo = (scale, x, y) => {
        let currentXPan = this._animatedValueX;
        let currentYPan = this._animatedValueY;
        let currentScale = this.scale._value;

        let animTime = currentScale === scale && currentScale > 1 ? 0 : 300;

        if (animTime > 0) {
            let scaleOut = AnimatedValueWrapped.create({
                start: currentScale,
                end: scale,
            });

            let animateXToOrigin = AnimatedValueWrapped.create({
                start: currentXPan,
                end: x,
            });

            let animateYToOrigin = AnimatedValueWrapped.create({
                start: currentYPan,
                end: y,
            });

            let combinedAnim = AnimatedValueWrapped.compose(animateXToOrigin, animateYToOrigin, scaleOut);

            combinedAnim.play(animTime, () => {
                this.pan.setOffset({
                    x: animateXToOrigin.value(),
                    y: animateYToOrigin.value(),
                });
                this.pan.setValue({ x: 0, y: 0 });
                this.scale.setValue(scaleOut.value());
            });
        }

        this.pan.setOffset({ x, y });
        this.pan.setValue({ x: 0, y: 0 });
        this.pan.flattenOffset();
        this.scale.setValue(scale);

        this.repositionAllTiles();
    };

    panToPositionDebounced = debounce((x, y) => {
        if (x === 'zoomout') {
            this.scaleAndPanTo(1, 0, 0);
        } else {
            this.panToPosition(x, y);
        }
    }, 200);

    getRenderCellContainerStyles = () => ({
        width: this.props.layout.layoutBoardWidth,
        height: this.getBoardHeight(),
        left: this.state.left,
        top: this.state.top,
    });

    getRenderCellAnimatedViewDimensions = () => ({
        width: this.props.layout.layoutBoardWidth,
        height: this.props.layout.layoutBoardWidth,
    });

    getBoardRowDimensions = (indexY) => ({
        position: 'absolute',
        left: 0,
        top: indexY * this.props.layout.layoutCellDimen,
        height: this.props.layout.layoutCellDimen + StyleSheet.hairlineWidth,
        width: '100%',
    });

    getSpecialCellsContainerStyles = (specialCellType, data) => ({
        left: data['0'] * this.props.layout.layoutCellDimen,
        width: this.props.layout.layoutCellDimen,
        height:
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_TOP_DIMENSION_MULTIPLIER +
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_BOTTOM_DIMENSION_MULTIPLIER,
        top:
            data['1'] * this.props.layout.layoutCellDimen +
            this.props.layout.layoutCellDimen * Config.COLOR_CELLS_CONTAINER_TOP_DIMENSION_MULTIPLIER,
        backgroundColor: GameBoardUtils.getCellBackgroundColor({
            specialCellType,
        }),
    });

    renderCells = () => (
        <View
            id={'boardRoot'}
            key={'boardRoot'}
            class={'boardRows'}
            style={[styles.boardRoot, styles.postionAbsolute, this.getRenderCellContainerStyles()]}
        >
            <Animated.View
                style={[styles.animatedView, this.getRenderCellAnimatedViewDimensions(), this.getStyle()]}
                {...this._panResponder.panHandlers}
                class={'boardRows'}
            >
                {times(get(this.props, 'game.board_size'), constant(null)).map((boardRow, indexY) => (
                    <View class={'boardRows'} style={[styles.insideAnimatedView, this.getBoardRowDimensions(indexY)]}>
                        {times(get(this.props, 'game.board_size'), constant(null)).map((cell, indexX) => (
                            <Cell isCreateBoard={true} idStr={'cell' + indexX + '_' + indexY} />
                        ))}
                    </View>
                ))}
            </Animated.View>
        </View>
    );

    setTiles = (tilesPositionsObjs) => {
        let cells = [];
        tilesPositionsObjs.forEach(({ tile, positionX, positionY }) => {
            let cell = cloneDeep(get(this.props, 'cells.cells')[positionX][positionY]);
            if (cell) {
                cell.currentTile = tile;
                cell.locked = false;
            }
            cells.push(cell);
        });
        eventBus.emit(CELL_REDUCER_SET_TILE, null, { cells });
    };

    renderTiles = (tileType, index, droppedTile) => (
        <Tile
            scale={this.scale}
            pan={this.pan}
            tileType={tileType}
            index={index}
            style={droppedTile ? { zIndex: 100 } : null}
            containerDimensions={this.getContainerDimensions()}
            isCreateBoard={true}
            boardAdditionalLeftDimension={this.state.boardAdditionalLeftDimension}
        />
    );

    getCellDimen = () => this.props.layout.layoutCellDimen;

    getBoardHeight = () => this.props.layout.layoutBoardWidth + StyleSheet.hairlineWidth;

    getSidePanelWidth = () => this.props.layout.screenWidth - this.props.layout.layoutBoardWidth - Config.RIGHT_LEFT_MARGIN;

    getCurrentScale = () => this.scale._value;

    refreshPosition = (y, x) => {
        let cell = get(this.props, 'layout.cellDimensions.' + x + '.' + y);

        let result = {
            x: cell.tileStartXUnscaledUnoffset,
            y: cell.tileStartYUnscaledUnoffset,
            endX: cell.tileEndXUnscaledUnoffset,
            endY: cell.tileEndYUnscaledUnoffset,
        };

        return result;
    };

    onDroppedWithinRack = ({ tile, oldPosition, moveX, moveY }) => {};

    getScale = () => this.scale._value;

    setCellVisibility = (tileType, visibility) => {
        eventBus.emit(CELL_REDUCER_HIDE_TILE, null, {
            position: { x: tileType.position.x, y: tileType.position.y },
            hidden: !visibility,
        });
    };

    onMoveShouldSetPanResponder = (e, gesture) => {
        let isClickingDroppedTile = false;
        if (e.nativeEvent.touches && e.nativeEvent.touches.length === 1) {
            let droppedTiles = this.getTiles().filter((tile) => !!tile.position);
            if (droppedTiles)
                isClickingDroppedTile = droppedTiles.some((tile) => {
                    let tileRef = 'tile_' + get(tile, 'id');
                    return this[tileRef].isTileBeingDragged();
                });
        }
        return (
            (!isClickingDroppedTile && this.scale._value > 1) || (e.nativeEvent.touches && e.nativeEvent.touches.length === 2)
        );
    };

    onCellDoubleTap = (cell, indexX, indexY) => {
        let boardSize = get(this.props, 'cells.cells').length;
        this.scaleAndPanTo(
            this.scale._value > 1 ? 1 : 2,
            this.scale._value > 1
                ? 0
                : this.props.layout.layoutBoardWidth / 2 -
                      (cell.tileStartXUnscaledUnoffset + Math.round(indexX / boardSize) * this.props.layout.layoutCellDimen),
            this.scale._value > 1
                ? 0
                : this.props.layout.layoutBoardWidth / 2 -
                      (cell.tileStartYUnscaledUnoffset + Math.round(indexY / boardSize) * this.props.layout.layoutCellDimen)
        );
    };

    getMouseMoveTileStyle = () => {
        let boardStartY = this.getContainerDimensions().top;
        let boardWidth = get(this.props, 'layout.boardDimen');
        let cellDimen = get(this.props, 'layout.cellDimen');
        let rackStartX = get(this.props, 'layout.layoutRackStartMarginOriginal');
        let boardEndX = this.getContainerDimensions().left + boardWidth - 3 * cellDimen;
        let margin = get(this.props, 'layout.layoutTileMarginInRack') + 20;
        let CIRCLE_RADIUS = cellDimen / 2;
        let index = this.getTitleIndex(this.props.tiles.selectedTile);
        let pointerTop = boardStartY + 68 + (index > 3 ? 50 : 0);
        let tempIndex = index < 4 ? index : index - 4;
        let pointerLeft =
            (rackStartX + boardEndX + this.props.layout.screenWidth) / 2 -
            2 * (2 * CIRCLE_RADIUS + margin + 1.3 * CIRCLE_RADIUS) +
            (2 * CIRCLE_RADIUS * tempIndex + margin * tempIndex) +
            1.3 * CIRCLE_RADIUS +
            28;
        return {
            alignItems: 'center',
            justifyContent: 'center',
            width: this.props.layout.layoutCellDimen * this.getScale() + 4,
            height: this.props.layout.layoutCellDimen * this.getScale() + 4,
            position: 'absolute',
            left: pointerLeft,
            top: pointerTop,
            borderRadius: this.getCellDimen() / 2 / 4,
            borderWidth: StyleSheet.hairlineWidth,
            borderColor: ColorConfig.CUSTOM_BOARD_CREATE_SELECTED_TILE,
            backgroundColor: ColorConfig.CUSTOM_BOARD_CREATE_SELECTED_TILE,
            boxShadow: '0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2)',
        };
    };
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'flex-start',
    },
    boardRoot: {
        overflow: 'hidden',
        flexDirection: 'column',
        zIndex: undefined,
        top: 0,
        backgroundColor: ColorConfig.DEFAULT_CELL_BACKGROUND_COLOR,
    },
    animatedView: {
        flexDirection: 'column',
        zIndex: undefined,
    },
    insideAnimatedView: {
        flexDirection: 'row',
        zIndex: undefined,
    },
    postionAbsolute: {
        position: 'absolute',
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    directionRow: {
        flexDirection: 'row',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    justifyFlexEnd: {
        justifyContent: 'center',
    },
    alignItemCenter: {
        alignItems: 'center',
    },
    alignItemFlexEnd: {
        alignItems: 'flex-end',
    },
    widthHundred: {
        width: '100%',
    },
    spaceBetweenRowStyle: { justifyContent: 'space-between' },

    sidePanelTitle: {
        padding: Config.TAB_RIGHT_LEFT_MARGIN,
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flexDirection: Config.ROW,
        alignItems: Config.CENTER,
        justifyContent: Config.CENTER,
    },
    titleBarHeadingTextStyle: {
        color: ColorConfig.NEW_GAME_BUTTON_COLOR,
        fontWeight: 'bold',
        paddingLeft: 8,
    },
    sideDetailsContainer: {
        flex: 1,
        padding: 16,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderLeftColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderBottomColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderBottomLeftRadius: 5,
        borderBottomRightRadius: 5,
    },
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        backgroundColor: ColorConfig.SOLO_SIDE_PANEL_BUTTON_BACKGROUND_COLOR,
        width: 200,
        height: 30,
        marginTop: 8,
    },
    buttonText: {
        color: ColorConfig.SOLO_SIDE_PANEL_BUTTON_TEXT_COLOR,
        alignSelf: 'center',
        fontSize: 14,
    },
    helpTitle: { fontWeight: 'bold', marginBottom: 4 },
    flexDirection: { flexDirection: 'row', flex: 1 },
    buttonContainer: { alignSelf: 'center', marginTop: 120 },
    sidePanelContainer: { alignSelf: 'flex-end' },
    tileCountContainer: { alignSelf: 'center' },
    tileCountValueContainer: {
        flexDirection: 'row',
        width: 45,
        alignItems: 'center',
        marginLeft: 16,
        marginBottom: 8,
    },
    tileCountValueText: {
        width: 25,
        height: 20,
        textAlign: 'center',
        alignSelf: 'flex-end',
        borderWidth: StyleSheet.hairlineWidth,
    },
    tileStatsContainer: { flexDirection: 'row', marginTop: 16 },
    tileStatsflex: { flex: 1 },
    tileRemainingText: {
        alignSelf: 'center',
        marginTop: 4,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: state.layout,
    tiles: state.tiles,
    cells: state.cells,

    boarddes: state.solitaire.boarddes,
    setBoardButton: state.solitaire.setBoardButton,
    bdsqvalSlot: state.solitaire.bdsqvalSlot,
    tilecountSlot: state.solitaire.tilecountSlot,
    tilevaluesSlot: state.solitaire.tilevaluesSlot,
});
export default connect(mapStateToProps)(CustomBoard);
