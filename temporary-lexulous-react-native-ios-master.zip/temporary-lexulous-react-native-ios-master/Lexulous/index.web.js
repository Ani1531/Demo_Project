import { AppRegistry } from 'react-native';
import { name as appName } from './app.json';
import AppContainer from './src/com/lexulous/Lexulous/app/AppContainer';

if (__DEV__) {
    if (module.hot) {
        module.hot.accept();
    }
}
AppRegistry.registerComponent(appName, () => AppContainer);
AppRegistry.runApplication(appName, {
    initialProps: {},
    rootTag: document.getElementById('app-root'),
});
