import React from 'react';
import { Text, StyleSheet } from 'react-native';
import S10Text from './S10Text';

export default class ProTag extends React.Component {
    render = () => <S10Text style={styles.proTagStyle}>PRO</S10Text>;
}
const styles = StyleSheet.create({
    proTagStyle: {
        backgroundColor: '#ffc107',
        color: '#212529',
        borderRadius: 5,
        padding: 2,
        marginHorizontal: 5,
        fontWeight: 'bold',
    },
});
