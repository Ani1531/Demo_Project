import WebSocketAsPromised from 'websocket-as-promised';
import Config from '../configs/Config';
import {
    GAME_HAS_ENDED,
    CHAT_APPEND_LIST_ITEM,
    GAME_MOVE,
    GAME_STARTED,
    GAME_LIVE_ROOM_ADD_OBSERVER,
    GAME_LIVE_ROOM_REMOVE_OBSERVER,
    GAME_LIVE_ROOM_LOGIN,
    GAME_HAS_ACTIVE_GAME_EVENT,
    GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
    GAME_LIVE_ADD_HOSTED_GAME,
    GAME_LIVE_DELETE_HOSTED_GAME,
    GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED,
    GAME_LIVE_HOST_GAME_ACTION,
    GAME_LIVE_GAME_CANCEL_INVITATION,
    GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL,
    CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE,
    GAME_LIVE_GAME_GET_ONLINE_STATUS,
    CHAT_CLEAR_LIST,
    GAME_SET_PLAYER_COUNT,
    CONNECTIVITY_REDUCER_CONNECTION_LOST,
    CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
    CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
    LOBBY_CHAT_MESSAGE,
    CHAT_APPEND_LIST_ITEM_MORE_TIME,
    GAME_LIVE_OBSERVABLE_GAME_REMOVE,
    GAME_SOLO_SET_NO_LOGIN_DATA,
    GAME_SOLO_GAME_LOGIN,
    GAME_SOLO_GET_RANDOM_BOARD,
    GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE,
    GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED,
    GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
    CONNECTIVITY_REDUCER_RESTART_SERVER,
    GAME_BLITZ_JNDPLYS_UPDATE,
    GAME_BLITZ_INP_GAMEOVER,
    GAME_BLITZ_JNDPLY_REMOVE,
    GAME_HAS_ENDED_ON_GAMEOVER,
} from '../configs/ActionIdentifiers';
import { to } from 'await-to-js';
import { getNull, isOnline, lastArrayElement, queueWithPromisifiedPush, StatusCheckableTimeout } from '../utils/Utils';
import get from 'lodash/get';
import StringUtils from '../utils/StringUtils';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import GameBoardUtils from '../utils/GameBoardUtils';
import SoundUtils from '../utils/SoundUtils';
import {
    getOnlinePlayerList,
    getSettings,
    isEmailGame,
    getHostedGameList,
    getLiveGameList,
    getHostJoinPlayerGameStats,
} from '../service/GamePlayService';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import { sendSoloGameStartData } from '../service/LiveGamePlayService';
import store from '../store';
import log from 'loglevel';
import NetInfo from '@react-native-community/netinfo';

const eventBus = require('js-event-bus')();

let reconnectTimeout;
let reconnectCount = 0;
let stopTryingToReconnect = false;
let duplicateConnection = false;
let websocket_was_disconected = false;
let websocketConnection;
let unsubscribe;
let unsubscribeGoneOfflineIndicator;
const request_queue = queueWithPromisifiedPush();

export default class WebSocketProvider {
    static disconnect = () => {
        if (WebSocketProvider.isConnected()) {
            websocketConnection.removeAllListeners();
            unsubscribe();
            unsubscribeGoneOfflineIndicator();

            websocketConnection.close();
        }
    };

    static getWebSocketConnection = async (newGame = false) => {
        const state = store.getState();

        let shouldReconnect = reconnectCount < Config.MAX_RECONNECT_TRIES;

        if (!newGame) {
            if (WebSocketProvider.isConnected()) return websocketConnection;
            else {
                if (!WebSocketProvider.isReconnectCleared() || !shouldReconnect || !isOnline()) {
                    return;
                }
            }
        }

        let loginParams = {
            action: Config.LOGIN_ACTION,
            channel: state.game.channel,
            ver: '3',
            device: 'WB',
        };

        if (state.game.game_type === Config.GAME_TYPE_SOLO) {
            let guid = ConfigurationWrapper.getSpecificLexulousGameConfiguration('guid');
            let uuid = ConfigurationWrapper.getSpecificLexulousGameConfiguration('uuid');
            if (guid && uuid) {
                loginParams.sourcetype = 'Lexcom_Practice';
            } else {
                guid = Date.now() + '';
                uuid = Date.now() + '';
                eventBus.emit(GAME_SOLO_SET_NO_LOGIN_DATA, null, {
                    guid,
                    uuid,
                    soloDemoAcc: true,
                });
                loginParams.sourcetype = 'quickGame';
            }

            loginParams.guid = guid;
            loginParams.uuid = uuid;
        } else {
            loginParams.guid = state.game.guid;
            loginParams.uuid = state.game.uuid;
        }

        let host = state.game.websocket_host + 'live?params=';
        if (state.game.game_type === Config.GAME_TYPE_SOLO) {
            host = state.game.solo_websocket_host + 'solitaire?json=';
        } else if (state.game.game_type === Config.GAME_TYPE_BLITZ) {
            host = state.game.blitz_websocket_host + 'blitz?params=';
        }
        let wsUrl = encodeURI(host + JSON.stringify(loginParams));
        websocketConnection = new WebSocketAsPromised(wsUrl, {
            packMessage: (data) => JSON.stringify(data),
            unpackMessage: (data) => JSON.parse(data),
            attachRequestId: (data, requestId) => Object.assign({ piggyback: JSON.stringify({ msgId: requestId }) }, data), // attach requestId to message as `id` field
            extractRequestId: (data) => data && data.piggyback && JSON.parse(data.piggyback).msgId, // read requestId from message `id` field
            timeout: Config.LIVE_GAME_REQUEST_TIMEOUT_TIME,
        });

        websocketConnection.onMessage.addListener(WebSocketProvider.handleIncomingMessage);
        websocketConnection.onClose.addListener(WebSocketProvider.checkAndReconnect);

        if (!unsubscribeGoneOfflineIndicator)
            unsubscribeGoneOfflineIndicator = NetInfo.addEventListener((state) => {
                if (!state.isConnected) WebSocketProvider.goneOfflineIndicator(reconnectCount);
            });

        if (!unsubscribe) unsubscribe = NetInfo.addEventListener(WebSocketProvider.checkAndReconnect);

        let res = await to(websocketConnection.open());

        if (res[0]) {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_LOST);
            ++reconnectCount;
            let setReconnectOnFail = reconnectCount + 1 <= Config.MAX_RECONNECT_TRIES;
            setReconnectOnFail && WebSocketProvider.setReconnectTimeout();
        } else {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED);
            reconnectCount = 0;
            return websocketConnection;
        }
    };

    static checkAndReconnect = () => {
        if (!WebSocketProvider.isConnected()) {
            websocket_was_disconected = true;
            if (stopTryingToReconnect || duplicateConnection) {
            } else {
                WebSocketProvider.attemptReconnection();
                getSettings();
            }
        } else {
            eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED);
            if (websocket_was_disconected) {
                websocket_was_disconected = false;
                duplicateConnection = false;
                getHostedGameList();
                getOnlinePlayerList();
                getLiveGameList();
            }
        }
    };

    static setReconnectTimeout = () => {
        WebSocketProvider.clearReconnect();
        reconnectTimeout = new StatusCheckableTimeout(
            WebSocketProvider.checkAndReconnect,
            Config.LIVE_GAME_REQUEST_TIMEOUT_TIME
        );
    };

    static isReconnectCleared = () => !reconnectTimeout || reconnectTimeout.getCleared();

    static clearReconnect = () => reconnectTimeout && reconnectTimeout.clear();

    static pleaseRefreshIndicator = (reconnectCount) => {};

    static goneOfflineIndicator = (reconnectCount) => {
        eventBus.emit(CONNECTIVITY_REDUCER_CONNECTION_LOST, null, {
            reconnectCount,
        });
    };

    static isConnected = () =>
        isOnline() && websocketConnection && websocketConnection.ws && [1, 0].includes(websocketConnection.ws.readyState);

    static attemptReconnection = async () => {
        websocketConnection && websocketConnection.removeAllListeners() && (await to(websocketConnection.close()));

        eventBus.emit(CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING);

        await to(WebSocketProvider.getWebSocketConnection());

        if (!WebSocketProvider.isConnected()) {
            LiveGamePlayUtils.stopPollOperation();
            if (reconnectCount < Config.MAX_RECONNECT_TRIES) {
                WebSocketProvider.goneOfflineIndicator(reconnectCount);
            } else {
                WebSocketProvider.pleaseRefreshIndicator(reconnectCount);
            }
        }
    };

    static isConnecting = () =>
        isOnline() && websocketConnection && websocketConnection.ws && [0].includes(websocketConnection.ws.readyState);

    static handleIncomingMessage = (message, showLogs = false) => {
        const state = store.getState();

        let messageObj = StringUtils.isString(message) ? JSON.parse(message) : message;
        // if ([Config.GAME_TYPE_LIVE_GAME].includes(get(state, "game.game_type")))
        //     eventBus.emit(SET_SERVER_TIME_DIFFERENCE, null, Date.now() - (Number(messageObj.tstmp)));
        if (
            state.game.game_type !== Config.GAME_TYPE_SOLO &&
            messageObj.piggyback &&
            !Config.HANDLED_BY_INCOMING_METHOD.includes(messageObj.action)
        )
            return;
        let action = messageObj.action;

        let hasEmittedGameMove = false;

        switch (String(action).valueOf()) {
            case Config.LOGIN_ACTION: {
                if (state.game.game_type === Config.GAME_TYPE_SOLO) {
                    eventBus.emit(GAME_SOLO_GAME_LOGIN, null, messageObj);
                    let soloRating = get(messageObj, 'rating');
                    let gid = get(messageObj, 'gid');
                    let pregamedata = get(messageObj, 'pregamedata');
                    if (!gid) {
                        eventBus.emit(Config.EVENT_SOLO_NO_LOGIN_GAME_START);
                        let params = {
                            action: Config.START_NEW_GAME_ACTION,
                            boardtype: 'N',
                            gametype: 'robot',
                            robotlevel: '10',
                            dic: 'twl',
                            timertype: '0',
                            timerlength: '0',
                            boarddetails: 'standard',
                        };
                        sendSoloGameStartData(params);
                    }
                } else {
                    eventBus.emit(GAME_LIVE_ROOM_LOGIN, null, messageObj);
                }
                break;
            }
            case Config.HAS_ACTIVE_GAME: {
                eventBus.emit(GAME_HAS_ACTIVE_GAME_EVENT, null, messageObj);
                eventBus.emit(Config.HAS_ACTIVE_GAME_EVENT, null, messageObj);
                break;
            }
            case Config.REQ_JOIN_HOSTED_GAME_ACTION:
            case Config.START_NEW_GAME_ACTION: {
                if (state.game.game_type === Config.GAME_TYPE_SOLO) {
                    WebSocketProvider.startSoloGame(messageObj);
                    return;
                }
                if (!(messageObj && messageObj.data && messageObj.data.sender)) return;
                eventBus.emit(GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED, null, messageObj.data);
                return eventBus.emit(Config.START_NEW_GAME_INVITATION_RECEIVED, null, {
                    ...messageObj.data,
                    reqJoinHostGame: action === Config.REQ_JOIN_HOSTED_GAME_ACTION,
                });
            }
            case Config.GAME_CHAT_RESPONSE_ACTION: {
                SoundUtils.messageSound();
                let chatMessageObj = {
                    message: isEmailGame() ? messageObj.data.chat[0] : messageObj.data,
                    direction: 'incoming',
                    id: Date.now(),
                };
                eventBus.emit(CHAT_APPEND_LIST_ITEM, null, chatMessageObj);
                break;
            }
            case Config.LEAVE_HOSTED_GAME_REPSPONSE_ACTION: {
                if (!messageObj.piggyback) {
                    /* eventBus.emit(
                        Config.LEAVE_HOSTED_GAME_EVENT,
                        null,
                        messageObj
                    ); */
                    eventBus.emit(GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE, null, messageObj);
                }
                return;
            }
            //Moves actions
            case Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION: {
                eventBus.emit(GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN);
            }
            case Config.PASS_MOVE_RESPONSE_ACTION:
            case Config.SWAP_TILES_RESPONSE_ACTION:
            case Config.SEND_LIVE_GAME_MOVE_DATA_RESPONSE_ACTION:
                if (state.game.game_type === Config.GAME_TYPE_SOLO) return;
                eventBus.emit(GAME_MOVE, null, messageObj);
                hasEmittedGameMove = true;
                GameBoardUtils.setPlayerSelfCurrentScore(messageObj);
                if (messageObj.piggyback) return;
            case Config.ACCEPT_MATCH_RESPONSE_ACTION: {
                if (messageObj.extcode === '1207') {
                    if (messageObj.piggyback) {
                        return;
                    }
                    let guidInMessage = get(messageObj, 'uri.guid');
                    if (guidInMessage !== state.game.guid) {
                        return eventBus.emit(Config.MATCH_REQUEST_REJECTED_EVENT, null, messageObj);
                    } else if (get(state, 'game.showingAnalyseMove')) {
                        return;
                    }
                }
            }
            case Config.JOIN_HOSTED_GAME_ACTION: {
                log.info(
                    'in App, in setLoaderOverlayVisibility, in WebSocketProvider, in Config.JOIN_HOSTED_GAME_ACTION case '
                );
                if (['1164', '1000'].includes(messageObj.extcode)) {
                    if (!messageObj.piggyback) eventBus.emit(Config.JOIN_HOSTED_GAME_EVENT, null, messageObj);

                    return;
                }
            }
            case Config.OBSERVE_GAME_RESPONSE_ACTION:
            case Config.GAME_FEED_REPSONSE_ACTION:
            case Config.GAMEOVER_EVENT_ACTION: {
                if (state.game.game_type === Config.GAME_TYPE_SOLO) {
                    WebSocketProvider.startSoloGame(messageObj);
                    return;
                }
                if (LiveGamePlayUtils.isBlitzGame() && Config.GAMEOVER_EVENT_ACTION.includes(messageObj.action)) {
                    return eventBus.emit(GAME_HAS_ENDED_ON_GAMEOVER, null, messageObj);
                }
                if (Config.RESET_MESSAGE_LIST_ACTIONS.includes(messageObj.action)) {
                    eventBus.emit(CHAT_CLEAR_LIST);
                }
                if (Config.SET_PLAYER_COUNT_ACTIONS.includes(messageObj.action)) {
                    GameBoardUtils.setPlayerCountInGame(messageObj);
                    eventBus.emit(GAME_SET_PLAYER_COUNT, null, messageObj);
                }
                GameBoardUtils.setDatas(messageObj);
                if (!hasEmittedGameMove) {
                    eventBus.emit(GAME_STARTED, null, messageObj);
                }
                let msgid = Date.now();
                eventBus.emit(
                    CHAT_APPEND_LIST_ITEM,
                    null,
                    (get(messageObj, 'data.' + state.game.channel + '.chat') || []).map((message) => ({
                        message,
                        direction: message.sender === GameBoardUtils.getSelfPid(messageObj) ? 'outgoing' : 'incoming',
                        id: msgid++,
                    })),
                    false
                );
                if (messageObj.extcode === '1') {
                    GameBoardUtils.setTilesInBag(messageObj);
                    GameBoardUtils.setPlayerSelfCurrentScore(messageObj);
                    eventBus.emit(Config.SHOW_BOARD_CONTAINER);
                    WebSocketProvider.updateScoreGraph(messageObj);
                    return eventBus.emit(Config.START_GAME_REQUEST_ACCEPTED, null, messageObj);
                }
            }
            case Config.ADD_HOSTED_GAMES_REQUEST_ACTION: {
                eventBus.emit(GAME_LIVE_ADD_HOSTED_GAME, null, messageObj);
                return eventBus.emit(Config.ADD_HOSTED_GAMES_ACTION, null, messageObj.data);
            }
            case Config.DELETE_HOSTED_GAME_REQUEST_ACTION: {
                eventBus.emit(GAME_LIVE_DELETE_HOSTED_GAME, null, messageObj);
                return eventBus.emit(Config.DELETE_HOSTED_GAME_ACTION, null, messageObj.data);
            }
            case Config.DELETE_GAME: {
                let currentTurn = get(messageObj, 'data.' + state.game.channel + '.current_turn');
                if (!currentTurn) LiveGamePlayUtils.clearGame();
                eventBus.emit(GAME_HAS_ENDED, null, messageObj);
                return eventBus.emit(Config.DELETE_GAME_EVENT, null, messageObj);
            }
            case Config.RESIGN_GAME: {
                let currentTurn = get(messageObj, 'data.' + state.game.channel + '.current_turn');
                if (!currentTurn) LiveGamePlayUtils.clearGame();
                eventBus.emit(GAME_HAS_ENDED, null, messageObj);
                return eventBus.emit(Config.RESIGN_GAME_EVENT, null, messageObj);
            }
            case Config.CANCEL_GAME_INVITATION_ACTION: {
                eventBus.emit(GAME_LIVE_GAME_CANCEL_INVITATION, null, messageObj.data);
                return eventBus.emit(Config.CANCEL_GAME_INVITATION_EVENT, null, messageObj.data);
            }
            case Config.GET_ONLINE_STATUS: {
                eventBus.emit(GAME_LIVE_GAME_GET_ONLINE_STATUS, null, messageObj);
                return eventBus.emit(Config.ONLINE_STATUS_CHANGED_EVENT, null, messageObj);
            }
            case Config.MORE_TIME_ACTION_RESPONSE_ACTION: {
                eventBus.emit(CHAT_APPEND_LIST_ITEM_MORE_TIME, null, messageObj);
                return eventBus.emit(GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL, null, messageObj);
            }
            case Config.DUPLICATE_CONNECTION_RESPONSE_ACTION: {
                if (get(messageObj, 'extcode') === '1160') {
                    duplicateConnection = true;
                    eventBus.emit(CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE, null, messageObj);
                    return eventBus.emit(Config.DUPLICATE_CONNECTION_OCCURENCE, null, messageObj);
                }
                break;
            }

            case Config.HOST_GAME_ACTION: {
                if (get(messageObj, 'extcode') === '1') {
                    eventBus.emit(GAME_LIVE_HOST_GAME_ACTION, null, messageObj);
                }
                break;
            }

            case Config.ADD_ONLINE_PLAYER: {
                return eventBus.emit(GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE, null, {
                    type: Config.ADD_ONLINE_PLAYER,
                    res: messageObj,
                });
            }

            case Config.REMOVE_ONLINE_PLAYER: {
                return eventBus.emit(GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE, null, {
                    type: Config.REMOVE_ONLINE_PLAYER,
                    res: messageObj,
                });
            }

            case Config.ADD_OBSERVER: {
                eventBus.emit(GAME_LIVE_ROOM_ADD_OBSERVER, null, messageObj);
                WebSocketProvider.setPlayerObjects(messageObj);
                break;
            }

            case Config.REMOVE_OBSERVER: {
                eventBus.emit(GAME_LIVE_ROOM_REMOVE_OBSERVER, null, messageObj);
                WebSocketProvider.setPlayerObjects(messageObj);
                break;
            }

            case Config.LOBBY_CHAT_ACTION: {
                return eventBus.emit(LOBBY_CHAT_MESSAGE, null, messageObj);
            }

            case Config.ADD_GAME_ACTION: {
                return eventBus.emit(GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED, null, messageObj);
            }

            case Config.REMOVE_GAME_ACTION: {
                return eventBus.emit(GAME_LIVE_OBSERVABLE_GAME_REMOVE, null, messageObj);
            }
            case Config.INP_GAME_OVER_ACTION: {
                eventBus.emit(GAME_BLITZ_INP_GAMEOVER, null, messageObj);
                return eventBus.emit(Config.EVENT_INP_GAME_OVER, null, messageObj);
            }

            case Config.ACTION_SOLO_QUICK_GAME_START:
            case Config.START_NEW_SAVED_GAME_ACTION: {
                if (state.game.game_type === Config.GAME_TYPE_SOLO) {
                    WebSocketProvider.startSoloGame(messageObj);
                    return;
                }
                break;
            }

            case Config.ACTION_SOLO_GET_RANDOM_BOARD:
                eventBus.emit(GAME_SOLO_GET_RANDOM_BOARD, null, {
                    boarddes: get(messageObj, 'data.boarddes'),
                });
                break;

            case Config.ACTION_SOLO_SLOT_GAME_EDIT:
                eventBus.emit(GAME_SOLO_GET_RANDOM_BOARD, null, {
                    boarddes: get(messageObj, 'data.boarddetails.boarddes'),
                    bdsqvalSlot: get(messageObj, 'data.boarddetails.bdsqval'),
                    tilecountSlot: get(messageObj, 'data.boarddetails.tilecount'),
                    tilevaluesSlot: get(messageObj, 'data.boarddetails.tilevalues'),
                });
                break;

            case Config.ACTION_RESTART_SERVER:
                eventBus.emit(CONNECTIVITY_REDUCER_RESTART_SERVER, null, messageObj);
                break;

            case Config.REQ_JOIN_HOSTED_GAME_REPSPONSE_ACTION:
                return eventBus.emit(Config.CANCEL_GAME_INVITATION_EVENT, null, messageObj);
            case Config.UPDATE_JNDPLY_ACTION: {
                return eventBus.emit(GAME_BLITZ_JNDPLYS_UPDATE, null, messageObj);
            }
            case Config.REMOVE_JNDPLY_ACTION: {
                return eventBus.emit(GAME_BLITZ_JNDPLY_REMOVE, null, messageObj);
            }
        }
    };

    static startSoloGame = (messageObj) => {
        const state = store.getState();
        eventBus.emit(GAME_STARTED, null, messageObj);
        GameBoardUtils.setDatas(messageObj);
        GameBoardUtils.setTilesInBag(messageObj);
        GameBoardUtils.setPlayerCountInGame(messageObj);
        let sourceType = get(messageObj, 'data.' + state.game.channel + '.source');
        let players = get(messageObj, 'data.' + state.game.channel + '.players');
        let player = players ? players[0] : [];
        let timeGame = get(player, 'timeleft', '-1');
        let pregamedata =
            get(messageObj, 'data.' + state.game.channel + '.dic') +
            ',' +
            get(messageObj, 'data.' + state.game.channel + '.robotlevel', '0') +
            ',' +
            get(messageObj, 'data.' + state.game.channel + '.livegame.duration', '0');
        WebSocketProvider.updateScoreGraph(messageObj);
        eventBus.emit(Config.SHOW_BOARD_CONTAINER);
        eventBus.emit(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, null, messageObj);
        log.info('in WebSocketProvider, in startSoloGame, method completed');
    };

    static setPlayerObjects = (messageObj) => {
        const state = store.getState();
        let guids = get(messageObj, 'data.guids');
        let someDataMissing = false;
        let playerObjects = guids.map((guid) => {
            let playerObject =
                (state.user.onlinePlayerBuddies || []).find((player) => player.guid === guid) ||
                (state.user.onlinePlayerOthers || []).find((player) => player.guid === guid);
            if (!playerObject) {
                someDataMissing = true;
            }
            return playerObject || guid;
        });
        if (someDataMissing) getOnlinePlayerList().then(getNull).catch(getNull);
        messageObj.data.playerObjects = playerObjects;
    };

    static updateMoveDefinition = ({ data } = {}) => {
        const state = store.getState();

        let wordsPlayed =
            get(data, state.game.channel + '.boarddata.wordsplayed') ||
            get(data, 'data.' + state.game.channel + '.boarddata.wordsplayed') ||
            [];

        if (wordsPlayed && wordsPlayed.length > 0) {
            let lastWordPlayedElement = wordsPlayed[wordsPlayed.length - 1];
            let lastMoveWordPlayedData = GameBoardUtils.getPlayerWordsPlayedOnAMove(
                lastWordPlayedElement,
                false,
                false
            ).toUpperCase();
        }
    };

    static updateScoreGraph = (messageObj) => {
        const state = store.getState();

        let { data, action } = messageObj || {};

        WebSocketProvider.updateMoveDefinition(messageObj);

        let wordsPlayed = get(data, state.game.channel + '.boarddata.wordsplayed') || [];
        let players = get(data, state.game.channel + '.players') || [];

        // Individual array for players and score insertion accordingly
        players.forEach((player) => {
            if (player && !player.scores) player.scores = [];
        });

        wordsPlayed.forEach((move) => {
            let score = GameBoardUtils.getPlayerMoveScoreOnAMove(move);
            let pid = GameBoardUtils.getPidFromMove(move);
            let player = players.find((player) => get(player, 'pid') === pid);
            let arrLength = player.scores.length;
            let totalScore = arrLength > 0 ? Number(lastArrayElement(player.scores)) + Number(score) : Number(score);
            player && player.scores.push(totalScore);
        });

        // Graph data object creation as per obj needed by chart library
        let graphData = [];
        for (let i = 0; i < (get(players, '0.scores') || []).length; i++) {
            let obj = {};

            // Move number
            obj.name = i + 1;

            // Each player score for this move number
            players.forEach((player) => {
                if (player) obj[player.pid] = player.scores[i];
            });

            graphData.push(obj);
        }
    };

    static getPuzzleData = async (params) => await WebSocketProvider.send(params);

    static sendPuzzleMoveData = async (params) => await WebSocketProvider.send(params);

    static sendMessage = async (params) => await WebSocketProvider.send(params);

    static getSettings = async (params) => await WebSocketProvider.send(params);

    static setSettings = async (params) => await WebSocketProvider.send(params);

    static getUserProfile = async (params) => await WebSocketProvider.send(params);

    static getWordValidity = async (params) => await WebSocketProvider.send(params);

    static getGameFeed = async (params) => await WebSocketProvider.send(params);

    static sendChallengeMove = async (params) => await WebSocketProvider.send(params);

    static friendApi = async (params) => await WebSocketProvider.send(params);

    static send = async (params) => await request_queue.promisifiedPush(() => WebSocketProvider.sendWithoutQueue(params));

    static sendWithoutQueue = async (params) => {
        let connectionReq = await to(WebSocketProvider.getWebSocketConnection());
        let sendReq = connectionReq[1] ? await to(connectionReq[1].sendRequest(params)) : [Error('Connection Unavailable')];
        if (sendReq[0]) {
            throw sendReq[0];
        } else return sendReq[1];
    };

    static ping = async (params) => await WebSocketProvider.send(params);
}
