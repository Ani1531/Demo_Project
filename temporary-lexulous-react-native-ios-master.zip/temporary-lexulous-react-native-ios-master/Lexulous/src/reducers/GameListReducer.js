import get from 'lodash/get';
import cloneDeep from 'lodash/cloneDeep';
import remove from 'lodash/remove';
import log from 'loglevel';
import * as ActionIdentifiers from '../configs/ActionIdentifiers';
import Config from '../configs/Config';
import GameBoardUtils from '../utils/GameBoardUtils';

const INITIAL_STATE = {
    normalGameOptionsModalShowRobots: true,
    selfhostedgamereqid: undefined,
    hostedGameArr: [],
    showGameList: 1,
    showMobileTablist: 0,
};

const removeObservableGameFromList = (state, gameid) => {
    state.observableGamesList = (state.observableGamesList || []).filter(
        (item) => item.gid !== gameid
    );
};

const gamelistReducer = (state = INITIAL_STATE, action) => {
    let globalState = get(action, 'globalState');
    switch (action.type) {
        case ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_ROBOTS_SET: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            state.normalGameOptionsModalShowRobots = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_GAME_LIST: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.payload);
            state.showGameList = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_SHOW_MOBILE_GAME_LIST: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.payload);
            state.showMobileTablist = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_HOST_PARAMS_SET: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.hostParams = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);

            let hostedGame = get(action.payload, 'reqJoinHostGame')
                ? state.hostedGame
                : state.hostedGamesList.find(
                      (hostedGameInList) =>
                          String(action.payload.data.reqgameid) ===
                          String(hostedGameInList.gamereqid)
                  );
            if (hostedGame)
                remove(
                    hostedGame.jndplys,
                    get(action.payload, 'reqJoinHostGame')
                        ? { secret: action.payload.secret }
                        : { guid: action.payload.data.guid }
                );
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            state.hostedGamesList =
                get(action.payload, 'data.hostedgames') || [];
            break;
        }

        case ActionIdentifiers.GAME_LIVE_ADD_HOSTED_GAME: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let hostedGamesToBeAdded =
                get(action.payload, 'data.hostedgames') || [];
            if (get(globalState, 'game.game_type') === Config.GAME_TYPE_BLITZ) {
                state.hostedGamesList = hostedGamesToBeAdded;
            } else {
                state.hostedGamesList = state.hostedGamesList || [];
                for (let i = 0; i < hostedGamesToBeAdded.length; i++) {
                    let hostedGameToBeAdded = hostedGamesToBeAdded[i];
                    let fromRating = Number(
                        get(hostedGameToBeAdded, 'fromrating')
                    );
                    let toRating = Number(get(hostedGameToBeAdded, 'torating'));
                    let user_stats = get(globalState, 'user.user_stats');
                    let rating = Number(get(user_stats, 'rating_stats.rating'));
                    let index = state.hostedGamesList.findIndex(
                        (hostedGameInList) =>
                            get(hostedGameInList, 'uid.guid') ===
                            get(hostedGameToBeAdded, 'uid.guid')
                    );
                    if (rating >= fromRating && rating <= toRating) {
                        if (index >= 0) {
                            state.hostedGamesList[index] = hostedGameToBeAdded;
                        } else {
                            state.hostedGamesList.unshift(hostedGameToBeAdded);
                        }
                    } else {
                        if (index >= 0) {
                            state.hostedGamesList.splice(index, 1);
                        }
                    }
                }
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_DELETE_HOSTED_GAME: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gameid =
                get(action.payload, 'gameid') ||
                get(action.payload, 'data.gameid') ||
                get(action.payload, 'data.gamereqid');
            state.hostedGamesList = (state.hostedGamesList || []).filter(
                (hostedGameInList) => hostedGameInList.gamereqid !== gameid
            );
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_GAME_ACTION: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let hostedGameToBeAdded = state.hostParams;
            state.hostedGamesList = state.hostedGamesList || [];
            let index = state.hostedGamesList.findIndex((hostedGameInList) =>
                get(hostedGameInList, 'isSelfHosted')
            );
            hostedGameToBeAdded.uid = get(globalState, 'user.user_info');
            let selfstats = get(globalState, 'user.user_stats');
            hostedGameToBeAdded.rating = get(selfstats, 'rating_stats.rating');
            hostedGameToBeAdded.live = hostedGameToBeAdded.livegame;
            hostedGameToBeAdded.isSelfHosted = true;
            hostedGameToBeAdded.gamereqid = get(action.payload, 'data');
            state.selfhostedgamereqid = hostedGameToBeAdded.gamereqid;
            if (index >= 0) {
                state.hostedGamesList[index] = hostedGameToBeAdded;
            } else {
                state.hostedGamesList.unshift(hostedGameToBeAdded);
            }
            state.hostedGame = hostedGameToBeAdded;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_DELETE_HOSTED_GAME: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gameid =
                get(action.payload, 'gameid') ||
                get(action.payload, 'data.gameid') ||
                state.selfhostedgamereqid;
            state.hostedGamesList = (state.hostedGamesList || []).filter(
                (hostedGameInList) => hostedGameInList.gamereqid !== gameid
            );
            state.selfhostedgamereqid = undefined;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            if (get(globalState, 'game.game_type') === Config.GAME_TYPE_BLITZ) {
                let games = get(action.payload, 'data') || [];
                (games || []).forEach((element) => {
                    element.jndplys.map((item, index) => {
                        item.strokeColor = GameBoardUtils.getBlitzPlayerWiseStrokeColor(
                            index
                        );
                    });
                });
                if (games.length > 0) {
                    state.observableGamesList = games;
                } else {
                    (state.observableGamesList || []).push(games[0]);
                }
            } else {
                let allPlayers = {
                    ...(get(action.payload, 'data.playersinfo') || {}),
                    ...(get(action.payload, 'data.uid') || {}),
                };
                let games = get(action.payload, 'data.games') || [];
                for (let i = 0; i < games.length; i++) {
                    let game = games[i];
                    let players = game.players || [];
                    for (let j = 0; j < players.length; j++) {
                        let player = players[j];
                        player.fullInfo = allPlayers[player.uid];
                    }
                }
                if (Object.keys(get(action.payload, 'data.uid')).length > 0) {
                    state.observableGamesList = games;
                } else {
                    (state.observableGamesList || []).push(games[0]);
                }
            }
            break;
        }

        case ActionIdentifiers.REMOVE_OBSERVABLE_GAME_FROM_LIST_AFTER_GAME_HAS_ENDED: {
            log.info('GameListReducer: ' + action.type);
            state = cloneDeep(state);
            let gameHasEnded = get(globalState, 'game.gameHasEnded');
            let gameid = get(globalState, 'game.gid');
            let gametype = get(globalState, 'game.game_type');

            if (
                !(
                    get(action.payload, 'action') ===
                        Config.RESIGN_GAME_ACTION &&
                    [Config.GAME_TYPE_BLITZ].includes(gametype)
                ) &&
                gameHasEnded &&
                [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(
                    gametype
                )
            ) {
                if (gametype === Config.GAME_TYPE_BLITZ) {
                    state.standingGameData = (
                        state.observableGamesList || []
                    ).find((item) => item.gid === gameid);
                }
                removeObservableGameFromList(state, gameid);
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_OBSERVABLE_GAME_REMOVE: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gameid =
                get(action.payload, 'data.gameid') ||
                get(action.payload, 'data.gid');
            removeObservableGameFromList(state, gameid);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gamereqid =
                get(action.payload, 'gamereqid') || state.hostedGame.gamereqid;
            let jndply = get(action.payload, 'jndply');

            let hostedGameList = state.hostedGamesList || [];
            let hostedGame = hostedGameList.find(
                (item) => gamereqid === item.gamereqid
            );
            if (hostedGame) {
                if (!hostedGame.jndplys) {
                    hostedGame.jndplys = [];
                }
                let plyExist = hostedGame.jndplys.findIndex(
                    (item) => item.guid === jndply.guid
                );
                if (plyExist >= 0) {
                    hostedGame.jndplys[plyExist] = jndply;
                } else {
                    hostedGame.jndplys.push(jndply);
                }
                if (
                    state.hostedGame &&
                    state.hostedGame.gamereqid === gamereqid
                ) {
                    state.hostedGame = hostedGame;
                }
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_JOINED_PLAYER_STATS: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let statsData = action.payload;
            let gameStats = get(statsData, 'data.0.game_stats');
            let ratingStats = get(statsData, 'data.0.rating_stats');
            state.hostedGame = {
                ...state.hostedGame,
                ...(gameStats || {}),
                ...(ratingStats || {}),
                ...(state.hostedGame.playerModal
                    ? {
                          stats: statsData,
                      }
                    : null),
                ...(state.isInvitation
                    ? {
                          rating: get(statsData, 'data.0.rating_stats.rating'),
                      }
                    : null),
            };
            if (state.hostedGameArr.length > 0) {
                state.hostedGameArr[state.hostedGameArr.length - 1] =
                    state.hostedGame;
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_JOIN_DIALOG: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let playerModal = get(action.payload, 'playerModal');
            let gamereqid =
                get(action.payload, 'gamereqid') ||
                get(action.payload, 'reqgameid');
            let hostedGame = action.payload || {};
            if (playerModal) {
                hostedGame = {
                    ...hostedGame,
                    playerModal,
                };
            } else if (gamereqid) {
                let hostedGameList = state.hostedGamesList || [];
                let hGame = hostedGameList.find(
                    (item) => gamereqid === item.gamereqid
                );
                hostedGame = {
                    ...hostedGame,
                    ...hGame,
                };
            }
            let reqJoinHostGame = !!get(action.payload, 'reqJoinHostGame');
            let isInvitation = !!get(action.payload, 'p1uid');
            let secret = get(action.payload, 'secret');
            hostedGame = {
                ...hostedGame,
                ...(isInvitation || reqJoinHostGame
                    ? { uid: get(action.payload, 'sender') || {} }
                    : {}),
                ...(isInvitation
                    ? { live: get(action.payload, 'livegame') || {} }
                    : {}),
                ...(isInvitation || reqJoinHostGame ? { secret } : {}),
                isInvitation,
                reqJoinHostGame,
                ...(isInvitation || reqJoinHostGame
                    ? { startTime: Date.now() }
                    : {}),
            };
            state.hostedGame = hostedGame;
            if (isInvitation || reqJoinHostGame) {
                state.hostedGameArr.push(state.hostedGame);
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            state.hostedGame = {
                ...state.hostedGame,
                ...{ headToHeadData: action.payload },
            };
            if (state.hostedGameArr.length > 0) {
                state.hostedGameArr[state.hostedGameArr.length - 1] =
                    state.hostedGame;
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            state.hostedGame = {
                ...state.hostedGame,
                uniqueWordCount: action.payload,
            };
            if (state.hostedGameArr.length > 0) {
                state.hostedGameArr[state.hostedGameArr.length - 1] =
                    state.hostedGame;
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_ADD_RATING_CHANGE: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let data = get(action.payload, 'data');
            let self = (data || []).find(
                (data) => data.guid === action.globalState.game.guid
            );
            let dr = get(self, 'rating.delta.dr') || '';
            let drParts = dr.split(',');
            state.hostedGame = {
                ...state.hostedGame,
                ratingChange: drParts,
            };
            if (state.hostedGameArr.length > 0) {
                state.hostedGameArr[state.hostedGameArr.length - 1] =
                    state.hostedGame;
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let data = get(action.payload, 'data');
            state.hostedGame = {
                ...state.hostedGame,
                ...data,
                reqJoinHostGame: true,
                startTime: Date.now(),
            };
            state.hostedGameArr.push(state.hostedGame);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            if (get(action.payload, 'timerFinish')) {
                state.hostedGameArr = [];
            } else {
                if (get(action.payload, 'secret')) {
                    remove(state.hostedGameArr, {
                        secret: action.payload.secret,
                    });
                } else {
                    state.hostedGameArr.pop();
                }
            }
            if (state.hostedGameArr.length > 0) {
                state.hostedGame =
                    state.hostedGameArr[state.hostedGameArr.length - 1];
            }
            break;
        }

        case ActionIdentifiers.GAME_BLITZ_JNDPLYS_UPDATE: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gameid = get(action.payload, 'data.gid');

            let gameData = (state.observableGamesList || []).find(
                (game) => game.gid === gameid
            );
            if (gameData) {
                let jndplysUpdate = get(action.payload, 'data.jndplys') || [];
                let jndplys = get(gameData, 'jndplys');
                jndplysUpdate.map((player) => {
                    let playerData = jndplys.find(
                        (p) => p.guid === player.guid
                    );
                    if (playerData) {
                        playerData.score = player.score || playerData.score;
                        playerData.tilesinbag = player.tilesinbag;
                        playerData.lastmovescore = player.lastmovescore || '0';
                        playerData.game_status = player.game_status;
                        playerData.cnseqtvscr = [
                            ...playerData.cnseqtvscr,
                            playerData.lastmovescore,
                        ];
                    }
                });
            }
            break;
        }

        case ActionIdentifiers.GAME_BLITZ_JNDPLY_REMOVE: {
            state = cloneDeep(state);
            log.info('GameListReducer: ' + action.type);
            let gameid = get(action.payload, 'data.gid');
            let jndplysRemove = get(action.payload, 'data.jndplys') || [];

            let gameData = (state.observableGamesList || []).find(
                (game) => game.gid === gameid
            );
            if (gameData) {
                jndplysRemove.map((player) => {
                    let jndplys = get(gameData, 'jndplys').filter(
                        (p) => p.guid !== player.guid
                    );
                    gameData.jndplys = jndplys;
                });
            }
            break;
        }
    }
    return { ...state };
};

export default gamelistReducer;
