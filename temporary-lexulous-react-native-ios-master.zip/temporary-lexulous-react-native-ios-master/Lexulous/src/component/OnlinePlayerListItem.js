import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Config from '../configs/Config';
import ColorConfig from '../configs/ColorConfig';
import GameBoardUtils from '../utils/GameBoardUtils';
import { openUserStatsPage } from '../utils/UrlUtils';
import AvatarImage from './AvatarImage';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import TooltipWrapper from './TooltipWrapper';
import S14Text from './S14Text';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

const eventBus = require('js-event-bus')();
function handleOnPress(event) {
    this.onPress(this.params, event);
}
export default class OnlinePlayerListItem extends React.Component {
    state = {
        showTooltip: false,
    };

    componentDidMount = () => {
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState) =>
        !isEqual(get(this.props, 'item'), get(nextProps, 'item')) ||
        !isEqual(get(this.props, 'rowColor'), get(nextProps, 'rowColor')) ||
        !isEqual(
            get(this.props, 'formattedName'),
            get(nextProps, 'formattedName')
        ) ||
        !isEqual(
            get(this.state, 'showTooltip'),
            get(nextState, 'showTooltip')
        ) ||
        !isEqual(get(this.props, 'statusText'), get(nextProps, 'statusText')) ||
        !isEqual(get(this.props, 'hasBuddyReq'), get(nextProps, 'hasBuddyReq'));

    getStyleForOddIndex = () => ({ backgroundColor: this.props.rowColor });

    getNameTextColorStyle = () => ({
        color: this.props.hasBuddyReq ? 'rgb(177, 46, 56)' : undefined,
    });

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    onPlayerItemPress = async (event) => {
        //event.stopPropagation();
        //event.nativeEvent.stopImmediatePropagation();
        if (
            !(
                this.props.isBoardPage &&
                GameBoardUtils.isMyself(this.props.item)
            )
        ) {
            eventBus.emit(Config.ON_PLAYER_ITEM_SELECTED, null, {
                playerItem: this.props.item,
                onObserveGame: this.props.onObserveGame,
                playerModal: true,
                matchCheckingTab: LiveGamePlayUtils.isBlitzGame()
                    ? false
                    : get(this.props.item, 'status') === 'avl',
                statsTab: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : get(this.props.item, 'status') !== 'avl' ||
                      this.props.isMyself,
                isPlaying: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : get(this.props.item, 'status') === 'ply',
                noMatchChecking: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : this.props.isMyself,
            });
        }
    };

    onOpenUserStatsPage = async (params, event) => {
        //event.stopPropagation();
        //event.nativeEvent.stopImmediatePropagation();
        openUserStatsPage(params);
    };

    render = () => (
        <TouchableOpacity
            key={this.props.item.guid}
            style={[
                styles.button,
                styles.playerListItem,
                this.getStyleForOddIndex(),
                this.props.cursor,
            ]}
            onPress={this.onPlayerItemPress}
        >
            <TooltipWrapper
                onPress={handleOnPress.bind({
                    params: this.props.item,
                    onPress: this.onOpenUserStatsPage,
                })}
                tooltip={'See ' + this.props.formattedName + "'s Profile"}
                onMouseEnter={this.showTooltip}
                onMouseOut={this.hideTooltip}
            >
                <AvatarImage
                    style={[styles.playerImageSmall]}
                    show={this.props.avatarId}
                    uri={this.props.avatarUrl}
                />
            </TooltipWrapper>

            <S14Text
                numberOfLines={1}
                ellipsizeMode={'tail'}
                style={[styles.flexFour, this.getNameTextColorStyle()]}
            >
                {this.props.formattedName}
                {this.props.isMyself ? (
                    <S14Text style={[styles.boldFont]}> (You)</S14Text>
                ) : null}
            </S14Text>
            <S14Text style={styles.playerRatingText}>
                {this.props.rating}
            </S14Text>
            <View style={styles.ratingStyles}>
                <View>
                    <S14Text style={styles.transparent}>Available</S14Text>
                    <S14Text
                        style={[
                            StyleSheet.absoluteFill,
                            styles.playerStatusText,
                        ]}
                    >
                        {this.props.statusText}
                    </S14Text>
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button: {
        //width: 'calc(100% - 20)',
        overflow: 'hidden',
    },
    playerListItem: {
        backgroundColor: ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.PLAYER_LIST_ITEM_BORDER_COLOR,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingTop: 1,
        paddingBottom: 1,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    flexFour: {
        width: '50%',
        flexDirection: 'row',
        alignItems: 'center',
    },
    playerRatingText: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        textAlign: 'left',
    },
    playerStatusText: {
        textAlign: 'left',
    },
    playerImageSmall: {
        height: 16,
        width: 16,
        marginRight: 5,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    ratingStyles: {
        flex: 2,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    transparent: { opacity: 0 },
    boldFont: {
        fontWeight: 'bold',
    },
    playerModalOverlay: {
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        overflow: 'hidden',
    },
});
