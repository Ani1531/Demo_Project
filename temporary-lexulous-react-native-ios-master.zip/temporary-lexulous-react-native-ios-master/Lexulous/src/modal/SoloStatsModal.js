import React from 'react';
import {
    FlatList,
    StyleSheet,
    Text,
    Pressable,
    TouchableOpacity,
    View,
} from 'react-native';
import { getSoloGameStats } from '../service/LiveGamePlayService';
import ColorConfig from '../configs/ColorConfig';
import LayoutUtils from '../utils/LayoutUtils';
import { getDictionaryDetails } from '../utils/GameBoardUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import * as d3 from 'd3-time-format';
import DimensionUtils from '../utils/DimensionUtils';
import { connect } from 'react-redux';
import get from 'lodash/get';
import PText from '../component/PText';
import S22Text from '../component/S22Text';
import S14Text from '../component/S14Text';
import LayoutWrapper from '../utils/LayoutWrapper';

const formatISODateForStatsList = (isoDate) => {
    let formatDate = d3.timeFormat('%d-%b-%Y');
    return formatDate(d3.isoParse(isoDate));
};

class SoloStatsModal extends React.Component {
    state = {
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
    };

    show = async () => {
        this.setState({ isOpen: true });
        getSoloGameStats();
    };

    hide = () => {
        this.setState({ isOpen: false });
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.hide();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width: '70%',
        //maxHeight: '90%',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    render = () =>
        this.state.isOpen &&
        typeof this.props.game.currHintData !== 'undefined' ? (
            <View style={this.getModalContentStyle()}>{this.renderBody()}</View>
        ) : null;

    getCloseButtonBackgroundColor = () => ({
        backgroundColor: this.state.closeBGColor,
    });

    renderBody = () => {
        const { bingos, stats } = this.props.game.currHintData.data;
        return (
            <View
                style={[
                    LayoutUtils.getDialogMainContainerStyle(),
                    this.getModalContainerDimension(),
                ]}
            >
                <View style={LayoutUtils.getDialogTitleContainerStyle()}>
                    <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                        My Bingos
                    </S22Text>
                    <TouchableOpacity
                        style={styles.closeButtonContainer}
                        onPress={this.onCloseButtonClick}
                        onMouseEnter={this.onCloseButtonMouseEnter}
                        onMouseLeave={this.onCloseButtonMouseLeave}
                    >
                        <View
                            style={[
                                this.getCloseButtonBackgroundColor(),
                                LayoutUtils.getDialogCloseButtonBGStyle(),
                            ]}
                        >
                            <FontAwesomeIcon
                                icon={faTimes}
                                size={DimensionUtils.isMobile() ? 20 : 24}
                                style={this.getCloseButtonStyle()}
                            />
                        </View>
                    </TouchableOpacity>
                </View>

                <View style={LayoutUtils.getDialogBodyContainerStyle()}>
                    {this.renderRow({ firstLine: true })}
                    <FlatList
                        renderItem={this.renderRow}
                        data={
                            this.props.game.game_type === 'solo'
                                ? (bingos || []).slice(0, 10)
                                : bingos || []
                        }
                        style={[styles.w100]}
                        contentContainerStyle={{ flexGrow: 1 }}
                    />

                    <View style={styles.gamesPlayedContainer}>
                        <S22Text style={LayoutUtils.getDialogTitleStyle()}>
                            Games Played
                        </S22Text>
                        <View style={styles.gamesPlayedRow1}>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryLabel,
                                        ,
                                    ]}
                                >
                                    French
                                </PText>
                            </View>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryGameCountLabel,
                                        ,
                                    ]}
                                >
                                    {stats.fr}
                                </PText>
                            </View>
                            <View style={styles.textSeperator} />
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryLabel,
                                        ,
                                    ]}
                                >
                                    UK English
                                </PText>
                            </View>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryGameCountLabel,
                                        ,
                                    ]}
                                >
                                    {stats.sow}
                                </PText>
                            </View>
                        </View>
                        <View style={styles.gamesPlayedRow2}>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryLabel,
                                        ,
                                    ]}
                                >
                                    Italian
                                </PText>
                            </View>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryGameCountLabel,
                                        ,
                                    ]}
                                >
                                    {stats.it}
                                </PText>
                            </View>
                            <View style={styles.textSeperator} />
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryLabel,
                                        ,
                                    ]}
                                >
                                    US English
                                </PText>
                            </View>
                            <View style={[styles.flex1]}>
                                <PText
                                    style={[
                                        StyleSheet.absoluteFill,
                                        styles.dictionaryGameCountLabel,
                                        ,
                                    ]}
                                >
                                    {stats.twl}
                                </PText>
                            </View>
                        </View>
                    </View>
                </View>

                <View style={LayoutUtils.getDialogBodyBtnContainerStyle()}>
                    <Pressable
                        style={[
                            LayoutUtils.getDialogActionButtonStyle(),
                            LayoutUtils.getBottonStyle(),
                        ]}
                        onPress={this.hide}
                    >
                        <S14Text style={LayoutUtils.getBottonTextStyle()}>
                            {'CLOSE'}
                        </S14Text>
                    </Pressable>
                </View>
            </View>
        );
    };

    renderRow = ({ item, index, firstLine } = {}) => (
        <View style={[styles.w100]}>
            <View style={[styles.flex1]}>
                <PText
                    style={[
                        StyleSheet.absoluteFill,
                        firstLine
                            ? styles.firstLineFontStyle
                            : styles.normalLineFontStyle,
                    ]}
                >
                    {firstLine ? '#' : index + 1}
                </PText>
            </View>
            <View style={[styles.flex5]}>
                <PText
                    style={[
                        StyleSheet.absoluteFill,
                        firstLine
                            ? styles.firstLineFontStyle
                            : styles.normalLineFontStyle,
                    ]}
                >
                    {firstLine ? 'Word' : item.word}
                </PText>
            </View>
            <View style={[styles.flex4]}>
                <PText
                    style={[
                        StyleSheet.absoluteFill,
                        firstLine
                            ? styles.firstLineFontStyle
                            : styles.normalLineFontStyle,
                    ]}
                >
                    {firstLine ? 'Score' : item.score}
                </PText>
            </View>
            <View style={[styles.flex6]}>
                <PText
                    style={[
                        StyleSheet.absoluteFill,
                        firstLine
                            ? styles.firstLineFontStyle
                            : styles.normalLineFontStyle,
                    ]}
                >
                    {firstLine
                        ? 'Date'
                        : formatISODateForStatsList(item.playtime)}
                </PText>
            </View>
            <View style={[styles.flex3]}>
                <PText
                    style={[
                        StyleSheet.absoluteFill,
                        firstLine
                            ? styles.firstLineFontStyle
                            : styles.normalLineFontStyle,
                    ]}
                >
                    {firstLine
                        ? 'Dictionary'
                        : getDictionaryDetails(item.dictionary).explanation}
                </PText>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    itemCenter: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    firstLineFontStyle: {
        fontWeight: 'bold',
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },

    normalLineFontStyle: {
        fontWeight: 'normal',
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },

    dictionaryLabel: {
        fontWeight: 'bold',
        flex: 1,
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },

    dictionaryGameCountLabel: {
        flex: 1,
        textAlign: 'right',
        color: ColorConfig.DIALOG_MODAL_BODY_TEXT_COLOR,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
    },
    gamesPlayedContainer: {
        width: '100%',
        marginTop: 16,
    },
    gamesPlayedRow1: {
        width: '100%',
        flexDirection: 'row',
        marginTop: 16,
    },
    textSeperator: {
        width: 5,
        height: 0,
    },
    gamesPlayedRow2: {
        width: '100%',
        flexDirection: 'row',
    },
    w100: {
        flexDirection: 'row',
        width: '100%',
    },
    myBingosStyle: { flex: 1, marginTop: 16 },
    fullHeight: { height: '100%' },
    flex1: {
        flex: 1,
        overflow: 'hidden',
        minHeight: 20,
    },
    flex3: {
        flex: 3,
        overflow: 'hidden',
        minHeight: 20,
    },
    flex4: {
        flex: 4,
        overflow: 'hidden',
        minHeight: 20,
    },
    flex5: {
        flex: 5,
        overflow: 'hidden',
        minHeight: 20,
    },
    flex6: {
        flex: 6,
        overflow: 'hidden',
        minHeight: 20,
    },
    flex9: {
        flex: 9,
        overflow: 'hidden',
        minHeight: 20,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    SoloStatsModal
);
