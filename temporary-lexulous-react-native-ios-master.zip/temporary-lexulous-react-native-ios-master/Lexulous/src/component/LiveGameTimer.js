import React from 'react';
import {
    Animated,
    Easing,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import Config from '../configs/Config';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import isNumber from 'lodash/isNumber';
import Timer from 'react-compound-timer';
import { formatToTwoDigits } from '../utils/Utils';
import ColorConfig from '../configs/ColorConfig';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
    faCaretRight,
    faPlusSquare,
    faSignal,
} from '@fortawesome/free-solid-svg-icons';
import {
    isEmailGame,
    isLiveGame,
    isSoloGame,
    moreTime,
} from '../service/GamePlayService';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import TimeRemainingTooltip from './TimeRemainingTooltip';
import PlayerAvatarNameRating from './PlayerAvatarNameRating';
import GameBoardUtils from '../utils/GameBoardUtils';
import SoundUtils from '../utils/SoundUtils';
import { connect } from 'react-redux';
import log from 'loglevel';
import TooltipWrapper from './TooltipWrapper';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();
let resignCalled = false;

{
    /*const CustomTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: ColorConfig.PLAYER_INFO_TOOLTIP_BACKGROUND_COLOR,
        borderWidth: 1,
        borderColor: '#dedede',
    },
    arrow: {
        color: ColorConfig.PLAYER_INFO_TOOLTIP_BACKGROUND_COLOR,
    },
}))(Tooltip);*/
}

function handleMoreTimeOnPress() {
    moreTime({ other: this.guid });
}

function handleMoreTimeOnMouseOver() {
    this.onMoreTimeMouseOver(this.guid);
}

function handleMoreTimeOnMouseOut() {
    this.onMoreTimeMouseOut(this.guid);
}

class LiveGameTimerScoreCard extends React.Component {
    state = {
        tileInBagTxtColor: ColorConfig.LIVE_GAMES_TIMER_CARD_TILES_IN_BAG,
        lastMoveTxtColor: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
        addTimeIconColor:
            ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
    };
    changeTurn = (yPos) =>
        Animated.timing(this.arrowPos, {
            toValue: yPos,
            useNativeDriver: true,
            easing: Easing.linear,
            duration: 500,
        }).start();

    constructor(props) {
        super(props);
        this.lastMoveToolTipRef = React.createRef();
        this.unseenTilesRef = React.createRef();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.setArrowPosition();
        if (
            this.props.config.connectionStatus !== 'connected' ||
            this.props.game.gameHasEnded
        ) {
            this.stopTimers();
        } else {
            (this.props.game.players || []).forEach((player) => {
                if (
                    GameBoardUtils.isPlayerResigned(player) ||
                    this.getCurrentTurn() !== player.pid
                ) {
                    this['player_' + player.pid] &&
                        this['player_' + player.pid].pause();
                } else {
                    this['player_' + player.pid] &&
                        this['player_' + player.pid].start();
                }
            });
        }
    }

    componentDidMount = () => {
        this.setArrowPosition();
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(this.props, nextProps) || !isEqual(this.state, nextState);

    stopTimers = () => {
        (this.props.game.players || []).forEach((playerData) => {
            if (playerData && this['player_' + playerData.pid])
                this['player_' + playerData.pid].pause();
        });
    };

    getScoreTimerMainContainerDimension = () => ({
        width: '100%',
    });

    setArrowPosition = () => {
        let index = (this.props.game.players || []).findIndex(
            (player) =>
                String(player.pid) ===
                String(get(this.props, 'game.currentTurn'))
        );
        let scoreTimerContainerHeightAsNumber =
            this.getScoreTimerContainerHeightAsNumber();
        let pos = scoreTimerContainerHeightAsNumber / 2 - 10;
        switch (index) {
            case 1: {
                pos = scoreTimerContainerHeightAsNumber + pos;
                break;
            }
            case 2: {
                pos = scoreTimerContainerHeightAsNumber * 2 + pos;
                break;
            }
            case 3: {
                pos = scoreTimerContainerHeightAsNumber * 3 + pos;
                break;
            }
        }
        pos = pos || 1;
        log.info('in LiveGameTimer, in setArrowPosition, pos will be: ' + pos);
        this.changeTurn(pos);
    };

    renderTurnView = () => {
        const animatedStyle = [
            {
                position: 'absolute',
                //top: this.arrowPos,
            },
            {
                transform: [
                    {
                        translateY: this.arrowPos,
                    },
                ],
            },
        ];
        return (
            <Animated.View style={animatedStyle}>
                <FontAwesomeIcon
                    size={20}
                    style={{
                        color: '#22B129',
                        width: 8,
                    }}
                    icon={faCaretRight}
                />
            </Animated.View>
        );
    };

    render = () => {
        let players = [
            ...get(this.props, 'game.players', []),
            { viewBoardData: true },
        ];
        return (
            <View
                key={'live-game-timer-container'}
                style={[
                    styles.mainContainer,
                    ...(this.props.lastMoveTilesRemainingOnly
                        ? [styles.topBorders, styles.aboveViewContainerStyles]
                        : [null]),
                    this.getScoreTimerMainContainerDimension(),
                    this.props.isAtBottom
                        ? {
                              borderWidth: undefined,
                              borderColor: undefined,
                              borderBottomWidth: StyleSheet.hairlineWidth,
                              borderBottomColor:
                                  ColorConfig.SIDE_PANEL_BORDER_COLOR,
                          }
                        : null,
                ]}
                key={this.state.key}
            >
                {(
                    (this.props.playersDataOnly &&
                        (players || []).filter(
                            (playerData) => !playerData.viewBoardData
                        )) ||
                    (this.props.lastMoveTilesRemainingOnly && [
                        (players || [])
                            .filter((playerData) => playerData.viewBoardData)
                            .pop(),
                    ]) ||
                    players ||
                    []
                ).map((playerData, index, arr) => {
                    return this.renderPlayerTimerData(playerData, index, arr);
                })}
                {this.props.playersDataOnly ? this.renderTurnView() : null}
            </View>
        );
    };

    getPlayerAvailabilityStatusColorStyleObj = (playerData) => ({
        color: this.getPlayerAvailabilityStatusColor(playerData),
    });

    getPlayerAvailabilityStatusColor = (playerData) => {
        if (
            !this.props.emailGame &&
            playerData.availablity_status === 'Offline'
        ) {
            return '#cccccc';
        } else if (
            this.props.emailGame &&
            playerData.availablity_status === 'Online' &&
            !(this.state.pid === playerData.pid)
        ) {
            return ColorConfig.PLAYER_NAME_COLOR;
        } else {
            return ColorConfig.TRANSPARENT;
        }
    };

    getCurrentTurn = () => this.props.game.currentTurn;

    getPlayerColorStatusStyle = (pid) => styles.nonActivePlayerColor;

    getTimerColorStatusStyle = (playerData) =>
        Number(this['player_' + playerData.pid].getTime() / 1000) < 60
            ? styles.activePlayerColor
            : styles.nonActivePlayerColor;

    getAddTimeColorStatusStyle = (playerData) =>
        this.getCurrentTurn() === playerData.pid &&
        this['player_' + playerData.pid] &&
        Number(this['player_' + playerData.pid].getTime() / 1000) < 60
            ? styles.activePlayerColor
            : { color: this.state.addTimeIconColor };

    getItemFlexPosition = (index) =>
        index < this.props.game.players.length / 2
            ? styles.itemLeftSide
            : styles.itemLeftSide;

    getCurrentScoreStyles = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 2,
        // paddingHorizontal: this.getGeneralPadding() * 2
    });

    getPlayerTimerStyle = (index, arr, playerData) => ({
        borderBottomWidth:
            index === (arr || []).length - 1 ? 0 : StyleSheet.hairlineWidth,
        borderColor:
            index === (arr || []).length - 1
                ? undefined
                : ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor:
            index % 2 === 0
                ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD
                : ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN,
        opacity: GameBoardUtils.isPlayerResigned(playerData) ? 0.5 : undefined,
    });

    getEmailGameContainerStyle = () => [
        !this.props.emailGame
            ? LayoutUtils.getCursorPointerStyle()
            : LayoutUtils.getCursorDefaultStyle(),
        styles.alignItemsCenter,
    ];

    getTimerFontSize = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 2,
    });

    onMoreTimeMouseOver = (guid) => {
        this.setState({
            addTimeIconColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR,
        });
        // this["addTimeTooltipPlayer" + guid].open();
    };

    onMoreTimeMouseOut = (guid) => {
        this.setState({
            addTimeIconColor:
                ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
        });
        // this["addTimeTooltipPlayer" + guid].close();
    };

    getScoreTimerContainerHeightAsNumber = () =>
        Math.round(
            (this.props.layout.boardDimen *
                (DimensionUtils.isMobile() ? 10 : 9)) /
                100
        );

    getScoreTimerContainerHeight = () => ({
        height: this.getScoreTimerContainerHeightAsNumber(),
    });

    arrowPos = new Animated.Value(1);

    renderPlayerTimerData = (playerData, index, arr) => {
        playerData.pid === get(this.props, 'game.pid') &&
            log.info(
                `in LiveGameTimer, in renderPlayerTimerData, playerData is:\n ${JSON.stringify(
                    playerData,
                    null,
                    2
                )}`
            );
        let totalTime = (playerData.timeleftArr || [0]).reduce(
            (acc, nextVal) => acc + nextVal
        );
        let elapsedTime =
            this.props.game.currentTurn === playerData.pid &&
            isNumber(playerData.turnStartTime)
                ? Date.now() - playerData.turnStartTime
                : 0;
        let timeLeft = totalTime * 1000 - elapsedTime;
        if (this['player_' + playerData.pid]) {
            this['player_' + playerData.pid].setTime(timeLeft);
        }
        let players = [...this.props.game.players, { viewBoardData: true }];
        let isTimeAddable =
            this.props.game.gid &&
            this.props.game.pid &&
            this.props.game.pid !== playerData.pid &&
            !GameBoardUtils.isPlayerResigned(playerData) &&
            !this.props.game.gameHasEnded;
        let isObserving = !get(this.props, 'game.pid');
        return (
            <View
                key={'player_timer_data_container_' + index}
                style={[
                    styles.scoreTimerContainer,
                    this.getItemFlexPosition(index),
                    this.getPlayerTimerStyle(index, arr, playerData),
                    this.getScoreTimerContainerHeight(),
                ]}
            >
                <View
                    style={[
                        styles.playerDataContainer,
                        { width: '50%', overflow: 'hidden' },
                    ]}
                >
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            {
                                paddingLeft: 10,
                                alignItems: 'flex-start',
                                justifyContent: 'center',
                                overflow: 'hidden',
                            },
                        ]}
                    >
                        <PlayerAvatarNameRating
                            player={playerData}
                            isBlitz={
                                this.props.game.game_type ===
                                Config.GAME_TYPE_BLITZ
                            }
                            flexDirection={'row'}
                            hideyoutext
                            userRatingPlainStyle
                            getRatingForPlayer={
                                LiveGamePlayUtils.getRatingForPlayer
                            }
                            toggleFriendship={
                                LiveGamePlayUtils.toggleFriendship
                            }
                            toggleBlock={LiveGamePlayUtils.toggleBlock}
                            currentTurn={
                                this.getCurrentTurn() === playerData.pid
                            }
                            guid={this.props.game.guid}
                            solitaire={this.props.solitaire}
                            forSideMenuTimer={true}
                            tooltipID="appTooltip"
                        />
                    </View>
                    {/* {(this.props.game.game_type === 'email' &&
                        playerData.availablity_status === 'Online') ||
                    (!(this.props.game.game_type === 'email') &&
                        playerData.availablity_status === 'Offline') ? (
                        <View style={[{ width: '20%', alignSelf: 'flex-end' }]}>
                            <View style={this.getEmailGameContainerStyle()}>
                                 {!this.props.emailGame ? (
                                    <CustomTooltip
                                        arrow
                                        disableHoverListener={
                                            this.props.emailGame ||
                                            !(
                                                playerData.pid ===
                                                this.getCurrentTurn()
                                            ) ||
                                            !(players || []).some(
                                                (player) =>
                                                    player.guid ===
                                                    this.props.game.guid
                                            )
                                        }
                                        disableFocusListener
                                        disableTouchListener
                                        placement={
                                            index < players.length / 2
                                                ? 'bottom'
                                                : 'bottom'
                                        }
                                        title={
                                            <TimeRemainingTooltip
                                                getPanelFontSize={
                                                    this.getPanelFontSize
                                                }
                                                playerData={playerData}
                                                moveCount={this.moveCount}
                                                isPlaying={(players || []).some(
                                                    (player) =>
                                                        player.guid ===
                                                        this.props.game.guid
                                                )}
                                            />
                                        }
                                    >
                                        <View>
                                            <FontAwesomeIcon
                                                icon={faSignal}
                                                size={
                                                    this.getPanelMiddleLineElementFontSize()
                                                        .fontSize
                                                }
                                                style={{
                                                    ...this.getPlayerAvailabilityStatusColorStyleObj(
                                                        playerData
                                                    ),
                                                    ...this.getPanelMiddleLineElementFontSize(),
                                                }}
                                            />
                                        </View>
                                    </CustomTooltip>
                                ) : ( 
                                <TooltipWrapper
                                    tooltip={playerData.name + ' is online'}
                                >
                                    <FontAwesomeIcon
                                        icon={faSignal}
                                        size={
                                            this.getPanelMiddleLineElementFontSize()
                                                .fontSize
                                        }
                                        style={{
                                            ...this.getPlayerAvailabilityStatusColorStyleObj(
                                                playerData
                                            ),
                                            ...this.getPanelMiddleLineElementFontSize(),
                                        }}
                                    />
                                </TooltipWrapper>
                                 )} 
                            </View>
                        </View>
                    ) : null}*/}
                </View>
                <View
                    style={[
                        styles.scoreDisplayingViewStyle,
                        this.props.game.players.some(
                            (player) =>
                                !!player.timeleft ||
                                GameBoardUtils.isPlayerResigned(player)
                        ) && !this.props.game.showingAnalyseMove
                            ? null
                            : { width: '50%' },
                    ]}
                >
                    <S14Text
                        style={[
                            this.getCurrentTurn() === playerData.pid
                                ? styles.boldFont
                                : null,
                            this.getCurrentScoreStyles(),
                            this.getPlayerColorStatusStyle(playerData.pid),
                        ]}
                    >
                        {GameBoardUtils.getCurrentScore(playerData)}
                    </S14Text>
                </View>
                {this.props.game.players.some(
                    (player) =>
                        !!player.timeleft ||
                        GameBoardUtils.isPlayerResigned(player)
                ) && !this.props.game.showingAnalyseMove ? (
                    !GameBoardUtils.isPlayerResigned(playerData) &&
                    !isEmailGame() ? (
                        <View
                            style={[
                                styles.timerLeftSidePanelStyle,
                                styles.timerContainerAfterBoardData,
                                styles.pr14,
                            ]}
                        >
                            {isLiveGame() && !isObserving ? (
                                isTimeAddable ? (
                                    <TooltipWrapper
                                        onPress={handleMoreTimeOnPress.bind({
                                            guid: playerData.guid,
                                        })}
                                        onMouseOver={handleMoreTimeOnMouseOver.bind(
                                            {
                                                guid: playerData.guid,
                                                onMoreTimeMouseOver:
                                                    this.onMoreTimeMouseOver,
                                            }
                                        )}
                                        onMouseOut={handleMoreTimeOnMouseOut.bind(
                                            {
                                                guid: playerData.guid,
                                                onMoreTimeMouseOut:
                                                    this.onMoreTimeMouseOut,
                                            }
                                        )}
                                        tooltip={'Add 10 seconds'}
                                        style={{ marginLeft: 5 }}
                                    >
                                        <FontAwesomeIcon
                                            icon={faPlusSquare}
                                            size={
                                                this.getPanelFontSize()
                                                    .fontSize *
                                                    1.1 +
                                                4
                                            }
                                            style={{
                                                ...this.getAddTimeColorStatusStyle(
                                                    playerData.pid
                                                ),
                                            }}
                                        />
                                    </TooltipWrapper>
                                ) : (
                                    <FontAwesomeIcon
                                        icon={faPlusSquare}
                                        size={
                                            this.getPanelFontSize().fontSize *
                                                1.1 +
                                            4
                                        }
                                        style={{
                                            opacity: 0,
                                            marginLeft: 5,
                                            ...this.getAddTimeColorStatusStyle(
                                                playerData.pid
                                            ),
                                        }}
                                    />
                                )
                            ) : null}
                            <View>
                                <Timer
                                    key={playerData.pid}
                                    timeToUpdate={1000}
                                    initialTime={timeLeft}
                                    direction="backward"
                                    startImmediately={
                                        this.getCurrentTurn() ===
                                            playerData.pid &&
                                        !get(this.props, 'game.gameHasEnded')
                                    }
                                    lastUnit="m"
                                    checkpoints={
                                        this.props.game.pid === playerData.pid
                                            ? [
                                                  {
                                                      time: 50000,
                                                      callback:
                                                          SoundUtils.errorSound,
                                                  },
                                                  {
                                                      time: 40000,
                                                      callback:
                                                          SoundUtils.errorSound,
                                                  },
                                                  {
                                                      time: 30000,
                                                      callback:
                                                          SoundUtils.errorSound,
                                                  },
                                                  {
                                                      time: 20000,
                                                      callback:
                                                          SoundUtils.errorSound,
                                                  },
                                                  {
                                                      time: 10000,
                                                      callback:
                                                          SoundUtils.errorSound,
                                                  },
                                              ]
                                            : []
                                    }
                                >
                                    {({
                                        start,
                                        pause,
                                        stop,
                                        setTime,
                                        timerState,
                                        getTime,
                                    }) => {
                                        this['player_' + playerData.pid] = {
                                            start,
                                            stop,
                                            pause,
                                            getTime,
                                            setTime,
                                            timerState,
                                        };
                                        if (
                                            isSoloGame() &&
                                            !resignCalled &&
                                            Number(
                                                this[
                                                    'player_' + playerData.pid
                                                ].getTime() / 1000
                                            ) < 0
                                        ) {
                                            resignCalled = true;
                                            eventBus.emit(
                                                Config.EVENT_SOLO_TIME_OVER_RESIGN
                                            );
                                        }
                                        return (
                                            <View
                                                style={[
                                                    styles.timerBeforeBoardData,
                                                    styles.timerOuterPadding,
                                                    styles.pr14,
                                                ]}
                                            >
                                                <S14Text
                                                    style={[
                                                        this.getCurrentTurn() ===
                                                        playerData.pid
                                                            ? styles.boldFont
                                                            : null,
                                                        this.getTimerFontSize(),
                                                        this.getTimerColorStatusStyle(
                                                            playerData
                                                        ),
                                                    ]}
                                                >
                                                    <Timer.Minutes
                                                        formatValue={
                                                            formatToTwoDigits
                                                        }
                                                    />
                                                </S14Text>

                                                <S14Text
                                                    style={[
                                                        this.getCurrentTurn() ===
                                                        playerData.pid
                                                            ? styles.boldFont
                                                            : null,
                                                        styles.pb4,
                                                        this.getTimerFontSize(),
                                                        this.getTimerColorStatusStyle(
                                                            playerData
                                                        ),
                                                    ]}
                                                >
                                                    {':'}
                                                </S14Text>

                                                <S14Text
                                                    style={[
                                                        this.getCurrentTurn() ===
                                                        playerData.pid
                                                            ? styles.boldFont
                                                            : null,
                                                        this.getTimerFontSize(),
                                                        this.getTimerColorStatusStyle(
                                                            playerData
                                                        ),
                                                    ]}
                                                >
                                                    <Timer.Seconds
                                                        formatValue={
                                                            formatToTwoDigits
                                                        }
                                                    />
                                                </S14Text>
                                            </View>
                                        );
                                    }}
                                </Timer>
                            </View>
                        </View>
                    ) : (
                        <View
                            style={[
                                styles.timerContainer,
                                styles.timerLeftSidePanelStyle,
                                styles.playerResignMsgContainer,
                            ]}
                        >
                            <S14Text
                                style={[
                                    this.getPlayerResignMessageFontStyle(),
                                    this.getPlayerColorStatusStyle(
                                        playerData.pid
                                    ),
                                ]}
                            >
                                {GameBoardUtils.getPlayerResignReasonMessage(
                                    playerData,
                                    this.props.game
                                )}
                            </S14Text>
                        </View>
                    )
                ) : null}
            </View>
        );
    };

    getPlayerResignMessageFontStyle = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 1.5,
    });

    getPanelFontSize = () => ({
        //fontSize: this.getScoreTimerMainContainerDimension().width * 0.035,
    });

    getPanelMiddleLineElementFontSize = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 0.9,
    });
}

const styles = StyleSheet.create({
    mainContainer: {
        flexDirection: 'column',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: 0,
        overflow: 'hidden',
        backgroundColor: '#f4f3ef',
    },
    topBorders: {
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
    },
    imageContainer: {
        flex: 1,
        overflow: 'hidden',
        flexDirection: 'column-reverse',
    },
    directionRow: {
        flexDirection: 'row',
    },
    rowContainer: {
        margin: 5,
        width: '100%',
        flex: 1,
        backgroundColor: ColorConfig.PLAYER_INFO_TOOLTIP_BACKGROUND_COLOR,
    },
    image: {
        flex: 1,
    },
    userStatsContainer: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 5,
    },
    playedGamesContainer: {
        flex: 2,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 5,
    },
    heading_style: {
        fontWeight: 'bold',
    },
    scoreTimerContainer: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    scoreTimerContainerForTopBar: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    playerDataContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        height: '100%',
        borderRightColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightWidth: 1,
    },
    textCenter: {
        textAlign: 'center',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    customHeadingFontWeight: {
        fontWeight: '400',
    },
    timerContainer: {
        flex: 1,
    },

    timerContainerAfterBoardData: {
        flexDirection: 'row-reverse',
    },
    timerBeforeBoardData: {
        flexDirection: 'row',
        flex: 2,
        alignItems: 'center',
    },
    timerAfterBoardData: {
        flexDirection: 'row-reverse',
        flex: 2,
        alignItems: 'center',
    },
    iconContainer: {
        flex: 6,
        flexDirection: 'column',
    },
    scoreContainer: {
        borderTopWidth: 1,
        width: '100%',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flex: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    blankSpaceContainer: {},
    boardData: {
        flexDirection: 'column-reverse',
        flex: 1,
    },
    tilesInBag: {
        alignSelf: 'center',
    },
    tilesInBagContainer: {
        flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    lastWordDataContainer: {
        flex: 1,
    },
    lastWordData: {
        fontWeight: 'bold',
        color: '#000',
    },
    activePlayerColor: {
        color: ColorConfig.LIVE_GAMES_TIMER_CARD_ACTIVE_PLAYER_COLOR,
    },

    nonActivePlayerColor: {
        color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
    },
    itemLeftSide: {
        alignItems: 'flex-start',
    },
    itemRightSide: {
        alignItems: 'flex-end',
    },
    row: {
        flexDirection: 'row',
    },

    rowReverse: {
        flexDirection: 'row-reverse',
    },
    timerLeftMargin: {
        marginLeft: 10,
    },
    timerRightMargin: {
        marginRight: 10,
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    toolTipButtonContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    toolTipUsernameAndButtonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%',
    },
    alignItemsCenter: {
        alignItems: 'center',
    },
    playerTilesInHand: {
        flexDirection: 'column',
        alignSelf: 'flex-start',
        color: ColorConfig.PLAYER_TILES_IN_HAND,
    },
    paddingLeftTwo: {
        paddingLeft: 2,
    },
    alignTextCenter: {
        textAlign: 'center',
    },
    playerReverseDataContainer: {
        flexDirection: 'row-reverse',
        flex: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    columnReverse: {
        flexDirection: 'column-reverse',
    },
    tilesInBagMainContainer: {
        alignItems: 'flex-end',
        flex: 1,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    scoreMainContainer: {
        alignItems: 'flex-start',
        justifyContent: 'center',
        flex: 2,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        flexDirection: 'column-reverse',
    },
    aboveViewContainerStyles: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    textColor: {
        color: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
    },
    flexTwoAndHalf: { flex: 2.5 },
    flexOneFifth: { flex: 0.2 },
    scoreDisplayingViewStyle: {
        width: '20%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    timerLeftSidePanelStyle: {
        height: '100%',
        width: '30%',
        alignItems: 'center',
        borderLeftWidth: 1,
        borderLeftColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    timerOuterPadding: { paddingLeft: 8 },
    timerMinutesViewStyle: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    timerSecondsViewStyle: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    firstTurnCountdownStyle: {
        width: 20,
        marginLeft: 3,
    },
    pl3: {
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
    },
    pb4: {
        paddingBottom: 4,
    },
    playerResignMsgContainer: {
        justifyContent: 'center',
    },
    pr14: {
        paddingRight: 10,
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    solitaire: state.solitaire,
    layout: state.layout,
    config: state.config,
});

export default connect(mapStateToProps)(LiveGameTimerScoreCard);
