// @flow

import AppLovinMAX from 'react-native-applovin-max';
import { kBannerAdUnit } from '../Constants';
import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class BannerAd {
    reInit = false;
    onBannerReceive = null;
    onBannerFail = null;
    adAvailable = false;
    adHeight = AppLovinMAX.isTablet() ? 90 : 50;
    adWidth = AppLovinMAX.isTablet() ? 728 : 320;
    yOffset: number = 0;
    constructor() {}
    onAppInit = (): void => {
        AppLovinMAX.addEventListener('OnBannerAdLoadedEvent', this.onBannerAdReceived);
        AppLovinMAX.addEventListener('OnBannerAdLoadFailedEvent', this.onBannerAdFailed);
        AppLovinMAX.setBannerExtraParameter(kBannerAdUnit, 'adaptive_banner', 'false');
        AppLovinMAX.setBannerWidth(kBannerAdUnit, this.adWidth);
        AppLovinMAX.createBannerWithOffsets(kBannerAdUnit, AppLovinMAX.AdViewPosition.BOTTOM_CENTER, 0, -this.adHeight);
        AppLovinMAX.setBannerBackgroundColor(kBannerAdUnit, '#f4f3ef');
    };

    onAppReInit = (): void => {
        this.reInit = false;
        this.onBannerReceive = null;
        this.onBannerFail = null;
        this.adAvailable = false;
        this.yOffset = 0;
        AppLovinMAX.removeEventListener('OnBannerAdLoadedEvent');
        AppLovinMAX.removeEventListener('OnBannerAdLoadFailedEvent');
        AppLovinMAX.destroyBanner(kBannerAdUnit);
        this.onAppInit();
    };

    onBannerAdReceived = (adInfo: any): void => {
        if (this.onUserSettingsUpdate()) {
            return;
        }
        if (this.adAvailable == false) {
            AppLovinMAX.updateBannerOffsets(kBannerAdUnit, 0, this.yOffset);
        }
        this.adAvailable = true;
        if (this.onBannerReceive != null) {
            this.onBannerReceive();
        }
    };

    onBannerAdFailed = (errorInfo: any): void => {
        if (this.adAvailable == true) {
            AppLovinMAX.updateBannerOffsets(kBannerAdUnit, 0, -this.adHeight);
        }
        this.adAvailable = false;
        if (this.onBannerFail != null) {
            this.onBannerFail();
        }
    };

    showBannerAd = (yoffset: number, onBannerReceive: () => void, onBannerFail: () => void): void => {
        if (this.reInit) {
            this.onAppReInit();
        }
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            if (onBannerFail != null) {
                onBannerFail();
            }
            return;
        }
        this.onBannerReceive = onBannerReceive;
        this.onBannerFail = onBannerFail;
        this.yOffset = yoffset;
        AppLovinMAX.showBanner(kBannerAdUnit);
        if (this.adAvailable) {
            if (this.onBannerReceive != null) {
                this.onBannerReceive();
                AppLovinMAX.updateBannerOffsets(kBannerAdUnit, 0, this.yOffset);
            }
        } else {
            if (this.onBannerFail != null) {
                this.onBannerFail();
            }
        }
    };

    hideBannerAd = (): void => {
        AppLovinMAX.updateBannerOffsets(kBannerAdUnit, 0, -this.adHeight);
        AppLovinMAX.hideBanner(kBannerAdUnit);
        this.onBannerReceive = null;
        this.onBannerFail = null;
    };

    invalidateBanner = (): void => {
        this.reInit = true;
        this.hideBannerAd();
        AppLovinMAX.destroyBanner(kBannerAdUnit);
    };

    onUserSettingsUpdate = (): boolean => {
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            if (this.onBannerFail != null) {
                this.onBannerFail();
                this.hideBannerAd();
                return true;
            }
        }
        return false;
    };
}

const bannerAd: BannerAd = new BannerAd();

export default bannerAd;
