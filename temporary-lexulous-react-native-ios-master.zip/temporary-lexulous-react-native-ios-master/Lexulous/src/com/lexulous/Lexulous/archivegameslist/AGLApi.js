// @flow

import dataServer from '../store/Store';
import * as CONSTANTS from '../commons/Constants';
import { rjLog } from '../commons/RJUtils.js';
import * as PFLSelector from '../userprofile/PFLSelector';
import requestManager from '../commons/RequestManager';
const qs = require('qs');

class AGLApi {
    fetchArchiveGamesList = (skip: number, timestamp: number) => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        let suuid = PFLSelector.getUUID(dataServer.getStore().getState());

        let data = {
            [CONSTANTS.kParamChannel]: CONSTANTS.kChannel,
            [CONSTANTS.kParamGuid]: sguid,
            [CONSTANTS.kParamUuid]: suuid,
            [CONSTANTS.kParamAction]: CONSTANTS.kActionArchiveGamesList,
            epoch: '0',
            currenttime: timestamp.toString(),
            skip: skip.toString(),
            limit: CONSTANTS.aglFetchLimit,
        };

        let params: string = qs.stringify({
            [CONSTANTS.kParams]: JSON.stringify(data),
        });
        rjLog(params, 'archivegameslist');
        return requestManager.axiosinst({
            url: CONSTANTS.kArchiveGamesListApiPath,
            data: params,
        });
    };
}
const aglApi = new AGLApi();
export default aglApi;
