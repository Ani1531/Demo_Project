import * as ActionIdentifiers from '../configs/ActionIdentifiers';

export const connectivityChanged = (res) => ({
    type: ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_LOST,
    payload: res,
});

export const connectivityReducerConnectionReestablished = (res) => ({
    type: ActionIdentifiers.CONNECTIVITY_REDUCER_CONNECTION_RECONNECTED,
    payload: res,
});

export const connectivityReducerConnectionReconnecting = (res) => ({
    type:
        ActionIdentifiers.CONNECTIVITY_REDUCER_WEBSOCKET_CONNECTION_RECONNECTING,
    payload: res,
});

export const connectivityReducerGameDuplicateConnectionOccurrence = (res) => ({
    type:
        ActionIdentifiers.CONNECTIVITY_REDUCER_DUPLICATE_CONNECTION_OCCURRENCE,
    payload: res,
});

export const connectivityReducerRestartServer = (res) => ({
    type: ActionIdentifiers.CONNECTIVITY_REDUCER_RESTART_SERVER,
    payload: res,
});
