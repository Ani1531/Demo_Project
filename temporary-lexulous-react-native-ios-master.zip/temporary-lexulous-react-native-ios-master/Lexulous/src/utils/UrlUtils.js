import { getNull } from './Utils';

export const getAvatarUrl = () => getNull;

export const openUserStatsPage = () => getNull;

export const openUserGiftsPage = () => getNull;

export const openPurchaseProPage = () => getNull;

export const replaceLocation = () => getNull;

export const spawnWindow = () => getNull;

export const getChatAttachmentUrl = () => getNull;

export const proChangeUrl = () => getNull;
