import { getNull } from './Utils';

export default class TooltipActionWrapper {
static rebuild = () => getNull;
static hide = () => getNull;
}