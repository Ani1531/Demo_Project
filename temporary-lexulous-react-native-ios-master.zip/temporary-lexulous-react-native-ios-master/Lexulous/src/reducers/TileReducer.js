import get from 'lodash/get';
import * as ActionIdentifiers from '../configs/ActionIdentifiers';
import GameBoardUtils, { getRackData } from '../utils/GameBoardUtils';
import Config from '../configs/Config';
import { generateUUID } from '../utils/StringUtils';
import isString from 'lodash/isString';
import cloneDeep from 'lodash/cloneDeep';
import isBoolean from 'lodash/isBoolean';
import isArray from 'lodash/isArray';
import { CELL_REDUCER_EMPTY_GAMEBOARD } from '../configs/ActionIdentifiers';

const INITIAL_STATE = {
    tileBeingDragged: undefined,
    rackArr: [],
    players: [],
};

const getRack = () => {
    let rackArr = [];
    let data = Config.SOLO_CREATE_BOARD_CELL;
    for (let i = 0; i < data.length; i++) {
        let letter = data[i];
        let tile = GameBoardUtils.tileCreation(letter);
        rackArr.push(tile);
    }
    return rackArr;
};

const getPuzzleRack = (globalState, result) => {
    let queryString = 'data.' + get(globalState, 'game.channel') + '.boarddata.rackinfo';
    let data = get(result, queryString) || '';
    // Harcode to test letter picker -
    // data = "*" + data.substring(1);
    if (!isString(data) || data.length < 1) return null;

    let rackArr = [];
    for (let i = 0; i < data.length; i++) {
        let letter = data.charAt(i);
        let tile = GameBoardUtils.tileCreation(letter);
        rackArr.push(tile);
    }
    while (rackArr.length < Config.RACK_LENGTH_INCLUDING_EMPTY_SPACE) {
        //For empty space at the end of Rack
        let emptySpaceObj = {
            id: generateUUID(),
            isEmptySpace: true,
        };
        rackArr.push(emptySpaceObj);
    }
    //Rack Array creation
    return rackArr;
};

const getCellDirectionTileX = (globalState) => get(globalState, 'cells.directionPositionX');

const getCellDirectionTileY = (globalState) => get(globalState, 'cells.directionPositionY');

const tileReducer = (state = INITIAL_STATE, action) => {
    let type = get(action, 'type');
    let payload = get(action, 'payload');
    let globalState = get(action, 'globalState');
    let messageObj = get(action, 'payload');
    let tiles = undefined;
    let caller = undefined;

    switch (type) {
        case ActionIdentifiers.RELOAD_APP: {
            state = cloneDeep(state);
            state.tileBeingDragged = undefined;
            state.puzzleIsComplete = undefined;
            state.players = [];
            state.rackArr = [];
            break;
        }
        case ActionIdentifiers.GAME_TILE_BEING_DRAGGED: {
            state = cloneDeep(state);
            let idToMatch = get(get(payload, 'tileBeingDragged') || get(state, 'tileBeingDragged'), 'id');
            state.puzzleIsComplete = get(payload, 'puzzleIsComplete') || state.puzzleIsComplete;
            let tileInCurrentRack = getTiles({ globalState, state }).find((tile) => get(tile, 'id') === idToMatch);
            if (tileInCurrentRack) {
                Object.assign(
                    tileInCurrentRack,
                    !payload.unset
                        ? {
                              zIndex: 10,
                              opacity: 1,
                              borderWidth: 1,
                          }
                        : {
                              zIndex: undefined,
                              opacity: undefined,
                              borderWidth: undefined,
                          }
                );
            }
            state.tileBeingDragged = payload.unset ? undefined : payload.tileBeingDragged;
            let tiles = get(action, 'payload.tiles');
            if (tiles) {
                updateTiles({ action, state, globalState, tiles });
            }
            break;
        }
        case ActionIdentifiers.GAME_STARTED:
        case ActionIdentifiers.GAME_MOVE:
        case ActionIdentifiers.GAME_HAS_ENDED: {
            state = cloneDeep(state);
            state.rackArr = getPuzzleRack(globalState, messageObj);

            let { data, action } = messageObj || {};

            let playersInData =
                get(data, get(globalState, 'game.channel') + '.players') ||
                get(messageObj, 'players') ||
                get(data, 'data.' + get(globalState, 'game.channel') + '.players') ||
                [];
            let players =
                (Config.SET_PLAYER_COUNT_ACTIONS.includes(action) || get(globalState, 'showingAnalyseMove')
                    ? playersInData
                    : state.players) || [];
            for (let i = 0; i < players.length; i++) {
                let player = players[i];
                let playerInData = (playersInData || []).find(
                    (playerInPlayersInData) => playerInPlayersInData.pid === player.pid
                );

                if (
                    !!get(playerInData, 'currentrack') &&
                    (get(player, 'currentrack') !== get(playerInData, 'currentrack') || !player.currentRackArr)
                ) {
                    player.currentRackArr = getRackData(get(playerInData, 'currentrack'));
                    player.currentrack = get(playerInData, 'currentrack');
                }
            }
            state.players = players;
            break;
        }
        case ActionIdentifiers.CELL_REDUCER_ON_TILE_CLICKED: {
            state = cloneDeep(state);
            let payload = get(action, 'payload');

            let { tileType } = payload;

            let globalState = get(action, 'globalState');
            let tiles = getTiles({
                state,
                globalState,
                includeEmptySpace: true,
            });
            let tileFromArr = (tiles || []).find((tileInArr) => get(tileInArr, 'id') === get(tileType, 'id'));

            let x = getCellDirectionTileX(globalState);
            let y = getCellDirectionTileY(globalState);
            let queryString = `layout.cellDimensions.${x}.${y}`;

            let cell = get(globalState, queryString);

            if (cell) {
                if (!!tileFromArr) {
                    tileFromArr.position = {
                        x: cell.tileX,
                        y: cell.tileY,
                        cellStartPositionX: cell.tileStartXUnscaledUnoffset,
                        cellEndPositionX: cell.tileEndXUnscaledUnoffset,
                        cellStartPositionY: cell.tileStartYUnscaledUnoffset,
                        cellEndPositionY: cell.tileEndYUnscaledUnoffset,
                        cellStartPositionXAdjusted: cell.tileStartX,
                        cellEndPositionXAdjusted: cell.tileEndX,
                        cellStartPositionYAdjusted: cell.tileStartY,
                        cellEndPositionYAdjusted: cell.tileEndY,
                    };
                    tileFromArr.placed = true;
                    tileFromArr.getLetter = tileType.getLetter;
                    tileFromArr.opacity = 0;
                }
            }

            break;
        }
        case ActionIdentifiers.UPDATE_TILES_AND_SET_CELL:
        case ActionIdentifiers.GAME_REDUCER_UPDATE_TILES: {
            state = cloneDeep(state);
            if (get(action, 'payload.caller') === 'TileOnTileRelease') {
                if (
                    (get(state, 'tileBeingDragged.id') || '').length > 0 &&
                    get(state, 'tileBeingDragged.id') === get(action, 'payload.tile.id')
                )
                    state.tileBeingDragged = undefined;
            }
            if (get(action, 'payload.isCreateBoard')) {
                state.rackArr = getRack();
            } else {
                caller = get(action, 'payload.tiles.caller') || get(action, 'payload.caller');
                tiles = get(action, 'payload.tiles.rack') || get(action, 'payload.rack');
                updateTiles({ action, state, globalState, tiles });
            }
            break;
        }
        case ActionIdentifiers.GAME_INITIALISE_TILES_FOR_CREATE_BOARD: {
            state = cloneDeep(state);
            state.rackArr = getRack();
            break;
        }

        case ActionIdentifiers.REDUCER_ON_TILE_REMOVED: {
            state = cloneDeep(state);
            let tileOrTiles = get(action, 'payload.tileOrTiles');

            if (!isArray(tileOrTiles)) tileOrTiles = [tileOrTiles];

            let doEmptyBlankTile = get(action, 'payload.doEmptyBlankTile');

            if (!isBoolean(doEmptyBlankTile)) doEmptyBlankTile = true;

            let globalState = get(action, 'globalState');
            let tiles = getTiles({ globalState, state, action });

            for (let i = 0; i < tileOrTiles.length; i++) {
                let tileType = tileOrTiles[i];
                let tile = (tiles || []).find((tile) => get(tile, 'id') === get(tileType, 'id'));
                if (tile) {
                    if (tile.isBlankTile && doEmptyBlankTile) {
                        tile.currentLetter = undefined;
                    }
                    tile.position = undefined;
                    tile.zIndex = undefined;
                    tile.opacity = undefined;
                    tile.borderWidth = undefined;
                    tile.placed = false;
                }
            }

            updateTiles({ action, state, globalState, tiles });

            break;
        }

        case ActionIdentifiers.REDUCER_UPDATE_BLANK_TILE_LETTER: {
            state = cloneDeep(state);
            let tiles = getTiles({ action, globalState, state });
            let tile = get(action, 'payload.tile');
            for (let i = 0; i < tiles.length; i++) {
                let tileType = tiles[i];
                if (get(tileType, 'id') === get(tile, 'id')) Object.assign(tileType, tile);
            }
            updateTiles({ action, state, globalState, tiles });
            break;
        }

        case CELL_REDUCER_EMPTY_GAMEBOARD: {
            if (!!get(action, 'payload.letNonLockedTilesRemain')) break;
            let tiles = getTiles({ action, globalState, state }) || [];
            for (let i = 0; i < tiles.length; i++) {
                let tile = tiles[i];
                tile.position = undefined;
                tile.placed = undefined;
                tile.zIndex = undefined;
                tile.opacity = undefined;
                tile.borderWidth = undefined;
                if (tile.isBlankTile) tile.currentLetter = undefined;
            }
            updateTiles({ action, state, globalState, tiles });
            state.tileBeingDragged = undefined;
            break;
        }

        case ActionIdentifiers.REDUCER_UPDATE_MOUSE_MOVE_TILE: {
            state = cloneDeep(state);
            state.selectedTile = get(payload, 'tileType');
            if (state.selectedTile) {
                let tileInCurrentRack = getTiles({
                    globalState,
                    state,
                }).find((tile) => get(tile, 'id') === get(state, 'tileBeingDragged.id'));
                if (tileInCurrentRack) {
                    Object.assign(tileInCurrentRack, {
                        zIndex: undefined,
                        opacity: undefined,
                        borderWidth: undefined,
                    });
                }
                state.tileBeingDragged = undefined;
            }
            break;
        }
    }

    return state;
};

const updateTiles = ({ action, state, globalState, tiles } = {}) => {
    if (get(state, 'rackArr')) {
        state.rackArr = tiles;
    } else {
        let pid = get(action, 'payload.pid') || get(globalState, 'game.pid') || get(globalState, 'game.currentTurn');
        let player = (state.players || []).find((player) => player.pid === pid) || {};
        player.currentRackArr = tiles;
    }
};

const getTiles = ({ action, state, globalState } = {}) => {
    if (get(state, 'rackArr')) {
        return state.rackArr;
    } else {
        let pid = get(action, 'payload.pid') || get(globalState, 'game.pid') || get(globalState, 'game.currentTurn');
        let player = (state.players || []).find((player) => player.pid === pid) || {};
        return player.currentRackArr;
    }
};

export default tileReducer;
