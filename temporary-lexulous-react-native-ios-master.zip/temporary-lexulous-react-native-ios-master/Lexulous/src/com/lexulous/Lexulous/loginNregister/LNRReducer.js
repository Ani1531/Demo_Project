// @flow

import type { LNRVwProps, LNRVwAction } from '../commons/RJTypes';
import { LRN_UPDT_UNAME, LRN_UPDT_LGN_INFO, LRN_UPDT_EMAIL, LRN_CLR_DATA } from './LNREventTypes';

const LNRInitState: LNRVwProps = {
    lrnVwLgnInfo: {
        authuser: null,
        authsecret: null,
        uid: null,
        email: null,
    },
};

export default function LNRReducer(state: LNRVwProps = LNRInitState, taction: LNRVwAction) {
    switch (taction.type) {
        case LRN_UPDT_UNAME: {
            let lgninfo = state.lrnVwLgnInfo;
            let dd = {
                lrnVwLgnInfo: {
                    ...lgninfo,
                    ...{ authuser: taction.payload },
                },
            };
            let data = { ...state, ...dd };
            return data;
        }
        case LRN_UPDT_LGN_INFO: {
            let lgninfo = state.lrnVwLgnInfo;
            let dd = {
                lrnVwLgnInfo: {
                    ...lgninfo,
                    ...taction.payload,
                },
            };
            let data = { ...state, ...dd };
            return data;
        }
        case LRN_UPDT_EMAIL: {
            let lgninfo = state.lrnVwLgnInfo;
            let dd = {
                lrnVwLgnInfo: {
                    ...lgninfo,
                    ...{ email: taction.payload },
                },
            };
            let data = { ...state, ...dd };
            return data;
        }
        case LRN_CLR_DATA: {
            return LNRInitState;
        }
        default:
            return state;
    }
}
