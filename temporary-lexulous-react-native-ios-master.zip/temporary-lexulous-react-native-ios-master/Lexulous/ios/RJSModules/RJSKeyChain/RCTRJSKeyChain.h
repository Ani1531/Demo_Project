//
//  RCTRJSKeyChain.h
//  Lexulous
//
//  Created by Balaram Singh on 31/12/21.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

NS_ASSUME_NONNULL_BEGIN

#define SERVICE_NAME @"rjscomlexulous"
#define GROUP_NAME @""

@interface RCTRJSKeyChain : NSObject<RCTBridgeModule>

@property (nonatomic,strong)NSString *service;
@property (nonatomic,strong)NSString *group;

//-(BOOL) insert:(NSString *)key data:(NSData *)data;
//-(BOOL) update:(NSString*)key data:(NSData*) data;
//-(BOOL) remove: (NSString*)key;
//-(NSData*) find:(NSString*)key;

@end

NS_ASSUME_NONNULL_END
