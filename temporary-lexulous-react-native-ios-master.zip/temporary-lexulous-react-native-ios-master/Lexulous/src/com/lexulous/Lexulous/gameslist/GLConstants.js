// @flow

//export const kPsistRvwTrgCnt = 'j7JYqNnB';
//export const kPsistShrTrgCnt = 'DTWsa8hq';
//export const kDefaultReviewCount = 4;
//export const kDefaultShareCount = 4;
//export const kDefaultRvwShrResetCount = 12;

export const reviewShareStateType = {
    ReviewShareStateUnknown: 0,
    ReviewViewStateInited: 1,
    ReviewViewStateFeedback: 2,
    ReviewViewStateAppstoreReview: 3,
    ShareViewStateInited: 4,
    ShareViewStateInvite: 5,
};
Object.freeze(reviewShareStateType);
