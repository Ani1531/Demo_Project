import Config from '../configs/Config';
import { getCallType, isEmailGame, pingPolling } from './GamePlayService';
import to from 'await-to-js';
import { getCustomMessage } from '../utils/MessageUtils';
import GameBoardUtils from '../utils/GameBoardUtils';
import get from 'lodash/get';
import once from 'lodash/once';
import { findAndRemove } from '../utils/Utils';
import WebSocketProvider from '../provider/WebSocketProvider';
import {
    GAME_HAS_ENDED,
    GAME_MOVE,
    GAME_MOVE_COUNT_SET,
    GAME_LIVE_GAME_BUDDY_LIST,
    GAME_SOLO_GAME_SEND_GAME_START_DATA,
    GAME_HINT_WORD_LIST_READY,
    GAME_SOLO_GAME_CURRENT_HINT_DATA,
    GAME_SOLO_SAVED_RULES,
    GAME_LIVE_HOST_ADD_RATING_CHANGE,
} from '../configs/ActionIdentifiers';
import store from '../store';
import cloneDeep from 'lodash/cloneDeep';
import zip from 'lodash/zip';
import log from 'loglevel';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import DimensionUtils from '../utils/DimensionUtils';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import ServiceWrapper from '../utils/ServiceWrapper';

const eventBus = require('js-event-bus')();

const getCommonLiveGameParams = () => {
    const state = store.getState();
    return state.game.game_type === Config.GAME_TYPE_SOLO
        ? null
        : {
              channel: state.game.channel,
              guid: state.game.guid,
              uuid: state.game.uuid,
              gid: state.game.gid,
              pid: state.game.pid,
          };
};

export const livePingPolling = async () => {
    pingPolling();
};

export const sendLiveGameMove = async (moveArr) => {
    const state = store.getState();
    let game_type = state.game.game_type;
    let requestMethod = getCallType('send');

    let params = {
        action: Config.SEND_LIVE_GAME_MOVE_DATA_ACTION,
        move: moveArr,
        pid: state.game.pid,
        mxscr: String(state.game.maxScore),
        ...getCommonLiveGameParams(),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        let moveTiles =
            get(res[1], state.game.channel + '.boarddata.movetiles') ||
            get(res[1], 'data.' + state.game.channel + '.boarddata.movetiles') ||
            [];
        let moveCount = (state.game.moveCount || 0) + moveTiles.length;
        let currentTurn = get(res[1], state.game.channel + '.current_turn');
        if (currentTurn === undefined || currentTurn === null) {
            currentTurn = get(res[1], 'data.' + state.game.channel + '.current_turn');
        }
        let winner = get(res[1], state.game.channel + '.winner');
        eventBus.emit(GAME_MOVE_COUNT_SET, null, moveCount);
        GameBoardUtils.setTilesInBag(res[1]);
        GameBoardUtils.setPlayerSelfCurrentScore(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        eventBus.emit(GAME_MOVE, null, res[1]);
        eventBus.emit(Config.SEND_LIVE_GAME_MOVE_SUCCESSFUL, null, res[1]);
        if (game_type === Config.GAME_TYPE_SOLO) {
            if (state.game.sourceType === Config.SOLO_SOURCE_ROBOT && currentTurn && currentTurn === '2' && !winner) {
            }
        } else {
        }
    }

    return res[1];
};

export const checkRatingChange = async (other) => {
    const state = store.getState();
    let requestMethod = getCallType(isEmailGame() ? 'getEmailGameStats' : 'send');
    let params = {
        channel: state.game.channel,
        action: Config.CHECK_RATING_CHANGE_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        other,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_LIVE_HOST_ADD_RATING_CHANGE, null, res[1]);
        return res[1];
    }
};

export const passMoveLiveGame = async () => {
    const state = store.getState();
    let game_type = state.game.game_type;
    let requestMethod = getCallType('send');
    let params = {
        action: Config.PASS_MOVE_ACTION,
        mxscr: String(state.game.maxScore),
        ...getCommonLiveGameParams(),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    if (
        [Config.GAME_TYPE_SOLO, Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL].includes(game_type)
    ) {
        eventBus.emit(GAME_MOVE, null, res[1]);
        if (state.game.sourceType === Config.SOLO_SOURCE_ROBOT) {
        }
    }

    return res[1];
};

export const sendLiveSwapTilesRequest = async (tiles) => {
    const state = store.getState();
    let game_type = state.game.game_type;
    let requestMethod = getCallType('send');

    let params = {
        action: Config.SWAP_TILES_ACTION,
        swaptiles: GameBoardUtils.makeRackString(tiles),
        mxscr: String(state.game.maxScore),
        ...getCommonLiveGameParams(),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.SWAP_TILES_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const resignLiveGame = async (doDelete = false) => {
    const state = store.getState();
    let game_type = state.game.game_type;
    let requestMethod = getCallType('send');

    let params = {
        action: doDelete ? Config.DELETE_GAME : Config.RESIGN_GAME_ACTION,
        ...getCommonLiveGameParams(),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(doDelete ? Config.DELETE_GAME_REQUEST_FAILED : Config.RESIGN_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        GameBoardUtils.setDatas(res[1]);
        res[1].gameover_reason = 'RESIGN';
        res[1].isSelfResign = true;
        eventBus.emit(GAME_HAS_ENDED, null, res[1]);
        eventBus.emit(doDelete ? Config.DELETE_GAME_REQUEST_SUCCESSFUL : Config.RESIGN_GAME_REQUEST_SUCCESSFUL, null, res[1]);
    }

    return res[1];
};

export const getBuddyList = async () => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: Config.GET_BUDDY_LIST_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.buddyListUpdate(get(res[1], 'data'));
    }

    return res[1];
};

export const getBuddyListOnce = once(getBuddyList);

export const addToBuddyList = async (player) => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: Config.ADD_TO_BUDDY_LIST_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        other: get(player, 'guid') || get(player, 'uid'),
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        extObj.player = player;
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.addRemoveBuddyUpdate(true, player);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            ServiceWrapper.sendFriendRequest(player);
        }
    }

    return res[1];
};

export const removeFromBuddyList = async (player) => {
    const state = store.getState();
    let buddyList = cloneDeep(state.user.buddyList) || {};

    let isFriend = (get(buddyList, 'buddies') || []).some((buddy) => buddy.guid === (player.guid || player.uid));
    let isRequestSentButNotAccepted = (get(buddyList, 'reqsent') || []).some(
        (buddy) => buddy.guid === (player.guid || player.uid)
    );
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action:
            (isFriend && Config.REMOVE_FROM_BUDDY_LIST_CONFIRMED_REQUEST_ACTION) ||
            (isRequestSentButNotAccepted && Config.REMOVE_FROM_BUDDY_LIST_REQUESTED_REQUEST_ACTION),
        guid: state.game.guid,
        uuid: state.game.uuid,
        other: get(player, 'guid') || get(player, 'uid'),
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        extObj.player = player;
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.addRemoveBuddyUpdate(false, player);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            if (isFriend) {
                ServiceWrapper.removeFriend(player);
            } else if (isRequestSentButNotAccepted) {
                ServiceWrapper.cancelFriendRequest(player);
            }
        }
    }

    return res[1];
};

export const lobbyChatSendMessage = async (message, receiver) => {
    let requestMethod = getCallType('send');
    let params = {
        action: Config.LOBBY_CHAT_ACTION,
        message: message,
        receiver: receiver,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }
    return res[1];
};

export const sendSoloGameStartData = async (params) => {
    eventBus.emit(Config.LOADER_OVERLAY, null, {
        caller: 'LiveGamePlayService.sendSoloGameStartData',
        visible: true,
        transparentLoader: true,
    });
    let requestMethod = getCallType('send');
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }
    log.info(
        'in GamePlayService, in LiveGamePlayService, emitting GAME_SOLO_GAME_SEND_GAME_START_DATA, res[1] is:\n' +
            JSON.stringify(res[1], null, 2)
    );
    eventBus.emit(GAME_SOLO_GAME_SEND_GAME_START_DATA, null, res[1]);
    return res[1];
};

export const sendSavedSoloGameStart = async (gid) => {
    const state = store.getState();
    eventBus.emit(Config.LOADER_OVERLAY, null, {
        caller: 'LiveGamePlayService.sendSavedSoloGameStart',
        visible: true,
        transparentLoader: true,
    });

    let requestMethod = getCallType('send');
    let params = {
        action: Config.GET_GAME_FEED_REQUEST_ACTION,
        gid: gid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    let channel = state.game.channel;
    let current_turn = res[1].data[channel].current_turn;
    if (current_turn === '2') {
        getRobotMove();
    } else {
        eventBus.emit(GAME_SOLO_GAME_SEND_GAME_START_DATA, null, res[1]);
        return res[1];
    }
};

export const getRobotMove = async () => {
    const state = store.getState();
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_GET_ROBOT_MOVE,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        let moveTiles =
            get(res[1], state.game.channel + '.boarddata.movetiles') ||
            get(res[1], 'data.' + state.game.channel + '.boarddata.movetiles') ||
            [];
        let moveCount = (state.game.moveCount || 0) + moveTiles.length;
        let currentTurn = get(res[1], 'data.' + state.game.channel + '.current_turn');
        let winner = get(res[1], 'data.' + state.game.channel + '.winner');
        GameBoardUtils.setTilesInBag(res[1]);
        GameBoardUtils.setPlayerSelfCurrentScore(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        eventBus.emit(GAME_MOVE, null, { ...res[1], fromRobotMove: true });
        eventBus.emit(Config.SEND_LIVE_GAME_MOVE_SUCCESSFUL, null, res[1]);
    }
    return res[1];
};

export const getHints = async () => {
    eventBus.emit(Config.GET_HINTS_REQUEST_STARTING);
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_GET_HINTS,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        let moveSet = get(res[1], 'data.1.moveset');

        let wordList = await GameBoardUtils.getWordsFromMoveSet({
            moveSet,
            gameBoard: zip(...get(store.getState(), 'cells.cells')),
        });

        eventBus.emit(GAME_HINT_WORD_LIST_READY, null, wordList);
        return res[1];
    }
};

export const getSoloGameStats = async () => {
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_GET_STATS,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(GAME_SOLO_GAME_CURRENT_HINT_DATA, null, null);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_SOLO_GAME_CURRENT_HINT_DATA, null, res[1]);
        return res[1];
    }
};

export const getCustomSavedBoard = async (saveType) => {
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_GET_SAVED_BOARD,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        if (res[1]) {
            let data = res[1];
            data.saveType = saveType;
            eventBus.emit(GAME_SOLO_SAVED_RULES, null, data);
        }
        return res[1];
    }
};

export const saveCreateGameData = async (params) => {
    params.action = Config.ACTION_SOLO_SAVE_CREATE_GAME;

    let requestMethod = getCallType('send');
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    return res;
};

export const editSlotGameData = async (slotId) => {
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_SLOT_GAME_EDIT,
        slotid: slotId,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }
    return res[1];
};

export const getRandomBoard = async () => {
    let requestMethod = getCallType('send');
    let params = {
        action: Config.ACTION_SOLO_GET_RANDOM_BOARD,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        return res[1];
    }
};
