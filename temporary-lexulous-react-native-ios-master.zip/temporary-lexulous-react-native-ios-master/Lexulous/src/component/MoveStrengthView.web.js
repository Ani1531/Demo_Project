import React from 'react';
import LinearGradient from 'react-native-web-linear-gradient';

export default class MoveStrengthView extends React.Component {
    render = () => (
        <LinearGradient
            colors={this.props.colors}
            style={{
                height: this.props.percentage + '%',
            }}
        />
    );
}
