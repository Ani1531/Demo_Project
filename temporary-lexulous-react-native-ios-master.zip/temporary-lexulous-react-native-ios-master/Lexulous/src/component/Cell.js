import React, { Fragment } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import debounce from 'lodash/debounce';
import GameBoardUtils from '../utils/GameBoardUtils';
import ColorConfig from '../configs/ColorConfig';
import DimensionUtils from '../utils/DimensionUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faArrowDown, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import LayoutWrapper from '../utils/LayoutWrapper';
import { connect } from 'react-redux';
import { CELL_REDUCER_SET_DIRECTION, CELL_REDUCER_SET_TILE } from '../configs/ActionIdentifiers';
import log from 'loglevel';
import S14Text from './S14Text';
import S12Text from './PText';
import LayoutUtils from '../utils/LayoutUtils';
import { getBoardCenterIcon } from '../utils/Utils';

const MULTIPLIER = LayoutWrapper.isSafariMobile() ? 4 : 1;
const eventBus = require('js-event-bus')();

const boardThemeArray = ['Lexulous', 'Classic', 'Adventure', 'Essence', 'Spirit', 'Dark'];

class Cell extends React.Component {
    makeRevealOpaque = debounce(() => this.setState({ hideTile: false }), 300);

    constructor(props) {
        super(props);
        let idStr = this.props.idStr;
        this.rootRef = React.createRef();
        let posInfo = idStr.substring(4);
        let posArr = posInfo.split('_');
        this.state = {
            tileX: Number(posArr[0]),
            tileY: Number(posArr[1]),
        };
    }

    tileOnPress = () => {
        if (!!this.getCurrentTile()) {
            if (!this.isLocked()) {
                eventBus.emit(CELL_REDUCER_SET_TILE, null, {
                    caller: 'tileOnPress',
                    position: { x: this.state.tileX, y: this.state.tileY },
                    locked: undefined,
                    tile: undefined,
                });
            } else {
                this.makeRevealTransparent();
            }
        }
    };

    shouldComponentUpdate = (nextProps, nextState) => {
        let ret =
            ((get(this.props, 'tileDrag.cellDraggedToX') !== get(nextProps, 'tileDrag.cellDraggedToX') ||
                get(this.props, 'tileDrag.cellDraggedToY') !== get(nextProps, 'tileDrag.cellDraggedToY')) &&
                [get(this.props, 'tileDrag.cellDraggedToX'), get(nextProps, 'tileDrag.cellDraggedToX')].includes(
                    nextState.tileX
                ) &&
                [get(this.props, 'tileDrag.cellDraggedToY'), get(nextProps, 'tileDrag.cellDraggedToY')].includes(
                    nextState.tileY
                )) ||
            this.state.hideTile !== nextState.hideTile ||
            this.getDirection(nextProps) !== this.getDirection() ||
            /* !isEqual(get(this.getCellData(), 'currentTile.id'), get(this.getCellData(nextProps), 'currentTile.id')) ||
            !isEqual(
                get(this.getCellData(), 'currentTile.currentLetter'),
                get(this.getCellData(nextProps), 'currentTile.currentLetter')
            ) ||
            !isEqual(
                get(this.getCellData(), 'currentTile.forRevealSolution'),
                get(this.getCellData(nextProps), 'currentTile.forRevealSolution')
            ) ||
            !isEqual(get(this.getCellData(), 'hidden'), get(this.getCellData(nextProps), 'hidden')) || */
            this.props.config.numbered_plain !== nextProps.config.numbered_plain ||
            get(this.props, 'config.theme') !== get(nextProps, 'config.theme') ||
            get(this.props, 'layout.layoutCellDimen') !== get(nextProps, 'layout.layoutCellDimen') ||
            !isEqual(this.getCellData(), this.getCellData(nextProps)) ||
            !isEqual(get(this.props, 'config.gp_brdcntrimg'), get(nextProps, 'config.gp_brdcntrimg'));
        return ret;
    };

    shouldShowTileDragOverlay = () =>
        !!get(this.props, 'tileDrag.cellDraggedToX') &&
        !!get(this.props, 'tileDrag.cellDraggedToY') &&
        isEqual(get(this.props, 'tileDrag.cellDraggedToX'), this.state.tileX) &&
        isEqual(get(this.props, 'tileDrag.cellDraggedToY'), this.state.tileY) &&
        !get(this.getCurrentTile());

    shouldShowNumberedPlain = () => get(this.props, 'config.numbered_plain');

    onDirectionSet = (direction, showArrow = true) => {
        eventBus.emit(CELL_REDUCER_SET_DIRECTION, null, {
            position: { x: this.state.tileX, y: this.state.tileY },
            direction,
            showArrow,
            ...(this.props.isCreateBoard
                ? {
                      createBoard: {
                          selectedTile: this.props.tiles.selectedTile,
                      },
                  }
                : undefined),
        });
    };

    getDirection = (props = this.props) => (this.hasDirection(props) ? get(props, 'cells.direction') : undefined);

    hasDirection = (props = this.props) =>
        props.cells.directionPositionX === this.state.tileX && props.cells.directionPositionY === this.state.tileY;

    shouldShowTile = () => this.hasTile() && !this.isHidden();

    makeRevealTransparent = () => {
        this.setState({ hideTile: true });
        this.makeRevealOpaque();
    };

    getDirectionIconStyleObj = () => {
        let isDarkMode = boardThemeArray[[(get(this.props, 'config.theme') || '').split('-')[0] || 0]] === 'Dark';
        let isStar =
            this.state.tileX === Math.floor(get(this.props, 'cells.cells').length / 2) &&
            this.state.tileY === Math.floor(get(this.props, 'cells.cells').length / 2);
        return {
            color: isDarkMode /* && !isStar */ ? ColorConfig.WHITE : ColorConfig.BLACK,
            fontSize: this.getCellDimen() * 0.9,
            zIndex: 10,
        };
    };

    getStarIconSizeStyle = () => this.getCellDimen() * MULTIPLIER * 0.9;

    getStarIconStyleObj = () => {
        return {
            color:
                boardThemeArray[[(get(this.props, 'config.theme') || '').split('-')[0] || 0]] === 'Dark'
                    ? '#ffffff'
                    : ColorConfig.STAR_BACKGROUND_COLOR,
            position: 'absolute',
            height: '75%', //this.getCellDimen(),
            width: '75%', //this.getCellDimen(),
        };
    };

    getContainerStyles = () => {
        let boardDimen = get(this.props, 'cells.cells').length;
        return {
            height: get(this.props, 'layout.layoutCellDimen') + (this.state.tileY === boardDimen - 1 ? 1 : 0),
            width: get(this.props, 'layout.layoutCellDimen') + (this.state.tileX === boardDimen - 1 ? 1 : 0),
            flex: 1,
            borderRightWidth: this.state.tileX === boardDimen - 1 ? StyleSheet.hairlineWidth : 0,
            borderBottomWidth: this.state.tileY === boardDimen - 1 ? StyleSheet.hairlineWidth : 0,
            backgroundColor: GameBoardUtils.getCellBackgroundColor({
                shouldShowTile: false,
                forRevealSolution: get(this.getCurrentTile(), '.currentTforRevealSolution'),
                isLocked: false,
                isDefaultCell:
                    this.state.tileX === Math.floor(boardDimen / 2) && this.state.tileY === Math.floor(boardDimen / 2),
                specialCellType: get(this.props, 'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.positionType'),
                boardTheme:
                    boardThemeArray[
                        (((get(this.props, 'config.theme') || '').length === 3 &&
                            (get(this.props, 'config.theme') || '').split('-')) ||
                            [])[0] || 0
                    ],
            }),
        };
    };

    getBgColorStyles = () => ({
        backgroundColor: this.props.isCreateBoard
            ? GameBoardUtils.getCellBackgroundColor({
                  specialCellType: this.getLetter(true),
              })
            : ColorConfig.RACK_TILE_BACKGROUND_COLOR,
    });

    getCellData = (props = this.props) => get(props, `cells.cells.${this.state.tileX}.${this.state.tileY}`);

    getCellType = () => get(this.getCellData(), 'positionType');

    isHidden = () =>
        this.state.hideTile || get(this.props, 'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.hidden');

    getCurrentTile = () => get(this.props, 'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.currentTile');

    getCellDimen = () => get(this.props, 'layout.layoutCellDimen');

    getStarStyles = () => ({
        height: this.getCellDimen() * MULTIPLIER,
        width: this.getCellDimen() * MULTIPLIER,
    });

    getNumberPlainTextStyles = () => ({
        color: GameBoardUtils.getCellTextColor(this.getCellType()),
        fontSize: (this.getCellDimen() * MULTIPLIER) / 2.75,
    });

    getTilesScoreStyles = () => ({
        bottom: (this.getCellDimen() * MULTIPLIER) / (DimensionUtils.isMobile() ? 30 : 12),
        right: (this.getCellDimen() * MULTIPLIER) / (DimensionUtils.isMobile() ? 30 : 12),
        fontSize: this.getCellDimen() * MULTIPLIER * 0.2833,
    });

    getCurrentTileLetterStyles = () => ({
        fontSize: (this.getCellDimen() * MULTIPLIER * 2) / 3,
    });

    getStyleForCellLetterFlex = () =>
        this.getCurrentTile().isBlankTile || this.props.isCreateBoard
            ? styles.flexOne
            : GameBoardUtils.getTileBasicScore(this.getCurrentTile()) > 9
            ? styles.flexTwo
            : GameBoardUtils.getTileBasicScore(this.getCurrentTile()) > 1
            ? styles.flexFour
            : styles.flexSix;

    getInnerViewStyle = () =>
        this.props.isCreateBoard
            ? this.getCustomInnerViewStyle()
            : {
                  backgroundColor: GameBoardUtils.getCellBackgroundColor({
                      shouldShowTile: true,
                      forRevealSolution: get(this.getCurrentTile(), 'forRevealSolution'),
                      isLocked: this.isLocked(),
                      isDefaultCell:
                          this.state.tileX === Math.floor(get(this.props, 'game.board_size') / 2) &&
                          this.state.tileY === Math.floor(get(this.props, 'game.board_size') / 2),
                      specialCellType: get(
                          this.props,
                          'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.positionType'
                      ),
                      boardTheme:
                          boardThemeArray[
                              (((get(this.props, 'config.theme') || '').length === 3 &&
                                  (get(this.props, 'config.theme') || '').split('-')) ||
                                  [])[0] || 0
                          ],
                  }),
                  borderColor: GameBoardUtils.getCellBorderColor({
                      shouldShowTile: true,
                      forRevealSolution: get(this.getCurrentTile(), 'forRevealSolution'),
                      isLocked: this.isLocked(),
                      isDefaultCell:
                          this.state.tileX === Math.floor(get(this.props, 'game.board_size') / 2) &&
                          this.state.tileY === Math.floor(get(this.props, 'game.board_size') / 2),
                      specialCellType: get(
                          this.props,
                          'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.positionType'
                      ),
                      boardTheme:
                          boardThemeArray[
                              (((get(this.props, 'config.theme') || '').length === 3 &&
                                  (get(this.props, 'config.theme') || '').split('-')) ||
                                  [])[0] || 0
                          ],
                  }),
                  borderWidth: StyleSheet.hairlineWidth,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
              };

    getCustomInnerViewStyle = () => ({
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
    });

    getTextStyle = () => {
        let cellTextColor = GameBoardUtils.getTheme().tileRackKey;
        if (this.getCurrentTile().forRevealSolution) {
            cellTextColor = GameBoardUtils.getTheme().tileLastPlayedKey;
        } else {
            cellTextColor = this.isLocked() ? GameBoardUtils.getTheme().tilePlayedKey : GameBoardUtils.getTheme().tileRackKey;
        }
        return { color: cellTextColor };
    };

    render = () => (
        <TouchableOpacity
            ref={this.rootRef}
            activeOpacity={1}
            style={[
                styles.doubleTap,
                styles.itemCenter,
                this.getContainerStyles(),
                ...(this.hasTile() && !this.isHidden()
                    ? [
                          this.getCurrentTile().forRevealSolution
                              ? styles.reveal_cell
                              : this.isLocked()
                              ? styles.locked_cell
                              : [styles.placed_cell, this.getBgColorStyles()],
                      ]
                    : []),
            ]}
            onPress={this.onSingleTap}
        >
            {!!this.getDirection() && this.props.cells.showArrow && !this.hasTile() ? (
                <FontAwesomeIcon
                    size={this.getDirectionIconStyleObj().fontSize}
                    style={{ ...this.getDirectionIconStyleObj() }}
                    icon={this.getDirection() === 'x' ? faArrowRight : faArrowDown}
                />
            ) : null}

            {this.shouldShowTile() ? (
                <View style={[StyleSheet.absoluteFill, this.getInnerViewStyle()]}>
                    {this.props.isCreateBoard ? (
                        <S14Text
                            class={'smooth_font'}
                            style={
                                DimensionUtils.isMobile()
                                    ? [
                                          styles.text,
                                          LayoutUtils.getCursorPointerStyle(),
                                          this.getNumberPlainTextStyles(),
                                          {
                                              fontSize: Math.max(5, (this.getCellDimen() * MULTIPLIER) / 2.75),
                                          },
                                          this.getTextStyle(),
                                      ]
                                    : [
                                          styles.text,
                                          LayoutUtils.getCursorPointerStyle(),
                                          this.getNumberPlainTextStyles(),
                                          this.getTextStyle(),
                                      ]
                            }
                        >
                            {this.getLetter(true)}
                        </S14Text>
                    ) : (
                        <S14Text
                            class={'smooth_font'}
                            style={[
                                get(this.getCurrentTile(), 'isBlankTile') ? styles.locked_text_red : this.getTextStyle(),
                                //LayoutUtils.getCursorPointerStyle(),
                                this.getCurrentTileLetterStyles(),
                                this.getStyleForCellLetterFlex(),
                                styles.textAlignCenterAlignSelfCenter,
                            ]}
                        >
                            {this.getLetter(true)}
                        </S14Text>
                    )}
                    {get(this.getCurrentTile(), 'isBlankTile') || this.props.isCreateBoard ? null : (
                        <S14Text
                            class={'smooth_font'}
                            style={[
                                //LayoutUtils.getCursorPointerStyle(),
                                this.getTilesScoreStyles(),
                                styles.bottomScoreText,
                                this.getTextStyle(),
                            ]}
                        >
                            {GameBoardUtils.getTileBasicScore(this.getCurrentTile())}
                        </S14Text>
                    )}
                </View>
            ) : this.state.tileX === Math.floor(get(this.props, 'cells.cells').length / 2) &&
              this.state.tileY === Math.floor(get(this.props, 'cells.cells').length / 2) ? (
                <FontAwesomeIcon
                    size={this.getStarIconSizeStyle()}
                    icon={getBoardCenterIcon()}
                    style={this.getStarIconStyleObj()}
                />
            ) : this.shouldShowNumberedPlain() && this.getCellType() ? (
                DimensionUtils.isMobile() ? (
                    <S12Text
                        style={[
                            styles.text,
                            styles.postionAbsolute,
                            this.getNumberPlainTextStyles(),
                            DimensionUtils.isMobile()
                                ? {
                                      fontSize: Math.max(5, (this.getCellDimen() * MULTIPLIER) / 2.75),
                                  }
                                : null,
                        ]}
                    >
                        {this.getCellType()}
                    </S12Text>
                ) : (
                    <S14Text
                        style={[
                            styles.text,
                            styles.postionAbsolute,
                            LayoutUtils.getCursorPointerStyle(),
                            this.getNumberPlainTextStyles(),
                            DimensionUtils.isMobile() ? styles.mobileFontSizeOverride : null,
                        ]}
                    >
                        {this.getCellType()}
                    </S14Text>
                )
            ) : null}
            {this.shouldShowTileDragOverlay() ? (
                <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.15)' }]} />
            ) : null}
        </TouchableOpacity>
    );

    getLetter = (render = false) => {
        if (render) {
            return (
                this.getCurrentTile().letter ||
                (this.getCurrentTile().currentLetter && this.getCurrentTile().currentLetter.toUpperCase())
            );
        } else {
            return (
                this.getCurrentTile().letter ||
                (this.getCurrentTile().currentLetter && this.getCurrentTile().currentLetter.toLowerCase())
            );
        }
    };

    isLocked = () => get(this.props, 'cells.cells.' + this.state.tileX + '.' + this.state.tileY + '.locked');

    hasTile = () => !!this.getCurrentTile();

    onTileSet = () => undefined;

    onInsideTilesPress = () => {
        let direction = undefined;
        if (!this.getDirection()) {
            direction = 'x';
        } else if (this.getDirection() && this.getDirection() === 'x') {
            direction = 'y';
        } else if (this.getDirection() && this.getDirection() === 'y') {
            direction = undefined;
        }
        this.onDirectionSet(direction);
    };

    onTerminalTilesPress = () => {
        let direction = undefined;
        let board_size = get(this.props, 'game.board_size');
        if (Number(this.state.tileX) === board_size - 1) {
            //on press of extreme right end tiles
            if (!this.getDirection()) {
                direction = 'y';
            } else if (this.getDirection() && this.getDirection() === 'y') {
                direction = undefined;
            }
            this.onDirectionSet(direction);
        } else if (Number(this.state.tileY) === board_size - 1) {
            //on press of extreme bottom end tiles
            if (!this.getDirection()) {
                direction = 'x';
            } else if (this.getDirection() && this.getDirection() === 'x') {
                direction = undefined;
            }
            this.onDirectionSet(direction);
        }
    };

    onSingleTap = () => {
        this.rootRef.current.blur();
        let board_size = get(this.props, 'game.board_size');
        if (!!this.getCurrentTile()) {
            this.tileOnPress();
        } else if (
            !this.isLocked() &&
            Number(this.state.tileX) !== board_size - 1 &&
            Number(this.state.tileY) !== board_size - 1
        ) {
            this.onInsideTilesPress();
        } else if (
            !this.isLocked() &&
            (Number(this.state.tileX) === board_size - 1 || Number(this.state.tileY) === board_size - 1)
        ) {
            this.onTerminalTilesPress();
        }
    };
}

let styles = StyleSheet.create({
    doubleTap: {
        overflow: 'hidden',
        borderColor: ColorConfig.CELL_BORDER_COLOR,
        borderRightColor: ColorConfig.CELL_BORDER_COLOR,
        borderTopColor: ColorConfig.CELL_BORDER_COLOR,
        borderLeftColor: ColorConfig.CELL_BORDER_COLOR,
        borderBottomColor: ColorConfig.CELL_BORDER_COLOR,
        borderWidth: 0,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    mainContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    dropZone: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    locked_text: {
        color: ColorConfig.LOCKED_TEXT_COLOR,
    },
    reveal_cell_text_style: {
        color: ColorConfig.JUST_PLAYED_TILE_TEXT_COLOR,
    },
    locked_text_red: {
        color: ColorConfig.LOCKED_TEXT_RED_COLOR,
        fontWeight: 'bold',
    },
    locked_cell: {
        backgroundColor: ColorConfig.LOCKED_CELL_BACKGROUND_COLOR,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
    },
    placed_cell: {
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
    },
    reveal_cell: {
        backgroundColor: '#22b129',
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
    },
    text: {
        alignSelf: 'center',
        justifyContent: 'center',
        //fontSmoothing: 'antialiased',
    },
    imageContent: {
        opacity: 0.5,
        padding: '10px',
    },
    mobileFontSizeOverride: {
        fontSize: 10 * MULTIPLIER,
    },

    star: {
        top: MULTIPLIER,
        left: -MULTIPLIER,
        overflow: 'hidden',
        color: ColorConfig.STAR_BACKGROUND_COLOR,
    },
    starLayout: {
        top: MULTIPLIER,
        left: -MULTIPLIER,
    },
    postionAbsolute: {
        position: 'absolute',
    },

    itemCenter: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    flexOne: { flex: 1 },
    flexTwo: { flex: 2 },
    flexFour: { flex: 4 },
    flexSix: { flex: 6 },

    bottomScoreText: {
        paddingRight: 1,
        textAlign: 'center',
        alignSelf: 'flex-end',
    },

    absoluteHundered: {
        position: 'absolute',
        height: '100%',
        width: '100%',
    },

    textAlignCenterAlignSelfCenter: {
        textAlign: 'center',
        alignSelf: 'center',
    },
});

const mapStateToProps = (state, props) => ({
    cells: state.cells,
    tiles: state.tiles,
    config: state.config,
    layout: state.layout,
    tileDrag:
        props.tileX === get(state, 'tileDrag.cellDraggedToX') && props.tileY === get(state, 'tileDrag.cellDraggedToY')
            ? state.tileDrag
            : undefined,
});

export default connect(mapStateToProps)(Cell);
