import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { connect } from 'react-redux';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';

class ScoreToBeatPanel extends React.Component {
    state = { showNextPuzzleView: undefined };

    constructor(props) {
        super(props);
        this.state = {
            showNextPuzzleView: false,
            cellDimen: this.props.cellDimen,
            puzzleTarget: '',
            myScore: '',
            scoreToBeat: '',
            aiScore: '',
        };
    }

    onBoardDimensionsSet = (dimensions) => {
        this.setState(dimensions);
    };

    getPanelTitleBarPaddingStyles = () => ({
        padding: this.props.layout.layoutSidePanelTitleBarPadding,
    });

    getPanelBodyPaddingStyles = () => ({
        padding: this.props.layout.layoutSidePanelBodyPadding,
    });

    getPanelFontSizeStyles = () => ({
        fontSize: this.props.layout.layoutSidePanelFontSize,
    });

    render = () => (
        <View style={[styles.container, styles.additionalStyles]}>
            {/* Score To Beat Heading */}
            <View style={[this.getPanelTitleBarPaddingStyles()]}>
                <S14Text
                    style={[
                        styles.heading,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {this.state.puzzleTarget}
                </S14Text>
            </View>
            <View
                style={[styles.dataContainer, this.getPanelBodyPaddingStyles()]}
            >
                <S14Text
                    style={[
                        styles.challengeScoreLabel,
                        styles.panelWidthStyles,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {'My Score'}
                </S14Text>
                <S14Text
                    style={[
                        styles.challengeScore,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {this.props.game.myScore}
                </S14Text>
            </View>
            <View
                style={[styles.dataContainer, this.getPanelBodyPaddingStyles()]}
            >
                <S14Text
                    style={[
                        styles.challengeScoreLabel,
                        styles.panelWidthStyles,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {'Score To Beat'}
                </S14Text>
                <S14Text
                    style={[
                        styles.challengeScore,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {this.props.game.scoreToBeat}
                </S14Text>
            </View>
            <View
                style={[this.getPanelBodyPaddingStyles(), styles.dataContainer]}
            >
                <S14Text
                    style={[
                        styles.challengeScoreLabel,
                        styles.panelWidthStyles,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {'AI Score'}
                </S14Text>
                <S14Text
                    style={[
                        styles.challengeScore,
                        this.getPanelFontSizeStyles(),
                        LayoutUtils.getCursorDefaultStyle(),
                    ]}
                >
                    {this.props.game.aiScore}
                </S14Text>
            </View>
            <View style={styles.seperationLineStyle} />
        </View>
    );
}

const styles = StyleSheet.create({
    challengeScore: {
        color: ColorConfig.SIDE_PANEL_SECONDARY_TEXT_COLOR,
        alignSelf: 'flex-end',
    },
    challengeScoreLabel: {
        color: ColorConfig.SIDE_PANEL_SECONDARY_TEXT_COLOR,
        alignSelf: 'flex-start',
    },
    dataContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    heading: {
        color: ColorConfig.SIDE_PANEL_HEADING_TEXT_COLOR,
        fontWeight: 'bold',
        alignSelf: 'center',
    },
    container: {
        width: '100%',
        overflow: 'hidden',
        marginBottom: Config.SIDE_PANEL_WRAPPER_PADDING,
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        flexDirection: 'column',
    },
    additionalStyles: {
        borderBottomRightRadius: 0,
        borderBottomLeftRadius: 0,
    },
    panelWidthStyles: { width: '50%' },
    seperationLineStyle: {
        borderTopWidth: 1,
        borderTopColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
});

const mapStateToProps = (state) => ({ layout: state.layout, game: state.game });

export default connect(mapStateToProps)(ScoreToBeatPanel);
