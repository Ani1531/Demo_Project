// @flow

export const CLR_ARCHIVE_GAMES: string = 'CLR_ARCHIVE_GAMES';
export const ADD_ARCHIVE_GAMES: string = 'ADD_ARCHIVE_GAMES';
export const AGL_REFRESH_STARTED: string = 'AGL_REFRESH_STARTED';
