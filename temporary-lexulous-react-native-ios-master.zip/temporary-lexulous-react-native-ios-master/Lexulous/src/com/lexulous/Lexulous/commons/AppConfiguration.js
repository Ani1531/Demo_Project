// @flow

import type { AppCfg, SourceType } from './RJTypes';

class AppConfiguration {
    getAppConfiguration = (param: string | null = null): AppCfg | null => {
        return null;
    };
    getSharePlugin = (): string | null => null;
    getFriendsPlugin = (): string | null => null;
    getInvitePlugin = (): string | null => null;
    getPinappPlugin = (): string | null => null;
    getPurchasePlugin = (): string | null => null;
    getQuitAppPlugin = (): string | null => null;
    getProductProtill = (): string | null => null;
    getProductAnalysetill = (): string | null => null;
    getApplicationSource = (): SourceType | null => null;
    getBlindGamePlugin = (): string | null => null;
    getOnBlindGameMovePlugin = (): string | null => null;
    getUpdateContextStorePlugin = (): string | null => null;
    getNotifyContextStorePlugin = (): string | null => null;
}
const appConfiguration: AppConfiguration = new AppConfiguration();

export default appConfiguration;
