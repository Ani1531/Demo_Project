import React from 'react';
import { View } from 'react-native';

export default class TabPanel extends React.Component {
    render = () => {
        const { children, value, index } = this.props;
        return value !== index ? null : (
            <View style={this.props.style}>{children}</View>
        );
    };
}
