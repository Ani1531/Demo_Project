# DEVELOPMENT ENVIRONMENT SETUP FOR WINDOWS 10 PRO 

* ### Nvm, Node, JDK Setup
---
 1) [Install NVM version 1.1.9](https://docs.microsoft.com/en-us/windows/dev-environment/javascript/nodejs-on-windows)
 2) [Install node version 14.17.6 using NVM](https://www.sitepoint.com/quick-tip-multiple-versions-node-nvm/)
 3) [Install Jdk 8](https://javacodepoint.com/jdk-installation-on-windows-operating-system/)
 4) [Install Android Studio](https://developer.android.com/studio)
---

 * ### [Required Setup for Android Studio](https://reactnative.dev/docs/0.63/environment-setup#:~:text=Android%20development%20environment)
```
 1) Android Sdk Platform 29
 2) Andriod 10(Q)
 3) Intel * 86 Atom-64 System Image
 4) Android SDK Build-Tools 29.0.2
```
---
*  ### [Set Environment Variables](https://reactnative.dev/docs/0.63/environment-setup#:~:text=3.%20Configure%20the%20ANDROID_HOME%20environment%20variable)
```
 - Configure the ANDROID_HOME environment variable- e.g. C:\Users\Admin\AppData\Local\Android\Sdk
 - Add platform-tools to Path- e.g. C:\Users\Admin\AppData\Local\Android\Sdk\platform-tools
 - Add tools to Path- e.g. C:\Users\Admin\AppData\Local\Android\Sdk\tools
 - Add emulator to Path- e.g. C:\Users\Admin\AppData\Local\Android\Sdk\emulator
 - Add tools\bin to Path- e.g. C:\Users\Admin\AppData\Local\Android\Sdk\tools\bin
```
---
*  ### Others

 1) [Download and install Smartgit](https://www.syntevo.com/smartgit/)
 2) [Login to gitlab and create SSH key then Clone the project in Smartgit](https://gitlab.rjs.in/users/sign_in)
 3) [Install Vs-Code Editor as IDE](https://code.visualstudio.com/download)
 4) Import project in VS-code
 5) [Create an emulator with the help of Virtual Device Manager](https://developer.android.com/studio/run/managing-avds)
 ---
 


# CLEANUP PREVIOUS ENVIRONMENT 

| Script              | Usage                    |
| ------------------- | ------------------------ |
| npm run env:cleanup | clean any prevoius build |

---

# ANDROID 

| Script                   | Usage                                                                                                |
| ------------------------ | ---------------------------------------------------------------------------------------------------- |
| npm run env:android:dev  | run once or if any change to env file is made                                                        |
| npm run android          | run once or if changes are made to project settings file like build.gradle, npm install/update, etc. |
|                          |                                                                                                      |
| npm run env:android:prod | run once or if any change to env file is made                                                        |
| npm run android          | run once or if changes are made to project settings file like build.gradle, npm install/update, etc. |

---

# IOS 

| Script               | Usage                                                                                                      |
| -------------------- | ---------------------------------------------------------------------------------------------------------- |
| npm run env:ios:dev  | run once or if any change to env file is made                                                              |
| npm run ios          | run once or if changes are made to project settings file like targets,info.plist, pod install/update, etc. |
|                      |                                                                                                            |
| npm run env:ios:prod | run once or if any change to env file is made                                                              |
| npm run ios          | run once or if changes are made to project settings file like targets,info.plist, pod install/update,etc.  |

---

# DESKTOP MAC 

| Script                 | Usage                                                    |
| ---------------------- | -------------------------------------------------------- |
| npm run env:mac:dev    | run once or if any change to env file is made            |
| npm run build          | build for web first of if any changes made to index.html |
| npm run build-electron | copy electron environment files                          |
| npm run package        | build executable                                         |
|                        |                                                          |
| npm run env:mac:prod   | run once or if any change to env file is made            |
| npm run build          | build for web first of if any changes made to index.html |
| npm run build-electron | copy electron environment files                          |
| npm run package        | build executable                                         |
---
# FBINSTANT 

| Script                     | Usage                                                    |
| -------------------------- | -------------------------------------------------------- |
| npm run env:fbinstant:dev  | run once or if any change to env file is made            |
| npm run build              | build for web first of if any changes made to index.html |
| npm run web                | run as needed                                            |
|                            |                                                          |
| npm run env:fbinstant:prod | run once or if any change to env file is made            |
| npm run build              | build for web first of if any changes made to index.html |
| npm run web                | run as needed                                            |

---

# Notes 

> Check for equivalent command for Windows OS from package.json file
---