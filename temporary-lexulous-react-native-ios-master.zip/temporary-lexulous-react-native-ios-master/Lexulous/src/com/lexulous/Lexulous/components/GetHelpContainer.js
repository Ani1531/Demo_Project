// @flow

import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle } from '@fortawesome/pro-light-svg-icons';
import { translate } from '../commons/translations/LangTransator';
import themeConfigutation from '../commons/ThemeConfiguration';

type GetHelpContainerProps = {
    closePopupHandler: () => void,
    tutorialHandler: () => void,
    userForumHandler: () => void,
    cstmSupportHandler: () => void,
    userPrivacyHandler: () => void,
};

class GetHelpContainer extends React.Component<GetHelpContainerProps> {
    getTutorial = () => {
        this.props.tutorialHandler();
        this.props.closePopupHandler();
    };
    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.container,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.props.closePopupHandler()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    <Pressable onPress={() => this.getTutorial()} style={[styles.btnStyle, { marginTop: 10 }]}>
                        <Text style={[styles.BtnTextStyle]}>{translate('tutorial')}</Text>
                    </Pressable>
                    <Pressable onPress={() => this.props.userForumHandler()} style={[styles.btnStyle, { marginTop: 20 }]}>
                        <Text style={[styles.BtnTextStyle]}>{translate('user_Forum')}</Text>
                    </Pressable>
                    <Pressable
                        onPress={() => this.props.cstmSupportHandler()}
                        style={[styles.btnStyle, {  marginTop: 20 }]}
                    >
                        <Text style={[styles.BtnTextStyle]}>{translate('cstm_Spprt')}</Text>
                    </Pressable>
                    <Pressable onPress={() => this.props.userPrivacyHandler()} style={[styles.btnStyle, { marginTop: 20, marginBottom:20 }]}>
                        <Text style={[styles.BtnTextStyle]}>{translate('terms_Privacy')}</Text>
                    </Pressable>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container: {
        flexDirection: 'column',
        maxWidth: 320,
        maxHeight: 350,
        alignItems: 'center',
        borderRadius: 10,
        paddingVertical: 8,
        paddingHorizontal: 8,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
    },
    BtnTextStyle: {
        color: '#ffffff',
        textAlign: 'center',
        fontSize: 18,
        paddingHorizontal: 16,
    },
    btnStyle: {
        minWidth: 230,
        padding: 8,
        borderRadius: 4,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
        backgroundColor: '#1d9df1',
        marginHorizontal: 10,
    },
});

export default GetHelpContainer;
