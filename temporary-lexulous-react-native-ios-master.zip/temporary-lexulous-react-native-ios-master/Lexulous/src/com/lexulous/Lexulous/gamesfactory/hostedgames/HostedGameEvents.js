// @flow

export const RESET_HOSTED_GAMES: string = 'RESET_HOSTED_GAMES';
