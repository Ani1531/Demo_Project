//@flow
import React from 'react';
import { View } from 'react-native';
import type { SliderContainerProps } from '../commons/RJTypes';
import MultiSlider from '../../../../component/MultiSlider';

type SliderContainerState = {
    low: number,
    high: number,
};
export default class SliderContainer extends React.Component<SliderContainerProps, SliderContainerState> {
    constructor(props: SliderContainerProps) {
        super(props);
        this.state = {
            low: this.props.min,
            high: this.props.max,
        };
    }

    onSliderValueChange = (low: number, high: number) => {
        if (low !== this.props.min || high !== this.props.max) {
            this.setState({
                low: low,
                high: high,
            });
            this.props.onValueSelect(low, high, this.props.tag);
        }
    };

    render() {
        return (
            <View style={{ flex: 1, marginRight: 8 }}>
                <MultiSlider
                    minValue={this.state.low}
                    maxValue={this.state.high}
                    onChangeValue={this.onSliderValueChange}
                    nativeSlider={true}
                />
            </View>
        );
    }
}
