// @flow

import * as CONSTANTS from './Constants';
import userDefault from './UserDefault';

class LgnMgr {
    type = '';
    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        console.log('Not implemented');
    };

    onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
        await this.deletePendingAssociation();
        if (onCompletion) {
            onCompletion();
        }
    };

    deletePendingAssociation = async (): Promise<boolean> => {
        let delkeys = [CONSTANTS.kPsistPendingAssociation];
        await userDefault.clearMultiple(delkeys);
        return true;
    };
}

export default LgnMgr;
