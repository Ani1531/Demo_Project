// @flow
import * as React from 'react';
import { StyleSheet, Text, View, Pressable, SectionList, Platform } from 'react-native';
import type { StatsProfileProp } from '../../commons/RJTypes';
import { batch, connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import dataServer from '../../store/Store';
import fndApi from '../../friends/FndApi';
import { actionSetIdle, actionSetBusy } from '../../commons/RJTypes';
import * as CONSTANTS from '../../commons/Constants';
import type {
    ProfileInfo,
    FndItemData,
    ServerResponse,
    ErrorResponse,
    UserStats,
    StatsSection,
    userSettings,
    StatsDataMap,
    userSettingsGameStart,
    FriendStatus,
    FndSectionData,
    WinLossStatsBarType,
    matchFriendData,
} from '../../commons/RJTypes';
import { actionUpdateMinStats } from '../../stats/minimalstats/MinStatsAction';
import requestManager from '../../commons/RequestManager';
import netManager from '../../commons/RJNetInfo';
import ProfileBarContainer from '../../components/ProfileBarContainer';
import {
    actionGLBLMkFriendEvent,
    actionGLBLRmFriendReqEvent,
    actionGLBLCancelSentFriendRequest,
    actionGLBLCensorEvent,
    actionGLBLRmAddedFriendReqEvent,
    actionGLBLUncensorEvent,
    actionGLBLInsertSentFriendRequest,
} from '../../friends/FndAction';
import { translate } from '../../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle, faCheckCircle, faExclamationTriangle, faGamepadAlt } from '@fortawesome/pro-light-svg-icons';
import WinLossStatsBarContainer from './WinLossStatsBarContainer';
import { updatePopupVisibility, clearPopups, showAlert, clearAlert } from '../../reducers/popupreducer/PopupAction';
import MatchFriendContainer from '../../components/MatchFriendContainer';
import bannerAd from '../../commons/ads/BannerAd';
import interstitialAd from '../../commons/ads/InterstitialAd';
import { handleException, showMessage } from '../../commons/RJUtils';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import rjAnalytics from '../../../../../RJAnalytics';
import themeConfigutation from '../../commons/ThemeConfiguration';
import LiveGamePlayUtils from '../../../../../utils/LiveGamePlayUtils';
import { SafeAreaView } from 'react-native-safe-area-context';

type StatsProfileState = {
    guid: string,
    name: string,
    avtar: string,
    stats: Array<StatsSection>,
    keyMap: StatsDataMap,
    rating: string,
    dictionary: string,
    otherUsrProfile?: ProfileInfo,
    friendStatus: FriendStatus,
    isFocused: boolean,
    won: number,
    games: number,
    lost: number,
    drawn: number,
    bingos: number,
    isComplete: boolean,
    definition: string,
    bannerHt: number,
};

type BtnActionTitleType = {
    btnAction: () => void,
    title: string,
    icon: any,
    color: string,
};

class ProfileStatsContainer extends React.Component<StatsProfileProp, StatsProfileState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;

    constructor(props: StatsProfileProp) {
        super(props);
        this.state = {
            otherUsrProfile: undefined,
            guid: '',
            name: '',
            avtar: '',
            stats: [],
            isFocused: false,
            keyMap: {
                game_stats: translate('game_stats'),
                aborted: translate('aborted'),
                active_game_count: translate('active_game_count'),
                avg_game_score: translate('avg_game_score'),
                best_streak: translate('best_streak'),
                bingo_count: translate('bingo_count'),
                current_streak: translate('current_streak'),
                deleted: translate('deleted'),
                drawn: translate('drawn'),
                lost: translate('lost'),
                played: translate('played'),
                won: translate('won_caps'),
                hgms_stats: translate('hgms_stats'),
                gid: translate('gid'),
                pid: translate('pid'),
                score: translate('score'),
                misc_stats: translate('misc_stats'),
                joining_time: translate('joining_time'),
                lastupdate: translate('lastupdate'),
                move_stats: translate('move_stats'),
                avg_bonustiles_used_percentage: translate('avg_bonustiles_used_percentage'),
                avg_move_score: translate('avg_move_score'),
                avg_move_time_spend: translate('avg_move_time_spend'),
                total_moves: translate('total_moves'),
                rating_stats: translate('rating_stats'),
                bestrating: translate('bestrating'),
                bestrating_date: translate('bestrating_date'),
                deviation: translate('deviation'),
                rating: translate('rating'),
                ratinglastupdate: translate('ratinglastupdate'),
                volatility: translate('volatility'),
                stats_ext1: translate('stats_ext1'),
            },
            rating: '',
            dictionary: 'twl',
            friendStatus: {},
            won: 0,
            games: 0,
            lost: 0,
            drawn: 0,
            bingos: 0,
            isComplete: false,
            definition: '',
            bannerHt: 0,
        };
    }

    componentDidUpdate(prevState) {
        let lnkarr: Array<string> = this.props.route.params.lnk.url.split('/');
        let len: number = lnkarr.length;
        let id: string = lnkarr[len - 1];
        if (this.state.guid !== id) {
            this.getGuid();
        }
    }

    componentDidMount() {
        this.props.clearPopups();
        this.getGuid();
        this.props.navigation.setOptions({
            headerLeft: () => {
                return (
                    <Pressable
                        style={styles.backButton}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('profile_stats_closed', 'profile_stats_container');
                            interstitialAd.showInterstitialAd(true, () => {
                                this.props.navigation.goBack();
                            });
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
                    </Pressable>
                );
            },
        });
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                bannerAd.showBannerAd(0, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ isFocused: false });
            }
        });
    }

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }
    openMatchFriendContainer = () => {
        this.props.updatePopupVisibility({ showMatchFriendPopup: true });
    };

    getValidActions = () => {
        let middleButtonData: ?BtnActionTitleType = this.getValidMiddleBtnData();
        let rightButtonData: ?BtnActionTitleType = this.getValidRightBtnData();
        let showMiddlebutton: boolean = middleButtonData !== null && middleButtonData !== undefined;
        let showRightbutton: boolean = rightButtonData !== null && rightButtonData !== undefined;
        return (
            <View style={[styles.buttonRowview]}>
                <Pressable
                    style={[styles.BtnStyle, { backgroundColor: '#1d9df1' }]}
                    onPress={() => {
                        rjAnalytics.sendAnalyticsEvent('match_friend_container_opened', 'profile_stats_container');
                        this.openMatchFriendContainer();
                    }}
                >
                    <FontAwesomeIcon icon={faGamepadAlt} size={20} style={{ marginRight: 5, color: 'white' }} />
                    <Text style={styles.btntxt}>{translate('match')}</Text>
                </Pressable>
                {showMiddlebutton ? (
                    <Pressable
                        style={[
                            styles.BtnStyle,
                            { backgroundColor: middleButtonData?.color },
                            { display: showMiddlebutton ? 'flex' : 'none' },
                        ]}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('add_Frnd_btn_pressed', 'profile_stats_container');
                            middleButtonData?.btnAction();
                        }}
                    >
                        <FontAwesomeIcon icon={middleButtonData?.icon} size={20} style={{ marginRight: 5, color: 'white' }} />
                        <Text style={styles.btntxt}>{translate(middleButtonData?.title)}</Text>
                    </Pressable>
                ) : null}

                {showRightbutton ? (
                    <Pressable
                        style={[
                            styles.BtnStyle,
                            { backgroundColor: rightButtonData?.color },
                            { display: showRightbutton ? 'flex' : 'none' },
                        ]}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent(
                                String(rightButtonData?.title) + '__btn_pressed',
                                'profile_stats_container'
                            );
                            rightButtonData?.btnAction();
                        }}
                    >
                        <FontAwesomeIcon icon={rightButtonData?.icon} size={20} style={{ marginRight: 5, color: 'white' }} />
                        <Text style={styles.btntxt}>{translate(rightButtonData?.title)}</Text>
                    </Pressable>
                ) : null}
            </View>
        );
    };

    getValidMiddleBtnData = (): ?BtnActionTitleType => {
        if (this.state.friendStatus.isFriend) {
            if (this.state.friendStatus.reqPending) {
                //request friend preceds remove friend
                return { btnAction: this.doAcceptFriend, title: 'accept', icon: faCheckCircle, color: 'green' };
            } else {
                return { btnAction: this.doRmAddedFriendReq, title: 'rm_frnd', icon: faTimesCircle, color: 'red' };
            }
        } else if (this.state.friendStatus.reqPending) {
            return { btnAction: this.doAcceptFriend, title: 'accept', icon: faCheckCircle, color: 'green' };
        } else if (this.state.friendStatus.reqSent) {
            return { btnAction: this.doCancelRequest, title: 'fnd_req_sent', icon: faTimesCircle, color: 'red' };
        } else if (this.state.friendStatus.hasCensored) {
            return null;
        } else {
            return { btnAction: this.doSendFriendRequest, title: 'add_Frnd', icon: faCheckCircle, color: 'green' };
        }
    };

    getValidRightBtnData = (): ?BtnActionTitleType => {
        if (this.state.friendStatus.reqPending) {
            if (this.state.friendStatus.hasCensored) {
                //request pending preceds uncensor
                return { btnAction: this.doRmFriendReq, title: 'reject', icon: faExclamationTriangle, color: 'red' };
            } else {
                return { btnAction: this.doRmFriendReq, title: 'reject', icon: faExclamationTriangle, color: 'red' };
            }
        } else if (this.state.friendStatus.hasCensored) {
            return { btnAction: this.doUncensorReq, title: 'uncensor', icon: faCheckCircle, color: 'green' };
        } else if (this.state.friendStatus.isFriend || this.state.friendStatus.reqSent) {
            return null;
        } else {
            return { btnAction: this.doSendCensorRequest, title: 'censor', icon: faExclamationTriangle, color: 'red' };
        }
    };

    doSendFriendRequest = () => {
        ////to send friend request
        if (this.state.otherUsrProfile) {
            if (this.state.otherUsrProfile.guid) {
                this.doGetGuidFromEmailOrName(this.state.otherUsrProfile.guid, this.doMkFriendRequest);
            }
        }
    };

    doSendCensorRequest = () => {
        ///to censored any user
        if (this.state.otherUsrProfile) {
            if (this.state.otherUsrProfile.guid) {
                this.doGetGuidFromEmailOrName(this.state.otherUsrProfile.guid, this.doCensorRequest);
            }
        }
    };

    doGetGuidFromEmailOrName = (data: string, callback: (string) => void) => {
        if (data !== null || data !== undefined) {
            let glblid = data;

            callback(glblid);
        }
    };

    doCancelRequest = (): void => {
        ///to cancel already send friend req
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            let otherProfile = this.state.otherUsrProfile;
            if (otherProfile.guid !== null && otherProfile.guid !== undefined) {
                let otherguid: string = otherProfile.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.cancelFriendRequest(otherguid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                batch(() => {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                    this.props.actionGLBLCancelSentFriendRequest(otherProfile);
                                    LiveGamePlayUtils.addRemoveBuddyUpdate(false, otherProfile);
                                });

                                this.setState({ friendStatus: this.getFriendshipStatus() });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    doUncensorReq = (): void => {
        ///for unblocked/uncensorced any friend frm censored list

        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            let otherProfile = this.state.otherUsrProfile;
            if (otherProfile.guid !== null && otherProfile.guid !== undefined) {
                let otherguid: string = otherProfile.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.uncensorRequest(otherguid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                batch(() => {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                    this.props.actionGLBLUncensorEvent(otherProfile);
                                    LiveGamePlayUtils.censorUncensorPlayerUpdate(false, otherProfile);
                                });

                                this.setState({ friendStatus: this.getFriendshipStatus() });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    doMkFriendRequest = () => {
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            if (this.state.otherUsrProfile.guid !== null && this.state.otherUsrProfile.guid !== undefined) {
                let glblid: string = this.state.otherUsrProfile.guid;
                //to send frnd reqst
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.mkFriendRequest(glblid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                let p2: AxiosPromise<ServerResponse> = requestManager.getProfileOtherUser([glblid]);
                                let p3: AxiosPromise<ServerResponse> = fndApi.getStats(
                                    [glblid],
                                    ['game_stats', 'rating_stats']
                                );
                                let promises: Array<AxiosPromise<ServerResponse>> = [];
                                promises.push(p2);
                                promises.push(p3);
                                Promise.all(promises)
                                    .then(async ([a, b]) => {
                                        let a1: ServerResponse = await a.data;
                                        let b1: ServerResponse = await b.data;
                                        let userstats: { [string]: UserStats } = {};
                                        let pflinfo: { [string]: ProfileInfo } = {};

                                        if (b1.check === CONSTANTS.kSuccess) {
                                            let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                                            let uu: { [string]: UserStats } = temp.reduce((pp, qq) => {
                                                pp[qq.guid] = qq;
                                                return pp;
                                            }, {});
                                            userstats = { ...uu };
                                        }

                                        if (a1.check === CONSTANTS.kSuccess) {
                                            pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                                        }

                                        let isempty = Object.keys(pflinfo).length === 0 && pflinfo.constructor === Object;
                                        if (!isempty) {
                                            batch(() => {
                                                dataServer.debouncedDispatch(actionSetIdle());
                                                dataServer.getStore().dispatch(actionUpdateMinStats(userstats));
                                                dataServer
                                                    .getStore()
                                                    .dispatch(actionGLBLInsertSentFriendRequest(pflinfo[glblid]));
                                                LiveGamePlayUtils.addRemoveBuddyUpdate(true, pflinfo[glblid]);
                                            });

                                            this.setState({ friendStatus: this.getFriendshipStatus() });
                                        }
                                    })
                                    .catch((error) => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        handleException(error);
                                    });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        })
                        .finally(() => {});
                }
            }
        }
    };

    doCensorRequest = (): void => {
        ////to censor any user no in frnd,pending,censor list
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            if (this.state.otherUsrProfile.guid !== null && this.state.otherUsrProfile.guid !== undefined) {
                let glblid: string = this.state.otherUsrProfile.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.censorRequest(glblid);

                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                let p2: AxiosPromise<ServerResponse> = requestManager.getProfileOtherUser([glblid]);
                                let p3: AxiosPromise<ServerResponse> = fndApi.getStats(
                                    [glblid],
                                    ['game_stats', 'rating_stats']
                                );
                                let promises: Array<AxiosPromise<ServerResponse>> = [];
                                promises.push(p2);
                                promises.push(p3);
                                Promise.all(promises)
                                    .then(async ([a, b]) => {
                                        let a1: ServerResponse = await a.data;
                                        let b1: ServerResponse = await b.data;
                                        let userstats: { [string]: UserStats } = {};
                                        let pflinfo: { [string]: ProfileInfo } = {};

                                        if (b1.check === CONSTANTS.kSuccess) {
                                            let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                                            let uu: { [string]: UserStats } = temp.reduce((pp, qq) => {
                                                pp[qq.guid] = qq;
                                                return pp;
                                            }, {});
                                            userstats = { ...uu };
                                        }

                                        if (a1.check === CONSTANTS.kSuccess) {
                                            pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                                        }

                                        let isempty = Object.keys(pflinfo).length === 0 && pflinfo.constructor === Object;
                                        if (!isempty) {
                                            batch(() => {
                                                dataServer.debouncedDispatch(actionSetIdle());
                                                dataServer.getStore().dispatch(actionUpdateMinStats(userstats));
                                                dataServer.getStore().dispatch(actionGLBLCensorEvent(pflinfo[glblid]));
                                                LiveGamePlayUtils.censorUncensorPlayerUpdate(true, pflinfo[glblid]);
                                            });

                                            this.setState({ friendStatus: this.getFriendshipStatus() });
                                        }
                                    })
                                    .catch((error) => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        handleException(error);
                                    });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    doAcceptFriend = (): void => {
        //////for accept freind req from pending list
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            let otherProfile = this.state.otherUsrProfile;
            if (otherProfile.guid !== null && otherProfile.guid !== undefined) {
                let otherguid: string = otherProfile.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.mkFriend(otherguid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                batch(() => {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                    this.props.actionGLBLMkFriendEvent(otherProfile);
                                    LiveGamePlayUtils.pendingRequestActionUpdate(true, otherProfile);
                                });
                                this.setState({ friendStatus: this.getFriendshipStatus() });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    doRmAddedFriendReq = (): void => {
        ////to remove a friend from friend list
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            let otherProfile = this.state.otherUsrProfile;
            if (otherProfile.guid !== null && otherProfile.guid !== undefined) {
                let otherguid: string = this.state.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.rmAddedFriendRequest(otherguid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                batch(() => {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                    this.props.actionGLBLRmAddedFriendReqEvent(otherProfile);
                                    LiveGamePlayUtils.addRemoveBuddyUpdate(false, otherProfile);
                                });
                                this.setState({ friendStatus: this.getFriendshipStatus() });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    doRmFriendReq = (): void => {
        ///for reject freind req from pending list
        if (this.state.otherUsrProfile !== null && this.state.otherUsrProfile !== undefined) {
            let otherProfile = this.state.otherUsrProfile;
            if (otherProfile.guid !== null && otherProfile.guid !== undefined) {
                let otherguid: string = otherProfile.guid;
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let p1: AxiosPromise<ServerResponse> = fndApi.rmFriendRequest(otherguid);
                    p1.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })
                        .then((jresp: ServerResponse) => {
                            if (jresp.check === CONSTANTS.kSuccess) {
                                batch(() => {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                    this.props.actionGLBLRmFriendReqEvent(otherProfile);
                                    LiveGamePlayUtils.pendingRequestActionUpdate(false, otherProfile);
                                });
                                this.setState({ friendStatus: this.getFriendshipStatus() });
                            } else {
                                let err: ErrorResponse = (jresp: ErrorResponse);
                                dataServer.debouncedDispatch(actionSetIdle());
                                showMessage(err.msg, 'profile_stats_container');
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            handleException(error);
                        });
                }
            }
        }
    };

    getDateFormat = (data: number) => {
        let timestamp = new Date(data).getTime();
        let todate = new Date(timestamp).getDate();
        let tomonth = new Date(timestamp).getMonth() + 1;
        let toyear = new Date(timestamp).getFullYear();
        return todate + '/' + tomonth + '/' + toyear;
    };

    getCachedProfile = (glblid: string): AxiosPromise<ServerResponse> => {
        let srch_data: ?FndItemData = null;
        this.props.friends.friends.forEach((element: FndSectionData) => {
            if (srch_data == null) {
                srch_data = element.data.find((val) => val.key === glblid);
            }
        });

        let p2: AxiosPromise<ServerResponse> = null;
        if (srch_data == null) {
            p2 = requestManager.getProfileOtherUser([glblid]);
        } else {
            p2 = new Promise(function (resolve, reject) {
                let profile: ProfileInfo = { [glblid]: srch_data?.data };
                let tstmp = new Date().getTime() / 1000;
                let data = {
                    data: profile,
                    extcode: '1',
                    action: 'getprofile',
                    tstmp: tstmp.toString(),
                    check: 'success',
                };
                resolve({ data });
            });
        }
        return p2;
    };

    getProfileandStat = (glblid: string) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p2: AxiosPromise<ServerResponse> = this.getCachedProfile(glblid);
            let p3: AxiosPromise<ServerResponse> = fndApi.getStats([glblid], []);
            let p4: AxiosPromise<ServerResponse> = requestManager.getUserSetting([glblid]);
            let promises: Array<AxiosPromise<ServerResponse>> = [];

            promises.push(p2);
            promises.push(p3);
            promises.push(p4);
            Promise.all(promises)
                .then(async ([a, b, c]) => {
                    let a1: ServerResponse = await a.data;
                    let b1: ServerResponse = await b.data;
                    let c1: ServerResponse = await c.data;
                    let pflinfo: { [string]: ProfileInfo } = {};
                    let usersttings: { [string]: userSettings } = {};

                    if (b1.check === CONSTANTS.kSuccess && b1.extcode == '1') {
                        let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                        if (temp !== undefined && temp !== null && temp.length > 0) {
                            let user_stat: UserStats = temp[0];
                            let rating = user_stat.rating_stats?.rating ?? CONSTANTS.Default_rating;
                            this.setState({
                                rating: rating,
                            });
                            if (user_stat.game_stats?.played) {
                                this.setState({ games: Number(user_stat.game_stats?.played) });
                            }
                            if (user_stat.game_stats?.bingo_count) {
                                this.setState({
                                    bingos: Number(user_stat.game_stats?.bingo_count),
                                });
                            }

                            if (user_stat.game_stats?.won) {
                                this.setState({
                                    won: Number(user_stat.game_stats?.won),
                                });
                            }
                            if (user_stat.game_stats?.lost) {
                                this.setState({
                                    lost: Number(user_stat.game_stats?.lost),
                                });
                            }
                            if (user_stat.game_stats?.drawn) {
                                this.setState({
                                    drawn: Number(user_stat.game_stats?.drawn),
                                });
                            }
                            if (user_stat !== null && user_stat !== undefined) {
                                let req_keys = Object.keys(user_stat);
                                let getFormattedData = (key, data) => {
                                    switch (key) {
                                        case 'joining_time':
                                        case 'lastupdate':
                                        case 'bestrating_date':
                                        case 'ratinglastupdate':
                                            return this.getDateFormat(Number(data) * 1000);
                                        default:
                                            return data;
                                    }
                                };

                                let dummyData = {
                                    data: [],
                                    title: 'kRemove',
                                };

                                let mappeddata = req_keys
                                    .map((sectionheaders: string) => {
                                        if (
                                            sectionheaders !== 'guid' &&
                                            sectionheaders !== 'channel' &&
                                            sectionheaders !== 'hgms_stats'
                                        ) {
                                            let isNotWordStatsSection: boolean = sectionheaders !== 'stats_ext1';
                                            let title: string = this.state.keyMap[sectionheaders];
                                            let sectiondata = user_stat[sectionheaders];
                                            if (isNotWordStatsSection) {
                                                let data = Object.keys(sectiondata).map((secdatakey: string) => {
                                                    return {
                                                        lbl: this.state.keyMap[secdatakey],
                                                        data: getFormattedData(secdatakey, sectiondata[secdatakey]),
                                                    };
                                                });
                                                return {
                                                    title,
                                                    data,
                                                };
                                            } else {
                                                let data = [
                                                    {
                                                        lbl: translate('lngst_wrd_plyd'),
                                                        key: CONSTANTS.kLongestWordPlayed,
                                                        data: sectiondata.longestwordplayed,
                                                    },
                                                ];
                                                if (sectiondata.longestwordplayed !== undefined) {
                                                    this.setState({ definition: '' });
                                                    let lngstWordPlyd = [data[0].data.word];
                                                    this.getDefination(lngstWordPlyd);
                                                    return {
                                                        title,
                                                        data,
                                                    };
                                                } else {
                                                    return dummyData;
                                                }
                                            }
                                        } else {
                                            return dummyData;
                                        }
                                    })
                                    .filter((m) => m != null && m != undefined && m.title != 'kRemove');
                                this.setState({
                                    stats: mappeddata,
                                });
                            }
                        }
                    } else {
                        throw { err: 'not a valid user' };
                    }

                    if (a1.check === CONSTANTS.kSuccess && a1.extcode == '1') {
                        pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                        this.setState({
                            otherUsrProfile: {
                                name: pflinfo[glblid].name,
                                avtar: pflinfo[glblid].avtar,
                                guid: pflinfo[glblid].guid,
                            },
                        });
                    } else {
                        throw { err: 'not a valid user' };
                    }

                    if (c1.check === CONSTANTS.kSuccess) {
                        usersttings = ((c1.data: any): { [string]: userSettings });
                        let dictionary: userSettingsGameStart = usersttings[glblid]['us_gamestart'] ?? {
                            gs_prefdic: CONSTANTS.US_English,
                        };
                        this.setState({
                            dictionary: dictionary.gs_prefdic,
                        });
                    }

                    this.setState({ friendStatus: this.getFriendshipStatus(), isComplete: true });
                    dataServer.debouncedDispatch(actionSetIdle());
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    showMessage(translate('err_mgs'), 'profile_stats_container');
                    handleException(error);
                });
        }
    };

    getFriendshipStatus = () => {
        let result = undefined;
        let fnd_status_obj = {};
        let isFriend: boolean = false;
        let hasCensored: boolean = false;
        let reqPending: boolean = false;
        let reqSent: boolean = false;
        for (let i = 0; i < this.props.friends.friends.length; i++) {
            result = this.props.friends.friends[i].data.find((val) => val.data.guid === this.state.guid);
            if (result) {
                switch (result.type) {
                    case 'fnd':
                        isFriend = true;
                        break;
                    case 'reqsent':
                        reqSent = true;
                        break;
                    case 'pending':
                        reqPending = true;
                        break;
                    case 'censored':
                        hasCensored = true;
                        break;
                    default:
                        break;
                }
            }
        }
        fnd_status_obj = {
            isFriend: isFriend,
            hasCensored: hasCensored,
            reqPending: reqPending,
            reqSent: reqSent,
        };
        return fnd_status_obj;
    };

    getGuid = () => {
        let lnkarr = this.props.route.params.lnk.url.split('/');
        let len = lnkarr.length;
        // let id: string = lnkarr[len - 1];
        this.setState({ guid: lnkarr[len - 1] }, () => {
            this.getProfileandStat(this.state.guid);
        });
    };

    separator = () => {
        return <View style={styles.separatorStyle} />;
    };

    renderItem = ({ item }) => {
        let renderWordStats: boolean = item.key === CONSTANTS.kLongestWordPlayed;
        if (!renderWordStats) {
            return (
                <View style={styles.statRowview}>
                    <Text style={[styles.scoreheaderText, { color: themeConfigutation.getColor('#000') }]}>{item.lbl}</Text>
                    <Text style={[styles.scoreheaderText, { color: themeConfigutation.getColor('#000') }]}>{item.data}</Text>
                </View>
            );
        } else {
            return (
                <View style={styles.statClmnview}>
                    <Text style={[styles.scoreheaderText, { paddingVertical: 4, color: themeConfigutation.getColor('#000') }]}>
                        {item.lbl}
                    </Text>
                    <View style={styles.tileNscoreSec}>
                        {item.data.word.split('').map((item, index) => this.getTilesView(item, index))}
                        <Text style={[styles.scroreText, { color: themeConfigutation.getColor('#014577') }]}>
                            {item.data.score}
                        </Text>
                    </View>
                    <Text style={[styles.scoreheaderText, { paddingVertical: 4, color: themeConfigutation.getColor('#000') }]}>
                        {this.state.definition}
                    </Text>
                </View>
            );
        }
    };

    getTilesView = (item, index) => {
        let isLower = (str) => {
            return /[a-z]/.test(str) && !/[A-Z]/.test(str);
        };
        let isLowerCase = isLower(item);
        return (
            <View key={index} style={styles.tileView}>
                <Text style={[styles.letterStyle, { color: isLowerCase ? '#DA1515' : '#1F1F1F' }]}>{item.toUpperCase()}</Text>
            </View>
        );
    };

    getDefination = (wordArray: Array<string>) => {
        let words = wordArray.map((i) => i.toUpperCase());
        requestManager
            .getDefinationByApi(words)
            .then((res) => {
                if (res.status == CONSTANTS.HTTPSuccessStatus) {
                    return res.data;
                } else {
                    throw { name: 'RequestFail', status: res.status, message: 'Request Failed' };
                }
            })
            .then((res) => {
                let isMultipleWords = words.length > 1;
                if (isMultipleWords) {
                    let wordDef = '';
                    words.map((item, index) => {
                        let def = res[item];
                        let addNxtLine = words.length - 1 == index ? '' : '\n\n';
                        if (def.length > 0) {
                            wordDef = wordDef + `${item}: ${def[0].description}` + addNxtLine;
                        } else {
                            wordDef = wordDef + `${item}: Definition not available` + addNxtLine;
                        }
                    });
                    this.setState({ definition: wordDef });
                } else {
                    let def = res[words[0]];
                    if (def.length > 0) {
                        this.setState({ definition: def[0].description });
                    } else {
                        this.setState({ definition: 'Definition not available.' });
                    }
                }
            })
            .catch((error) => {
                console.log('error', error);
            });
    };

    renderHeaderItem = ({ section: { title } }: Object) => (
        <Text
            style={[
                styles.header,
                { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#5f6368') },
            ]}
        >
            {title}
        </Text>
    );

    renderAdViewPlaceHolder = () => {
        return <View style={{ height: this.state.bannerHt, backgroundColor: themeConfigutation.getColor('#f4f3ef') }} />;
    };

    render() {
        let isButtonsvisible = this.props.profile.guid != this.state.guid;
        let statdata: WinLossStatsBarType = {
            won: this.state.won,
            games: this.state.games,
            lost: this.state.lost,
            drawn: this.state.drawn,
            bingos: this.state.bingos,
        };
        let userStats: matchFriendData = {};
        if (this.state.otherUsrProfile) {
            userStats = {
                barstats: statdata,
                guid: this.state.guid,
                profile: this.state.otherUsrProfile,
                rating: this.state.rating,
            };
        }
        return this.state.isFocused && this.state.isComplete ? (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#fff') }]}>
                    {this.props.popups.showMatchFriendPopup && this.state.otherUsrProfile ? (
                        <MatchFriendContainer
                            cancelMatch={() => {
                                this.props.clearPopups();
                                rjAnalytics.sendAnalyticsEvent('match_friend_container_closed', 'profile_stats_container');
                            }}
                            profile={this.state.otherUsrProfile}
                            userStats={userStats}
                            navigation={this.props.navigation}
                            opponentDict={this.state.dictionary}
                        />
                    ) : null}
                    <ProfileBarContainer
                        rating={this.state.rating}
                        dictionary={this.state.dictionary}
                        otherUsrProfile={this.state.otherUsrProfile}
                    />
                    {/* <Text>Stats Profile :: {this.props.route.params.lnk.url}</Text> */}
                    {isButtonsvisible ? this.getValidActions() : null}
                    <WinLossStatsBarContainer statdata={statdata} isForHostedGame={false} />
                    {this.state.stats.length !== 0 ? (
                        <SectionList
                            sections={(this.state.stats: any)}
                            keyExtractor={(item, index) => item + index}
                            renderItem={this.renderItem}
                            renderSectionHeader={this.renderHeaderItem}
                            stickySectionHeadersEnabled
                            style={[styles.sectionStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                        />
                    ) : null}
                    {this.renderAdViewPlaceHolder()}
                </View>
            </SafeAreaView>
        ) : null;
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'flex-start',
    },
    backButton: {
        padding: 10,
    },
    BtnStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingHorizontal: 8,
        paddingVertical: 8,
        borderRadius: 4,
    },
    scoreheaderText: {
        fontSize: 14,
        fontWeight: '600',
    },
    btntxt: {
        color: 'white',
        fontSize: 13,
        fontWeight: '700',
    },
    buttonRowview: {
        width: '100%',
        padding: 8,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    header: {
        fontSize: 14,
        paddingLeft: 8,
        paddingTop: 4,
        paddingBottom: 4,
    },
    statRowview: {
        justifyContent: 'space-between',
        flexDirection: 'row',
        paddingHorizontal: 12,
        paddingVertical: 6,
    },
    statClmnview: {
        justifyContent: 'flex-start',
        flexDirection: 'column',
        paddingHorizontal: 12,
        paddingVertical: 6,
    },
    tileNscoreSec: {
        alignItems: 'center',
        flexDirection: 'row',
    },
    tileView: {
        backgroundColor: '#F7A434',
        borderRadius: 2,
        borderColor: '#fcba27',
        marginRight: 2,
        alignItems: 'center',
    },
    letterStyle: {
        textAlign: 'center',
        fontSize: 16,
        fontWeight: 'bold',
        aspectRatio: 1,
        padding: 4,
    },
    scroreText: {
        marginLeft: 'auto',
        fontSize: 16,
        fontWeight: 'bold',
        paddingLeft: 8,
        textAlign: 'center',
    },
    sectionStyle: {
        ...Platform.select({
            native: { flexGrow: 1 },
            default: {
                height: 100,
            },
        }),
    },
    separatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
});
const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionGLBLMkFriendEvent,
            actionGLBLRmFriendReqEvent,
            actionGLBLCancelSentFriendRequest,
            actionGLBLCensorEvent,
            actionGLBLRmAddedFriendReqEvent,
            actionGLBLUncensorEvent,
            updatePopupVisibility,
            clearPopups,
            showAlert,
            clearAlert,
        },
        dispatch
    );

function mapStateToProps(state) {
    const { profile, friends, popups, utils } = state;
    return { profile, friends, popups, utils };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileStatsContainer);
