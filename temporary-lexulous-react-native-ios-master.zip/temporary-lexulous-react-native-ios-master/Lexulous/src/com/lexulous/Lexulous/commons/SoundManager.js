// @flow

import HowlObject from '../../../../utils/HowlObject';
import dataServer from '../store/Store';

class SoundManager {
    _soundNames: Array<string> = [
        'bingo',
        'clicktile',
        'droptilesound',
        'error',
        'gamestartendsound',
        'invalid_word',
        'message',
        'opp_submits',
        'recall',
        'shuffle',
        'user_submits',
        'user_wins_game',
    ];
    _RJSound = {
        RJSoundBingo: 0,
        RJSoundClick: 1,
        RJSoundDropTile: 2,
        RJSoundError: 3,
        RJSoundGameStart: 4,
        RJSoundInvalidWord: 5,
        RJSoundNewMsg: 6,
        RJOppSubmit: 7,
        RJSoundRecall: 8,
        RJSoundShuffle: 9,
        RJSoundUserSubmits: 10,
        RJSoundUserWonGame: 11,
    };

    constructor() {
        this.onAppInit();
    }

    get RJSound() {
        return this._RJSound;
    }

    onAppInit = (): void => {};

    onDestroy = (): void => {};

    playSound = (soundname: number): void => {
        //play the preloaded sound
        //configure any play flags here from redux store here
        let isSoundEnabled: boolean = dataServer.getSoundSettings();

        if (isSoundEnabled) {
            HowlObject.playSound(this._soundNames[soundname]);
        }
    };
}

const soundManager: SoundManager = new SoundManager();

export default soundManager;
