import { LAYOUT_REDUCER_SET_FIELD } from '../configs/ActionIdentifiers';

export const layoutReducerSetField = (res) => (dispatch, getState)=> dispatch({
    type: LAYOUT_REDUCER_SET_FIELD,
    payload: res,
    globalState: getState()
});
