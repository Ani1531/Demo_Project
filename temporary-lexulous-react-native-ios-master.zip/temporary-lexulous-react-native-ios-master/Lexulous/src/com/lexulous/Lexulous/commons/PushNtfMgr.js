// @flow

class PushNtfMgr {
    constructor() {}

    mountPushNotification = (callback: ?(boolean) => void) => {};

    doGetInitialNotification = () => {};

    unmountPushNotification = () => {};

    shouldUpdatePin = (pin: string) => {};

    shouldDeletePin = (pin: string) => {};

    isPinValid = (pin: string) => {};

    isPinSame = (pin: string) => {};

    doUpdateDevicePin = (forceupdate?: boolean) => {};

    updateDevicePin = (pin: string, ack: string) => {};

    deleteDevicePin = (pin: ?string) => {};

    doHandleNotification = (notification: Notification, ntfstate?: string) => {};

    showAleartForTestNtf = (msg: string) => {};

    pinMayHaveExpired = async () => {};

    notificationChecking = async () => {
        return false;
    };
}

const pushNtfMgr: PushNtfMgr = new PushNtfMgr();

export default pushNtfMgr;
