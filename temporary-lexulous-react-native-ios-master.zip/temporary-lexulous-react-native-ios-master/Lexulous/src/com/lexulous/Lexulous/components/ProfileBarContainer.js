// @flow

import * as React from 'react';
import { StyleSheet, Text, View, Pressable, Linking, Platform } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faShareAlt, faEdit } from '@fortawesome/pro-light-svg-icons';
import * as CONSTANTS from '../commons/Constants';
import Clipboard from '@react-native-clipboard/clipboard';
import type { ProfileBarContainerProps, AlertBoxType } from '../commons/RJTypes';
import AvatarSelector from '../components/AvatarSelector';
import { translate } from '../commons/translations/LangTransator';
import { updatePopupVisibility, showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type ProfileBarContainertateState = {
    greetingText: string,
    greetingUrl: string | null,
    showSharePopup: boolean,
};
const leftbar = {
    rating: 'rating',
    icon: 'icon',
};

class ProfileBarContainer extends React.Component<ProfileBarContainerProps, ProfileBarContainertateState> {
    constructor(props: ProfileBarContainerProps) {
        super(props);
        const greetinfo = CONSTANTS.greetingInfo.split(',');
        let gtxt = null;
        let gurl = null;
        if (greetinfo.length == 3) {
            gurl = greetinfo[2];
        }
        gtxt = greetinfo[0];
        this.state = {
            greetingText: gtxt,
            greetingUrl: gurl,
            showSharePopup: false,
        };
    }
    getDictionaryValue = (defaultVal: string) => {
        switch (defaultVal) {
            case CONSTANTS.US_English:
                return translate('dict_us');
            case CONSTANTS.UK_English:
                return translate('dict_uk');
            case CONSTANTS.Italian:
                return translate('dict_it');
            case CONSTANTS.French:
                return translate('dict_fr');
            default:
                return translate('dict_us');
        }
    };

    onTab = () => {
        this.copyToClipBoard();
    };

    copyToClipBoard = () => {
        let lexid = this.props.profile.guid;
        if (lexid !== null && lexid !== undefined) {
            let formattedlexid: string = CONSTANTS.getLexIdWithDash(lexid);
            Clipboard.setString(formattedlexid);
        }
    };

    showDictinfoAlertBox() {
        rjAnalytics.sendAnalyticsEvent('user_dic_pref_alert_opened', 'profile_bar_container');
        let alertBoxInfo: AlertBoxType = {
            message: translate('user_dic_pref_alert'),
            actions: [
                {
                    text: translate('ok'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('user_dic_pref_alert_ok_pressed_closed', 'profile_bar_container');
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBOTH,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    }

    renderIconOrRating = (data) => {
        switch (data) {
            case leftbar.rating:
                return this.renderDictNrating();

            case leftbar.icon:
                return this.renderIcon();

            default:
                return null;
        }
    };

    renderDictNrating = () => {
        return (
            <View style={styles.dicNratingStyle}>
                <Text style={{ paddingRight: 5, alignSelf: 'flex-end', color: themeConfigutation.getColor('#000') }}>
                    {this.props.rating}
                </Text>
                <Pressable
                    onPress={() => {
                        this.showDictinfoAlertBox();
                    }}
                    style={[styles.dicTypeBtnStyle, { backgroundColor: themeConfigutation.getColor('#e5e7e9') }]}
                >
                    <Text numberOfLines={1} style={{ color: themeConfigutation.getColor('#000') }}>
                        {this.getDictionaryValue(this.props.dictionary)}
                    </Text>
                </Pressable>
            </View>
        );
    };

    renderIcon = () => {
        let renderIconBtn = () => (
            <Pressable
                onPress={() => {
                    this.props.openPopupHandler();
                }}
                style={[styles.iconStyle]}
            >
                <FontAwesomeIcon
                    icon={this.getAllowedActionIndicator()}
                    color={themeConfigutation.getColor('#000')}
                    size={22}
                />
            </Pressable>
        );

        if (this.props.canShare) {
            if (!this.props.disableActionBtn) {
                return renderIconBtn();
            }
        } else {
            return renderIconBtn();
        }
    };

    render() {
        let renderOtherUserInfo: string =
            this.props.otherUsrProfile !== null && this.props.otherUsrProfile !== undefined ? leftbar.rating : leftbar.icon;

        return (
            <Pressable
                onPress={() => {
                    this.onTab();
                }}
            >
                <View style={[styles.profileContainer, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <AvatarSelector
                        avtar={this.props.otherUsrProfile?.avtar ?? null}
                        editingFinishedHandler={this.props.userAvatarDidFinishedEditing}
                    />
                    <View style={[styles.labelAndIconContainer, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                        <View style={[styles.labelContainer]}>
                            <Text
                                numberOfLines={0}
                                style={[
                                    this.getGreetingStyle(),
                                    {
                                        fontSize: 18,
                                        color: themeConfigutation.getColor('#000'),
                                        backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                                    },
                                ]}
                                onPress={this.openGreetingUrl}
                            >
                                {this.getGreetingAndName(this.props.otherUsrProfile?.name ?? null)}
                            </Text>
                            <Text
                                numberOfLines={1}
                                style={{
                                    backgroundColor: themeConfigutation.getColor('#f4f3ef'),
                                    color: themeConfigutation.getColor('#5f6368'),
                                    fontSize: 14,
                                }}
                            >
                                {'Lex ID: ' +
                                    CONSTANTS.getLexIdWithDash(
                                        this.props.otherUsrProfile?.guid ?? this.props.profile.guid ?? CONSTANTS.Default_guid
                                    )}
                            </Text>
                        </View>
                        {this.renderIconOrRating(renderOtherUserInfo)}
                    </View>
                </View>
            </Pressable>
        );
    }

    getGreetingStyle = () => {
        if (this.props.canShare && this.state.greetingUrl !== null && this.state.greetingUrl !== undefined) {
            return [styles.textStyleLink];
        }
    };

    openGreetingUrl = () => {
        if (this.props.canShare && this.state.greetingUrl !== null && this.state.greetingUrl !== undefined) {
            Linking.openURL(this.state.greetingUrl);
        }
    };

    getGreetingAndName = (data: ?string) => {
        let greetingtext = '';
        if (this.props.canShare) {
            greetingtext = this.state.greetingText + ',  ';
        }
        if (data) {
            greetingtext += data;
        } else {
            greetingtext += this.props.profile.name ?? CONSTANTS.Default_name;
        }
        return greetingtext;
    };

    getAllowedActionIndicator = () => {
        if (this.props.canShare) {
            return faShareAlt;
        } else {
            return faEdit;
        }
    };
}

const styles = StyleSheet.create({
    profileContainer: {
        ...Platform.select({
            native: { height: 60 },
            default: { height: 70 },
        }),
        height: 70,
        width: '100%',
        padding: 10,
        flexDirection: 'row',
        borderBottomWidth: 2,
        borderColor: '#D1D1CE',
        alignItems: 'center',
    },
    labelAndIconContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginLeft: 10,
    },
    labelContainer: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    textStyleLink: { textDecorationLine: 'underline' },
    iconStyle: { alignItems: 'center' },
    dicNratingStyle: {
        flexDirection: 'column',
        marginLeft: 4,
    },
    dicTypeBtnStyle: {
        padding: 5,
        borderWidth: 1,
        alignSelf: 'flex-end',
    },
});

function mapStateToProps(state) {
    const { profile, popups, utils } = state;
    return { profile, popups, utils };
}

const mapDispatchToProps = (dispatch) => bindActionCreators({ updatePopupVisibility, clearAlert, showAlert }, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ProfileBarContainer);
