// @flow

import type { GamesListResponse, ActionGLRefreshStarted, ActionGLClearData } from '../commons/RJTypes';

type ActionArchivedGamesType = {
    type: string,
    payload: GamesListResponse,
    timestamp: number,
    skip: number,
};

import { ADD_ARCHIVE_GAMES, CLR_ARCHIVE_GAMES, AGL_REFRESH_STARTED } from './AGLEventTypes';

export const actionAddArchiveGames = (data: GamesListResponse, timestamp: number, skip: number): ActionArchivedGamesType => {
    return {
        type: ADD_ARCHIVE_GAMES,
        payload: data,
        timestamp: timestamp,
        skip: skip,
    };
};

export const aglRefreshStarted = (): ActionGLRefreshStarted => {
    return {
        type: AGL_REFRESH_STARTED,
    };
};

export const aglClearData = (): ActionGLClearData => {
    return {
        type: CLR_ARCHIVE_GAMES,
    };
};
