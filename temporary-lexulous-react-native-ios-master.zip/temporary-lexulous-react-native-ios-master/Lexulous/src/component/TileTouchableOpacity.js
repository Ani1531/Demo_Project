import React from 'react';
import {
    StyleSheet,
    TouchableHighlight,
    TouchableOpacity,
    View,
} from 'react-native';

export default class TileTouchableOpacity extends React.PureComponent {
    state = {
        disabled: false,
        hidden: this.props.hidden,
        backgroundColor: null,
        onPress: this.props.onPress,
        toggle: this.props.toggle,
        toggleState: !!this.props.toggleState,
    };

    getContainerBackgroundColor = () =>
        this.state.backgroundColor
            ? {
                  backgroundColor: this.state.backgroundColor,
              }
            : null;

    getContainerJustifyContent = () =>
        this.state.justifyContent
            ? {
                  justifyContent: this.state.justifyContent,
              }
            : null;

    getOpacity = () =>
        this.props.hoverEffect
            ? { opacity: this.state.mouseEntered ? 0.5 : 1 }
            : null;

    render = () => {
        if (this.state.hidden) {
            return <View style={[classStyles.hiddenState]} />;
        }

        let style = [
            this.props.style,
            this.getContainerBackgroundColor(),
            this.getContainerJustifyContent(),
            this.getOpacity(),
        ];

        if (!this.state.onPress)
            return (
                <View
                    {...this.props}
                    disabled={this.state.disabled}
                    style={style}
                    onMouseOver={
                        !!this.props.hoverEffects || !!this.props.onHoverIn
                            ? this.onMouseOver
                            : undefined
                    }
                    onMouseOut={
                        !!this.props.hoverEffects || !!this.props.onHoverIn
                            ? this.onMouseOut
                            : undefined
                    }
                >
                    {this.props.children}
                </View>
            );

        return this.props.underlayColor ? (
            <TouchableHighlight
                {...this.props}
                onPress={this.onPress}
                onMouseOver={
                    !!this.props.hoverEffects || !!this.props.onHoverIn
                        ? this.onMouseOver
                        : undefined
                }
                onMouseOut={
                    !!this.props.hoverEffects || !!this.props.onHoverIn
                        ? this.onMouseOut
                        : undefined
                }
                disabled={this.state.disabled}
                style={style}
                activeOpacity={this.props.hoverEffect ? 0.5 : 1}
            >
                {this.props.children}
            </TouchableHighlight>
        ) : (
            <TouchableOpacity
                {...this.props}
                onPress={this.onPress}
                onMouseOver={
                    !!this.props.hoverEffects || !!this.props.onHoverIn
                        ? this.onMouseOver
                        : undefined
                }
                onMouseOut={
                    !!this.props.hoverEffects || !!this.props.onHoverIn
                        ? this.onMouseOut
                        : undefined
                }
                disabled={this.state.disabled}
                style={style}
                activeOpacity={1}
            >
                {this.props.children}
            </TouchableOpacity>
        );
    };

    onPress = (event) => {
        if (this.state.toggle)
            this.setState(
                { toggleState: !this.state.toggleState },
                () => this.state.onPress && this.state.onPress(event)
            );
        else this.state.onPress && this.state.onPress(event);
    };

    onMouseOver = (event) => {
        event.preventDefault();
        this.setState({ mouseEntered: true });
        this.props.onHoverIn && this.props.onHoverIn(event);
    };

    onMouseOut = (event) => {
        event.preventDefault();
        this.setState({ mouseEntered: false });
        this.props.onHoverOut && this.props.onHoverOut(event);
    };

    getToggledState = () => !!this.state.toggleState;

    resetToggledState = () => this.setState({ toggleState: false });

    setToggledState = (toggleState) => this.setState({ toggleState });

    setOnPress = (onPress) => this.setState({ onPress });

    setDisabled = (disabled) => this.setState({ disabled });

    setVisibility = (visible) => this.setState({ hidden: !visible });

    setBackgroundColor = (backgroundColor) =>
        this.setState({ backgroundColor });

    setJustifyContent = (justifyContent) => this.setState({ justifyContent });

    isVisible = () => !this.state.hidden;

    isEnabled = () => !this.state.disabled;
}

const classStyles = StyleSheet.create({
    hiddenState: {
        height: 0,
        width: 0,
        overflow: 'hidden',
    },
});
