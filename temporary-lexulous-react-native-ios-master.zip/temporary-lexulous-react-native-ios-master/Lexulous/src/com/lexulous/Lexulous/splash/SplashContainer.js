// @flow

import React from 'react';
import { connect, batch } from 'react-redux';
import { bindActionCreators } from 'redux';
import { CommonActions } from '@react-navigation/native';
import { StyleSheet, Text, View, ImageBackground, StatusBar, Image, Pressable, Platform } from 'react-native';
import UserNameContainer from '../components/UserNameContainer';
import DictionarySelectContainer from '../components/DictionarySelectContainer';
import type {
    SplashViewProps,
    ProfileInfo,
    userSettings,
    ServerResponse,
    GenGlobalIDRequest,
    GenGlobalIDResponseData,
    us_dictionary,
    LegacyAuthData,
    LegacyAuthResponse,
    LgnMedium,
    GamesListResponse,
    LXLSLoginInfo,
    FBLoginInfo,
    AlertBoxType,
} from '../commons/RJTypes';
import minStatsApi from '../stats/minimalstats/MinStatsApi';
import dataServer from '../store/Store';
import requestManager from '../commons/RequestManager';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import { actionUpdateProfile } from '../userprofile/PFLAction';
import * as CONSTANTS from '../commons/Constants';
import AccountSecureContainer from '../components/AccountSecureContainer';
import loginCoordinator from '../commons/LoginCoordinator';
import fbLgnMgr from '../commons/FBLgnMgr';
import applLgnMgr from '../commons/ApplLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import LoadingContainer from '../components/LoadingIndicator';
import netManager from '../commons/RJNetInfo';
import { updatePopupVisibility, clearPopups, showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import { actionUpdateUserSettings } from '../userprofile/PFLAction';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import userDefault from '../commons/UserDefault';
import RNBootSplash from 'react-native-bootsplash';
import * as ProfileSelector from '../userprofile/PFLSelector';
import pushNtfMgr from '../commons/PushNtfMgr';
import fndApi from '../friends/FndApi';
import glApi from '../gameslist/GLApi';
import { actionAddGames } from '../gameslist/GLAction';
import AlertBox from '../components/AlertBox';
import { handleException, showMessage } from '../commons/RJUtils';
import inAppPurchases from '../commons/iap/InAppPurchases';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import appConfiguration from '../commons/AppConfiguration';

type SplashContainerState = {
    userName: string,
    editedName: string,
};

class SplashContainer extends React.Component<SplashViewProps, SplashContainerState> {
    unsubscribeFocusListener: ?() => void = null;
    selectedDictionary: us_dictionary = CONSTANTS.Default_Dictionary;
    medium: ?LgnMedium = null;

    constructor(props: SplashViewProps) {
        super(props);
        this.state = {
            userName: '',
            editedName: '',
        };
    }

    componentDidMount() {
        Platform.OS === 'android' || Platform.OS === 'ios' ? RNBootSplash.hide() : null;
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (loginCoordinator.lgnMgr) {
                let performchecks: boolean = loginCoordinator.lgnMgr === lxlsLgnMgr;
                if (performchecks) {
                    this.medium = CONSTANTS.kPlatformLexCom;
                    loginCoordinator.onLXLSDotComFastLogin(this.onLoginCompletion);
                }
            }
        });
    }

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
    }

    userNameBeginEditing = () => {
        this.props.updatePopupVisibility({ showUserNamePopup: true });
    };

    userNameDidCancledEditing = () => {
        this.props.clearPopups();
    };

    userNameDidFinishedEditing = (name: string) => {
        this.props.clearPopups();
        this.props.updatePopupVisibility({ showDictionaryPopup: true });
        this.setState({ editedName: name });
    };

    dictDidCancledEditing = () => {
        this.props.clearPopups();
        this.props.updatePopupVisibility({ showUserNamePopup: true });
    };

    didSelectedDictionary = (prefdic: string) => {
        switch (prefdic) {
            case 'US English':
                this.selectedDictionary = CONSTANTS.US_English;
                break;
            case 'UK English':
                this.selectedDictionary = CONSTANTS.UK_English;
                break;
            case 'Italian':
                this.selectedDictionary = CONSTANTS.Italian;
                break;
            case 'French':
                this.selectedDictionary = CONSTANTS.French;
                break;
            default:
                this.selectedDictionary = CONSTANTS.US_English;
        }
        this.props.clearPopups();
        if (netManager.isConnected()) {
            this.genGlobalID();
        } else {
            this.startupRetryConfirmation(this.genGlobalID);
        }
    };

    dictDidFinishedEditing = (prefdic: string) => {
        let nameHasChanged: boolean = this.state.userName !== this.state.editedName;
        let prefDicHasChanged: boolean = prefdic !== null && prefdic !== undefined;
        if (nameHasChanged) {
            this.updateGuestData(this.state.editedName, null);
        }
        if (prefDicHasChanged) {
            //DO SOMETHING
            let settings: userSettings = {
                us_gamestart: {
                    gs_prefdic:
                        prefdic === 'US English'
                            ? CONSTANTS.US_English
                            : prefdic === 'UK English'
                            ? CONSTANTS.UK_English
                            : prefdic === 'Italian'
                            ? CONSTANTS.Italian
                            : CONSTANTS.French,
                },
            };
            this.updateUserSetting(settings);
        }
        this.props.clearPopups();
    };

    updateGuestData = (name: string, avtid: ?string) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateProfile(name, null);
            rsp.then((response) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    let usrpfl: ProfileInfo = { name: name };
                    dataServer.getStore().dispatch(actionUpdateProfile(usrpfl));
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    updateUserSetting = (settings: userSettings) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = requestManager.updateUserSetting(settings);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((result: ServerResponse) => {
                    const resetAction = CommonActions.reset({
                        index: 0,
                        routes: [{ name: 'Home' }],
                    });
                    this.props.navigation.dispatch(resetAction);
                    dataServer.getStore().dispatch(actionUpdateUserSettings(settings));
                    this.props.navigation.navigate('Home', { screen: 'New Game' });
                })
                .catch((error) => {
                    handleException(error);
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    genGlobalID = () => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            requestManager.doGenGlobalID((request: GenGlobalIDRequest, response: ServerResponse) => {
                if (response.check === CONSTANTS.kSuccess) {
                    let respdata: GenGlobalIDResponseData = ((response.data: any): GenGlobalIDResponseData);
                    if (respdata.guid !== undefined && respdata.uuid !== undefined) {
                        let guid = respdata.guid;
                        let uuid = respdata.uuid;
                        // let guid = '730005128462'; //TEST CODE
                        // let uuid = '10534322-bf9c-4d45-a35f-f4c9b8e9982b';
                        requestManager.onGenGlobalIDResponse(request, response);
                        let data = {
                            channel: CONSTANTS.kChannel,
                            guid: guid,
                            uuid: uuid,
                        };
                        requestManager.doGetProfile(data, (request, response) => {
                            requestManager.onDoGetProfileResponse(request, response);
                            let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                            if ((sguid ?? 0) !== 0) {
                                pushNtfMgr.doUpdateDevicePin(true);
                                this.updateGuestData(this.state.editedName, null);
                                let settings: userSettings = {
                                    us_gamestart: {
                                        gs_prefdic: this.selectedDictionary,
                                    },
                                };
                                this.updateUserSetting(settings);
                            }
                            dataServer.debouncedDispatch(actionSetIdle());
                        }); //NO NEED TO ADD GET PROFILE CALL
                    }
                } else {
                    dataServer.debouncedDispatch(actionSetIdle());
                }
                //NO ELSE CHECKING FOR REQUEST FAILURE
            });
        }
    };

    startupRetryConfirmation = (retry: () => void) => {
        rjAnalytics.sendAnalyticsEvent('internet_err_alert_open', 'splash_container');
        let alertBoxInfo: AlertBoxType = {
            message: translate('err_internet'),
            actions: [
                {
                    text: translate('retry'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('internet_err_alert_closed', 'splash_container');
                        retry();
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    };

    openAccnSecureContainer = () => {
        let source: string | null = appConfiguration.getApplicationSource();
        if (source != null && source == CONSTANTS.kDeskTopApp) {
            this.props.navigation.navigate('UserNameOREmail', {
                lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail,
            });
        } else {
            this.props.updatePopupVisibility({ showLoginPopup: true });
        }
    };

    closeAccnSecureContainer = () => {
        this.props.clearPopups();
    };

    onLoginCompletion = () => {
        if (this.medium != null && this.medium != undefined) {
            let fmedium: LgnMedium = this.medium;
            let authdata: ?LegacyAuthData = null;
            if (this.medium == CONSTANTS.kPlatformLexCom) {
                let lgninfo: ?LXLSLoginInfo = dataServer.getLxlsLoginInfo();
                if (
                    lgninfo != null &&
                    lgninfo != undefined &&
                    lgninfo.authuser != null &&
                    lgninfo.authuser != undefined &&
                    lgninfo.authsecret != null &&
                    lgninfo.authsecret != undefined
                ) {
                    authdata = {
                        lexcom: {
                            authuser: lgninfo.authuser,
                            authsecret: lgninfo.authsecret,
                        },
                        piggyback: CONSTANTS.kPlatformLexCom,
                    };
                } else {
                    // to do
                }
            } else if (this.medium == CONSTANTS.kPlatformFB) {
                let fblgninfo: ?FBLoginInfo = dataServer.getFbLoginInfo();
                if (
                    fblgninfo != null &&
                    fblgninfo != undefined &&
                    fblgninfo.fbAccessToken != null &&
                    fblgninfo.fbAccessToken != undefined
                ) {
                    let userid: string = fblgninfo.fbAccessToken.userID;
                    let accessToken: string = fblgninfo.fbAccessToken.accessToken;
                    authdata = {
                        fb: {
                            fb_sig_user: userid,
                            fb_sig_session_key: accessToken,
                        },
                        piggyback: CONSTANTS.kPlatformFB,
                    };
                } else {
                    // to do
                }
            }
            if (authdata != null && authdata != undefined) {
                let fauthdata: LegacyAuthData = authdata;
                this.doUserLogin(fmedium, fauthdata);
            }
        }
    };

    onUserDataFetchCompletion = () => {
        const resetAction = CommonActions.reset({
            index: 0,
            routes: [{ name: 'Home' }],
        });
        this.props.navigation.dispatch(resetAction);
        let hasgames = dataServer.hasActiveGames();
        if (!hasgames) {
            this.props.navigation.navigate('Home', { screen: 'New Game' });
        } else {
            userDefault.set(CONSTANTS.kPsistAppNwUser, 'false');
        }
    };

    onIntentFBLogin = () => {
        rjAnalytics.sendAnalyticsEvent('fb_login_btn_pressed', 'splash_container');
        this.medium = CONSTANTS.kPlatformFB;
        this.doFbLogin(this.onLoginCompletion);
    };

    doFbLogin = (onCompletionCallback: ?() => void) => {
        let callback = () => {
            loginCoordinator.onFBFastLogin(onCompletionCallback);
        };
        fbLgnMgr.doFbLogin(callback);
    };

    onIntentGoogleLogin = () => {
        rjAnalytics.sendAnalyticsEvent('google_login_btn_pressed', 'splash_container');
        this.medium = CONSTANTS.kPlatformLexCom;
        this.doGoogleLogin(this.onLoginCompletion);
    };

    doGoogleLogin = (onCompletionCallback: ?() => void) => {
        let callback = () => {
            loginCoordinator.onGoogleFastLogin(onCompletionCallback);
        };
        gglLgnMgr.doGoogleLogin(callback);
    };

    doAppleLogin = () => {
        rjAnalytics.sendAnalyticsEvent('apple_login_btn_pressed', 'splash_container');
        if (CONSTANTS.isAppleLoginSupported()) {
            this.medium = CONSTANTS.kPlatformLexCom;
            applLgnMgr.signInWithApple(loginCoordinator.onAppleFastLogin, this.onLoginCompletion);
        }
    };

    doLXLSDotComLogin = () => {
        rjAnalytics.sendAnalyticsEvent('lnr_vw_container_opened', 'splash_container');
        rjAnalytics.sendAnalyticsEvent('email_input_opened', 'splash_container');
        this.props.navigation.navigate('UserNameOREmail', {
            lrnVwCode: CONSTANTS.LNRVwCode.LNRVwCodeUserNameOREmail,
        });
    };

    doUserLogin = (medium: LgnMedium, authdata: LegacyAuthData) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p1: AxiosPromise<ServerResponse> = requestManager.getGuidUuid(authdata);
            p1.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((jresp: ServerResponse) => {
                    if (jresp.check === CONSTANTS.kSuccess) {
                        let authresp: LegacyAuthResponse = ((jresp.data: any): LegacyAuthResponse);
                        if (authresp[medium] != null && authresp[medium] != undefined) {
                            let uiddata: Array<string> = Object.keys(authresp[medium]);
                            let uid = uiddata[0];

                            let guid = authresp[medium][uid].guid;
                            let uuid = authresp[medium][uid].uuid;
                            if (guid != null && guid != undefined && uuid != null && uuid != undefined) {
                                requestManager.updatePsistDataGuidUuid(guid, uuid);
                                let data = { channel: CONSTANTS.kChannel, guid: guid, uuid: uuid };
                                requestManager.doGetProfile(data, (request, response) => {
                                    requestManager.onDoGetProfileResponse(request, response);
                                    minStatsApi.getLoggedInUserStats();
                                    fndApi.getFriendListCumulative(false);
                                    requestManager.fetchUserSettings();
                                    pushNtfMgr.doUpdateDevicePin(true);
                                    inAppPurchases.getPurchaseHistory();

                                    let profile = dataServer.getProfile();
                                    let promises: Array<AxiosPromise<ServerResponse>> = [];
                                    let p1: AxiosPromise<ServerResponse> = glApi.getActiveGamesList();
                                    promises.push(p1);
                                    let p2: AxiosPromise<ServerResponse> = glApi.getArchivedGamesList();
                                    promises.push(p2);
                                    Promise.all(promises)
                                        .then(async ([a, b]) => {
                                            let a1: ServerResponse = await a.data;
                                            let b1: ServerResponse = await b.data;
                                            if (a1.check === CONSTANTS.kSuccess && b1.check === CONSTANTS.kSuccess) {
                                                let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                                                let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                                                batch(() => {
                                                    dataServer.debouncedDispatch(actionSetIdle());
                                                    dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                                                    dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                                                });
                                            } else if (a1.check === CONSTANTS.kSuccess) {
                                                let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                                                batch(() => {
                                                    dataServer.debouncedDispatch(actionSetIdle());
                                                    dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                                                });
                                            } else if (b1.check === CONSTANTS.kSuccess) {
                                                let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                                                batch(() => {
                                                    dataServer.debouncedDispatch(actionSetIdle());
                                                    dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                                                });
                                            }
                                            this.onUserDataFetchCompletion();
                                        })
                                        .catch((error) => {
                                            showMessage(translate('err_code_010'), 'splash_container');
                                            dataServer.debouncedDispatch(actionSetIdle());
                                        });
                                });
                            }
                        } else {
                            dataServer.debouncedDispatch(actionSetIdle());
                            loginCoordinator.doSignOutMostRecentLogin(true, translate('err_code_009'));
                        }
                    } else {
                        dataServer.debouncedDispatch(actionSetIdle());
                        loginCoordinator.doSignOutMostRecentLogin(true, translate('err_code_006'));
                    }
                })
                .catch((error) => {
                    loginCoordinator.doSignOutMostRecentLogin(true, translate('err_code_003'));
                })
                .finally(() => {
                    dataServer.debouncedDispatch(actionSetIdle());
                });
        }
    };

    renderUserNameContainer = () => {
        if (this.props.popups.showUserNamePopup) {
            return (
                <UserNameContainer
                    editingCancledHandler={() => {
                        this.userNameDidCancledEditing();
                        rjAnalytics.sendAnalyticsEvent('user_name_editing_canceled', 'splash_container');
                    }}
                    editingFinishedHandler={(name: string) => {
                        rjAnalytics.sendAnalyticsEvent('user_name_editing_finished', 'splash_container');
                        rjAnalytics.sendAnalyticsEvent('dict_editing_opened', 'splash_container');
                        this.userNameDidFinishedEditing(name);
                    }}
                    btnAutoEnable={true}
                    btnTxt={translate('next')}
                    avoidKeyboard={true}
                    userName={this.state.editedName}
                />
            );
        } else {
            return null;
        }
    };

    renderDictionarySelectContainer = () => {
        if (this.props.popups.showDictionaryPopup) {
            return (
                <DictionarySelectContainer
                    btnTxt={translate('play')}
                    editingCancledHandler={() => {
                        this.dictDidCancledEditing();
                        rjAnalytics.sendAnalyticsEvent('dict_editing_closed', 'splash_container');
                    }}
                    editingFinishedHandler={(prefdict: string) => {
                        this.didSelectedDictionary(prefdict);
                        rjAnalytics.sendAnalyticsEvent('dict_editing_finished', 'splash_container');
                    }}
                />
            );
        } else {
            return null;
        }
    };

    renderAccountSecureContainer = () => {
        if (this.props.popups.showLoginPopup) {
            return (
                <AccountSecureContainer
                    closePopupHandler={() => {
                        rjAnalytics.sendAnalyticsEvent('acc_secure_container_closed', 'lnr_vw_container');
                        this.closeAccnSecureContainer();
                    }}
                    fbLoginHandler={this.onIntentFBLogin}
                    googleLoginHandler={this.onIntentGoogleLogin}
                    appleLoginHandler={this.doAppleLogin}
                    lxlsLoginHandler={this.doLXLSDotComLogin}
                />
            );
        } else {
            return null;
        }
    };

    render() {
        let pic = Platform.select({
            native: () => {
                return { uri: 'splash' };
            },
            default: () => {
                return {
                    uri: require('../assets/web_screen/web_splash_screen.png'),
                };
            },
        });
        return (
            <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                <StatusBar hidden={true} animated={true} />
                <LoadingContainer />
                <AlertBox />
                <ImageBackground source={pic()} style={styles.bkgImage}>
                    <View style={styles.btnPanel}>
                        {this.renderUserNameContainer()}
                        {this.renderDictionarySelectContainer()}
                        {this.renderAccountSecureContainer()}
                        <View style={styles.btnLogoContainer}>
                            <View style={styles.logoContainer}>
                                <Image source={require('../assets/splash/splash_logo.png')} style={styles.logo} />
                            </View>
                            <Pressable
                                style={styles.signinBtn}
                                onPress={() => {
                                    rjAnalytics.sendAnalyticsEvent('acc_secure_container_opened', 'splash_container');
                                    this.openAccnSecureContainer();
                                }}
                            >
                                <Text style={styles.signinBtnText}>{translate('alrdy_Accnt_Msg')}</Text>
                            </Pressable>
                            <Pressable
                                style={styles.skipBtn}
                                onPress={() => {
                                    this.userNameBeginEditing();
                                    rjAnalytics.sendAnalyticsEvent('user_name_editing_started', 'splash_container');
                                }}
                            >
                                <Text style={[styles.skipBtnText, { color: '#FFFFFF' }]}>{translate('setup_Accnt_Msg')}</Text>
                            </Pressable>
                        </View>
                    </View>
                </ImageBackground>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    bkgImage: {
        flex: 1,
        width: '100%',
        height: '100%',
        justifyContent: 'center',
    },
    btnPanel: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'flex-end',
        paddingBottom: 30,
        zIndex: 1,
    },
    logoContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    logo: {
        width: 200,
        height: 60,
        resizeMode: 'contain',
    },
    btnLogoContainer: {
        zIndex: -1,
    },
    signinBtn: {
        alignSelf: 'center',
        marginTop: 10,
        padding: 10,
        backgroundColor: '#1d9df1',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#1d9df1',
    },
    signinBtnText: {
        color: '#FFFFFF',
        textAlign: 'center',
        paddingLeft: 10,
        paddingRight: 10,
    },
    skipBtn: {
        // marginRight: '40%',
        // marginLeft: '40%',
        marginTop: 10,
        paddingTop: 10,
        paddingBottom: 10,
    },
    skipBtnText: {
        textAlign: 'center',
        paddingLeft: 10,
        paddingRight: 10,
        textDecorationLine: 'underline',
    },
});

function mapStateToProps(state) {
    const { popups, utils } = state;
    return { popups, utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            updatePopupVisibility,
            clearPopups,
            showAlert,
            clearAlert,
            actionUpdateUserSettings,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(SplashContainer);
