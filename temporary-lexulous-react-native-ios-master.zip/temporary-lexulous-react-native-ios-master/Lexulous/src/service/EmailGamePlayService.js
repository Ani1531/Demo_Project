import { getCallType, pingPolling } from './GamePlayService';
import Config from '../configs/Config';
import to from 'await-to-js';
import GameBoardUtils from '../utils/GameBoardUtils';
import { getCustomMessage } from '../utils/MessageUtils';
import get from 'lodash/get';
import { Base64 } from 'js-base64';
import WebSocketProvider from '../provider/WebSocketProvider';
import {
    GAME_EMAIL_GET_GAME_NOTES,
    GAME_EMAIL_SET_GAME_NOTES,
    GAME_HAS_ENDED,
    GAME_MOVE,
    GAME_MOVE_COUNT_SET,
    GAME_SET_NOTES_FAILED,
    GAME_SET_NOTES_STARTED,
    GAME_STARTED,
} from '../configs/ActionIdentifiers';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import store from '../store';
import { checkNativeGamelistUpdate } from '../utils/Utils';

require('format-unicorn');
const eventBus = require('js-event-bus')();

export const emailPingPolling = async () => {
    pingPolling();
};

export const sendEmailMove = async (moveArr) => {
    const state = store.getState();
    let requestMethod = getCallType('sendEmailMove');

    let params = {
        channel: state.game.channel,
        action: Config.SEND_EMAIL_GAME_MOVE_DATA_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
        move: moveArr,
        mxscr: String(state.game.maxScore),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        let moveTiles =
            get(res[1], state.game.channel + '.boarddata.movetiles') ||
            get(res[1], 'data.' + state.game.channel + '.boarddata.movetiles') ||
            [];
        let moveCount = (state.game.moveCount || 0) + moveTiles.length;
        let currentTurn = get(res[1], state.game.channel + '.current_turn');
        if (currentTurn === undefined || currentTurn === null) {
            currentTurn = get(res[1], 'data.' + state.game.channel + '.current_turn');
        }
        let winner = get(res[1], state.game.channel + '.winner');
        eventBus.emit(GAME_MOVE_COUNT_SET, null, moveCount);
        eventBus.emit(GAME_MOVE, null, res[1]);
        GameBoardUtils.setDatas(res[1]);
        GameBoardUtils.setTilesInBag(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        eventBus.emit(Config.SEND_EMAIL_GAME_MOVE_SUCCESSFUL, null, res[1]);
        checkNativeGamelistUpdate({ ...res[1], gid: state.game.gid });
    }

    return res[1];
};

export const passMoveEmailGame = async () => {
    const state = store.getState();
    let requestMethod = getCallType('sendEmailPass');

    let params = {
        channel: state.game.channel,
        action: Config.SEND_EMAIL_GAME_PASS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
        mxscr: String(state.game.maxScore),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_MOVE, null, res[1]);
        GameBoardUtils.setDatas(res[1]);
        GameBoardUtils.setTilesInBag(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        eventBus.emit(Config.SEND_EMAIL_GAME_PASS_SUCCESSFUL, null, res[1]);
        checkNativeGamelistUpdate({ ...res[1], gid: state.game.gid });
        return res[1];
    }
};

export const sendEmailSwapTilesRequest = async (tiles) => {
    const state = store.getState();
    let requestMethod = getCallType('sendEmailSwap');
    let params = {
        channel: state.game.channel,
        action: Config.SWAP_TILES_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
        swaptiles: GameBoardUtils.makeRackString(tiles),
        mxscr: String(state.game.maxScore),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.SWAP_TILES_EMAIL_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        GameBoardUtils.setDatas(res[1]);
        GameBoardUtils.setTilesInBag(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        eventBus.emit(Config.SWAP_TILES_EMAIL_GAME_REQUEST_SUCCESSFUL, null, res[1]);
        checkNativeGamelistUpdate({ ...res[1], gid: state.game.gid });
    }

    return res[1];
};

export const resignEmailGame = async (doDelete = false) => {
    const state = store.getState();
    let requestMethod = getCallType('sendEmailResign');
    let params = {
        channel: state.game.channel,
        action: doDelete ? Config.DELETE_GAME : Config.RESIGN_GAME_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(
            doDelete ? Config.DELETE_EMAIL_GAME_REQUEST_FAILED : Config.RESIGN_EMAIL_GAME_REQUEST_FAILED,
            null,
            extObj
        );
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_HAS_ENDED, null, res[1]);
        GameBoardUtils.setDatas(res[1]);
        res[1].data = {
            ...(res[1].data || {}),
            guid: state.game.guid,
        };
        eventBus.emit(
            doDelete ? Config.DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL : Config.RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL,
            null,
            res[1]
        );
        checkNativeGamelistUpdate({ ...res[1], gid: state.game.gid });
    }

    return res[1];
};

export const sendEmailRematchRequest = async () => {
    const state = store.getState();
    let requestMethod = getCallType('sendEmailRematch');
    let params = {
        channel: state.game.channel,
        action: Config.REMATCH_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_STARTED, null, res[1]);
        GameBoardUtils.setDatas(res[1]);
    }

    return res[1];
};

export const getNextGameUrl = async (rawData) => {
    const state = store.getState();
    let requestMethod = getCallType('nextGameUrl');
    let params = {
        channel: state.game.channel,
        action: Config.NEXT_GAME_URL_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        return rawData
            ? res[1]
            : ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('next_game_url').formatUnicorn(get(res[1], 'data'));
    }
};

export const setGameNotes = async (notes) => {
    const state = store.getState();
    eventBus.emit(GAME_SET_NOTES_STARTED);
    let requestMethod = getCallType('setGameNotes');
    let params = {
        channel: state.game.channel,
        action: Config.SET_GAME_NOTES_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
        note: Base64.encode(notes),
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(GAME_SET_NOTES_FAILED);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_EMAIL_SET_GAME_NOTES, null, notes);
        return res[1];
    }
};

export const getGameNotes = async () => {
    const state = store.getState();
    if (state.game.emailGameNotes) {
        let res = state.game.emailGameNotes;
        return res;
    }
    let requestMethod = getCallType('getGameNotes');
    let params = {
        channel: state.game.channel,
        action: Config.GET_GAME_NOTES_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_EMAIL_GET_GAME_NOTES, null, res[1]);
        return res[1];
    }
};

export const readAllChatMessages = async () => {
    const state = store.getState();
    let requestMethod = getCallType('readAllChatMessages');
    let params = {
        channel: state.game.channel,
        action: Config.READ_ALL_CHAT_MESSAGES_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }
    return res[1];
};
