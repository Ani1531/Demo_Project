import React from 'react';

export default class ReactCustomTooltipExp extends React.PureComponent {
    render = () => null;
}
