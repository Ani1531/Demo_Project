// @flow

import AppLovinMAX from 'react-native-applovin-max';
import { kApplovinSdkKey, kPrivacyPolicyUrl } from '../Constants';
import bannerAd from './BannerAd';
import interstitialAd from './InterstitialAd';
import rewardedAdNF from './RewardedAdNF';

class AdMgr {
    adSdkInited: boolean = false;
    constructor() {
        this.adSdkInited = false;
    }
    onAppInit = (): void => {
        AppLovinMAX.setTestDeviceAdvertisingIds([]);
        AppLovinMAX.setVerboseLogging(true);
        AppLovinMAX.setConsentFlowEnabled(true);
        AppLovinMAX.setPrivacyPolicyUrl(kPrivacyPolicyUrl);
        AppLovinMAX.setTermsOfServiceUrl(kPrivacyPolicyUrl);
        AppLovinMAX.initialize(kApplovinSdkKey, (configuration) => {
            bannerAd.onAppInit();
            interstitialAd.onAppInit();
            rewardedAdNF.onAppInit();
        });
    };
}

const adMgr: AdMgr = new AdMgr();

export default adMgr;
