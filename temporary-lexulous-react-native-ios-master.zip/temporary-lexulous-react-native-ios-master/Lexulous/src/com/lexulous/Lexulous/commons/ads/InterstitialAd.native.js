// @flow

import AppLovinMAX from 'react-native-applovin-max';
import rewardedAdNF from './RewardedAdNF';
import { kInterStitialAdUnit } from '../Constants';
import dataServer from '../../store/Store';
import inAppPurchases from '../iap/InAppPurchases';

class InterstitialAd {
    retryAttempt = 0;

    //will show interstitial if is set to 0
    interstitialTrigger: number = 5; //first interstitial after five screen changes
    onCompletion: () => void = () => {};
    constructor() {}
    onAppInit = (): void => {
        AppLovinMAX.addEventListener('OnInterstitialLoadedEvent', () => {
            this.retryAttempt = 0;
        });
        AppLovinMAX.addEventListener('OnInterstitialLoadFailedEvent', () => {
            this.retryAttempt = this.retryAttempt + 1;
            var retryDelay = Math.pow(2, Math.min(5, this.retryAttempt));
            setTimeout(function () {
                AppLovinMAX.loadInterstitial(kInterStitialAdUnit);
            }, retryDelay * 1000);
        });
        AppLovinMAX.addEventListener('OnInterstitialClickedEvent', () => {});
        AppLovinMAX.addEventListener('OnInterstitialDisplayedEvent', () => {});
        AppLovinMAX.addEventListener('OnInterstitialAdFailedToDisplayEvent', () => {
            AppLovinMAX.loadInterstitial(kInterStitialAdUnit);
            this.onAdCompletion(false);
        });
        AppLovinMAX.addEventListener('OnInterstitialHiddenEvent', () => {
            AppLovinMAX.loadInterstitial(kInterStitialAdUnit);
            this.onAdCompletion(true);
        });
        AppLovinMAX.loadInterstitial(kInterStitialAdUnit);
    };

    showInterstitialAd = (rewardedPreferred: boolean, onCompletion: () => void): void => {
        this.onCompletion = onCompletion;
        if (dataServer.isProUser() || inAppPurchases.isAdFreeSubsActive()) {
            this.onAdCompletion(false);
            return;
        }
        let showInterstitial: boolean = this.interstitialTrigger == 0;
        if (rewardedPreferred && rewardedAdNF.canShowRewardedNFInterstitial() && showInterstitial) {
            let rewardedCompletion = (shown: boolean): void => {
                this.onAdCompletion(shown);
            };
            rewardedAdNF.showRewardedNFInterstitialAd(rewardedCompletion);
        } else {
            if (AppLovinMAX.isInterstitialReady(kInterStitialAdUnit) && showInterstitial) {
                AppLovinMAX.showInterstitial(kInterStitialAdUnit, null, null);
            }
        }
        if (!showInterstitial) {
            this.onAdCompletion(false);
        }
    };

    genRandom = (min: number, max: number): number => {
        return Math.floor(Math.random() * (max - min)) + min;
    };

    onAdCompletion = (shown: boolean) => {
        let temp = this.onCompletion;
        if (shown) {
            this.interstitialTrigger = this.genRandom(4, 8);
        } else {
            if (this.interstitialTrigger > 0) {
                this.interstitialTrigger--;
            }
        }
        this.onCompletion = () => {};
        if (temp) {
            temp();
        }
    };
}

const interstitialAd: InterstitialAd = new InterstitialAd();

export default interstitialAd;
