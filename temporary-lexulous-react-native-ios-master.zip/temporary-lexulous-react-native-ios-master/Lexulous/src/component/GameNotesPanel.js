import React from 'react';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import { StyleSheet, TextInput, View } from 'react-native';
import Config from '../configs/Config';
import { getGameNotes, setGameNotes } from '../service/EmailGamePlayService';
import ColorConfig, {
    StandardButtonMouseHoverEffect,
} from '../configs/ColorConfig';
import StandardButton from './StandardButton';
import { connect } from 'react-redux';
import { CELL_REDUCER_CLEAR_DIRECTION } from '../configs/ActionIdentifiers';

const eventBus = require('js-event-bus')();

class GameNotesPanel extends React.PureComponent {
    state = {};
    textInputRef = React.createRef();

    static getDerivedStateFromProps = (props, state) => ({
        ...(state || {}),
        currentNotes:
            typeof state.currentNotes !== 'undefined'
                ? state.currentNotes
                : typeof get(props, 'game.emailGameNotes') === 'string'
                ? get(props, 'game.emailGameNotes')
                : get(props, 'game.emailGameNotes.data.note'),
    });

    componentDidMount = () => {
        getGameNotes();

        if (
            get(this.props, 'game.tabWasSetByClicking') &&
            get(this.props, 'game.gameBoardSideLayoutActiveTab') === 2
        ) {
            this.textInputRef.current.focus();
        }
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(this.props, nextProps) || !isEqual(this.state, nextState);

    focusTextInput = () => this.textInputRef.current.focus();

    onKeyDown = (event) => {
        event.stopPropagation();
    };

    onFocus = (e) => {
        eventBus.emit(CELL_REDUCER_CLEAR_DIRECTION);
        e.currentTarget.setSelectionRange(
            e.currentTarget.value.length,
            e.currentTarget.value.length
        );
    };

    onNotesPanelTextChange = (currentNotes) => this.setState({ currentNotes });

    getButtonStyles = () => ({
        width:
            get(this.props, 'layout.cellDimen') +
            2 * (get(this.props, 'layout.cellDimen') / 3.5),
        height: get(this.props, 'layout.cellDimen'),
        fontSize: get(this.props, 'layout.cellDimen') / 2.3,
        minWidth:
            get(this.props, 'layout.cellDimen') +
            2 * (get(this.props, 'layout.cellDimen') / 3.5),
        paddingHorizontal:
            (get(this.props, 'layout.cellDimen') +
                2 * (get(this.props, 'layout.cellDimen') / 3.5)) *
            0.1,
    });

    render = () => {
        return (
            <View
                style={[
                    styles.styleGameNotesContainer,
                    styles.flex1,
                    this.props.bottomCornerStyle &&
                        this.props.bottomCornerStyle(),
                ]}
            >
                <StandardButton
                    loaderVisible={this.props.game.savingEmailGameNotes}
                    style={[
                        styles.styleSaveNotesTouchable,
                        this.getButtonStyles(),
                    ]}
                    onPress={this.onSaveNotes}
                    text="Save"
                    textStyle={[
                        styles.saveNotesTextStyle,
                        { fontSize: this.getButtonStyles().fontSize },
                    ]}
                    fontSize={this.getButtonStyles().fontSize}
                    logHeight={true}
                    mouseHoverEffect={StandardButtonMouseHoverEffect}
                />
                <TextInput
                    placeholder={'Scribble notes here...'}
                    value={this.state.currentNotes}
                    onChangeText={this.onNotesPanelTextChange}
                    onFocus={this.onFocus}
                    multiline={true}
                    style={styles.saveNotesTextInputStyle}
                    onKeyPress={this.onKeyDown}
                    ref={this.textInputRef}
                    autoComplete={'off'}
                    autoCompleteType={'off'}
                />
                {this.props.game.savingEmailGameNotes ? (
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            styles.overlayContainer,
                        ]}
                    />
                ) : null}
            </View>
        );
    };

    onSaveNotes = () => {
        let emailGameNotes = this.props.game.emailGameNotes;
        let notes =
            typeof emailGameNotes === 'string'
                ? emailGameNotes
                : get(emailGameNotes, 'data.note');
        if (
            this.state.currentNotes.trim() !== '' &&
            notes !== this.state.currentNotes
        ) {
            setGameNotes(this.state.currentNotes);
        }
    };
}

const styles = StyleSheet.create({
    styleGameNotesContainer: {
        flexDirection: 'column-reverse',
        backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderLeftWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: StyleSheet.hairlineWidth,
        padding: 5,
        alignItems: 'flex-start',
    },
    styleSaveNotesTouchable: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 5,
        overflow: 'hidden',
        marginTop: 5,
        borderRadius: Config.COMMON_BORDER_RADIUS,
        backgroundColor: ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR,
    },
    saveNotesTextStyle: {
        color: ColorConfig.PLAY_BUTTON_TEXT_COLOR,
    },
    saveNotesTextInputStyle: {
        flex: 1,
        backgroundColor: ColorConfig.DEFAULT_CELL_BACKGROUND_COLOR,
        padding: 5,
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        width: '100%',
    },
    overlayContainer: {
        height: '100%',
        width: '100%',
        backgroundColor: 'transparent',
        overflow: 'hidden',
    },
    flex1: { flex: 1 },
});

const mapStateToProps = (state) => ({
    game: state.game,
    layout: state.layout,
});

export default connect(mapStateToProps)(GameNotesPanel);
