// @flow
import React from 'react';
import type { NavigationProp } from '@react-navigation/native';
import { StyleSheet, View, Pressable, Platform } from 'react-native';
import App from '../../../../App';
import { cellReducerEmptyGameboard } from '../../../../actions/CellActions';
import { reloadApp } from '../../../../actions/GameActions';
import dataServer from '../store/Store';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import rjAnalytics from '../../../../RJAnalytics';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { actionReadChat } from '../gameslist/GLAction';
import store from '../../../../store';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import appConfiguration from '../commons/AppConfiguration';
import themeConfigutation from '../commons/ThemeConfiguration';
import { SafeAreaView } from 'react-native-safe-area-context';

type GameBoardState = {
    isFocused: boolean,
};

class GameBoardContainer extends React.Component<{ navigation: NavigationProp }, GameBoardState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    unsubscribeCleanListener: ?() => void = null;

    constructor(props: { navigation: NavigationProp }) {
        super(props);
        this.state = {
            isFocused: false,
        };
    }

    componentDidMount() {
        this.props.navigation.setOptions({
            headerLeft: () => {
                return (
                    <Pressable
                        style={styles.backButton}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('board_screen_closed', 'game_board_container');
                            this.props.navigation.goBack();
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
                    </Pressable>
                );
            },
        });
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                this.setState({ isFocused: false });
            }
        });
        if (gameBoardDataExchanger.gameBoardData != null && gameBoardDataExchanger.gameBoardData != undefined) {
            let gbddata: gameBoardDataExchng = gameBoardDataExchanger.gameBoardData;
            let notifyContextStore: string | null = appConfiguration.getNotifyContextStorePlugin();
            if (notifyContextStore != null) {
                gbddata.notifyFBContext = window[notifyContextStore];
            }
            let updateContextStore: string | null = appConfiguration.getUpdateContextStorePlugin();
            if (updateContextStore != null) {
                gbddata.updateContextStore = window[updateContextStore];
            }
            let isblindgame: boolean = gbddata.isBlindGame ?? false;
            if (isblindgame) {
                gbddata.onBlindGameMove = () => {
                    let onBlindGameMove: string | null = appConfiguration.getOnBlindGameMovePlugin();
                    if (onBlindGameMove != null) {
                        let onCompletion = (error: Error | null, value: string | null): void => {
                            if (error != null) {
                                console.log('gid error :: ' + JSON.stringify(error));
                            } else if (value != null) {
                                console.log('get gid success :: ' + value);
                            }
                        };
                        window[onBlindGameMove](onCompletion, gbddata.gid);
                    } else {
                        console.log('onBlindGameMove empty');
                    }
                };
            }
            gameBoardDataExchanger.gameBoardData = gbddata;
        }
    }

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    getCstmSupport = () => {
        this.props.navigation.navigate('CustomerSupportScreen');
    };

    gameBoardGoBack = () => {
        let baordtermactions = Platform.select({
            native: () => {},
            default: () => {
                let gidArray = [store.getState().game.gid];
                dataServer.getStore().dispatch(actionReadChat(gidArray));
            },
        });
        baordtermactions();
        this.props.navigation.goBack();
    };

    render() {
        return this.state.isFocused ? (
            <SafeAreaView style={styles.containerWrapper}>
                <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#fff') }]}>
                    <App showBoardContainer={true} openSupport={this.getCstmSupport} gameBoardGoBack={this.gameBoardGoBack} />
                </View>
            </SafeAreaView>
        ) : null;
    }

    /* render() {
        return this.state.isFocused ? (
            <View style={styles.container}>
                <Text>{JSON.stringify(gameBoardDataExchanger.gameBoardData, null, '\t')}</Text>
            </View>
        ) : null;
    } */
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    backButton: {
        padding: 10,
    },
    containerWrapper: {
        flex: 1,
    },
});
const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            cellReducerEmptyGameboard,
            reloadApp,
        },
        dispatch
    );
export default connect(null, mapDispatchToProps)(GameBoardContainer);
