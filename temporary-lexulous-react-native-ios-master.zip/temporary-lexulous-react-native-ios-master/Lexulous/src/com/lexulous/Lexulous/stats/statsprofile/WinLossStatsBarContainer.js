// @flow
import React, { Component } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import type { WinLossStatsBarType } from '../../commons/RJTypes';
import rjAnalytics from '../../../../../RJAnalytics';
import themeConfigutation from '../../commons/ThemeConfiguration';

type StatsBarState = {
    toggleBingo: boolean,
};
type StatsBarProps = {
    statdata: WinLossStatsBarType,
    isForHostedGame: boolean,
};

export default class WinLossStatsBarContainer extends Component<StatsBarProps, StatsBarState> {
    constructor(props: StatsBarProps) {
        super(props);
        this.state = {
            toggleBingo: !props.isForHostedGame,
        };
    }
    shouldComponentUpdate(nextProps: StatsBarProps, nextState: StatsBarState) {
        return nextProps.statdata !== this.props.statdata || nextState.toggleBingo !== this.state.toggleBingo;
    }

    getBingoDisplay = () => {
        return (
            <View style={styles.stattextContainer}>
                <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }}>
                    Bingos: {this.props.statdata.bingos}
                </Text>
                <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }}>
                    Games: {this.props.statdata.games}
                </Text>
            </View>
        );
    };
    getstatDisplay = () => {
        return (
            <View style={styles.stattextContainer}>
                <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }}>Won: {this.props.statdata.won}</Text>
                <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }}>
                    Draw: {this.props.statdata.drawn}
                </Text>
                <Text style={{ fontSize: 14, color: themeConfigutation.getColor('#000') }}>
                    Lost: {this.props.statdata.lost}
                </Text>
            </View>
        );
    };
    getWinFlex = () => ({
        flex: this.props.statdata.won == 0 ? 1 : this.props.statdata.won,
    });
    getlostFlex = () => ({
        flex: this.props.statdata.lost == 0 ? 1 : this.props.statdata.lost,
    });
    getdrawFlex = () => ({
        flex: this.props.statdata.drawn,
    });
    onChangeBingo = () => {
        this.setState({ toggleBingo: !this.state.toggleBingo });
    };
    renderStatinfo = () => {
        if (this.state.toggleBingo) {
            return this.getBingoDisplay();
        } else {
            return this.getstatDisplay();
        }
    };
    render() {
        return (
            <View>
                <Pressable
                    disabled={this.props.isForHostedGame}
                    onPress={() => {
                        rjAnalytics.sendAnalyticsEvent('win_loss_bar_toggled', 'win_loss_stats_bar_container');
                        this.onChangeBingo();
                    }}
                    style={styles.statbar}
                >
                    <View
                        style={[
                            this.getWinFlex(),
                            {
                                backgroundColor: this.props.statdata.won != 0 ? '#E9A817' : '#C0C9CE',
                                height: 8,
                                borderTopLeftRadius: 17,
                                borderBottomLeftRadius: 17,
                            },
                        ]}
                    />
                    <View style={[this.getdrawFlex(), { backgroundColor: '#224884', height: 8 }]} />
                    <View
                        style={[
                            this.getlostFlex(),
                            { backgroundColor: '#C0C9CE', height: 8, borderTopRightRadius: 17, borderBottomRightRadius: 17 },
                        ]}
                    />
                </Pressable>
                {this.renderStatinfo()}
            </View>
        );
    }
}
const styles = StyleSheet.create({
    statbar: {
        marginHorizontal: 8,
        marginBottom: 4,
        marginTop: 4,
        flexDirection: 'row',
        backgroundColor: '#C0C9CE',
        borderRadius: 17,
    },
    stattextContainer: {
        marginHorizontal: 8,
        marginBottom: 4,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
});
