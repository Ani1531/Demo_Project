// @flow

import { kDeepLinkDomain } from './Constants';

const config = {
    screens: {
        AppSplash: {
            screens: {
                Splash: 'lgn',
                Home: {
                    path: 'home',
                    screens: {
                        initialRouteName: 'home',
                        Friends: 'friends',
                        'New Game': 'newgame',
                        Settings: 'settings',
                    },
                },
                StatsProfile: {
                    path: 'abhijit/lexulouscom/php/v2/player/:guid',
                },
                BoardScreen: 'game',
                UserNameOREmail: 'usernameoremail',
                ExstPwd: 'exstpwd',
                RegUserName: 'reguname',
                RegPwd: 'regpwd',
                Tutorial: 'tutorial',
                CustomerSupportScreen: 'support',
                Theme: 'theme',
                AGLContainer: 'archive',
            },
        },
    },
};

const RJSLinks = {
    prefixes: [kDeepLinkDomain, 'lxls://gbd', 'https://localhost:8080', 'http://localhost:8080'],
    config,
};

export default RJSLinks;
