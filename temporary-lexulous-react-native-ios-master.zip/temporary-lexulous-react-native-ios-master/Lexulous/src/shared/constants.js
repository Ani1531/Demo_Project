module.exports = {
    channels: {
        APP_INFO: 'app_info',
        NOTIFICATION_INFO: 'notification_info',
        ACTION_CHAT_SCAM_ALERT: 'chat_scam_alert',
        ACTION_LOBBY_CHAT_SCAM_ALERT: 'lobby_chat_scam_alert',
    },
};
