import { gameHasEnded } from './GameActions';
import {
    SET_PLAYER_STATUS_AVL_AFTER_GAME_HAS_ENDED,
    REMOVE_OBSERVABLE_GAME_FROM_LIST_AFTER_GAME_HAS_ENDED,
} from '../configs/ActionIdentifiers';
import { batch } from 'react-redux';

export const gameOver = (messageObj) => (dispatch, getState) => {
    batch(() => {
        dispatch(gameHasEnded(messageObj, getState()));

        dispatch({
            type: SET_PLAYER_STATUS_AVL_AFTER_GAME_HAS_ENDED,
            payload: messageObj,
            globalState: getState(),
        });
        dispatch({
            type: REMOVE_OBSERVABLE_GAME_FROM_LIST_AFTER_GAME_HAS_ENDED,
            payload: messageObj,
            globalState: getState(),
        });
    });
};
