// @flow

import React from 'react';
import { connect } from 'react-redux';
import { StyleSheet, Text, View, Pressable, Modal, Image } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import type { AlertBoxType, PopupData, AppUtilsTypes } from '../commons/RJTypes';
import { AlertBoxButtonType } from '../commons/Constants';
import themeConfigutation from '../commons/ThemeConfiguration';

type AlertBoxPropsType = { popups: PopupData, utils: AppUtilsTypes };

class AlertBox extends React.Component<AlertBoxPropsType> {
    renderTitle(AlertInfo: Array<AlertBoxType>) {
        let title = null;
        if (AlertInfo[0].title) {
            title = (
                <Text style={[styles.titleStyle, { color: themeConfigutation.getColor('#212121') }]}>{AlertInfo[0].title}</Text>
            );
        }
        return title;
    }

    renderCloseButton(AlertInfo: Array<AlertBoxType>) {
        let closeButton = null;
        let buttonInfo = AlertInfo[0].actions?.find(
            ({ type }) => type === AlertBoxButtonType.SHOWCANCELONLY || type === AlertBoxButtonType.SHOWBOTH
        );
        if (buttonInfo) {
            closeButton = (
                <Pressable
                    onPress={() => {
                        this.removeAlert(buttonInfo.action);
                    }}
                    style={[styles.xBtnStyle]}
                >
                    <FontAwesomeIcon icon={faTimes} size={22} color={themeConfigutation.getColor('#000')} />
                </Pressable>
            );
        }
        return closeButton;
    }

    renderTitleSection = (AlertInfo: Array<AlertBoxType>) => {
        return (
            <View style={styles.titleSection}>
                {AlertInfo[0].title_icon ? <Image style={styles.msgIcon} source={AlertInfo[0].title_icon} /> : null}
                {this.renderTitle(AlertInfo)}
                {this.renderCloseButton(AlertInfo)}
            </View>
        );
    };

    renderMessage(AlertInfo: Array<AlertBoxType>) {
        let message = null;
        if (AlertInfo[0].message) {
            message = (
                <View style={styles.msgSection}>
                    {AlertInfo[0].message_icon ? <Image style={styles.msgIcon} source={AlertInfo[0].message_icon} /> : null}
                    <Text selectable={true} numberOfLines={5} style={[styles.bodyTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                        {AlertInfo[0].message}
                    </Text>
                </View>
            );
        }
        return message;
    }

    renderButton(AlertInfo: Array<AlertBoxType>) {
        return (
            <View style={styles.btnSection}>
                {AlertInfo[0].actions.map(({ text, action, color, type }, index) => {
                    let buttonStyle = [
                        styles.buttonStyle,
                        {
                            backgroundColor: themeConfigutation.getColor(color.bgColor),
                            borderColor: themeConfigutation.getColor('#f1f2f6'),
                        },
                    ];
                    let buttonTextStyle = [styles.buttonTextStyle, { color: themeConfigutation.getColor(color.textColor) }];
                    let showCancelBtnOnly = type === AlertBoxButtonType.SHOWCANCELONLY;
                    if (!showCancelBtnOnly) {
                        return (
                            <Pressable
                                focusable={false}
                                style={buttonStyle}
                                onPress={() => {
                                    this.removeAlert(action);
                                }}
                                key={index}
                            >
                                <Text style={buttonTextStyle} numberOfLines={1} ellipsizeMode="tail">
                                    {text}
                                </Text>
                            </Pressable>
                        );
                    } else {
                        return null;
                    }
                })}
            </View>
        );
    }

    validateState(alertBoxInfo: AlertBoxType) {
        let validationStatus = true;

        let showCancelOnlyBtn = alertBoxInfo.actions?.filter(({ type }) => type === AlertBoxButtonType.SHOWCANCELONLY);
        let showBothBtn = alertBoxInfo?.actions?.filter(({ type }) => type === AlertBoxButtonType.SHOWBOTH);
        let isInvalid: boolean =
            showBothBtn.length > 1 ||
            showCancelOnlyBtn.length > 1 ||
            (showBothBtn.length >= 1 && showCancelOnlyBtn.length >= 1);

        validationStatus = !isInvalid;

        return validationStatus;
    }

    removeAlert(buttonAction?: () => void) {
        if (this.props.popups.pendingAlerts?.length) {
            if (buttonAction) {
                buttonAction();
            }
        }
    }

    render() {
        let alertContainer = null;
        if (this.props.popups.pendingAlerts != null && this.props.popups.pendingAlerts !== undefined) {
            if (this.props.popups.pendingAlerts.length) {
                let AlertInfo = this.props.popups.pendingAlerts;
                return (
                    <Modal animationType="none" transparent={true} visible={true}>
                        <View style={styles.popupView} focusable={false}>
                            <View
                                style={[
                                    styles.dialogContainer,
                                    {
                                        backgroundColor: themeConfigutation.getColor('#fafafa'),
                                        shadowColor: themeConfigutation.getColor('#000'),
                                    },
                                ]}
                            >
                                {this.renderTitleSection(AlertInfo)}
                                {this.renderMessage(AlertInfo)}
                                {this.renderButton(AlertInfo)}
                            </View>
                        </View>
                    </Modal>
                );
            }
        }
        return alertContainer;
    }
}

const styles = StyleSheet.create({
    popupView: {
        flex: 1,
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    dialogContainer: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        borderRadius: 4,
        padding: 8,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        width: '95%',
        maxWidth: 320,
    },
    titleSection: {
        width: '100%',
        flexDirection: 'row',
        paddingBottom: 4,
        justifyContent: 'space-around',
    },
    titleStyle: {
        fontSize: 18,
        flex: 1,
        paddingBottom: 4,
    },
    msgSection: {
        width: '100%',
        flexDirection: 'row',
        paddingBottom: 4,
        justifyContent: 'space-around',
    },
    bodyTextstyle: {
        fontSize: 14,
        flex: 1,
        paddingBottom: 4,
    },
    xBtnStyle: {
        marginLeft: 'auto',
    },
    btnSection: {
        flexWrap: 'wrap',
        flexDirection: 'row',
        justifyContent: 'space-around',
        width: '100%',
        paddingVertical: 8,
        paddingHorizontal: 8,
    },
    buttonStyle: {
        alignSelf: 'center',
        paddingHorizontal: 16,
        paddingVertical: 6,
        margin: 5,
        borderRadius: 2,
        borderWidth: 1,
    },
    buttonTextStyle: {
        fontSize: 14,
        textAlign: 'center',
    },
    msgIcon: {
        width: 30,
        height: 30,
        marginRight: 8,
    },
});

function mapStateToProps(state) {
    const { popups, utils } = state;
    return { popups, utils };
}

export default connect(mapStateToProps, null)(AlertBox);
