import {
    CONFIG_SET_MENU_VISIBILITY,
    CONFIG_SET_SETTING,
    CONFIG_SETTINGS_RETRIEVED,
    SET_SERVER_TIME_DIFFERENCE,
    CONFIG_SETTINGS_CHANGED,
    CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
} from '../configs/ActionIdentifiers';
import NetInfo from '@react-native-community/netinfo';
import isBoolean from 'lodash/isBoolean';

export const setServerTimeDifference = (serverTimeDifference) => ({
    type: SET_SERVER_TIME_DIFFERENCE,
    payload: serverTimeDifference,
});

export const configReduceerSetSetting = (obj) => ({
    type: CONFIG_SET_SETTING,
    payload: obj,
});

export const configSettingsRetrieved = (res) => ({
    type: CONFIG_SETTINGS_RETRIEVED,
    payload: res,
});

export const configMenuVisibiltyChanged = (res) => (dispatch, getState) =>
    dispatch({
        type: CONFIG_SET_MENU_VISIBILITY,
        payload: res,
        globalState: getState(),
    });

export const configReducerSettingsChanged = (res) => ({
    type: CONFIG_SETTINGS_CHANGED,
    payload: res,
});

export const connectivityReducerCheckAndSetConnectivity = (res) => async (
    dispatch
) => {
    let isConnected = undefined;
    if (isBoolean(res)) {
        isConnected = res;
    } else {
        let netInfoData = await NetInfo.fetch();
        isConnected = netInfoData.isConnected;
    }
    dispatch({
        type: CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
        payload: { isConnected },
    });
};
