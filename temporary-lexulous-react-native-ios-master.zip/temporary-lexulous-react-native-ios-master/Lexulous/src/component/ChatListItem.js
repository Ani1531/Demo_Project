import React from 'react';
import { View, StyleSheet, Text, Linking, TouchableOpacity } from 'react-native';
import RemoteImage from './RemoteImage';
import get from 'lodash/get';
import { spawnWindow } from '../utils/UrlUtils.web';
import AvatarImage from './AvatarImage';
import ColorConfig from '../configs/ColorConfig';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faUser, faCog } from '@fortawesome/free-solid-svg-icons';
import Config from '../configs/Config';
import { ADD_PVT_MESSAGE_KEY } from '../configs/ActionIdentifiers';
import isEqual from 'lodash/isEqual';
import TooltipWrapper from './TooltipWrapper';
import S10Text from './S10Text';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import { createDialogInstance } from '../utils/MessageUtils';
import ChatMessage from './ChatMessage';
const sanitizeUrl = require('@braintree/sanitize-url').sanitizeUrl;

const eventBus = require('js-event-bus')();

export default class ChatListItem extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showDateTime: false,
        };
    }

    componentDidUpdate = () => {
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState) => {
        return (
            !isEqual(get(this.props, 'item'), get(nextProps, 'item')) ||
            !isEqual(get(this.state, 'showDateTime'), get(nextState, 'showDateTime')) ||
            !isEqual(get(this.props, 'width'), get(nextProps, 'width')) ||
            !isEqual(get(this.props, 'chatFontSize'), get(nextProps, 'chatFontSize'))
        );
    };

    onMessageHoverIn = () => this.setState({ showDateTime: true });

    onMessageItemHoverOut = () => this.setState({ showDateTime: false });

    onChatImagePress = () => (this.props.imageBucketUrl ? spawnWindow(this.props.imageBucketUrl) : null);

    onUserNamePress = () => {
        if (this.props.isMyself) {
            return null;
        } else {
            let obj = {
                guid: get(this.props.item, 'message.sender'),
                username: this.props.messageUserName,
            };
            eventBus.emit(ADD_PVT_MESSAGE_KEY, null, obj);
        }
    };

    getAvatarStyle = () => ({
        height: 16,
        width: 16,
        marginRight: 8,
        marginTop: 4,
        alignItems: 'center',
        justifyContent: 'flex-start',
    });

    renderAvatar = () => {
        return this.props.isLobbyChat ? (
            this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_NORMAL ||
            this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_PRIVATE ? (
                <TouchableOpacity activeOpacity={1}>
                    <AvatarImage style={[this.getAvatarStyle()]} uri={this.props.avatarUrl} />
                </TouchableOpacity>
            ) : (
                <FontAwesomeIcon
                    key={'chtlst_avtar'}
                    color={
                        this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE
                            ? ColorConfig.LOBBY_CHAT_GAME_UPDATE_COLOR
                            : ColorConfig.LOBBY_CHAT_SYSTEM_COLOR
                    }
                    icon={this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE ? faUser : faCog}
                    style={[this.getAvatarStyle(), LayoutUtils.getCursorPointerStyle()]}
                />
            )
        ) : null;
    };

    renderUserName = () => {
        return this.props.isLobbyChat &&
            (this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_NORMAL ||
                this.props.item.type === Config.LOBBY_CHAT_MESSAGE_TYPE_PRIVATE) ? (
            <View style={styles.userNameContainer}>
                <TouchableOpacity onPress={this.onUserNamePress}>
                    <S10Text style={[styles.userNameColor]}>{this.props.messageUserName}</S10Text>
                </TouchableOpacity>
                <S10Text style={[styles.messageTime]}>
                    {this.state.showDateTime ? this.props.item.message.formattedTime : null}
                </S10Text>
            </View>
        ) : !this.props.isLobbyChat && this.props.isMultiplayerGame && this.state.showDateTime ? (
            <S10Text
                style={[
                    this.getUserNameFontColor(),
                    this.props.item.direction === 'outgoing' ? styles.chatOutgoingMsgTimeContainerStyle : null,
                ]}
            >
                {this.props.messageUserName}
            </S10Text>
        ) : null;
    };

    render = () => {
        return (
            <View
                key={'chatlist_item_container'}
                activeOpacity={1}
                style={[
                    this.props.isImage ? styles.imageMsgItem : this.getMsgItemPadding(),
                    this.props.item.direction === 'outgoing'
                        ? styles.chatOutgoingMsgItemFlexDirection
                        : styles.chatIncomingMsgItemFlexDirection,
                ]}
            >
                {this.props.isImage ? (
                    <TouchableOpacity
                        key={'chatlist_item_image'}
                        onPress={this.onChatImagePress}
                        style={[
                            this.props.getImageChatItemMaxWidth(),
                            this.props.item.direction === 'outgoing'
                                ? styles.chatOutgoingMsgItemFlexDirection
                                : styles.chatIncomingMsgItemFlexDirection,
                            this.props.item.direction === 'outgoing'
                                ? styles.chatOutgoingMsgAlignItems
                                : styles.chatIncomingMsgAlignItems,
                        ]}
                    >
                        <RemoteImage
                            key={'chatlist_item_remoteimage'}
                            imageId={get(this.props.item, 'message.msg').slice(2, -2)}
                            maxWidth={this.props.getImageChatItemMaxWidth().width}
                        />
                    </TouchableOpacity>
                ) : (
                    <View
                        key={'chtlst_avtar_name_msg_container'}
                        style={{ flexDirection: 'row' }}
                        onMouseOver={this.onMessageHoverIn}
                        onMouseOut={this.onMessageItemHoverOut}
                    >
                        {this.renderAvatar()}
                        <TooltipWrapper
                            key={'chtlst_name_msg_container'}
                            tooltip={this.props.isLobbyChat ? null : this.props.item.message.formattedTime}
                            style={[
                                {
                                    width: this.props.getChatItemMaxWidth().maxWidth,
                                },
                            ]}
                        >
                            {this.renderUserName()}
                            <TouchableOpacity
                                key={'chtlst_msg_container'}
                                disabled
                                style={[styles.chatMsgStyle, this.getChatBgStyle()]}
                            >
                                <S10Text style={[this.props.getChatItemMaxWidth(), this.getChatMsgFontStyle()]}>
                                    {this.getChatText(this.props.item.message.msg)}
                                </S10Text>
                            </TouchableOpacity>
                        </TooltipWrapper>
                    </View>
                )}
            </View>
        );
    };

    getChatText = (msgText) => {
        let mgsArray = msgText.split(Config.URL_REGEX);
        const regex = new RegExp(Config.URL_REGEX);
        let finalMsg = mgsArray.map((element) =>
            regex.test(element) ? (
                <Text onPress={() => this.getAlertWarning(element)}>{sanitizeUrl(element)}</Text>
            ) : (
                <ChatMessage key={'chatlist_chatmessage'} message={element} fallback={this.getLoadingText()} />
            )
        );
        return finalMsg;
    };

    getAlertWarning = (url) => {
        createDialogInstance({
            title: 'Warning!',
            actionButtonText: 'OK, Proceed',
            secondButtonText: 'Cancel',
            onAction: () => Linking.openURL(url),
            body: 'Please click on links shared by people you know.',
        });
    };

    getLoadingText = () => (
        <View style={styles.loadingTextContainer}>
            <S14Text style={styles.loadingText}>...</S14Text>
        </View>
    );

    getUserNameFontColor = () => ({
        color: this.props.item.direction === 'outgoing' ? '#FFFFFF' : this.props.isLobbyChat ? '#999999' : '#444444',
    });

    getChatBgStyle = () => ({
        alignSelf: this.props.item.direction === 'outgoing' ? 'flex-end' : 'flex-start',
        backgroundColor: this.props.item.direction === 'outgoing' ? '#1483FB' : this.props.isLobbyChat ? null : '#E4E6EB',
        padding: this.props.isLobbyChat ? null : 8,
    });

    getChatMsgFontStyle = () => ({
        width: '100%',
        color: this.props.item.direction === 'outgoing' ? '#FFFFFF' : this.props.isLobbyChat ? '#000' : '#444444',
        fontSize: this.props.isLobbyChat ? this.props.chatFontSize + 4 : this.props.chatFontSize,
    });

    getMsgItemPadding = () => ({
        padding: this.props.isLobbyChat ? 4 : 8,
    });
}

const styles = StyleSheet.create({
    imageMsgItem: {
        margin: 8,
    },
    chatMsgStyle: {
        alignItems: 'flex-start',
        justifyContent: 'center',
        borderRadius: 5,
        overflow: 'hidden',
    },
    chatOutgoingMsgTimeContainerStyle: {
        height: 15,
        marginBottom: 4,
        alignSelf: 'flex-end',
    },
    chatIncomingMsgTimeContainerStyle: {
        height: 15,
        marginBottom: 4,
        alignSelf: 'flex-start',
    },
    chatOutgoingMsgItemFlexDirection: {
        flexDirection: 'row-reverse',
        width: '100%',
    },
    chatIncomingMsgItemFlexDirection: {
        flexDirection: 'row',
        width: '100%',
    },
    chatOutgoingMsgAlignItems: {
        alignItems: 'flex-end',
    },
    chatIncomingMsgAlignItems: {
        alignItems: 'flex-start',
    },
    userNameContainer: { flexDirection: 'row', alignItems: 'center' },
    messageTime: { marginLeft: 8, color: '#999999' },
    userNameColor: { color: ColorConfig.ALERT_OTHER_BUTTON_TEXT_COLOR },
    loadingTextContainer: {
        height: 25,
        width: 60,
        alignItems: 'center',
        justifyContent: 'center',
    },
    loadingText: {
        opacity: 0.7,
        fontSize: 12,
    },
});
