import Config from '../configs/Config';
import to from 'await-to-js';
import { getCustomMessage } from '../utils/MessageUtils';
import PuzzleGamePlayService, { puzzlePingPolling, sendPuzzleMove } from './PuzzleGamePlayService';
import RestAPIProvider from '../provider/RestAPIProvider';
import WebSocketProvider from '../provider/WebSocketProvider';
import get from 'lodash/get';
import once from 'lodash/once';
import isFunction from 'lodash/isFunction';
import isObject from 'lodash/isObject';
import isNumber from 'lodash/isNumber';
import {
    getBuddyListOnce,
    livePingPolling,
    passMoveLiveGame,
    resignLiveGame,
    sendLiveGameMove,
    sendLiveSwapTilesRequest,
    sendSoloGameStartData,
} from './LiveGamePlayService';
import GameBoardUtils from '../utils/GameBoardUtils';
import { Base64 } from 'js-base64';
import SettingsUtil from '../utils/SettingsUtil';
import {
    emailPingPolling,
    passMoveEmailGame,
    readAllChatMessages,
    resignEmailGame,
    sendEmailMove,
    sendEmailSwapTilesRequest,
} from './EmailGamePlayService';
import { findAndRemove, checkNativeGamelistUpdateViaBoardInfo, getNativeWebGameType } from '../utils/Utils';
import WordValidityWebSocketProvider from '../provider/WordValidityWebSocketProvider';
import AnalyseWebSocketProvider from '../provider/AnalyseWebSocketProvider';
import {
    CHAT_APPEND_LIST_ITEM,
    CHAT_APPEND_LIST_ITEM_MORE_TIME,
    CONFIG_SETTINGS_RETRIEVED,
    GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN,
    GAME_LIVE_GAME_BUDDY_LIST,
    GAME_LIVE_GAME_DELETE_HOSTED_GAME,
    GAME_LIVE_GAME_HOST_PARAMS_SET,
    GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED,
    GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL,
    GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED,
    GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE,
    GAME_LIVE_GAME_SENSOR_LIST_RETRIEVED,
    GAME_LIVE_GAME_USER_STATS_FETCHED,
    GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT,
    GAME_MOVE,
    GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED,
    GAME_PUZZLE_PASS_SENT_SUCCESSFULLY,
    GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED,
    GAME_SOLO_NEW_GAME,
    GAME_STARTED,
    GAME_MOVE_MAX_SCORE_RETRIEVED,
    GAME_LIVE_REQ_JOIN_HOST_GAME,
    GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE,
    GAME_SOLO_SET_NO_LOGIN_DATA,
    GAME_LIVE_BUDDY_REQ_LIST_RETRIEVED,
} from '../configs/ActionIdentifiers';
import store from '../store';
import cloneDeep from 'lodash/cloneDeep';
import log from 'loglevel';
import orderBy from 'lodash/orderBy';
import sortedIndexBy from 'lodash/sortedIndexBy';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import { getTiles } from '../reducers/GameReducer';
import DimensionUtils from '../utils/DimensionUtils';
import ServiceWrapper from '../utils/ServiceWrapper';
import ServiceUtils from '../utils/ServiceUtils';

const eventBus = require('js-event-bus')();

export const getGameType = () =>
    DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
        ? getNativeWebGameType()
        : ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type');

export const isLiveGame = () => getGameType() === Config.GAME_TYPE_LIVE_GAME || isBlitzGame();
export const isPuzzleGame = () => getGameType() === Config.GAME_TYPE_PUZZLE;
export const isEmailGame = () => getGameType() === Config.GAME_TYPE_EMAIL;
export const isSoloGame = () => getGameType() === Config.GAME_TYPE_SOLO;
export const isBlitzGame = () => getGameType() === Config.GAME_TYPE_BLITZ;
export const isProUser = () => ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isProUser');

const getRequestUrlType = () => store.getState().game.request_url_type;

export const getCallType = (methodname) => {
    if (Config.ALWAYS_USE_REST_METHODS.includes(methodname)) return RestAPIProvider[methodname];

    if (methodname === 'useArchiveGameFeed') return RestAPIProvider.getGameFeed;

    if (isPuzzleGame() || isEmailGame()) {
        if (methodname === 'getWordValidity') {
            return WordValidityWebSocketProvider.isConnected()
                ? WordValidityWebSocketProvider.getWordValidity
                : RestAPIProvider.getWordValidity;
        } else if (methodname === 'ping') {
            return WordValidityWebSocketProvider.ping;
        }
    }

    switch (getRequestUrlType()) {
        case 'rest_api':
            return RestAPIProvider[methodname];
        case 'web_socket':
            return WebSocketProvider[methodname];
        default:
            throw new Error('Invalid request url type');
    }
};

export const gameInitialize = async () => {
    let initMethod;
    switch (getGameType()) {
        case Config.GAME_TYPE_LIVE_GAME:
        case Config.GAME_TYPE_BLITZ:
            initMethod = liveRoomInitialise;
            break;
        case Config.GAME_TYPE_PUZZLE:
            let already_attempted = store.getState().game.already_attempted;
            initMethod = already_attempted ? getArchivedPuzzle : puzzleInitialise;
            break;
        case Config.GAME_TYPE_EMAIL:
            initMethod = emailGameInitialise;
            break;
        case Config.GAME_TYPE_SOLO:
            initMethod = soloGameInitialise;
            break;
        default:
            throw new Error('Invalid game type');
    }
    log.info('in App, in gameInitialize, initMethod is: ' + !!initMethod);

    if (initMethod) {
        let res = await to(initMethod());
        if (res[0]) throw res[0];
        else return res[1];
    } else {
        throw Error('Invalid Game Type');
    }
};

export const liveRoomInitialise = async () => {
    eventBus.on(Config.EVENT_PING_POLLING, livePingPolling);
    log.info('in App, in gameInitialize, in liveRoomInitialise');
    eventBus.emit(Config.SHOW_START_GAME_OPTIONS);
};

export const soloGameInitialise = async () => {
    log.info('in GamePlayService, in soloGameInitialise');
    const state = store.getState();
    eventBus.on(Config.EVENT_PING_POLLING, livePingPolling);
    if (state.solitaire.soloNewGame) {
        switch (state.solitaire.soloNewGame) {
            case Config.SOLO_NO_LOGIN_NEW_GAME:
                WebSocketProvider.getWebSocketConnection(true);
                break;
            case Config.SOLO_REMATCH:
                log.info('in GamePlayService, in soloGameInitialise, in Config.SOLO_REMATCH case');
                let params = {
                    action: Config.ACTION_SOLO_QUICK_GAME_START,
                };
                sendSoloGameStartData(params);
                break;
        }
        eventBus.emit(GAME_SOLO_NEW_GAME, null, {
            soloNewGame: state.solitaire.soloNewGame,
        });
    } else {
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'GamePlayService.soloGameInitialise',
            visible: true,
            transparentLoader: true,
        });
    }
};

export const emailGameInitialise = async () => {
    const state = store.getState();
    let archiveGameView = false;
    if (!state.game.guid && !state.game.uuid) {
        archiveGameView = true;
        eventBus.emit(GAME_SOLO_SET_NO_LOGIN_DATA, null, {
            guid: Date.now() + '',
            uuid: Date.now() + '',
            archiveGameView,
        });
    }
    eventBus.on(Config.EVENT_PING_POLLING, emailPingPolling);
    if (!DimensionUtils.isNative() && !ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
        getBuddyListOnce();
        getBuddyRequestList();
        getSensorListOnce();
    }
    await getGameFeed({ archiveGameView });
};

export const puzzleInitialise = async () => {
    eventBus.on(Config.EVENT_PING_POLLING, puzzlePingPolling);
    eventBus.emit(Config.BOARD_LOAD_START);

    let requestMethod = getCallType('getPuzzleData');

    const state = store.getState();
    let params = {
        channel: state.game.channel,
        action: Config.GET_PUZZLE_DATA_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        boarddes: state.game.boarddes,
        ...(state.config.isProUser ? {} : { puzzleid: state.game.puzzle_id }),
        dic: state.game.dic,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.BOARD_LOAD_FAIL, null, extObj);
        throw res[0] || new Error(res[1].msg);
    } else {
        let puzzle_id = get(res[1], 'data.' + state.game.channel + '.puzzleid');
        let rating = get(res[1], 'data.' + state.game.channel + '.rating') || get(res[1], 'data.currentrating');

        //emitting puzzle response data
        eventBus.emit(GAME_STARTED, null, res[1]);
        eventBus.emit(Config.SHOW_BOARD_CONTAINER);
        eventBus.emit(Config.BOARD_PUZZLE_DATA_READY, null, res[1]);
    }
};

export const pingPolling = async () => {
    ping();
};

const createSendableMoveArray = (playedTilesCellsOrPlayedTiles) => {
    let moveArr = [];

    for (let i = 0; i < playedTilesCellsOrPlayedTiles.length; i++) {
        let playedTileOrCell = playedTilesCellsOrPlayedTiles[i];
        let currentTile = get(playedTileOrCell, 'currentTile') || playedTileOrCell;
        let letter = get(currentTile, 'letter') || get(currentTile, 'currentLetter').toLowerCase();
        let tileX = get(playedTileOrCell, 'tileX');
        let x = isNumber(tileX) ? tileX : get(playedTileOrCell, 'position.x');
        let tileY = get(playedTileOrCell, 'tileY');
        let y = isNumber(tileY) ? tileY : get(playedTileOrCell, 'position.y');

        let moveStr = y + ',' + x + ',' + letter;
        moveArr.push(moveStr);
    }
    return moveArr;
};

export const sendPlayMove = async (playedTilesCellsOrPlayedTiles) => {
    let sendMethod;
    switch (getGameType()) {
        case Config.GAME_TYPE_PUZZLE:
            sendMethod = sendPuzzleMove;
            break;
        case Config.GAME_TYPE_EMAIL:
            sendMethod = sendEmailMove;
            break;
        case Config.GAME_TYPE_LIVE_GAME:
        case Config.GAME_TYPE_BLITZ:
        case Config.GAME_TYPE_SOLO:
            sendMethod = sendLiveGameMove;
            break;
        default:
            throw new Error('Invalid game type');
    }
    let moveArr = createSendableMoveArray(playedTilesCellsOrPlayedTiles);
    if (sendMethod) return await sendMethod(moveArr);
    else throw new Error('Game Type Not Found!');
};

export const sendLiveGameRequest = async ({
    guid,
    dictionary = get(store.getState(), 'game.dic') || SettingsUtil.get('us_gamestart.gs_prefdic'),
    time: duration = get(store.getState(), 'game.duration'),
    increment: increament = get(store.getState(), 'game.increament'),
    gametype = store.getState().game.gametype,
    challengeregular = store.getState().game.gametypeMode || SettingsUtil.get('us_gamestart.gs_gametype') || 'LR',
} = {}) => {
    const state = store.getState();

    let requestMethod = getCallType('send');
    let params = {
        action: Config.START_NEW_GAME_ACTION,
        channel: state.game.channel,
        p1uid: state.game.guid,
        gametype: challengeregular,
        dic: String(dictionary),
        boardtype: 'N',
        guid: state.game.guid,
        uuid: state.game.uuid,
        p2uid: String(guid),
        livegame: {
            duration: String(duration),
            increament: String(increament),
            rated: gametype,
        },
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
    }
    return res[1];
};

export const getGameList = async () => {
    let hostedGameReq = await to(getHostedGameList());
    let hostedGamesList = hostedGameReq[1] || [];
    if (hostedGameReq[0]) {
        eventBus.emit(Config.GET_GAME_LIST_REQUEST_FAILED, null, hostedGameReq[0]);
    } else {
        eventBus.emit(Config.GET_GAME_LIST_REQUEST_COMPLETE, null, {
            hostedGamesList,
        });
    }
};

export const getSelfStats = async () => {
    const state = store.getState();
    let res = await to(getLiveGameStats([state.game.guid]));
    let user_stats = get(res, '1.data.0');
    eventBus.emit(GAME_LIVE_GAME_USER_STATS_FETCHED, null, user_stats);
};

export const getWordValidity = async ({ word, dic = store.getState().game.dic, doEmit, actionToEmit } = {}) => {
    let requestMethod = getCallType('getWordValidity');
    let params = {
        action: 'checkword',
        dic,
        words: word,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        if (actionToEmit) {
            eventBus.emit(actionToEmit, null, get(res[1], 'data'));
        }
        if (doEmit) {
            eventBus.emit(Config.GET_WORD_VALIDITY_REQUEST_SUCCESSFUL, null, get(res[1], 'data'));
        }
        return res[1];
    }
};

export const getLiveGameList = async (end) => {
    const state = store.getState();

    let requestMethod = getCallType('send');
    let params = {
        action: Config.GET_LIVE_GAME_LIST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        end && end();
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_LIVE_GAME_OBSERVABLE_GAMES_LIST_RETRIEVED, null, res[1]);
    }
    end && end();
    return get(res[1], 'data.games');
};

export const getHostedGameList = async (end) => {
    const state = store.getState();
    let requestMethod = getCallType('send');
    let params = {
        action: Config.GET_HOSTED_GAME_LIST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
        multi: 'y',
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        end && end();
        throw new Error(getCustomMessage(extObj));
    }

    end && end();
    eventBus.emit(GAME_LIVE_GAME_HOSTED_GAMES_LIST_RETRIEVED, null, res[1]);
    return get(res[1], 'data.hostedgames');
};

export const getOnlinePlayerList = async (end) => {
    const state = store.getState();
    let requestMethod = getCallType('send');
    let params = {
        action: Config.GET_ONLINE_PLAYER_LIST_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        end && end();
        throw new Error(getCustomMessage(extObj));
    } else {
        let resLocal = res[1];
        eventBus.emit(GAME_LIVE_GAME_ONLINE_PLAYER_LIST_AVAILABLE, null, resLocal);
        let playerListData = getPlayerListData(resLocal);
        // let playerListDataOn = state.game.playerListDataOn;
        // let playerListDataOrder = state.game.playerListDataOrder;
        //playerListData = sortList(playerListData, playerListDataOn, playerListDataOrder);
        eventBus.emit(Config.GET_ONLINE_PLAYER_LIST_REQUEST_SUCCESSFUL, null, res[1]);
    }
    end && end();
    return get(res[1], 'data');
};

export const addToSortedList = (playerListData, itemToAdd, on, order) => {
    if (on === 'name') {
        playerListData.splice(sortedIndexBy(playerListData, itemToAdd, 'sortingName'), 0, itemToAdd);
        playerListData = order === 'asc' ? playerListData : sortList(playerListData, on, order);
    } else {
        playerListData.splice(
            sortedIndexBy(playerListData, itemToAdd, (e) => {
                if (on === 'rating') {
                    return order === 'asc' ? e.sortingRating : -e.sortingRating;
                } else {
                    return order === 'asc' ? e.status.charCodeAt(0) : -e.status.charCodeAt(0);
                }
            }),
            0,
            itemToAdd
        );
    }
    return playerListData;
};

export const sortList = (playerListData, on, order) => {
    let value = on === 'name' ? 'sortingName' : on === 'rating' ? 'sortingRating' : 'status';
    return orderBy(playerListData, [value], [order]);
};

export const getPlayerListData = (res) => {
    let data = get(res, 'data');
    let keys = Object.keys(data || {});
    return keys.map((key) => {
        let player = get(data, key);
        player.guid = key;
        player.sortingName = player.name.toLowerCase();
        player.sortingRating = Number(player.rating);
        return player;
    });
};

export const ping = async (end) => {
    if (!WebSocketProvider.isConnected() && !WordValidityWebSocketProvider.isConnected()) {
        if (end) end();
        return;
    }

    let requestMethod = getCallType('ping');
    let params = {
        action: Config.PING_ACTION,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    to((await AnalyseWebSocketProvider.getConnection()).sendRequest(params));

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        end && end();
        throw new Error(getCustomMessage(extObj));
    }
    end && end();
    return get(res[1], 'data');
};

export const hostGame = async ({
    players,
    gametype,
    time,
    increment,
    dictionary,
    wordcheck,
    brag = '',
    fromrating,
    torating,
    challengeregular = 'LR',
}) => {
    const state = store.getState();
    let requestMethod = getCallType('send');
    let params = {
        action: Config.HOST_GAME_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
        adult: 'n',
        speed: 's',
        brag: brag,
        dic: dictionary,
        maxrequest: '1',
        fromrating: String(fromrating),
        torating: String(torating),
        numplys: String(players),
        livegame: {
            increament: String(increment),
            duration: String(time),
            rated: players > 2 ? 'n' : gametype,
        },
        gametype: challengeregular,
        boardtype: 'N',
        fftdays: '1',
    };

    eventBus.emit(GAME_LIVE_GAME_HOST_PARAMS_SET, null, params);
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.HOST_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        if (players > 2) {
            eventBus.emit(Config.SHOW_VIEW_STATS_MODAL_ON_MULTIPLAYER_SELF_HOST_GAME, null, params);
        }
    }
    return res[1];
};

export const acceptRejectGamePlayRequest = async (data, accept) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        channel: state.game.channel,
        action: Config.ACCEPT_MATCH_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        secret: data.secret,
        accept: accept ? 'y' : 'n',
        message: 'some text mmm qqq',
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || (res[1].extcode !== '1' && res[1].extcode !== '1207')) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.ACCEPT_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        WebSocketProvider.updateScoreGraph(res[1]);
        if (accept) eventBus.emit(Config.ACCEPT_GAME_REQUEST_SUCCESSFUL, null, res[1]);
    }

    return res[1];
};

export const cancelGamePlayRequest = async (data) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        channel: state.game.channel,
        action: Config.CANCEL_GAME_INVITATION_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        secret: data.secret,
        message: 'i will be back soon',
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || (res[1].extcode !== '1' && res[1].extcode !== '1000')) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const sendJoinGameRequest = async (hostedgame) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        reqgameid: hostedgame.gamereqid,
    };
    if (LiveGamePlayUtils.isHostGameRandom() || state.game.game_type === Config.GAME_TYPE_BLITZ) {
        params = {
            ...params,
            action: Config.JOIN_HOSTED_GAME_ACTION,
            channel: state.game.channel,
            guid: state.game.guid,
            uuid: state.game.uuid,
        };
    } else {
        params = {
            ...params,
            action: Config.REQ_JOIN_HOSTED_GAME_ACTION,
        };
    }
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || !['1', '1164', '1000'].includes(res[1].extcode)) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.JOIN_HOSTED_GAME_REQUEST_FAILED, null, {
            ...extObj,
            ...{ gameid: hostedgame.gamereqid },
        });
        throw new Error(getCustomMessage(extObj));
    } else {
        if (!LiveGamePlayUtils.isHostGameRandom() && state.game.game_type !== Config.GAME_TYPE_BLITZ)
            eventBus.emit(GAME_LIVE_REQ_JOIN_HOST_GAME, null, res[1]);
    }
    return res[1];
};

export const acceptRejectJoinHostRequest = async (data, accept) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        action: Config.REQ_JOIN_HOSTED_GAME_REPSPONSE_ACTION,
        secret: data.secret,
        accept: accept ? 'y' : 'n',
        message: 'some text mmm qqq',
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || !['1'].includes(res[1].extcode)) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.JOIN_HOSTED_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    }
    return res[1];
};

export const sendLeaveGameRequest = async (hostedgame) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        channel: state.game.channel,
        action: Config.LEAVE_HOSTED_GAME_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        reqgameid: hostedgame.gamereqid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || !['1'].includes(res[1].extcode)) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_LIVE_MULTIPLAYER_HOSTED_GAME_LEAVE, null, {
            data: {
                reqgameid: hostedgame.gamereqid,
                guid: state.game.guid,
            },
        });
    }
    return res[1];
};

export const getBuddyRequestList = async () => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: Config.BUDDY_REQUEST_LIST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.pendingRequestListUpdate(get(res[1], 'data'));
    }

    return res[1];
};

export const buddyRequestAction = async (accept, playerItem) => {
    const state = store.getState();

    let requestMethod = getCallType('friendApi');

    let params = {
        action: accept ? Config.BUDDY_REQUEST_ACCEPT_ACTION : Config.BUDDY_REQUEST_REJECT_ACTION,
        other: playerItem.guid,
        channel: state.game.channel,
        guid: state.game.guid,
        uuid: state.game.uuid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || !['1'].includes(res[1].extcode)) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        //eventBus.emit(Config.JOIN_HOSTED_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.pendingRequestActionUpdate(accept, playerItem);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            if (accept) {
                ServiceWrapper.acceptFriendRequest(playerItem);
            } else {
                ServiceWrapper.rejectFriendRequest(playerItem);
            }
        }
    }
    return res[1];
};

export const sendObserveGameRequest = async (item) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        channel: state.game.channel,
        action: Config.OBSERVE_GAME_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: item.gid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const sendUnobserveGame = async (gid) => {
    const state = store.getState();

    let requestMethod = getCallType('send');

    let params = {
        channel: state.game.channel,
        action: Config.UNOBSERVE_GAME_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: gid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.UNOBSERVE_GAME_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const sendSwapTilesRequest = async (tiles) => {
    let sendMethod;
    switch (getGameType()) {
        case Config.GAME_TYPE_EMAIL:
            sendMethod = sendEmailSwapTilesRequest;
            break;
        case Config.GAME_TYPE_LIVE_GAME:
        case Config.GAME_TYPE_BLITZ:
        case Config.GAME_TYPE_SOLO:
            sendMethod = sendLiveSwapTilesRequest;
            break;
        default:
            throw new Error('Invalid game type');
    }
    if (sendMethod) {
        let res = await to(sendMethod(tiles));
        eventBus.emit(GAME_MOVE, null, res[1]);
        return res[0];
    } else throw new Error('Game Type Not Found!');
};

export const passMove = async () => {
    let sendMethod;
    switch (getGameType()) {
        case Config.GAME_TYPE_EMAIL:
            sendMethod = passMoveEmailGame;
            break;
        case Config.GAME_TYPE_LIVE_GAME:
        case Config.GAME_TYPE_BLITZ:
        case Config.GAME_TYPE_SOLO:
            sendMethod = passMoveLiveGame;
            break;
        default:
            throw new Error('Invalid game type');
    }
    if (sendMethod) return await sendMethod();
    else throw new Error('Game Type Not Found!');
};

export const resignGame = async (doDelete = false) => {
    let sendMethod;
    switch (getGameType()) {
        case Config.GAME_TYPE_EMAIL:
            sendMethod = resignEmailGame;
            break;
        case Config.GAME_TYPE_LIVE_GAME:
        case Config.GAME_TYPE_BLITZ:
        case Config.GAME_TYPE_SOLO:
            sendMethod = resignLiveGame;
            break;
        default:
            throw new Error('Invalid game type');
    }
    if (sendMethod) return await sendMethod(doDelete);
    else throw new Error('Game Type Not Found!');
};

export const deleteHostedGame = async () => {
    const state = store.getState();
    let requestMethod = getCallType('send');
    let params = {
        channel: state.game.channel,
        action: Config.DELETE_HOSTED_GAME_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_LIVE_GAME_DELETE_HOSTED_GAME, null, res[1]);
        eventBus.emit(Config.DELETE_HOSTED_GAME_REQUEST_SUCCESSFUL, null, res[1]);
    }

    return res[1];
};

export const sendMessage = async (messageText) => {
    const state = store.getState();
    let requestMethod = getCallType('sendMessage');
    let params = {
        channel: state.game.channel,
        action: Config.GAME_CHAT_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
        msg: Base64.encode(messageText),
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const sendImage = async ({ file }) => {
    const state = store.getState();
    let requestMethod = RestAPIProvider.sendImage;
    let params = {
        channel: state.game.channel,
        action: Config.GAME_CHAT_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
    };

    let res = requestMethod ? await to(requestMethod(params, file)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const getUniqueWordsPlayedCount = async (guid) => {
    let requestMethod = getCallType('getUniqueWordsPlayedCount');

    let params = {
        action: 'getuqewdpldcnt',
        guid: guid,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_LIVE_HOST_ADD_UNIQUE_WORD_COUNT, null, get(res[1], 'data.' + guid));
    }

    return res[1];
};

export const getLiveGameStats = async (accounts) => {
    const state = store.getState();

    let requestMethod = getCallType([Config.GAME_TYPE_EMAIL].includes(getGameType()) ? 'getEmailGameStats' : 'send');
    let params = {
        channel: state.game.channel,
        action: Config.LIVE_GAME_STATS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        accounts,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    }

    return res[1];
};

export const getSensorList = async (accounts) => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: Config.LIVE_GAME_LIST_SENSOR_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        accounts,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        ServiceUtils.censorListUpdate(get(res[1], 'data'));
    }

    return res[1];
};

export const getSensorListOnce = once(getSensorList);

export const censorPlayer = async (player) => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: 'censor',
        guid: state.game.guid,
        uuid: state.game.uuid,
        other: player.guid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.LIVE_GAME_CENSOR_PLAYER_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.censorUncensorPlayerUpdate(true, player);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            ServiceWrapper.censorPlayer(player);
        }
    }

    return res[1];
};

export const uncensorPlayer = async (player) => {
    const state = store.getState();
    let requestMethod = getCallType('friendApi');
    let params = {
        channel: state.game.channel,
        action: 'uncensor',
        guid: state.game.guid,
        uuid: state.game.uuid,
        other: player.guid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.LIVE_GAME_UNCENSOR_PLAYER_REQUEST_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        LiveGamePlayUtils.censorUncensorPlayerUpdate(false, player);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            ServiceWrapper.uncensorPlayer(player);
        }
    }

    return res[1];
};

export const sendPuzzlePass = async (secret) => {
    const state = store.getState();
    let requestMethod = getCallType('sendPuzzlePass');

    let params = {
        channel: state.game.channel,
        action: Config.PUZZLE_PASS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        puzzleid: state.game.puzzle_id,
        dic: state.game.dic,
        secret,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_PUZZLE_PASS_SENT_SUCCESSFULLY, null, res[1]);
        eventBus.emit(Config.PUZZLE_PASS_SUCCESS, null, res[1]);
    }
};

export const getArchivedPuzzle = async (puzzleid = store.getState().game.puzzle_id) => {
    const state = store.getState();
    let requestMethod = getCallType('getArchivedPuzzle');

    let params = {
        channel: state.game.channel,
        action: Config.GET_ARCHIVED_PUZZLE_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        piggyback: '{"msg":"test"}',
        boarddes: 'n',
        puzzleid,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_STARTED, null, {
            ...res[1],
            isArchivedGame: true,
            forNext: false,
        });
        eventBus.emit(Config.SHOW_BOARD_CONTAINER);
        eventBus.emit(Config.GET_ARCHIVED_PUZZLE_SUCCESS, null, res[1]);
    }
};

export const getLastGamesStatusAndRanking = async () => await to(Promise.all([getLastGamesStatus(), getPuzzleRanking()]));

export const getPuzzleRanking = async () => {
    const state = store.getState();
    let requestMethod = getCallType('getPuzzleRanking');

    let params = {
        action: 'getpuzzleranking',
        channel: state.game.channel,
        guid: state.game.guid,
        uuid: state.game.uuid,
        limit: '1',
        skip: '0',
        dic: state.game.dic,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED, null, res[1]);
    }
};

export const getLastGamesStatus = async () => {
    const state = store.getState();
    let requestMethod = getCallType('getLastGamesStatus');

    let params = {
        channel: state.game.channel,
        action: 'archivepuzzlelist',
        guid: state.game.guid,
        uuid: state.game.uuid,
        page: '0',
        limit: state.game.game_status_limit,
        dic: state.game.dic,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED, null, res[1]);
    }
};

export const getUserProfile = async (guids) => {
    const state = store.getState();
    let requestMethod = getCallType('getUserProfile');

    let params = {
        channel: state.game.channel,
        action: 'getprofile',
        guid: state.game.guid,
        uuid: state.game.uuid,
        guids,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        return res[1];
    }
};

export const getHostGamesHeadToHeadStats = async (data) => {
    let oppGuid = LiveGamePlayUtils.getOpponentGuid(data);
    let param = undefined;
    if (oppGuid < get(store.getState(), 'game.guid')) {
        param = oppGuid + '-' + get(store.getState(), 'game.guid');
    } else {
        param = get(store.getState(), 'game.guid') + '-' + oppGuid;
    }
    let res = await getHeadToHeadStats(param);
    let retObj = await LiveGamePlayUtils.getHeadToHeadPercentage(res);
    return retObj;
};

export const getHeadToHeadStats = async (data) => {
    const state = store.getState();
    let requestMethod = getCallType(isEmailGame() ? 'getHeadToHeadStats' : 'send');
    let params = {
        action: Config.GET_HEAD_TO_HEAD_STATS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        uid: { uids: data, platform: 'glbl' },
        channel: state.game.channel,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || !['1', '1127'].includes(res[1].extcode)) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        return res[1];
    }
};

export const getSettings = async () => {
    if (!DimensionUtils.isNative() && isEmailGame()) {
        let emailSettingData = await ServiceWrapper.getDataFromCache(Config.CACHE_NAME, Config.CACHE_USER_SETTINGS);
        let expiryTime = Date.now() - (emailSettingData.updatetime || 0);
        if (expiryTime < 30 * 60 * 1000) {
            eventBus.emit(CONFIG_SETTINGS_RETRIEVED, null, emailSettingData.usersettings);
            eventBus.emit(Config.GET_SETTINGS_REQUEST_SUCCESSFUL, null, emailSettingData.usersettings);
            return;
        }
    }
    const state = store.getState();
    let requestMethod = getCallType('getSettings');
    let params = {
        action: Config.GET_SETTINGS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        let settings = get(res, '1.data.' + state.game.guid);
        //SettingsUtil.applySettings(settings);
        eventBus.emit(CONFIG_SETTINGS_RETRIEVED, null, settings);
        eventBus.emit(Config.GET_SETTINGS_REQUEST_SUCCESSFUL, null, settings);
        if (!DimensionUtils.isNative() && isEmailGame()) {
            ServiceWrapper.setDataIntoCache(Config.CACHE_NAME, Config.CACHE_USER_SETTINGS, {
                usersettings: settings,
                updatetime: Date.now(),
            });
        }
        return res[1];
    }
};

export const getSettingsOnce = once(getSettings);

export const setSettings = async (settings = {}) => {
    const state = store.getState();
    let requestMethod = getCallType('setSettings');
    let params = {
        action: Config.SET_SETTINGS_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
        settings,
    };
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        if (!DimensionUtils.isNative() && isEmailGame()) {
            let emailSettingData = await ServiceWrapper.getDataFromCache(Config.CACHE_NAME, Config.CACHE_USER_SETTINGS);
            let updateUserSetting = {
                ...emailSettingData,
                usersettings: {
                    ...emailSettingData.usersettings,
                    ...settings,
                },
            };
            ServiceWrapper.setDataIntoCache(Config.CACHE_NAME, Config.CACHE_USER_SETTINGS, updateUserSetting);
        }
        eventBus.emit(CONFIG_SETTINGS_RETRIEVED, null, settings);
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            ServiceWrapper.nativeUpdateUserSettings(settings);
        }
        return res[1];
    }
};

export const moreTime = async ({ other, time = 10 } = {}) => {
    let requestMethod = getCallType('send');

    let params = {
        action: 'moretime',
        other,
        time: String(time), //seconds
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(CHAT_APPEND_LIST_ITEM_MORE_TIME, null, res[1]);
        eventBus.emit(GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL, null, res[1]);

        return res[1];
    }
};

export const getNextGameUrl = async () => {
    const state = store.getState();
    let requestMethod = getCallType('nextGameUrl');
    let params = {
        action: Config.NEXT_GAME_REQUEST_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        channel: state.game.channel,
    };

    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        return res[1];
    }
};

export const getGameFeed = async (param) => {
    const state = store.getState();
    let end = isFunction(param) ? param : undefined;
    let data = isObject(param) ? param : undefined;
    let dontEmit = get(data, 'dontEmit') || false;
    let archiveGameView = !!get(param, 'archiveGameView');
    let useArchiveGameFeed = get(data, 'useArchiveGameFeed') || archiveGameView || false;

    !dontEmit &&
        eventBus.emit(Config.LOADER_OVERLAY, null, {
            caller: 'GamePlayService.getGameFeed',
            visible: true,
            transparentLoader: true,
            ...(DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')
                ? { boardSpinner: Config.BOARD_SPINNER }
                : null),
        });

    let requestMethod = getCallType(useArchiveGameFeed ? 'useArchiveGameFeed' : 'getGameFeed');
    let params = {
        action: archiveGameView
            ? Config.GET_ARCHIVED_GAME_VIEW_ACTION
            : useArchiveGameFeed
            ? Config.GET_ARCHIVED_GAME_ACTION
            : Config.GET_GAME_FEED_REQUEST_ACTION,
        channel: state.game.channel,
        gid: get(data, 'gid') || get(store.getState(), 'game.gid'),
        ...(!archiveGameView
            ? {
                  guid: state.game.guid,
                  uuid: state.game.uuid,
                  pid: get(store.getState(), 'game.pid'),
                  noboarddes: '1',
                  showgameover: '0',
              }
            : {}),
    };

    let res = requestMethod ? await to(requestMethod(params, useArchiveGameFeed)) : [Error('Invalid Request Type')];

    end && end();

    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_STARTED, null, res[1]);
        GameBoardUtils.setDatas(res[1]);
        //for appending chat message
        GameBoardUtils.clearMessages();
        let msgid = Date.now();
        let arr = (get(res[1], 'data.' + state.game.channel + '.chat') || []).map((message) => ({
            message,
            direction: message.sender === GameBoardUtils.getSelfPid(res[1]) ? 'outgoing' : 'incoming',
            id: msgid++,
        }));
        eventBus.emit(CHAT_APPEND_LIST_ITEM, null, arr);
        GameBoardUtils.setTilesInBag(res[1]);
        WebSocketProvider.updateScoreGraph(res[1]);
        GameBoardUtils.setPlayerCountInGame(res[1]);
        if (!dontEmit) {
            eventBus.emit(Config.SHOW_BOARD_CONTAINER);
            eventBus.emit(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, null, res[1]);
        }
        if (isEmailGame() && !DimensionUtils.isNative() && arr.length > 0) {
            let lastMsgInfo = arr[arr.length - 1].message;
            if (lastMsgInfo.sender !== GameBoardUtils.getSelfPid(res[1])) {
                readAllChatMessages();
            }
        }
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            checkNativeGamelistUpdateViaBoardInfo(res[1]);
        }
        return res[1];
    }
};

export const updateMoveDefinition = async ({ moveWord, lastMoveWordsArr = [] } = {}) => {
    if (moveWord && moveWord.length > 0) {
        let lastMoveWordPlayedData = moveWord;
        let lastMoveWords = [];
        //SWAP, CHALLENGE And PASS case
        if (moveWord === 'SWAP' || moveWord === 'PASS' || moveWord === 'CHALLENGE') {
            let obj = {};
            obj.wordPlayed = lastMoveWordPlayedData + ' move';
            obj.showDefinition = false;
            lastMoveWords.push(obj);
        } else {
            let lastMoveWordPlayedArr = lastMoveWordPlayedData.split(',');
            let unqueriedWords = [];

            lastMoveWordPlayedArr.forEach((lastMoveWord) => {
                let word = lastMoveWordsArr.find((lastWord) => lastWord.wordPlayed === lastMoveWord);
                if (word) {
                    lastMoveWords.push(word);
                } else {
                    unqueriedWords.push(lastMoveWord);
                }
            });

            if (unqueriedWords.length > 0) {
                let data = await to(getDictionaryData(unqueriedWords));
                unqueriedWords.forEach((word) => {
                    if (!lastMoveWords.some((wordObj) => wordObj.wordPlayed === word)) {
                        lastMoveWords.push({
                            wordPlayed: word,
                            showDefinition: true,
                            definition: get(data[1], word + '.0.description'),
                        });
                    }
                });
            }

            lastMoveWordsArr = lastMoveWordsArr.concat(lastMoveWords);
        }
        return { lastMoveWords, lastMoveWordsArr };
    }
};

export const getDictionaryData = async (data) => {
    const state = store.getState();
    let requestMethod = getCallType('getDictionaryData');
    let params = {
        word: data,
        mobile: 'y',
        meaning: 'y',
        dic: state.game.dic,
    };

    let res = await to(requestMethod(params));

    if (res[0]) {
        return res[0];
    } else {
        return res[1];
    }
};

export const sendChallengeMove = async () => {
    const state = store.getState();
    let requestMethod = getCallType('sendChallengeMove');
    eventBus.emit(GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN);
    let params = {
        channel: state.game.channel,
        action: Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION,
        guid: state.game.guid,
        uuid: state.game.uuid,
        gid: state.game.gid,
        pid: state.game.pid,
    };
    log.info('in GamePlayService, in sendChallengeMove, requestMethod is: ' + !!requestMethod);
    let res = requestMethod ? await to(requestMethod(params)) : [Error('Invalid Request Type')];
    if (res[0] || Number(res[1].extcode) !== 1) {
        let extObj = GameBoardUtils.getNotSuccessExitCodeInstance(res);
        eventBus.emit(Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_FAILED, null, extObj);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_MOVE, null, res[1]);
        eventBus.emit(Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_SUCCESSFUL, null, res[1]);
    }

    return res[1];
};

export const getPossibleMoves = async (gid) => await AnalyseWebSocketProvider.getPossibleMoves(gid);

export const getMoveStrengthData = async (globalState) => {
    let wordInfo = get(globalState, 'game.pid') + ',AA,2,r';
    let wordsplayed = [[wordInfo]];

    let rackTiles = '';
    let rackTilesArr = getTiles({ globalState });

    rackTilesArr.map((tile) => {
        if (!tile.isEmptySpace) {
            rackTiles += tile.isBlankTile ? '*' : tile.letter;
        }
    });

    let movetiles = get(globalState, 'game.msMoveTiles');

    let rackinfo = [rackTiles];

    let res = (await to(AnalyseWebSocketProvider.getMoveStrengthData(wordsplayed, movetiles, rackinfo)))[1];

    if (res) {
        let maxScore = Number(get(res, 'data.maxscr'));
        store.dispatch({
            type: GAME_MOVE_MAX_SCORE_RETRIEVED,
            payload: maxScore,
        });
    }
};
