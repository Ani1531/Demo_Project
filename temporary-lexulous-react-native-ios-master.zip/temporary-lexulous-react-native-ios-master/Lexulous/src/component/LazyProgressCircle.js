import { ProgressCircle } from 'react-native-svg-charts';
import React from 'react';

export default class LazyProgressCircle extends React.Component {
    render = () => <ProgressCircle {...this.props} />;
}
