// @flow

import dataServer from '../store/Store';
import * as CONSTANTS from './Constants';
import { kPsistLexAuthUser, kPsistLexAuthSecret, kPsistLexUid, kPsistLexEmail } from './Constants';
import userDefault from './UserDefault';
import LgnMgr from './LgnMgr';
import type { LXLSLoginInfo, LXLSLoginSuccessResponse, LNRResponse } from '../commons/RJTypes';
import { actionUpdateLXLSLgnInfo } from '../userprofile/PFLAction';
import lnrApi from '../loginNregister/LNRApi';
import { actionLNRUpdateLgnInfo } from '../loginNregister/LNRAction';
import { batch } from 'react-redux';
import netManager from './RJNetInfo';
import type { AxiosPromise, AxiosResponse } from 'axios';
import { handleException } from './RJUtils';

// end data types

class LXLSLgnMgr extends LgnMgr {
    type = 'LXLSLgnMgr';
    constructor() {
        super();
    }

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {
        let deletedaaplinfo = await this.deleteLoginData();
        let delpendingassoc = await this.deletePendingAssociation();
        dataServer.getStore().dispatch(actionUpdateLXLSLgnInfo(null));
        if (onCompletion) {
            onCompletion();
        }
        //LXLSLgnMgr.sharedInstance.store.dispatch(actionUpdateAppleLgnInfo(null));
    };

    promoteTempLoginInfo = async (): Promise<boolean> => {
        let promoted = false;
        let tempdata: LXLSLoginInfo = await this.getTempLoginData();
        let isempty = tempdata && Object.keys(tempdata).length === 0 && tempdata.constructor === Object;
        if (!isempty) {
            promoted = await this.storeLoginInfo(tempdata);
        }
        return promoted;
    };

    storeTempLoginInfo = async (tempdata: LXLSLoginInfo): Promise<boolean> => {
        let bulkdata: any = {};
        if (tempdata.authuser !== null && tempdata.authuser !== undefined) {
            let authuser = tempdata[CONSTANTS.kAuthUser];
            bulkdata[CONSTANTS.kPsistTempLexAuthUser] = authuser;
        }
        if (tempdata.authsecret !== null && tempdata.authsecret !== undefined) {
            let authsecret = tempdata[CONSTANTS.kAuthSecret];
            bulkdata[CONSTANTS.kPsistTempLexAuthSecret] = authsecret;
        }
        if (tempdata.uid !== null && tempdata.uid !== undefined) {
            let uid = tempdata[CONSTANTS.kUid];
            bulkdata[CONSTANTS.kPsistTempLexUid] = uid;
        }
        if (tempdata.email !== null && tempdata.email !== undefined) {
            let email = tempdata[CONSTANTS.kParamEmail];
            bulkdata[CONSTANTS.kPsistTempLexEmail] = email;
        }

        await userDefault.setMultiple(bulkdata);
        return true;
    };

    storeLoginInfo = async (data: LXLSLoginInfo): Promise<boolean> => {
        let bulkdata: any = {};

        if (data.authuser !== null && data.authuser !== undefined) {
            let authuser = data[CONSTANTS.kAuthUser];
            bulkdata[kPsistLexAuthUser] = authuser;
        }
        if (data.authsecret !== null && data.authsecret !== undefined) {
            let authsecret = data[CONSTANTS.kAuthSecret];
            bulkdata[kPsistLexAuthSecret] = authsecret;
        }
        if (data.uid !== null && data.uid !== undefined) {
            let uid = data[CONSTANTS.kUid];
            bulkdata[kPsistLexUid] = uid;
        }
        if (data.email !== null && data.email !== undefined) {
            let email = data[CONSTANTS.kParamEmail];
            bulkdata[kPsistLexEmail] = email;
        }
        await userDefault.setMultiple(bulkdata);
        return true;
    };

    deleteTempLoginData = async (): Promise<boolean> => {
        let delkeys = [
            CONSTANTS.kPsistTempLexAuthUser,
            CONSTANTS.kPsistTempLexAuthSecret,
            CONSTANTS.kPsistTempLexUid,
            CONSTANTS.kPsistTempLexEmail,
        ];
        await userDefault.clearMultiple(delkeys);
        return true;
    };

    deleteLoginData = async (): Promise<boolean> => {
        let delkeys = [kPsistLexAuthUser, kPsistLexAuthSecret, kPsistLexUid, kPsistLexEmail];
        await userDefault.clearMultiple(delkeys);
        return true;
    };

    getTempLoginData = async (): Promise<LXLSLoginInfo> => {
        let reqdata: any = [
            CONSTANTS.kPsistTempLexAuthUser,
            CONSTANTS.kPsistTempLexAuthSecret,
            CONSTANTS.kPsistTempLexUid,
            CONSTANTS.kPsistTempLexEmail,
        ];
        let mapping = {
            [CONSTANTS.kPsistTempLexAuthUser]: [CONSTANTS.kAuthUser],
            [CONSTANTS.kPsistTempLexAuthSecret]: [CONSTANTS.kAuthSecret],
            [CONSTANTS.kPsistTempLexUid]: [CONSTANTS.kUid],
            [CONSTANTS.kPsistTempLexEmail]: [CONSTANTS.kParamEmail],
        };
        const result = await userDefault.getMultiple(reqdata);
        let data = {};
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    data[mapping[reqdata[index]]] = JSON.parse(JSON.stringify(value));
                }
            });
        }
        return data;
    };

    getLoginData = async (): Promise<LXLSLoginInfo> => {
        let reqdata: any = [kPsistLexAuthUser, kPsistLexAuthSecret, kPsistLexUid, kPsistLexEmail];
        let mapping = {
            [kPsistLexAuthUser]: [CONSTANTS.kAuthUser],
            [kPsistLexAuthSecret]: [CONSTANTS.kAuthSecret],
            [kPsistLexUid]: [CONSTANTS.kUid],
            [kPsistLexEmail]: [CONSTANTS.kParamEmail],
        };
        const result = await userDefault.getMultiple(reqdata);
        let data = {};
        if (result != null) {
            result.forEach((value, index) => {
                if (value !== null && value !== undefined) {
                    data[mapping[reqdata[index]]] = JSON.parse(JSON.stringify(value));
                }
            });
        }
        return data;
    };

    checkLoginSilentMode = () => {
        let p1 = this.getLoginData();
        p1.then((lgninfo) => {
            if (lgninfo != null && lgninfo != undefined) {
                if (
                    lgninfo.authuser !== null &&
                    lgninfo.authuser !== undefined &&
                    lgninfo.authsecret !== null &&
                    lgninfo.authsecret !== undefined &&
                    lgninfo.email !== null &&
                    lgninfo.email !== undefined
                ) {
                    let authuser = lgninfo.authuser;
                    let authsecret = lgninfo.authsecret;
                    if (netManager.isConnected()) {
                        let rsp: AxiosPromise<LNRResponse> = lnrApi.doLogin(authuser, authsecret);
                        rsp.then((response: AxiosResponse<LNRResponse, any>) => {
                            if (response.status == CONSTANTS.HTTPSuccessStatus) {
                                return response.data;
                            } else {
                                throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                            }
                        })
                            .then((qq: LNRResponse) => {
                                if ((qq?.check ?? CONSTANTS.kFailure).toUpperCase() === CONSTANTS.kSuccess.toUpperCase()) {
                                    let tmpsrvresp: LXLSLoginSuccessResponse = ((qq: any): LXLSLoginSuccessResponse);
                                    let lgndata = {
                                        authuser: authuser,
                                        authsecret: authsecret,
                                        uid: tmpsrvresp.uid,
                                        email: tmpsrvresp.email,
                                    };
                                    batch(() => {
                                        dataServer.getStore().dispatch(actionLNRUpdateLgnInfo(lgndata));
                                        dataServer.getStore().dispatch(actionUpdateLXLSLgnInfo(lgndata));
                                    });
                                }
                            })
                            .catch((error) => handleException(error));
                    }
                }
            }
        }).catch((err) => handleException(err));
    };
}
const lxlsLgnMgr: LXLSLgnMgr = new LXLSLgnMgr();
export default lxlsLgnMgr;
