// @flow

import React from 'react';
import { connect } from 'react-redux';
import type { NavigationProp } from '@react-navigation/native';
import { StyleSheet, Text, View, SectionList, Pressable, Platform } from 'react-native';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import AGLTblVwElement from './AGLTblVwElement';
import i18n from 'i18n-js';
import * as CONSTANTS from '../commons/Constants';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import aglApi from './AGLApi';
import netManager from '../commons/RJNetInfo';
import type {
    GamesListItemData,
    ProfileInfo,
    ServerResponse,
    GamesListResponse,
    GamesListGameData,
    AppUtilsTypes,
} from '../commons/RJTypes';
import dataServer from '../store/Store';
import * as ProfileSelector from '../userprofile/PFLSelector';
import { actionAddArchiveGames, aglRefreshStarted, aglClearData } from './AGLAction';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import { setEmailData } from '../../../../actions/GameActions';
import bannerAd from '../commons/ads/BannerAd';
import interstitialAd from '../commons/ads/InterstitialAd';
import { handleException } from '../commons/RJUtils';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import appConfiguration from '../commons/AppConfiguration';
import { SafeAreaView } from 'react-native-safe-area-context';

type AGLContainerStatetype = {
    showBottomLoadingUI: boolean,
    isFocused: boolean,
    bannerHt: number,
};

type AGLContainerPropsType = {
    navigation: NavigationProp,
    utils: AppUtilsTypes,
    archivegames: Array<{
        title: string,
        data: Array<GamesListItemData>,
    }>,
    playersinfo: { [string]: ProfileInfo },
    skip: number,
    timestamp: number,
};

class AGLContainer extends React.Component<AGLContainerPropsType, AGLContainerStatetype> {
    skip: number;
    currentTstmp: number;
    mostRecentFetchFailed: boolean = false;
    timer: IntervalID | null = null;
    fetchedAll: boolean = false;
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    sectionListWindowSize: number = CONSTANTS.SectionListWindowSize.For_Native;

    constructor(props: AGLContainerPropsType) {
        super(props);
        this.state = {
            showBottomLoadingUI: false,
            isFocused: false,
            bannerHt: 0,
        };
    }
    componentDidMount = () => {
        this.props.navigation.setOptions({
            headerLeft: () => this.getBackButton(),
        });
        this.skip = this.props.skip;
        this.currentTstmp = Date.now();
        this.fetchedAll = false;

        if (this.shouldReload()) {
            dataServer.getStore().dispatch(aglClearData());
            if (netManager.isConnected()) {
                this.getArchiveGameList();
            } else {
                this.timer = setInterval(this.onTimerTick, CONSTANTS.aglRecallDurationMilisec);
            }
        }
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                bannerAd.showBannerAd(0, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ isFocused: false });
            }
        });
        let updateSectionListWndwSize = Platform.select({
            native: () => null,
            default: () => {
                let source: string | null = appConfiguration.getApplicationSource();
                if (source != null) {
                    if (source == CONSTANTS.kDeskTopApp || source == CONSTANTS.kFBInstantApp) {
                        this.sectionListWindowSize = CONSTANTS.SectionListWindowSize.For_Web;
                    }
                }
            },
        });
        updateSectionListWndwSize();
    };

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        clearInterval(this.timer);
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    onTimerTick = () => {
        if (netManager.isConnected()) {
            this.getArchiveGameList();
            clearInterval(this.timer);
        }
    };

    shouldReload = () => {
        let isTstmpInvalid: boolean = this.props.timestamp === 0;
        if (isTstmpInvalid) {
            return isTstmpInvalid;
        }
        let elapsedTime = new Date(this.currentTstmp - this.props.timestamp).getSeconds();
        let cacheDurationExpired = elapsedTime >= CONSTANTS.aglCacheDurationSec;
        return cacheDurationExpired;
    };

    getBackButton = () => {
        return (
            <Pressable
                style={{ paddingHorizontal: 12 }}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('agl_container_closed', 'agl_container');
                    interstitialAd.showInterstitialAd(true, () => {
                        this.props.navigation.goBack();
                    });
                }}
            >
                <FontAwesomeIcon icon={faChevronLeft} size={25} color={'white'} />
            </Pressable>
        );
    };

    getArchiveGameList = () => {
        if (netManager.isConnected()) {
            let rsp: AxiosPromise<ServerResponse> = aglApi.fetchArchiveGamesList(this.skip, this.currentTstmp);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((res: ServerResponse) => {
                    if (res.check === CONSTANTS.kSuccess) {
                        this.mostRecentFetchFailed = false;
                        this.setState({ showBottomLoadingUI: false });
                        let resData: GamesListResponse = ((res.data: any): GamesListResponse);
                        if (resData.games.length < 1) {
                            this.fetchedAll = true;
                        } else {
                            dataServer.getStore().dispatch(actionAddArchiveGames(resData, this.currentTstmp, this.skip));
                        }
                    } else {
                        this.mostRecentFetchFailed = true;
                        this.setState({ showBottomLoadingUI: false });
                    }
                })
                .catch((error) => {
                    handleException(error);
                    this.mostRecentFetchFailed = true;
                    this.setState({ showBottomLoadingUI: false });
                });
        } else {
            this.mostRecentFetchFailed = true;
            this.setState({ showBottomLoadingUI: false });
        }
    };

    onRefresh = () => {
        this.skip = 0;
        this.currentTstmp = Date.now();
        this.setState({ showBottomLoadingUI: false });
        this.mostRecentFetchFailed = false;
        this.fetchedAll = false;
        dataServer.getStore().dispatch(aglRefreshStarted());
        this.getArchiveGameList();
    };

    onReachedEnd = () => {
        let reentry: boolean = this.state.showBottomLoadingUI;
        if (!this.fetchedAll && !reentry) {
            if (netManager.isConnected()) {
                if (this.mostRecentFetchFailed) {
                    this.mostRecentFetchFailed = false;
                    this.skip = this.props.skip;
                }
            }
            if (!this.mostRecentFetchFailed) {
                this.setState({ showBottomLoadingUI: true });
                this.skip = this.skip + CONSTANTS.aglSkip;
                let updateTstmp: boolean = this.props.timestamp != 0;
                if (updateTstmp) {
                    this.currentTstmp = this.props.timestamp;
                }
                this.getArchiveGameList();
            }
        }
    };

    handleTap = (game: GamesListItemData, onCompletion: () => void | null): void => {
        let type = game.type;
        if (type === 'game') {
            let gamedata: GamesListGameData = ((game.data: any): GamesListGameData);
            let boardType: string = gamedata.boardtype;
            let gid: string = gamedata.gid;
            let guid: string = CONSTANTS.Default_guid;
            let uuid: string = '';
            let dict: string = gamedata.dic;
            let profile: ProfileInfo = ProfileSelector.getProfile(dataServer.getStore().getState());
            if (profile.guid !== undefined && profile.guid !== null) {
                guid = profile.guid;
            }
            if (profile.uuid !== undefined && profile.uuid !== null) {
                uuid = profile.uuid;
            }
            let me = gamedata.players.find((element) => element.uid === guid);
            let mypid = '1';
            if (me !== undefined && me !== null) {
                mypid = me.pid;
            }
            const gameBoardData: gameBoardDataExchng = {
                gid: gid,
                pid: mypid,
                dic: dict, //sow, fr, it
                boarddes: 'n',
                already_attempted: false,
                game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                board_type: boardType == CONSTANTS.Super ? CONSTANTS.server_S : CONSTANTS.server_N,
                //request_url_type: 'rest_api', //"rest_api",//"web_socket",
                //channel: CONSTANTS.kChannel,
                guid: guid,
                uuid: uuid,
                board_size: boardType == CONSTANTS.Super ? CONSTANTS.Board_sz_s : CONSTANTS.Board_sz_n,
            };
            gameBoardDataExchanger.gameBoardData = gameBoardData;
            dataServer.getStore().dispatch(setEmailData(gameBoardData));
            if (onCompletion != null && onCompletion != undefined) {
                onCompletion();
            }
            rjAnalytics.sendAnalyticsEvent('board_screen_opened', 'agl_container');
            this.props.navigation.navigate('BoardScreen');
        }
    };

    onImagePress = (guid: string) => {
        rjAnalytics.sendAnalyticsEvent('profile_stats_opened', 'agl_container');
        this.props.navigation.navigate('StatsProfile', { lnk: { url: CONSTANTS.statShareLink + guid } });
    };

    renderItem = ({ item }) => {
        return <AGLTblVwElement game={item} imageTapHandler={this.onImagePress} gameTapHandler={this.handleTap} />;
    };

    renderHeaderItem = ({ section: { title } }) => {
        let titleName = i18n.t(title, {
            number: this.props.archivegames[0].data.length,
        });
        return (
            <Text
                style={[
                    styles.header,
                    { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#000') },
                ]}
            >
                {titleName}
            </Text>
        );
    };

    extractKey = (item) => item.key;

    renderSelectionList = () => {
        return this.props.archivegames.length ? (
            <>
                <SectionList
                    sections={(this.props.archivegames: any)}
                    renderItem={this.renderItem}
                    keyExtractor={this.extractKey}
                    renderSectionHeader={this.renderHeaderItem}
                    ItemSeparatorComponent={separator}
                    ListFooterComponent={separator}
                    onRefresh={() => this.onRefresh()}
                    refreshing={false}
                    stickySectionHeadersEnabled
                    onEndReachedThreshold={0.5}
                    onEndReached={() => this.onReachedEnd()}
                    windowSize={this.sectionListWindowSize}
                    style={[styles.listStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                />
                {this.renderFooterComponent()}
                {this.renderAdViewPlaceHolder()}
            </>
        ) : (
            this.renderMsg()
        );
    };

    renderAdViewPlaceHolder = () => {
        return <View style={{ backgroundColor: themeConfigutation.getColor('#f4f3ef'), height: this.state.bannerHt }} />;
    };

    render() {
        return this.state.isFocused ? (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    {this.renderSelectionList()}
                </View>
            </SafeAreaView>
        ) : null;
    }

    renderMsg = () => {
        let getMsg = (): string => {
            if (this.mostRecentFetchFailed) {
                return translate('waiting_for_internet');
            } else {
                return translate('no_Games_Msg');
            }
        };
        return (
            <View style={styles.mgsStyle}>
                <Text style={{ color: themeConfigutation.getColor('#000') }}>{getMsg()}</Text>
            </View>
        );
    };

    renderFooterComponent = () => {
        if (this.state.showBottomLoadingUI) {
            return (
                <Text
                    style={[
                        styles.header,
                        styles.loadingStyle,
                        { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#000') },
                    ]}
                >
                    {translate('loading')}
                </Text>
            );
        } else {
            return null;
        }
    };
}

const separator = () => {
    return <View style={styles.separatorStyle} />;
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'flex-start',
    },
    header: {
        fontSize: 12,
        paddingLeft: 8,
        paddingTop: 4,
        paddingBottom: 4,
    },
    mgsStyle: {
        flex: 1,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    separatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
    loadingStyle: { textAlign: 'center', paddingBottom: 8 },
    listStyle: {
        ...Platform.select({
            native: { flexGrow: 1 },
            default: {
                height: 100,
            },
        }),
    },
});

function mapStateToProps(state) {
    const { archiveGamesList, utils } = state;
    return { ...archiveGamesList, utils };
}

export default connect(mapStateToProps, null)(AGLContainer);
