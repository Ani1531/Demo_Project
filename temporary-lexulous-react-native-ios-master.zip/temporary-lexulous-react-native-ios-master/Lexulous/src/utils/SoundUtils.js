import get from 'lodash/get';
import store from '../store';
import HowlObject from './HowlObject';

const playSingleSound = (soundName, extraData) => {
    if (
        !HowlObject.isPlaying() &&
        (get(extraData, 'playForSure') === true ||
            (!extraData && isSoundsEnabled()))
    ) {
        HowlObject.playSound(soundName);
    }
};

export const isSoundsEnabled = (globalState = store.getState()) =>
    !!get(globalState, 'config.sounds_enabled');

export default class SoundUtils {
    static playShuffleSound = (extraData) =>
        playSingleSound('shuffle', extraData);

    static playDropTileSound = (extraData) =>
        playSingleSound('droptilesound', extraData);

    static playClickTileSound = (extraData) =>
        playSingleSound('clicktile', extraData);

    static bingoSound = (extraData) => playSingleSound('bingo', extraData);

    static recallAllSound = (extraData) => playSingleSound('recall', extraData);

    static gameStartSound = (extraData) =>
        playSingleSound('gamestartendsound', extraData);

    static messageSound = (extraData) => playSingleSound('message', extraData);

    static errorSound = (extraData) => playSingleSound('error', extraData);

    static oppSubmits = (extraData) =>
        playSingleSound('opp_submits', extraData);

    static userSubmits = (extraData) =>
        playSingleSound('user_submits', extraData);

    static invalidWord = (extraData) =>
        playSingleSound('invalid_word', extraData);

    static userWinsGame = (extraData) =>
        playSingleSound('user_wins_game', extraData);
}
