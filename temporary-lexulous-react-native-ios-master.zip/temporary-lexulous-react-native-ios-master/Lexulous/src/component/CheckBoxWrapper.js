import React from 'react';
import CheckBox from '@react-native-community/checkbox';

export default class CheckBoxWrapper extends React.Component {
    render = () => (
        <CheckBox
            value={this.props.value}
            onValueChange={this.props.onValueChange}
        />
    );
}
