import React from 'react';
import Config from '../configs/Config';

export default class SelectOption extends React.Component {
    renderOptions = () => {
        if (this.props.type === Config.SELECT_OPTION_TYPES.players)
            return (
                <>
                    <option value={2}>{'2'}</option>
                    <option value={3}>{'3'}</option>
                    <option value={4}>{'4'}</option>
                </>
            );
        else if (this.props.type === Config.SELECT_OPTION_TYPES.dictionary) {
            return (
                <>
                    <option value="twl">{'US English'}</option>
                    <option value="sow">{'UK English'}</option>
                    <option value="it">{'Italian'}</option>
                    <option value="fr">{'French'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.gameType) {
            return (
                <>
                    <option value="LR">{'Regular'}</option>
                    <option value="LC">{'Challenge'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.rated) {
            return (
                <>
                    <option value="y">{'Yes'}</option>
                    <option value="n">{'No'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.time) {
            return (
                <>
                    <option value={60}>{'1 minute'}</option>
                    <option value={120}>{'2 minute'}</option>
                    <option value={180}>{'3 minute'}</option>
                    <option value={240}>{'4 minute'}</option>
                    <option value={300}>{'5 minute'}</option>
                    <option value={420}>{'7 minute'}</option>
                    <option value={600}>{'10 minute'}</option>
                    <option value={900}>{'15 minute'}</option>
                    <option value={1200}>{'20 minute'}</option>
                    <option value={1800}>{'30 minute'}</option>
                    <option value={3600}>{'60 minute'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.increments) {
            return (
                <>
                    <option value="0">{'None'}</option>
                    <option value="1">{'1 second'}</option>
                    <option value="5">{'5 second'}</option>
                    <option value="10">{'10 second'}</option>
                    <option value="15">{'15 second'}</option>
                    <option value="30">{'30 second'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.robotLevel) {
            return (
                <>
                    <option value={1}>{'1 (Easiest)'}</option>
                    <option value={2}>{'2'}</option>
                    <option value={3}>{'3'}</option>
                    <option value={4}>{'4'}</option>
                    <option value={5}>{'5'}</option>
                    <option value={6}>{'6'}</option>
                    <option value={7}>{'7'}</option>
                    <option value={8}>{'8'}</option>
                    <option value={9}>{'9'}</option>
                    <option value={10}>{'10 (Toughest)'}</option>
                </>
            );
        } else if (this.props.type === Config.SELECT_OPTION_TYPES.timeRobot) {
            return (
                <>
                    <option value={0}>{'Untimed'}</option>
                    <option value={1}>{'1 minute'}</option>
                    <option value={2}>{'2 minute'}</option>
                    <option value={3}>{'3 minute'}</option>
                    <option value={4}>{'4 minute'}</option>
                    <option value={5}>{'5 minute'}</option>
                    <option value={7}>{'7 minute'}</option>
                    <option value={10}>{'10 minute'}</option>
                    <option value={15}>{'15 minute'}</option>
                    <option value={20}>{'20 minute'}</option>
                    <option value={30}>{'30 minute'}</option>
                    <option value={60}>{'60 minute'}</option>
                </>
            );
        }
    };
    render = () => (
        <select
            style={this.props.style}
            value={this.props.selectedValue}
            onChange={(event) => this.props.onSelectChange(event.target.value)}
        >
            {this.renderOptions()}
        </select>
    );
}
