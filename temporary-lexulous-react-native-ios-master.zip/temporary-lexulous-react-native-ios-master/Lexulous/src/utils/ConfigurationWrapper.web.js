export default class ConfigurationWrapper {
    static getLexulousGameConfigTooltipMargin = () =>
        window.__lexulous_game_configuration_tooltipMargin;

    static getSpecificLexulousGameConfiguration = (field) =>
        window.__lexulous_game_configuration__[field];

    static getSpecificLexulousGeneralConfiguration = (field) =>
        window.__lexulous_general_configuration__[field];

    static getLexulousGameConfiguration = () =>
        window.__lexulous_game_configuration__;

    static getLexulousGeneralConfiguration = () =>
        window.__lexulous_general_configuration__;
}
