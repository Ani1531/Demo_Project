// @flow

import * as React from 'react';
import { connect, batch } from 'react-redux';
import { bindActionCreators } from 'redux';
import { StyleSheet, Text, View, Image, Pressable, Platform } from 'react-native';
import * as CONSTANTS from '../commons/Constants';
import * as MinStatsSelector from '../stats/minimalstats/MinStatsSelector';
import dataServer from '../store/Store';
import type {
    UserStats,
    ServerResponse,
    ErrorResponse,
    ProfileInfo,
    FndItemData,
    ActionMkFriend,
    ActionCancelSentFndReq,
    ActionCensorReq,
    ActionRmAddedFriendReq,
    ActionUncensorReq,
    WinLossStatsBarType,
    AlertBoxType,
    PopupData,
    AppUtilsTypes,
} from '../commons/RJTypes';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import fndApi from './FndApi';
import {
    actionGLBLMkFriendEvent,
    actionGLBLRmFriendReqEvent,
    actionGLBLCancelSentFriendRequest,
    actionGLBLCensorEvent,
    actionGLBLRmAddedFriendReqEvent,
    actionGLBLUncensorEvent,
} from '../friends/FndAction';
import netManager from '../commons/RJNetInfo';
import { faTrashAlt, faCheck, faGamepadAlt } from '@fortawesome/pro-light-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import WinLossStatsBarContainer from '../stats/statsprofile/WinLossStatsBarContainer';
import i18n from 'i18n-js';
import { updatePopupVisibility, clearAlert, showAlert } from '../reducers/popupreducer/PopupAction';
import interstitialAd from '../commons/ads/InterstitialAd';
import { handleException, showMessage } from '../commons/RJUtils';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';
import LiveGamePlayUtils from '../../../../utils/LiveGamePlayUtils';

class FndElementView extends React.Component<{
    element: FndItemData,
    utils: AppUtilsTypes,
    actionGLBLMkFriendEvent: (ProfileInfo) => ActionMkFriend,
    actionGLBLRmFriendReqEvent: (ProfileInfo) => ActionMkFriend,
    actionGLBLCancelSentFriendRequest: (ProfileInfo) => ActionCancelSentFndReq,
    actionGLBLCensorEvent: (ProfileInfo) => ActionCensorReq,
    actionGLBLRmAddedFriendReqEvent: (ProfileInfo) => ActionRmAddedFriendReq,
    actionGLBLUncensorEvent: (ProfileInfo) => ActionUncensorReq,
    imageHandler: (string) => void,
    openpopup: (ProfileInfo) => void,
    updatePopupVisibility: (PopupData) => void,
    showAlert: (AlertBoxType) => void,
    clearAlert: () => void,
}> {
    doMakeFriend = (data: ProfileInfo): void => {
        if (data.guid !== null && data.guid !== undefined) {
            let otherguid: string = data.guid;
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = fndApi.mkFriend(otherguid);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        if (jresp.check === CONSTANTS.kSuccess) {
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.props.actionGLBLMkFriendEvent(data);
                                LiveGamePlayUtils.pendingRequestActionUpdate(true, data);
                            });
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(err.msg, 'fnd_element_view');
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    doRmFriendReq = (data: ProfileInfo): void => {
        if (data.guid !== null && data.guid !== undefined) {
            let otherguid: string = data.guid;
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = fndApi.rmFriendRequest(otherguid);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        if (jresp.check === CONSTANTS.kSuccess) {
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.props.actionGLBLRmFriendReqEvent(data);
                                LiveGamePlayUtils.pendingRequestActionUpdate(false, data);
                            });
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(err.msg, 'fnd_element_view');
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    doRmAddedFriendReq = (data: ProfileInfo): void => {
        if (data.guid !== null && data.guid !== undefined) {
            let otherguid: string = data.guid;
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = fndApi.rmAddedFriendRequest(otherguid);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        if (jresp.check === CONSTANTS.kSuccess) {
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.props.actionGLBLRmAddedFriendReqEvent(data);
                                LiveGamePlayUtils.addRemoveBuddyUpdate(false, data);
                            });
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(err.msg, 'fnd_element_view');
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    doCancelRequest = (data: ProfileInfo): void => {
        if (data.guid !== null && data.guid !== undefined) {
            let otherguid: string = data.guid;
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = fndApi.cancelFriendRequest(otherguid);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        if (jresp.check === CONSTANTS.kSuccess) {
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.props.actionGLBLCancelSentFriendRequest(data);
                                LiveGamePlayUtils.addRemoveBuddyUpdate(false, data);
                            });
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(err.msg, 'fnd_element_view');
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    doUncensorReq = (data: ProfileInfo): void => {
        if (data.guid !== null && data.guid !== undefined) {
            let otherguid: string = data.guid;
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let p1: AxiosPromise<ServerResponse> = fndApi.uncensorRequest(otherguid);
                p1.then((response: AxiosResponse<ServerResponse, any>) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((jresp: ServerResponse) => {
                        if (jresp.check === CONSTANTS.kSuccess) {
                            batch(() => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.props.actionGLBLUncensorEvent(data);
                                LiveGamePlayUtils.censorUncensorPlayerUpdate(false, data);
                            });
                        } else {
                            let err: ErrorResponse = (jresp: ErrorResponse);
                            dataServer.debouncedDispatch(actionSetIdle());
                            showMessage(err.msg, 'fnd_element_view');
                        }
                    })
                    .catch((error) => {
                        dataServer.debouncedDispatch(actionSetIdle());
                        handleException(error);
                    });
            }
        }
    };

    render() {
        let type = this.props.element.type;
        if (type === 'fnd' || type === 'reqsent' || type === 'pending' || type === 'censored') {
            let data: ProfileInfo = ((this.props.element.data: any): ProfileInfo);
            let stats: ?UserStats = null;
            if (data.guid !== null && data.guid !== undefined) {
                stats = MinStatsSelector.getMinStats(data.guid, dataServer.getStore().getState());
            }
            return this.renderFriendData(type, data, stats);
        } else {
            return null;
        }
    }

    getValidActions = (type: string, data: ProfileInfo) => {
        if (type === 'fnd') {
            return this.getValidFndActions(data);
        } else if (type === 'pending') {
            return this.getValidPendingActions(data);
        } else if (type === 'reqsent') {
            return this.getValidFndReqSentActions(data);
        } else if (type === 'censored') {
            return this.getValidCensorActions(data);
        } else {
            return null;
        }
    };

    getValidCensorActions = (data: ProfileInfo) => {
        return (
            <Pressable
                style={[styles.btnStyle, styles.deleteBtn]}
                onPress={() => {
                    this.doConfirmUncensor(data);
                }}
            >
                <FontAwesomeIcon icon={faTrashAlt} size={18} color={themeConfigutation.getColor('#000')} />
            </Pressable>
        );
    };

    doConfirmRejectFriendRequest = (data: ProfileInfo) => {
        rjAnalytics.sendAnalyticsEvent('rmfndreq_alert_opened', 'fnd_element_view');
        let msg: string = i18n.t('rmfndreqcfm', {
            user: data.name,
        });
        let alertBoxInfo: AlertBoxType = {
            message: msg,
            actions: [
                {
                    text: translate('cancel'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('rmfndreq_alert_cancel_closed', 'fnd_element_view');
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBOTH,
                },
                {
                    text: translate('ok'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('rmfndreq_alert_ok_closed', 'fnd_element_view');
                        this.props.clearAlert();
                        this.doRejectFriendRequest(data);
                        rjAnalytics.sendAnalyticsEvent('friend_request_removed', 'fnd_element_view');
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    };

    doConfirmUncensor = (data: ProfileInfo) => {
        rjAnalytics.sendAnalyticsEvent('uncensorcfm_for_alert_opened', 'fnd_element_view');
        let msg: string = i18n.t('uncensorcfm', {
            user: data.name,
        });
        let alertBoxInfo: AlertBoxType = {
            message: msg,
            actions: [
                {
                    text: translate('cancel'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('uncensorcfm_alert_cancel_press_closed', 'fnd_element_view');
                        this.props.clearAlert();
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.NEGATIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBOTH,
                },
                {
                    text: translate('ok'),
                    action: () => {
                        rjAnalytics.sendAnalyticsEvent('uncensorcfm_alert_ok_press_closed', 'fnd_element_view');
                        this.props.clearAlert();
                        this.doSendUncensorRequest(data);
                    },
                    color: CONSTANTS.COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: CONSTANTS.AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        this.props.showAlert(alertBoxInfo);
    };

    openMatchFriendContainer = (data: ProfileInfo) => {
        this.props.openpopup(data);
    };

    getValidFndActions = (data: ProfileInfo) => {
        return (
            <Pressable
                style={[styles.btnStyle, styles.rejectbtn]}
                // onPress={() => {
                //     this.doRmAddedFriendRequest(data);
                // }}
                onPress={() => {
                    this.openMatchFriendContainer(data);
                }}
            >
                <FontAwesomeIcon icon={faGamepadAlt} size={22} color={themeConfigutation.getColor('#000')} />
            </Pressable>
        );
    };

    getValidFndReqSentActions = (data: ProfileInfo) => {
        return (
            <Pressable
                style={[styles.btnStyle, styles.rejectbtn]}
                onPress={() => {
                    rjAnalytics.sendAnalyticsEvent('friend_request_canceled', 'fnd_element_view');
                    this.doCancelSentFriendRequest(data);
                }}
            >
                <FontAwesomeIcon icon={faTrashAlt} size={22} color={themeConfigutation.getColor('#000')} />
            </Pressable>
        );
    };

    getValidPendingActions = (data: ProfileInfo) => {
        return (
            <View style={styles.btnStyle}>
                <Pressable
                    style={styles.acceptbtn}
                    onPress={() => {
                        this.doAcceptFriendRequest(data);
                        rjAnalytics.sendAnalyticsEvent('friend_request_accepted', 'fnd_element_view');
                    }}
                >
                    <FontAwesomeIcon icon={faCheck} size={22} color={themeConfigutation.getColor('#000')} />
                </Pressable>

                <Pressable
                    style={styles.rejectbtn}
                    onPress={() => {
                        this.doConfirmRejectFriendRequest(data);
                    }}
                >
                    <FontAwesomeIcon icon={faTrashAlt} size={18} color={themeConfigutation.getColor('#000')} />
                </Pressable>
            </View>
        );
    };

    doAcceptFriendRequest = (data: ProfileInfo) => {
        this.doMakeFriend(data);
    };

    doRejectFriendRequest = (data: ProfileInfo) => {
        this.doRmFriendReq(data);
    };

    doCancelSentFriendRequest = (data: ProfileInfo) => {
        this.doCancelRequest(data);
    };

    doRmAddedFriendRequest = (data: ProfileInfo) => {
        this.doRmAddedFriendReq(data);
    };

    doSendUncensorRequest = (data: ProfileInfo) => {
        this.doUncensorReq(data);
    };

    renderFriendData(type: string, data: ProfileInfo, stats: ?UserStats) {
        let statdata: WinLossStatsBarType = {};
        let rating = '1500';
        let name = ''; //used
        if (data !== null && data.name !== undefined && data.name !== null) {
            name = data.name;
        }
        let avtar = '1';
        if (data !== null && data.avtar !== null && data.avtar !== undefined) {
            avtar = data.avtar;
        }

        let timg: number | {| uri: string |} = data.picurl ? { uri: data.picurl } : CONSTANTS.avtarIcons[avtar];

        if (stats !== null && stats !== undefined) {
            if (
                stats.rating_stats !== null &&
                stats.rating_stats !== undefined &&
                stats.rating_stats.rating !== null &&
                stats.rating_stats.rating !== undefined
            ) {
                rating = stats.rating_stats.rating;
            }

            let played = 0;
            if (
                stats.game_stats !== null &&
                stats.game_stats !== undefined &&
                stats.game_stats.played !== null &&
                stats.game_stats.played !== undefined
            ) {
                played = stats.game_stats.played;
            }

            let won = 0;
            if (
                stats.game_stats !== null &&
                stats.game_stats !== undefined &&
                stats.game_stats.won !== null &&
                stats.game_stats.won !== undefined
            ) {
                won = stats.game_stats.won;
            }

            let lost = 0;
            if (
                stats.game_stats !== null &&
                stats.game_stats !== undefined &&
                stats.game_stats.lost !== null &&
                stats.game_stats.lost !== undefined
            ) {
                lost = stats.game_stats.lost;
            }
            let drawn = 0;
            if (
                stats.game_stats !== null &&
                stats.game_stats !== undefined &&
                stats.game_stats.drawn !== null &&
                stats.game_stats.drawn !== undefined
            ) {
                drawn = stats.game_stats.drawn;
            }
            let bingos = 0;
            if (stats?.game_stats?.bingo_count !== null && stats?.game_stats?.bingo_count !== undefined) {
                bingos = stats.game_stats.bingo_count;
            }
            statdata = {
                won: Number(won),
                lost: Number(lost),
                drawn: Number(drawn),
                games: Number(played),
                bingos: Number(bingos),
            };
        }

        let action = this.getValidActions(type, data);
        return (
            <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                <Pressable
                    style={{ alignSelf: 'center' }}
                    onPress={() => {
                        interstitialAd.showInterstitialAd(true, () => {
                            if (data.guid !== null && data.guid !== undefined) {
                                this.props.imageHandler(data.guid);
                            }
                        });
                    }}
                >
                    <Image
                        source={timg}
                        style={[styles.imgStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}
                    />
                </Pressable>
                <View style={[styles.contentStyle, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <Text numberOfLines={0} style={[styles.nameStyle, { color: themeConfigutation.getColor('#000') }]}>
                        {name}
                        <Text> </Text>
                        <Text style={{ fontSize: 16 }}>({rating})</Text>
                    </Text>
                    {/* <View style={{ width: '100%' }}> */}
                    <WinLossStatsBarContainer statdata={statdata} isForHostedGame={false} />
                    {/* </View> */}
                </View>
                {action}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingLeft: 8,
        paddingVertical: 4,
        flexDirection: 'row',
        ...Platform.select({
            native: {},
            default: {
                width: '100%',
            },
        }),
    },
    btnStyle: {
        flexShrink: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignSelf: 'center',
        marginRight: 12,
    },
    acceptbtn: {
        paddingHorizontal: 4,
        paddingBottom: 6,
    },
    rejectbtn: {
        paddingHorizontal: 4,
        paddingBottom: 6,
    },
    deleteBtn: {
        paddingTop: 8,
        paddingBottom: 8,
        paddingLeft: 8,
        paddingRight: 8,
    },
    imgStyle: {
        width: 30,
        height: 30,
        marginRight: 8,
    },
    contentStyle: {
        ...Platform.select({
            native: { flex: 4 },
            default: { flexGrow: 1 },
        }),
        justifyContent: 'center',
    },
    nameStyle: {
        marginBottom: 1,
        fontSize: 18,
        paddingLeft: 8,
    },
});
function mapStateToProps(state) {
    const { utils } = state;
    return { utils };
}

const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            actionGLBLMkFriendEvent,
            actionGLBLRmFriendReqEvent,
            actionGLBLCancelSentFriendRequest,
            actionGLBLCensorEvent,
            actionGLBLRmAddedFriendReqEvent,
            actionGLBLUncensorEvent,
            updatePopupVisibility,
            showAlert,
            clearAlert,
        },
        dispatch
    );
export default connect(mapStateToProps, mapDispatchToProps)(FndElementView);
