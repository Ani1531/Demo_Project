// @flow

import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import type {
    GameFactoryContainerProps,
    ServerResponse,
    HostedGameElement,
    HostedGameActionType,
    HostedGameResponse,
} from '../commons/RJTypes';
import { StyleSheet, Text, View, SectionList, Pressable, Platform } from 'react-native';
import ProfileShareContainer from '../components/ProfileShareContainer';
import ProfileBarContainer from '../components/ProfileBarContainer';
import { updatePopupVisibility, clearPopups } from '../reducers/popupreducer/PopupAction';
import GamesListElement from '../gameslist/GLTblVwElement';
import { translate } from '../commons/translations/LangTransator';
import userDefault from '../commons/UserDefault';
import * as CONSTANTS from '../commons/Constants';
import ShowTutorialContainer from '../components/ShowTutorialContainer';
import bannerAd from '../commons/ads/BannerAd';
import interstitialAd from '../commons/ads/InterstitialAd';
import rjAnalytics from '../../../../RJAnalytics';
import dataServer from '../store/Store';
import appConfiguration from '../commons/AppConfiguration';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import { gameLiveMultiplayerHostGameLeave, joinHostedGame, setEmailData } from '../../../../actions/GameActions';
import * as PFLSelector from '../userprofile/PFLSelector';
import themeConfigutation from '../commons/ThemeConfiguration';
import netManager from '../commons/RJNetInfo';
import type { AxiosPromise, AxiosResponse } from 'axios';
import hostedGamesApi from './hostedgames/HostedGamesApi';
import HostedGamesContainer from './hostedgames/HostedGamesContainer';
import ViewStatsModal from '../../../../modal/ViewStatsModal';
import Config from '../../../../configs/Config';
import get from 'lodash/get';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import LiveGamePlayUtils from '../../../../utils/LiveGamePlayUtils';
import * as MinStatsSelector from '../stats/minimalstats/MinStatsSelector';
import { handleException, showMessage } from '../commons/RJUtils';

type GameFactoryContainerState = {
    isFocused: boolean,
    bannerHt: number,
    DATA: Array<{
        title: string,
        type: string,
        data: Array<{
            type: string,
            key: string,
            data: {},
        }>,
    }>,
    hostGameId: string,
};

class GameFactoryContainer extends React.Component<GameFactoryContainerProps, GameFactoryContainerState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    disableActionBtn: boolean = false;
    view_stats_modal: any = null;

    constructor(props: GameFactoryContainerProps) {
        super(props);
        this.state = {
            isFocused: false,
            bannerHt: 0,
            DATA: [
                {
                    title: 'new_game',
                    type: 'extension',
                    data: [
                        {
                            type: 'extension',
                            key: 'playlive',
                            data: {},
                        },
                        {
                            type: 'extension',
                            key: 'playoffline',
                            data: {},
                        },
                        {
                            type: 'extension',
                            key: 'other_lex_player',
                            data: {},
                        },
                        {
                            type: 'extension',
                            key: 'analizegames',
                            data: {},
                        },
                    ],
                },
            ],
            hostGameId: '',
        };
        this.view_stats_modal = React.createRef();
    }

    componentDidMount() {
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                hostedGamesApi.getHostedGamesList();
                bannerAd.showBannerAd(CONSTANTS.kTabBarHeight, this.onBannerReceive, this.onBannerFail);
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                bannerAd.hideBannerAd();
                this.setState({ isFocused: false });
            }
        });
        setTimeout(() => {
            userDefault.get(CONSTANTS.kPsistAppNwUser).then((value) => {
                if (value == 'true') {
                    this.props.updatePopupVisibility({ showTutorialPopup: true });
                }
            });
        }, 1000);
    }

    onHostedGameItemSelected = (item): void => {
        let guid = get(item, 'uid.guid');
        this.setState({ hostGameId: item.gamereqid });
        if (guid !== PFLSelector.getGUID(dataServer.getStore().getState()) || Number(get(item, 'numplys')) > 2) {
            LiveGamePlayUtils.onShowViewStatsModal(item);
            this.view_stats_modal.current.show(item);
        }
    };

    onBannerReceive = (): void => {
        this.setState({ bannerHt: bannerAd.adHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
    }

    updateBlindGameOptions = () => {
        let doUpdate = Platform.select({
            native: () => {},
            default: () => {
                let source: string | null = appConfiguration.getApplicationSource();
                if (source != null && source == CONSTANTS.kFBInstantApp) {
                    let hasgames = dataServer.hasActiveGames();
                    let hasNoFriends: boolean = this.props.friends.friends.length < 1;
                    let isAlreadyAdded =
                        this.state.DATA[0].data.filter((item) => {
                            return item.key == 'blindGame';
                        }).length > 0;
                    let add: boolean = !hasgames && hasNoFriends;
                    if (add) {
                        if (!isAlreadyAdded) {
                            this.state.DATA[0].data.unshift({
                                type: 'extension',
                                key: 'blindGame',
                                data: {},
                            });
                            this.setState({ DATA: this.state.DATA.slice(0) });
                        }
                    } else {
                        if (isAlreadyAdded) {
                            this.state.DATA[0].data.shift();
                            this.setState({ DATA: this.state.DATA.slice(0) });
                        }
                    }
                }
                if (source != null && source == CONSTANTS.kDeskTopApp) {
                    this.disableActionBtn = true;
                }
            },
        });
        doUpdate();
    };

    openProfileShareContainer = () => {
        this.props.updatePopupVisibility({ showSharePopup: true });
    };

    closeProfileShareContainer = () => {
        rjAnalytics.sendAnalyticsEvent('profile_share_container_closed', 'game_factory_container');
        this.props.clearPopups();
    };
    onShowTutorial = () => {
        rjAnalytics.sendAnalyticsEvent('tutorial_opened', 'game_factory_container');
        this.props.navigation.navigate('Tutorial');
    };

    onRowClicked = (item) => {
        if (item.key === 'analizegames') {
            rjAnalytics.sendAnalyticsEvent('agl_container_opened', 'game_factory_container');
            this.props.navigation.navigate('AGLContainer');
        }
        if (item.key === 'blindGame') {
            rjAnalytics.sendAnalyticsEvent('random_game', 'game_factory_container');
            this.getBlindGame();
        }
        if (item.key == 'other_lex_player') {
            rjAnalytics.sendAnalyticsEvent('host_game_container_Opened', 'game_factory_container');
            this.props.updatePopupVisibility({ showHostGamePopup: true });
        }
    };

    getBlindGame = () => {
        let randomGameData: string | null = appConfiguration.getBlindGamePlugin();
        if (randomGameData != null) {
            let onCompletion = (error: Error | null, value: string | null): void => {
                if (error != null) {
                    console.log('blind game error :: ' + JSON.stringify(error));
                } else if (value != null) {
                    this.showBlindGame(value);
                }
            };
            window[randomGameData](onCompletion);
        } else {
            console.log('startRandomGame empty');
        }
    };

    showBlindGame = (res: any) => {
        if (res !== null && res !== undefined) {
            let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
            if (sguid !== null && sguid !== undefined) {
                let pid = 1;
                let me = res.players.find((element) => element.guid === sguid);
                pid = me.pid;
                const data: gameBoardDataExchng = {
                    gid: res.gid,
                    pid: pid,
                    dic: res.dic, //sow, fr, it
                    boarddes: 'n',
                    already_attempted: false,
                    game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                    board_type: res.board_type == CONSTANTS.Super ? CONSTANTS.server_S : CONSTANTS.server_N,
                    request_url_type: 'rest_api', //"rest_api",//"web_socket",
                    channel: CONSTANTS.kChannel,
                    guid: sguid,
                    uuid: PFLSelector.getUUID(dataServer.getStore().getState()) ?? '',
                    board_size: res.board_type == CONSTANTS.Super ? CONSTANTS.Board_sz_s : CONSTANTS.Board_sz_n,
                    isBlindGame: true,
                };
                gameBoardDataExchanger.gameBoardData = data;
                dataServer.getStore().dispatch(setEmailData(data));
                this.props.navigation.navigate('BoardScreen');
                this.updateBlindGameOptions();
            }
        }
    };

    renderProfileShareContainer = () => {
        if (this.props.popups.showSharePopup) {
            return <ProfileShareContainer closePopupHandler={this.closeProfileShareContainer} />;
        } else {
            return null;
        }
    };
    renderTutorialContainer = () => {
        if (this.props.popups.showTutorialPopup) {
            return (
                <ShowTutorialContainer closePopupHandler={this.props.clearPopups} showTutorialHandler={this.onShowTutorial} />
            );
        } else {
            return null;
        }
    };

    renderItem = ({ item }) => {
        return (
            <Pressable
                onPress={() => {
                    interstitialAd.showInterstitialAd(true, () => {
                        this.onRowClicked(item);
                    });
                }}
            >
                <GamesListElement game={item} />
            </Pressable>
        );
    };

    renderHeaderItem = ({ section: { title } }) => (
        <Text
            style={[
                styles.header,
                { backgroundColor: themeConfigutation.getColor('#e5e7e9'), color: themeConfigutation.getColor('#000') },
            ]}
        >
            {translate(title)}
        </Text>
    );

    extractKey = (item) => item.key;

    renderSelectionList = () => {
        return (
            <SectionList
                sections={(this.state.DATA: any)}
                renderItem={this.renderItem}
                keyExtractor={this.extractKey}
                renderSectionHeader={this.renderHeaderItem}
                ItemSeparatorComponent={separator}
                style={[styles.width100, { backgroundColor: themeConfigutation.getColor('#f4f3ef'), flexGrow: 0 }]}
            />
        );
    };

    renderHostedGames = () => {
        return <HostedGamesContainer navigation={this.props.navigation} hostGameAction={this.onHostedGameItemSelected} />;
    };

    renderAdViewPlaceHolder = () => {
        return <View style={[{ height: this.state.bannerHt }]} />;
    };

    renderJoinGameDialog = () => {
        return (
            <ViewStatsModal
                ref={this.view_stats_modal}
                id={'view_stats_modal'}
                key={'view_stats_modal'}
                overlayStyle={this.getModalOverlayStyle()}
                myStats={MinStatsSelector.getMinStats(
                    PFLSelector.getGUID(dataServer.getStore().getState()) || '',
                    dataServer.getStore().getState()
                )}
                myName={PFLSelector.getName(dataServer.getStore().getState())}
                myAvtar={PFLSelector.getAvtar(dataServer.getStore().getState())}
                emailHostGameJoin={this.onHostGameJoin}
            />
        );
    };

    onHostGameJoin = (type: string, data: any): void => {
        console.log('---onHostGameJoin button click: ', type, data);
        switch (type) {
            case 'hostjoin':
                this.hostedGamesAction('joinhostedgame');
                break;
            case 'multijoin':
                dataServer.getStore().dispatch(joinHostedGame(data));
                this.hostedGamesAction('joinhostedgame');
                break;
            case 'multileave':
                dataServer.getStore().dispatch(gameLiveMultiplayerHostGameLeave(data));
                this.hostedGamesAction('leavehostedgame');
                break;
        }
    };

    hostedGamesAction = (action: HostedGameActionType) => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        if (netManager.isConnected() && sguid != null && sguid != undefined) {
            dataServer.getStore().dispatch(actionSetBusy());
            let rsp: AxiosPromise<ServerResponse> = hostedGamesApi.hostedGamesAction(this.state.hostGameId, action);
            rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((res: ServerResponse) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    if (res.check === CONSTANTS.kSuccess) {
                        let hostedGameResponse = (res.data: any);
                        if (typeof hostedGameResponse == 'number') {
                            hostedGameResponse = ((res.data: any): number);
                            if (hostedGameResponse == 2 || hostedGameResponse == 3) {
                                // for join multi  game
                                hostedGamesApi.getHostedGamesList();
                            }
                            if (hostedGameResponse == 1) {
                                // for leave  multi game
                                hostedGamesApi.getHostedGamesList();
                            }
                        } else {
                            //To the board
                            hostedGameResponse = ((res.data: any): HostedGameResponse);
                            let pid = '1';
                            let gameData = hostedGameResponse[CONSTANTS.kChannel];
                            let me = gameData.players.find((element) => element.guid === sguid);
                            if (me != null && me != undefined) {
                                pid = me.pid;
                                const data: gameBoardDataExchng = {
                                    gid: gameData.gid,
                                    pid: pid,
                                    dic: gameData.dic, //sow, fr, it
                                    boarddes: 'n',
                                    already_attempted: false,
                                    game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                                    board_type: gameData.boardtype == CONSTANTS.Super ? CONSTANTS.server_S : CONSTANTS.server_N,
                                    request_url_type: 'rest_api', //"rest_api",//"web_socket",
                                    channel: CONSTANTS.kChannel,
                                    guid: sguid,
                                    uuid: PFLSelector.getUUID(dataServer.getStore().getState()) ?? '',
                                    board_size:
                                        gameData.boardtype == CONSTANTS.Super ? CONSTANTS.Board_sz_s : CONSTANTS.Board_sz_n,
                                };
                                gameBoardDataExchanger.gameBoardData = data;
                                dataServer.getStore().dispatch(setEmailData(data));
                                this.props.navigation.navigate('BoardScreen');
                            }
                        }
                    } else {
                        if (res.check === CONSTANTS.kFailure) showMessage(res.msg, 'game_factory');
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    console.log('Error while Joining hosted games...', error);
                });
        }
    };

    getModalOverlayStyle = () => ({
        //backgroundColor: 'rgba(55, 55, 55, 0.6)',
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        borderRadius: Config.COMMON_BORDER_RADIUS,
        justifyContent: 'center',
    });

    render() {
        if (this.state.isFocused) {
            this.updateBlindGameOptions();
            return (
                <View style={[styles.container, { backgroundColor: themeConfigutation.getColor('#f4f3ef') }]}>
                    <ProfileBarContainer
                        canShare={true}
                        openPopupHandler={() => {
                            this.openProfileShareContainer();
                            rjAnalytics.sendAnalyticsEvent('profile_share_container_opened', 'game_factory_container');
                        }}
                        disableActionBtn={this.disableActionBtn}
                    />
                    {this.renderProfileShareContainer()}
                    {this.renderSelectionList()}
                    {this.renderHostedGames()}
                    {this.renderTutorialContainer()}
                    {this.renderAdViewPlaceHolder()}
                    {this.renderJoinGameDialog()}
                </View>
            );
        } else {
            return null;
        }
    }
}

const separator = () => {
    return <View style={styles.separatorStyle} />;
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'flex-start',
    },
    width100: { width: '100%' },
    header: {
        fontSize: 12,
        paddingLeft: 8,
        paddingTop: 4,
        paddingBottom: 4,
    },
    separatorStyle: {
        height: 1,
        width: '100%',
        backgroundColor: '#a6a6a6',
    },
});

function mapStateToProps(state) {
    const { popups, utils, friends } = state;
    return { popups, utils, friends };
}
const mapDispatchToProps = (dispatch) =>
    bindActionCreators(
        {
            updatePopupVisibility,
            clearPopups,
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(GameFactoryContainer);
