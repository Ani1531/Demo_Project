import React, { PureComponent } from 'react';
import { AppState, BackHandler, StyleSheet, View } from 'react-native';
import Board from './Board';
import Config from './configs/Config';
import ConfigurationWrapper from './utils/ConfigurationWrapper';
import PuzzleGamePlayService from './service/PuzzleGamePlayService';
import DialogModal from './modal/DialogModal';
import MenuContainer from './component/MenuContainer';
import { createDialogInstance, getCustomMessage } from './utils/MessageUtils';
import {
    gameInitialize,
    getGameType,
    getLiveGameStats,
    getHostGamesHeadToHeadStats,
    getSettingsOnce,
    getUniqueWordsPlayedCount,
    isEmailGame,
    isLiveGame,
    isPuzzleGame,
    isSoloGame,
} from './service/GamePlayService';
import DimensionUtils from './utils/DimensionUtils';
import get from 'lodash/get';
import debounce from 'lodash/debounce';
import NormalGameOptionsModal from './modal/NormalGameOptionsModal';
import SoloGameOptionsModal from './modal/SoloGameOptionsModal';
import ConnectionIndicator from './component/ConnectionIndicator';
import BoardHeader from './component/BoardHeader';
import ViewStatsModal from './modal/ViewStatsModal';
import ReactResizeDetector from 'react-resize-detector';
import UnseenTilesModal from './modal/UnseenTilesModal';
import { getEventKeyCode, getNull, invokeGlobalMethod } from './utils/Utils';
import SoundUtils from './utils/SoundUtils';
import MoveListModal from './modal/MoveListModal';
import ScoringDetailsModal from './modal/ScoringDetailsModal';
import HostInviteGameModal from './modal/HostInviteGameModal';
import SoloStatsModal from './modal/SoloStatsModal';
import GameBoardSideLayout from './component/GameBoardSideLayout';
import EventWrapper from './utils/EventWrapper';
import NetInfo from '@react-native-community/netinfo';
import { Provider } from 'react-redux';
import TemporaryEventReceiver from './TemporaryEventReceiver';
import { screenResized } from './actions/DimensionActions';
import ReactCustomTooltip from './component/ReactCustomTooltip';
import SoloSaveGameContainerModal from './modal/SoloSaveGameContainerModal';
import ColorConfig from './configs/ColorConfig';
import DocumentWrapper from './utils/DocumentWrapper';
import LobbyChat from './component/LobbyChat';
import NativeChatDictionary from './component/NativeChatDictionary';
import store from './store';
import {
    CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY,
    GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS,
    GAME_LIVE_HOST_JOINED_PLAYER_STATS,
    GAME_LIVE_HOST_JOIN_DIALOG,
    GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME,
    GAME_LIVE_LANGUAGE_CHANGE,
    GAME_PAGE_VISIBILITY_CHANGED,
    GAME_REDUCER_UPDATE_GAMETYPE,
    GAME_SET_INGAME_MODE,
    GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET,
    CONFIG_SET_SETTING,
    RELOAD_APP,
    DIMENSION_SCREEN_RESIZE,
} from './configs/ActionIdentifiers';
import log from 'loglevel';
import LiveGamePlayUtils from './utils/LiveGamePlayUtils';
import { checkRatingChange } from './service/LiveGamePlayService';
import ReactCustomTooltipExp from './component/ReactCustomTooltipExp';
import LetterSelectorModal from './modal/LetterSelectorModal';
import SwapTilesModal from './modal/SwapTilesModal';
import S14Text from './component/S14Text';
import FontAwesomeSpin from './component/FontAwesomeSpin';
import LayoutUtils from './utils/LayoutUtils';
import useInterval from './provider/UseInterval';
import LayoutWrapper from './utils/LayoutWrapper';
import { setBoardAboveViewsHeight } from './utils/GameBoardUtils';
import ServiceWrapper from './utils/ServiceWrapper';
import { cellReducerEmptyGameboard, cellReducerReinitCell } from './actions/CellActions';
import { reloadApp } from './actions/GameActions';
import { clearMessageList } from './actions/ChatActions';

const eventBus = require('js-event-bus')();

function PollingCallInit() {
    useInterval(() => {
        eventBus.emit(Config.EVENT_PING_POLLING);
    }, Config.ASYNC_POLLING_TIMEOUT);
    useInterval(() => {
        if (!DimensionUtils.isNative() && DimensionUtils.isMobile()) {
            eventBus.emit(DIMENSION_SCREEN_RESIZE);
        }
    }, Config.RESIZE_POLLING_TIMEOUT);
    return null;
}

export default class App extends PureComponent {
    onWindowResize = debounce((width, height) => {
        store.dispatch(screenResized({ width, height, top: 0, left: 0 }));
    }, ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('window_resize_debounce'));

    constructor(props) {
        super(props);
        this.dialogModalRef = React.createRef();
        this.normal_game_options_overlay = React.createRef();
        this.solo_game_options_overlay = React.createRef();
        this.view_stats_modal = React.createRef();
        this.unseen_tiles_modal = React.createRef();
        this.move_list_modal = React.createRef();
        this.hostInviteModalRef = React.createRef();
        this.soloStatusDialogRef = React.createRef();
        this.letterSelectorModalRef = React.createRef();
        this.swapTilesModal = React.createRef();
        this.state = {
            showPuzzleBoardHeader: true,
            showBoardContainer: this.props.showBoardContainer,
            showLoader: true,
            showSideMenu: false,
            showInnerSideMenu: false,
            showNormalGameOptions: false,
            showMenu: false,
            showChatOrDictionary: undefined,
            bannerHt: 0,
        };
        store.dispatch(screenResized(DimensionUtils.getWindowDimensions()));
    }

    validateUser = () => {
        let guid = store.getState().game.guid;
        let uuid = store.getState().game.uuid;

        if (!DimensionUtils.isNative() && !guid && !uuid) {
            invokeGlobalMethod('login_method_name', 'login_method_params');
            if (isPuzzleGame()) {
            } else {
                eventBus.emit(Config.NO_VALID_USER);
                throw new Error('No User');
            }
        }
    };

    onSendGameRequest = (guid) => {
        this.normal_game_options_overlay.current.onSendGameRequest({ guid }, true);
    };

    forceUpdatePromise = () => new Promise((accept) => this.forceUpdate(accept));

    componentDidMount = () => {
        if (!DimensionUtils.isNative() && !ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            getSettingsOnce();
        }
        setTimeout(() => this.showBannerAds(), 1000);
        eventBus.on(Config.SEND_PUZZLE_MOVE_FAIL, PuzzleGamePlayService.onSendPuzzleMoveFail);
        eventBus.on(Config.SEND_PUZZLE_MOVE_SUCCESS, PuzzleGamePlayService.onSendPuzzleMoveSuccess);
        eventBus.on(Config.SHOW_DIALOG_MODAL, this.showDialogModal);
        eventBus.on(Config.HIDE_DIALOG_MODAL, this.hideDialogModal);
        eventBus.on(Config.LOADER_OVERLAY, this.setLoaderOverlayVisibility);
        eventBus.on(Config.BOARD_LOAD_START, this.boardOnLoadStart);
        eventBus.on(Config.BOARD_LOAD_FAIL, this.boardOnLoadFail);
        eventBus.on(Config.EVENT_SOLO_NO_LOGIN_GAME_START, this.soloNoLoginGameStart);
        eventBus.on(Config.SHOW_START_GAME_OPTIONS, this.showStartGameOptions);
        eventBus.on(Config.START_NEW_GAME_INVITATION_RECEIVED, this.onInvitationReceived);
        eventBus.on(Config.START_GAME_REQUEST_ACCEPTED, this.startNewGame);
        eventBus.on(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, this.startNewGame);
        eventBus.on(Config.SEND_EMAIL_GAME_PASS_SUCCESSFUL, this.startNewGame);
        eventBus.on(Config.ON_HOSTED_GAME_ITEM_SELECTED, this.onHostedGameItemSelected);
        eventBus.on(Config.SHOW_MOVES_LIST, this.onShowMovesList);
        eventBus.on(Config.ON_SEND_GAME_REQUEST, this.onSendGameRequest);
        eventBus.on(Config.SEND_EMAIL_GAME_MOVE_SUCCESSFUL, this.startNewGame);
        eventBus.on(Config.SWAP_TILES_EMAIL_GAME_REQUEST_SUCCESSFUL, this.startNewGame);
        eventBus.on(Config.RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onStopGamefeedPollOperation);
        eventBus.on(Config.DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onStopGamefeedPollOperation);
        eventBus.on(Config.DELETE_EMAIL_GAME_REQUEST_FAILED, this.onStopGamefeedPollOperation);
        eventBus.on(Config.RESIGN_EMAIL_GAME_REQUEST_FAILED, this.onStopGamefeedPollOperation);
        eventBus.on(Config.SHOW_BOARD_CONTAINER, this.showBoardContainer);
        eventBus.on(Config.SHOW_VIEW_STATS_MODAL_ON_MULTIPLAYER_SELF_HOST_GAME, this.onShowViewStatsModalForSelfHostedGame);
        eventBus.on(Config.HIDE_BOARD_CONTAINER, this.hideBoardContainer);
        eventBus.on(Config.SHOW_SOLO_STATS_DIALOG, this.onShowSoloStatusDialog);
        eventBus.on(Config.DETACH_ALL_EVENT, this.detachAllEvent);
        eventBus.on(Config.HIDE_PUZZLE_BOARD_HEADER, this.showHidePuzzleBoardHeader);
        eventBus.on(Config.ON_PLAYER_ITEM_SELECTED, this.openPlayerModal);
        eventBus.on(Config.JOIN_HOSTED_GAME_EVENT, this.onGameJoin);
        eventBus.on(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, this.boardCloseLobbyShow);

        EventWrapper.addKeyListener(this.onKeyUp);
        EventWrapper.addCustomeEventListener(this.customEventListener);
        this.changeAppStateSubscription = AppState.addEventListener('change', this.handleVisibilityChange);
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', this.onBackPress);

        this.networkListenerUnsubscribe = NetInfo.addEventListener((state) => {
            eventBus.emit(CONNECTIVITY_REDUCER_CHECK_AND_SET_CONNECTIVITY, null, state.isConnected);
        });
        //Game Initialization
        log.info('in App, in setLoaderOverlayVisibility, in App.componentDidMount');
        gameInitialize();
        this.validateUser();
        this.setDivHeight();
        eventBus.on(Config.SET_SHOW_SIDE_MENU, this.setShowSideMenu);
        eventBus.on(Config.SET_SHOW_INNER_SIDE_MENU, this.setShowInnerSideMenu);
        eventBus.on(Config.REFRESH_APP_ROOT_COMPONENT, this.refreshAppRootComponent);
    };

    showBannerAds = () => {
        let players = get(store.getState(), 'game.players');
        if (players != null && players != undefined) {
            if (players.length > 2) {
                if (!!this.state.showChatOrDictionary)
                    ServiceWrapper.nativeShowBannerAds(0, this.onBannerReceive, this.onBannerFail);
            } else {
                ServiceWrapper.nativeShowBannerAds(0, this.onBannerReceive, this.onBannerFail);
            }
        }
    };

    onBannerReceive = (): void => {
        let bnrAdsHeight = ServiceWrapper.nativeGetBannerAdsHeight();
        this.setState({ bannerHt: bnrAdsHeight });
    };

    onBannerFail = (): void => {
        this.setState({ bannerHt: 0 });
    };

    boardCloseLobbyShow = (data = {}) => {
        eventBus.emit(RELOAD_APP, null, data);
        if (!DimensionUtils.isNative() && !ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            this.hideBoardContainer();
        }
        if (isLiveGame()) {
            this.setState({ reloadNative: !!data.background });
        }
        gameInitialize();
        if (isPuzzleGame()) {
            this.showHidePuzzleBoardHeader(true);
        }
    };

    setDivHeight = () => {
        if (DimensionUtils.isMobile()) {
            let boardDimen = get(store.getState(), 'layout.layoutBoardDimenWidth');
            let newHeight = 2.25 * boardDimen;
            if (!isNaN(newHeight)) DocumentWrapper.setContainerHeight(newHeight + 'px');
        } else if (get(store.getState(), 'game.board_type') === 'super') {
            DocumentWrapper.setContainerHeight(Config.LOBBY_SCREEN_MOBILE_CONTAINER_HEIGHT);
        } else if (isLiveGame()) {
            DocumentWrapper.setContainerHeight(Config.LOBBY_SCREEN_CONTAINER_HEIGHT);
        } else if (!!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            DocumentWrapper.setContainerHeight('100vh');
        } else {
            DocumentWrapper.setContainerHeight(Config.NORMAL_SCREEN_CONTAINER_HEIGHT);
        }
    };

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.setDivHeight();

        if (!DimensionUtils.isMobile() && get(store.getState(), 'game.gameBoardSideLayoutActiveTab') === 4)
            eventBus.emit(GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET);
    }

    refreshAppRootComponent = () => {
        this.setState({ lastRendered: Date.now() });
        this.setDivHeight();
    };

    showHidePuzzleBoardHeader = (val) => {
        this.setState({ showPuzzleBoardHeader: val });
    };

    openPlayerModal = (data) => {
        LiveGamePlayUtils.onShowViewStatsModal(data);
        this.view_stats_modal.current.show(data);
    };

    restartApp = () => {
        this.setState({ uniqueId: Math.random() });
    };

    setLoaderOverlayVisibility = (result) => {
        if (result.visible) {
            log.info('in App, in setLoaderOverlayVisibility, result.caller is: ' + result.caller);
        }
        this.setState({
            showLoader: result.visible,
            showLoaderColor: result.loaderColor,
            boardSpinner: result.boardSpinner,
        });
    };

    boardOnLoadStart = (result) => {
        this.setLoaderOverlayVisibility({
            visible: true,
            transparentLoader: true,
            caller: 'App.boardOnLoadStart',
        });
    };

    showBoardContainer = () => {
        this.setState({ showLoader: false, showBoardContainer: true });
    };

    hideBoardContainer = () => {
        this.setState({ showBoardContainer: false });
    };

    setLangForDic = (data) => {
        let dic = get(data, store.getState().game.channel + '.dic');
        if (dic && dic.length > 0) {
            let lang = null;
            switch (dic) {
                case 'twl':
                    lang = 'us_en';
                    break;
                case 'sow':
                    lang = 'uk_en';
                    break;
                default:
                    lang = dic;
                    break;
            }
            if (lang && lang !== store.getState().game.lang) {
                eventBus.emit(GAME_LIVE_LANGUAGE_CHANGE, null, lang);
            }
        }
    };

    startNewGame = ({ action, data }) => {
        let channel = store.getState().game.channel;
        let dic = get(data, channel + '.dic');
        let increament = get(data, channel + '.increament') || get(data, channel + '.livegame.increament');
        let duration = get(data, channel + '.duration') || get(data, channel + '.livegame.duration');
        let gametype = get(data, channel + '.rated') || get(data, channel + '.livegame.rated');

        let obj = {
            ...(dic ? { dic } : {}),
            ...(increament ? { increament } : {}),
            ...(duration ? { duration } : {}),
            ...(gametype ? { gametype } : {}),
        };

        if (dic || increament || duration) {
            eventBus.emit(GAME_REDUCER_UPDATE_GAMETYPE, null, {
                ...(dic ? { dic } : {}),
                ...(increament ? { increament } : {}),
                ...(duration ? { duration } : {}),
                ...(gametype ? { gametype } : {}),
            });
        }

        let result = this.hideAllGameStartModalDialog();
        !isEmailGame() &&
            this.setLoaderOverlayVisibility({
                visible: false,
                caller: 'App.startNewGame',
            });
        this.setLangForDic(data);
        if (
            action === Config.GAME_FEED_REPSONSE_ACTION &&
            result &&
            [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(getGameType())
        ) {
            this.normal_game_options_overlay.current && this.normal_game_options_overlay.current.setGameFeed(true);
            if (getGameType() !== Config.GAME_TYPE_BLITZ) {
                createDialogInstance({
                    title: 'Continue Game',
                    actionButtonText: 'OK',
                    onAction: getNull,
                    body: 'You are playing a game, please click to continue',
                    hideCancel: true,
                    isConfirmableByKey: true,
                });
            }
        } else if (result === true) {
            SoundUtils.gameStartSound();
        }
    };

    onShowSoloStatusDialog = () => {
        this.soloStatusDialogRef && this.soloStatusDialogRef.current && this.soloStatusDialogRef.current.show();
    };

    hideAllGameStartModalDialog = () => {
        /* let normalGameOptionsDidHide =
            this.normal_game_options_overlay.current &&
            this.normal_game_options_overlay.current.hide(); */
        this.hideStartGameOptions();
        let viewStatsModalDidHide = this.view_stats_modal.current && this.view_stats_modal.current.onClose();
        let unseenTilesModalDidHide = this.unseen_tiles_modal.current && this.unseen_tiles_modal.current.onClose();
        this.hostInviteModalRef && this.hostInviteModalRef.current && this.hostInviteModalRef.current.hide();
        this.dialogModalRef.current /* &&
            this.dialogModalRef.current.isAutoCancellable() */ && this.dialogModalRef.current.hide();
        store.dispatch({ type: GAME_SET_INGAME_MODE, payload: true });
        return (
            /*  normalGameOptionsDidHide || */
            viewStatsModalDidHide || unseenTilesModalDidHide
        );
    };

    boardOnLoadFail = (result) => {
        let messageText = getCustomMessage(result);
        createDialogInstance({
            title: 'Message',
            actionButtonText: 'Retry',
            onAction: gameInitialize,
            body: messageText,
            hideCancel: true,
            notDismissable: true,
            isConfirmableByKey: true,
        });

        this.setLoaderOverlayVisibility({
            visible: false,
            caller: 'App.boardOnLoadFail',
        });
    };

    showDialogModal = (data) => {
        this.dialogModalRef.current.show(data);
        this.setLoaderOverlayVisibility({
            visible: false,
            caller: 'App.showDialogModal',
        });
    };

    hideDialogModal = () => this.dialogModalRef.current.hide();

    showStartGameOptions = () => {
        /* this.normal_game_options_overlay.current &&
            this.normal_game_options_overlay.current.fetchNormalGameOptions(); */
        this.setState({ showNormalGameOptions: true });
    };

    hideStartGameOptions = () => {
        this.setState({ showNormalGameOptions: false });
    };

    soloNoLoginGameStart = () => {
        this.setLoaderOverlayVisibility({
            visible: false,
            caller: 'App.soloNoLoginGameStart',
        });
    };

    onInvitationReceived = async (data) => {
        let players = get(store.getState(), 'game.players') || [];
        if (
            this.dialogModalRef &&
            this.dialogModalRef.current.isOpen() &&
            this.dialogModalRef.current.isRematchDialog() &&
            players.find((player) => player.guid === get(data, 'sender.guid'))
        ) {
            eventBus.emit(Config.MATCH_REMATCH_RESPONSE_EVENT, null, data);
        } else {
            SoundUtils.messageSound();
            let reqgameid = get(data, 'reqgameid');
            if (reqgameid) {
                if (LiveGamePlayUtils.isMultiplayerAcceptDialog()) {
                    let jndply = await LiveGamePlayUtils.getAllPlayerDatasAndSet(get(data, 'sender'));
                    let secret = get(data, 'secret');
                    let wait = get(data, 'wait');
                    eventBus.emit(GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME, null, {
                        gamereqid: reqgameid,
                        jndply: { ...jndply, secret, wait },
                    });
                    if (!this.view_stats_modal.current.isOpen()) {
                        this.view_stats_modal.current.show(data);
                    }
                } else {
                    LiveGamePlayUtils.onShowViewStatsModal(data);
                    this.view_stats_modal.current.show(data);
                }
            } else {
                LiveGamePlayUtils.onShowViewStatsModal(data);
                this.view_stats_modal.current.show(data);
            }
        }
    };

    onGameJoin = async (res) => {
        let jndply = await LiveGamePlayUtils.getAllPlayerDatasAndSet(res.data);
        eventBus.emit(GAME_LIVE_JOIN_MULTI_PLAYER_HOSTED_GAME, null, {
            gamereqid: get(res, 'data.gamereqid'),
            jndply,
        });
    };

    isDialogModalOpen = () => {
        return this.dialogModalRef.current.isOpen();
    };

    componentWillUnmount = () => {
        this.detachAllEvent();
        if (DimensionUtils.isNative() || !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('isRNWeb')) {
            DocumentWrapper.setContainerHeight('100vh');
            store.dispatch(cellReducerEmptyGameboard());
            store.dispatch(cellReducerReinitCell());
            store.dispatch(reloadApp());
            store.dispatch(clearMessageList());
        }
    };

    detachAllEvent = () => {
        eventBus.detach(Config.EVENT_BOARD_CLOSE_LOBBY_SHOW, this.boardCloseLobbyShow);
        eventBus.detach(Config.SEND_PUZZLE_MOVE_FAIL, PuzzleGamePlayService.onSendPuzzleMoveFail);
        eventBus.detach(Config.SEND_PUZZLE_MOVE_SUCCESS, PuzzleGamePlayService.onSendPuzzleMoveSuccess);
        eventBus.detach(Config.SHOW_DIALOG_MODAL, this.showDialogModal);
        eventBus.detach(Config.HIDE_DIALOG_MODAL, this.hideDialogModal);
        eventBus.detach(Config.LOADER_OVERLAY, this.setLoaderOverlayVisibility);
        eventBus.detach(Config.BOARD_LOAD_START, this.boardOnLoadStart);
        eventBus.detach(Config.BOARD_LOAD_FAIL, this.boardOnLoadFail);
        eventBus.detach(Config.EVENT_SOLO_NO_LOGIN_GAME_START, this.soloNoLoginGameStart);
        eventBus.detach(Config.SHOW_START_GAME_OPTIONS, this.showStartGameOptions);
        eventBus.detach(Config.START_NEW_GAME_INVITATION_RECEIVED, this.onInvitationReceived);
        eventBus.detach(Config.START_GAME_REQUEST_ACCEPTED, this.startNewGame);
        eventBus.detach(Config.GET_GAME_FEED_REQUEST_SUCCESSFUL, this.startNewGame);
        eventBus.detach(Config.SEND_EMAIL_GAME_PASS_SUCCESSFUL, this.startNewGame);
        eventBus.detach(Config.ON_HOSTED_GAME_ITEM_SELECTED, this.onHostedGameItemSelected);
        eventBus.detach(Config.SHOW_MOVES_LIST, this.onShowMovesList);
        eventBus.detach(Config.ON_SEND_GAME_REQUEST, this.onSendGameRequest);
        eventBus.detach(Config.SEND_EMAIL_GAME_MOVE_SUCCESSFUL, this.startNewGame);
        eventBus.detach(Config.SWAP_TILES_EMAIL_GAME_REQUEST_SUCCESSFUL, this.startNewGame);
        eventBus.detach(Config.RESIGN_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onStopGamefeedPollOperation);
        eventBus.detach(Config.DELETE_EMAIL_GAME_REQUEST_SUCCESSFUL, this.onStopGamefeedPollOperation);
        eventBus.detach(Config.DELETE_EMAIL_GAME_REQUEST_FAILED, this.onStopGamefeedPollOperation);
        eventBus.detach(Config.RESIGN_EMAIL_GAME_REQUEST_FAILED, this.onStopGamefeedPollOperation);
        eventBus.detach(Config.SHOW_BOARD_CONTAINER, this.showBoardContainer);
        eventBus.detach(Config.SHOW_VIEW_STATS_MODAL_ON_MULTIPLAYER_SELF_HOST_GAME, this.onShowViewStatsModalForSelfHostedGame);
        eventBus.detach(Config.HIDE_BOARD_CONTAINER, this.hideBoardContainer);
        eventBus.detach(Config.SHOW_SOLO_STATS_DIALOG, this.onShowSoloStatusDialog);
        eventBus.detach(Config.DETACH_ALL_EVENT, this.detachAllEvent);
        eventBus.detach(Config.HIDE_PUZZLE_BOARD_HEADER, this.showHidePuzzleBoardHeader);
        eventBus.detach(Config.ON_PLAYER_ITEM_SELECTED, this.openPlayerModal);
        eventBus.detach(Config.JOIN_HOSTED_GAME_EVENT, this.onGameJoin);

        EventWrapper.removeKeyListener(this.onKeyUp);
        EventWrapper.removeCustomeEventListener(this.customEventListener);
        this.changeAppStateSubscription && this.changeAppStateSubscription.remove();
        this.backHandler && this.backHandler.remove();

        this.networkListenerUnsubscribe && this.networkListenerUnsubscribe();
        eventBus.detach(Config.SET_SHOW_SIDE_MENU, this.setShowSideMenu);
        eventBus.detach(Config.SET_SHOW_INNER_SIDE_MENU, this.setShowInnerSideMenu);
        eventBus.detach(Config.REFRESH_APP_ROOT_COMPONENT, this.refreshAppRootComponent);
        eventBus.detach(Config.EVENT_PING_POLLING);
    };

    onStopGamefeedPollOperation = () => {};

    onHostedGameItemSelected = (item) => {
        let guid = get(item, 'uid.guid');
        if (guid !== store.getState().game.guid || Number(get(item, 'numplys')) > 2) {
            LiveGamePlayUtils.onShowViewStatsModal(item);
            this.view_stats_modal.current.show(item);
        }
    };

    onShowViewStatsModalForSelfHostedGame = (res) => {
        res.selfHost = true;
        LiveGamePlayUtils.onShowViewStatsModal(res);
        if (this.view_stats_modal.current) this.view_stats_modal.current.show(res);
        else eventBus.emit(Config.ON_SHOW_VIEW_STATS_MODAL_FOR_SELF_HOST, null, res);
    };

    onBackPress = () => {
        ServiceWrapper.nativeHideBannerAds();
        let showIntertitialAdsOnBackBtnPress = () => {
            if (this.state.showBoardContainer && isLiveGame()) {
                eventBus.emit(Config.NATIVE_BACK_PRESS_HANDLE);
                return true;
            }
            return false;
        };
        ServiceWrapper.nativeShowInterstitialAd(showIntertitialAdsOnBackBtnPress());
    };

    onEscapeKeyUp = (event) => {
        if (this.dialogModalRef && this.dialogModalRef.current && this.dialogModalRef.current.isOpen()) {
            return this.dialogModalRef.current.checkAndHide();
        } else if (this.move_list_modal && this.move_list_modal.current && this.move_list_modal.current.isOpen()) {
            return this.move_list_modal.current.onClose();
        } else {
            eventBus.emit(Config.KEY_PRESS_EVENT_FOR_BOARD, null, event);
        }
    };

    getBoardDimension = () => {
        let boardDimenWidth = get(this.props, 'layout.layoutBoardWidth');

        return {
            top: 0,
            left: 0,
            height: DimensionUtils.getWindowDimensions().height,
            width: boardDimenWidth,
        };
    };

    getLoaderContainerStyle = () => {
        return {
            height: LayoutWrapper.getLoaderContainerHeight(),
        };
    };

    getGameSpecificAboveViews = () => {
        switch (getGameType()) {
            case Config.GAME_TYPE_LIVE_GAME:
            case Config.GAME_TYPE_BLITZ:
                return this.getLiveGameSpecificAboveViews();
            case Config.GAME_TYPE_EMAIL:
                return this.getEmailGameSpecificAboveViews();
            case Config.GAME_TYPE_SOLO:
                return this.getEmailGameSpecificAboveViews();
            case Config.GAME_TYPE_PUZZLE:
                return !store.getState().game.already_attempted && this.state.showPuzzleBoardHeader
                    ? this.getEmailGameSpecificAboveViews()
                    : null;
            default:
                return null;
        }
    };

    getGameBoardSideLayout = () => (
        <GameBoardSideLayout
            id={'gameboard_side_layout'}
            key={'gameboard_side_layout'}
            showInnerSideMenu={this.state.showInnerSideMenu}
        />
    );

    openChatorDictionary = (data) => {
        this.setState({ showChatOrDictionary: data }, () => {
            this.showBannerAds();
        });
    };

    renderAdViewPlaceHolder = () => {
        return <View style={[{ height: this.state.bannerHt }]} />;
    };

    renderNativeChatDictionaryContainer = () =>
        DimensionUtils.isNative() ? (
            <View
                pointerEvents="box-none"
                style={{
                    height: '100%',
                    width: '100%',
                    zIndex: 1,
                    position: 'absolute',
                    justifyContent: 'flex-end',
                }}
            >
                {!!this.state.showChatOrDictionary ? (
                    <View
                        style={{
                            height: '100%',
                            width: '100%',
                            zIndex: 1,
                            position: 'absolute',
                            backgroundColor: ColorConfig.SIDE_PANEL_BACKGROUND_COLOR,
                        }}
                    >
                        <NativeChatDictionary type={this.state.showChatOrDictionary} closeMenuHandler={this.closeMenuPopUp} />
                    </View>
                ) : null}
                {this.renderAdViewPlaceHolder()}
            </View>
        ) : null;

    showMenuPopUp = () => {
        this.setState({ showMenu: true });
    };

    closeMenuPopUp = () => {
        this.setState({ showMenu: false });
        if (!!this.state.showChatOrDictionary) {
            this.setState({ showChatOrDictionary: undefined }, () => {
                this.showBannerAds();
            });
        }
    };

    renderMenuContainer = () =>
        this.state.showMenu ? (
            <MenuContainer
                closeMenuHandler={this.closeMenuPopUp}
                openChatorDictionary={this.openChatorDictionary}
                openSupport={this.props.openSupport}
                gameBoardGoBack={this.props.gameBoardGoBack}
            />
        ) : null;

    onResize = (width, height) => {
        setBoardAboveViewsHeight(height);
    };

    getLiveGameSpecificAboveViews = () =>
        DimensionUtils.isNative() ? (
            <BoardHeader lastMoveTilesRemainingOnly gameBoardGoBack={this.props.gameBoardGoBack} />
        ) : (
            <ReactResizeDetector handleHeight onResize={this.onResize} style={[styles.overflowHidden]}>
                <BoardHeader lastMoveTilesRemainingOnly gameBoardGoBack={this.props.gameBoardGoBack} />
            </ReactResizeDetector>
        );

    getEmailGameSpecificAboveViews = () =>
        DimensionUtils.isNative() ? (
            <BoardHeader emailGame lastMoveTilesRemainingOnly gameBoardGoBack={this.props.gameBoardGoBack} />
        ) : (
            <ReactResizeDetector handleHeight onResize={this.onResize} style={[styles.overflowHidden]}>
                <BoardHeader emailGame lastMoveTilesRemainingOnly gameBoardGoBack={this.props.gameBoardGoBack} />
            </ReactResizeDetector>
        );

    onShowMovesList = () => {
        this.move_list_modal.current && this.move_list_modal.current.show();
    };

    handleVisibilityChange = (appState) => {
        let isVisible = appState === 'active';
        eventBus.emit(GAME_PAGE_VISIBILITY_CHANGED, null, isVisible);
        eventBus.emit(Config.PAGE_VISIBILITY_CHANGED, null, isVisible);
        EventWrapper.onAppStateChange(appState, () => this.hideStartGameOptions());
    };

    onKeyUp = (event) => {
        let code = getEventKeyCode(event);
        if (code.includes('Escape')) {
            this.onEscapeKeyUp(event);
        } else if (code.includes('Enter') && this.dialogModalRef.current && this.dialogModalRef.current.isOpen()) {
            if (this.dialogModalRef.current.getIsConfirmableByKey()) {
                this.dialogModalRef.current.onAction();
            }
        } else {
            eventBus.emit(Config.KEY_PRESS_EVENT_FOR_BOARD, null, event);
        }
    };

    customEventListener = (event) => {
        let darkMode = get(event, 'detail.darkMode');
        if (darkMode) {
            let obj = {
                isDarkMode: darkMode === 'y',
            };
            eventBus.emit(CONFIG_SET_SETTING, null, obj);
        }
    };

    getModalOverlayStyle = () => ({
        backgroundColor: 'rgba(55, 55, 55, 0.6)',
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        borderRadius: Config.COMMON_BORDER_RADIUS,
        justifyContent: 'center',
    });

    setShowSideMenu = (value) => this.setState({ showSideMenu: value, showInnerSideMenu: false });

    setShowInnerSideMenu = (value) => this.setState({ showInnerSideMenu: value, showSideMenu: false });

    shouldShowSideMenu = () => true;

    render = () =>
        DimensionUtils.isNative() ? (
            this.renderContent()
        ) : (
            <ReactResizeDetector handleHeight handleWidth onResize={this.onWindowResize}>
                {this.renderContent()}
            </ReactResizeDetector>
        );

    renderContent = () => (
        <View style={[styles.heightWidthHundredPercent, styles.overflowHidden]}>
            <TemporaryEventReceiver />
            <PollingCallInit />
            {this.state.showBoardContainer
                ? [
                      <View
                          id={'board_container'}
                          key={'board_container'}
                          style={[styles.coloumnDirection, LayoutWrapper.getBoardContainerHeight()]}
                      >
                          {this.getGameSpecificAboveViews()}
                          <Board
                              isDialogModalOpen={this.isDialogModalOpen}
                              id={'board'}
                              key={'board'}
                              {...this.getBoardDimension()}
                              letterSelectorModalRef={this.letterSelectorModalRef}
                              swapTilesModal={this.swapTilesModal}
                              showMenuPopUp={this.showMenuPopUp}
                              closeMenuPopUp={this.closeMenuPopUp}
                              showMenu={this.state.showMenu}
                              gameBoardGoBack={this.props.gameBoardGoBack}
                          />
                      </View>,
                      this.getGameBoardSideLayout(),
                      this.renderMenuContainer(),
                      this.renderNativeChatDictionaryContainer(),
                  ]
                : null}

            {this.state.showLoader ? (
                <View style={[StyleSheet.absoluteFill, styles.overlayContainer, { ...this.getLoaderContainerStyle() }]}>
                    {this.state.boardSpinner === Config.BOARD_SPINNER ? (
                        <FontAwesomeSpin />
                    ) : (
                        <S14Text style={LayoutUtils.getLoaderTextColorStyle()}>Connecting ...</S14Text>
                    )}
                </View>
            ) : null}
            {isLiveGame()
                ? [
                      this.state.showNormalGameOptions ? (
                          <NormalGameOptionsModal
                              ref={this.normal_game_options_overlay}
                              id={'normal_game_options_overlay'}
                              key={'normal_game_options_overlay'}
                              reloadNative={this.state.reloadNative}
                          />
                      ) : null,
                      <HostInviteGameModal
                          ref={this.hostInviteModalRef}
                          isForHosting={false}
                          renderBodyOnly={false}
                          overlayStyle={this.getModalOverlayStyle()}
                          id={'host_invite_game_overlay'}
                          key={'host_invite_game_overlay'}
                      />,
                      DimensionUtils.isMobile() ? null : <LobbyChat />,
                  ]
                : null}
            {!isPuzzleGame() ? (
                <ViewStatsModal
                    ref={this.view_stats_modal}
                    id={'view_stats_modal'}
                    key={'view_stats_modal'}
                    overlayStyle={this.getModalOverlayStyle()}
                />
            ) : null}
            {isSoloGame()
                ? [
                      <SoloGameOptionsModal
                          ref={this.solo_game_options_overlay}
                          id={'solo_game_options_overlay'}
                          key={'solo_game_options_overlay'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                      <SoloSaveGameContainerModal
                          ref={this.soloSaveGameDialogRef}
                          id={'soloSaveGameDialogRef'}
                          key={'soloSaveGameDialogRef'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                  ]
                : null}
            <DialogModal
                ref={this.dialogModalRef}
                id={'dialog_modal'}
                key={'dialog_modal'}
                overlayStyle={this.getModalOverlayStyle()}
            />
            <LetterSelectorModal
                key={'letterSelectorModal'}
                ref={this.letterSelectorModalRef}
                overlayStyle={this.getModalOverlayStyle()}
            />
            <SwapTilesModal key={'swapTilesModal'} ref={this.swapTilesModal} overlayStyle={this.getModalOverlayStyle()} />
            {!isPuzzleGame()
                ? [
                      <UnseenTilesModal
                          ref={this.unseen_tiles_modal}
                          id={'unseen_tiles_modal'}
                          key={'unseen_tiles_modal'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                      <MoveListModal
                          ref={this.move_list_modal}
                          id={'move_list_modal'}
                          key={'move_list_modal'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                      <ScoringDetailsModal
                          id={'scoring_details_modal'}
                          key={'scoring_details_modal'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                      <SoloStatsModal
                          ref={this.soloStatusDialogRef}
                          id={'soloStatusDialogRef'}
                          key={'soloStatusDialogRef'}
                          overlayStyle={this.getModalOverlayStyle()}
                      />,
                  ]
                : null}
            <ConnectionIndicator id={'connection_indicator'} key={'connection_indicator'} />
            <ReactCustomTooltip />
            <ReactCustomTooltipExp />
        </View>
    );
}

const styles = StyleSheet.create({
    puzzleSidePanelScrollContainer: {
        overflow: 'hidden',
        paddingBottom: '18px',
        position: 'absolute',
    },
    coloumnDirection: {
        flexDirection: 'column',
    },
    flex1: {
        flex: 1,
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    maxHeightHundred: {
        maxHeight: '100%',
    },
    overlayContainer: {
        backgroundColor: 'transparent',
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
    },

    heightWidthHundredPercent: {
        height: '100%',
        width: '100%',
    },
});
