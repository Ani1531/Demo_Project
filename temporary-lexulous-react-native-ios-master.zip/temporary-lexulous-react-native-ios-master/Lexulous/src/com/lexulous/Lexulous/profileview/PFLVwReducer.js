// @flow

import { UPDT_APPL_LGN_INFO, UPDT_FB_LGN_INFO, UPDT_GGL_LGN_INFO, UPDT_LXLS_LGN_INFO } from '../userprofile/PFLEventTypes';

import type {
    ActionUpdateAppleLgnInfo,
    ActionUpdateFBLgnInfo,
    ActionUpdateGGLLgnInfo,
    ActionUpdateLXLSLgnInfo,
    ProfileAssociations,
    ProfileVwAction,
} from '../commons/RJTypes';

const INITIAL_STATE = {
    appleLoginInfo: null,
    fbLoginInfo: null,
    gglLoginInfo: null,
    lxlsLoginInfo: null,
};

export default function PFLVwReducer(state: ProfileAssociations = INITIAL_STATE, action: ProfileVwAction) {
    switch (action.type) {
        case UPDT_APPL_LGN_INFO: {
            let mdfdaction = ((action: any): ActionUpdateAppleLgnInfo);
            let data = doUpdateAppleLoginInfo(state, mdfdaction);
            return data;
        }
        case UPDT_FB_LGN_INFO: {
            let mdfdaction = ((action: any): ActionUpdateFBLgnInfo);
            let data = doUpdateFBLoginInfo(state, mdfdaction);
            return data;
        }
        case UPDT_GGL_LGN_INFO: {
            let mdfdaction = ((action: any): ActionUpdateGGLLgnInfo);
            let data = doUpdateGGLLoginInfo(state, mdfdaction);
            return data;
        }
        case UPDT_LXLS_LGN_INFO: {
            let mdfdaction = ((action: any): ActionUpdateLXLSLgnInfo);
            let data = doUpdateLXLSLoginInfo(state, mdfdaction);
            return data;
        }
        default:
            return state;
    }
}

let doUpdateAppleLoginInfo = (state: ProfileAssociations, action: ActionUpdateAppleLgnInfo) => {
    let appleLoginInfo = action.payload;
    //will discard all previous value
    return { ...state, appleLoginInfo };
};

let doUpdateFBLoginInfo = (state: ProfileAssociations, action: ActionUpdateFBLgnInfo) => {
    let fbLoginInfo = action.payload;
    //will discard all previous value
    return { ...state, fbLoginInfo };
};

let doUpdateGGLLoginInfo = (state: ProfileAssociations, action: ActionUpdateGGLLgnInfo) => {
    let gglLoginInfo = action.payload;
    //will discard all previous value
    return { ...state, gglLoginInfo };
};

let doUpdateLXLSLoginInfo = (state: ProfileAssociations, action: ActionUpdateLXLSLgnInfo) => {
    let lxlsLoginInfo = action.payload;
    //will discard all previous value
    return { ...state, lxlsLoginInfo };
};
