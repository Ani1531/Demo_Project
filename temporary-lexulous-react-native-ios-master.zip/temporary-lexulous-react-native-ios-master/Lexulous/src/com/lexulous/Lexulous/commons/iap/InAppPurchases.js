// @flow

class InAppPurchases {
    constructor() {
        this.onAppInit();
    }

    isAdFreeSubsActive = (): boolean => {
        return true;
    };

    onAppInit = (): void => {};

    onDestroy = (): void => {};

    flushTransaction = () => {};

    purchaseCompleted = () => {};

    verifyAnalizerReceipt = () => {};

    getPurchaseHistory = () => {};

    requestPurchase = async (sku: string, callback: ((null, sku: string) => void) | null) => {};

    requestSubscription = async (sku: string, callback: ((null, sku: string) => void) | null) => {};

    getProductsDisplayDetails = async (skus: Array<string>): Promise<{ [string]: { [string]: string } }> => {
        return {};
    };
}

const inAppPurchases: InAppPurchases = new InAppPurchases();

export default inAppPurchases;
