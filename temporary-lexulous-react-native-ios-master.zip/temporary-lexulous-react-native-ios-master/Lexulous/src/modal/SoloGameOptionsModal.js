import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import DimensionUtils from '../utils/DimensionUtils';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
    faArrowCircleLeft,
    faBolt,
    faRobot,
    faStar,
    faUser,
    faPencilAlt,
    faSave,
    faBars,
    faRandom,
    faTable,
} from '@fortawesome/free-solid-svg-icons';
import SoloGameStartForm from '../component/SoloGameStartForm';
import CreateCustomGame from '../component/CreateCustomGame';
import LayoutUtils from '../utils/LayoutUtils';
import {
    sendSavedSoloGameStart,
    sendSoloGameStartData,
    getCustomSavedBoard,
    editSlotGameData,
} from '../service/LiveGamePlayService';
import { connect } from 'react-redux';
import { createDialogInstance } from '../utils/MessageUtils';
import {
    CELL_REDUCER_UPDATE_BOARD_STRUCTURE,
    DIMENSION_SCREEN_RESIZE,
    GAME_INITIALISE_TILES_FOR_CREATE_BOARD,
    GAME_SOLO_MENU_SHOW_HIDE,
    GAME_SOLO_RESET_RESUME_GAME,
    GAME_SOLO_SET_CURRENT_MENU_OPT,
    GAME_SOLO_SET_FORM_TYPE,
} from '../configs/ActionIdentifiers';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import PText from '../component/PText';
import S14Text from '../component/S14Text';
import LayoutWrapper from '../utils/LayoutWrapper';

const eventBus = require('js-event-bus')();

const MenuOption = {
    Init: 1,
    GameForm: 2,
    BoardType: 3,
    Custom: 4,
    BoardSlot: 5,
    CreateGame: 6,
};

function bindFunction() {
    this.bindRequest(this.params);
}

class SoloGameOptionsModal extends React.Component {
    state = {};

    isMenuOpen = () =>
        !this.props.hasSavedGame && this.props.menuOpt && this.props.gid;

    onClose = () => {
        eventBus.emit(GAME_SOLO_MENU_SHOW_HIDE, null, { menuOpt: false });
    };

    onSaveOptClose = () => {
        eventBus.emit(GAME_SOLO_RESET_RESUME_GAME);
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(this.props, nextProps) || !isEqual(this.state, nextState);

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () => ({
        width:
            this.props.currentOpt === MenuOption.CreateGame
                ? 'calc(100% - 1px)'
                : DimensionUtils.isMobile()
                ? '90%'
                : '46%',
        height:
            this.props.currentOpt === MenuOption.CreateGame
                ? 'calc(100% - 1px)'
                : 'min(60%, 330px)',
        position: 'absolute',
        top: LayoutWrapper.getDialogTopValue(),
        left: LayoutWrapper.getDialogLeftValue(),
        right: 'auto',
        bottom: 'auto',
        transform: LayoutWrapper.getDialogTransformValue(),
    });

    saveGameStart = () => {
        this.onSaveOptClose();
        this.onClose();
        sendSavedSoloGameStart(this.props.gid);
    };

    checkSavedGameOption = () => {
        if (this.props.hasSavedGame) {
            createDialogInstance({
                title: 'Game in progress!',
                actionButtonText: 'Yes',
                onAction: this.saveGameStart,
                body: 'You have a saved game. Would you like to complete it?',
                notDismissable: true,
                isConfirmableByKey: false,
                cancelButtonText: 'No',
                onCancel: this.onSaveOptClose,
            });
        }
    };

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.checkSavedGameOption();
    }

    render = () => {
        return this.isMenuOpen() ? (
            <View style={this.getModalContentStyle()}>
                <View
                    style={[
                        LayoutUtils.getDialogMainContainerStyle(),
                        this.getModalContainerDimension(),
                        this.props.currentOpt === MenuOption.CreateGame
                            ? { boxShadow: null }
                            : undefined,
                    ]}
                >
                    {this.checkRenderOption()}
                </View>
            </View>
        ) : null;
    };

    onSoloGameDismissDialog = () => {
        this.setRenderOption(MenuOption.Init);
        this.onClose();
    };

    setGameDetails = (isRobot) => {
        eventBus.emit(GAME_SOLO_SET_FORM_TYPE, null, { isRobot: isRobot });
        this.setRenderOption(MenuOption.GameForm);
    };

    onBackButtonPress = () => {
        this.setRenderOption(MenuOption.Init);
    };

    selectCustomBoardOptions = () => {
        this.setRenderOption(MenuOption.Custom);
    };

    setRenderOption = (currentOpt = MenuOption.Init) => {
        eventBus.emit(GAME_SOLO_SET_CURRENT_MENU_OPT, null, {
            currentOpt: currentOpt,
        });
    };

    checkRenderOption = () => {
        switch (this.props.currentOpt) {
            case MenuOption.Init:
                return this.renderOptionInitial();

            case MenuOption.BoardType:
                return this.renderOptionBoardType();

            case MenuOption.GameForm:
                return (
                    <SoloGameStartForm
                        onCancel={this.onBackButtonPress}
                        onActionButton={bindFunction.bind({
                            params: MenuOption.BoardType,
                            bindRequest: this.setRenderOption,
                        })}
                    />
                );
            case MenuOption.Custom:
                return this.renderOptionCustomType();
            case MenuOption.BoardSlot:
                return (
                    <SoloGameStartForm
                        savedRules={true}
                        onActionButton={this.onSlotAction}
                        onCancel={this.selectCustomBoardOptions}
                    />
                );
            case MenuOption.CreateGame:
                return (
                    <CreateCustomGame
                        onActionButton={this.onCreateGameStartAction}
                        onCancel={
                            this.state.boardEdit
                                ? this.loadSavedRules
                                : this.selectCustomBoardOptions
                        }
                        getDialogDimension={DimensionUtils.getWindowDimensions}
                    />
                );
            default:
                throw new Error('Invalid option');
        }
    };

    renderMenuItem = (params) => (
        <TouchableOpacity
            activeOpacity={1}
            style={[
                styles.menuContainer,
                params.height,
                params.border ? styles.menuBorder : null,
            ]}
            onPress={params.onclick}
            id={params.id}
            key={String(params.id)}
        >
            <View style={[styles.rowDirection]}>
                <FontAwesomeIcon
                    icon={params.icon}
                    style={{
                        ...this.getIconStyleObj(),
                    }}
                />
                <View style={styles.gameTypeTextContainer}>
                    <S14Text>{params.title}</S14Text>
                    <PText>{params.desc}</PText>
                </View>
            </View>
        </TouchableOpacity>
    );

    renderOptionInitial = () => (
        <View style={{ flex: 1 }}>
            {[
                this.props.isOldUser
                    ? this.renderMenuItem({
                          id: 8,
                          icon: faBolt,
                          title: 'Quick Start',
                          desc: 'Re-use previous game settings',
                          height: { height: '33%', flex: 1 },
                          onclick: this.startQuickGame,
                          border: true,
                      })
                    : null,
                this.renderMenuItem({
                    id: 9,
                    icon: faUser,
                    title: 'Solitaire Mode',
                    desc: 'Play Lexulous by yourself',
                    height: {
                        height: this.props.isOldUser ? '33%' : '50%',
                        flex: 1,
                    },
                    onclick: bindFunction.bind({
                        params: false,
                        bindRequest: this.setGameDetails,
                    }),
                    border: true,
                }),
                this.renderMenuItem({
                    id: 10,
                    icon: faRobot,
                    title: 'Computer Opponent',
                    desc: 'Choose from 10 different AI skill levels',
                    height: {
                        height: this.props.isOldUser ? '33%' : '50%',
                        flex: 1,
                    },
                    onclick: bindFunction.bind({
                        params: true,
                        bindRequest: this.setGameDetails,
                    }),
                    border: false,
                }),
            ]}
        </View>
    );

    renderOptionBoardType = () => (
        <View style={{ flex: 1 }}>
            {[
                this.renderMenuItem({
                    id: 1,
                    icon: faStar,
                    title: 'Lexulous',
                    desc: 'Play on the classic board',
                    height: { height: '25%', flex: 1 },
                    onclick: bindFunction.bind({
                        params: { boardType: Config.SOLO_BOARD_TYPE_STANDARD },
                        bindRequest: this.sendGameRequest,
                    }),
                    border: true,
                }),
                this.renderMenuItem({
                    id: 2,
                    icon: faTable,
                    title: 'Super Lexulous',
                    desc: 'Try the larger 21x21 board',
                    height: { height: '25%', flex: 1 },
                    onclick: bindFunction.bind({
                        params: { boardType: Config.SOLO_BOARD_TYPE_SUPER },
                        bindRequest: this.sendGameRequest,
                    }),
                    border: true,
                }),
                DimensionUtils.isMobile()
                    ? null
                    : this.renderMenuItem({
                          id: 3,
                          icon: faPencilAlt,
                          title: 'Create Your Own Game',
                          desc: 'Your game, your rules',
                          height: { height: '25%', flex: 1 },
                          onclick: this.selectCustomBoardOptions,
                          border: true,
                      }),
                this.renderMenuItem({
                    id: 4,
                    icon: faArrowCircleLeft,
                    title: 'Back',
                    desc: 'See previous menu',
                    height: { height: '25%', flex: 1 },
                    onclick: bindFunction.bind({
                        params: this.props.isRobot,
                        bindRequest: this.setGameDetails,
                    }),
                    border: false,
                }),
            ]}
        </View>
    );

    renderOptionCustomType = () => (
        <View style={[styles.columnDirection, { flex: 1 }]}>
            {[
                this.renderMenuItem({
                    id: 4,
                    icon: faSave,
                    title: 'Load Saved Rules',
                    desc: 'Select from an existing slot',
                    height: { height: '25%', flex: 1 },
                    onclick: this.loadSavedRules,
                    border: true,
                }),
                this.renderMenuItem({
                    id: 5,
                    icon: faBars,
                    title: 'Create New Game',
                    desc: 'Frame your rules',
                    height: { height: '25%', flex: 1 },
                    onclick: this.onCreateGameAction,
                    border: true,
                }),
                this.renderMenuItem({
                    id: 6,
                    icon: faRandom,
                    title: 'Random Board',
                    desc: 'Let us pick a game for you',
                    height: { height: '25%', flex: 1 },
                    onclick: bindFunction.bind({
                        params: { boardType: Config.SOLO_BOARD_TYPE_RANDOM },
                        bindRequest: this.sendGameRequest,
                    }),
                    border: true,
                }),
                this.renderMenuItem({
                    id: 7,
                    icon: faArrowCircleLeft,
                    title: 'Back',
                    desc: 'See previous menu',
                    height: { height: '25%', flex: 1 },
                    onclick: bindFunction.bind({
                        params: MenuOption.BoardType,
                        bindRequest: this.setRenderOption,
                    }),
                    border: false,
                }),
            ]}
        </View>
    );

    onSlotAction = (slotInfo) => {
        if (slotInfo.type === Config.SOLO_SLOT_PLAY_BUTTON) {
            this.sendGameRequest({
                boardType: Config.SOLO_BOARD_TYPE_MANUAL,
                slotId: slotInfo.slotId,
            });
        } else {
            this.onCreateGameAction(slotInfo);
            editSlotGameData(slotInfo.slotId);
        }
    };

    onCreateGameAction = (slotInfo) => {
        this.setState({ boardEdit: slotInfo && slotInfo.slotId });
        eventBus.emit(GAME_INITIALISE_TILES_FOR_CREATE_BOARD);
        eventBus.emit(CELL_REDUCER_UPDATE_BOARD_STRUCTURE, null, {
            setPosType: false,
            forCreateGame: true,
        });
        eventBus.emit(DIMENSION_SCREEN_RESIZE, null, { forCreateGame: true });
        this.setRenderOption(MenuOption.CreateGame);
    };

    onCreateGameStartAction = async () => {
        this.sendGameRequest({
            boardType: Config.SOLO_BOARD_TYPE_MANUAL,
            params: {
                boarddes: this.props.createBoardDes,
                bdsqval: this.props.bdsqvalSlot,
                tilevalues: this.props.createBoardTilevalues,
                tile_count: this.props.createBoardTileCount,
            },
        });
    };

    startQuickGame = () => {
        this.onClose();
        let params = {
            action: Config.ACTION_SOLO_QUICK_GAME_START,
        };
        sendSoloGameStartData(params);
    };

    loadSavedRules = () => {
        getCustomSavedBoard(false);
        this.setRenderOption(MenuOption.BoardSlot);
    };

    sendGameRequest = (boardDetails) => {
        let params = {
            action: boardDetails.slotId
                ? Config.START_NEW_SAVED_GAME_ACTION
                : Config.START_NEW_GAME_ACTION,
            boardtype:
                boardDetails.boardType === Config.SOLO_BOARD_TYPE_SUPER
                    ? 'S'
                    : 'N',
            gametype: this.props.isRobot ? 'robot' : 'solitaire',
            robotlevel: this.props.level,
            dic: this.props.dictionary,
            timertype: this.props.time > 0 ? '1' : '0',
            timerlength: this.props.time,
            boarddetails:
                boardDetails.boardType === Config.SOLO_BOARD_TYPE_SUPER
                    ? Config.SOLO_BOARD_TYPE_STANDARD
                    : boardDetails.boardType,
            slotid: boardDetails.slotId,
            ...boardDetails.params,
        };
        sendSoloGameStartData(params);
        this.onSoloGameDismissDialog();
    };

    getIconStyleObj = () => ({
        width: 24,
        height: 24,
        color: ColorConfig.BUTTON_TEXT_COLOR,
    });
}

const styles = StyleSheet.create({
    //Main Renders Styles
    modalContent: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
    },
    itemCenter: {
        alignItems: 'center',
    },
    rowDirection: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    maxHeightHundred: {
        maxHeight: '100%',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    columnDirection: {
        flexDirection: 'column',
        padding: 0,
        margin: 0,
    },
    menuContainer: {
        justifyContent: 'center',
        paddingLeft: 32,
    },
    menuBorder: {
        borderColor: ColorConfig.OBSERVABLE_GAMES_LIST_BACKGROUND_COLOR,
        borderBottomWidth: 1,
    },
    gameTypeTextContainer: {
        marginLeft: 8,
    },
    closeButtonContainer: {
        flex: 1,
        alignItems: 'flex-end',
        marginLeft: 24,
    },
    bodyContainer: {
        paddingLeft: 32,
        paddingRight: 32,
        paddingBottom: 32,
    },
    slotRow: {
        flexDirection: 'row',
        marginBottom: 4,
    },
    slotActionContainer: {
        flex: 1,
        alignSelf: 'flex-end',
        alignItems: 'flex-end',
    },
});

const mapStateToProps = (state) => ({
    menuOpt: state.solitaire.menuOpt,
    currentOpt: state.solitaire.currentOpt,
    hasSavedGame: state.solitaire.hasSavedGame,
    gid: state.solitaire.gid,
    isOldUser: state.solitaire.isOldUser,
    isRobot: state.solitaire.isRobot,
    dictionary: state.solitaire.dictionary,
    level: state.solitaire.level,
    time: state.solitaire.time,
    slotData: state.solitaire.slotData,
    bdsqvalSlot: state.solitaire.bdsqvalSlot,
    createBoardDes: state.solitaire.createBoardDes,
    createBoardTilevalues: state.solitaire.createBoardTilevalues,
    createBoardTileCount: state.solitaire.createBoardTileCount,
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    SoloGameOptionsModal
);
