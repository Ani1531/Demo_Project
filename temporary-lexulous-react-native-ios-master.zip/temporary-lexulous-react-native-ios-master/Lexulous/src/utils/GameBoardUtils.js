import get from 'lodash/get';
import uniq from 'lodash/uniq';
import isNumber from 'lodash/isNumber';
import isEmpty from 'lodash/isEmpty';
import zip from 'lodash/zip';
import cloneDeep from 'lodash/cloneDeep';
import { getGameFeed, getGameType, getPossibleMoves, isPuzzleGame, isSoloGame, sendPlayMove } from '../service/GamePlayService';
import { createDialogInstance, createGeneralRequestFailureDialog } from './MessageUtils';
import to from 'await-to-js';
import StringUtils, { generateUUID } from './StringUtils';
import Config from '../configs/Config';
import ColorConfig, { BoardTheme, TileTheme } from '../configs/ColorConfig';
import SoundUtils from './SoundUtils';
import { openPurchaseProPage, spawnWindow } from './UrlUtils';
import {
    GAME_ANALYSE_DATA_READY,
    GAME_MOVE_COUNT_SET,
    GAME_SET_PLAYER_SELF_CURRENT_SCORE,
    GAME_SHOW_PLAY_BUTTON_LOADER,
    LAYOUT_REDUCER_SET_FIELD,
    LAYOUT_SET_BOARD_ABOVE_VIEWS_HEIGHT,
} from '../configs/ActionIdentifiers';
import ConfigurationWrapper from './ConfigurationWrapper';
import store from '../store';
import log from 'loglevel';
import { printBoard } from '../reducers/CellReducer';
import DimensionUtils from './DimensionUtils';
import { lastArrayElement } from './Utils';

const eventBus = require('js-event-bus')();

export default class GameBoardUtils {
    static ENGLISH_LETTER_SCORES =
        'A,1|B,4|C,4|D,2|E,1|F,5|G,2|H,5|I,1|J,8|K,6|L,1|M,4|N,1|O,1|P,4|Q,12|R,1|S,1|T,2|U,1|V,5|W,5|X,8|Y,5|Z,12|a,0|b,0|c,0|d,0|e,0|f,0|g,0|h,0|i,0|j,0|k,0|l,0|m,0|n,0|o,0|p,0|q,0|r,0|s,0|t,0|u,0|v,0|w,0|x,0|y,0|z,0';
    static FRENCH_LETTER_SCORES =
        'A,1|B,4|C,4|D,2|E,1|F,5|G,2|H,5|I,1|J,10|K,12|L,1|M,2|N,1|O,1|P,3|Q,8|R,1|S,1|T,1|U,1|V,5|W,12|X,12|Y,12|Z,12|a,0|b,0|c,0|d,0|e,0|f,0|g,0|h,0|i,0|j,0|k,0|l,0|m,0|n,0|o,0|p,0|q,0|r,0|s,0|t,0|u,0|v,0|w,0|x,0|y,0|z,0';
    static ITALIAN_LETTER_SCORES =
        'A,1|B,4|C,4|D,2|E,1|F,5|G,2|H,5|I,1|J,10|K,6|L,1|M,4|N,1|O,1|P,4|Q,12|R,1|S,1|T,2|U,1|V,5|W,5|X,10|Y,5|Z,12|a,0|b,0|c,0|d,0|e,0|f,0|g,0|h,0|i,0|j,0|k,0|l,0|m,0|n,0|o,0|p,0|q,0|r,0|s,0|t,0|u,0|v,0|w,0|x,0|y,0|z,0';

    static InitialTilesUSUK = 'AAAAAAAABBCCDDDEEEEEEEEEEEFFGGHHIIIIIIIIJKLLLMMNNNNNOOOOOOOPPQRRRRRSSSTTTTTUUUVVWWXYYYZ**';
    static InitialTilesFr =
        'AAAAAAAAABBCCDDDEEEEEEEEEEEEEEEFFGGHHIIIIIIIIJKLLLLLMMMNNNNNNOOOOOOPPQRRRRRRSSSSSSTTTTTTUUUUUUVVWXYZ**';
    static InitialTilesIt =
        'AAAAAAAAAAAAAABBBCCCCCCDDDEEEEEEEEEEEFFFGGHHIIIIIIIIIIIILLLLLMMMMMNNNNNOOOOOOOOOOOOOOOPPPQRRRRRRSSSSSSTTTTTTUUUUUVVVZZ**';
    static InitialTilesSuperUSUKFrIt =
        'AAAAAAAAAAAAAABBBBCCCCCCDDDDDDEEEEEEEEEEEEEEEEEEEEEEFFFFGGGHHHHHIIIIIIIIIIIIJJKKLLLLLMMMMMMNNNNNNNNNNOOOOOOOOOOOOOOPPPPQQRRRRRRRRRRSSSSSSSSTTTTTTTTTTTTUUUUUUVVVWWWWXXYYYYYYZZ****';

    static preSetBoardDes =
        'WWWGWWWWWWWGWWWWWRWWWBWBWWWRWWWRWWWLWWWLWWWRWGWWWPWWWWWPWWWGWWWPWWWWWWWPWWWWWLWWWLWLWWWLWWWBWWWLWWWLWWWBWWWWWWWWWWWWWWWWWBWWWLWWWLWWWBWWWLWWWLWLWWWLWWWWWPWWWWWWWPWWWGWWWPWWWWWPWWWGWRWWWLWWWLWWWRWWWRWWWBWBWWWRWWWWWGWWWWWWWGWWW';
    static SCRABLE_TILE_COUNT_DEF = [9, 2, 2, 4, 12, 2, 3, 2, 9, 1, 1, 4, 2, 6, 8, 2, 1, 6, 4, 6, 4, 2, 2, 1, 2, 1, 2];
    static SCRABLE_TILE_SCORE_DEF = [
        1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ];
    static TOTAL_TILE_COUNT = 89;
    static MAX_TILE_VALUE = 12;

    static setGameBoardInfo = (messageObj) => {
        if (get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.boarddes')) {
            let board_size = get(store.getState(), 'game.board_size');
            let boarddes = get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.boarddes.boarddes'),
                bdsqval = get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.boarddes.bdsqval'),
                tile_count = get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.boarddes.tile_count');

            let customBoardInfo = [];
            bdsqval.split('|').forEach((val) => {
                let valInfoArr = val.split(',');
                if (valInfoArr[0] !== 'W') {
                    let pos = [];
                    for (let i = 0; i < boarddes.length; i++) {
                        if (boarddes[i] === valInfoArr[0]) {
                            let x = i % board_size;
                            let y = Math.floor(i / board_size);
                            pos.push([x, y]);
                        }
                    }
                    customBoardInfo.push({
                        type: valInfoArr[1],
                        positions: pos,
                    });
                }
            });

            let tileCountInfo = '';
            tile_count.split('|').forEach((tileInfo) => {
                let tileInfoArr = tileInfo.split(',');
                tileCountInfo += (tileInfoArr[0] === 'blank' ? '*' : tileInfoArr[0]).repeat(tileInfoArr[1]);
            });
        }
    };

    static initGameBoard = (dimenY, dimenX, setPosType = true) => {
        let gameboard = [];
        for (let i = 0; i < dimenY; i++) {
            let row = [];
            for (let j = 0; j < dimenX; j++) {
                row.push({
                    tileX: j,
                    tileY: i,
                    positionType: setPosType ? GameBoardUtils.getPositionType(dimenX, dimenY, j, i) : '',
                });
            }
            gameboard.push(row);
        }
        return gameboard;
    };

    static getPositionType = (dimenX, dimenY, tileX, tileY) => {
        let boardType = GameBoardUtils.getSpecialPostions(dimenX, dimenY);
        for (let i = 0; i < boardType.length; i++) {
            let { type, positions } = boardType[i];
            for (let j = 0; j < positions.length; j++) {
                let position = positions[j];
                if (position[0] === tileX && position[1] === tileY) return type;
            }
        }
        return '';
    };

    static getSpecialPostions = (dimenX) => {
        let globalState = store.getState();
        if (!!get(globalState, 'game.customBoardInfo')) {
            return get(globalState, 'game.customBoardInfo');
        }
        switch (dimenX) {
            case Config.CLASSIC_BOARD_SIZE_FIFTEEN:
                return Config.FITFEEN_BY_FIFTEEN_BOARD;
            case Config.SUPER_BOARD_SIZE_TWENTYONE:
                return Config.TWENTYONE_BY_TWENTYONE_BOARD;
        }
    };

    static isBoardEmpty = (gameBoardFlatOrGameBoard) => !gameBoardFlatOrGameBoard.flat(8).some((cell) => get(cell, 'locked'));

    static isSomeNeighbourLocked = (x, y, gameBoardFlatOrGameBoard) => {
        gameBoardFlatOrGameBoard = (gameBoardFlatOrGameBoard || []).flat(8);
        if (x > 0) {
            let cellToTheLeft = (gameBoardFlatOrGameBoard || []).find(
                (cell) => get(cell, 'tileX') === x - 1 && get(cell, 'tileY') === y
            );
            if (get(cellToTheLeft, 'locked')) return true;
        }
        if (x < (gameBoardFlatOrGameBoard || []).length - 1) {
            let cellToTheRight = (gameBoardFlatOrGameBoard || []).find(
                (cell) => get(cell, 'tileX') === x + 1 && get(cell, 'tileY') === y
            );
            if (get(cellToTheRight, 'locked')) return true;
        }
        if (y > 0) {
            let cellAbove = (gameBoardFlatOrGameBoard || []).find(
                (cell) => get(cell, 'tileX') === x && get(cell, 'tileY') === y - 1
            );
            if (get(cellAbove, 'locked')) return true;
        }
        if (y < (gameBoardFlatOrGameBoard || []).length - 1) {
            let cellBelow = (gameBoardFlatOrGameBoard || []).find(
                (cell) => get(cell, 'tileX') === x && get(cell, 'tileY') === y + 1
            );
            if (get(cellBelow, 'locked')) return true;
        }
    };

    static validateAndSendMove = async ({ gameBoard, tiles, refs, preconfirm, forWordList } = {}) => {
        let tempTilesArrCopy = tiles;
        let playedTiles = null;
        let playedTilesCells = null;
        let gameBoardFlat = null;

        gameBoard = gameBoard || zip(...get(store.getState(), 'cells.cells'));

        printBoard(gameBoard);

        if (tempTilesArrCopy) {
            playedTiles = uniq(
                tempTilesArrCopy.filter((tile) => tile.position),
                'id'
            );
        }

        if (gameBoard) {
            gameBoardFlat = gameBoard.flat(8);
            playedTilesCells = gameBoardFlat.filter((cell) => cell.currentTile && !cell.locked);
            if (!forWordList)
                playedTiles = uniq(
                    playedTilesCells.map((cell) => cell.currentTile),
                    'id'
                );
        }

        let isValid = playedTiles.length > 0;
        if (!isValid) {
            return; //"No Tiles Played";
        }
        let constantCoordinate = 'x';
        let playedTilesCellsConstantCordinatePosition = get(playedTilesCells, '0.tileX');
        let constantCoordinatePosition = isNumber(playedTilesCellsConstantCordinatePosition)
            ? playedTilesCellsConstantCordinatePosition
            : get(playedTiles, '0.position.x');
        for (let i = 1; isValid && i < playedTiles.length; i++) {
            if (i === 1) {
                let playedTilesCellsArrayFirstItemXCoordinate = get(playedTilesCells, '0.tileX');
                let arrayFirstItemXCoordinate = isNumber(playedTilesCellsArrayFirstItemXCoordinate)
                    ? playedTilesCellsArrayFirstItemXCoordinate
                    : get(playedTiles, '0.position.x');
                let playedTilesCellsArrayFirstItemYCoordinate = get(playedTilesCells, '0.tileY');
                let arrayFirstItemYCoordinate = isNumber(playedTilesCellsArrayFirstItemYCoordinate)
                    ? playedTilesCellsArrayFirstItemYCoordinate
                    : get(playedTiles, '0.position.y');

                let playedTilesCellsArraySecondItemXCoordinate = get(playedTilesCells, '1.tileX');
                let arraySecondItemXCoordinate = isNumber(playedTilesCellsArraySecondItemXCoordinate)
                    ? playedTilesCellsArraySecondItemXCoordinate
                    : get(playedTiles, '1.position.x');
                let playedTilesCellsArraySecondItemYCoordinate = get(playedTilesCells, '1.tileY');
                let arraySecondItemYCoordinate = isNumber(playedTilesCellsArraySecondItemYCoordinate)
                    ? playedTilesCellsArraySecondItemYCoordinate
                    : get(playedTiles, '1.position.y');

                constantCoordinate =
                    arrayFirstItemXCoordinate === arraySecondItemXCoordinate
                        ? 'x'
                        : arrayFirstItemYCoordinate === arraySecondItemYCoordinate
                        ? 'y'
                        : null;
                if (constantCoordinate) {
                    let playedTilesCellsConstantCoordinatePosition = get(
                        playedTilesCells,
                        '0.tile' + constantCoordinate.toUpperCase()
                    );
                    constantCoordinatePosition = isNumber(playedTilesCellsConstantCoordinatePosition)
                        ? playedTilesCellsConstantCoordinatePosition
                        : get(playedTiles, '0.position.' + constantCoordinate);
                }
            }
            if (constantCoordinate && !isNaN(constantCoordinatePosition)) {
                let playedTilesCellsQueryString = i + '.tile' + constantCoordinate.toUpperCase();
                let playedTilesQueryString = i + '.position.' + constantCoordinate;

                let playedTilesCellsConstantCoordinatePosition = get(playedTilesCells, playedTilesCellsQueryString);
                let playedTilesConstantCoordinatePosition = isNumber(playedTilesCellsConstantCoordinatePosition)
                    ? playedTilesCellsConstantCoordinatePosition
                    : get(playedTiles, playedTilesQueryString);
                isValid =
                    playedTilesCellsConstantCoordinatePosition === constantCoordinatePosition ||
                    playedTilesConstantCoordinatePosition === constantCoordinatePosition;
            } else {
                isValid = false;
                break;
            }
        }

        if (!isValid) {
            return 'Tiles played must be in a single row or column.';
        }

        let varyingCoordinate = constantCoordinate === 'x' ? 'y' : 'x';

        playedTiles = (playedTiles || []).sort(
            (tile1, tile2) => get(tile1, 'position.' + varyingCoordinate) - get(tile2, 'position.' + varyingCoordinate)
        );

        playedTilesCells = (playedTilesCells || []).sort(
            (cell1, cell2) =>
                get(cell1, 'tile' + varyingCoordinate.toUpperCase()) - get(cell2, 'tile' + varyingCoordinate.toUpperCase())
        );

        let startIndexOnPlayedTilesCells = get(playedTilesCells, '0.tile' + varyingCoordinate.toUpperCase());
        let wordStartIndex =
            typeof startIndexOnPlayedTilesCells !== 'undefined'
                ? startIndexOnPlayedTilesCells
                : get(playedTiles, '0.position.' + varyingCoordinate);

        let wordEndIndex =
            get(lastArrayElement(playedTilesCells || []), 'tile' + varyingCoordinate.toUpperCase()) ||
            get(lastArrayElement(playedTiles || []), 'position.' + varyingCoordinate);

        for (let i = wordStartIndex; isValid && i <= wordEndIndex; i++) {
            let currentCell = (gameBoardFlat || []).find(
                (cell) =>
                    cell.tileX === (constantCoordinate === 'x' ? constantCoordinatePosition : i) &&
                    cell.tileY === (constantCoordinate === 'x' ? i : constantCoordinatePosition)
            );
            if (!currentCell)
                currentCell = get(
                    gameBoard,
                    (constantCoordinate === 'x' ? i : constantCoordinatePosition) +
                        '.' +
                        (constantCoordinate === 'x' ? constantCoordinatePosition : i)
                );

            isValid =
                !!currentCell.currentTile ||
                (forWordList &&
                    tiles.some(
                        (tile) =>
                            get(tile, 'position.x') === (constantCoordinate === 'x' ? constantCoordinatePosition : i) &&
                            get(tile, 'position.y') === (constantCoordinate === 'x' ? i : constantCoordinatePosition)
                    ));
        }

        if (!isValid) {
            return 'Tiles must be played next to each other without gaps';
        }

        let words = [];
        let wordsCells = [];
        if (GameBoardUtils.isBoardEmpty(gameBoard)) {
            let word = '';
            let wordCells = [];

            for (let i = wordStartIndex; isValid && i <= wordEndIndex; i++) {
                let currentCell =
                    (gameBoardFlat || []).find(
                        (cell) =>
                            cell.tileX === (constantCoordinate === 'x' ? constantCoordinatePosition : i) &&
                            cell.tileY === (constantCoordinate === 'x' ? i : constantCoordinatePosition)
                    ) ||
                    get(
                        gameBoard,
                        (constantCoordinate === 'x' ? i : constantCoordinatePosition) +
                            '.' +
                            (constantCoordinate === 'x' ? constantCoordinatePosition : i)
                    );
                if (currentCell && currentCell.currentTile) {
                    word = word + '' + (currentCell.currentTile.currentLetter || currentCell.currentTile.letter || '*');
                    wordCells.push(currentCell);
                } else if (forWordList) {
                    let tile = playedTiles.find(
                        (tile) =>
                            tile.position.x === (constantCoordinate === 'x' ? constantCoordinatePosition : i) &&
                            tile.position.y === (constantCoordinate === 'x' ? i : constantCoordinatePosition)
                    );
                    if (tile) {
                        word = word + '' + (tile.currentLetter || tile.letter || '*');
                    }
                }
            }

            words.push(word);
            wordsCells.push(wordCells);

            let centerCord = Math.ceil(gameBoard.length / 2) - 1;
            isValid =
                playedTilesCells.some((cell) => get(cell, 'tileX') === centerCord && get(cell, 'tileY') === centerCord) ||
                playedTiles.some((tile) => get(tile, 'position.x') === centerCord && get(tile, 'position.y') === centerCord);
            if (!isValid) {
                return 'At least one tile must cover the centre square';
            }
        } else {
            isValid = false;
            if (playedTilesCells && playedTilesCells.length > 0) {
                for (let i = 0; i < playedTilesCells.length; i++) {
                    let playedTileCell = playedTilesCells[i];
                    let playedTileXCoord = get(playedTileCell, 'tileX');
                    let playedTileYCoord = get(playedTileCell, 'tileY');
                    if (GameBoardUtils.isSomeNeighbourLocked(playedTileXCoord, playedTileYCoord, gameBoard)) {
                        isValid = true;
                        break;
                    }
                }
            } else if (playedTiles.length > 0) {
                for (let i = 0; i < playedTiles.length; i++) {
                    let playedTile = playedTiles[i];
                    let playedTileXCoord = get(playedTile, 'position.x');
                    let playedTileYCoord = get(playedTile, 'position.y');
                    if (GameBoardUtils.isSomeNeighbourLocked(playedTileXCoord, playedTileYCoord, gameBoard)) {
                        isValid = true;
                        break;
                    }
                }
            }
            if (!isValid) {
                return 'Tiles you play must touch at least one tile already played';
            }

            //First check with the neighbours in the varying coordinate
            for (let i = 0; i < (!isEmpty(playedTilesCells) ? playedTilesCells : playedTiles).length; i++) {
                let playedTilesCellsMinVaryingCoordinatePosition = get(
                    playedTilesCells,
                    i + '.tile' + varyingCoordinate.toUpperCase()
                );
                let minVaryingCoordinatePosition = isNumber(playedTilesCellsMinVaryingCoordinatePosition)
                    ? playedTilesCellsMinVaryingCoordinatePosition
                    : get(playedTiles, i + '.position.' + varyingCoordinate);
                let playedTilesSubWordBeginingPosition = get(playedTilesCells, i + '.tile' + constantCoordinate.toUpperCase());

                let subWordBeginningPosition = isNumber(playedTilesSubWordBeginingPosition)
                    ? playedTilesSubWordBeginingPosition
                    : get(playedTiles, i + '.position.' + constantCoordinate);

                log.info('in GameBoardUtils, finding subWordBeginningPosition, initially it is: ' + subWordBeginningPosition);

                for (let j = subWordBeginningPosition - 1; j >= 0; j--) {
                    let xCoord = constantCoordinate === 'x' ? j : minVaryingCoordinatePosition;
                    let yCoord = constantCoordinate === 'x' ? minVaryingCoordinatePosition : j;

                    let cell =
                        (gameBoardFlat || []).find((cell) => cell.tileX === xCoord && cell.tileY === yCoord) ||
                        gameBoard[yCoord][xCoord];

                    log.info(
                        'in GameBoardUtils, finding subWordBeginningPosition, checking cell:\n' + JSON.stringify(cell, null, 2)
                    );

                    if (!!cell.currentTile) {
                        subWordBeginningPosition = j;
                    } else {
                        break;
                    }
                }

                log.info('in GameBoardUtils, finding subWordBeginningPosition, finally is: ' + subWordBeginningPosition);

                let playedTilesCellsSubWordEndingPosition = get(
                    playedTilesCells,
                    i + '.tile' + constantCoordinate.toUpperCase()
                );

                let subWordEndingPosition = isNumber(playedTilesCellsSubWordEndingPosition)
                    ? playedTilesCellsSubWordEndingPosition
                    : playedTiles[i].position[constantCoordinate];

                log.info(
                    'in GameBoardUtils, finding subWordEndingPosition, subWordEndingPosition initially is: ' +
                        subWordEndingPosition
                );

                for (let j = subWordEndingPosition + 1; j < gameBoard.length; j++) {
                    let xCoord = constantCoordinate === 'x' ? j : minVaryingCoordinatePosition;
                    let yCoord = constantCoordinate === 'x' ? minVaryingCoordinatePosition : j;

                    let cell =
                        (gameBoardFlat || []).find((cell) => cell.tileX === xCoord && cell.tileY === yCoord) ||
                        gameBoard[yCoord][xCoord];

                    log.info(
                        'in GameBoardUtils, finding subWordEndingPosition, checking cell:\n' + JSON.stringify(cell, null, 2)
                    );

                    if (cell.currentTile) {
                        subWordEndingPosition = j;
                    } else {
                        break;
                    }
                }

                log.info(
                    'in GameBoardUtils, finding subWordEndingPosition, subWordEndingPosition finally is: ' +
                        subWordEndingPosition
                );

                if (subWordBeginningPosition !== subWordEndingPosition) {
                    let word = '';
                    let wordCells = [];
                    for (let j = subWordBeginningPosition; j <= subWordEndingPosition; j++) {
                        let letter = undefined;

                        let cell =
                            (gameBoardFlat || []).find(
                                (cell) =>
                                    cell.tileX === (constantCoordinate === 'x' ? j : minVaryingCoordinatePosition) &&
                                    cell.tileY === (constantCoordinate === 'x' ? minVaryingCoordinatePosition : j)
                            ) ||
                            gameBoard[constantCoordinate === 'x' ? minVaryingCoordinatePosition : j][
                                constantCoordinate === 'x' ? j : minVaryingCoordinatePosition
                            ];

                        if (cell && cell.currentTile) {
                            letter = cell.currentTile.currentLetter || cell.currentTile.letter || '*';
                            wordCells.push(cell);
                        }

                        if (forWordList && !letter) {
                            log.info(
                                'in GameBoardUtils, finding subWord, playedTiles is:\n' + JSON.stringify(playedTiles, null, 2)
                            );

                            let xCoord = constantCoordinate === 'x' ? j : minVaryingCoordinatePosition;
                            let yCoord = constantCoordinate === 'x' ? minVaryingCoordinatePosition : j;
                            let position = { x: xCoord, y: yCoord };

                            log.info(
                                'in GameBoardUtils, finding subWord, checking position:\n' + JSON.stringify(position, null, 2)
                            );

                            let tile = playedTiles.find((tile) => tile.position.x === xCoord && tile.position.y === yCoord);

                            if (tile) {
                                letter = tile.currentLetter || tile.letter || '*';
                            }
                        }

                        if (letter) word = word + letter;
                    }

                    words.push(word);
                    wordsCells.push(wordCells);
                }
            }

            //Then check in the same coordinate
            {
                log.info(`in GameBoardUtils, finding mainWordBeginningPosition, constantCoordinate is ${constantCoordinate}`);

                let playedTilesCellsMinConstantCoordinatePosition = get(
                    playedTilesCells,
                    '0.tile' + constantCoordinate.toUpperCase()
                );

                log.info(
                    `in GameBoardUtils, finding mainWordBeginningPosition, playedTilesCellsMinConstantCoordinatePosition is ${playedTilesCellsMinConstantCoordinatePosition}`
                );

                let playedTilesMinConstantCoordinatePosition = get(playedTiles, '0.position.' + constantCoordinate);

                log.info(
                    `in GameBoardUtils, finding mainWordBeginningPosition, playedTilesMinConstantCoordinatePosition is ${playedTilesMinConstantCoordinatePosition}`
                );

                let minConstantCoordinatePosition = isNumber(playedTilesCellsMinConstantCoordinatePosition)
                    ? playedTilesCellsMinConstantCoordinatePosition
                    : playedTilesMinConstantCoordinatePosition;

                let queryString = '0.position.' + varyingCoordinate;

                let playedTilesMainWordBeginningPosition = get(playedTiles, queryString);

                let playedTilesCellsMainWordBeginningPosition = get(
                    playedTilesCells,
                    '0.tile' + varyingCoordinate.toUpperCase()
                );

                let mainWordBeginningPosition = isNumber(playedTilesCellsMainWordBeginningPosition)
                    ? playedTilesCellsMainWordBeginningPosition
                    : playedTilesMainWordBeginningPosition;

                log.info(
                    `in GameBoardUtils, finding mainWordBeginningPosition, mainWordBeginningPosition is ${mainWordBeginningPosition}`
                );

                for (let j = mainWordBeginningPosition - 1; j >= 0; j--) {
                    let xCoord = constantCoordinate === 'x' ? minConstantCoordinatePosition : j;
                    let yCoord = constantCoordinate === 'x' ? j : minConstantCoordinatePosition;

                    log.info(`in GameBoardUtils, finding mainWordBeginningPosition, xCoors is ${xCoord}, yCoord is ${yCoord}`);

                    let cell =
                        (gameBoardFlat || []).find(
                            (cell) => cell && get(cell, 'tileX') === xCoord && get(cell, 'tileY') === yCoord
                        ) || get(gameBoard, `${yCoord}.${xCoord}`);
                    if (cell.currentTile) {
                        mainWordBeginningPosition = j;
                    } else {
                        break;
                    }
                }

                let playedTileCellsLast = lastArrayElement(playedTilesCells || []);
                let playedTileCellsQueryString = 'tile' + varyingCoordinate.toUpperCase();
                let playedTileCellsLastMainWordEndingPosition = get(playedTileCellsLast, playedTileCellsQueryString);
                let mainWordEndingPosition = isNumber(playedTileCellsLastMainWordEndingPosition)
                    ? playedTileCellsLastMainWordEndingPosition
                    : lastArrayElement(playedTiles).position[varyingCoordinate];

                for (let j = mainWordEndingPosition + 1; j < gameBoard.length; j++) {
                    let cell =
                        (gameBoardFlat || []).find(
                            (cell) =>
                                cell.tileX === (constantCoordinate === 'x' ? minConstantCoordinatePosition : j) &&
                                cell.tileY === (constantCoordinate === 'x' ? j : minConstantCoordinatePosition)
                        ) ||
                        gameBoard[constantCoordinate === 'x' ? j : minConstantCoordinatePosition][
                            constantCoordinate === 'x' ? minConstantCoordinatePosition : j
                        ];
                    log.info(`in GameBoardUtils, finding mainWordEndingPosition, cell is ${JSON.stringify(cell, null, 2)}`);
                    if (cell.currentTile) {
                        mainWordEndingPosition = j;
                    } else {
                        break;
                    }
                }
                log.info(
                    `in GameBoardUtils, finding mainWordEndingPosition, mainWordEndingPosition is ${mainWordEndingPosition}`
                );

                if (mainWordBeginningPosition !== mainWordEndingPosition) {
                    let word = '';
                    let wordCells = [];

                    for (let j = mainWordBeginningPosition; j <= mainWordEndingPosition; j++) {
                        let x = constantCoordinate === 'x' ? minConstantCoordinatePosition : j;
                        let y = constantCoordinate === 'x' ? j : minConstantCoordinatePosition;

                        let cell =
                            (gameBoardFlat || []).find((cell) => cell.tileX === x && cell.tileY === y) || gameBoard[y][x];

                        if (cell && cell.currentTile) {
                            word = word + '' + (cell.currentTile.currentLetter || cell.currentTile.letter || '*');
                            wordCells.push(cell);
                        } else if (forWordList) {
                            let tile = playedTiles.find(
                                (tileInArr) =>
                                    tileInArr.position.x === (constantCoordinate === 'x' ? minConstantCoordinatePosition : j) &&
                                    tileInArr.position.y === (constantCoordinate === 'x' ? j : minConstantCoordinatePosition)
                            );

                            if (tile) {
                                word = word + '' + (tile.currentLetter || tile.letter || '*');
                            }
                        }
                    }

                    words.push(word);
                    wordsCells.push(wordCells);
                }
            }
        }

        let score = GameBoardUtils.getTempScore(wordsCells, playedTiles);
        let tileX = undefined;
        let tileY = undefined;

        if (refs) {
            let guid = ConfigurationWrapper.getSpecificLexulousGameConfiguration('guid');
            let uuid = ConfigurationWrapper.getSpecificLexulousGameConfiguration('uuid');

            if (isPuzzleGame() && (!guid || guid.length == 0) && (!uuid || uuid.length == 0)) {
                createDialogInstance({
                    title: Config.DIALOG_HEADER_TEXT,
                    actionButtonText: 'SIGN IN',
                    onAction: () => spawnWindow(ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('site_domain')),
                    body: 'Please sign in to play a move',
                    hideCancel: true,
                    isConfirmableByKey: true,
                });
                eventBus.emit(GAME_SHOW_PLAY_BUTTON_LOADER, null, null);
                return;
            }

            preconfirm && (await preconfirm(words, score));

            let res = await to(sendPlayMove(playedTilesCells || playedTiles));
            if (res[0]) {
                createDialogInstance({
                    title: Config.DIALOG_HEADER_TEXT,
                    actionButtonText: 'OK',
                    onAction: () => null,
                    body: res[0].message,
                    hideCancel: true,
                    isConfirmableByKey: true,
                });
                eventBus.emit(GAME_SHOW_PLAY_BUTTON_LOADER, null, null);
                SoundUtils.invalidWord();
                throw res[0];
            } else {
                GameBoardUtils.playSendMoveSound(playedTiles.length);
                varyingCoordinate = undefined;
                /*for (let i = 0; i < playedTiles.length; i++) {
                    log.info(
                        "in GameBoardUtils.validateAndSendMove, playedTiles is:\n"
                        + JSON.stringify(playedTiles, null, 2)
                    );
                    let tile = playedTiles[i];
                    // let cell = ((gameBoard[tile.position.y])[tile.position.x]);
                    // cell.currentTile = tile;
                    // cell.locked = true;
                    refs(tile);
                    tempTilesArrCopy = tempTilesArrCopy.filter(tileInArr => tileInArr.id !== tile.id);
                }*/
            }
        } else {
            if (playedTiles.length > 1) {
                let startI =
                    get(lastArrayElement(playedTilesCells || []), 'tile' + varyingCoordinate.toUpperCase()) ||
                    get(lastArrayElement(playedTiles || []), 'position' + varyingCoordinate);
                for (let i = startI + 1; i < gameBoard.length; i++) {
                    let cell =
                        (gameBoardFlat || []).find(
                            (cell) =>
                                cell.tileX === (constantCoordinate === 'x' ? constantCoordinatePosition : i) &&
                                cell.tileY === (constantCoordinate === 'x' ? i : constantCoordinatePosition)
                        ) ||
                        gameBoard[constantCoordinate === 'x' ? i : constantCoordinatePosition][
                            constantCoordinate === 'x' ? constantCoordinatePosition : i
                        ];
                    if (!cell.currentTile) {
                        tileX = varyingCoordinate === 'x' ? i : constantCoordinatePosition;
                        tileY = varyingCoordinate === 'y' ? i : constantCoordinatePosition;
                        break;
                    }
                }
            }
        }

        let outputs = '+' + score;

        return {
            words,
            playedTiles,
            tiles: GameBoardUtils.shuffleTilesCopy(tempTilesArrCopy),
            outputs,
            noDragParams: {
                direction: varyingCoordinate,
                tileX,
                tileY,
            },
        };
    };

    static playSendMoveSound = (moveCount) => {
        let soundFunc = SoundUtils.userSubmits;
        if (moveCount >= Config.BINGO_TILES_COUNT) soundFunc = SoundUtils.bingoSound;

        let already_attempted = get(store.getState(), 'game.already_attempted');
        if (!already_attempted && [Config.GAME_TYPE_PUZZLE].includes(getGameType())) soundFunc();
        else if (
            [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL, Config.GAME_TYPE_SOLO].includes(
                getGameType()
            )
        ) {
            soundFunc();
        }
    };

    static shuffleTilesCopy = (orgTiles) => {
        let array = cloneDeep(orgTiles);

        let isSomeTilePlaced = array.some((tile) => !!tile.position);

        let notBeShuffeddPart, canBeShuffedPart;

        if (isSomeTilePlaced) {
            notBeShuffeddPart = array.filter((tile) => tile.isEmptySpace || tile.position);
            canBeShuffedPart = array.filter((tile) => !tile.isEmptySpace && !tile.position);
        } else {
            let index = array.findIndex((tile) => tile.isEmptySpace || tile.position);
            notBeShuffeddPart = array.slice(index, array.length);
            canBeShuffedPart = array.slice(0, index);
        }

        let currentIndex = canBeShuffedPart.length;
        let temporaryValue;
        let randomIndex;
        while (0 !== currentIndex) {
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;
            temporaryValue = canBeShuffedPart[currentIndex];
            canBeShuffedPart[currentIndex] = canBeShuffedPart[randomIndex];
            canBeShuffedPart[randomIndex] = temporaryValue;
        }

        let finalArr = canBeShuffedPart.concat(notBeShuffeddPart);

        return finalArr;
    };

    static getTempScore = (wordsCells, playedTiles) => {
        //init total score of all words in move
        let totalScore = 0;

        //iterates through words
        for (let i = 0; i < wordsCells.length; i++) {
            // score
            let current_word_score = 0;

            //total score multiplier
            let total_score_multiplier = 1;

            for (let j = 0; j < wordsCells[i].length; j++) {
                let basicTileScore = GameBoardUtils.getTileBasicScore(wordsCells[i][j].currentTile);
                let positionType = wordsCells[i][j].positionType;
                let locked = !!wordsCells[i][j].locked;
                if (positionType && positionType.charAt(1).valueOf() === 'W' && !locked) {
                    total_score_multiplier *= parseInt(positionType.charAt(0));
                    current_word_score += basicTileScore;
                } else if (positionType && positionType.charAt(1).valueOf() === 'L' && !locked) {
                    current_word_score += basicTileScore * parseInt(positionType.charAt(0));
                } else {
                    current_word_score += basicTileScore;
                }
            }

            current_word_score *= total_score_multiplier;
            totalScore += current_word_score;
        }

        //bonus score for 7 and 8 letters placed (words made)
        if (playedTiles.length === 7) {
            totalScore += 40;
        } else if (playedTiles.length === 8) {
            totalScore += 50;
        }

        return totalScore;
    };

    static getTileBasicScore = (tile) => {
        if (tile['isBlankTile'] || tile.letter === '*') {
            return 0;
        }

        let str = '';
        let dic = get(store.getState(), 'game.dic');

        switch (getDictionaryDetails(dic).lang) {
            case 'us_en':
            case 'uk_en':
                str = get(store.getState(), 'game.letterScoreInfo', GameBoardUtils.ENGLISH_LETTER_SCORES);
                break;
            case 'fr':
                str = get(store.getState(), 'game.letterScoreInfo', GameBoardUtils.FRENCH_LETTER_SCORES);
                break;
            case 'it':
                str = get(store.getState(), 'game.letterScoreInfo', GameBoardUtils.ITALIAN_LETTER_SCORES);
                break;
            default:
                throw new Error('Invalid Dictionary Code');
        }

        let scoreText = '';

        for (let i = str.indexOf(tile.letter) + 2; i < str.length && GameBoardUtils.is_numeric(str.charAt(i)); i++) {
            let charAt = str.charAt(i);
            scoreText = scoreText + charAt;
        }

        return parseInt(scoreText);
    };

    static is_numeric = (str) => {
        return /^\d+$/.test(str);
    };

    static tileCreation = (letter, forRevealSolution) => {
        let tile = {
            id: generateUUID(),
        };

        if (letter === '*' || (letter >= 'a' && letter <= 'z')) {
            tile.isBlankTile = true;
            /*
             *For small letter i.e, if user uses letter picker denoted by small letter ,
             *so uppercasing it for view purpose
             */
            tile.currentLetter = letter >= 'a' && letter <= 'z' ? letter.toUpperCase() : undefined;
        } else {
            tile.letter = letter;
        }
        tile.forRevealSolution = forRevealSolution;
        return tile;
    };

    static createMoveArray = (playedTiles) => {
        let moveArr = [];

        for (let i = 0; i < playedTiles.length; i++) {
            let letter = playedTiles[i].letter ? playedTiles[i].letter : playedTiles[i].currentLetter.toLowerCase();
            let x = playedTiles[i].position.x;
            let y = playedTiles[i].position.y;

            let moveStr = y + ',' + x + ',' + letter;
            moveArr.push(moveStr);
        }
        return moveArr;
    };

    static appendDataToMoveTileArr = (moveTileArr, data, forRevealSolution) => {
        data.forEach((element = '') => {
            let moveData = element.split(',');
            if (moveData.length > 0 && !isNaN(moveData[1]) && !isNaN(moveData[2])) {
                let x = parseInt(moveData[2]);
                let y = parseInt(moveData[1]);
                let letter = moveData[3];
                let position = { x, y };
                let tile = GameBoardUtils.tileCreation(letter, forRevealSolution);
                tile.position = position;
                let letterObj = {
                    position,
                    tile,
                };
                moveTileArr.push(letterObj);
            }
        });
        return moveTileArr;
    };

    static makeRackString(tiles) {
        let rackString = '';
        (tiles || []).forEach((tile) => {
            if (tile) {
                if (tile.isBlankTile) rackString = rackString + '*';
                else rackString = rackString + tile.letter;
            }
        });
        return rackString;
    }

    static getNotSuccessExitCodeInstance = (data, orgPiggback) => {
        return {
            extcode: data[0] ? 0 : get(data, '1.extcode') || get(data, '1.' + orgPiggback + '.extcode'),
            msg: data[0] ? data[0].message : get(data, '1.msg') || get(data, '1.' + orgPiggback + '.msg'),
        };
    };

    static getWinReasonText = ({
        gameover_reason,
        isGameDrawn,
        isObserver,
        isWinner,
        selfName,
        selfScore,
        opponentScore,
        opponentName,
        isSelfResign,
        noScoreDetailsText,
        isMultiPlayer,
        isSoloSingle,
        isSoloGame,
        myBestMoves,
        oppBestMoves,
        totalMoves,
        isBlitzGame,
        isArchiveGameView,
    }) => {
        let baseText = '';
        switch (gameover_reason) {
            case 'FORCEWINRESIGN':
            case 'CONTINUOUSPASS':
                log.info('in GameBoardUtils.getWinReasonText, gameover_reason is');
                baseText = 'The game has ended as ' + (isMultiPlayer ? 'all' : 'both') + ' players passed their turn. ';
                break;
            case 'LIVETIMEOUTRESIGN':
                baseText = isObserver ? 'The game has ended. ' : isSelfResign ? 'Time up! ' : opponentName + ' timed out. ';
                break;
            case 'NORMAL':
                if (isObserver || isBlitzGame || isArchiveGameView) {
                    baseText = 'The game has ended. ';
                }
                break;
            case 'LIVEDISCONNECTTIMEOUTRESIGN':
                baseText = opponentName + ' had gone offline. ';
                break;
            case 'RESIGN':
                baseText = isSelfResign
                    ? (isObserver || isArchiveGameView ? 'The game has ended. ' : 'You have') +
                      (!isObserver && !isArchiveGameView ? ' resigned the game. ' : '')
                    : (isMultiPlayer ? 'The opponent' : opponentName) + ' has resigned the game. ';
                break;
            case 'TIMEOUT':
                baseText = 'Time is over. Do you want to start a new game?';
                break;
            default:
                throw new Error('Invalid game over reason');
        }

        baseText =
            gameover_reason !== 'TIMEOUT'
                ? baseText +
                  (!noScoreDetailsText
                      ? isGameDrawn
                          ? 'The game is drawn.'
                          : (isObserver || isArchiveGameView
                                ? isWinner
                                    ? selfName + ' won'
                                    : opponentName + ' won'
                                : isSoloSingle
                                ? 'Game over !!!'
                                : isWinner
                                ? 'You won'
                                : 'You lost') +
                            (isSoloSingle ? ' You scored ' : ' with a score of ') +
                            (isMultiPlayer || isSoloSingle
                                ? isObserver || isArchiveGameView
                                    ? isWinner
                                        ? selfScore
                                        : opponentScore
                                    : selfScore
                                : isObserver || isArchiveGameView
                                ? isWinner
                                    ? selfScore + ' to ' + opponentScore
                                    : opponentScore + ' to ' + selfScore
                                : selfScore + ' to ' + opponentScore) +
                            '.'
                      : '')
                : baseText;
        if (!isSoloGame && !isObserver && !isArchiveGameView) {
            baseText =
                baseText +
                '\n\nYou got the highest score in ' +
                myBestMoves +
                '/' +
                totalMoves +
                ' turns.' +
                (!isBlitzGame ? ' Opp in ' + oppBestMoves + '/' + totalMoves + ' turns.' : '');
        }

        return baseText;
    };

    static getDeleteReasonText = ({ gameover_reason, isMyself, opponentName, isMultiPlayer }) => {
        switch (gameover_reason) {
            case 'LIVETIMEOUTNOFIRSTMOVE':
                return (
                    'This game has been deleted since ' +
                    (isMyself ? 'you' : opponentName) +
                    ' failed to play the first move within 1 minute.'
                );
            case 'LIVETIMEOUTRESIGN':
                return 'This game has been deleted since ' + (isMyself ? 'you' : opponentName) + ' timed out.';
            case 'LIVEDISCONNECTTIMEOUTRESIGN':
                return 'This game was deleted as ' + (isMyself ? ' you went offline' : opponentName + ' has gone offline.');
            default:
                return (
                    'This game has been deleted by ' +
                    (isMyself ? 'you' : opponentName || (isMultiPlayer ? 'an ' : 'the ') + 'opponent') +
                    '.'
                );
        }
    };

    static getName = (player) => get(player, 'name');

    static getRack = (player) => get(player, 'currentrack');

    static getPid = (player) => get(player, 'pid');

    static isResigned = (player) => get(player, 'resigned') === 'y';

    static getCurrentScore = (player) => get(player, 'current_score') || lastArrayElement(get(player, 'scoresInGame') || []);

    static evaluateRackTotalValue = (rack) => {
        let totalScore = 0;
        if (rack) {
            let rackArr = rack.split('');
            for (let i = 0; i < rackArr.length; i++) {
                totalScore =
                    totalScore +
                    Number(
                        GameBoardUtils.getTileBasicScore({
                            letter: String(rackArr[i]),
                        })
                    );
            }
        }
        return totalScore;
    };

    static getSelf = (data) => {
        let players = get(data, get(store.getState(), 'game.channel') + '.players');
        let self = (players || []).filter((player) => player.guid === get(store.getState(), 'game.guid'))[0];
        return self;
    };

    static getOpponent = (data) => {
        let players = get(data, get(store.getState(), 'game.channel') + '.players');
        let opponent = (players || []).filter((player) => player.guid !== get(store.getState(), 'game.guid'))[0];
        return opponent;
    };

    static getPlayerAtPosition = (data, position) => {
        let players = get(data, get(store.getState(), 'game.channel') + '.players');
        return get(players, '' + position);
    };

    static getSelfRack = (data) => GameBoardUtils.getRack(GameBoardUtils.getSelf(data));

    static getSelfTileValue = (data) => GameBoardUtils.evaluateRackTotalValue(GameBoardUtils.getSelfRack(data));

    static getSelfResign = (data) => GameBoardUtils.isResigned(GameBoardUtils.getSelf(data));

    static getOpponentName = (data) => GameBoardUtils.getName(GameBoardUtils.getOpponent(data));

    static getOpponentScore = (data) => GameBoardUtils.getCurrentScore(GameBoardUtils.getOpponent(data));

    static getOpponentRack = (data) => GameBoardUtils.getRack(GameBoardUtils.getOpponent(data));

    static getOpponentTileValue = (data) => GameBoardUtils.evaluateRackTotalValue(GameBoardUtils.getOpponentRack(data));

    static getPlayerOneRack = (data) => GameBoardUtils.getRack(GameBoardUtils.getPlayerAtPosition(data, 0));

    static getPlayerTwoRack = (data) => GameBoardUtils.getRack(GameBoardUtils.getPlayerAtPosition(data, 1));

    static setGameTypeMode = (messageObj) => {};

    static setPlayerCountInGame = (messageObj) => {};

    static setDatas = (messageObj) => {
        GameBoardUtils.setGameBoardInfo(messageObj);
        let moveTiles =
            get(messageObj, get(store.getState(), 'game.channel') + '.boarddata.movetiles') ||
            get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.boarddata.movetiles') ||
            [];
        let moveCount = get(store.getState(), 'game.moveCount', 0) + moveTiles.length;
        eventBus.emit(GAME_MOVE_COUNT_SET, null, moveCount);
        GameBoardUtils.checkGameEndedAndTurn(messageObj);
    };

    static checkGameEndedAndTurn = (res) => {};

    static getTheme = () => {
        let tileThemeArray = ['Lexulous', 'Classic', 'Adventure', 'Essence', 'Dark'];
        let gameTheme = get(store.getState(), 'config.theme');
        let positionToUse = (gameTheme && gameTheme.split('-')[1]) || '0';
        let themeId = tileThemeArray[positionToUse];
        return TileTheme[themeId];
    };

    static getCellBackgroundColor = ({
        shouldShowTile,
        forRevealSolution,
        isLocked,
        isDefaultCell,
        specialCellType,
        boardTheme = 'Lexulous',
    } = {}) => {
        if (shouldShowTile) {
            if (forRevealSolution) {
                return GameBoardUtils.getTheme().tileLastPlayed;
            }
            return isLocked ? GameBoardUtils.getTheme().tilePlayed : GameBoardUtils.getTheme().tileRack;
        }
        if (isDefaultCell) return BoardTheme[boardTheme]['blankWeight'];
        switch (specialCellType) {
            case '5W':
                return BoardTheme[boardTheme]['5WWeight'];
            case '4W':
                return BoardTheme[boardTheme]['4WWeight'];
            case '3W':
                return BoardTheme[boardTheme]['3WWeight'];
            case '2W':
                return BoardTheme[boardTheme]['2WWeight'];
            case '5L':
                return BoardTheme[boardTheme]['5LWeight'];
            case '4L':
                return BoardTheme[boardTheme]['4LWeight'];
            case '3L':
                return BoardTheme[boardTheme]['3LWeight'];
            case '2L':
                return BoardTheme[boardTheme]['2LWeight'];
            default:
                return BoardTheme[boardTheme]['blankWeight'];
        }
    };

    static getCellBorderColor = ({
        shouldShowTile,
        forRevealSolution,
        isLocked,
        isDefaultCell,
        specialCellType,
        boardTheme = 'Lexulous',
    } = {}) => {
        if (shouldShowTile) {
            if (forRevealSolution) {
                return GameBoardUtils.getTheme().tileLastPlayedBorder;
            }
            return isLocked ? GameBoardUtils.getTheme().tilePlayedBorder : GameBoardUtils.getTheme().tileRackBorder;
        }
        if (isDefaultCell) return ColorConfig.DEFAULT_CELL_BACKGROUND_COLOR;
        switch (specialCellType) {
            case '5W':
                return BoardTheme[boardTheme]['5WWeight'];
            case '4W':
                return BoardTheme[boardTheme]['4WWeight'];
            case '3W':
                return BoardTheme[boardTheme]['3WWeight'];
            case '2W':
                return BoardTheme[boardTheme]['2WWeight'];
            case '5L':
                return BoardTheme[boardTheme]['5LWeight'];
            case '4L':
                return BoardTheme[boardTheme]['4LWeight'];
            case '3L':
                return BoardTheme[boardTheme]['3LWeight'];
            case '2L':
                return BoardTheme[boardTheme]['2LWeight'];
            default:
                return BoardTheme[boardTheme]['blankWeight'];
        }
    };

    static getCellTextColor = (cellType) => {
        switch (cellType) {
            case '5W':
                return '#000';
            case '4W':
                return '#000';
            case '3W':
                return '#FFF';
            case '2W':
                return '#000';
            case '5L':
                return '#FFF';
            case '4L':
                return '#000';
            case '3L':
                return '#FFF';
            case '2L':
                return '#000';
            default:
                return 'rgba(250, 250, 250, 0.40)';
        }
    };

    static isMyself = (item, globalState) =>
        get(item, 'uid.guid') === get(globalState || store.getState(), 'game.guid') ||
        get(item, 'guid') === get(globalState || store.getState(), 'game.guid');

    static isBlockedByMe = (player) => {
        if (get(store.getState(), 'user.sensorList')) {
            let sensorList = get(store.getState(), 'user.sensorList');
            return sensorList.some((sensored) => sensored.guid === (get(player, 'guid') || get(player, 'uid')));
        }
        return false;
    };

    static isMyFriend = (player) => {
        if (get(store.getState(), 'user.buddyList')) {
            let buddyList = get(store.getState(), 'user.buddyList');
            return !!(
                (buddyList.buddies || []).find((buddy) => buddy.guid === player.guid) ||
                (buddyList.reqsent || []).find((request) => request.guid === player.guid) ||
                (buddyList.online || []).find((onlinePlayer) => onlinePlayer.guid === player.guid)
            );
        }
        return false;
    };

    static isMenuAtTheBottom = () => DimensionUtils.isMobile() || get(store.getState(), 'game.board_type') === 'super';

    static getSelfPid = (messageObj) => {
        let players = get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.players');
        return ((players || []).filter((player) => player.guid === get(store.getState(), 'game.guid'))[0] || {}).pid;
    };

    static clearMessages = () => null;

    static setTilesInBag = () => null;

    static getPlayerWordsPlayedOnAMove = (move, maxletters, spaceBetweenWords) => {
        let wordsPlayedInMove = '';
        move.forEach((word, index) => {
            let wordParts = word.split(',');
            if (wordParts[3] === 's') wordParts[1] = 'SWAP';
            else if (wordParts[3] === 'c' && Number(index) === 0) wordParts[1] = 'CHALLENGE';
            else if (wordParts[3] === 'c' && index > 0) return;

            if (spaceBetweenWords) {
                wordsPlayedInMove = wordsPlayedInMove + ', ' + wordParts[1];
            } else {
                wordsPlayedInMove = wordsPlayedInMove + ',' + wordParts[1];
            }
        });

        if (maxletters && wordsPlayedInMove.length > maxletters) {
            if (spaceBetweenWords) wordsPlayedInMove = wordsPlayedInMove.substring(2, maxletters - 3) + '...';
            //escapping first comma, space and  word length
            else wordsPlayedInMove = wordsPlayedInMove.substring(1, maxletters - 3) + '...'; //escapping first comma and word length
        } else {
            if (spaceBetweenWords) wordsPlayedInMove = wordsPlayedInMove.substring(2);
            //escapping first comma and space
            else wordsPlayedInMove = wordsPlayedInMove.substring(1); //escapping first comma
        }
        return wordsPlayedInMove;
    };

    static getPlayerMoveScoreOnAMove = (move) => {
        let scoreInMove = 0;
        move.forEach((word) => {
            let wordParts = word.split(',');
            scoreInMove = Number(scoreInMove) + Number(wordParts[2]);
        });
        return scoreInMove;
    };

    static getBestScoreOnAMove = (move) => {
        let bestScore = Number(move[0].split(',')[5]);
        return bestScore;
    };

    static getPlayerWiseStrokeColor = (pid) => {
        if (String(pid) === String(get(store.getState(), 'game.pid'))) return '#f0932b';
        else {
            let indices = ['1', '2', '3', '4'];
            let selfIndex = indices.indexOf(String(get(store.getState(), 'game.pid')));
            if (selfIndex > -1) {
                indices.splice(selfIndex, 1);
            }
            switch (String(pid)) {
                case indices[0]:
                    return '#2762e3';
                case indices[1]:
                    return '#F00';
                case indices[2]:
                    return '#2d3436';
                default:
                    return '#f0932b';
            }
        }
    };

    static getBlitzPlayerWiseStrokeColor = (index) => {
        let colors = ['#2e68cb', '#F00', '#f7ac28', '#008000'];
        if (index < colors.length) {
            return colors[index];
        } else {
            let letters = '0123456789ABCDEF';
            let color = '#';
            for (let i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        }
    };

    static getPidFromMove = (move) => move[0][0];

    static isChallengeModeStr = (str) => Config.CHALLENGE_MODE.includes(str);

    static isChallengeMode = (globalState = store.getState()) =>
        GameBoardUtils.isChallengeModeStr(get(globalState, 'game.gametypeMode'));

    static isPlayerResigned = (player) => get(player, 'resigned') === 'y' || get(player, 'deleted');

    static getPlayerResignReasonMessage = (player, gameState) => {
        let reason =
            get(player, 'reason') ||
            (get(player, 'resigned') === 'y'
                ? (get(gameState, 'gameover_reason') || '').toUpperCase().includes('LIVETIMEOUTRESIGN')
                    ? 'TIMEOUT'
                    : 'RESIGN'
                : '') ||
            '';
        log.info('in GameReducer, in GameBoardUtils, in getPlayerResignReasonMessage, reason is: ' + reason);

        if (reason.toUpperCase() === 'LIVEDISCONNECTTIMEOUTRESIGN') return Config.LIVE_DISCONNECT_TIME_OUT_RESIGN;
        else if (reason.toUpperCase().includes('TIMEOUT')) return Config.LIVE_TIME_OUT_RESIGN_MESSAGE;
        else if (reason.toUpperCase().includes('RESIGN')) return Config.PLAYER_SELF_RESIGN_MESSAGE;
        else if (reason.toUpperCase().includes('DELETE')) return Config.PLAYER_SELF_DELETE_MESSAGE;
        return ' ';
    };

    static setPlayerSelfCurrentScore = (messageObj) => {
        let players = get(messageObj, 'data.' + get(store.getState(), 'game.channel') + '.players');
        let player = (players || []).filter((player) => player.pid === get(store.getState(), 'game.pid'))[0];

        let playerSelfCurrentScore = get(player, 'current_score');

        if (playerSelfCurrentScore) {
            eventBus.emit(GAME_SET_PLAYER_SELF_CURRENT_SCORE, null, playerSelfCurrentScore);
        }
    };

    static getPsuedoGameBoardFromMoveTiles = (moveTiles, position) => {
        let board_size = get(store.getState(), 'game.board_size');
        let gameBoard = GameBoardUtils.initGameBoard(board_size, board_size);
        for (let i = 0; i < position; i++) {
            let move = (moveTiles || [])[i];
            (move || []).forEach((tile) => {
                let tileInfoParts = tile.split(',');
                let tileToBeCreated = GameBoardUtils.tileCreation(tileInfoParts[3], true);
                let cell = gameBoard[tileInfoParts[1]][tileInfoParts[2]];
                cell.currentTile = tileToBeCreated;
                cell.locked = true;
            });
        }
        return gameBoard;
    };

    static getWordsFromMoveSet = async ({ gameBoard, moveSet } = {}) => {
        if (moveSet && moveSet.length > 0) {
            for (let i = 0; i < moveSet.length; i++) {
                let move = moveSet[i];
                let tiles = [];
                (move.set || move.movetiles || []).forEach((tileDesc) => {
                    let parts = tileDesc.split(',');
                    let tile = {
                        position: {
                            x: Number(parts[1]),
                            y: Number(parts[0]),
                        },
                    };
                    if (StringUtils.isUpperCase(parts[2])) tile.letter = parts[2];
                    else tile.currentLetter = parts[2];
                    tile.id = generateUUID();
                    tiles.push(tile);
                });

                log.info('in GameBoardUtils, in getWordsFromMoveSet, tiles is:\n' + JSON.stringify(tiles, null, 2));

                let res = await to(
                    GameBoardUtils.validateAndSendMove({
                        gameBoard,
                        tiles,
                        forWordList: true,
                    })
                );

                move.wordsFormed = get(res, '1.words') || [];

                log.info(
                    'in GameBoardUtils, in getWordsFromMoveSet, move.wordsFormed is:\n' +
                        JSON.stringify(move.wordsFormed, null, 2)
                );
            }
        }

        return moveSet;
    };

    getCellBorderColor = () => {};
}

export const getRackData = (data, forAnalyse) => {
    let rackArr = [];

    //Rack Array creation
    for (let i = 0; i < data.length; i++) {
        let letter = data.charAt(i);
        let tile = GameBoardUtils.tileCreation(letter);
        tile.forAnalyse = forAnalyse;
        rackArr.push(tile);
    }

    /*
     * For empty space at the end of Rack -
     * If rack size in data is less than config rack size,
     * then rest elements are added as empty spaces in rack array
     */
    let rackLength = data.length;
    while (rackLength < getMaxRackLength() + 1) {
        let emptySpaceObj = {
            id: generateUUID(),
            isEmptySpace: true,
        };
        rackArr.push(emptySpaceObj);
        rackLength++;
    }

    return rackArr;
};

const getMaxRackLength = () => 8;

export const createMoveTilesArr = ({ data, forRevealSolution, isGameFeed, isObserve } = {}) => {
    let moveTilesArr = [];
    //MoveTiles array creation
    for (let i = 0; i < data.length; i++) {
        let element = data[i];
        appendDataToMoveTileArr(
            moveTilesArr,
            element,
            forRevealSolution || ((isObserve || isGameFeed) && i === data.length - 1)
        );
    }
    return moveTilesArr;
};

export const appendDataToMoveTileArr = (moveTileArr, data, forRevealSolution) => {
    data.forEach((element = '') => {
        let moveData = element.split(',');
        if (moveData.length > 0 && !isNaN(moveData[1]) && !isNaN(moveData[2])) {
            let x = parseInt(moveData[2]);
            let y = parseInt(moveData[1]);
            let letter = moveData[3];
            let letterObj = {
                position: { x, y },
                tile: GameBoardUtils.tileCreation(letter, forRevealSolution),
            };
            moveTileArr.push(letterObj);
        }
    });

    return moveTileArr;
};

export const sortTimerPositionViewOrder = (players) => {
    players = cloneDeep(players);
    let orgLength = players.length;
    let midPoint = Math.floor(orgLength / 2);

    let viewOrderPlayers = [];

    let selfIndex = players.findIndex((player) => player.guid === get(store.getState(), 'game.guid'));
    let selfArr = selfIndex >= 0 ? players.splice(selfIndex, 1) : [];
    let self = selfArr[0];

    viewOrderPlayers.push(self || players.shift());

    for (let i = 0; i < orgLength; i++) {
        if (i === midPoint) {
            /* let lastWordData = {
                viewBoardData: true
            };
            viewOrderPlayers.push(lastWordData); */
        } else {
            let item = players.shift();
            item && viewOrderPlayers.push(item);
        }
    }

    return viewOrderPlayers;
};

export const onStartAnalyse = async () => {
    let gid =
        get(get(store.getState(), 'game.channel') + '.players') ||
        get(get(store.getState(), 'game.channel') + '.players') ||
        get(store.getState(), 'game.gid');
    let possibleMovesObjs = await getPossibleMoves(gid);
    let extcode = get(possibleMovesObjs, 'extcode');
    if (extcode === '1102') {
        openPurchaseProPage();
    } else if (extcode === '1') {
        let gameFeedData = await getGameFeed({
            dontEmit: true,
            useArchiveGameFeed: true,
        });

        let movesList =
            get(gameFeedData, get(store.getState(), 'game.channel') + '.boarddata.movetiles') ||
            get(gameFeedData, 'data.' + get(store.getState(), 'game.channel') + '.boarddata.movetiles') ||
            [];
        let rackInfos =
            get(gameFeedData, get(store.getState(), 'game.channel') + '.boarddata.rackinfo') ||
            get(gameFeedData, 'data.' + get(store.getState(), 'game.channel') + '.boarddata.rackinfo') ||
            [];
        let wordsPlayeds =
            get(gameFeedData, get(store.getState(), 'game.channel') + '.boarddata.wordsplayed') ||
            get(gameFeedData, 'data.' + get(store.getState(), 'game.channel') + '.boarddata.wordsplayed') ||
            [];
        let players =
            get(gameFeedData, get(store.getState(), 'game.channel') + '.players') ||
            get(gameFeedData, 'data.' + get(store.getState(), 'game.channel') + '.players') ||
            [];
        let movesObjs = [];

        players = sortTimerPositionViewOrder(players);

        for (let index = 0; index < movesList.length; index++) {
            let move = movesList[index];
            let possibleMoves = get(possibleMovesObjs, 'data.' + (index + 1) + '.moveset');
            let psuedoGameBoard = GameBoardUtils.getPsuedoGameBoardFromMoveTiles(movesList, index);

            possibleMoves = await GameBoardUtils.getWordsFromMoveSet({
                moveSet: possibleMoves,
                gameBoard: psuedoGameBoard,
            });

            let rack = rackInfos[index] || get(possibleMovesObjs, 'data.' + (index + 1) + '.rack');
            let rackArr = getRackData(rack, true);

            let objToPush = {
                move,
                rack,
                rackArr,
                wordsPlayed: wordsPlayeds[index],
                possibleMoves,
            };
            movesObjs.push(objToPush);
        }

        eventBus.emit(GAME_ANALYSE_DATA_READY, null, { movesObjs, players });
        eventBus.emit(Config.ANALYSE_DISPLAY_MOVE_RACK, null, {
            movesObjs,
            players,
            position: 0,
        });
    } else {
        createGeneralRequestFailureDialog();
    }
};

export const getNameForPlayer = (player) => player.pid;

export const getDictionaryDetails = (dictionary) => {
    switch ((dictionary || '').toLowerCase()) {
        case 't':
        case 'twl':
            return {
                indicator: 'T',
                lang: 'us_en',
                explanation: 'US English',
                abreviations: 'US',
            };
        case 's':
        case 'sow':
            return {
                indicator: 'S',
                lang: 'uk_en',
                explanation: 'UK English',
                abreviations: 'UK',
            };
        case 'f':
        case 'fr':
            return {
                indicator: 'F',
                lang: 'fr',
                explanation: 'French',
                abreviations: 'FR',
            };
        case 'i':
        case 'it':
            return {
                indicator: 'I',
                lang: 'it',
                explanation: 'Italian',
                abreviations: 'IT',
            };
        default:
            throw new Error('Invalid Dictionary Code');
    }
};

export const showAnalysePurchaseDialog = () => {
    createDialogInstance({
        title: 'PRO Feature: Analyse Games',
        body: 'This feature is available for PRO users only.',
        actionButtonText: 'Go PRO',
        onAction: () => openPurchaseProPage(false),
        notDismissable: true,
    });
};

export const getGameRequestText = ({
    gameover_reason,
    rematchData,
    isMultiPlayer,
    isSoloSingle,
    isObserver,
    opponentName,
    isArchiveGameView,
}) => {
    let baseText = '';
    if (rematchData) {
        if (rematchData.accept) {
            baseText = opponentName + ' would like to play another game with you. Accept Rematch?';
        } else {
            baseText = 'Would you like to play another game with ' + opponentName + '?';
        }
    } else {
        if (gameover_reason !== 'TIMEOUT' && !isMultiPlayer && !isSoloSingle && !isObserver && !isArchiveGameView)
            baseText = 'Would you like to play another game with ' + opponentName + '?';
    }
    return baseText;
};

export const setBoardAboveViewsHeight = (height) => {
    store.dispatch({
        type: LAYOUT_SET_BOARD_ABOVE_VIEWS_HEIGHT,
        payload: height,
        globalState: store.getState(),
    });
};

export const setSidePanelTabWidthHeight = (width, height) => {
    eventBus.emit(LAYOUT_REDUCER_SET_FIELD, null, { tabHeight: height });
};
