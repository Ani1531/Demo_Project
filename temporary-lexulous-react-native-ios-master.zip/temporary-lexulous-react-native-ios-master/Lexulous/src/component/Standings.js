import React from 'react';
import { Animated, FlatList, StyleSheet, View } from 'react-native';
import Config from '../configs/Config';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import ColorConfig from '../configs/ColorConfig';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import PlayerAvatarNameRating from './PlayerAvatarNameRating';
import GameBoardUtils from '../utils/GameBoardUtils';
import { connect } from 'react-redux';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';
import TooltipWrapper from './TooltipWrapper';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

class Standings extends React.Component {
    state = {
        mouseOver: false,
    };

    componentDidUpdate = () => {
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState, nextContext) =>
        !isEqual(this.props, nextProps) || !isEqual(this.state, nextState);

    getScoreTimerMainContainerDimension = () => ({
        width: '100%',
    });

    render = () => {
        let gameData =
            (get(this.props, 'gamelist.observableGamesList') || []).find(
                (game) => game.gid === get(this.props, 'game.gid')
            ) || get(this.props, 'gamelist.standingGameData');
        let standingPlayers = (get(gameData, 'jndplys') || []).filter(
            (player) => player.guid !== get(this.props, 'game.guid')
        );
        standingPlayers.sort(
            (player1, player2) => Number(player2.score) - Number(player1.score)
        );
        return (
            <View
                style={[
                    styles.mainContainer,
                    this.getScoreTimerMainContainerDimension(),
                    this.props.isAtBottom
                        ? {
                              borderWidth: undefined,
                              borderColor: undefined,
                              borderBottomWidth: StyleSheet.hairlineWidth,
                              borderBottomColor:
                                  ColorConfig.SIDE_PANEL_BORDER_COLOR,
                          }
                        : null,
                ]}
                key={this.state.key}
            >
                <FlatList
                    data={standingPlayers}
                    renderItem={this.renderPlayerTimerData}
                    keyExtractor={(item) => item.guid}
                />
            </View>
        );
    };

    getPlayerAvailabilityStatusColorStyleObj = (playerData) => ({
        color: this.getPlayerAvailabilityStatusColor(playerData),
    });

    getPlayerAvailabilityStatusColor = (playerData) => {
        if (
            !this.props.emailGame &&
            playerData.availablity_status === 'Offline'
        ) {
            return '#cccccc';
        } else if (
            this.props.emailGame &&
            playerData.availablity_status === 'Online' &&
            !(this.state.pid === playerData.pid)
        ) {
            return ColorConfig.PLAYER_NAME_COLOR;
        } else {
            return ColorConfig.TRANSPARENT;
        }
    };

    getCurrentTurn = () => this.props.game.currentTurn;

    getPlayerColorStatusStyle = (pid) => styles.nonActivePlayerColor;

    getTimerColorStatusStyle = (playerData) =>
        Number(this['player_' + playerData.pid].getTime() / 1000) < 60
            ? styles.activePlayerColor
            : styles.nonActivePlayerColor;

    getAddTimeColorStatusStyle = (playerData) =>
        this.getCurrentTurn() === playerData.pid &&
        this['player_' + playerData.pid] &&
        Number(this['player_' + playerData.pid].getTime() / 1000) < 60
            ? styles.activePlayerColor
            : { color: this.state.addTimeIconColor };

    getItemFlexPosition = (index) =>
        index < this.props.game.players.length / 2
            ? styles.itemLeftSide
            : styles.itemLeftSide;

    getCurrentScoreStyles = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 2,
        // paddingHorizontal: this.getGeneralPadding() * 2
    });

    getPlayerTimerStyle = (index, arr, playerData) => ({
        borderBottomWidth:
            index === (arr || []).length - 1 ? 0 : StyleSheet.hairlineWidth,
        borderColor:
            index === (arr || []).length - 1
                ? undefined
                : ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor:
            index % 2 === 0
                ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD
                : ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN,
        opacity: GameBoardUtils.isPlayerResigned(playerData) ? 0.5 : undefined,
    });

    getEmailGameContainerStyle = () => [
        !this.props.emailGame
            ? LayoutUtils.getCursorPointerStyle()
            : LayoutUtils.getCursorDefaultStyle(),
        styles.alignItemsCenter,
    ];

    onMoreTimeMouseOver = (guid) => {
        this.setState({
            addTimeIconColor: ColorConfig.BUTTON_TEXT_HOVER_COLOR,
        });
        // this["addTimeTooltipPlayer" + guid].open();
    };

    onMoreTimeMouseOut = (guid) => {
        this.setState({
            addTimeIconColor:
                ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
        });
        // this["addTimeTooltipPlayer" + guid].close();
    };

    getScoreTimerContainerHeightAsNumber = () =>
        Math.round(
            (this.props.layout.boardDimen *
                (DimensionUtils.isMobile() ? 10 : 9)) /
                100
        );

    getScoreTimerContainerHeight = () => ({
        height: this.getScoreTimerContainerHeightAsNumber(),
    });

    arrowPos = new Animated.Value(1);

    renderPlayerTimerData = ({ item, index, arr }) => {
        let playerData = get(item, 'player');
        let score = get(item, 'score');
        let tilesinbag = get(item, 'tilesinbag');
        return (
            <View
                style={[
                    styles.scoreTimerContainer,
                    this.getItemFlexPosition(index),
                    this.getPlayerTimerStyle(index, arr, playerData),
                    this.getScoreTimerContainerHeight(),
                ]}
            >
                <View
                    style={[
                        styles.playerDataContainer,
                        { width: '50%', overflow: 'hidden' },
                    ]}
                >
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            {
                                paddingLeft: 10,
                                alignItems: 'flex-start',
                                justifyContent: 'center',
                                overflow: 'hidden',
                            },
                        ]}
                    >
                        <PlayerAvatarNameRating
                            player={playerData}
                            isBlitz={true}
                            flexDirection={'row'}
                            hideyoutext
                            userRatingPlainStyle
                            getRatingForPlayer={
                                LiveGamePlayUtils.getRatingForPlayer
                            }
                            toggleFriendship={
                                LiveGamePlayUtils.toggleFriendship
                            }
                            toggleBlock={LiveGamePlayUtils.toggleBlock}
                            currentTurn={
                                this.getCurrentTurn() === playerData.pid
                            }
                            guid={this.props.game.guid}
                            forSideMenuTimer={true}
                            tooltipID="appTooltip"
                        />
                    </View>
                </View>
                <View style={[styles.scoreDisplayingViewStyle]}>
                    <S14Text
                        style={[
                            this.getCurrentTurn() === playerData.pid
                                ? styles.boldFont
                                : null,
                            this.getCurrentScoreStyles(),
                            this.getPlayerColorStatusStyle(playerData.pid),
                        ]}
                    >
                        {score}
                    </S14Text>
                </View>
                {
                    <TooltipWrapper
                        tooltip={'Tiles left'}
                        expTooltip={true}
                        style={[
                            styles.timerContainer,
                            styles.timerLeftSidePanelStyle,
                            styles.playerResignMsgContainer,
                        ]}
                        onMouseOver={() => {
                            this.setState({ mouseOver: true });
                        }}
                        onMouseOut={() => {
                            this.setState({ mouseOver: false });
                        }}
                    >
                        <S14Text
                            style={[
                                this.getPlayerResignMessageFontStyle(),
                                this.getPlayerColorStatusStyle(playerData.pid),
                            ]}
                        >
                            {tilesinbag}
                        </S14Text>
                    </TooltipWrapper>
                }
            </View>
        );
    };

    getPlayerResignMessageFontStyle = () => ({
        //fontSize: this.getPanelFontSize().fontSize * 1.5,
    });

    getPanelFontSize = () => ({
        //fontSize: this.getScoreTimerMainContainerDimension().width * 0.035,
    });
}

const styles = StyleSheet.create({
    mainContainer: {
        flexDirection: 'column',
        overflow: 'hidden',
        backgroundColor: '#f4f3ef',
    },
    imageContainer: {
        flex: 1,
        overflow: 'hidden',
        flexDirection: 'column-reverse',
    },
    directionRow: {
        flexDirection: 'row',
    },
    rowContainer: {
        margin: 5,
        width: '100%',
        flex: 1,
        backgroundColor: ColorConfig.PLAYER_INFO_TOOLTIP_BACKGROUND_COLOR,
    },
    image: {
        flex: 1,
    },
    userStatsContainer: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 5,
    },
    playedGamesContainer: {
        flex: 2,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 5,
    },
    heading_style: {
        fontWeight: 'bold',
    },
    scoreTimerContainer: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    scoreTimerContainerForTopBar: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    playerDataContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        height: '100%',
        borderRightColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightWidth: 1,
    },
    textCenter: {
        textAlign: 'center',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    customHeadingFontWeight: {
        fontWeight: '400',
    },
    timerContainer: {
        flex: 1,
    },

    timerContainerAfterBoardData: {
        flexDirection: 'row-reverse',
    },
    timerBeforeBoardData: {
        flexDirection: 'row',
        flex: 2,
        alignItems: 'center',
    },
    timerAfterBoardData: {
        flexDirection: 'row-reverse',
        flex: 2,
        alignItems: 'center',
    },
    iconContainer: {
        flex: 6,
        flexDirection: 'column',
    },
    scoreContainer: {
        borderTopWidth: 1,
        width: '100%',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        flex: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    blankSpaceContainer: {},
    boardData: {
        flexDirection: 'column-reverse',
        flex: 1,
    },
    tilesInBag: {
        alignSelf: 'center',
    },
    tilesInBagContainer: {
        flex: 1,
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    lastWordDataContainer: {
        flex: 1,
    },
    lastWordData: {
        fontWeight: 'bold',
        color: '#000',
    },
    activePlayerColor: {
        color: ColorConfig.LIVE_GAMES_TIMER_CARD_ACTIVE_PLAYER_COLOR,
    },

    nonActivePlayerColor: {
        color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
    },
    itemLeftSide: {
        alignItems: 'flex-start',
    },
    itemRightSide: {
        alignItems: 'flex-end',
    },
    row: {
        flexDirection: 'row',
    },

    rowReverse: {
        flexDirection: 'row-reverse',
    },
    timerLeftMargin: {
        marginLeft: 10,
    },
    timerRightMargin: {
        marginRight: 10,
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    toolTipButtonContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    toolTipUsernameAndButtonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%',
    },
    alignItemsCenter: {
        alignItems: 'center',
    },
    playerTilesInHand: {
        flexDirection: 'column',
        alignSelf: 'flex-start',
        color: ColorConfig.PLAYER_TILES_IN_HAND,
    },
    paddingLeftTwo: {
        paddingLeft: 2,
    },
    alignTextCenter: {
        textAlign: 'center',
    },
    playerReverseDataContainer: {
        flexDirection: 'row-reverse',
        flex: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    columnReverse: {
        flexDirection: 'column-reverse',
    },
    tilesInBagMainContainer: {
        alignItems: 'flex-end',
        flex: 1,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    scoreMainContainer: {
        alignItems: 'flex-start',
        justifyContent: 'center',
        flex: 2,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        flexDirection: 'column-reverse',
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    textColor: {
        color: ColorConfig.BOARD_CURRENT_SCORE_TEXT_COLOR,
    },
    flexTwoAndHalf: { flex: 2.5 },
    flexOneFifth: { flex: 0.2 },
    scoreDisplayingViewStyle: {
        width: '20%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    timerLeftSidePanelStyle: {
        height: '100%',
        width: '30%',
        alignItems: 'center',
        borderLeftWidth: 1,
        borderLeftColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    timerOuterPadding: { paddingLeft: 8 },
    timerMinutesViewStyle: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    timerSecondsViewStyle: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    firstTurnCountdownStyle: {
        width: 20,
        marginLeft: 3,
    },
    pl3: {
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
    },
    pb4: {
        paddingBottom: 4,
    },
    playerResignMsgContainer: {
        justifyContent: 'center',
    },
});

const mapStateToProps = (state) => ({
    game: state.game,
    gamelist: state.gamelist,
    layout: state.layout,
    config: state.config,
});

export default connect(mapStateToProps)(Standings);
