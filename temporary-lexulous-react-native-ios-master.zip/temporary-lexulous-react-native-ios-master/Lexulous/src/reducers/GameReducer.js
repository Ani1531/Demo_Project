import cloneDeep from 'lodash/cloneDeep';
import get from 'lodash/get';
import isArray from 'lodash/isArray';
import isEmpty from 'lodash/isEmpty';
import isBoolean from 'lodash/isBoolean';
import isObject from 'lodash/isObject';
import isEqual from 'lodash/isEqual';
import log from 'loglevel';
import * as ActionIdentifiers from '../configs/ActionIdentifiers';
import Config from '../configs/Config';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import DocumentWrapper from '../utils/DocumentWrapper';
import GameBoardUtils, { getDictionaryDetails } from '../utils/GameBoardUtils';
import SoundUtils, { isSoundsEnabled } from '../utils/SoundUtils';
import { is2dArray, lastArrayElement } from '../utils/Utils';
import isString from 'lodash/isString';
import isNumber from 'lodash/isNumber';
import StringUtils from '../utils/StringUtils';
import DimensionUtils from '../utils/DimensionUtils';
import remove from 'lodash/remove';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import store from '../store';

const isChallengeModeStr = (str) => Config.CHALLENGE_MODE.includes(str);

const isChallengeMode = (globalState = store.getState()) => isChallengeModeStr(get(globalState, 'game.gametypeMode'));

export const getDefaultTab = (globalState = {}) => {
    if (['puzzle'].includes(ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type'))) {
        return 2;
    } else if (DimensionUtils.isMobile()) {
        return 4;
    } else if (
        [Config.GAME_TYPE_SOLO, Config.GAME_TYPE_BLITZ].includes(
            ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type')
        )
    ) {
        return 1;
    } else if (
        [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_EMAIL].includes(
            ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type')
        )
    ) {
        if (!LiveGamePlayUtils.isObserving(globalState)) {
            return 0;
        } else {
            if (isChallengeMode(globalState)) {
                return 2;
            } else return 1;
        }
    }

    return 0;
};

const INITIAL_STATE = {
    ...ConfigurationWrapper.getLexulousGameConfiguration(),
    gameHasEnded: undefined,
    gameBoardSideLayoutActiveTab: getDefaultTab(),
    tabWasSetByClicking: false,
    isPageVisible: DocumentWrapper.isPageVisible(),
    differentialsList: [],
    lastMoveWordsArr: [],
    headToHeadArr: [],
    allRegularPlayedWords: {},
};

const swap = (json = {}) => {
    let ret = {};
    (Object.keys(json || {}) || []).forEach((key) => {
        ret[json[key]] = key;
    });
    return ret;
};

const getBestMoveScore = (data, state) => get(data, 'data.' + state.channel + '.boarddata.bestmove.score');

const getBestMoveLetterCount = (data, state) => get(data, 'data.' + state.channel + '.boarddata.bestmove.tileused');

const getBestMoveScoreForArchivedPuzzle = (data, state) => {
    let wordsPlayed = get(data, 'data.' + state.channel + '.boarddata.bestmove.0.wordsplayed') || [];
    let score = getScoreFromWordsPlayed(wordsPlayed);
    return score;
};

const getScoreFromWordsPlayed = (wordsPlayed) => {
    let sum = 0;
    (wordsPlayed || []).forEach((word) => {
        let parts = word.split(',');
        sum = sum + Number(parts[2]);
    });
    return sum;
};

const shouldShowMoveStrengthPercentage = (state) =>
    !state.showingAnalyseMove && !GameBoardUtils.isChallengeMode({ game: state });

const getLastPlayerScore = (data, state) => {
    let lastWordPlayed = get(data, 'data.' + state.channel + '.boarddata.lastwordplayed') || []; // if undefined then empty array
    let lastScore = 0;
    for (let i = 0; i < lastWordPlayed.length; i++) {
        let element = lastWordPlayed[i];
        let elementArr = element.split(',');
        let score = elementArr[2];
        lastScore = parseInt(lastScore) + parseInt(score);
    }
    return lastScore;
};

const getCurrentScore = (res, state) =>
    get(res, 'data.' + state.channel + '.current_score') || getSelfArchivedGameScore(res, state) || 0;

const getSelfArchivedGameScore = (res, state) => {
    let wordsplayed = get(res, 'data.' + state.channel + '.boarddata.wordsplayed') || [];
    return getScoreFromWordsPlayed(wordsplayed);
};

const getRating = (result, state) => {
    let data = get(result, 'data.' + state.channel + '.rating') || get(result, 'data.currentrating');
    return data;
};

const getBestMoveLetterCountForArchivedPuzzle = (data, state) => {
    let moveTiles = get(data, 'data.' + state.channel + '.boarddata.bestmove.0.movetiles') || [];
    return moveTiles.length;
};

const getLastPlayerLetterCount = (data, state) => {
    let firstElementOfLastWordPlayed = get(data, 'data.' + state.channel + '.boarddata.lastwordplayed.0') || []; // if undefined then empty array
    //Validation for empty array
    if (firstElementOfLastWordPlayed.length === 0) {
        return '0';
    }
    let firstElementArr = firstElementOfLastWordPlayed.split(',');
    let letterCount = firstElementArr[1] || '0'; // "0" value for handling element[1] not found, example: firstElementOfLastWordPlayed =  "2,,48,r,h"
    return letterCount;
};

const getScoreDifferentialsForLastGames = (data) => {
    let scoreDifferentials = [];
    let puzzleDataList = get(data, 'data.puzzles') || [];

    for (let i = 0; i < puzzleDataList.length; i++) {
        let currentMoveScore = 0;
        let puzzle = get(data, 'data.puzzles.' + i);

        let lastMovesScore = puzzle.lastmovescore;
        let currentWordPlayed = puzzle.wordsplayed;

        //For current player calculation and string formation
        for (let j = 0; j < currentWordPlayed.length; j++) {
            let element = currentWordPlayed[j];
            let elementArr = element.split(',');
            let score = elementArr[2];
            currentMoveScore = parseInt(currentMoveScore) + parseInt(score);
        }

        let scoreDifferential = parseInt(currentMoveScore) - parseInt(lastMovesScore);
        scoreDifferentials.push({
            scoreDifferential,
            puzzleid: puzzle.puzzleid,
        });
    }

    return scoreDifferentials;
};

const comparePuzzleMoves = (data, state) => {
    let currentScore = 0;
    let lastScore = 0;
    let currentWordPlayed = get(data, 'data.' + state.channel + '.boarddata.wordsplayed');
    let lastWordPlayed = get(data, 'data.' + state.channel + '.boarddata.lastwordplayed');
    let currentRating = get(data, 'data.' + state.channel + '.rating');

    let currentWordPlayedStr = '';
    let lastWordPlayedStr = '';

    //For current player calculation and string formation
    for (let i = 0; i < currentWordPlayed.length; i++) {
        let element = currentWordPlayed[i];
        let elementArr = element.split(',');
        let score = elementArr[2];
        let word = elementArr[1];

        currentWordPlayedStr = currentWordPlayedStr + '\n' + word.toUpperCase() + ' - ' + score;
        currentScore = parseInt(currentScore) + parseInt(score);
    }
    //For last player calculation and string formation
    for (let i = 0; i < lastWordPlayed.length; i++) {
        let element = lastWordPlayed[i];
        let elementArr = element.split(',');
        let score = elementArr[2];
        let word = elementArr[1];
        lastWordPlayedStr = lastWordPlayedStr + '\n' + word.toUpperCase() + ' - ' + score;
        lastScore = parseInt(lastScore) + parseInt(score);
    }
    let rating = state.rating;
    let changeInRating = isNaN(rating) || rating === null ? undefined : currentRating - rating;
    changeInRating = changeInRating > 0 ? '+' + changeInRating : changeInRating;
    rating = currentRating;
    return {
        currentScore,
        lastScore,
        currentWordPlayedStr,
        lastWordPlayedStr,
        currentRating,
        changeInRating,
        rating,
    };
};

const getRanking = (data) => {
    return get(data, 'data.rank');
};

const updateCompleteData = (messageObj, state) => {
    log.info('in HintSection, in GameReducer, in updateCompleteData, messageObj is:\n' + JSON.stringify(messageObj, null, 2));

    let { data, action } = messageObj || {};

    let isAnalysing = get(messageObj, 'isAnalysing');
    let moveListCompleteData =
        Config.SET_PLAYER_COUNT_ACTIONS.includes(action) || isAnalysing ? [] : state.moveListCompleteData || [];
    let wordsPlayed = get(data, state.channel + '.boarddata.wordsplayed') || get(messageObj, 'wordsPlayed') || [];
    let playersInData =
        get(data, state.channel + '.players') ||
        get(messageObj, 'players') ||
        get(data, 'data.' + state.channel + '.players') ||
        [];
    let players = (Config.SET_PLAYER_COUNT_ACTIONS.includes(action) || isAnalysing ? playersInData : state.players) || [];
    let moveTiles = get(data, state.channel + '.boarddata.movetiles') || [];
    let msMoveTiles = get(state, 'msMoveTiles') || moveTiles;

    if (action === Config.SEND_LIVE_GAME_MOVE_DATA_RESPONSE_ACTION) {
        msMoveTiles.push(moveTiles[0]);
    } else if (action === Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION) {
        let moveTile = lastArrayElement(moveTiles);
        if (moveTile.length > 0) {
            let index = msMoveTiles.findIndex((move) => isEqual(moveTile, move));
            if (index >= 0) msMoveTiles.splice(index, 1);
        }
    }
    state.msMoveTiles = msMoveTiles;

    // Individual array for players and score insertion accordingly
    for (let i = 0; i < players.length; i++) {
        let player = players[i];
        let playerInData = (playersInData || []).find((playerInPlayersInData) => playerInPlayersInData.pid === player.pid);

        if (!!playerInData) {
            if (!player.scoresInGame || isAnalysing) player.scoresInGame = [];

            player.current_score =
                get(
                    ((playersInData || []).find((playerInPlayersInData) => playerInPlayersInData.pid === player.pid),
                    'current_score')
                ) || player.current_score;
            if (!isAnalysing) {
                if (get(playerInData, 'timeleft')) {
                    player.timeleftArr = [Number(get(playerInData, 'timeleft'))];
                    player.lastTimeTimeLeftArrUpdated = Date.now();
                }
            }
            Object.assign(player, playerInData);
        }
        player.turnStartTime = Date.now();
    }

    log.info('in HintSection, in GameReducer, in updateCompleteData, messageObj is:\n' + JSON.stringify(messageObj, null, 2));

    if (
        [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL, Config.GAME_TYPE_SOLO].includes(
            state.game_type
        ) ||
        (!state.already_attempted && isEmpty(moveListCompleteData))
    ) {
        (wordsPlayed || []).forEach((move) => {
            let moveWordPlayedElementArr = JSON.stringify(move).split(',');
            let swapTileCount = moveWordPlayedElementArr[3] === 's' ? moveWordPlayedElementArr[1].length : undefined;
            let score = GameBoardUtils.getPlayerMoveScoreOnAMove(move);
            let bestScore = GameBoardUtils.getBestScoreOnAMove(move);
            let words = GameBoardUtils.getPlayerWordsPlayedOnAMove(move, false, false);
            let pid = GameBoardUtils.getPidFromMove(move);
            let player = players.find((player) => player.pid === pid);
            let arrLength = player.scoresInGame.length;

            if (action === Config.SEND_EMAIL_GAME_CHALLENGE_MOVE_DATA_ACTION && moveTiles[0] && moveTiles[0].length > 0) {
                let moveListLastIndex = moveListCompleteData.length - 1;
                if (moveListCompleteData[moveListLastIndex].hasOwnProperty(pid)) {
                    delete moveListCompleteData[moveListLastIndex][pid];
                }

                player.scoresInGame.pop();
            }

            let totalScore = arrLength > 0 ? Number(lastArrayElement(player.scoresInGame) ?? 0) + Number(score) : Number(score);
            player.scoresInGame.push(totalScore ?? 0);
            moveListCompleteData[player.scoresInGame.length - 1] = {
                ...(moveListCompleteData[player.scoresInGame.length - 1] || {}),
                [pid]: {
                    score,
                    bestScore,
                    words,
                    player,
                    totalScore,
                    swapTileCount,
                },
            };
        });
    }
    log.info(
        'in HintSection, in GameReducer, in updateCompleteData, moveListCompleteData is:\n' +
            JSON.stringify(moveListCompleteData, null, 2)
    );
    return { players, moveListCompleteData };
};

const displayChallengeScore = ({ state, data, forNext, isArchivedGame }) => {
    let challengeScore = '';

    if (forNext || isArchivedGame) {
        challengeScore = String(isArchivedGame ? getSelfArchivedGameScore(data, state) : getCurrentScore(data, state));
        state.myScore = challengeScore;
    }

    if (!forNext) {
        challengeScore = getLastPlayerScore(data, state).toString(); //required to parse to string for view
        let lastPlayerLetterCount = getLastPlayerLetterCount(data, state);
        lastPlayerLetterCount = lastPlayerLetterCount + (lastPlayerLetterCount === 1 ? ' tile' : ' tiles');
        challengeScore = challengeScore + ' ( ' + lastPlayerLetterCount + ' )';
        if (!isArchivedGame) state.myScore = '0';
        state.scoreToBeat = challengeScore;
    }

    if (!forNext || isArchivedGame) {
        let bestMoveScoreText = isArchivedGame ? getBestMoveScoreForArchivedPuzzle(data, state) : getBestMoveScore(data, state);
        let bestMoveLetterCount = isArchivedGame
            ? getBestMoveLetterCountForArchivedPuzzle(data, state)
            : getBestMoveLetterCount(data, state);
        let bestMoveLetterCountStr = bestMoveLetterCount + (bestMoveLetterCount === 1 ? ' tile' : ' tiles');
        bestMoveScoreText = bestMoveScoreText + ' ( ' + bestMoveLetterCountStr + ' )';
        state.aiScore = !isNaN(bestMoveLetterCount) && bestMoveLetterCount != null ? bestMoveScoreText : challengeScore;
    }
};

const getValidityValue = (data) =>
    !(data.err === null && data.err === undefined && data.error === null && data.error === undefined) &&
    (Number(data.err) === 0 || Number(data.error) === 0);
const goToAnalysePosition = (state, position) => {
    state.currPosition = position;
    state.currentTurn = GameBoardUtils.getPidFromMove(state.movesObjs[position].wordsPlayed);

    let wordsPlayedArr = [];
    for (let i = 0; i <= position; i++) {
        let wordsPlayedInMove = state.movesObjs[i].wordsPlayed;
        wordsPlayedArr.push(wordsPlayedInMove);
    }
    let res = updateCompleteData(
        {
            wordsPlayed: wordsPlayedArr,
            players: state.players,
            isAnalysing: true,
        },
        state
    );
    state.moveListCompleteData = res.moveListCompleteData;
    state.players = res.players;
    state.showingAnalyseMove = true;
};

const getMoveTiles = (state, result) => {
    let data = get(result, 'data.' + get(state, 'channel') + '.boarddata.movetiles');
    let moveTilesArr = [];
    if (data) {
        if (!is2dArray(data)) data = [data];
        //MoveTiles array creation
        for (let i = 0; i < data.length; i++) {
            let element = data[i];
            GameBoardUtils.appendDataToMoveTileArr(moveTilesArr, element);
        }
    }
    return moveTilesArr;
};

const getMoveTilesForArchivedGame = (state, result) => {
    let movetiles = get(result, 'data.' + get(state, 'channel') + '.boarddata.movetiles') || [];
    let data = movetiles.splice(0, movetiles.length - 1);
    let ret = GameBoardUtils.appendDataToMoveTileArr([], data.flat());
    return ret;
};

const getVowelCount = (state) => {
    let letterDistribution = state.letterDistribution;
    let unplacedVowels = letterDistribution.filter((tile) => 'AEIOU'.includes(tile.letter) && !tile.placed);
    return unplacedVowels.length;
};

const getUnseenTileCount = (state) => {
    let letterDistribution = state.letterDistribution;
    let unplacedTiles = letterDistribution.filter((tile) => !tile.placed);
    return unplacedTiles.length;
};

export const getTiles = ({ globalState, gameReducerState, includeEmptySpace = false, forRendering = false } = {}) => {
    let currentRackArr = [];
    if (!gameReducerState) gameReducerState = get(globalState, 'game');
    if (get(gameReducerState, 'showingAnalyseMove')) {
        let movesObjs = get(gameReducerState, 'movesObjs');
        let currentPosition = get(gameReducerState, 'currPosition');
        let moveObj = (movesObjs || [])[currentPosition];
        currentRackArr = cloneDeep(get(moveObj, 'rackArr'));
    } else if (get(globalState, 'tiles.rackArr') && get(globalState, 'tiles.rackArr').length > 0) {
        currentRackArr = cloneDeep(get(globalState, 'tiles.rackArr'));
    } else {
        let players = get(gameReducerState, 'players');
        let selfPid = get(gameReducerState, 'pid');
        let currentTurn = get(gameReducerState, 'currentTurn');

        let pidToUse = isString(selfPid) && selfPid.length > 0 ? selfPid : currentTurn;
        let player = (players || []).find((player) => player.pid === pidToUse);

        currentRackArr = [];
        if (player) {
            for (let i = 0; i < player.currentrack.length; i++) {
                let letter = player.currentrack.charAt(i);
                currentRackArr.push(GameBoardUtils.tileCreation(letter));
            }
        }
    }
    let nonNullTiles = currentRackArr.filter(Boolean);
    if (includeEmptySpace) {
        return nonNullTiles;
    }
    let actualTiles = nonNullTiles.filter((tile) => !tile.isEmptySpace);
    if (forRendering && actualTiles.length > 2) return nonNullTiles;
    return actualTiles;
};

export const getDistribution = (globalState, state) => {
    let moveTiles = (get(state, 'msMoveTiles') || []).flat(8);

    let distributionFromMoveTiles = {};

    moveTiles.forEach((tileStr) => {
        let tileParts = tileStr.split(',');
        let searchStr = StringUtils.isUpperCase(tileParts[3]) ? tileParts[3] : '*';
        distributionFromMoveTiles[searchStr] = (distributionFromMoveTiles[searchStr] || 0) + 1;
    });

    let tiles = getTiles({ globalState, gameReducerState: state });

    tiles.forEach((tile) => {
        let searchStr = !!tile.letter ? tile.letter : '*';
        distributionFromMoveTiles[searchStr] = (distributionFromMoveTiles[searchStr] || 0) + 1;
    });

    return distributionFromMoveTiles;
};

export const getLetterDistribution = (globalState, state) => {
    let currentTilesData = getDistribution(globalState, state);
    let tileSetStr = '';
    switch (get(state, 'board_type')) {
        case 'normal': {
            switch (getDictionaryDetails(get(state, 'dic')).lang) {
                case 'us_en':
                case 'uk_en': {
                    tileSetStr = get(state, 'tileCountInfo') || GameBoardUtils.InitialTilesUSUK;
                    break;
                }
                case 'fr': {
                    tileSetStr = get(state, 'tileCountInfo') || GameBoardUtils.InitialTilesFr;
                    break;
                }
                case 'it': {
                    tileSetStr = get(state, 'tileCountInfo') || GameBoardUtils.InitialTilesIt;
                    break;
                }
                default:
                    throw new Error('Invalid Dictionary Code');
            }
            break;
        }
        case 'super': {
            tileSetStr = get(state, 'tileCountInfo') || GameBoardUtils.InitialTilesSuperUSUKFrIt;
            break;
        }
        default:
            throw new Error('Invalid board type');
    }
    let letterDistribution = stringToLetterDistribution(tileSetStr);
    let letterDistributionKeys = Object.keys(letterDistribution)
        .sort((a, b) => /[A-Za-z]/.test(a) - /[A-Za-z]/.test(b) || b.charCodeAt(0) - a.charCodeAt(0))
        .reverse();
    let finalDistribution = [];
    let letterCounter = 1;
    for (let i = 0; i < letterDistributionKeys.length; i++) {
        let letter = letterDistributionKeys[i];
        let totalCount = letterDistribution[letter];
        let placedCount = currentTilesData[letter] || 0;
        let unplacedCount = totalCount - placedCount;
        for (let j = 0; j < totalCount; j++) {
            finalDistribution.push({
                letter,
                placed: !(j < unplacedCount),
                id: letterCounter++,
            });
        }
    }
    return finalDistribution;
};

export const stringToLetterDistribution = (tileSetStr = '') => {
    let freq = {};
    for (let i = 0; i < tileSetStr.length; i++) {
        let character = tileSetStr.charAt(i);
        freq[character] = (freq[character] || 0) + 1;
    }
    return freq;
};

const getRequestUrlType = (gameType) => {
    switch (gameType) {
        case 'email':
        case 'puzzle':
            return 'rest_api';

        case 'live_room':
        case 'blitz':
        case 'solo':
            return 'web_socket';
    }
};

const gameReducer = (state = INITIAL_STATE, action) => {
    let messageObj = get(action, 'payload');
    let globalState = get(action, 'globalState');
    state = cloneDeep(state);
    let gameHasEnded = false;
    switch (action.type) {
        case ActionIdentifiers.RELOAD_APP: {
            state = cloneDeep(state);
            let firstRun = get(messageObj, 'firstRun');
            if (!firstRun) {
                state.pid = get(messageObj, 'pid');
                state.gid = get(messageObj, 'gid');
                state.dic = get(messageObj, 'dic') || state.dic;
                state.onProNext = get(messageObj, 'caller') === 'onGoToNextLocation';
            }
            state.showingAnalyseMove = false;
            state.showPlayButtonSpinnerData = undefined;
            state.playButtonScoreText = undefined;
            state.winner = undefined;
            state.brdtype = undefined;
            state.inGameMode = undefined;
            state.gameDeleterGuid = undefined;
            state.gameover_reason = undefined;
            state.gameHasEnded = undefined;
            state.gameRestartData = get(messageObj, 'gameRestartData');
            state.showRevealSolutionData = undefined;
            state.msMoveTiles = undefined;
            state.tabWasSetByClicking = false;
            state.letterDistribution = undefined;
            state.unseenTileCount = undefined;
            state.unseenVowelCount = undefined;
            state.allRegularPlayedWords = {};
            state.players = undefined;
            state.gameBoardSideLayoutActiveTab = getDefaultTab(globalState);
            state.emailGameNotes = undefined;
            state.board_type = undefined;
            state.board_size = 15;
            break;
        }
        case ActionIdentifiers.GAME_MOVE_FURTHER_DATA_SHOW_LOADER: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.gameMoveFurtherDataShowLoader = true;
            break;
        }
        case ActionIdentifiers.GAME_MOVE_FURTHER_DATA_HIDE_LOADER: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.gameMoveFurtherDataShowLoader = false;
            break;
        }
        case ActionIdentifiers.GAME_HAS_ENDED:
        case ActionIdentifiers.GAME_SOLO_GAME_SEND_GAME_START_DATA:
        case ActionIdentifiers.GAME_STARTED:
        case ActionIdentifiers.GAME_MOVE: {
            state = cloneDeep(state);

            log.info('in GameReducer, state.gameover_reason was: ' + state.gameover_reason);

            state.board_type = get(messageObj, 'data.' + state.channel + '.boardtype')
                ? get(messageObj, 'data.' + state.channel + '.boardtype') === 'S'
                    ? 'super'
                    : 'normal'
                : state.board_type;

            switch (state.board_type) {
                case 'normal': {
                    state.board_size = 15;
                    state.rack_size = 8;
                    state.total_tile_count = 89;
                    break;
                }
                case 'super': {
                    state.board_size = 21;
                    state.rack_size = 8;
                    state.total_tile_count = 178;
                    break;
                }
            }

            state.gid =
                get(messageObj, state.channel + '.gid') || get(messageObj, 'data.' + state.channel + '.gid') || state.gid;

            state.gametype = get(messageObj, 'data.' + state.channel + '.gametype') || state.gametype;

            let players =
                get(messageObj, state.channel + '.players') ||
                get(messageObj, 'data.' + state.channel + '.players') ||
                get(messageObj, 'data.players') ||
                state.players ||
                [];
            let myself = players.find((player) => player.guid === state.guid);

            state.pid = get(myself, 'pid') || state.pid;

            state.gameover_reason =
                ((get(messageObj, 'action') || '').includes(Config.DELETE_GAME) ? 'DELETE' : undefined) ||
                ((get(messageObj, 'action') || '').includes(Config.RESIGN_GAME) ? 'RESIGN' : undefined) ||
                state.gameover_reason;

            state.gameover_reason =
                get(messageObj, 'gameover_reason') ||
                get(messageObj, 'data.gameover_reason') ||
                get(messageObj, 'data.' + get(state, 'channel') + '.gameover_reason') ||
                state.gameover_reason;

            log.info('in GameReducer, state.gameover_reason is: ' + state.gameover_reason);

            log.info('GameReducer: ' + action.type);

            if ([ActionIdentifiers.GAME_HAS_ENDED].includes(action.type)) {
                gameHasEnded = true;
                state.playButtonScoreText = undefined;
                if (!get(state, 'pid') && [Config.GAME_TYPE_LIVE_GAME].includes(state.game_type)) {
                    state.observers = (state.observers || []).filter((guid) => !(guid === state.guid));
                }
                state.gameDeleterGuid =
                    get(messageObj, 'data.guid') ||
                    get(
                        (state.players || []).find((player) => get(player, 'resigned') === 'y'),
                        'guid'
                    ) ||
                    state.gameDeleterGuid;
                log.info('in GameReducer, in GAME_HAS_ENDED case, state.gameDeleterGuid is: ' + state.gameDeleterGuid);
                let player = state.players.find((playerInStatePlayers) => playerInStatePlayers.guid === state.gameDeleterGuid);
                log.info('in GameReducer, in GAME_HAS_ENDED case, player was: ' + JSON.stringify(player, null, 2));
                if (player) {
                    player.reason = state.gameover_reason;
                    player.deleted = true;
                }
                log.info('in GameReducer, in GAME_HAS_ENDED case, player is: ' + JSON.stringify(player, null, 2));
            }

            state.gametypeMode =
                get(messageObj, get(state, 'channel') + '.gametype') ||
                get(messageObj, 'data.' + get(state, 'channel') + '.gametype') ||
                state.gametypeMode;
            log.info('in Board, about to make moveTilesArr 2, state.gametypeMode is now: ' + state.gametypeMode);

            log.info('in GameReducer, state.game_type is: ' + state.game_type);
            if (
                [
                    ActionIdentifiers.GAME_HAS_ENDED,
                    ActionIdentifiers.GAME_SOLO_GAME_SEND_GAME_START_DATA,
                    ActionIdentifiers.GAME_STARTED,
                ].includes(action.type)
            ) {
                log.info('in GameReducer, in GAME_STARTED,etc  case');
                state.sourceType = get(messageObj, 'data.' + state.channel + '.source');
                state.lastMoveWordPlayedData = '';
                let players =
                    get(messageObj, state.channel + '.players') || get(messageObj, 'data.' + state.channel + '.players') || [];
                let myself = players.find((player) => player.guid === state.guid);
                if (!get(myself, 'pid') && [Config.GAME_TYPE_LIVE_GAME].includes(state.game_type)) {
                    state.gameBoardSideLayoutActiveTab = DimensionUtils.isMobile()
                        ? 4
                        : GameBoardUtils.isChallengeModeStr(state.gametypeMode)
                        ? 2
                        : 1;
                    state.tabWasSetByClicking = false;
                } else if (
                    get(myself, 'pid') &&
                    [ActionIdentifiers.GAME_HAS_ENDED].includes(action.type) &&
                    [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_EMAIL].includes(state.game_type)
                ) {
                    state.gameBoardSideLayoutActiveTab = DimensionUtils.isMobile() ? 4 : 0;
                    state.tabWasSetByClicking = false;
                } else if (
                    action.type === ActionIdentifiers.GAME_HAS_ENDED &&
                    [Config.GAME_TYPE_BLITZ].includes(state.game_type)
                ) {
                    state.gameBoardSideLayoutActiveTab = DimensionUtils.isMobile() ? 4 : 2;
                    state.tabWasSetByClicking = false;
                } else if ([ActionIdentifiers.GAME_STARTED].includes(action.type)) {
                    log.info('in GameReducer, in GAME_STARTED case');
                    switch (state.game_type) {
                        case Config.GAME_TYPE_EMAIL:
                        case Config.GAME_TYPE_LIVE_GAME:
                            state.gameBoardSideLayoutActiveTab = DimensionUtils.isMobile()
                                ? 4
                                : !!state.pid
                                ? 0
                                : GameBoardUtils.isChallengeMode() || [Config.GAME_TYPE_SOLO].includes(state.game_type)
                                ? 2
                                : 1;
                            state.tabWasSetByClicking = false;
                            break;
                        case Config.GAME_TYPE_SOLO:
                            state.gameBoardSideLayoutActiveTab = DimensionUtils.isMobile() ? 4 : 1;
                            state.tabWasSetByClicking = false;
                            break;
                        case Config.GAME_TYPE_PUZZLE:
                        case Config.GAME_TYPE_BLITZ:
                            state.gameBoardSideLayoutActiveTab = 2;
                            state.tabWasSetByClicking = false;
                            break;
                    }
                    log.info(
                        'in GameReducer, in GAME_STARTED  case, state.gameBoardSideLayoutActiveTab is: ' +
                            state.gameBoardSideLayoutActiveTab
                    );
                }
            }
            if ([ActionIdentifiers.GAME_STARTED].includes(action.type)) {
                state.brdtype = get(messageObj, 'data.' + state.channel + '.boarddata.brdtype');
            }
            state.action = get(messageObj, 'action');
            state.hintWordList = undefined;
            state.hasActiveGame = true;
            state.moveStrengthPercentage = undefined;

            let already_attempted = get(state, 'already_attempted');

            state.moveTilesArr = already_attempted
                ? getMoveTilesForArchivedGame(state, messageObj)
                : getMoveTiles(state, messageObj);

            displayChallengeScore({
                state,
                data: messageObj,
                forNext: get(action, 'payload.forNext') !== undefined ? get(action, 'payload.forNext') : false,
                isArchivedGame:
                    get(action, 'payload.isArchivedGame') !== undefined ? get(action, 'payload.isArchivedGame') : false,
            });

            state.puzzle_id = get(messageObj, 'data.' + state.channel + '.puzzleid');

            //EXTRACTING SOME INFO ABOUT THE BOARD
            let customBoardInfo = [];
            if (get(messageObj, 'data.' + state.channel + '.boarddes')) {
                let boarddes = get(messageObj, 'data.' + state.channel + '.boarddes.boarddes'),
                    bdsqval = get(messageObj, 'data.' + state.channel + '.boarddes.bdsqval'),
                    tile_count = get(messageObj, 'data.' + state.channel + '.boarddes.tile_count');

                let board_size = state.board_size;

                (bdsqval.split('|') || []).forEach((val) => {
                    let valInfoArr = val.split(',');
                    if (valInfoArr[0] !== 'W') {
                        let pos = [];
                        for (let i = 0; i < boarddes.length; i++) {
                            if (boarddes[i] === valInfoArr[0]) {
                                let x = i % board_size;
                                let y = Math.floor(i / board_size);
                                pos.push([x, y]);
                            }
                        }
                        customBoardInfo.push({
                            type: valInfoArr[1],
                            positions: pos,
                        });
                    }
                });

                let tileCountInfo = '';
                (tile_count.split('|') || []).forEach((tileInfo) => {
                    let tileInfoArr = tileInfo.split(',');
                    tileCountInfo += (tileInfoArr[0] === 'blank' ? '*' : tileInfoArr[0]).repeat(tileInfoArr[1]);
                });
                let letterScoreInfo = get(messageObj, 'data.' + state.channel + '.boarddes.tilevalues');

                state.tileCountInfo = tileCountInfo;
                state.letterScoreInfo = letterScoreInfo;
            }
            state.customBoardInfo = customBoardInfo.length > 0 ? customBoardInfo : undefined;

            //EXTRACTING SOME BASIC INFO ABOUT THE TURN, ETC
            let currentTurn =
                get(messageObj, state.channel + '.current_turn') ??
                get(messageObj, 'data.' + state.channel + '.current_turn') ??
                get(messageObj, 'data.current_turn');

            state.currentTurn = currentTurn;

            let dic = get(messageObj, state.channel + '.dic') || get(messageObj, 'data.' + state.channel + '.dic') || state.dic;
            if (dic) state.dic = dic;

            let wordsPlayed =
                get(messageObj, state.channel + '.boarddata.wordsplayed') ||
                get(messageObj, 'data.' + state.channel + '.boarddata.wordsplayed') ||
                [];

            state.tilesInBag =
                get(messageObj, state.channel + '.tilesinbag') ||
                get(messageObj, 'data.' + state.channel + '.tilesinbag') ||
                state.tilesInBag;

            if (
                (!state.already_attempted ||
                    [Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ, Config.GAME_TYPE_EMAIL].includes(state.game_type)) &&
                wordsPlayed &&
                wordsPlayed.length > 0
            ) {
                let lastWordPlayedElement = wordsPlayed[wordsPlayed.length - 1];
                state.lastMoveWordPlayedData = GameBoardUtils.getPlayerWordsPlayedOnAMove(
                    lastWordPlayedElement,
                    false,
                    false
                ).toUpperCase();
            }

            let res = updateCompleteData(messageObj, state);
            state.players = res.players;

            log.info('in GameReducer, state.players is:\n' + JSON.stringify(state.players, null, 2));

            let lastUpdate =
                get(messageObj, state.channel + '.lastupdate') || get(messageObj, 'data.' + state.channel + '.lastupdate') || 0;
            (state.players || []).forEach((player) => {
                if (player.availablity_status === 'Offline' && player.pid === currentTurn)
                    state['start_time_' + player.guid] = Number(lastUpdate) * 1000;
                else state['start_time_' + player.guid] = undefined;
            });

            state.moveListCompleteData = res.moveListCompleteData;

            log.info(
                'in reducer before trialone, in Board, in startLiveGame, moveTilesArr is:\n' +
                    JSON.stringify(messageObj, null, 2)
            );
            // Solo game requirement [new game, gamefeed, quick game, slot game]
            state.timeGame = players.length > 0 ? get(players[0], 'timeleft') : '-1';

            //move, swap, pass
            let winner = get(messageObj, 'data.' + state.channel + '.winner');
            state.winner = winner || state.winner;

            log.info('in Board, in GameReducer, state.winner is:\n' + JSON.stringify(state.winner, null, 2));

            let selfObjectInPlayers = (state.players || []).find((player) => player.guid === state.guid);

            state.gameHasEnded =
                get(messageObj, 'isSelfResign') ||
                isArray(state.winner) ||
                !currentTurn ||
                ([Config.GAME_TYPE_LIVE_GAME, Config.GAME_TYPE_BLITZ].includes(state.game_type) &&
                    get(selfObjectInPlayers, 'resigned') === 'y') ||
                ([Config.GAME_TYPE_BLITZ].includes(state.game_type) &&
                    [ActionIdentifiers.GAME_HAS_ENDED].includes(action.type)) ||
                state.gameHasEnded;

            log.info('in Board, in GameReducer, state.gameHasEnded is:\n' + JSON.stringify(state.gameHasEnded, null, 2));
            if (state.game_type === Config.GAME_TYPE_BLITZ && state.gameHasEnded) {
                state.blitz_players = get(action.payload, 'data.jndplys') || [];
            }
            //Solo game requirement end
            let trialOneQueryString = get(state, 'channel') + '.boarddata.movetiles';

            let trialOne = get(messageObj, trialOneQueryString);
            log.info('in reducer trialone, in Board, in startLiveGame, moveTilesArr is:\n' + JSON.stringify(trialOne, null, 2));
            let trialTwoQueryString = 'data.' + get(state, 'channel') + '.boarddata.movetiles';
            let trialTwo = get(messageObj, trialTwoQueryString);
            log.info('in reducer trialTwo, in Board, in startLiveGame, moveTilesArr is:\n' + JSON.stringify(trialTwo, null, 2));
            state.moveTiles = trialOne || trialTwo || state.moveTiles || [];
            log.info('in reducer, in Board, in startLiveGame, moveTilesArr is:\n' + JSON.stringify(state.moveTiles, null, 2));
            state.wordsPlayed =
                get(messageObj, get(state, 'channel') + '.boarddata.wordsplayed') ||
                get(messageObj, 'data.' + get(state, 'channel') + '.boarddata.wordsplayed') ||
                state.wordsPlayed ||
                [];

            state.gametype =
                get(messageObj, state.channel + '.rated') ||
                get(messageObj, 'data.' + state.channel + '.rated') ||
                get(messageObj, state.channel + '.livegame.rated') ||
                get(messageObj, 'data.' + state.channel + '.livegame.rated') ||
                state.gametype;

            log.info('in GameReducer, state.gametype is: ' + state.gametype);

            log.info('in Board, about to make moveTilesArr 2, messageObj is:\n' + JSON.stringify(messageObj, null, 2));

            state.letterDistribution = getLetterDistribution(globalState, state);
            state.unseenTileCount = getUnseenTileCount(state);
            state.unseenVowelCount = getVowelCount(state);

            break;
        }
        case ActionIdentifiers.GAME_WORD_DEFINITIONS: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.gameMoveFurtherDataShowLoader = false;
            state.lastMoveWords = get(action, 'payload.lastMoveWords');
            state.lastMoveWordsArr = get(action, 'payload.lastMoveWordsArr');
            break;
        }
        case ActionIdentifiers.GAME_PUZZLE_MOVE_SENT_SUCCESSFULLY:
        case ActionIdentifiers.GAME_PUZZLE_PASS_SENT_SUCCESSFULLY:
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            displayChallengeScore({
                state,
                data: action.payload,
                forNext: true,
                isArchivedGame: false,
            });
        case ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.differentialsList =
                (action.type === ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED
                    ? getScoreDifferentialsForLastGames(action.payload)
                    : state.differentialsList) || state.differentialsList;
            if (action.type !== ActionIdentifiers.GAME_PUZZLE_LAST_GAMES_STATUSES_RETRIEVED) {
                let resultObj = comparePuzzleMoves(action.payload, state);
                let currentScore = resultObj.currentScore;
                let lastScore = resultObj.lastScore;
                let scoreDifferential = currentScore - lastScore;
                state.differentialsList.unshift({
                    scoreDifferential,
                    puzzleid: state.puzzle_id,
                });
            }
            let oldRating = state.puzzleRating;
            state.puzzleRating = parseInt(getRating(action.payload, state)); //required to parse to string for view
            if (!isNaN(oldRating) && oldRating != null) {
                if (oldRating < state.puzzleRating) {
                    state.changeInRating = 'increase';
                } else {
                    state.changeInRating = 'decrease';
                }
            }
            break;
        }
        case ActionIdentifiers.GAME_PUZZLE_PUZZLE_RANKING_RETRIEVED: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.puzzleRanking = parseInt(getRanking(action.payload)); //required to parse to string for view
            break;
        }

        case ActionIdentifiers.GAME_RESOURCE_PANEL_WORD_VALIDITY: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.resourcePanelWordValid = action.payload && getValidityValue(action.payload);
            break;
        }

        case ActionIdentifiers.GAME_PLAY_BUTTON_WORD_VALIDITY: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.playButtonWordValid = action.payload && getValidityValue(action.payload);
            if (!!state.playButtonWordValid) {
                let currentScore = Math.round(Number((state.playButtonScoreText || '+0').substring(1)));
                state.moveStrengthPercentage = Math.min((currentScore / state.maxScore) * 100, 100);
            } else {
                state.moveStrengthPercentage = undefined;
            }
            state.moveStrengthPercentage = !!state.playButtonWordValid ? state.moveStrengthPercentage : undefined;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_ROOM_ADD_OBSERVER: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let guids = get(action.payload, 'data.guids');
            state.observers = state.observers || [];
            (guids || []).forEach((guid) => !state.observers.includes(guid) && state.observers.push(guid));
            break;
        }

        case ActionIdentifiers.GAME_LIVE_ROOM_REMOVE_OBSERVER: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let guids = get(action.payload, 'data.guids');
            state.observers = (state.observers || []).filter((guid) => !guids.includes(guid));
            break;
        }

        case ActionIdentifiers.GAME_HAS_ACTIVE_GAME_EVENT: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.hasActiveGame = false;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_START_NEW_GAME_INVITATION_RECEIVED: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            SoundUtils.messageSound({
                playForSure: isSoundsEnabled(globalState),
            });
            state.gameInvitationObject = action.payload;
            log.info(
                "in GameReducer, in ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE case, get(messageObj, 'data.livegame.rated') is: " +
                    get(messageObj, 'livegame.rated')
            );
            state.gametype = get(messageObj, 'livegame.rated') || get(messageObj, 'data.livegame.rated') || state.gametype;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_CLEAR_INVITATION: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.gameInvitationObject = null;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_GET_ONLINE_STATUS: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let data = swap(action.payload);
            let players = state.players || [];
            players.forEach((player) => {
                let newStatus = data[player.guid];
                if (newStatus) {
                    player.availablity_status = newStatus === 'online' ? 'Online' : 'Offline';

                    if (player.pid === state.currentTurn) {
                        if (player.availablity_status === 'Offline') {
                            state['start_time_' + player.guid] =
                                Date.now() - (get(action.globalState, 'confg.server_time_diff') || 0);
                        } else {
                            state['start_time_' + player.guid] = undefined;
                        }
                    }
                }
            });
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_CANCEL_INVITATION: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let secret = get(action.payload, 'secret');
            let secretInState = get(state, 'currentlyViewingHostedGame.secret');
            if (secret === secretInState) {
                state.currentlyViewingHostedGame = null;
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_GAME_MORE_TIME_REQUEST_SUCCESSFUL: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let message = action.payload;
            let opponentGuid = get(message, 'data.other');
            let moreTimeToAddInTimer = get(message, 'data.time') || 0;
            state.players = (state.players || []).map((player) => {
                player = cloneDeep(player);
                if (!player.viewBoardData && player.guid === opponentGuid) {
                    player.lastTimeTimeLeftArrUpdated = Date.now();
                    player.timeleftArr.push(Number(moreTimeToAddInTimer));
                }
                return player;
            });
            return state;
        }

        case ActionIdentifiers.GAME_SET_PLAYER_COUNT: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            let messageObj = action.payload;
            let players =
                get(messageObj, state.channel + '.players') || get(messageObj, 'data.' + state.channel + '.players') || [];
            state.playersCount = players.length;
            break;
        }

        case ActionIdentifiers.GAME_SET_NOTES_STARTED: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.savingEmailGameNotes = true;
            break;
        }
        case ActionIdentifiers.GAME_SET_NOTES_FAILED:
        case ActionIdentifiers.GAME_EMAIL_SET_GAME_NOTES: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.savingEmailGameNotes = false;
        }
        case ActionIdentifiers.GAME_EMAIL_GET_GAME_NOTES: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.emailGameNotes = action.payload || state.emailGameNotes;
            break;
        }

        case ActionIdentifiers.GAME_SOLO_GAME_CURRENT_HINT_DATA: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.currHintData = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_ANALYSE_DATA_READY: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.movesObjs = get(action, 'payload.movesObjs');
            state.players = get(action, 'payload.players');
            goToAnalysePosition(state, 0);
            break;
        }

        case ActionIdentifiers.GAME_ANALYSE_CURRENT_POSITION_CHANGED: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            goToAnalysePosition(state, get(action, 'payload.currPosition'));
            break;
        }

        case ActionIdentifiers.GAME_CHALLENGE_GAME_SET_PREVIOUS_TURN: {
            state = cloneDeep(state);
            state.previousTurn = state.currentTurn;
            log.info(
                `in startlivegame2, in Board, in GameReducer, currentTurn is ${state.currentTurn}, previousTurn is ${state.previousTurn}`
            );
            break;
        }

        case ActionIdentifiers.GAME_HINT_WORD_LIST_READY: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.hintWordList = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_SET: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            if (isNumber(action.payload)) {
                state.gameBoardSideLayoutActiveTab = action.payload;
                state.tabWasSetByClicking = false;
            } else if (isObject(action.payload)) {
                state.gameBoardSideLayoutActiveTab = get(action.payload, 'value');
                state.tabWasSetByClicking = !DimensionUtils.isMobile() && get(action.payload, 'fromClick');
            }
            state.resourcePanelWordValid = undefined;
            break;
        }

        case ActionIdentifiers.GAME_NORMAL_GAME_OPTIONS_MODAL_GAME_RESTART_DATA_SET: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.gameLiveGameRestartDataSet = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_SOLO_SET_NO_LOGIN_DATA: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.soloDemoAcc = get(messageObj, 'soloDemoAcc');
            state.archiveGameView = get(messageObj, 'archiveGameView');
            state.guid = get(messageObj, 'guid') || state.guid;
            state.uuid = get(messageObj, 'uuid') || state.uuid;
            break;
        }

        case ActionIdentifiers.GAME_PAGE_VISIBILITY_CHANGED: {
            state = cloneDeep(state);
            state.isPageVisible = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_SET_PLAYER_SELF_CURRENT_SCORE: {
            state = cloneDeep(state);
            state.playerSelfCurrentScore = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_SHOW_PLAY_BUTTON_LOADER: {
            state = cloneDeep(state);
            state.showPlayButtonSpinnerData = get(action, 'payload');
            break;
        }

        case ActionIdentifiers.GAME_PLAY_BUTTON_SCORE_TEXT: {
            state = cloneDeep(state);
            state.playButtonScoreText = get(action, 'payload');
            let currentScore = Math.round(Number((state.playButtonScoreText || '+0').substring(1)));
            if (shouldShowMoveStrengthPercentage(state) && isNumber(state.maxScore))
                state.moveStrengthPercentage = Math.min((currentScore / state.maxScore) * 100, 100);
            else state.moveStrengthPercentage = undefined;
            state.showPlayButtonSpinnerData = undefined;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_PAGE_VISIBILITY_CHANGE: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.isPageVisible = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_LANGUAGE_CHANGE: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.lang = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_MOVE_COUNT_SET: {
            state = cloneDeep(state);
            log.info('GameReducer: ' + action.type);
            state.moveCount = action.payload;
            break;
        }

        case ActionIdentifiers.GAME_BOARD_PUZZLE_RECEIVED: {
            state = cloneDeep(state);
            state.gameHasEnded = false;
            break;
        }

        case ActionIdentifiers.GAME_TILE_BEING_DRAGGED: {
            state = cloneDeep(state);
            if (state.showingAnalyseMove) {
                let unset = get(action, 'payload.unset');
                let rack = get(action, 'payload.tiles');
                if (unset && rack) {
                    let movesObjs = state.movesObjs;
                    let currentPosition = state.currPosition;
                    let moveObj = (movesObjs || [])[currentPosition];
                    moveObj.rackArr = rack;
                }
            }
            break;
        }

        case ActionIdentifiers.GAME_SET_INGAME_MODE: {
            state = cloneDeep(state);
            state.inGameMode = get(action, 'payload');
            break;
        }

        case ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE: {
            log.info(
                "in GameReducer, in ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE case, get(action, 'payload') is: " +
                    JSON.stringify(get(action, 'payload'), null, 2)
            );
            let payload = get(action, 'payload');
            if (isBoolean(payload)) {
                state.gametype = payload ? 'y' : 'n';
            } else if (isObject(payload)) {
                state.dic = get(payload, 'dic') || state.dic;
                state.increament = get(payload, 'increament') || state.increament;
                state.duration = get(payload, 'duration') || state.duration;
                log.info(
                    "in GameReducer, in ActionIdentifiers.GAME_REDUCER_UPDATE_GAMETYPE case, get(payload, 'gametype') is: " +
                        get(payload, 'gametype')
                );
                state.gametype = get(payload, 'gametype') || state.gametype;
            }
            break;
        }

        case ActionIdentifiers.GAME_REDUCER_UNSET_GAME_RESTART_DATA: {
            state.gameRestartData = messageObj;
            break;
        }

        case ActionIdentifiers.GAME_LIVE_HOST_ADD_HEAD_TO_HEAD_STATS: {
            state.headToHead = undefined;
            if (get(action, 'payload')) {
                let gameHistories =
                    (get(action, 'payload.history') || []).length >= 15
                        ? (get(action, 'payload.history') || []).slice(
                              (get(action, 'payload.history') || []).length - 15,
                              (get(action, 'payload.history') || []).length
                          )
                        : get(action, 'payload.history') || [];
                if (gameHistories.length < 15) {
                    let blankAppendableArray = [];
                    let numberOfBlanksToBeAppended = 15 - gameHistories.length;
                    for (let i = 0; i < numberOfBlanksToBeAppended; i++) {
                        blankAppendableArray.push({ result: '-' });
                    }
                    gameHistories = [...blankAppendableArray, ...gameHistories];
                }
                state.headToHead = {
                    gameHistories,
                    h2hstats: action.payload.h2hstats,
                    won: action.payload.won,
                    lost: action.payload.lost,
                    draw: action.payload.draw,
                    check: action.payload.check,
                    guidArr: action.payload.guidArr,
                    secret: action.payload.secret,
                };
                if (action.payload.secret) {
                    state.headToHeadArr.push(state.headToHead);
                }
            }
            break;
        }

        case ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME: {
            state.headToHeadArr.push(state.headToHead);
            break;
        }

        case ActionIdentifiers.GAME_LIVE_REQ_JOIN_HOST_GAME_REJECT: {
            log.info('GameReducer: ' + action.type);
            if (get(action.payload, 'timerFinish')) {
                state.headToHeadArr = [];
            } else {
                if (get(action.payload, 'secret')) {
                    remove(state.headToHeadArr, {
                        secret: action.payload.secret,
                    });
                } else {
                    state.headToHeadArr.pop();
                }
            }
            if (state.headToHeadArr.length > 0) {
                state.headToHead = state.headToHeadArr[state.headToHeadArr.length - 1];
            }
            break;
        }

        case ActionIdentifiers.GAME_MOVE_MAX_SCORE_RETRIEVED: {
            state = cloneDeep(state);
            state.maxScore = get(action, 'payload');
            break;
        }

        case ActionIdentifiers.GAME_REDUCER_SET_MOVE_STRENGTH: {
            state = cloneDeep(state);
            state.moveStrengthPercentage = get(action, 'payload');
            break;
        }

        case ActionIdentifiers.REDUCER_ON_TILE_REMOVED: {
            let caller = get(action, 'payload.caller');
            if (caller === 'BoardOnRecallPressWithSoundControl') {
                state.moveStrengthPercentage = undefined;
            }
            break;
        }

        case ActionIdentifiers.UPDATE_TILES_AND_SET_CELL: {
            let caller = get(action, 'payload.caller');
            if (caller !== 'TileOnTileRelease') {
                state.moveStrengthPercentage = undefined;
            }
            break;
        }

        case ActionIdentifiers.GAME_SIDE_LAYOUT_ACTIVE_TAB_RESET: {
            state = cloneDeep(state);
            state.gameBoardSideLayoutActiveTab = ['puzzle'].includes(
                ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type')
            )
                ? 2
                : ['solo'].includes(ConfigurationWrapper.getSpecificLexulousGameConfiguration('game_type'))
                ? 1
                : DimensionUtils.isMobile()
                ? 4
                : !!state.pid
                ? 0
                : GameBoardUtils.isChallengeModeStr(state.gametypeMode)
                ? 2
                : 1;
            break;
        }

        case ActionIdentifiers.GAME_INITIALISE_TILES_FOR_CREATE_BOARD: {
            state = cloneDeep(state);
            state.board_type = 'normal';
            state.board_size = 15;
            break;
        }

        case ActionIdentifiers.CONFIG_SET_MENU_VISIBILITY: {
            if (!get(action, 'payload')) {
                state = cloneDeep(state);
                state.gameBoardSideLayoutActiveTab = getDefaultTab(get(action, 'globalState'));
            }
            break;
        }

        case ActionIdentifiers.GET_ALL_PLAYED_WORD_DEFINATIONS: {
            state = cloneDeep(state);
            state.allRegularPlayedWords = {
                ...state.allRegularPlayedWords,
                ...get(action, 'payload'),
            };
            break;
        }

        case ActionIdentifiers.SET_EMAIL_GAME_DATA: {
            state = cloneDeep(state);
            state.gid = get(action.payload, 'gid');
            state.pid = get(action.payload, 'pid');
            state.dic = get(action.payload, 'dic');
            state.game_type = get(action.payload, 'game_type');
            state.request_url_type = getRequestUrlType(state.game_type);
            state.guid = get(action.payload, 'guid');
            state.uuid = get(action.payload, 'uuid');
            state.isBlindGame = get(action.payload, 'isBlindGame');
            break;
        }
    }

    return { ...state };
};
export default gameReducer;
