import get from 'lodash/get';
import {
    LOBBY_CHAT_MESSAGE,
    ADD_PVT_MESSAGE_KEY,
    SET_ACTIVE_PVT_MESSAGE_KEY,
    REMOVE_PVT_MESSAGE_KEY,
} from '../configs/ActionIdentifiers';
import * as d3 from 'd3-time-format';
import Config from '../configs/Config';
import log from 'loglevel';
import cloneDeep from 'lodash/cloneDeep';
// import { parseEmojis } from '../utils/StringUtils';

const INITIAL_STATE = {
    messages: [],
    pvtMessages: {},
    activePvtMessageKey: undefined,
    lobbyMsgUnreadCount: 0,
};

const formatMessageData = (item) => {
    let formatDate = d3.timeFormat('%I:%M %p');
    item.message.formattedTime = formatDate(new Date());
    let copyFormatDate = d3.timeFormat('%Y-%m-%d %H:%M');
    item.message.copyFormattedTime = copyFormatDate(new Date());
    // item.message.msg = parseEmojis(get(item, 'message.msg'));
    item.message.msg = get(item, 'message.msg');
    return item;
};

const setUnreadCount = ({ state, pvtMessageKey, isLobby }) => {
    if (isLobby && state.activePvtMessageKey) {
        state.lobbyMsgUnreadCount = (state.lobbyMsgUnreadCount || 0) + 1;
    } else if (!isLobby && state.pvtMessages.hasOwnProperty(pvtMessageKey)) {
        if (state.activePvtMessageKey !== pvtMessageKey) {
            state.pvtMessages[pvtMessageKey].unreadCount =
                (state.pvtMessages[pvtMessageKey].unreadCount || 0) + 1;
        }
    }
    return state;
};

const lobbyChatReducer = (state = INITIAL_STATE, action) => {
    let globalState = get(action, 'globalState');
    switch (action.type) {
        case LOBBY_CHAT_MESSAGE:
            log.info('LobbyChatReducer: ' + action.type);
            state = cloneDeep(state);
            let sender = get(action.payload, 'data.sender');
            let isBlockedUser = (globalState.user.sensorList || []).find(
                (p) => p.guid === sender
            );
            if (globalState.config.show_lobby_chat && !isBlockedUser) {
                let name = get(action.payload, 'data.name');
                let username =
                    get(
                        (globalState.user.onlinePlayerBuddies || []).find(
                            (p) => p.guid === sender
                        ),
                        'name'
                    ) ||
                    get(
                        (globalState.user.onlinePlayerOthers || []).find(
                            (p) => p.guid === sender
                        ),
                        'name'
                    ) ||
                    get(
                        (globalState.user.myData || []).find(
                            (p) => p.guid === sender
                        ),
                        'name'
                    ) ||
                    name;
                let avtar =
                    get(
                        (globalState.user.onlinePlayerBuddies || []).find(
                            (p) => p.guid === sender
                        ),
                        'avtar'
                    ) ||
                    get(
                        (globalState.user.onlinePlayerOthers || []).find(
                            (p) => p.guid === sender
                        ),
                        'avtar'
                    ) ||
                    get(
                        (globalState.user.myData || []).find(
                            (p) => p.guid === sender
                        ),
                        'avtar'
                    );
                let messageInfo = {
                    message: {
                        sender,
                        msg: get(action.payload, 'data.message'),
                        time: Date.now(),
                    },
                    username,
                    avtar,
                    id: Date.now(),
                    direction: 'incoming',
                    type: get(action.payload, 'data.type'),
                };

                if (
                    get(action.payload, 'data.type') ===
                    Config.LOBBY_CHAT_MESSAGE_TYPE_PRIVATE
                ) {
                    let showAsGameUpdate = get(
                        action.payload,
                        'showAsGameUpdate'
                    );
                    if (showAsGameUpdate) {
                        messageInfo.type =
                            Config.LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE;
                    }
                    let pvtMessageKey =
                        get(action.payload, 'data.pvtMessageKey') || sender;

                    if (state.pvtMessages.hasOwnProperty(pvtMessageKey)) {
                        let pvtMessages =
                            state.pvtMessages[pvtMessageKey].messages;
                        pvtMessages.unshift(formatMessageData(messageInfo));
                        if (
                            pvtMessages.length > Config.LOBBY_CHAT_MESSAGE_LIMIT
                        ) {
                            pvtMessages.pop();
                        }
                    } else {
                        let pvtMessages = state.pvtMessages;
                        pvtMessages[pvtMessageKey] = {
                            name: username,
                            messages: [formatMessageData(messageInfo)],
                        };
                        state.pvtMessages = pvtMessages;
                    }
                    state.pvtMessages = setUnreadCount({
                        state,
                        pvtMessageKey,
                    }).pvtMessages;
                } else if (
                    get(action.payload, 'data.type') !==
                        Config.LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE ||
                    (get(action.payload, 'data.type') ===
                        Config.LOBBY_CHAT_MESSAGE_TYPE_GAME_UPDATE &&
                        globalState.config.lobby_game_update)
                ) {
                    state.messages.unshift(formatMessageData(messageInfo));
                    if (
                        state.messages.length > Config.LOBBY_CHAT_MESSAGE_LIMIT
                    ) {
                        state.messages.pop();
                    }
                    state.messages = setUnreadCount({
                        state,
                        isLobby: true,
                    }).messages;
                }
            }
            break;

        case ADD_PVT_MESSAGE_KEY:
            log.info('LobbyChatReducer: ' + action.type);
            state = cloneDeep(state);
            let pvtMessageKey = get(action.payload, 'guid');
            state.activePvtMessageKey = pvtMessageKey;
            state.pvtMessages[pvtMessageKey] = {
                name: get(action.payload, 'username'),
                messages:
                    get(state.pvtMessages, pvtMessageKey + '.messages') || [],
            };
            break;

        case SET_ACTIVE_PVT_MESSAGE_KEY:
            log.info('LobbyChatReducer: ' + action.type);
            state = cloneDeep(state);
            state.activePvtMessageKey = action.payload;
            if (
                Object.keys(state.pvtMessages).length > 0 &&
                action.payload &&
                Object.keys(state.pvtMessages).includes(action.payload)
            ) {
                state.pvtMessages[action.payload].unreadCount = 0;
            } else if (!action.payload && state.messages.length > 0) {
                state.lobbyMsgUnreadCount = 0;
            }
            break;

        case REMOVE_PVT_MESSAGE_KEY:
            log.info('LobbyChatReducer: ' + action.type);
            state = cloneDeep(state);
            let pvtMessages = state.pvtMessages;
            delete pvtMessages[action.payload];
            state.pvtMessages = pvtMessages;
            state.activePvtMessageKey = undefined;
            break;
    }
    return { ...state };
};

export default lobbyChatReducer;
