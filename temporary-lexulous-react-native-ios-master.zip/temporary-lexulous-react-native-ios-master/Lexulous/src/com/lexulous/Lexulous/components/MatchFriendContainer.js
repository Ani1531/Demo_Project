//@flow

import * as React from 'react';
import { StyleSheet, View, Text, TextInput, Pressable, Keyboard, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimesCircle, faSearch } from '@fortawesome/pro-light-svg-icons';
import { connect } from 'react-redux';
import * as CONSTANTS from '../commons/Constants';
import type {
    MatchFriendPopupProps,
    ProfileInfo,
    userSettings,
    ServerResponse,
    UserStats,
    WinLossStatsBarType,
    matchFriendData,
    StartNewGamePlayers,
    ErrorResponse,
    StartNewGameSetting,
} from '../commons/RJTypes';
import { translate } from '../commons/translations/LangTransator';
import dataServer from '../store/Store';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import requestManager from '../commons/RequestManager';
import netManager from '../commons/RJNetInfo';
import type { AxiosPromise, AxiosResponse } from 'axios';
import fndApi from '../friends/FndApi';
import AvatarSelector from './AvatarSelector';
import WinLossStatsBarContainer from '../stats/statsprofile/WinLossStatsBarContainer';
import SelectDropdown from 'react-native-select-dropdown';
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import * as PFLSelector from '../userprofile/PFLSelector';
import trslateConstants from '../commons/translations/TrslateConstants';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import { setEmailData } from '../../../../actions/GameActions';
import interstitialAd from '../commons/ads/InterstitialAd';
import { handleException } from '../commons/RJUtils';
import rjAnalytics from '../../../../RJAnalytics';
import themeConfigutation from '../commons/ThemeConfiguration';

type MatchFndState = {
    InputData?: string,
    txtInpRef: { current: null | React.ElementRef<'input'> },
    matchFriendlist: Array<matchFriendData>,
    errorMsg: string,
    showGamesetting: boolean,
    showAddPlayer: boolean,
    showGameDetails: boolean,
    GameType: Array<string>,
    BoardType: Array<string>,
    Dictionary: Array<string>,
    selectedDictionary: string,
    selectedBrdtype: string,
    selectedGmtype: string,
    cachedList: Array<matchFriendData>,
    displayNames: Array<string>,
    displayList: Array<matchFriendData>,
};
class MatchFriendContainer extends React.Component<MatchFriendPopupProps, MatchFndState> {
    constructor(props: MatchFriendPopupProps) {
        super(props);
        this.state = {
            InputData: '',
            txtInpRef: React.createRef(),
            matchFriendlist: [],
            errorMsg: '',
            showGamesetting: false,
            showAddPlayer: false,
            showGameDetails: true,
            GameType: [translate('game_reglr'), translate('game_chlg')],
            BoardType: [translate('board_clsc'), translate('board_lx')],
            Dictionary: [translate('dict_us'), translate('dict_uk'), translate('dict_fr'), translate('dict_it')],
            selectedDictionary:
                trslateConstants.DictionaryValues()[
                    this.props.profileSettings.us_gamestart?.gs_prefdic ?? CONSTANTS.US_English
                ] ?? translate('dict_us'),
            selectedBrdtype:
                trslateConstants.BoardTypeValues()[this.props.profileSettings.us_gamestart?.gs_boardtype ?? CONSTANTS.Normal] ??
                translate('board_clsc'),
            selectedGmtype:
                trslateConstants.GameTypeValues()[
                    this.props.profileSettings.us_gamestart?.gs_gametype ?? CONSTANTS.Email_Regular
                ] ?? translate('game_reglr'),
            cachedList: [],
            displayNames: [],
            displayList: [],
        };
    }

    componentDidMount() {
        if (this.props.userStats) {
            this.addPlayer(this.props.userStats);
        }
    }

    maxPlayersReached = (): boolean => {
        return this.state.matchFriendlist.length >= 3;
    };

    isSelf = (guid: string): boolean => {
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        return sguid === guid;
    };

    alreadyAdded = (guid: string): boolean => {
        let added = this.state.matchFriendlist.find((val) => val.guid === guid);
        return added != null && added != undefined;
    };

    getCachedData = (guid: string): ?matchFriendData => {
        let srch_cached_data = this.state.cachedList.find((val) => val.guid === guid);
        return srch_cached_data ?? null;
    };

    closePopup = () => {
        if (this.state.showAddPlayer) {
            this.setState({ showGamesetting: false, showAddPlayer: false, showGameDetails: true, errorMsg: '' });
        } else {
            this.props.cancelMatch();
        }
    };

    setAddmatchFriend = (value?: string) => {
        this.setState({ errorMsg: '', InputData: value });
    };
    getBoardtype = (data: string, index: number) => {
        if (data !== translate('board_desc')) {
            this.setState({ selectedBrdtype: data });
        }
    };
    getType = (data: string, index: number) => {
        if (data !== translate('game_desc')) {
            this.setState({ selectedGmtype: data });
        }
    };
    getDict = (data: string, index: number) => {
        if (data !== translate('dict_desc')) {
            this.setState({ selectedDictionary: data });
        }
    };

    removePlayer = (data: matchFriendData) => {
        let matchFriendlist = [...this.state.matchFriendlist];
        let displayNames = [...this.state.displayNames];
        matchFriendlist = matchFriendlist.filter((val) => val.guid !== data.guid);
        displayNames = displayNames.filter((val) => val !== data.profile?.name);
        this.setState({
            matchFriendlist,
            displayNames,
            errorMsg: '',
        });
    };

    addPlayer = (playerstats: matchFriendData, updatecache: boolean = true) => {
        let matchFriendlist = [...this.state.matchFriendlist];
        let displayList = [...this.state.displayList];
        let cachedList = [...this.state.cachedList];
        let displayNames = [...this.state.displayNames];
        matchFriendlist.push(playerstats);
        if (updatecache) {
            cachedList.push(playerstats);
        }
        if (playerstats.profile?.name) {
            displayNames.push(playerstats.profile.name);
        }
        if (this.props.userStats.guid !== playerstats.guid) {
            displayList.push(playerstats);
        }

        this.setState({
            matchFriendlist,
            cachedList,
            displayList,
            InputData: '',
            displayNames,
            errorMsg: '',
        });
    };

    doAddMatchFriend = () => {
        this.setState({ errorMsg: '' });

        let value = '';
        if (this.state.InputData !== null && this.state.InputData !== undefined) {
            value = this.state.InputData;
        }
        if (value == '') {
            this.setState({ errorMsg: translate('blank_idMsg') });
        } else {
            this.performAddMatchFriend(value);
        }
    };

    performAddMatchFriend = (guidOrnameOremail: string) => {
        if (this.maxPlayersReached()) {
            this.setState({ errorMsg: translate('err_mgs_max_people') });
            this.state.txtInpRef.current?.focus();
        } else if (this.isSelf(guidOrnameOremail)) {
            this.setState({ errorMsg: translate('err_mgs_Same_user') });
            this.state.txtInpRef.current?.focus();
        } else if (this.alreadyAdded(guidOrnameOremail)) {
            this.setState({ errorMsg: translate('err_mgs_Already') });
            this.state.txtInpRef.current?.focus();
        } else {
            let cacheddata: ?matchFriendData = this.getCachedData(guidOrnameOremail);
            if (cacheddata != null) {
                this.addPlayer(cacheddata, false);
                Keyboard.dismiss();
            } else {
                let glblregex = /^\d+$/;
                let isvalidglobalid: boolean =
                    glblregex.test(guidOrnameOremail) && guidOrnameOremail.length == CONSTANTS.kMinGlobalIdLen;
                if (isvalidglobalid) {
                    this.getPlayerProfileandStat(guidOrnameOremail, this.addPlayer);
                } else {
                    this.doGetGuidFromEmailOrName(guidOrnameOremail, this.performAddMatchFriend);
                }
            }
        }
    };

    doGetGuidFromEmailOrName = (data: string, callback: (guid: string) => void) => {
        let glblid = data;
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p1: AxiosPromise<any> = fndApi.getGuidFromEmailOrName(data);
            p1.then((response: AxiosResponse<any, any>) => {
                if (response.status == CONSTANTS.HTTPSuccessStatus) {
                    return response.data;
                } else {
                    throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                }
            })
                .then((dd: any) => {
                    if (dd.check == 'success' && dd.data.length != 0) {
                        glblid = dd.data.other[data];
                        if (glblid.length > 0) {
                            if (callback) {
                                callback(glblid);
                            }
                            dataServer.debouncedDispatch(actionSetIdle());
                        }
                    } else {
                        let msg = dd.msg ?? translate('lxlsusrntfnt');
                        dataServer.debouncedDispatch(actionSetIdle());
                        this.setState({ errorMsg: dd.msg });
                        this.state.txtInpRef.current?.focus();
                    }
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    handleException(error);
                    this.state.txtInpRef.current?.focus();
                });
        }
    };

    getPlayerProfileandStat = (glblid: string, callback: ?(profileNstat: matchFriendData) => void) => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            let p2: AxiosPromise<ServerResponse> = requestManager.getProfileOtherUser([glblid]);
            let p3: AxiosPromise<ServerResponse> = fndApi.getStats([glblid], []);
            let promises: Array<AxiosPromise<ServerResponse>> = [];

            promises.push(p2);
            promises.push(p3);
            let rating = '1500';
            let won = 0;
            let lost = 0;
            let drawn = 0;
            let name = '';
            let guid = '';
            let avtar = '';
            let games = 0;
            let bingos = 0;

            Promise.all(promises)
                .then(async ([a, b]) => {
                    let a1: ServerResponse = await a.data;
                    let b1: ServerResponse = await b.data;

                    let pflinfo: { [string]: ProfileInfo } = {};
                    if (b1.check === CONSTANTS.kSuccess) {
                        let temp: Array<UserStats> = ((b1.data: any): Array<UserStats>);
                        if (temp !== undefined && temp !== null && temp.length > 0) {
                            let user_stat: UserStats = temp[0];

                            if (user_stat.game_stats?.won) {
                                won = Number(user_stat.game_stats?.won);
                            }
                            if (user_stat.game_stats?.drawn) {
                                drawn = Number(user_stat.game_stats?.drawn);
                            }
                            if (user_stat.game_stats?.lost) {
                                lost = Number(user_stat.game_stats?.lost);
                            }
                            if (user_stat.game_stats?.played) {
                                games = Number(user_stat.game_stats?.played);
                            }
                            if (user_stat.game_stats?.bingo_count) {
                                bingos = Number(user_stat.game_stats?.bingo_count);
                            }
                        }
                    }

                    if (a1.check === CONSTANTS.kSuccess && a1.extcode == '1') {
                        pflinfo = ((a1.data: any): { [string]: ProfileInfo });
                        name = pflinfo[glblid].name;
                        avtar = pflinfo[glblid].avtar;
                        guid = pflinfo[glblid].guid;
                        let barstats: WinLossStatsBarType = {
                            won: won,
                            lost: lost,
                            drawn: drawn,
                            games: games,
                            bingos: bingos,
                        };
                        let profile: ProfileInfo = {
                            name: name,
                            avtar: avtar,
                        };
                        let obj: matchFriendData = {
                            barstats: barstats,
                            profile: profile,
                            rating: rating,
                            guid: guid ?? CONSTANTS.Default_guid,
                        };
                        if (callback) {
                            Keyboard.dismiss();
                            callback(obj);
                        }
                    } else {
                        this.setState({ errorMsg: translate('lxlsusrntfnt') });
                        this.state.txtInpRef.current?.focus();
                    }

                    dataServer.debouncedDispatch(actionSetIdle());
                })
                .catch((error) => {
                    dataServer.debouncedDispatch(actionSetIdle());
                    this.setState({ errorMsg: translate('err_mgs') });
                    this.state.txtInpRef.current?.focus();
                    handleException(error);
                });
        }
    };

    startGame = () => {
        let allplayers: StartNewGamePlayers = {};
        let players: Array<string> = [];
        let sguid = PFLSelector.getGUID(dataServer.getStore().getState());
        if (sguid !== null && sguid !== undefined) {
            players.push(sguid);
            this.state.matchFriendlist.forEach((val, index) => {
                players.push(val?.guid);
            });
            players.forEach((val, index) => {
                allplayers['p' + (index + 1) + 'uid'] = val;
            });

            let dictmapping: { [key: string]: string } = {
                [translate('dict_us')]: CONSTANTS.US_English,
                [translate('dict_uk')]: CONSTANTS.UK_English,
                [translate('dict_it')]: CONSTANTS.Italian,
                [translate('dict_fr')]: CONSTANTS.French,
            };
            let nw_strt_gm_dict: string = dictmapping[this.state.selectedDictionary] ?? CONSTANTS.US_English;
            let gametypemapping: { [key: string]: string } = {
                [translate('game_reglr')]: CONSTANTS.Email_Regular,
                [translate('game_chlg')]: CONSTANTS.Email_Challange,
            };
            let nw_strt_gm_gmtype: string = gametypemapping[this.state.selectedGmtype] ?? CONSTANTS.Email_Regular;
            let boardtypemapping: { [key: string]: string } = {
                [translate('board_clsc')]: CONSTANTS.Normal,
                [translate('board_lx')]: CONSTANTS.Super,
            };
            let nw_strt_gm_boardtype: string = boardtypemapping[this.state.selectedBrdtype] ?? CONSTANTS.Normal;
            let gameSetting: StartNewGameSetting = {
                dic: nw_strt_gm_dict,
                gametype: nw_strt_gm_gmtype,
                boardtype: nw_strt_gm_boardtype,
            };
            if (netManager.isConnected()) {
                dataServer.getStore().dispatch(actionSetBusy());
                let rsp = requestManager.startNewGame(allplayers, gameSetting);

                rsp.then((response) => {
                    if (response.status == CONSTANTS.HTTPSuccessStatus) {
                        return response.data;
                    } else {
                        throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                    }
                })
                    .then((result: ServerResponse) => {
                        if (result.check === CONSTANTS.kSuccess) {
                            dataServer.debouncedDispatch(actionSetIdle());
                            let res = (result: any);
                            let pid = 1;
                            let me = res.data[CONSTANTS.kChannel].players.find((element) => element.guid === sguid);
                            pid = me.pid;
                            const data: gameBoardDataExchng = {
                                gid: res.data[CONSTANTS.kChannel].gid,
                                pid: pid,
                                dic: nw_strt_gm_dict, //sow, fr, it
                                boarddes: 'n',
                                already_attempted: false,
                                game_type: 'email', //"email",//"live_room","puzzle","solo", "blitz"
                                board_type: nw_strt_gm_boardtype == CONSTANTS.Super ? CONSTANTS.server_S : CONSTANTS.server_N,
                                request_url_type: 'rest_api', //"rest_api",//"web_socket",
                                channel: CONSTANTS.kChannel,
                                guid: sguid,
                                uuid: PFLSelector.getUUID(dataServer.getStore().getState()) ?? '',
                                board_size:
                                    nw_strt_gm_boardtype == CONSTANTS.Super ? CONSTANTS.Board_sz_s : CONSTANTS.Board_sz_n,
                            };
                            gameBoardDataExchanger.gameBoardData = data;
                            dataServer.getStore().dispatch(setEmailData(data));
                            this.props.navigation.navigate('BoardScreen');
                            this.props.cancelMatch();
                        } else {
                            let err: ErrorResponse = (result: ErrorResponse);
                            this.setState({ errorMsg: err.msg });
                        }
                    })
                    .catch((error) => {
                        handleException(error);
                        this.setState({ errorMsg: 'Something went wrong' });
                        dataServer.debouncedDispatch(actionSetIdle());
                    })
                    .finally(() => {
                        dataServer.debouncedDispatch(actionSetIdle());
                    });
            }
        }
    };

    separator = () => {
        return (
            <View
                style={{
                    height: 1,
                    width: '100%',
                    backgroundColor: '#a6a6a6',
                }}
            />
        );
    };

    renderList = (): Array<any> => {
        return this.state.displayList.map((element: matchFriendData) => {
            let statdata: WinLossStatsBarType = {
                won: element?.barstats.won,
                lost: element?.barstats.lost,
                drawn: element.barstats.drawn,
                games: element.barstats.games,
                bingos: element.barstats.bingos,
            };
            return (
                <View key={element?.guid} style={{}}>
                    {this.separator()}
                    <View style={{ flexDirection: 'row', paddingVertical: 6 }}>
                        <AvatarSelector avtar={element?.profile?.avtar ?? null} editingFinishedHandler={null} />
                        <View style={{ flex: 1 }}>
                            <Text style={{ paddingLeft: 6, color: themeConfigutation.getColor('#000') }}>
                                {element.profile?.name}
                                <Text> </Text>
                                <Text>({element?.rating})</Text>
                            </Text>
                            <WinLossStatsBarContainer statdata={statdata} isForHostedGame={false} />
                        </View>
                        {/* <View style={styles.removebttnview}>
                            <Pressable
                                onPress={() => this.removePlayer(element)}
                                style={{
                                    paddingTop: 6,
                                    justifyContent: 'center',
                                }}
                            >
                                <FontAwesomeIcon icon={faTimesCircle} size={18} />
                            </Pressable>
                        </View> */}
                    </View>
                </View>
            );
        });
    };

    renderNxtbttn = () => {
        return this.state.displayList?.length >= 1 ? (
            <Pressable
                style={[styles.nxtBtnstyle, { backgroundColor: '#1d9df1', alignSelf: 'flex-end' }]}
                onPress={() => {
                    this.setState({
                        showGamesetting: false,
                        errorMsg: '',
                        InputData: '',
                        showAddPlayer: false,
                        showGameDetails: true,
                        displayList: [],
                    });
                }}
            >
                <Text style={styles.btntxt}>{translate('nxt')}</Text>
            </Pressable>
        ) : null;
    };

    renderErrmsg = () => {
        return this.state?.errorMsg?.length > 1 ? (
            <Text style={{ color: '#ff6347', paddingBottom: 8, fontSize: 10, alignSelf: 'flex-start' }}>
                {this.state.errorMsg}
            </Text>
        ) : null;
    };

    renderSearchPlayer = () => {
        return (
            <View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 }}>
                    <TextInput
                        ref={this.state.txtInpRef}
                        placeholder={translate('type_glbId')}
                        autoCompleteType={'off'}
                        autoCapitalize={'none'}
                        autoCorrect={false}
                        autoFocus={true}
                        returnKeyType={'done'}
                        placeholderTextColor={themeConfigutation.getColor('#d6d6d7')}
                        style={[
                            styles.inputBoxStyle,
                            { color: themeConfigutation.getColor('#5f6368'), borderColor: '#d6d6d7' },
                        ]}
                        onChangeText={(value) => this.setAddmatchFriend(value)}
                        //  onSubmitEditing={this.doSendMatchRequest}
                        value={this.state.InputData}
                    />

                    <Pressable
                        style={[
                            styles.nxtBtnstyle,
                            { backgroundColor: '#1d9df1', height: 27, marginTop: 4, alignSelf: 'center', flexDirection: 'row' },
                        ]}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('search_btn_pressed', 'match_friend_container');
                            this.doAddMatchFriend();
                        }}
                    >
                        <FontAwesomeIcon icon={faSearch} size={18} style={{ marginRight: 5, color: '#fff' }} />
                        <Text style={[styles.btntxt, { color: '#fff' }]}>{translate('srch')}</Text>
                    </Pressable>
                </View>
                {this.renderErrmsg()}
                {this.renderList()}
                {this.renderNxtbttn()}
            </View>
        );
    };

    renderStartGameSummary = () => {
        let names = this.state.displayNames.join(', ');
        return (
            <View>
                <Text style={{ paddingVertical: 8, alignSelf: 'center', color: themeConfigutation.getColor('#000') }}>
                    {translate('strt_gm_txt')}
                    <Text>{names}</Text>
                </Text>
                <View style={{ flexDirection: 'row', padding: 8, justifyContent: 'space-between' }}>
                    <Pressable
                        disabled={this.state.matchFriendlist.length === 3}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('ad_plr_btn_pressed', 'match_friend_container');
                            this.setState({
                                showGamesetting: false,
                                showAddPlayer: true,
                                showGameDetails: false,
                                errorMsg: '',
                                InputData: '',
                                displayList: [],
                            });
                        }}
                        style={[
                            styles.nxtBtnstyle,
                            { backgroundColor: this.state.matchFriendlist.length === 3 ? 'grey' : '#1d9df1' },
                        ]}
                    >
                        <Text style={[styles.btntxt]}>{translate('ad_plr')}</Text>
                    </Pressable>
                    <Pressable
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('continue_btn_pressed', 'match_friend_container');
                            this.setState({
                                showGamesetting: true,
                                showAddPlayer: false,
                                showGameDetails: true,
                                errorMsg: '',
                                displayList: [],
                            });
                        }}
                        style={[styles.nxtBtnstyle, { backgroundColor: '#1d9df1' }]}
                    >
                        <Text style={[styles.btntxt]}>{translate('cont')}</Text>
                    </Pressable>
                </View>
            </View>
        );
    };

    getIcon = () => {
        return <FontAwesomeIcon icon={faCaretDown} size={20} color={themeConfigutation.getColor('#000')} />;
    };

    renderStartGameSettings = () => {
        return (
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' }}>
                    <View style={{ padding: 16 }}>
                        <SelectDropdown
                            rowStyle={{
                                backgroundColor: themeConfigutation.getColor('#fff'),
                                ...Platform.select({
                                    native: {},
                                    default: { paddingVertical: 13 },
                                }),
                            }}
                            buttonStyle={[
                                styles.drillDown_pickerStyle,
                                { backgroundColor: themeConfigutation.getColor('#d6d6d7') },
                            ]}
                            dropdownIconPosition={'right'}
                            dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                            renderDropdownIcon={this.getIcon}
                            data={this.state.GameType}
                            onSelect={(selectedItem: string, index: number) => this.getType(selectedItem, index)}
                            renderCustomizedButtonChild={() => {
                                return (
                                    <Text style={{ alignSelf: 'center', color: themeConfigutation.getColor('#000') }}>
                                        {this.state.selectedGmtype}
                                    </Text>
                                );
                            }}
                            renderCustomizedRowChild={(item: string) => {
                                return (
                                    <Text
                                        style={{
                                            alignSelf: 'center',
                                            flexWrap: 'wrap',
                                            padding: 3,
                                            color: themeConfigutation.getColor('#000'),
                                        }}
                                    >
                                        {item}
                                    </Text>
                                );
                            }}
                            rowTextStyle={{ color: themeConfigutation.getColor('#000') }}
                            buttonTextStyle={{ color: themeConfigutation.getColor('#000') }}
                        />
                    </View>
                    <View style={{ padding: 16 }}>
                        <SelectDropdown
                            rowStyle={{
                                backgroundColor: themeConfigutation.getColor('#fff'),
                                ...Platform.select({
                                    native: {},
                                    default: { paddingVertical: 13 },
                                }),
                            }}
                            buttonStyle={[
                                styles.drillDown_pickerStyle,
                                { backgroundColor: themeConfigutation.getColor('#d6d6d7') },
                            ]}
                            dropdownIconPosition={'right'}
                            dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                            renderDropdownIcon={this.getIcon}
                            data={this.state.BoardType}
                            onSelect={(selectedItem: string, index: number) => this.getBoardtype(selectedItem, index)}
                            renderCustomizedButtonChild={() => {
                                return (
                                    <Text style={{ alignSelf: 'center', color: themeConfigutation.getColor('#000') }}>
                                        {this.state.selectedBrdtype}
                                    </Text>
                                );
                            }}
                            renderCustomizedRowChild={(item: string) => {
                                return (
                                    <Text
                                        style={{
                                            alignSelf: 'center',
                                            flexWrap: 'wrap',
                                            padding: 3,
                                            color: themeConfigutation.getColor('#000'),
                                        }}
                                    >
                                        {item}
                                    </Text>
                                );
                            }}
                            rowTextStyle={{ color: themeConfigutation.getColor('#000') }}
                            buttonTextStyle={{ color: themeConfigutation.getColor('#000') }}
                        />
                    </View>
                    <View style={{ padding: 16 }}>
                        <SelectDropdown
                            rowStyle={{
                                backgroundColor: themeConfigutation.getColor('#fff'),
                                ...Platform.select({
                                    native: {},
                                    default: { paddingVertical: 13 },
                                }),
                            }}
                            buttonStyle={[
                                styles.drillDown_pickerStyle,
                                { backgroundColor: themeConfigutation.getColor('#d6d6d7') },
                            ]}
                            dropdownIconPosition={'right'}
                            dropdownOverlayColor={'rgba(45, 52, 54,0.2)'}
                            renderDropdownIcon={this.getIcon}
                            data={this.state.Dictionary}
                            onSelect={(selectedItem: string, index: number) => this.getDict(selectedItem, index)}
                            renderCustomizedButtonChild={() => {
                                return (
                                    <Text style={{ alignSelf: 'center', color: themeConfigutation.getColor('#000') }}>
                                        {this.state.selectedDictionary}
                                    </Text>
                                );
                            }}
                            renderCustomizedRowChild={(item: string) => {
                                return (
                                    <Text
                                        style={{
                                            alignSelf: 'center',
                                            flexWrap: 'wrap',
                                            padding: 3,
                                            color: themeConfigutation.getColor('#000'),
                                        }}
                                    >
                                        {item}
                                    </Text>
                                );
                            }}
                            rowTextStyle={{ color: themeConfigutation.getColor('#000') }}
                            buttonTextStyle={{ color: themeConfigutation.getColor('#000') }}
                        />
                    </View>
                </View>
                <View style={{ flexDirection: 'row', padding: 6, width: '100%', justifyContent: 'flex-end' }}>
                    <Pressable
                        style={[styles.nxtBtnstyle, { backgroundColor: '#1d9df1' }]}
                        onPress={() => {
                            interstitialAd.showInterstitialAd(true, () => {
                                this.startGame();
                            });
                        }}
                    >
                        <Text style={styles.btntxt}>{translate('strt_gm')}</Text>
                    </Pressable>
                </View>
                {this.renderErrmsg()}
            </View>
        );
    };
    renderpopupContent = () => {
        if (this.state.showAddPlayer) {
            return this.renderSearchPlayer();
        } else if (this.state.showGamesetting) {
            return this.renderStartGameSettings();
        } else {
            return this.renderStartGameSummary();
        }
    };
    render() {
        return (
            <View style={styles.popupView}>
                <View
                    style={[
                        styles.popupMainView,
                        {
                            backgroundColor: themeConfigutation.getColor('#fafafa'),
                            shadowColor: themeConfigutation.getColor('#000'),
                        },
                    ]}
                >
                    <Pressable onPress={() => this.closePopup()} style={[styles.xBtnStyle]}>
                        <FontAwesomeIcon icon={faTimesCircle} size={22} color={themeConfigutation.getColor('#000')} />
                    </Pressable>
                    {this.renderpopupContent()}
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    popupView: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 1,
        justifyContent: 'center',
    },
    popupMainView: {
        minWidth: 250,
        maxWidth: 300,
        alignSelf: 'center',
        justifyContent: 'center',
        borderRadius: 10,
        padding: 10,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },

    xBtnStyle: {
        alignSelf: 'flex-end',
        marginBottom: 8,
        alignContent: 'center',
    },
    btntxt: {
        color: '#fff',
        fontSize: 13,
        fontWeight: '700',
    },
    inputBoxStyle: {
        fontSize: 14,
        padding: 3,
        borderBottomWidth: 1,
        marginRight: 10,
        minWidth: '60%',
        maxWidth: '70%',
    },
    nxtBtnstyle: {
        // width: '20%',
        borderRadius: 4,
        paddingVertical: 4,
        paddingHorizontal: 7,
        justifyContent: 'center',
    },
    drillDown_pickerStyle: {
        maxWidth: 200,
        height: 30,
        alignSelf: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        // padding: 4,
    },
    removebttnview: {
        width: '20%',
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
});
function mapStateToProps(state) {
    const { profileSettings } = state;

    return { profileSettings };
}

export default connect(mapStateToProps)(MatchFriendContainer);
