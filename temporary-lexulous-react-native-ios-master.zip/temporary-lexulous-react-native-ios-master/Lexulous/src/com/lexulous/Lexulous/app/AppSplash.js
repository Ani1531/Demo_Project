// @flow

import 'react-native-gesture-handler';
import { batch } from 'react-redux';
import React from 'react';
import { StyleSheet, Linking, ImageBackground, StatusBar, Platform } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import userDefault from '../commons/UserDefault';
import legacyCoordinator from '../legacy/LegacyCoordinator';
import requestManager from '../commons/RequestManager';
import glApi from '../gameslist/GLApi';
import * as CONSTANTS from '../commons/Constants';
import { TransitionPresets } from '@react-navigation/stack';
import type {
    PsistData,
    GenGlobalIDRequest,
    ServerResponse,
    GenGlobalIDResponseData,
    RequestData,
    GamesListResponse,
    AlertBoxType,
    SourceType,
} from '../commons/RJTypes';
import minStatsApi from '../stats/minimalstats/MinStatsApi';
import { actionAddGames, glClearData } from '../gameslist/GLAction';

import SplashContainer from '../splash/SplashContainer';
import LNRVwContainer from '../loginNregister/LNRVwContainer';

import dataServer from '../store/Store';
import * as ProfileSelector from '../userprofile/PFLSelector';
import NavLexLogo from '../components/NavLexLogo';
import loginCoordinator from '../commons/LoginCoordinator';
import applLgnMgr from '../commons/ApplLgnMgr';
import gglLgnMgr from '../commons/GGLgnMgr';
import lxlsLgnMgr from '../commons/LXLSLgnMgr';
import fbLgnMgr from '../commons/FBLgnMgr';
import { actionSetIdle, actionSetBusy } from '../commons/RJTypes';
import netManager from '../commons/RJNetInfo';
import GameBoardContainer from '../gameboard/GameBoardContainer';
import ProfileStatsContainer from '../stats/statsprofile/ProfileStatsContainer';
import * as RootNavigation from '../commons/RootNavigation';
import HomeScreenContainer from '../home/HomeScreenContainer';
import CustomerSupportScreenContainer from '../customersupport/CustomerSupportScreenContainer';
import TutorialVwContainer from '../tutorial/TutorialVwContainer';
import RJSHRpicker from '../hrpicker/RJSHRpicker';
import fndApi from '../friends/FndApi';
import { showAlert, clearAlert } from '../reducers/popupreducer/PopupAction';
import * as RNLocalize from 'react-native-localize';
import { setI18nConfig, translate } from '../commons/translations/LangTransator';
import type { AxiosPromise, AxiosResponse } from 'axios';
import LoadingContainer from '../components/LoadingIndicator';
import pushNtfMgr from '../commons/PushNtfMgr';
import { LegacyOnboardPathCode } from '../legacy/LegacyCoordinator';
import MultipleAccountSelectionContainer from '../components/MultipleAccountSelectionContainer';
import RNBootSplash from 'react-native-bootsplash';
import AGLContainer from '../archivegameslist/AGLContainer';
import AlertBox from '../components/AlertBox';
import { AlertBoxButtonType, COLOR } from '../commons/Constants';
import { handleException } from '../commons/RJUtils';
import inAppPurchases from '../commons/iap/InAppPurchases';
import appConfiguration from '../commons/AppConfiguration';
import { gameBoardDataExchanger, type gameBoardDataExchng } from '../../../../utils/GameBoardDataExchange';
import { setEmailData } from '../../../../actions/GameActions';
import { actionUpdateFBLgnInfo } from '../userprofile/PFLAction';
import { AccessToken } from 'react-native-fbsdk-next';

const appInitialState = {
    SHOWLOADING: 1,
    SHOWSPLASHSCRN: 2,
    SHOWGMLSTSCRN: 3,
};
Object.freeze(appInitialState);

type State = {
    initState: number,
    showMultipleAccountSelection: ?() => React$Element<typeof MultipleAccountSelectionContainer>,
};

class AppSplash extends React.Component<{}, State> {
    deeplinkurl: ?{| url: string |} = null;

    constructor(props: {}) {
        super(props);
        this.state = {
            initState: appInitialState.SHOWLOADING,
            showMultipleAccountSelection: null,
        };
        setI18nConfig();
    }

    componentDidMount() {
        //FETCH DATA FROM ASYNC STORE ON STARTUP
        Linking.addEventListener('url', this.handleOpenUrl);
        Linking.getInitialURL()
            .then((url) => {
                if (url) {
                    if (url !== null && url !== undefined) {
                        if (this.deeplinkurl?.url != url) {
                            this.deeplinkurl = { url };
                        }
                    }
                }
            })
            .catch((e) => {});
        netManager.onAppInit();
        pushNtfMgr.mountPushNotification();
        legacyCoordinator.onboardUserPathCode().then((onboardingcode) => {
            if (onboardingcode == LegacyOnboardPathCode.Merge) {
                legacyCoordinator.uiDelegateMultipleAccountSelection = this.uiDelegateCallBack;
                legacyCoordinator.doOnboardUser();
            } else {
                //=====required for web==================
                let accommodateParentData = Platform.select({
                    native: () => {},
                    default: () => {
                        let source: SourceType | null = appConfiguration.getApplicationSource();
                        if (source) {
                            let appcfg: any = appConfiguration.getAppConfiguration(source);

                            let guid: string = appcfg?.[source]?.guid ?? '0';
                            let uuid: string = appcfg?.[source]?.uuid ?? '_';
                            if (guid != '0' && uuid != '_') {
                                requestManager.updatePsistDataGuidUuid(guid, uuid);
                                if (source != null && source == CONSTANTS.kFBInstantApp) {
                                    let tkn: AccessToken = ('dhfajds-dfjdkeur': any);
                                    let lgndata = {
                                        fbAccessToken: tkn,
                                        username: 'fb',
                                    };
                                    dataServer.getStore().dispatch(actionUpdateFBLgnInfo(lgndata));
                                }
                            }
                        }
                    },
                });
                accommodateParentData();
                //=====end required for web==============
                loginCoordinator
                    .fetchInitDataFromUserPrefs()
                    .then((result) => {
                        this.onInitialDataFetchFromDataStore(result);
                    })
                    .catch((err) => handleException(err));
            }
        });
        RNLocalize.addEventListener('change', this.handleLocalizationLanguageChange);
    }

    uiDelegateCallBack = async (renderer: ?() => React$Element<typeof MultipleAccountSelectionContainer>): Promise<void> => {
        Platform.OS === 'android' || Platform.OS === 'ios' ? await RNBootSplash.hide({ fade: true }) : null;
        this.setState({ showMultipleAccountSelection: renderer });
    };

    componentWillUnmount() {
        //cleans up event listener
        Linking.removeEventListener('url', this.handleOpenUrl);
        RNLocalize.removeEventListener('change', this.handleLocalizationLanguageChange);
    }

    handleLocalizationLanguageChange = () => {
        setI18nConfig();
        this.forceUpdate();
    };

    handleOpenUrl = (event: {| url: string |}) => {
        //FIRING POINT
        if (event) {
            this.doNavigateToDeepLink(event, false);
        }
    };

    doNavigateToDeepLink = (lnk: {| url: string |}, isinitial: boolean) => {
        if (this.deeplinkurl !== null && this.deeplinkurl !== undefined) {
            this.deeplinkurl = null;
        }
        //TO DO: URL PARSING AND SWITCHING BASED ON PATH
        if (lnk.url.includes('player')) {
            RootNavigation.navigationRef.current?.navigate('StatsProfile', { lnk });
        } else {
            this.doUpdateGameInvitation();
        }
    };

    doUpdateGameInvitation = () => {
        let gameInvitation = Platform.select({
            native: () => {},
            default: () => {
                let source: SourceType | null = appConfiguration.getApplicationSource();
                if (source) {
                    let appcfg: any = appConfiguration.getAppConfiguration(source);

                    let tmpchannel: any = appcfg?.[source]?.channel ?? null;
                    let tmpguid: any = appcfg?.[source]?.guid ?? null;
                    let tmpuuid: any = appcfg?.[source]?.uuid ?? null;
                    let tmpgame: any = appcfg?.[source]?.gameinvitation ?? null;
                    if (tmpchannel && tmpguid && tmpuuid && tmpgame) {
                        const data: gameBoardDataExchng = {
                            gid: tmpgame.gid,
                            pid: tmpgame.pid,
                            dic: tmpgame.dic,
                            boarddes: tmpgame.boarddes,
                            already_attempted: tmpgame.already_attempted,
                            game_type: tmpgame.game_type,
                            board_type: tmpgame.board_type,
                            request_url_type: tmpgame.request_url_type,
                            channel: tmpchannel,
                            guid: tmpguid,
                            uuid: tmpuuid,
                            board_size: tmpgame.board_size,
                        };
                        gameBoardDataExchanger.gameBoardData = data;
                        dataServer.getStore().dispatch(setEmailData(data));
                        RootNavigation.navigationRef.current?.navigate('BoardScreen');
                    } else {
                        console.log('appcfg is null');
                    }
                }
            },
        });
        gameInvitation();
    };

    startupRetryConfirmation = (retry: () => void) => {
        let alertBoxInfo: AlertBoxType = {
            message: translate('err_internet'),
            actions: [
                {
                    text: translate('retry'),
                    action: () => {
                        retry();
                        dataServer.getStore().dispatch(clearAlert());
                    },
                    color: COLOR.AlertBoxButtonColor.POSITIVEBUTTONCOLOR,
                    type: AlertBoxButtonType.SHOWBUTTONONLY,
                },
            ],
        };
        dataServer.getStore().dispatch(showAlert(alertBoxInfo));
    };

    //fetch saved data from user perferences

    onInitialDataFetchFromDataStore = (datastoreresponse: PsistData) => {
        let storedguid = datastoreresponse.guid;
        if (!storedguid) {
            //new install fetch guid
            // userDefault.set(CONSTANTS.kPsistAppNwUser, 'true');
            // if (netManager.isConnected()) {
            //     this.genGlobalID();
            // } else {
            //     this.startupRetryConfirmation(this.genGlobalID);
            // }
            // begin lazy guid allocation
            this.setState({
                initState: appInitialState.SHOWSPLASHSCRN,
            });
            // end lazy guid allocation
        } else {
            let storeduuid = datastoreresponse.uuid;
            let startup: () => void = () => {
                let data: RequestData = {
                    channel: CONSTANTS.kChannel,
                    guid: storedguid,
                    uuid: storeduuid ?? '',
                };
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let rsp: AxiosPromise<ServerResponse> = requestManager.getProfile(data);

                    rsp.then((response: AxiosResponse<ServerResponse, any>) => {
                        if (response.status == CONSTANTS.HTTPSuccessStatus) {
                            return response.data;
                        } else {
                            throw { name: 'RequestFail', status: response.status, message: 'Request Failed' };
                        }
                    })

                        .then((result: ServerResponse) => {
                            if (storeduuid !== null && storeduuid !== undefined) {
                                requestManager.onProfileResponse(storedguid, storeduuid, result);
                            }
                            let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                            if ((sguid ?? 0) !== 0) {
                                requestManager.fetchUserSettings();
                                fndApi.getFriendListCumulative(false);
                                minStatsApi.getLoggedInUserStats();
                                applLgnMgr.checkLoginSilentMode();
                                fbLgnMgr.checkLoginSilentMode();
                                lxlsLgnMgr.checkLoginSilentMode();
                                gglLgnMgr.checkLoginSilentMode();
                                inAppPurchases.getPurchaseHistory();
                                pushNtfMgr.pinMayHaveExpired().then((pinhasexpired) => {
                                    pushNtfMgr.doUpdateDevicePin(pinhasexpired);
                                });
                                fetchGamesList();
                            } else {
                                dataServer.debouncedDispatch(actionSetIdle());
                                this.startupRetryConfirmation(startupfailhandler);
                            }
                        })
                        .catch((error) => {
                            dataServer.debouncedDispatch(actionSetIdle());
                            this.startupRetryConfirmation(startupfailhandler);
                        });
                } else {
                    this.startupRetryConfirmation(startupfailhandler);
                }
            };

            let startupfailhandler: () => void = startup;

            let fetchGamesList = () => {
                dataServer.getStore().dispatch(glClearData()); //for hot reload
                if (netManager.isConnected()) {
                    dataServer.getStore().dispatch(actionSetBusy());
                    let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                    if ((sguid ?? 0) !== 0) {
                        let promises: Array<AxiosPromise<ServerResponse>> = [];
                        let p1: AxiosPromise<ServerResponse> = glApi.getActiveGamesList();
                        promises.push(p1);
                        let p2: AxiosPromise<ServerResponse> = glApi.getArchivedGamesList();
                        promises.push(p2);
                        let activegamecnt: number = 0;
                        let archivegamecnt: number = 0;
                        Promise.all(promises)
                            .then(async ([a, b]) => {
                                let a1: ServerResponse = await a.data;
                                let b1: ServerResponse = await b.data;
                                let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
                                if (a1.check === CONSTANTS.kSuccess && b1.check === CONSTANTS.kSuccess) {
                                    let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                                    let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                                    activegamecnt = a1respdata.games.length;
                                    archivegamecnt = b1respdata.games.length;
                                    batch(() => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                                        dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                                    });
                                } else if (a1.check === CONSTANTS.kSuccess) {
                                    let a1respdata: GamesListResponse = ((a1.data: any): GamesListResponse);
                                    activegamecnt = a1respdata.games.length;
                                    batch(() => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        dataServer.getStore().dispatch(actionAddGames(a1respdata, profile));
                                    });
                                } else if (b1.check === CONSTANTS.kSuccess) {
                                    let b1respdata: GamesListResponse = ((b1.data: any): GamesListResponse);
                                    archivegamecnt = b1respdata.games.length;
                                    batch(() => {
                                        dataServer.debouncedDispatch(actionSetIdle());
                                        dataServer.getStore().dispatch(actionAddGames(b1respdata, profile));
                                    });
                                } else {
                                    dataServer.debouncedDispatch(actionSetIdle());
                                }
                                this.setState({ initState: appInitialState.SHOWGMLSTSCRN });
                                let gamecount = activegamecnt + archivegamecnt;
                                if (gamecount == 0) {
                                    userDefault.get(CONSTANTS.kPsistAppNwUser).then((value) => {
                                        if (value == null || value == undefined || value == 'false') {
                                            userDefault.set(CONSTANTS.kPsistAppNwUser, 'true');
                                        }
                                    });
                                    RootNavigation.navigationRef.current?.navigate('New Game');
                                }
                                if (this.deeplinkurl) {
                                    this.doNavigateToDeepLink(this.deeplinkurl, true);
                                } else {
                                    pushNtfMgr.doGetInitialNotification();
                                }
                                // a.text()
                                //     .then((result) => this.onActiveGamesListResposeReceive(JSON.parse(result)))
                                //     .catch((error) =>  handleException( error));
                                // b.text()
                                //     .then((result) => this.onArchiveGamesListResposeReceive(JSON.parse(result)))
                                //     .catch((error) =>  handleException(error));
                            })
                            .catch((error) => {
                                dataServer.debouncedDispatch(actionSetIdle());
                                handleException(error);
                            });
                    }
                } else {
                    this.setState({ initState: appInitialState.SHOWGMLSTSCRN });
                }
            };
            startup();
        }
    };

    genGlobalID = () => {
        if (netManager.isConnected()) {
            dataServer.getStore().dispatch(actionSetBusy());
            requestManager.doGenGlobalID((request: GenGlobalIDRequest, response: ServerResponse) => {
                if (response.check === CONSTANTS.kSuccess) {
                    let respdata: GenGlobalIDResponseData = ((response.data: any): GenGlobalIDResponseData);
                    if (respdata.guid !== undefined && respdata.uuid !== undefined) {
                        let guid = respdata.guid;
                        let uuid = respdata.uuid;
                        // let guid = '730005128462'; //TEST CODE
                        // let uuid = '10534322-bf9c-4d45-a35f-f4c9b8e9982b';
                        requestManager.onGenGlobalIDResponse(request, response);
                        let data = {
                            channel: CONSTANTS.kChannel,
                            guid: guid,
                            uuid: uuid,
                        };
                        requestManager.doGetProfile(data, (request, response) => {
                            requestManager.onDoGetProfileResponse(request, response);
                            let sguid = ProfileSelector.getGUID(dataServer.getStore().getState());
                            if ((sguid ?? 0) !== 0) {
                                pushNtfMgr.doUpdateDevicePin(true);
                                this.setState({
                                    initState: appInitialState.SHOWSPLASHSCRN,
                                });
                            }
                            dataServer.debouncedDispatch(actionSetIdle());
                        }); //NO NEED TO ADD GET PROFILE CALL
                    }
                } else {
                    dataServer.debouncedDispatch(actionSetIdle());
                }
                //NO ELSE CHECKING FOR REQUEST FAILURE
            });
        }
    };

    onActiveGamesListResposeReceive = (response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let respdata: GamesListResponse = ((response.data: any): GamesListResponse);
            let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
            dataServer.getStore().dispatch(actionAddGames(respdata, profile));
        }

        //NO ELSE CHECKING FOR REQUEST FAILURE
    };

    onArchiveGamesListResposeReceive = (response: ServerResponse) => {
        if (response.check === CONSTANTS.kSuccess) {
            let respdata: GamesListResponse = ((response.data: any): GamesListResponse);
            let profile = ProfileSelector.getProfile(dataServer.getStore().getState());
            dataServer.getStore().dispatch(actionAddGames(respdata, profile));
        }

        //NO ELSE CHECKING FOR REQUEST FAILURE
    };

    render() {
        let pic = Platform.select({
            native: () => {
                return { uri: 'splash' };
            },
            default: () => {
                return {};
            },
        });
        if (this.state.initState == appInitialState.SHOWLOADING) {
            return (
                <SafeAreaProvider>
                    <StatusBar hidden={Platform.OS === 'ios' ? true : false} />
                    <LoadingContainer />
                    <AlertBox />
                    <ImageBackground source={pic()} style={styles.bkgImage} />
                    {this.state.showMultipleAccountSelection ? this.state.showMultipleAccountSelection() : null}
                </SafeAreaProvider>
            );
        }
        return this.installNavigator();
    }

    installNavigator = () => {
        let showsplash: boolean = this.state.initState === appInitialState.SHOWSPLASHSCRN;
        let showgamelist: boolean = this.state.initState === appInitialState.SHOWGMLSTSCRN;
        if (showgamelist) {
            return this.installNavigatorWithHome();
        } else if (showsplash) {
            return this.installNavigatorWithSplash();
        } else {
            return this.installNavigatorWithSplash();
        }
    };

    installNavigatorWithSplash() {
        return (
            <CONSTANTS.Stack.Navigator>
                {this.getSplashScreen()}
                {this.getHomeScreen()}
                {this.getLXLSBoardScreen()}
                {this.getLXLSStatsProfileScreen()}
                {this.getLXLSEmailOrUserNameScreen()}
                {this.getLXLSExistingPwdScreen()}
                {this.getLXLSRegUserNameScreen()}
                {this.getLXLSRegPwdScreen()}
                {this.getLXLSTutorialScreen()}
                {this.getCustomerSupportScreen()}
                {this.getThemeSwiperScreen()}
                {this.getArchiveGamesListScreen()}
            </CONSTANTS.Stack.Navigator>
        );
    }

    installNavigatorWithHome() {
        return (
            <CONSTANTS.Stack.Navigator>
                {this.getHomeScreen()}
                {this.getLXLSBoardScreen()}
                {this.getLXLSStatsProfileScreen()}
                {this.getLXLSEmailOrUserNameScreen()}
                {this.getLXLSExistingPwdScreen()}
                {this.getLXLSRegUserNameScreen()}
                {this.getLXLSRegPwdScreen()}
                {this.getLXLSTutorialScreen()}
                {this.getCustomerSupportScreen()}
                {this.getThemeSwiperScreen()}
                {this.getArchiveGamesListScreen()}
            </CONSTANTS.Stack.Navigator>
        );
    }

    getSplashScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="Splash"
                component={SplashContainer}
                options={{
                    title: '',
                    headerShown: false,
                }}
            />
        );
    }

    getHomeScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="Home"
                component={HomeScreenContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSBoardScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="BoardScreen"
                component={GameBoardContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: false,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSStatsProfileScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="StatsProfile"
                component={ProfileStatsContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSEmailOrUserNameScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="UserNameOREmail"
                component={LNRVwContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSExistingPwdScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="ExstPwd"
                component={LNRVwContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSRegUserNameScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="RegUserName"
                component={LNRVwContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }

    getLXLSRegPwdScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="RegPwd"
                component={LNRVwContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }
    getLXLSTutorialScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="Tutorial"
                component={TutorialVwContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }
    getCustomerSupportScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="CustomerSupportScreen"
                component={CustomerSupportScreenContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }
    getThemeSwiperScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="Theme"
                component={RJSHRpicker}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                }}
            />
        );
    }

    getArchiveGamesListScreen() {
        return (
            <CONSTANTS.Stack.Screen
                name="AGLContainer"
                component={AGLContainer}
                options={{
                    headerTitle: <NavLexLogo />,
                    headerLeft: () => null,
                    headerStyle: {
                        backgroundColor: '#1d9df1', //Set Header color
                    },
                    headerShown: true,
                    headerTitleAlign: 'center',
                    ...TransitionPresets.SlideFromRightIOS,
                }}
            />
        );
    }
}

const styles = StyleSheet.create({
    bkgImage: {
        flex: 1,
        width: '100%',
        height: '100%',
        justifyContent: 'center',
    },
});

export default AppSplash;
