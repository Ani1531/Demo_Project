// @flow

import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import themeConfigutation from '../commons/ThemeConfiguration';

type TutorialHeaderProps = {
    HeaderText: string,
};

export default class TutorialHeader extends Component<TutorialHeaderProps> {
    constructor(props: TutorialHeaderProps) {
        super(props);
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <Text style={{ textAlign: 'center', fontSize: 22, color: themeConfigutation.getColor('#000') }}>
                        {this.props.HeaderText}
                    </Text>
                </View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        padding: 5,
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
    },
    headerView: {
        width: '100%',
        justifyContent: 'center',
        flexDirection: 'row',
    },
});
