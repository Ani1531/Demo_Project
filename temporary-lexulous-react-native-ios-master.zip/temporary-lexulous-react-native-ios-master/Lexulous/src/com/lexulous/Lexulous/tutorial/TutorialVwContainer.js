// @flow
import React from 'react';
import { View, Text, Animated, Dimensions, ScrollView, Image, Pressable, StyleSheet, Platform } from 'react-native';
import TutorialHeader from './TutorialHeader';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faPlay, faSync, faShare, faRandom, faReply, faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';

import { translate } from '../commons/translations/LangTransator';
import type { NavigationStackProp } from '@react-navigation/native';
import rjAnalytics from '../../../../RJAnalytics';
import { type ScrollEvent } from 'react-native/Libraries/Types/CoreEventTypes';
import themeConfigutation from '../commons/ThemeConfiguration';
import { connect } from 'react-redux';
import type { AppUtilsTypes } from '../commons/RJTypes';
import { SafeAreaView } from 'react-native-safe-area-context';

type TutorialVwContainerProps = {
    ...NavigationStackProp,
    utils: AppUtilsTypes,
};

type TutorialVwContainerState = {
    tutorialHeaderTitle: Array<{ Title: string }>,
    isFocused: boolean,
    dim: any,
    currentPage: number,
    scrollViewRef: any,
};
class TutorialVwContainer extends React.Component<TutorialVwContainerProps, TutorialVwContainerState> {
    unsubscribeFocusListener: ?() => void = null;
    unsubscribeBlurListener: ?() => void = null;
    unsubscribeDimensionListener: ?() => void = null;
    scrollX = new Animated.Value(0);

    constructor(props: TutorialVwContainerProps) {
        super(props);
        this.state = {
            isFocused: false,
            tutorialHeaderTitle: [
                {
                    Title: translate('tutrl_Wlcm'),
                },
                {
                    Title: translate('tutrl_objtv'),
                },
                {
                    Title: translate('tutrl_points'),
                },
                {
                    Title: translate('tutrl_rules'),
                },
                {
                    Title: translate('tutrl_bttns'),
                },
                {
                    Title: translate('tutrl_end'),
                },
                {
                    Title: translate('tutrl_thank'),
                },
            ],
            dim: Dimensions.get('window'),
            currentPage: 0,
            scrollViewRef: React.createRef(),
        };
    }
    componentDidMount() {
        this.props.navigation.setOptions({
            headerLeft: () => {
                return (
                    <Pressable
                        style={styles.backButton}
                        onPress={() => {
                            rjAnalytics.sendAnalyticsEvent('tutorial_closed', 'tutorial_vw_container');
                            this.props.navigation.goBack();
                        }}
                    >
                        <FontAwesomeIcon icon={faChevronLeft} size={25} color={'#fff'} />
                    </Pressable>
                );
            },
        });
        this.unsubscribeFocusListener = this.props.navigation.addListener('focus', () => {
            if (this.state.isFocused == false) {
                this.setState({ isFocused: true });
            }
        });
        this.unsubscribeBlurListener = this.props.navigation.addListener('blur', () => {
            if (this.state.isFocused == true) {
                this.setState({ isFocused: false });
            }
        });
        this.unsubscribeDimensionListener = Dimensions.addEventListener('change', this.onChange);
    }

    componentWillUnmount() {
        if (this.unsubscribeFocusListener) {
            this.unsubscribeFocusListener();
        }
        if (this.unsubscribeBlurListener) {
            this.unsubscribeBlurListener();
        }
        if (this.unsubscribeDimensionListener) {
            this.unsubscribeDimensionListener();
        }
    }

    onChange = (evt: any) => {
        this.setState({ dim: evt.window });
    };

    renderInfoType(type: string) {
        let lexulous_bg = { uri: 'splash' };
        let imageView = { marginTop: 20, width: this.state.dim.width, height: this.state.dim.width };
        if (Platform.OS === 'web') {
            lexulous_bg = require('../assets/lexbg/lex_bg.png');
            imageView.marginTop = 5;
            imageView.height = this.state.dim.height - 270;
        }
        switch (type) {
            case translate('tutrl_Wlcm'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('intro1')}
                            </Text>
                        </View>
                        <View style={imageView}>
                            <Image source={lexulous_bg} resizeMode="cover" style={{ height: '100%', width: '100%' }} />
                        </View>
                    </View>
                );

            case translate('tutrl_objtv'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('rule1')}
                            </Text>
                        </View>
                        <View>
                            <View style={imageView}>
                                <Image source={lexulous_bg} resizeMode="cover" style={{ height: '100%', width: '100%' }} />
                            </View>
                            <View
                                style={{
                                    minHeight: 90,
                                    width: 140,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    top: 30,
                                    left: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>{translate('rule2')}</Text>
                            </View>
                            <View
                                style={{
                                    minHeight: 90,
                                    width: 140,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    top:
                                        Platform.OS === 'web'
                                            ? Math.floor(this.state.dim.height / 2.3)
                                            : Math.floor(this.state.dim.width / 2.3),
                                    right: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>{translate('rule3')}</Text>
                            </View>
                            <View
                                style={{
                                    minHeight: 60,
                                    width: 120,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    bottom: 50,
                                    left: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>{translate('rule4')}</Text>
                            </View>
                        </View>
                    </View>
                );
            case translate('tutrl_points'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('scoreRule1')}
                            </Text>
                        </View>
                        <View>
                            <View style={imageView}>
                                <Image source={lexulous_bg} resizeMode="cover" style={{ height: '100%', width: '100%' }} />
                            </View>
                            <View
                                style={{
                                    minHeight: 90,
                                    width: 140,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    top: 30,
                                    left: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>
                                    {translate('scoreRule2')}
                                </Text>
                            </View>
                            <View
                                style={{
                                    minHeight: 90,
                                    width: 140,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    top:
                                        Platform.OS === 'web'
                                            ? Math.floor(this.state.dim.height / 2.3)
                                            : Math.floor(this.state.dim.width / 2.3),
                                    right: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>
                                    {translate('scoreRule3')}
                                </Text>
                            </View>
                            <View
                                style={{
                                    minHeight: 90,
                                    width: 140,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: '#000',
                                    position: 'absolute',
                                    bottom: 50,
                                    left: 20,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff', padding: 6 }]}>
                                    {translate('scoreRule4')}
                                </Text>
                            </View>
                        </View>
                    </View>
                );
            case translate('tutrl_rules'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('gameRule1')}
                            </Text>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                marginTop: 20,
                            }}
                        >
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingTop: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule2i')}</Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule2ii')}</Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingBottom: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule2iii')}</Text>
                            </View>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                marginTop: 20,
                            }}
                        >
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingTop: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule3i')}</Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingBottom: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule3ii')}</Text>
                            </View>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                marginTop: 20,
                            }}
                        >
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingTop: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule4i')}</Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule4ii')}</Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: 'row',
                                    paddingHorizontal: 8,
                                    paddingBottom: 8,
                                }}
                            >
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                                <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('gameRule4iii')}</Text>
                            </View>
                        </View>
                    </View>
                );
            case translate('tutrl_bttns'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('btn_titleMsg')}
                            </Text>
                        </View>
                        <View
                            style={{
                                margin: 7,
                                marginTop: 30,
                                flexDirection: 'row',
                            }}
                        >
                            <View style={styles.buttonView}>
                                <FontAwesomeIcon icon={faPlay} size={15} style={{ color: '#fff' }} />
                            </View>
                            <View style={[styles.buttonDetailstyle, { width: this.state.dim.width - 70 }]}>
                                <Text style={[styles.infoTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                                    <Text style={styles.actionButtonStyle}>{translate('play')}</Text>
                                    {translate('btn_playMsg')}
                                </Text>
                            </View>
                        </View>
                        <View
                            style={{
                                margin: 7,
                                marginTop: 10,
                                flexDirection: 'row',
                            }}
                        >
                            <View style={styles.buttonView}>
                                <FontAwesomeIcon icon={faSync} size={15} style={{ color: '#fff' }} />
                            </View>
                            <View style={[styles.buttonDetailstyle, { width: this.state.dim.width - 70 }]}>
                                <Text style={[styles.infoTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                                    <Text style={styles.actionButtonStyle}>{translate('swap')}</Text>
                                    {translate('btn_swapMsg')}
                                </Text>
                            </View>
                        </View>
                        <View
                            style={{
                                margin: 7,
                                marginTop: 10,
                                flexDirection: 'row',
                            }}
                        >
                            <View style={styles.buttonView}>
                                <FontAwesomeIcon icon={faShare} size={15} style={{ color: '#fff' }} />
                            </View>
                            <View style={[styles.buttonDetailstyle, { width: this.state.dim.width - 70 }]}>
                                <Text style={[styles.infoTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                                    <Text style={styles.actionButtonStyle}>{translate('pass')}</Text>
                                    {translate('btn_passMsg')}
                                </Text>
                            </View>
                        </View>
                        <View
                            style={{
                                margin: 7,
                                marginTop: 10,
                                flexDirection: 'row',
                            }}
                        >
                            <View style={styles.buttonView}>
                                <FontAwesomeIcon icon={faRandom} size={15} style={{ color: '#fff' }} />
                            </View>
                            <View style={[styles.buttonDetailstyle, { width: this.state.dim.width - 70 }]}>
                                <Text style={[styles.infoTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                                    <Text style={styles.actionButtonStyle}>{translate('shuffle')}</Text>
                                    {translate('btn_shuffleMsg')}
                                </Text>
                            </View>
                        </View>
                        <View
                            style={{
                                margin: 7,
                                marginTop: 10,
                                flexDirection: 'row',
                            }}
                        >
                            <View style={styles.buttonView}>
                                <FontAwesomeIcon icon={faReply} size={15} style={{ color: '#fff' }} />
                            </View>
                            <View style={[styles.buttonDetailstyle, { width: this.state.dim.width - 70 }]}>
                                <Text style={[styles.infoTextstyle, { color: themeConfigutation.getColor('#5f6368') }]}>
                                    <Text style={styles.actionButtonStyle}>{translate('recall')}</Text>
                                    {translate('btn_recallMsg')}
                                </Text>
                            </View>
                        </View>
                    </View>
                );
            case translate('tutrl_end'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('endrule1')}
                            </Text>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                marginTop: 20,
                                flexDirection: 'row',
                                padding: 8,
                            }}
                        >
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('endrule2')}</Text>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                flexDirection: 'row',
                                padding: 8,
                            }}
                        >
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('endrule3')}</Text>
                        </View>
                        <View
                            style={{
                                backgroundColor: themeConfigutation.getColor('#0d0d0d'),
                                margin: 8,
                                flexDirection: 'row',
                                padding: 8,
                            }}
                        >
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>- </Text>
                            <Text style={[styles.infoTextstyle, { color: '#fff' }]}>{translate('endrule4')}</Text>
                        </View>
                    </View>
                );
            case translate('tutrl_thank'):
                return (
                    <View>
                        <View style={{ height: 100 }}>
                            <Text style={[styles.subTitleView, { color: themeConfigutation.getColor('#5f6368') }]}>
                                {translate('statement1')}
                            </Text>
                        </View>
                        <Pressable
                            onPress={() => {
                                rjAnalytics.sendAnalyticsEvent('tutorial_play_closed', 'tutorial_vw_container');
                                this.props.navigation.goBack();
                            }}
                            style={styles.playButtonView}
                        >
                            <Text style={{ color: '#fff', fontSize: 13 }}>{translate('play')}!</Text>
                        </Pressable>
                    </View>
                );

            default:
                return null;
        }
    }

    handleScroll = (event: ScrollEvent) => {
        this.setState({ currentPage: Math.round(parseFloat(event.nativeEvent.contentOffset.x / this.state.dim.width)) });
    };

    renderScrollLeftArrow() {
        let scroll_left_arrow = null;
        if (Platform.OS === 'web') {
            scroll_left_arrow = (
                <Pressable
                    onPress={() => {
                        this.state.scrollViewRef.current.scrollTo({
                            x: this.state.dim.width * (this.state.currentPage - 1),
                        });
                    }}
                    disabled={this.state.currentPage === 0}
                >
                    <FontAwesomeIcon
                        icon={faChevronLeft}
                        size={30}
                        color={this.state.currentPage === 0 ? '#ABB2B9' : themeConfigutation.getColor('#000')}
                    />
                </Pressable>
            );
        }
        return scroll_left_arrow;
    }

    renderScrollRightArrow = () => {
        let scroll_right_arrow = null;
        if (Platform.OS === 'web') {
            let total_scroll_item = this.state.tutorialHeaderTitle.length - 1;
            scroll_right_arrow = (
                <Pressable
                    onPress={() => {
                        this.state.scrollViewRef.current.scrollTo({
                            x: this.state.dim.width * (this.state.currentPage + 1),
                        });
                    }}
                    disabled={this.state.currentPage === total_scroll_item}
                >
                    <FontAwesomeIcon
                        icon={faChevronRight}
                        size={30}
                        color={this.state.currentPage === total_scroll_item ? '#ABB2B9' : themeConfigutation.getColor('#000')}
                    />
                </Pressable>
            );
        }
        return scroll_right_arrow;
    };

    render() {
        let position = Animated.divide(this.scrollX, this.state.dim.width);
        let otptrng: Array<number> = [0.3, 1, 0.3];
        return this.state.isFocused ? (
            <SafeAreaView edges={['right', 'bottom', 'left']} style={{ flex: 1 }}>
                <View style={{ flex: 1, backgroundColor: themeConfigutation.getColor('#fff') }}>
                    <ScrollView
                        horizontal={true}
                        pagingEnabled={true}
                        showsHorizontalScrollIndicator={false}
                        onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: this.scrollX } } }], {
                            useNativeDriver: false,
                            listener: this.handleScroll,
                        })}
                        scrollEventThrottle={16}
                        ref={this.state.scrollViewRef}
                    >
                        {this.state.tutorialHeaderTitle.map((item2, index) => {
                            return (
                                <View key={index} style={{ width: this.state.dim.width }}>
                                    <TutorialHeader HeaderText={item2.Title} />
                                    {this.renderInfoType(item2.Title)}
                                </View>
                            );
                        })}
                    </ScrollView>

                    <View style={styles.footerView}>
                        {this.renderScrollLeftArrow()}
                        <View style={styles.indicatorview}>
                            {this.state.tutorialHeaderTitle.length > 0 &&
                                this.state.tutorialHeaderTitle.map((_, i) => {
                                    let opacity = position.interpolate({
                                        inputRange: [i - 1, i, i + 1],
                                        outputRange: otptrng,
                                        extrapolate: 'clamp',
                                    });
                                    return (
                                        <Animated.View
                                            key={i}
                                            style={[
                                                styles.indicatorCircle,
                                                {
                                                    backgroundColor: themeConfigutation.getColor('#444'),
                                                    opacity,
                                                },
                                            ]}
                                        />
                                    );
                                })}
                        </View>
                        {this.renderScrollRightArrow()}
                    </View>
                </View>
            </SafeAreaView>
        ) : null;
    }
}
const styles = StyleSheet.create({
    subTitleView: {
        padding: 4,
        margin: 8,
        marginTop: 10,
        ...Platform.select({
            native: {
                fontSize: 15,
            },
            web: {
                fontSize: 19,
                textAlign: 'center',
            },
        }),
    },
    buttonView: {
        backgroundColor: '#0B4D97',
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
        height: 30,
        width: 30,
    },
    infoTextstyle: {
        fontSize: Platform.OS === 'web' ? 17 : 13,
        textAlign: 'left',
        fontStyle: 'normal',
    },
    buttonDetailstyle: {
        marginLeft: 4,
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
    },
    backButton: {
        padding: 10,
    },
    actionButtonStyle: {
        color: '#F2170C',
        fontWeight: 'bold',
        paddingRight: 4,
    },
    indicatorview: {
        flexDirection: 'row',
        height: 10,
        zIndex: 9,
        paddingHorizontal: 75,
    },
    indicatorCircle: {
        height: 6,
        width: 6,
        margin: 2,
        borderRadius: 30,
    },
    playButtonView: {
        padding: 8,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        borderRadius: 4,
        width: 70,
        marginTop: 30,
        backgroundColor: '#1d9df1',
    },
    footerView: {
        height: 60,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

function mapStateToProps(state) {
    const { utils } = state;
    return { utils };
}
export default connect(mapStateToProps, null)(TutorialVwContainer);
