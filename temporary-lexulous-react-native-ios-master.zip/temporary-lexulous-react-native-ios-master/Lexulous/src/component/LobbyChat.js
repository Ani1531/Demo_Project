import React from 'react';
import { StyleSheet, View, TouchableOpacity, ScrollView } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import {
    faTextSize,
    faMicrophone,
    faMicrophoneSlash,
    faCommentAlt,
    faCommentAltSlash,
    faCopy,
} from '@fortawesome/pro-regular-svg-icons';
import ColorConfig from '../configs/ColorConfig';
import Config from '../configs/Config';
import DimensionUtils from '../utils/DimensionUtils';
import LiveGameChat from './LiveGameChat';
import SettingsUtil from '../utils/SettingsUtil';
import {
    CONFIG_SET_SETTING,
    SET_ACTIVE_PVT_MESSAGE_KEY,
    REMOVE_PVT_MESSAGE_KEY,
} from '../configs/ActionIdentifiers';
import { connect } from 'react-redux';
import isEqual from 'lodash/isEqual';
import get from 'lodash/get';
import { getNull } from '../utils/Utils';
import { formatName } from '../utils/StringUtils';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import TooltipWrapper from './TooltipWrapper';
import S14Text from './S14Text';
import S10Text from './S10Text';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

const eventBus = require('js-event-bus')();

function handlePrivateChatTabActivation() {
    this.activateTab(this.guid);
}

class LobbyChat extends React.Component {
    constructor(props) {
        super(props);
        this.privateChatTabScrollView = React.createRef();
        this.liveGameChat = React.createRef();
    }

    componentDidUpdate() {
        TooltipActionWrapper.rebuild();
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return (
            !isEqual(
                get(this.props, 'config.lobby_game_update'),
                get(nextProps, 'config.lobby_game_update')
            ) ||
            !isEqual(
                get(this.props, 'config.show_lobby_chat'),
                get(nextProps, 'config.show_lobby_chat')
            ) ||
            !isEqual(
                get(this.props, 'lobbyChat.pvtMessages'),
                get(nextProps, 'lobbyChat.pvtMessages')
            ) ||
            !isEqual(
                get(this.props, 'lobbyChat.activePvtMessageKey'),
                get(nextProps, 'lobbyChat.activePvtMessageKey')
            ) ||
            !isEqual(
                get(this.props, 'lobbyChat.lobbyMsgUnreadCount'),
                get(nextProps, 'lobbyChat.lobbyMsgUnreadCount')
            )
        );
    };

    getIconCommonStyle = (rightMargin = true) => ({
        marginRight: rightMargin ? 10 : null,
    });

    copyMessages = () => {
        this.liveGameChat.current && this.liveGameChat.current.copyMessages();
    };

    fontSizeUpdateSetting = () => {
        let fontSize = Number(this.props.config.gp_chtfntsze);
        this.saveSettingsData({
            gp_chtfntsze: fontSize >= 18 ? 10 : fontSize + 2,
        });
    };

    toggleGameUpdateSetting = () => {
        this.saveSettingsData({
            lobby_game_update: !this.props.config.lobby_game_update,
        });
    };

    toggleLobbyChatSetting = () => {
        this.saveSettingsData({
            show_lobby_chat: !this.props.config.show_lobby_chat,
        });
    };

    saveSettingsData = (obj) => {
        eventBus.emit(CONFIG_SET_SETTING, null, obj);
        let data = {
            ...(obj.hasOwnProperty('gp_chtfntsze')
                ? { gp_chtfntsze: obj.gp_chtfntsze }
                : {}),
            ...(obj.hasOwnProperty('lobby_game_update')
                ? { lobby_game_update: obj.lobby_game_update }
                : {}),
            ...(obj.hasOwnProperty('show_lobby_chat')
                ? { show_lobby_chat: obj.show_lobby_chat }
                : {}),
        };
        SettingsUtil.sendSetting(data);
    };

    getAdditionalTabStyle = (guid) => ({
        backgroundColor:
            this.props.lobbyChat.activePvtMessageKey === guid
                ? ColorConfig.TAB_SELECTED_COLOR
                : undefined,
        cursor:
            this.props.lobbyChat.activePvtMessageKey === guid
                ? 'default'
                : 'pointer',
        paddingLeft:
            !!guid && this.props.lobbyChat.activePvtMessageKey === guid
                ? 10
                : 16,
        paddingRight:
            !!guid && this.props.lobbyChat.activePvtMessageKey === guid
                ? 8
                : 16,
    });

    getTabText = (guid) => {
        const { pvtMessages } = this.props.lobbyChat;
        return formatName(pvtMessages[guid]['name']);
    };

    activateTab = (guid) => {
        eventBus.emit(SET_ACTIVE_PVT_MESSAGE_KEY, null, guid);
        if (typeof guid === 'undefined') {
            this.scrollToScrollViewStart();
        }
    };

    getCloseButtonStyle = () => ({
        fontSize: 12,
        color: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR,
    });

    removeTab = () => {
        eventBus.emit(
            REMOVE_PVT_MESSAGE_KEY,
            null,
            this.props.lobbyChat.activePvtMessageKey
        );
        this.scrollToScrollViewStart();
    };

    getTabTextStyle = (guid) => {
        let obj = { color: ColorConfig.TOOL_CHAT_TAB_TEXT_COLOR };
        if (
            typeof guid !== 'undefined' &&
            guid !== this.props.lobbyChat.activePvtMessageKey
        ) {
            let pvtMessages = this.props.lobbyChat.pvtMessages[guid];

            if (pvtMessages.unreadCount > 0) {
                obj.color = ColorConfig.PLAY_BUTTON_NEXT_BACKGROUND_COLOR;
                obj.fontWeight = 'bold';
            }
        }
        return obj;
    };

    getChatCount = (guid) =>
        !!guid
            ? String(this.props.lobbyChat.pvtMessages[guid].unreadCount)
            : get(this.props, 'lobbyChat.lobbyMsgUnreadCount');

    getCircleDimension = (isCount10Plus) => ({
        height: isCount10Plus ? 20 : 15,
        width: isCount10Plus ? 20 : 15,
        borderRadius: (isCount10Plus ? 20 : 15) / 2,
    });

    renderTab = (guid) => (
        <View
            key={'lobby_chat_view_11_' + guid}
            style={[styles.tab, this.getAdditionalTabStyle(guid)]}
        >
            <TouchableOpacity
                key={'lobby_chat_view_12_' + guid}
                onPress={
                    this.props.lobbyChat.activePvtMessageKey &&
                    guid === this.props.lobbyChat.activePvtMessageKey
                        ? getNull
                        : handlePrivateChatTabActivation.bind({
                              activateTab: this.activateTab,
                              guid: guid,
                          })
                }
                activeOpacity={1}
                style={styles.pvtChatTabTextUnreadCntRowStyle}
            >
                <S14Text style={this.getTabTextStyle(guid)}>
                    {!!guid ? this.getTabText(guid) : 'Lobby'}
                </S14Text>
                {this.getChatCount(guid) > 0 && (
                    <View
                        key={'lobby_chat_view_13_' + guid}
                        style={[
                            styles.pvtChatTabUnreadCntViewStyle,
                            this.getCircleDimension(
                                this.getChatCount(guid) > 9
                            ),
                        ]}
                    >
                        <S10Text style={styles.pvtChatTabUnreadCntTextStyle}>
                            {this.getChatCount(guid) > 9
                                ? '10+'
                                : this.getChatCount(guid)}
                        </S10Text>
                    </View>
                )}
            </TouchableOpacity>
            {!!guid && guid === this.props.lobbyChat.activePvtMessageKey ? (
                <TouchableOpacity
                    key={'lobby_chat_view_14_' + guid}
                    activeOpacity={1}
                    style={styles.closeTabIconContainer}
                    onPress={this.removeTab}
                >
                    <FontAwesomeIcon
                        key={'close_btn_' + guid}
                        icon={faTimes}
                        size={12}
                        style={this.getCloseButtonStyle()}
                    />
                </TouchableOpacity>
            ) : null}
        </View>
    );

    isPrivateMessageAvailable = () =>
        (Object.keys(this.props.lobbyChat.pvtMessages) || []).length > 0;

    scrollToScrollViewEnd = () => {
        this.privateChatTabScrollView.current.scrollToEnd({ animated: true });
    };

    scrollToScrollViewStart = () => {
        this.privateChatTabScrollView.current.scrollTo({
            x: 0,
            y: 0,
            animated: true,
        });
    };

    render = () => (
        <View
            key={'lobby_chat_view_1'}
            style={
                DimensionUtils.isMobile()
                    ? styles.lobbyChatContainerMobile
                    : styles.lobbyChatContainer
            }
        >
            <View
                key={'lobby_chat_view_2'}
                style={[
                    styles.lobbyChatHeader,
                    this.isPrivateMessageAvailable()
                        ? styles.privateLobbyChatHeader
                        : styles.positionCenter,
                ]}
            >
                {this.isPrivateMessageAvailable() ? (
                    <View key={'lobby_chat_view_3'} style={styles.tabContainer}>
                        <ScrollView
                            horizontal={true}
                            showsHorizontalScrollIndicator={true}
                            ref={this.privateChatTabScrollView}
                            onContentSizeChange={this.scrollToScrollViewEnd}
                            className="customScrollView"
                        >
                            {this.renderTab()}
                            {Object.keys(this.props.lobbyChat.pvtMessages).map(
                                (guid, index) => {
                                    return this.renderTab(guid);
                                }
                            )}
                        </ScrollView>
                    </View>
                ) : (
                    <S14Text style={styles.headerText}>{'Lobby'}</S14Text>
                )}

                <View
                    key={'lobby_chat_view_4'}
                    style={[
                        styles.iconContainer,
                        this.isPrivateMessageAvailable()
                            ? styles.privateLobbyChatIconContainer
                            : null,
                    ]}
                >
                    <TooltipWrapper
                        key={'lobby_chat_view_5'}
                        tooltip={'Copy Conversation'}
                        onPress={this.copyMessages}
                    >
                        <FontAwesomeIcon
                            key={'copy-conversion'}
                            icon={faCopy}
                            size={18}
                            style={[this.getIconCommonStyle()]}
                        />
                    </TooltipWrapper>

                    <TooltipWrapper
                        key={'lobby_chat_view_6'}
                        tooltip={'Change Font Size'}
                        onPress={this.fontSizeUpdateSetting}
                    >
                        <FontAwesomeIcon
                            key={'font-size-update'}
                            icon={faTextSize}
                            size={18}
                            style={[this.getIconCommonStyle()]}
                        />
                    </TooltipWrapper>

                    <TooltipWrapper
                        key={'lobby_chat_view_7'}
                        tooltip={
                            this.props.config.lobby_game_update
                                ? 'Disable Game Updates'
                                : 'Enable Game Updates'
                        }
                        onPress={this.toggleGameUpdateSetting}
                    >
                        <FontAwesomeIcon
                            key={
                                this.props.config.lobby_game_update
                                    ? 'enable-game-update'
                                    : 'disable-game-update'
                            }
                            icon={
                                this.props.config.lobby_game_update
                                    ? faMicrophone
                                    : faMicrophoneSlash
                            }
                            size={18}
                            style={[this.getIconCommonStyle()]}
                        />
                    </TooltipWrapper>

                    <TooltipWrapper
                        key={'lobby_chat_view_8'}
                        tooltip={
                            this.props.config.show_lobby_chat
                                ? 'Disable Chat'
                                : 'Enable Chat'
                        }
                        onPress={this.toggleLobbyChatSetting}
                    >
                        <FontAwesomeIcon
                            key={
                                this.props.config.show_lobby_chat
                                    ? 'lobby-chat-enable'
                                    : 'lobby-chat-disable'
                            }
                            icon={
                                this.props.config.show_lobby_chat
                                    ? faCommentAlt
                                    : faCommentAltSlash
                            }
                            size={18}
                            style={[this.getIconCommonStyle(false)]}
                        />
                    </TooltipWrapper>
                </View>
            </View>
            <View key={'lobby_chat_view_9'} style={{ flex: 1 }}>
                <LiveGameChat
                    key={'lobby_chat_view_10'}
                    ref={this.liveGameChat}
                    isLobbyChat={true}
                    pvtMessageKey={this.props.lobbyChat.activePvtMessageKey}
                    width={DimensionUtils.getWindowDimensions().width}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    lobbyChatContainerMobile: {
        flex: 1,
    },
    lobbyChatContainer: {
        position: 'absolute',
        bottom: 0,
        width: '100%',
        height: Config.LOBBY_CHAT_VIEW_HEIGHT - Config.RIGHT_LEFT_MARGIN,
    },
    positionCenter: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    lobbyChatHeader: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        padding: Config.HEADER_CONTAINER_PADDING,
        borderBottomWidth: StyleSheet.hairlineWidth,
        width: '100%',
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    privateLobbyChatHeader: {
        paddingBottom: 0,
        borderBottomWidth: 0,
        flexDirection: 'row',
    },
    iconContainer: {
        flexDirection: 'row',
        alignSelf: 'flex-end',
    },
    privateLobbyChatIconContainer: {
        position: 'absolute',
        right: 8,
        top: 10,
    },
    headerText: {
        position: 'absolute',
    },
    tabContainer: {
        width: '90%',
    },
    tab: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 6,
        paddingBottom: 6,
        borderTopLeftRadius: Config.COMMON_BORDER_RADIUS,
        borderTopRightRadius: Config.COMMON_BORDER_RADIUS,
    },
    closeTabIconContainer: {
        justifyContent: 'center',
        marginLeft: 8,
        padding: 2,
    },
    pvtChatTabTextUnreadCntRowStyle: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    pvtChatTabUnreadCntViewStyle: {
        backgroundColor: 'rgb(194,55,66)',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 3,
    },
    pvtChatTabUnreadCntTextStyle: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: 'bold',
    },
});

const mapStateToProps = (state) => ({
    config: state.config,
    lobbyChat: state.lobbyChat,
});

export default connect(mapStateToProps)(LobbyChat);
