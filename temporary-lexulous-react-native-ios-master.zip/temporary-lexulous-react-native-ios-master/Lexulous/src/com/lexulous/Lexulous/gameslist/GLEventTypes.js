// @flow

export const CLR_GAMES: string = 'CLR_GAMES';
export const ADD_GAMES: string = 'ADD_GAMES';
export const GL_REFRESH_STARTED: string = 'GL_REFRESH_STARTED';
export const GL_REFRESH_FINISHED: string = 'GL_REFRESH_FINISHED';
export const UPDT_RVW_SHR: string = 'UPDT_RVW_SHR';
export const CLR_RVW_SHR: string = 'CLR_RVW_SHR';
export const GL_AD_EVT: string = 'GL_AD_EVT';
export const GL_READ_CHAT: string = 'GL_READ_CHAT';
export const GL_SVCCON_ADD_GAME: string = 'GL_SVCCON_ADD_GAME';
export const GL_UPDT_VIA_BOARD_INFO: string = 'GL_UPDT_VIA_BOARD_INFO';
