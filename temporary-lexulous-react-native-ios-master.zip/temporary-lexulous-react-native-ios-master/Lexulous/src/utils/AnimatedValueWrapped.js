import { getNull } from './Utils';

export default class AnimatedValueWrapped {
    static create = getNull;
    static compose = getNull;
}
