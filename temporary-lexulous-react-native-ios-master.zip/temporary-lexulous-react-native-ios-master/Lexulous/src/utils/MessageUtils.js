import Config from '../configs/Config';
import SoundUtils from '../utils/SoundUtils';

const eventBus = require('js-event-bus')();

const dialogMessage = {
    0: 'There seems to be a problem, please try again.',
};

export function getCustomMessage({ extcode, msg }) {
    if (dialogMessage[extcode]) {
        return dialogMessage[extcode];
    }
    return msg;
}

export function createDialogInstance(data) {
    eventBus.emit(Config.SHOW_DIALOG_MODAL, null, data);
}

export function createGeneralRequestFailureDialog({ onAction, body } = {}) {
    SoundUtils.errorSound();
    createDialogInstance({
        title: Config.DIALOG_HEADER_TEXT,
        body: body ? body : 'There seems to be a problem, please try again',
        cancelButtonText: onAction ? 'Cancel' : 'Ok',
        actionButtonText: onAction ? 'Retry' : undefined,
        onAction,
    });
}
