// @flow

import LgnMgr from './LgnMgr';

type AccessToken = {};

class FBLgnMgr extends LgnMgr {
    _accessToken: ?AccessToken = null;
    _tempOnLoginCallBack: ?() => void = null;
    type = 'FBLgnMgr';

    constructor() {
        super();
        this._accessToken = null;
        this._tempOnLoginCallBack = null;
    }

    get accessToken(): ?AccessToken {
        return this._accessToken;
    }

    checkLoginSilentModeAsync = async (): Promise<boolean> => {
        return false;
    };

    checkLoginSilentMode = (onboarduser: ?() => void) => {};

    isUserLoggedIn = async () => {};

    // onAssociationCompletion = async (onCompletion: ?() => void): Promise<void> => {
    //     this._tempOnLoginCallBack = null;
    //     super.onAssociationCompletion(onCompletion);
    // };

    doSignOut = async (onCompletion: ?() => void): Promise<void> => {};

    doFbLogin = (onCompletion: ?() => void) => {};

    fbTokenChangeListener = (accessToken: ?any) => {};

    fbDidLoggedOut = async (onCompletion: ?() => void) => {};

    getFbUserProfile = async (): Promise<?any> => {};

    retryFn = (maxRetries: number, fn: () => Promise<any>) => {};

    fbDidLoggedIn = (onCompletion: ?() => void) => {};

    doInviteFbFriends = () => {};
}
const fbLgnMgr: FBLgnMgr = new FBLgnMgr();

export default fbLgnMgr;
