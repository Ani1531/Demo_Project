// @flow

import type {
    ActionSetProfile,
    ActionUpdateProfile,
    ActionClearProfile,
    ActionUpdateAppleLgnInfo,
    ActionUpdateFBLgnInfo,
    ActionUpdateGGLLgnInfo,
    ActionUpdateLXLSLgnInfo,
    ProfileInfo,
    AppleLoginInfo,
    GGLLoginInfo,
    LXLSLoginInfo,
    FBLoginInfo,
    ActionProfileSettings,
    userSettings,
} from '../commons/RJTypes';

import {
    SET_PROFILE,
    UPDT_PROFILE,
    CLR_PROFILE,
    UPDT_APPL_LGN_INFO,
    UPDT_FB_LGN_INFO,
    UPDT_GGL_LGN_INFO,
    UPDT_LXLS_LGN_INFO,
    UPDT_SETTINGS,
} from './PFLEventTypes';

export const actionSetProfile = (profile: ProfileInfo): ActionSetProfile => {
    return {
        type: SET_PROFILE,
        payload: profile,
    };
};

export const actionUpdateProfile = (profile: ProfileInfo): ActionUpdateProfile => {
    return {
        type: UPDT_PROFILE,
        payload: profile,
    };
};

export const actionClearProfile = (): ActionClearProfile => {
    return {
        type: CLR_PROFILE,
    };
};

export const actionUpdateAppleLgnInfo = (lgninfo: ?AppleLoginInfo): ActionUpdateAppleLgnInfo => {
    return {
        type: UPDT_APPL_LGN_INFO,
        payload: lgninfo,
    };
};

export const actionUpdateFBLgnInfo = (lgninfo: ?FBLoginInfo): ActionUpdateFBLgnInfo => {
    return {
        type: UPDT_FB_LGN_INFO,
        payload: lgninfo,
    };
};

export const actionUpdateGGLLgnInfo = (lgninfo: ?GGLLoginInfo): ActionUpdateGGLLgnInfo => {
    return {
        type: UPDT_GGL_LGN_INFO,
        payload: lgninfo,
    };
};

export const actionUpdateLXLSLgnInfo = (lgninfo: ?LXLSLoginInfo): ActionUpdateLXLSLgnInfo => {
    return {
        type: UPDT_LXLS_LGN_INFO,
        payload: lgninfo,
    };
};

export const actionUpdateUserSettings = (settings: userSettings): ActionProfileSettings => {
    return {
        type: UPDT_SETTINGS,
        payload: settings,
    };
};
