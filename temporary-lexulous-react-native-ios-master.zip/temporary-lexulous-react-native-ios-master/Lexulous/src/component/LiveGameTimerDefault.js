import React from 'react';
import { Animated, Easing, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Config from '../configs/Config';
import get from 'lodash/get';
import isEqual from 'lodash/isEqual';
import isNumber from 'lodash/isNumber';
import Timer from 'react-compound-timer';
import { formatToTwoDigits } from '../utils/Utils';
import ColorConfig from '../configs/ColorConfig';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCaretRight, faCircle, faPlusSquare, faSignal } from '@fortawesome/free-solid-svg-icons';
import { isEmailGame, isLiveGame, isSoloGame, moreTime } from '../service/GamePlayService';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import TimeRemainingTooltip from './TimeRemainingTooltip';
import PlayerAvatarNameRating from './PlayerAvatarNameRating';
import GameBoardUtils from '../utils/GameBoardUtils';
import SoundUtils from '../utils/SoundUtils';
import { connect } from 'react-redux';
import log from 'loglevel';
import TooltipWrapper from './TooltipWrapper';
import DimensionUtils from '../utils/DimensionUtils';
import S14Text from './S14Text';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';
import PText from './PText';

const DEF_PLAYERS = ['player_1', 'player_2'];
class LiveGameTimerDefault extends React.Component {
    arrowPos = new Animated.Value(1);
    state = {};

    constructor(props) {
        super(props);
    }

    changeTurn = (yPos) =>
        Animated.timing(this.arrowPos, {
            toValue: yPos,
            useNativeDriver: true,
            easing: Easing.linear,
            duration: 500,
        }).start();

    componentDidMount = () => {
        this.setArrowPosition();
    };

    getScoreTimerMainContainerDimension = () => ({
        width: '100%',
    });

    setArrowPosition = () => {
        let pos = this.getScoreTimerContainerHeightAsNumber() / 2 - 10;
        pos = pos || 1;
        log.info('in LiveGameTimer, in setArrowPosition, pos will be: ' + pos);
        this.changeTurn(pos);
    };

    renderTurnView = () => {
        const animatedStyle = [
            {
                position: 'absolute',
                //top: this.arrowPos,
            },
            {
                transform: [
                    {
                        translateY: this.arrowPos,
                    },
                ],
            },
        ];
        return (
            <Animated.View style={animatedStyle}>
                <FontAwesomeIcon
                    size={20}
                    style={{
                        color: '#22B129',
                        width: 8,
                    }}
                    icon={faCaretRight}
                />
            </Animated.View>
        );
    };

    render = () => {
        return (
            <View
                key={'live-game-timer-container'}
                style={[styles.mainContainer, this.getScoreTimerMainContainerDimension()]}
                key={this.state.key}
            >
                {DEF_PLAYERS.map((playerData, index) => {
                    return this.renderPlayerTimerData(index);
                })}
                {this.renderTurnView()}
            </View>
        );
    };

    getItemFlexPosition = (index) => (index < DEF_PLAYERS.length / 2 ? styles.itemLeftSide : styles.itemLeftSide);

    getPlayerTimerStyle = (index, arr) => ({
        borderBottomWidth: index === (arr || []).length - 1 ? 0 : StyleSheet.hairlineWidth,
        borderColor: index === (arr || []).length - 1 ? undefined : ColorConfig.SIDE_PANEL_BORDER_COLOR,
        backgroundColor:
            index % 2 === 0
                ? ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD
                : ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN,
    });

    getScoreTimerContainerHeightAsNumber = () =>
        Math.round((this.props.layout.boardDimen * (DimensionUtils.isMobile() ? 10 : 9)) / 100);

    getScoreTimerContainerHeight = () => ({
        height: this.getScoreTimerContainerHeightAsNumber(),
    });

    renderPlayerTimerData = (index) => {
        return (
            <View
                key={'player_timer_data_container_' + index}
                style={[
                    styles.scoreTimerContainer,
                    this.getItemFlexPosition(index),
                    this.getPlayerTimerStyle(index),
                    this.getScoreTimerContainerHeight(),
                ]}
            >
                <View style={[styles.playerDataContainer, { width: '50%', overflow: 'hidden' }]}>
                    <View
                        style={[
                            StyleSheet.absoluteFill,
                            {
                                paddingLeft: 10,
                                alignItems: 'flex-start',
                                justifyContent: 'center',
                                overflow: 'hidden',
                            },
                        ]}
                    >
                        {this.playerAvatarNameRating()}
                    </View>
                </View>
                <View style={[styles.scoreDisplayingViewStyle, { width: '50%' }]}>
                    <S14Text style={[{ color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR }]}>{'0'}</S14Text>
                </View>
                {!isEmailGame() ? (
                    <View style={[styles.timerLeftSidePanelStyle, styles.timerContainerAfterBoardData, styles.pr14]}>
                        <View style={[styles.timerBeforeBoardData, styles.timerOuterPadding, styles.pr14]}>
                            <S14Text style={[{ color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR }]}>
                                {'00'}
                            </S14Text>

                            <S14Text style={[styles.pb4, { color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR }]}>
                                {':'}
                            </S14Text>

                            <S14Text style={[{ color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR }]}>
                                {'00'}
                            </S14Text>
                        </View>
                    </View>
                ) : null}
            </View>
        );
    };

    playerAvatarNameRating = () => (
        <View
            style={[
                {
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'flex-start',
                    overflow: 'hidden',
                    paddingLeft: 8,
                },
            ]}
        >
            <Image style={styles.playerImageSmall} source={require('../assets/avatars/1.png')} resizeMode={'contain'} />
            <View style={[{ flexDirection: 'column', padding: 0, margin: 0, alignItems: 'flex-start' }]}>
                <PText
                    numberOfLines={1}
                    ellipsizeMode={'tail'}
                    style={[
                        {
                            width: '100%',
                            color: ColorConfig.PLAYER_NAME_COLOR,
                        },
                    ]}
                >
                    {'Anonymous'}
                </PText>

                <View style={[{ flexDirection: 'row' } /* styles.styleBackgroundColorAndOverflowForNonSoloGame */]}>
                    <TooltipWrapper style={styles.ratingIconContainerStyle}>
                        <FontAwesomeIcon
                            icon={faCircle}
                            size={8}
                            style={{
                                ...this.getIconStyles(),
                            }}
                        />
                    </TooltipWrapper>

                    <PText style={[{ marginLeft: 4, color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR }]}>
                        {'1200'}
                    </PText>
                </View>
            </View>
        </View>
    );

    getIconStyles = () => {
        return {
            fontSize: 8,
            height: '100%',
            color: LiveGamePlayUtils.getDotColorAndTextForRating(1200).rating_color,
            backgroundColor: 'rgba(0,0,0,0)',
        };
    };
}

const styles = StyleSheet.create({
    mainContainer: {
        flexDirection: 'column',
        borderColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        borderBottomWidth: 0,
        overflow: 'hidden',
        backgroundColor: '#f4f3ef',
    },
    image: {
        flex: 1,
    },
    scoreTimerContainer: {
        flexDirection: 'row',
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
    },
    playerDataContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        height: '100%',
        borderRightColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
        borderRightWidth: 1,
    },
    timerContainer: {
        flex: 1,
    },
    timerContainerAfterBoardData: {
        flexDirection: 'row-reverse',
    },
    timerBeforeBoardData: {
        flexDirection: 'row',
        flex: 2,
        alignItems: 'center',
    },
    iconContainer: {
        flex: 6,
        flexDirection: 'column',
    },
    boardData: {
        flexDirection: 'column-reverse',
        flex: 1,
    },
    itemLeftSide: {
        alignItems: 'flex-start',
    },
    row: {
        flexDirection: 'row',
    },
    scoreDisplayingViewStyle: {
        width: '20%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    timerLeftSidePanelStyle: {
        height: '100%',
        width: '30%',
        alignItems: 'center',
        borderLeftWidth: 1,
        borderLeftColor: ColorConfig.SIDE_PANEL_BORDER_COLOR,
    },
    timerOuterPadding: { paddingLeft: 8 },
    pb4: {
        paddingBottom: 4,
    },
    pr14: {
        paddingRight: 10,
    },
    playerImageSmall: {
        height: 16,
        width: 16,
        marginRight: 5,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    ratingIconContainerStyle: {
        height: 15,
        width: 8,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(0,0,0,0)',
    },
});

const mapStateToProps = (state) => ({
    layout: state.layout,
});
export default connect(mapStateToProps)(LiveGameTimerDefault);
