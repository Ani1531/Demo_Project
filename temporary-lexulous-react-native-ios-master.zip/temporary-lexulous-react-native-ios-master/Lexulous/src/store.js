import { applyMiddleware, combineReducers, createStore } from 'redux';
import thunk from 'redux-thunk';
import ServiceUtils from './utils/ServiceUtils';
import PFLReducer from './com/lexulous/Lexulous/userprofile/PFLReducer';
import PFLSettingsReducer from './com/lexulous/Lexulous/userprofile/PFLSettingsReducer';
import PFLVwReducer from './com/lexulous/Lexulous/profileview/PFLVwReducer';
import GLReducer from './com/lexulous/Lexulous/gameslist/GLReducer';
import FndReducer from './com/lexulous/Lexulous/friends/FndReducer';
import LNRReducer from './com/lexulous/Lexulous/loginNregister/LNRReducer';
import MinStatsReducer from './com/lexulous/Lexulous/stats/minimalstats/MinStatsReducer';
import BusyReducer from './com/lexulous/Lexulous/commons/BusyReducer';
import UtilsReducer from './com/lexulous/Lexulous/commons/UtilsReducer';
import PopupReducer from './com/lexulous/Lexulous/reducers/popupreducer/PopupReducer';
import AGLReducer from './com/lexulous/Lexulous/archivegameslist/AGLReducer';
import HostedGameReducer from './com/lexulous/Lexulous/gamesfactory/hostedgames/HostedGameReducer';

export const rootReducer = combineReducers({
    ...ServiceUtils.getCommonReducers(),

    profile: PFLReducer,
    profileVw: PFLVwReducer,
    gamesList: GLReducer,
    friends: FndReducer,
    lnrVw: LNRReducer,
    minStats: MinStatsReducer,
    busyIndicator: BusyReducer,
    profileSettings: PFLSettingsReducer,
    utils: UtilsReducer,
    popups: PopupReducer,
    archiveGamesList: AGLReducer,
    hostedGames: HostedGameReducer,
});
const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
