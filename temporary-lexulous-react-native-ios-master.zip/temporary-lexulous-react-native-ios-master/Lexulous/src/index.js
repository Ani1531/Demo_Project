// index.js - WEB
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import browser from 'browser-detect';
import Config from './configs/Config';
import { isLiveGame, isSoloGame } from './service/GamePlayService';
import WordValidityWebSocketProvider from './provider/WordValidityWebSocketProvider';
import get from 'lodash/get';
import WebSocketProvider from './provider/WebSocketProvider';
import ConfigurationWrapper from './utils/ConfigurationWrapper';
import log from 'loglevel';
import { CONFIG_SET_SETTING, DIMENSION_SCREEN_RESIZE, RELOAD_APP } from './configs/ActionIdentifiers';
import { Provider } from 'react-redux';
import store from './store';
import NetInfo from '@react-native-community/netinfo';

let enableLog = !!ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('enable_log');
enableLog ? log.enableAll() : log.disableAll();

const result = browser();
window.isSafari = result && result.name && result.name.valueOf() === 'safari';
window.isMobile = result.mobile;
window.isSafariMobile = window.isSafari && window.isMobile;

NetInfo.configure({
    reachabilityUrl: 'https://www.google.com',
    reachabilityShouldRun: () => true,
});

!(isLiveGame() || isSoloGame()) && WordValidityWebSocketProvider.getWebSocketConnection();

const eventBus = require('js-event-bus')();
const root = document.getElementById(ConfigurationWrapper.getSpecificLexulousGeneralConfiguration('container_name'));
const AppContainer = (props) => (
    <Provider store={store}>
        <App key={Date.now()} />
    </Provider>
);

const render = async (data = {}) => {
    if (!get(data, 'firstRun')) {
        eventBus.emit(RELOAD_APP, null, data);
    }
    eventBus.emit(Config.DETACH_ALL_EVENT);
    ReactDOM.render(<AppContainer />, root);
};

window.destroy = () => {
    ReactDOM.unmountComponentAtNode(root);
    WebSocketProvider.disconnect();
    WordValidityWebSocketProvider.disconnect();
};

//eventBus.on(Config.RESTART_APP, render);

render({ firstRun: true });

registerServiceWorker();
