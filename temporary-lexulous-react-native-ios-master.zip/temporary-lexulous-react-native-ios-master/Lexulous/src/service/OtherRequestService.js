import Config from '../configs/Config';
import { getCustomMessage } from '../utils/MessageUtils';
import PuzzleGamePlayService from './PuzzleGamePlayService';
import RestAPIProvider from '../provider/RestAPIProvider';
import to from 'await-to-js';
import { GAME_RESOURCE_PANEL_WORD_VALIDITY } from '../configs/ActionIdentifiers';
import store from '../store';

const eventBus = require('js-event-bus')();

export const getDictionaryData = async (data) => {
    const state = store.getState();
    let params = {
        word: data,
        mobile: 'y',
        meaning: 'y',
        dic: state.game.dic,
    };

    let res = await to(RestAPIProvider.getDictionaryData(params));

    if (res[0]) {
        let extObj = PuzzleGamePlayService.getNotSuccessExitCodeInstance(res);
        throw new Error(getCustomMessage(extObj));
    } else {
        eventBus.emit(GAME_RESOURCE_PANEL_WORD_VALIDITY);
    }
};
