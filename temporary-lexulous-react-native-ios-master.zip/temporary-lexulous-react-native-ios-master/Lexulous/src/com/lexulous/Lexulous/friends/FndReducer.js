// @flow
import { v4 as uuidv4 } from 'uuid';

import type {
    Friends,
    FndSectionData,
    GLBLFriendsAndFoes,
    FndItemData,
    FndAction,
    ActionAddGLBLFriendsAndFoes,
    ActionGLBLFndRefreshStarted,
    ActionGLBLFndRefreshFinished,
    ActionGLBLFndClearData,
    ActionGLBLFndAdEvent,
    ActionMkFriend,
    ActionRmFriendReq,
    ActionInsertSentFndReq,
    ActionCancelSentFndReq,
    ActionCensorReq,
    ActionUncensorReq,
    ProfileInfo,
} from '../commons/RJTypes';

import {
    ADD_GLBL_FND_AND_FOES,
    GLBL_FND_REFRESH_STARTED,
    GLBL_FND_REFRESH_FINISHED,
    CLR_GLBL_FND_DATA,
    GLBL_FND_AD_EVT,
    MK_FRIEND,
    RM_FRIEND_REQ,
    INST_SENT_FND_REQ,
    CANCEL_SENT_FND_REQ,
    CENSOR_REQ,
    RM_ADDED_FRIEND_REQ,
    UNCENSOR_REQ,
} from './FndEventTypes';

import { translate } from '../commons/translations/LangTransator';

const FriendInitState: Friends = {
    isrefreshing: false,
    lastupdated: 0,
    friends: [],
};

// Use the initialState as a default value
export default function FndReducer(state: Friends = FriendInitState, taction: FndAction) {
    switch (taction.type) {
        case ADD_GLBL_FND_AND_FOES: {
            let action = ((taction: any): ActionAddGLBLFriendsAndFoes);
            let friends: GLBLFriendsAndFoes = action.payload;

            // let fnd: Array<ProfileInfo> = extractFriends(state.friends, 'fnd');
            // let fndreqsent: Array<ProfileInfo> = extractFriends(state.friends, 'reqsent');

            // fnd = [...fnd, ...friends.buddies];
            // fndreqsent = [...fndreqsent, ...friends.reqsent];

            let fnd: Array<ProfileInfo> = [...friends.buddies];
            let fndreqsent: Array<ProfileInfo> = [...friends.reqsent];
            let pending: Array<ProfileInfo> = [...friends.pending];
            let censored: Array<ProfileInfo> = [...friends.censored];

            fnd = sortFriendsByName(fnd);
            fndreqsent = sortFriendsByName(fndreqsent);
            pending = sortFriendsByName(pending);
            censored = sortFriendsByName(censored);

            let mdffnds: Array<FndSectionData> = [];

            if (pending.length > 0) {
                let ttlstr = translate('pending') + '  (' + pending.length + ')';
                let secdata: Array<FndItemData> = pending.map((val: ProfileInfo) => {
                    let keydata = '';
                    if (val.guid) {
                        keydata = val.guid;
                    } else {
                        keydata = uuidv4();
                    }
                    return {
                        type: 'pending',
                        key: keydata,
                        data: val,
                    };
                });
                mdffnds.push({
                    title: ttlstr,
                    type: 'pending',
                    data: secdata,
                });
            }

            if (fnd.length > 0) {
                let ttlstr = translate('friends') + '  (' + fnd.length + ')';
                let secdata: Array<FndItemData> = fnd.map((val: ProfileInfo) => {
                    let keydata = '';
                    if (val.guid) {
                        keydata = val.guid;
                    } else {
                        keydata = uuidv4();
                    }
                    return {
                        type: 'fnd',
                        key: keydata,
                        data: val,
                    };
                });
                mdffnds.push({
                    title: ttlstr,
                    type: 'fnd',
                    data: secdata,
                });
            }

            if (fndreqsent.length > 0) {
                let ttlstr = translate('reqst_snt') + '  (' + fndreqsent.length + ')';
                let secdata: Array<FndItemData> = fndreqsent.map((val: ProfileInfo) => {
                    let keydata = '';
                    if (val.guid) {
                        keydata = val.guid;
                    } else {
                        keydata = uuidv4();
                    }
                    return {
                        type: 'reqsent',
                        key: keydata,
                        data: val,
                    };
                });
                mdffnds.push({
                    title: ttlstr,
                    type: 'reqsent',
                    data: secdata,
                });
            }

            if (censored.length > 0) {
                let ttlstr = translate('cap_censor') + '  (' + censored.length + ')';
                let secdata: Array<FndItemData> = censored.map((val: ProfileInfo) => {
                    let keydata = '';
                    if (val.guid) {
                        keydata = val.guid;
                    } else {
                        keydata = uuidv4();
                    }
                    return {
                        type: 'censored',
                        key: keydata,
                        data: val,
                    };
                });
                mdffnds.push({
                    title: ttlstr,
                    type: 'censored',
                    data: secdata,
                });
            }

            let newstate = {
                lastupdated: Math.floor(Date.now() / 1000),
                friends: mdffnds,
                isrefreshing: state.isrefreshing,
            };
            return { ...newstate };
        }
        case GLBL_FND_REFRESH_STARTED: {
            let action = ((taction: any): ActionGLBLFndRefreshStarted);
            let mdffnds: Array<FndSectionData> = [];

            let newstate = {
                isrefreshing: true,
                friends: mdffnds,
            };
            return { ...state, ...newstate };
        }

        case GLBL_FND_REFRESH_FINISHED: {
            let action = ((taction: any): ActionGLBLFndRefreshFinished);
            let mdfgames: Array<FndSectionData> = [];

            let newstate = {
                isrefreshing: false,
                friends: mdfgames,
            };
            return { ...state, ...newstate };
        }
        case CLR_GLBL_FND_DATA: {
            let action = ((taction: any): ActionGLBLFndClearData);
            let mdfgames: Array<FndSectionData> = [];
            return { ...state, ...{ lastupdated: 0, friends: mdfgames } };
        }
        case GLBL_FND_AD_EVT: {
            let action = ((taction: any): ActionGLBLFndAdEvent);
            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: state.friends,
            };
            return newstate;
        }
        case MK_FRIEND: {
            let action = ((taction: any): ActionMkFriend);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'pending');
            if (containeridx != -1) {
                let pending: FndSectionData = fnds[containeridx];
                let subcntnridx = pending.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    pending.data.splice(subcntnridx, 1); //removed from pending
                    if (pending.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('pending') + '  (' + pending.data.length + ')';
                        pending.title = ttlstr;
                    }
                }
            }

            containeridx = fnds.findIndex((p) => p.type == 'censored');
            if (containeridx != -1) {
                let censored: FndSectionData = fnds[containeridx];
                let subcntnridx = censored.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    censored.data.splice(subcntnridx, 1); //removed from censored
                    if (censored.data.length == 0) {
                        fnds.splice(containeridx, 3);
                    } else {
                        let ttlstr = translate('cap_censor') + '  (' + censored.data.length + ')';
                        censored.title = ttlstr;
                    }
                }
            }

            containeridx = fnds.findIndex((p) => p.type == 'fnd');
            if (containeridx != -1) {
                let fnd: FndSectionData = fnds[containeridx];
                //FIND PLACE TO INSERT
                let insrtidx = sortedIndex(profile, fnd.data);
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'fnd',
                    key: keydata,
                    data: profile,
                };
                fnd.data.splice(insrtidx, 0, idata); //added to friend
                let ttlstr = translate('friends') + '  (' + fnd.data.length + ')';
                fnd.title = ttlstr;
            } else {
                let ttlstr = translate('friends') + '  (1)';
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'fnd',
                    key: keydata,
                    data: profile,
                };
                let secdata: Array<FndItemData> = [idata];
                fnds.splice(0, 0, {
                    title: ttlstr,
                    type: 'fnd',
                    data: secdata,
                });
            }

            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        case RM_FRIEND_REQ: {
            let action = ((taction: any): ActionRmFriendReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'pending');
            if (containeridx != -1) {
                let pending: FndSectionData = fnds[containeridx];
                let subcntnridx = pending.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    pending.data.splice(subcntnridx, 1); //removed from pending
                    if (pending.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('pending') + '  (' + pending.data.length + ')';
                        pending.title = ttlstr;
                    }
                }
            }

            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        case INST_SENT_FND_REQ: {
            let action = ((taction: any): ActionInsertSentFndReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;

            let containeridx = fnds.findIndex((p) => p.type == 'reqsent');
            if (containeridx != -1) {
                let fnd: FndSectionData = fnds[containeridx];
                //FIND PLACE TO INSERT
                let insrtidx = sortedIndex(profile, fnd.data);
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'reqsent',
                    key: keydata,
                    data: profile,
                };
                fnd.data.splice(insrtidx, 0, idata); //added to request sent
                let ttlstr = translate('reqst_snt') + '  (' + fnd.data.length + ')';
                fnd.title = ttlstr;
            } else {
                let ttlstr = translate('reqst_snt') + '  ( 1 )';
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'reqsent',
                    key: keydata,
                    data: profile,
                };
                let secdata: Array<FndItemData> = [idata];
                fnds.splice(1, 0, {
                    title: ttlstr,
                    type: 'reqsent',
                    data: secdata,
                });
            }

            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }

        case CANCEL_SENT_FND_REQ: {
            let action = ((taction: any): ActionCancelSentFndReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'reqsent');
            if (containeridx != -1) {
                let pending: FndSectionData = fnds[containeridx];
                let subcntnridx = pending.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    pending.data.splice(subcntnridx, 1); //removed from pending
                    if (pending.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('reqst_snt') + '  (' + pending.data.length + ')';
                        pending.title = ttlstr;
                    }
                }
            }
            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        case CENSOR_REQ: {
            let action = ((taction: any): ActionCensorReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'fnd');
            if (containeridx != -1) {
                let buddies: FndSectionData = fnds[containeridx];
                let subcntnridx = buddies.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    buddies.data.splice(subcntnridx, 1); //removed from fnd
                    if (buddies.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('friends') + '  (' + buddies.data.length + ')';
                        buddies.title = ttlstr;
                    }
                }
            }

            containeridx = fnds.findIndex((p) => p.type == 'reqsent');
            if (containeridx != -1) {
                let reqsent: FndSectionData = fnds[containeridx];
                let subcntnridx = reqsent.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    reqsent.data.splice(subcntnridx, 1); //removed from censored
                    if (reqsent.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('cap_censor') + '  (' + reqsent.data.length + ')';
                        reqsent.title = ttlstr;
                    }
                }
            }

            containeridx = fnds.findIndex((p) => p.type == 'censored');
            if (containeridx != -1) {
                let censored: FndSectionData = fnds[containeridx];
                //FIND PLACE TO INSERT
                let insrtidx = sortedIndex(profile, censored.data);
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'censored',
                    key: keydata,
                    data: profile,
                };
                censored.data.splice(insrtidx, 0, idata); //added to censored
                let ttlstr = translate('cap_censor') + '  (' + censored.data.length + ')';
                censored.title = ttlstr;
            } else {
                let ttlstr = translate('cap_censor') + '  ( 1 )';
                let keydata = '';
                if (profile.guid) {
                    keydata = profile.guid;
                } else {
                    keydata = uuidv4();
                }
                let idata = {
                    type: 'censored',
                    key: keydata,
                    data: profile,
                };
                let secdata: Array<FndItemData> = [idata];
                fnds.splice(3, 0, {
                    title: ttlstr,
                    type: 'censored',
                    data: secdata,
                });
            }

            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        case RM_ADDED_FRIEND_REQ: {
            let action = ((taction: any): ActionCancelSentFndReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'fnd');
            if (containeridx != -1) {
                let buddies: FndSectionData = fnds[containeridx];
                let subcntnridx = buddies.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    buddies.data.splice(subcntnridx, 1); //removed from pending
                    if (buddies.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('friends') + '  (' + buddies.data.length + ')';
                        buddies.title = ttlstr;
                    }
                }
            }
            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        case UNCENSOR_REQ: {
            let action = ((taction: any): ActionUncensorReq);
            let profile: ProfileInfo = action.payload;
            let fnds: Array<FndSectionData> = state.friends;
            let containeridx = fnds.findIndex((p) => p.type == 'censored');
            if (containeridx != -1) {
                let censored: FndSectionData = fnds[containeridx];
                let subcntnridx = censored.data.findIndex((uu) => uu.data.guid == profile.guid);
                if (subcntnridx != -1) {
                    censored.data.splice(subcntnridx, 1); //removed from pending
                    if (censored.data.length == 0) {
                        fnds.splice(containeridx, 1);
                    } else {
                        let ttlstr = translate('cap_censor') + '  (' + censored.data.length + ')';
                        censored.title = ttlstr;
                    }
                }
            }

            let newstate: Friends = {
                isrefreshing: state.isrefreshing,
                lastupdated: state.lastupdated,
                friends: [].concat(state.friends),
            };
            return { ...state, ...newstate };
        }
        default:
            return state;
    }
}

let sortedIndex = (info: ProfileInfo, data: Array<FndItemData>): number => {
    let low: number = 0;
    let high: number = data.length;
    while (low < high) {
        let mid: number = (low + high) >>> 1;
        if ((data[mid].data.name ?? '') < (info.name ?? '')) {
            low = mid + 1;
        } else {
            high = mid;
        }
    }
    return low;
};

// let extractFriends = (friends: Array<FndSectionData>, fndtype: 'fnd' | 'reqsent'): Array<ProfileInfo> => {
//     let qq = friends
//         .map((ff) => {
//             if (ff.type == fndtype) {
//                 let mm = ff.data.map((uu) => {
//                     return ((uu.data: any): ProfileInfo);
//                 });
//                 return mm;
//             }
//         })
//         .flat()
//         .filter((zz) => zz != null);
//     return ((qq: any): Array<ProfileInfo>);
// };

let sortFriendsByName = (fnds: Array<ProfileInfo>): Array<ProfileInfo> => {
    let mdffnds = fnds.sort((a: ProfileInfo, b: ProfileInfo) => {
        if (a.name && b.name) {
            if (a.name < b.name) {
                return -1;
            }
            if (a.name > b.name) {
                return 1;
            }
        }
        return 0;
    });
    return mdffnds;
};
