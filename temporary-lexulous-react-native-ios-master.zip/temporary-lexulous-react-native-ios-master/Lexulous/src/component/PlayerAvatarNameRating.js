import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import LiveGamePlayUtils from '../utils/LiveGamePlayUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCircle } from '@fortawesome/free-solid-svg-icons';
import React from 'react';
import ColorConfig from '../configs/ColorConfig';
import get from 'lodash/get';
//import TileTouchableOpacity from "./TileTouchableOpacity";
import { formatName } from '../utils/StringUtils';
import Config from '../configs/Config';
import ConfigurationWrapper from '../utils/ConfigurationWrapper';
import GameBoardUtils from '../utils/GameBoardUtils';
import { isSoloGame } from '../service/GamePlayService';
import { openUserStatsPage } from '../utils/UrlUtils';
import AvatarImage from './AvatarImage';
import isEqual from 'lodash/isEqual';
import TooltipWrapper from './TooltipWrapper';
import S14Text from './S14Text';
import PText from './PText';
import DimensionUtils from '../utils/DimensionUtils';
import LayoutUtils from '../utils/LayoutUtils';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';

require('format-unicorn');
const eventBus = require('js-event-bus')();

function handleOnPress(event) {
    this.onPress(this.params, event);
}

export default class PlayerAvatarNameRating extends React.Component {
    state = {
        showTooltip: false,
    };

    componentDidUpdate = () => {
        TooltipActionWrapper.rebuild();
    };

    shouldComponentUpdate = (nextProps, nextState) =>
        !isEqual(
            get(this.props, 'player.racklen'),
            get(nextProps, 'player.racklen')
        ) ||
        !isEqual(get(this.state, 'showTooltip'), get(nextState, 'showTooltip'));

    isSoloBot = (guid) => guid !== this.props.guid;

    getFlexDirection = (flexDirection) => ({ flexDirection });

    getAlignItems = (flexDirection) => ({
        alignItems: flexDirection === 'row' ? 'flex-start' : 'flex-end',
    });

    getIconStyles = (player) => {
        return {
            fontSize: 8,
            height: '100%',
            color: LiveGamePlayUtils.getDotColorAndTextForRating(
                player.rating ||
                    LiveGamePlayUtils.getRatingForPlayer(player.guid)
            ).rating_color,
            backgroundColor: 'rgba(0,0,0,0)',
        };
    };

    getPlayerColorStatusStyleObj = () => ({
        color: ColorConfig.LIVE_GAMES_TIMER_CARD_NON_ACTIVE_PLAYER_COLOR,
    });

    getPlayerNameColorStyleObj = () => ({
        color: ColorConfig.PLAYER_NAME_COLOR,
    });

    getpaddingForNativeOnly = () => ({
        paddingLeft: DimensionUtils.isNative() ? 8 : null,
    });

    onAvatarClick = (player) => {
        openUserStatsPage(player);
    };

    /* onAvatarPress = (player, event) => {
        event.stopPropagation && event.stopPropagation();
        event.nativeEvent && event.nativeEvent.stopImmediatePropagation();
        this.onAvatarClick(player);
    }; */

    onPlayerNamePress = async (params, event) => {
        //event.stopPropagation();
        //event.nativeEvent.stopImmediatePropagation();
        if (!this.props.forSideMenuTimer && this.props.joinGameModalOpen) {
            this.props.onJoinGame();
        } else {
            eventBus.emit(Config.ON_PLAYER_ITEM_SELECTED, null, {
                playerItem: this.props.player,
                watchGame: this.props.watchGame,
                observe: this.props.observe,
                onObserveGame: this.props.onObserveGame,
                playerModal: true,
                matchCheckingTab: LiveGamePlayUtils.isBlitzGame()
                    ? false
                    : get(this.props.player, 'status') === 'avl',
                statsTab: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : get(this.props.player, 'status') !== 'avl',
                isPlaying: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : get(this.props.player, 'status') === 'ply',
                noMatchChecking: LiveGamePlayUtils.isBlitzGame()
                    ? true
                    : this.props.forSideMenuTimer,
            });
        }
    };

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    renderAvatar = ({ player = this.props.player, styleType } = {}) => {
        return (
            <TooltipWrapper
                onPress={
                    isSoloGame()
                        ? undefined
                        : handleOnPress.bind({
                              params: player,
                              onPress: this.onPlayerNamePress,
                          })
                }
                tooltip={'See ' + get(player, 'name') + "'s Profile"}
            >
                <AvatarImage
                    style={[styles.playerImageSmall]}
                    show={get(player, 'avtar')}
                    uri={ConfigurationWrapper.getSpecificLexulousGeneralConfiguration(
                        'avatar_url_format'
                    ).formatUnicorn({ id: get(player, 'avtar') })}
                />
            </TooltipWrapper>
        );
    };

    renderPlayerNameTextOnly = ({ player, stylesParam }) => (
        <TooltipWrapper
            onPress={
                isSoloGame()
                    ? undefined
                    : handleOnPress.bind({
                          params: player,
                          onPress: this.onPlayerNamePress,
                      })
            }
            tooltip={
                player.racklen
                    ? 'has ' +
                      player.racklen +
                      ' tile' +
                      (Number(player.racklen) > 1 ? 's' : '')
                    : ''
            }
        >
            {DimensionUtils.isMobile() ? (
                <PText
                    numberOfLines={1}
                    ellipsizeMode={'tail'}
                    style={[
                        styles[stylesParam],
                        this.getPlayerNameColorStyleObj(),
                    ]}
                >
                    {formatName(get(player, 'name'))}
                    {GameBoardUtils.isMyself(player) &&
                    !this.props.hideyoutext ? (
                        <S14Text style={[styles.boldFont]}> (You)</S14Text>
                    ) : null}
                </PText>
            ) : (
                <S14Text
                    numberOfLines={1}
                    ellipsizeMode={'tail'}
                    style={[
                        styles[stylesParam],
                        this.getPlayerNameColorStyleObj(),
                    ]}
                >
                    {formatName(get(player, 'name'))}
                    {GameBoardUtils.isMyself(player) &&
                    !this.props.hideyoutext ? (
                        <S14Text style={[styles.boldFont]}> (You)</S14Text>
                    ) : null}
                </S14Text>
            )}
        </TooltipWrapper>
    );

    renderPlayerName = ({ player = this.props.player, stylesParam } = {}) =>
        isSoloGame() ? (
            <TouchableOpacity>
                {this.renderPlayerNameTextOnly({
                    player,
                    stylesParam: stylesParam,
                })}
            </TouchableOpacity>
        ) : (
            <TouchableOpacity
                style={
                    this.props.forSideMenuTimer
                        ? [styles[stylesParam]]
                        : undefined
                }
                onPress={handleOnPress.bind({
                    params: undefined,
                    onPress: this.onPlayerNamePress,
                })}
            >
                {this.renderPlayerNameTextOnly({
                    player,
                    stylesParam: stylesParam,
                })}
            </TouchableOpacity>
        );

    renderPlayerRating = (player, styles) =>
        DimensionUtils.isMobile() ? (
            <PText style={[styles, this.getPlayerColorStatusStyleObj()]}>
                {isSoloGame()
                    ? this.isSoloBot(player.guid)
                        ? 'Level ' + this.props.solitaire.level
                        : this.props.solitaire.soloRating
                    : get(player, 'rating') ||
                      LiveGamePlayUtils.getRatingForPlayer(player.guid) ||
                      LiveGamePlayUtils.getRatingForPlayerFromLiveGameListData(
                          player.guid
                      )}
            </PText>
        ) : (
            <S14Text style={[styles, this.getPlayerColorStatusStyleObj()]}>
                {isSoloGame()
                    ? this.isSoloBot(player.guid)
                        ? 'Level ' + this.props.solitaire.level
                        : this.props.solitaire.soloRating
                    : get(player, 'rating') ||
                      LiveGamePlayUtils.getRatingForPlayer(player.guid) ||
                      LiveGamePlayUtils.getRatingForPlayerFromLiveGameListData(
                          player.guid
                      )}
            </S14Text>
        );

    renderPlayerTypeIndicator = (player) =>
        player.usrtype === 'r' ||
        (isSoloGame() && this.isSoloBot(player.guid)) ? (
            <TooltipWrapper tooltip={'Lex Robot'}>
                <S14Text
                    style={[
                        styles.robotIndicatorContainer,
                        styles.robotIndicatorTextColor,
                    ]}
                >
                    {'R'}
                </S14Text>
            </TooltipWrapper>
        ) : null;

    render = () => (
        <View
            style={[
                this.getFlexDirection(this.props.flexDirection),
                styles.itemCenter,
                styles.justifyFlexStart,
                styles.overflowHidden,
                this.getpaddingForNativeOnly(),
            ]}
            onMouseEnter={this.showTooltip}
            onMouseOut={this.hideTooltip}
        >
            {this.renderAvatar({ styleType: 'playerImageLarge' })}
            <View
                style={[
                    styles.columnDirection,
                    this.props.watchGameListItem
                        ? styles.maxWidth80
                        : this.getAlignItems(this.props.flexDirection),
                ]}
            >
                {this.renderPlayerName({
                    stylesParam: 'playerNameTextHostGame',
                })}

                <View
                    style={[
                        styles.rowDirection,
                        styles.styleBackgroundColorAndOverflowForNonSoloGame,
                    ]}
                >
                    {(isSoloGame() && this.isSoloBot(this.props.player.guid)) ||
                    LiveGamePlayUtils.isBlitzGame() ? null : (
                        <TooltipWrapper
                            style={styles.ratingIconContainerStyle}
                            tooltip={
                                LiveGamePlayUtils.getDotColorAndTextForRating(
                                    get(this.props.player, 'rating') ||
                                        LiveGamePlayUtils.getRatingForPlayer(
                                            get(this.props.player, 'guid')
                                        )
                                ).rating_level
                            }
                        >
                            <FontAwesomeIcon
                                icon={faCircle}
                                size={8}
                                style={{
                                    ...this.getIconStyles(this.props.player),
                                }}
                            />
                        </TooltipWrapper>
                    )}
                    {!LiveGamePlayUtils.isBlitzGame() &&
                        this.renderPlayerRating(this.props.player, [
                            this.props.userRatingPlainStyle
                                ? styles.playerRatingTextHostGamePain
                                : styles.playerRatingTextHostGame,
                            styles.styleBlackBackground,
                        ])}
                    {!LiveGamePlayUtils.isBlitzGame() &&
                        this.renderPlayerTypeIndicator(this.props.player)}
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    styleBlackBackground: {
        backgroundColor: 'rgba(0,0,0,0)',
    },
    styleBackgroundColorAndOverflowForNonSoloGame: {
        backgroundColor: 'rgba(0,0,0,0)',
        overflow: 'hidden',
    },
    playerImageLarge: {
        height: 19,
        width: 19,
        marginRight: 8,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    itemCenter: {
        alignItems: 'center',
    },
    justifyFlexStart: {
        justifyContent: 'flex-start',
    },
    columnDirection: {
        flexDirection: 'column',
        padding: 0,
        margin: 0,
    },
    rowDirection: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    ratingIconContainerStyle: {
        height: 15,
        width: 8,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(0,0,0,0)',
    },
    //Main Renders Styles
    modalContent: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
    },
    mainContainer: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.MAIN_CONTAINER_BACKGROUND_COLOR,
    },
    bodyContainer: {
        flexDirection: 'column',
    },
    playButton: {
        backgroundColor: ColorConfig.BUTTON_BACKGROUND_COLOR,
        margin: 2,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
    },
    playerImageSmall: {
        height: 16,
        width: 16,
        marginRight: 5,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    playerNameText: {
        flex: 3,
        marginLeft: 10,
        justifyContent: 'center',
    },
    playerNameTextHostGame: {
        width: '100%',
    },
    playerRatingText: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        textAlign: 'left',
    },
    minHeightTwenty: {
        minHeight: 20,
    },
    playerRatingTextHostGame: { marginLeft: 4, fontWeight: 'bold' },
    playerRatingTextHostGamePain: { marginLeft: 4 },
    playerStatusTextHeader: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    playerStatusText: {
        textAlign: 'left',
    },
    rowStyle: { flexDirection: 'row', marginBottom: 10 },
    spaceBetweenRowStyle: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },
    pickerContainerStyle: { flex: 1 },
    pickersDividerStyle: { width: 10 },
    newGameTabRootStyle: {
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        padding: 5,
    },

    transparent: {
        backgroundColor: ColorConfig.TRANSPARENT,
    },
    transparentOpacity: {
        opacity: 0,
    },
    buttonText: {
        color: ColorConfig.INVITE_HOST_BUTTON_TEXT_COLOR,
        fontSize: 18,
    },
    playerListItem: {
        backgroundColor: ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_ODD,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.PLAYER_LIST_ITEM_BORDER_COLOR,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingTop: 1,
        paddingBottom: 1,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    playerListHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    playerListItemEven: {
        backgroundColor: ColorConfig.PLAYER_LIST_ITEM_BACKGROUND_COLOR_EVEN,
    },
    overflowHidden: {
        overflow: 'hidden',
    },
    maxHeightHundred: {
        maxHeight: '100%',
    },
    boldFont: {
        fontWeight: 'bold',
    },
    headerSectionMinWidth: { minWidth: 14, overflow: 'hidden' },
    leftSideContainer: {
        flexDirection: 'column',
        backgroundColor: ColorConfig.PLAYER_LIST_BACKGROUND_COLOR,
        borderRadius: 5,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        overflow: 'hidden',
    },
    containerDivider: {
        width: Config.RIGHT_LEFT_MARGIN,
        height: 0,
    },
    headerContainer: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        padding: 10,
        alignItems: 'center',
        justifyContent: 'center',
        borderBottomWidth: StyleSheet.hairlineWidth,
        width: '100%',
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    headerContainerNoPadding: {
        backgroundColor: ColorConfig.GAME_OPTIONS_HEADERS_BACKGROUND_COLOR,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 10,
        borderBottomWidth: StyleSheet.hairlineWidth,
        paddingLeft: Config.RIGHT_LEFT_MARGIN,
        paddingRight: Config.RIGHT_LEFT_MARGIN,
    },
    headerText: {
        fontWeight: 'bold',
        color: ColorConfig.GAME_OPTIONS_TEXT_COLOR,
    },
    paddingFive: {
        padding: 5,
    },
    paddingSixteen: {
        padding: Config.RIGHT_LEFT_MARGIN,
        height: 3.5 * Config.RIGHT_LEFT_MARGIN + 2 * Config.RIGHT_LEFT_MARGIN,
        borderWidth: 0,
        borderColor: 'rgba(0,0,0,0)',
    },
    buttonContainer: {
        maxWidth: '100%',
        maxHeight: '100%',
        minWidth: '100%',
        minHeight: '100%',
        /*backgroundColor: ColorConfig.INVITE_HOST_BUTTON_BACKGROUND_COLOR,
        borderColor: ColorConfig.INVITE_HOST_BUTTON_BORDER_COLOR,
        borderWidth: StyleSheet.hairlineWidth,
        borderRadius: 5*/
    },
    rightSideContainer: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: ColorConfig.GAME_OPTIONS_HEADERS_BORDER_COLOR,
        borderTopRightRadius: 5,
        borderTopLeftRadius: 5,
        borderBottomRightRadius: 5,
        borderBottomLeftRadius: 5,
        overflow: 'hidden',
    },
    gameListContainer: {
        overflow: 'hidden',
    },
    alignItemsCenter: {
        alignItems: 'center',
    },
    justifyCenter: {
        justifyContent: 'center',
    },
    robotContainer: {
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row',
        padding: 5,
    },
    inputLabelDivider: {
        height: 0,
        width: 5,
    },
    hostedGameListBackgroundColor: {
        backgroundColor: ColorConfig.HOSTED_GAMES_LIST_BACKGROUND_COLOR,
    },
    observeListContainer: {
        overflow: 'hidden',
    },
    observeGameListBackgroundColor: {
        backgroundColor: ColorConfig.OBSERVABLE_GAMES_LIST_BACKGROUND_COLOR,
    },
    observeGame: {
        flexDirection: 'row',
        padding: 5,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    observeGameViewPosition: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    },
    ratedIndicatorContainer: {
        flexDirection: 'column',
        width: 10,
        height: 10,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:
            ColorConfig.ACCEPT_HOSTED_LIST_ITEM__TIMED_INDICATOR_COLOR,
    },
    robotIndicatorTextColor: {
        color: '#FFF',
        fontSize: 8,
    },
    dictionaryContainer: {
        flexDirection: 'column',
        width: 10,
        height: 10,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:
            ColorConfig.ACCEPT_HOSTED_LIST_ITEM__RATED_INDICATOR_COLOR,
    },
    robotIndicatorContainer: {
        flexDirection: 'column',
        width: 10,
        height: 10,
        textAlign: 'center',
        backgroundColor: 'red',
        marginLeft: 4,
    },
    timeControlTextColor: {
        color: ColorConfig.TIME_CONTROL_TEXT_COLOR,
        fontSize: 10,
    },
    timerControlContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 4,
    },
    hairlineBorderWidth: {
        borderWidth: StyleSheet.hairlineWidth,
    },
    heightForty: {
        height: 40,
    },
    flexFour: {
        width: '50%',
        flexDirection: 'row',
        alignItems: 'center',
    },
    statusTextContainer: {
        flexDirection: 'row',
        flex: 2,
        justifyContent: 'center',
    },
    onlineListItemPlayerNameTextStyle: {
        width: '100%',
    },
    maxWidth80: {
        maxWidth: '80%',
    },
});
