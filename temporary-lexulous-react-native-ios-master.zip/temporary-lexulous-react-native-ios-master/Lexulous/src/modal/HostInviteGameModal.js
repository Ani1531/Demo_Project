import {
    StyleSheet,
    Text,
    Pressable,
    TouchableOpacity,
    View,
} from 'react-native';
import ColorConfig from '../configs/ColorConfig';
import React from 'react';
//import TileTouchableOpacity from "../component/TileTouchableOpacity";
import { to } from 'await-to-js';
import {
    cancelGamePlayRequest,
    deleteHostedGame,
    hostGame,
    sendLiveGameRequest,
} from '../service/GamePlayService';
import SettingsUtil from '../utils/SettingsUtil';
import get from 'lodash/get';
import Config from '../configs/Config';
import LayoutUtils from '../utils/LayoutUtils';
import DimensionUtils from '../utils/DimensionUtils';
import { createGeneralRequestFailureDialog } from '../utils/MessageUtils';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faTimes } from '@fortawesome/pro-light-svg-icons';
import Timer from 'react-compound-timer';
import { formatToTwoDigits } from '../utils/Utils';
import isBoolean from 'lodash/isBoolean';
import { GAME_REDUCER_UPDATE_GAMETYPE } from '../configs/ActionIdentifiers';
import TooltipWrapper from '../component/TooltipWrapper';
import isEqual from 'lodash/isEqual';
import { connect } from 'react-redux';
import PText from '../component/PText';
import S14Text from '../component/S14Text';
import S22Text from '../component/S22Text';
import SelectOption from '../component/SelectOption';
import MultiSlider from '../component/MultiSlider';
import FontAwesomeSpin from '../component/FontAwesomeSpin';
import TooltipActionWrapper from '../utils/TooltipActionWrapper';
import LayoutWrapper from '../utils/LayoutWrapper';

// const theme = createMuiTheme({
//     // here are default values in ms
//     transitions: {
//         duration: {
//             shortest: 50,
//             shorter: 50,
//             short: 50,
//             standard: 50,
//             complex: 50,
//             enteringScreen: 50,
//             leavingScreen: 50,
//         }
//     }
// });

const eventBus = require('js-event-bus')();

class HostInviteGameModal extends React.Component {
    state = {
        key: Math.random(),
        closeBGColor: ColorConfig.TRANSPARENT,
        closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        showOverlay: false,
        failureDetail: null,
        showTooltip: false,
        hoverPlayerEffect: false,
        hoverDicEffect: false,
        hoverGameTypeEffect: false,
        hoverRateEffect: false,
        hoverTimeEffect: false,
        hoverIncrementEffect: false,
    };

    componentDidMount = () => {
        eventBus.on(
            Config.MATCH_REQUEST_REJECTED_EVENT,
            this.onMatchRequestRejected
        );
        eventBus.on(
            Config.GET_SETTINGS_REQUEST_SUCCESSFUL,
            this.onDefaultSettingsAvailable
        );
        eventBus.on(Config.HOST_GAME_REQUEST_FAILED, this.onHostGameFail);
        eventBus.on(Config.SHOW_HOST_INVITE_DIALOG, this.show);
        this.onDefaultSettingsAvailable();
    };

    componentWillUnmount = () => {
        eventBus.detach(
            Config.MATCH_REQUEST_REJECTED_EVENT,
            this.onMatchRequestRejected
        );
        eventBus.detach(
            Config.GET_SETTINGS_REQUEST_SUCCESSFUL,
            this.onDefaultSettingsAvailable
        );
        eventBus.detach(Config.HOST_GAME_REQUEST_FAILED, this.onHostGameFail);
        eventBus.detach(Config.SHOW_HOST_INVITE_DIALOG, this.show);
    };

    onPlayerHoverInOut = () => {
        this.setState({ hoverPlayerEffect: !this.state.hoverPlayerEffect });
    };
    onDicHoverInOut = () => {
        this.setState({ hoverDicEffect: !this.state.hoverDicEffect });
    };
    onGameTypeInOut = () => {
        this.setState({ hoverGameTypeEffect: !this.state.hoverGameTypeEffect });
    };
    onRateInOut = () => {
        this.setState({ hoverRateEffect: !this.state.hoverRateEffect });
    };
    onTimeInOut = () => {
        this.setState({ hoverTimeEffect: !this.state.hoverTimeEffect });
    };
    onIncrementInOut = () => {
        this.setState({
            hoverIncrementEffect: !this.state.hoverIncrementEffect,
        });
    };

    rebuildTooltip = () => {
        setTimeout(() => {
            TooltipActionWrapper.rebuild();
        }, 100);
    };

    componentDidUpdate() {
        TooltipActionWrapper.rebuild();
    }

    shouldComponentUpdate = (nextState) =>
        !isEqual(get(this.state, 'showTooltip'), get(nextState, 'showTooltip'));

    onDefaultSettingsAvailable = () => {
        let newStateObj = {
            players: SettingsUtil.get('us_gamestart.gs_numplayers'),
            gametype: SettingsUtil.get('us_gamestart.gs_rated'),
            time: SettingsUtil.get('us_gamestart.gs_lvduration'),
            increment: SettingsUtil.get('us_gamestart.gs_lvincrmnt'),
            dictionary: SettingsUtil.get('us_gamestart.gs_prefdic'),
            challengeregular: (
                SettingsUtil.get('us_gamestart.gs_gametype') || ''
            ).endsWith('C')
                ? 'LC'
                : 'LR',
            wordcheck: 'regular',
            minRating: SettingsUtil.getMinRatingRange(),
            maxRating: SettingsUtil.getMaxRatingRange(),
        };
        this.setState(newStateObj);
        this.rebuildTooltip();
    };

    checkUnRatedOrMultiPlayerGame = (state = this.state) =>
        !state.players ||
        state.players > 2 ||
        !state.gametype ||
        state.gametype === 'n';

    onPlayersSelect = (value) => this.setState({ players: value });
    onGameTypesSelect = (value) => this.setState({ gametype: value });
    onChallengeRegularSelect = (value) =>
        this.setState({ challengeregular: value });
    onTimeSelect = (value) => this.setState({ time: value });
    onIncrementsSelect = (value) => this.setState({ increment: value });
    onDictionarySelect = (value) => this.setState({ dictionary: value });
    //onWordCheckSelect = (value) => this.setState({ wordcheck: value });
    onChangeRatingRange = (minRating, maxRating) => {
        this.setState({ minRating, maxRating });
    };

    show = (opts) => {
        if (!this.props.isForHosting) {
            this.setState({
                isOpen: true,
                showOverlay: false,
                failureDetail: null,
                ...(opts || {}),
            });
            this.rebuildTooltip();
        }
    };

    hide = () => {
        this.setState({
            isOpen: false,
            showOverlay: false,
            failureDetail: null,
        });
    };

    onCloseButtonClick = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
        this.hide();
    };

    onCloseButtonMouseEnter = () => {
        this.setState({
            closeBGColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_BG_COLOR,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_HOVER_TEXT_COLOR,
        });
    };

    onCloseButtonMouseLeave = () => {
        this.setState({
            closeBGColor: ColorConfig.TRANSPARENT,
            closeColor: ColorConfig.DIALOG_MODAL_CLOSE_BUTTON_TEXT_COLOR,
        });
    };

    render = () =>
        this.props.renderBodyOnly
            ? this.renderMainBody()
            : this.renderModalAndMain();

    getModalContentStyle = () => ({
        ...this.props.overlayStyle,
        height: DimensionUtils.isMobile()
            ? '100%'
            : get(this.props, 'layout.layoutGamePlayAreaHeight'),
    });

    getModalContainerDimension = () =>
        this.isForHosting()
            ? null
            : {
                  width: DimensionUtils.isMobile() ? '90%' : '50%',
                  //maxHeight: '90%',
                  position: 'absolute',
                  top: LayoutWrapper.getDialogTopValue(),
                  left: LayoutWrapper.getDialogLeftValue(),
                  right: 'auto',
                  bottom: 'auto',
                  transform: LayoutWrapper.getDialogTransformValue(),
              };

    getCloseButtonStyle = () => ({
        color: this.state.closeColor,
        fontSize: DimensionUtils.isMobile() ? 20 : 24,
    });

    getHoverInStyle = () => ({
        backgroundColor: this.isForHosting() ? '#f4f3ef' : null,
        border: 0,
        borderBottomStyle: 'solid',
        borderWidth: '2.5px',
        fontSize: '100%',
    });
    getHoverOutStyle = () => ({
        backgroundColor: this.isForHosting() ? '#f4f3ef' : null,
        border: 0,
        borderBottomStyle: 'ridge',
        borderWidth: '3px',
        fontSize: '100%',
    });

    renderModalAndMain = () =>
        !!this.state.isOpen ? (
            <View style={this.getModalContentStyle()}>
                <TouchableOpacity
                    activeOpacity={1}
                    style={[StyleSheet.absoluteFill]}
                    onPress={this.hide}
                />
                {this.renderMainBody()}
            </View>
        ) : null;

    getCloseButtonBackgroundColor = () => ({
        backgroundColor: this.state.closeBGColor,
    });

    isForHosting = () =>
        isBoolean(this.state.isForHosting)
            ? this.state.isForHosting
            : this.props.isForHosting;

    renderMainBody = () => (
        <View
            key={'MainBody'}
            style={[
                styles.widthHundred,
                this.isForHosting()
                    ? styles.listBackgroundColor
                    : LayoutUtils.getDialogMainContainerStyle(),
                this.getModalContainerDimension(),
            ]}
        >
            {this.isForHosting() ? null : (
                <View
                    key={'InvitationContainer'}
                    style={[
                        LayoutUtils.getDialogTitleContainerStyle(),
                        {
                            width: '100%',
                            alignItems: 'space-between',
                            justifyContent: 'center',
                            paddingBottom: DimensionUtils.isMobile()
                                ? 16
                                : undefined,
                        },
                    ]}
                >
                    <S22Text style={[LayoutUtils.getDialogTitleStyle()]}>
                        {'Send an Invitation'}
                    </S22Text>
                    <View
                        key={'InvitationHeader'}
                        style={{
                            alignItems: 'flex-end',
                            justifyContent: 'center',
                            flex: 1,
                        }}
                    >
                        <TouchableOpacity
                            key={'InvitationHeaderCloseBtn'}
                            style={[
                                styles.closeButtonContainer,
                                this.getCloseButtonBackgroundColor(),
                                LayoutUtils.getDialogCloseButtonBGStyle(),
                            ]}
                            onPress={this.onCloseButtonClick}
                            onMouseEnter={this.onCloseButtonMouseEnter}
                            onMouseLeave={this.onCloseButtonMouseLeave}
                        >
                            <FontAwesomeIcon
                                icon={faTimes}
                                size={DimensionUtils.isMobile() ? 20 : 24}
                                style={this.getCloseButtonStyle()}
                            />
                        </TouchableOpacity>
                    </View>
                </View>
            )}
            {this.renderNewGameTab()}
            {this.state.showOverlay ? (
                <View
                    key={'showOverlay'}
                    style={[StyleSheet.absoluteFill, styles.overlayContainer]}
                >
                    {this.state.failureDetail !== null ? (
                        [
                            <View
                                key={'failureDetail'}
                                style={styles.failureDetailLayout}
                            >
                                <S14Text
                                    style={LayoutUtils.getCursorDefaultStyle()}
                                >
                                    {this.state.failureDetail.message}
                                </S14Text>
                                {this.state.failureDetail.timer ? (
                                    <Timer
                                        initialTime={
                                            this.state.failureDetail.timer
                                                .timeout
                                        }
                                        startImmediately={true}
                                        direction={'backward'}
                                        checkpoints={[
                                            {
                                                time: 0,
                                                callback: this.onTimerTimeOut,
                                            },
                                        ]}
                                    >
                                        <S14Text
                                            style={[
                                                styles.rowDirection,
                                                styles.marginFive,
                                            ]}
                                        >
                                            <Timer.Minutes
                                                formatValue={formatToTwoDigits}
                                            />
                                            <S14Text>{':'}</S14Text>
                                            <Timer.Seconds
                                                formatValue={formatToTwoDigits}
                                            />
                                        </S14Text>
                                    </Timer>
                                ) : null}
                            </View>,
                            this.state.failureDetail.btnText ? (
                                <View
                                    key={'failureDetail_btnText'}
                                    style={[
                                        styles.rowDirection,
                                        styles.btnContainer,
                                    ]}
                                >
                                    <TouchableOpacity
                                        activeOpacity={1}
                                        style={styles.btn}
                                        onPress={this.onFailureButtonPress}
                                    >
                                        <S14Text style={[styles.btnTextStyle]}>
                                            {this.state.failureDetail.btnText}
                                        </S14Text>
                                    </TouchableOpacity>
                                </View>
                            ) : null,
                        ]
                    ) : (
                        <FontAwesomeSpin />
                    )}
                </View>
            ) : null}
        </View>
    );

    renderTitle = () => (
        <S14Text style={[styles.title, LayoutUtils.getCursorDefaultStyle()]}>
            {this.isForHosting() ? 'Host A Game' : 'Send an Invitation'}
        </S14Text>
    );

    showTooltip = () => this.setState({ showTooltip: true });
    hideTooltip = () => this.setState({ showTooltip: false });

    renderNewGameTab = () => (
        <View
            key={'NewGameTab'}
            style={[
                this.isForHosting()
                    ? styles.newGameTabRootStyleForHosting
                    : styles.newGameTabRootStyle,
            ]}
        >
            <View
                key={'NewGameTabInnerView_1'}
                style={[styles.rowStyle, styles.widthHundred]}
            >
                {/*<TileTouchableOpacity*/}
                {/*    hidden={true}*/}
                {/*    style={[styles.pickerContainerStyle]}*/}
                {/*    ref={this.enterGuidLineRef}*/}
                {/*>*/}
                {/*    <TextField*/}
                {/*        label="Enter GUID of the user"*/}
                {/*        value={this.state.guid_text}*/}
                {/*        onChangeText={this.onGuidChangeText}*/}
                {/*    />*/}
                {/*</TileTouchableOpacity>*/}
                {!this.isForHosting() ? null : (
                    <View
                        key={'NewGameTabInnerView_2'}
                        style={styles.pickerContainerStyle}
                    >
                        <View
                            key={'NewGameTabInnerView_3'}
                            onMouseEnter={this.onPlayerHoverInOut}
                            onMouseLeave={this.onPlayerHoverInOut}
                        >
                            <PText style={styles.numberStepperLabel}>
                                Players
                            </PText>
                            <SelectOption
                                style={
                                    this.state.hoverPlayerEffect
                                        ? this.getHoverInStyle()
                                        : this.getHoverOutStyle()
                                }
                                type={Config.SELECT_OPTION_TYPES.players}
                                selectedValue={this.state.players}
                                onSelectChange={this.onPlayersSelect}
                            />
                        </View>
                    </View>
                )}

                {[
                    !this.isForHosting() ? null : (
                        <View
                            key={'NewGameTabInnerView_4'}
                            style={styles.pickersDividerStyle}
                        />
                    ),
                    <View
                        key={'NewGameTabInnerView_5'}
                        style={styles.pickerContainerStyle}
                    >
                        <View
                            key={'NewGameTabInnerView_6'}
                            onMouseEnter={this.onDicHoverInOut}
                            onMouseLeave={this.onDicHoverInOut}
                        >
                            <PText style={styles.numberStepperLabel}>
                                Dictionary
                            </PText>
                            <SelectOption
                                style={
                                    this.state.hoverDicEffect
                                        ? this.getHoverInStyle()
                                        : this.getHoverOutStyle()
                                }
                                type={Config.SELECT_OPTION_TYPES.dictionary}
                                selectedValue={this.state.dictionary}
                                onSelectChange={this.onDictionarySelect}
                            />
                        </View>
                    </View>,
                    !this.isForHosting() ? (
                        <View
                            key={'NewGameTabDividerView_1'}
                            style={styles.pickersDividerStyle}
                        />
                    ) : null,
                ]}
                {this.isForHosting() ? (
                    <View
                        key={'NewGameTabDividerView_2'}
                        style={styles.pickersDividerStyle}
                    />
                ) : null}
                <View
                    key={'NewGameTabInnerView_7'}
                    style={styles.pickerContainerStyle}
                >
                    <View
                        key={'NewGameTabInnerView_8'}
                        onMouseEnter={this.onGameTypeInOut}
                        onMouseLeave={this.onGameTypeInOut}
                    >
                        <PText style={styles.numberStepperLabel}>
                            Game Type
                        </PText>
                        <SelectOption
                            style={
                                this.state.hoverGameTypeEffect
                                    ? this.getHoverInStyle()
                                    : this.getHoverOutStyle()
                            }
                            type={Config.SELECT_OPTION_TYPES.gameType}
                            selectedValue={this.state.challengeregular}
                            onSelectChange={this.onChallengeRegularSelect}
                        />
                    </View>
                </View>
            </View>
            <View
                key={'NewGameTabInnerView_9'}
                style={[styles.rowStyle, styles.widthHundred]}
            >
                {this.state.players > 2
                    ? null
                    : [
                          <View
                              key={'NewGameTabInnerView_10'}
                              style={styles.pickerContainerStyle}
                          >
                              <View
                                  key={'NewGameTabInnerView_11'}
                                  onMouseEnter={this.onRateInOut}
                                  onMouseLeave={this.onRateInOut}
                              >
                                  <PText style={styles.numberStepperLabel}>
                                      Rated
                                  </PText>
                                  <SelectOption
                                      style={
                                          this.state.hoverRateEffect
                                              ? this.getHoverInStyle()
                                              : this.getHoverOutStyle()
                                      }
                                      type={Config.SELECT_OPTION_TYPES.rated}
                                      selectedValue={this.state.gametype}
                                      onSelectChange={this.onGameTypesSelect}
                                  />
                              </View>
                          </View>,
                          <View
                              key={'NewGameTabDividerView_3'}
                              style={styles.pickersDividerStyle}
                          />,
                      ]}
                <View
                    key={'NewGameTabInnerView_12'}
                    style={styles.pickerContainerStyle}
                >
                    <View
                        key={'NewGameTabInnerView_13'}
                        onMouseEnter={this.onTimeInOut}
                        onMouseLeave={this.onTimeInOut}
                    >
                        <TooltipWrapper
                            key={'NewGameTabInnerView_14'}
                            tooltip={'Total time each player gets'}
                            onMouseEnter={this.showTooltip}
                            onMouseOut={this.hideTooltip}
                        >
                            <PText style={styles.numberStepperLabel}>
                                Time
                            </PText>
                        </TooltipWrapper>
                        <SelectOption
                            key={'NewGameTabInnerView_15'}
                            style={
                                this.state.hoverTimeEffect
                                    ? this.getHoverInStyle()
                                    : this.getHoverOutStyle()
                            }
                            type={Config.SELECT_OPTION_TYPES.time}
                            selectedValue={this.state.time}
                            onSelectChange={this.onTimeSelect}
                        />
                    </View>
                </View>
                <View
                    key={'NewGameTabDividerView_4'}
                    style={styles.pickersDividerStyle}
                />
                <View
                    key={'NewGameTabInnerView_16'}
                    style={styles.pickerContainerStyle}
                >
                    <View
                        key={'NewGameTabInnerView_17'}
                        onMouseEnter={this.onIncrementInOut}
                        onMouseLeave={this.onIncrementInOut}
                    >
                        <TooltipWrapper
                            key={'NewGameTabInnerView_18'}
                            tooltip={
                                'Seconds added to total time after<br>each move'
                            }
                            onMouseEnter={this.showTooltip}
                            onMouseOut={this.hideTooltip}
                            multiline={true}
                        >
                            <PText style={styles.numberStepperLabel}>
                                Increments
                            </PText>
                        </TooltipWrapper>
                        <SelectOption
                            key={'NewGameTabInnerView_19'}
                            style={
                                this.state.hoverIncrementEffect
                                    ? this.getHoverInStyle()
                                    : this.getHoverOutStyle()
                            }
                            type={Config.SELECT_OPTION_TYPES.increments}
                            selectedValue={this.state.increment}
                            onSelectChange={this.onIncrementsSelect}
                        />
                    </View>
                </View>
            </View>
            {/*<View style={[styles.rowStyle, styles.widthHundred]}>*/}
            {/*    <View hidden={true} style={styles.pickersDividerStyle}/>*/}
            {/*    <View hidden={true} style={styles.pickerContainerStyle}>*/}
            {/*        <FormControl>*/}
            {/*            <InputLabel htmlFor="wordcheck-simple">Word Check</InputLabel>*/}
            {/*            <Select*/}
            {/*                native*/}
            {/*                value={this.state.wordcheck}*/}
            {/*                onChange={this.onWordCheckSelect}*/}
            {/*                inputProps={{*/}
            {/*                    name: 'wordcheck',*/}
            {/*                    id: 'wordcheck-simple',*/}
            {/*                }}*/}
            {/*            >*/}
            {/*                <MenuItem value={"regular"}>Regular</MenuItem>*/}
            {/*                <MenuItem value={"single"}>Single</MenuItem>*/}
            {/*                <MenuItem value={"double"}>Double</MenuItem>*/}
            {/*                <MenuItem value={"five_points"}>5 points</MenuItem>*/}
            {/*                <MenuItem value={"strict"}>Strict</MenuItem>*/}
            {/*            </Select>*/}
            {/*        </FormControl>*/}
            {/*    </View>*/}
            {/*</View>*/}
            {!this.checkUnRatedOrMultiPlayerGame() && this.isForHosting() && (
                <View
                    key={'NewGameTabInnerView_20'}
                    style={[styles.lastRowStyle, styles.widthHundred]}
                    ref={this.minMaxRatingRowRef}
                >
                    <View
                        key={'NewGameTabInnerView_21'}
                        style={styles.pickerContainerStyle}
                    >
                        <PText style={styles.numberStepperLabel}>
                            Rating Range [{this.state.minRating} -{' '}
                            {this.state.maxRating}]
                        </PText>
                        <MultiSlider
                            key={'NewGameTabInnerView_22'}
                            minValue={this.state.minRating}
                            maxValue={this.state.maxRating}
                            onChangeValue={this.onChangeRatingRange}
                        />
                    </View>
                </View>
            )}
            <View
                key={'NewGameTabInnerView_23'}
                style={[
                    this.isForHosting()
                        ? styles.hostingBtnContainer
                        : styles.bodyBtnContainer,
                    DimensionUtils.isMobile() && !this.isForHosting()
                        ? styles.buttonContainerMobileOverride
                        : undefined,
                    this.isForHosting()
                        ? { marginTop: 2 * Config.RIGHT_LEFT_MARGIN }
                        : undefined,
                ]}
            >
                {this.isForHosting() ? (
                    <Pressable
                        key={'NewGameTabInnerView_24'}
                        style={[styles.setButton, LayoutUtils.getBottonStyle()]}
                        onPress={this.onSendRequest}
                    >
                        <S14Text style={LayoutUtils.getBottonTextStyle()}>
                            {' '}
                            {'SET TABLE'}
                        </S14Text>
                    </Pressable>
                ) : (
                    <Pressable
                        key={'NewGameTabInnerView_24'}
                        style={[
                            LayoutUtils.getBottonStyle(),
                            LayoutUtils.getDialogActionButtonStyle(),
                        ]}
                        onPress={this.onSendRequest}
                    >
                        <S14Text style={LayoutUtils.getBottonTextStyle()}>
                            {'OK'}
                        </S14Text>
                    </Pressable>
                )}
                {this.isForHosting() ? (
                    <TouchableOpacity
                        key={'NewGameTabInnerView_25'}
                        activeOpacity={1}
                        style={[styles.hostingCloseIcon]}
                        onPress={this.props.onCancel}
                    >
                        <FontAwesomeIcon
                            icon={faTimes}
                            size={16}
                            style={this.getHostingCLoseIconText()}
                        />
                    </TouchableOpacity>
                ) : null}
            </View>
        </View>
    );

    getHostingCLoseIconText = () => ({
        color: '#fff',
        fontSize: 16,
    });

    onSendRequest = async () => {
        this.setState({ showOverlay: true });
        let res = {};
        let host_game_prefs = {
            players: this.state.players,
            gametype: this.state.gametype,
            challengeregular: this.state.challengeregular,
            time: this.state.time,
            increment: this.state.increment,
            dictionary: this.state.dictionary,
            wordcheck: this.state.wordcheck,
            ...(this.checkUnRatedOrMultiPlayerGame()
                ? {
                      fromrating: get(
                          Config.LIVE_DEFAULT_SETTINGS,
                          'us_gamestart.gs_ratingrange'
                      ).split('-')[0],
                      torating: get(
                          Config.LIVE_DEFAULT_SETTINGS,
                          'us_gamestart.gs_ratingrange'
                      ).split('-')[1],
                  }
                : {
                      fromrating:
                          this.state.minRating ||
                          SettingsUtil.getMinRatingRange(),
                      torating:
                          this.state.maxRating ||
                          SettingsUtil.getMaxRatingRange(),
                      ratingrange: this.getRatingRange(),
                  }),
        };
        eventBus.emit(GAME_REDUCER_UPDATE_GAMETYPE, null, this.state.gametype);
        await to(SettingsUtil.sendSetting(host_game_prefs));
        if (this.isSendingInvite()) {
            return await to(
                this.onSendGameRequest({
                    ...host_game_prefs,
                    guid: this.state.guid,
                })
            );
        } else {
            res = await to(hostGame(host_game_prefs));
            if (res[1]) {
                if (this.props.onDoneInviting) this.props.onDoneInviting();
                if (!this.props.renderMainBody) this.hide();
            }
            this.setState({ showOverlay: false });
            if (!DimensionUtils.isMobile()) {
                this.props.goToJoinGame();
            }
        }
    };

    onHostGameFail = (obj) => {
        if (this.props.isForHosting) {
            if (!this.props.renderBodyOnly) this.hide();
            createGeneralRequestFailureDialog({
                body: obj.msg,
            });
        }
    };

    deleteHostedGame = async () => {
        this.setState({ showOverlay: true });
        await deleteHostedGame();
        this.setState({ showOverlay: false });
    };

    isSendingInvite = () => !this.isForHosting();

    onSendGameRequest = async (opts) => {
        await this.setState({ showOverlay: true });
        let res = await to(sendLiveGameRequest(opts));
        let options = { visible: true };
        if (res[0]) {
            options.failureDetail = {
                message: 'Unable to send request',
                btnText: 'Back',
                onBtnClick: this.hide,
            };
        } else {
            options.failureDetail = {
                message: 'Waiting for player to accept game request..',
                timer: {
                    timeout: parseInt(get(res[1], 'data.wait')) * 1000,
                    onTimeOut: this.showExpiredMessage,
                },
                btnText: 'Cancel Request',
                onBtnClick: () => this.onCancelSentRequest(res[1]),
            };
        }
        this.setState({
            showOverlay: options.visible,
            failureDetail: options.failureDetail,
        });
    };

    showExpiredMessage = () => {
        this.setState({
            showOverlay: true,
            failureDetail: {
                message: 'Your game invitation has expired',
                btnText: 'OK',
                onBtnClick: this.hide,
            },
        });
    };

    onCancelSentRequest = async (res) => {
        this.setState({ showOverlay: true, failureDetail: null });
        let req = await to(cancelGamePlayRequest(res.data));
        if (req[1]) {
            this.hide();
        } else {
            this.setState({
                showOverlay: true,
                failureDetail: {
                    message: 'Request Failed',
                    btnText: 'Retry',
                    onBtnClick: () => this.onCancelSentRequest(res),
                },
            });
        }
    };

    getRatingRange = () => this.state.minRating + '-' + this.state.maxRating;

    isOpen = () => this.state.isOpen;

    onMatchRequestRejected = (res) => {
        if (this.isOpen() && !this.props.renderBodyOnly)
            this.setState({
                showOverlay: true,
                failureDetail: {
                    message: 'Player has rejected game request',
                    btnText: 'OK',
                    onBtnClick: this.hide,
                },
            });
    };

    onGuidChangeText = (guid_text) => this.setState({ guid_text });

    onTimerTimeOut = () =>
        this.state.failureDetail.timer.onTimeOut &&
        this.state.failureDetail.timer.onTimeOut();

    onFailureButtonPress = () =>
        this.state.failureDetail.onBtnClick &&
        this.state.failureDetail.onBtnClick();
}
const styles = StyleSheet.create({
    itemCenter: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    rowDirection: {
        flexDirection: 'row',
    },
    newGameTabRootStyle: {
        marginLeft: Config.DIALOG_GENERAL_MARGIN,
        marginRight: Config.DIALOG_GENERAL_MARGIN,
        marginBottom: Config.DIALOG_GENERAL_MARGIN,
    },
    newGameTabRootStyleForHosting: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: Config.RIGHT_LEFT_MARGIN,
        borderWidth: 0,
        borderColor: 'rgba(0,0,0,0)',
    },
    pickerContainerStyle: { flex: 1 },
    numberStepperLabel: {
        color: ColorConfig.NEW_HOST_GAMES_RATING_LABEL_COLOR,
        paddingBottom: 10,
    },
    pickersDividerStyle: { width: 10 },
    rowStyle: { flexDirection: 'row', marginBottom: 10 },
    title: {
        marginRight: Config.DIALOG_GENERAL_MARGIN,
        marginLeft: Config.DIALOG_GENERAL_MARGIN,
        marginTop: Config.DIALOG_GENERAL_MARGIN,
        color: ColorConfig.DIALOG_MODAL_HEADING_TEXT_COLOR,
        fontWeight: 'bold',
    },
    widthHundred: {
        width: '100%',
    },
    bodyBtnContainer: {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        marginTop: Config.DIALOG_GENERAL_MARGIN,
    },
    hostingBtnContainer: {
        width: '100%',
        flexDirection: 'row-reverse',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: Config.DIALOG_GENERAL_MARGIN,
    },
    buttonContainerMobileOverride: {
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    lastRowStyle: {
        flexDirection: 'row',
    },
    modalBackgroundColor: {
        backgroundColor: '#FFF',
        borderWidth: 0,
        borderColor: 'rgba(0,0,0,0)',
    },
    listBackgroundColor: {
        backgroundColor: ColorConfig.OBSERVABLE_GAMES_LIST_BACKGROUND_COLOR,
        borderWidth: 0,
        borderColor: 'rgba(0,0,0,0)',
    },
    closeButtonContainer: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    hostingCloseIcon: {
        marginLeft: 10,
        backgroundColor: 'rgb(194, 55, 66)',
        height: 20,
        width: 20,
        borderRadius: 20 / 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    overlayContainer: {
        height: '100%',
        width: '100%',
        borderRadius: 4,
        backgroundColor: '#f4f3ef',
        justifyContent: 'center',
        alignItems: 'center',
    },
    failureDetailLayout: {
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        position: 'absolute',
    },
    btnContainer: {
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: 32,
        paddingBottom: 32,
    },
    btn: {
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 3,
        backgroundColor: 'rgb(177, 46, 56)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    btnTextStyle: {
        color: '#fff',
    },
    marginFive: {
        margin: 5,
    },
    textIncrementStyle: {
        color: 'rgba(0, 0, 0, 0.54)',
    },
    setButton: {
        width: '35%',
        backgroundColor: '#3484f0',
        padding: 10,
    },
});

const mapStateToProps = (state) => ({
    layout: {
        layoutGamePlayAreaHeight: get(state, 'layout.layoutGamePlayAreaHeight'),
    },
});
export default connect(mapStateToProps, null, null, { forwardRef: true })(
    HostInviteGameModal
);
